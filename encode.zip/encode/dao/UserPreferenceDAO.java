package com.healogics.encode.dao;

import com.healogics.encode.dto.UserPreferenceReq;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface UserPreferenceDAO {

	boolean updateUserColorCodes(UserPreferenceReq req) throws EncodeExceptionHandler;

}
