package com.healogics.encode.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.encode.dto.AppNotificationsReq;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.entity.AppNotification;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface AppNotificationDAO {

	Boolean saveNoteNotifications(NotesReq req, int noteId)
			throws EncodeExceptionHandler;

	Boolean saveEscalateNoteNotifications(ChartDetailsReq req)
			throws EncodeExceptionHandler;

	public Long updateNotifications(AppNotificationsReq req)
			throws EncodeExceptionHandler;

	public List<AppNotification> getAppNotification(Long userId,
			Timestamp clearNotificationTimestamp,
			String last30DaysDate) throws EncodeExceptionHandler;

	public Long getNotificationCount(Long userId) throws EncodeExceptionHandler;

	Boolean saveWeaknessAppNotifications(ChartDetailsReq req)throws EncodeExceptionHandler;
	
	public Boolean saveProviderResponseNotifications(NotesReq req, int noteId)
			throws EncodeExceptionHandler;

	Boolean saveWeaknessAppNotificationsAuditor(SaveAuditDetailsReq req) throws EncodeExceptionHandler;

}
