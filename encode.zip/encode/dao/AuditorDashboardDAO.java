package com.healogics.encode.dao;

import java.util.List;
import java.util.Map;

import com.healogics.encode.dto.AuditorCollapsibleSectionData;
import com.healogics.encode.dto.AuditorCollapsibleSectionReq;
import com.healogics.encode.dto.AuditorDashboardFilter;
import com.healogics.encode.dto.AuditorDashboardReq;
import com.healogics.encode.dto.ChartByStatusReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.ReleaseByFilterChartReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.dto.SaveAuditDetailsRes;
import com.healogics.encode.dto.UpdateChartstatusReq;
import com.healogics.encode.dto.addOrRemovePinnedFilterReq;
import com.healogics.encode.entity.AuditQueue;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.Filters;
import com.healogics.encode.entity.InsuranceCarrier;
import com.healogics.encode.entity.Notes;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface AuditorDashboardDAO {

	public List<InsuranceCarrier> getInsuranceCarrier() throws EncodeExceptionHandler;

	public List<Reasons> getAuditorReasons() throws EncodeExceptionHandler;

	public SaveAuditDetailsRes saveAuditDetails(SaveAuditDetailsReq req) throws EncodeExceptionHandler;

	public Map<String, Object> getFilteredAuditorList(AuditorDashboardReq req, int index) throws EncodeExceptionHandler;

	public Long getTotalCount(int index, AuditorDashboardReq req) throws EncodeExceptionHandler;

	public List<Filters> getAllAuditRecords(AuditorDashboardReq req, int index, boolean includeAllData) throws EncodeExceptionHandler;
	
	public List<AuditQueue> getCollapseDetails(int filterId, AuditorCollapsibleSectionReq req)throws EncodeExceptionHandler;

	public AuditorDashboardFilter getAuditorFilterOptions(AuditorDashboardReq req) throws EncodeExceptionHandler;

	public void updateAuditChartStatus(UpdateChartstatusReq req, String auditStatus, String role) throws EncodeExceptionHandler;
	
	public void performUnbillableAction(UpdateChartstatusReq req,String auditStatus, String role) throws EncodeExceptionHandler;

	public AuditQueue getRecordByVisitId(long visitId)throws EncodeExceptionHandler;

	public void updatedCompletedStatus(UpdateChartstatusReq req, String completedStatus)throws EncodeExceptionHandler;

	public Long getCountOfAuditQueueByFilterId(int filterId, AuditorDashboardReq req) throws EncodeExceptionHandler;

	long fetchNextRecord(int filterId, Long currentVisitId, String role) throws EncodeExceptionHandler;

	public void updatedDashboardStatus(UpdateChartstatusReq req)throws EncodeExceptionHandler;

	public Dashboard getDashboardByVisitId(Long visitId)throws EncodeExceptionHandler;

	public List<Notes> getAuditNotes(NoteListReq req) throws EncodeExceptionHandler;

	public List<Object[]> getExcelAllAuditRecords(AuditorDashboardReq req, int index, boolean b) throws EncodeExceptionHandler;

	public FilterOptions retrieveCollapsibleFilterOption(AuditorCollapsibleSectionReq req, int filterId)throws EncodeExceptionHandler;

	public Map<String, Object> getCollapsibleFilteredData(int filterId, AuditorCollapsibleSectionReq req, int index,
			boolean isApplyPagination)throws EncodeExceptionHandler;

	public Map<String, Object> getAllFilteredAuditorList(AuditorDashboardReq req, int index, boolean b)throws EncodeExceptionHandler;

	public List<AuditorCollapsibleSectionData> getALLInAuditRecords() throws EncodeExceptionHandler;

	public List<AuditorCollapsibleSectionData> getChartByStatus(ChartByStatusReq req) throws EncodeExceptionHandler;

	public Reasons getNurseDispositionList() throws EncodeExceptionHandler;

	public List<Notification> fetchNotificationsByvisitId(Long visitId);

	public void updateStatus(UpdateChartstatusReq req, String string) throws EncodeExceptionHandler;

	public Long getPatientId(Long visitId);

	public PatientMedicalRecords getPatientMedicalRecord(Long patientId, Long visitId, List<String> docTypeList) throws EncodeExceptionHandler ;

	public Map<String, Object> getFilteredAuditorReleaseList(AuditorDashboardReq req, int index) throws EncodeExceptionHandler;

	public Long getCountOfAuditQueueByFilterIdRelease(int filterId, AuditorDashboardReq req) throws EncodeExceptionHandler;

	public void releaseByFilterChart(ReleaseByFilterChartReq req) throws EncodeExceptionHandler;

	Dashboard getRecordByVisitIdDashboard(long visitId) throws EncodeExceptionHandler;

	public EncodeUsers findByUserId(Long valueOf) throws EncodeExceptionHandler;

	public void addOrRemovePinnedFilter(addOrRemovePinnedFilterReq req) throws EncodeExceptionHandler;

	
}

