package com.healogics.encode.dao;

import java.util.List;

import com.healogics.encode.dto.SystemNotificationListReq;
import com.healogics.encode.dto.SystemNotificationWSAReq;
import com.healogics.encode.dto.UserNotificationReq;
import com.healogics.encode.entity.SystemNotification;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface SystemNotificationDAO {

	public String saveSystemNotifications(SystemNotificationWSAReq systemNotificationReq)
			throws EncodeExceptionHandler;

	public List<SystemNotification> getSystemNotifications(SystemNotificationListReq req)
			throws EncodeExceptionHandler;

	public void deleteNotifications(List<String> notificationIds) throws EncodeExceptionHandler;
	
	public void saveUserNotifications(UserNotificationReq userNotificationReq)
			throws EncodeExceptionHandler;

}
