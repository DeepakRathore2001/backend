package com.healogics.encode.dao;

import java.util.List;

import com.healogics.encode.dto.IHealUserObj;
import com.healogics.encode.dto.LoginUser;
import com.healogics.encode.dto.UserFacilities;

public interface UserLoginDAO {
	public void saveUserLogin(LoginUser loginUser);

	public void saveEncodeUserLogin(IHealUserObj iHealUserObj);

	public int saveUserFacilities(String userId, List<UserFacilities> facilities);
}
 