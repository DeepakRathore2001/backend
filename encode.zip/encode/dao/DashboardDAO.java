package com.healogics.encode.dao;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.EscalatedChartDetailsReq;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.ParsedDataDTO;
import com.healogics.encode.dto.PatientMedicalRecordsDTO;
import com.healogics.encode.dto.SaveRecordReq;
import com.healogics.encode.entity.CPTCodes;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.DisparateFacilities;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.entity.ICDCodesMaster;
import com.healogics.encode.entity.Notes;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.entity.WeeklyIncompleteReportEmail;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface DashboardDAO {
	public void savePending(SaveRecordReq req, String status)
		throws EncodeExceptionHandler;

	public Dashboard getRecordByVisitId(long visitId)
		throws EncodeExceptionHandler;
	
	public ChartDetails getChartRecordByVisitId(long visitId) 
			throws EncodeExceptionHandler;

	public void savePatientRecords(Dashboard dasboardObj, String doctype,
			String docContent, String docName,
			String docSource, Timestamp receivedTimestamp, 
			boolean isRecordExists, PatientMedicalRecords pntMedRecord)
		throws EncodeExceptionHandler;

	public int saveNotes(NotesReq req) throws EncodeExceptionHandler;

	public Long getTotalCount(NoteListReq req)
		throws EncodeExceptionHandler;

	public List<Notes> getCMCRetrieveNote(NoteListReq req)
		throws EncodeExceptionHandler;	
	
	public void saveUnbillable(SaveRecordReq req, String status)
		throws EncodeExceptionHandler;
	
	public void saveNotificationStatus(Notification notification)
		throws EncodeExceptionHandler;
	
	public void saveValidate(SaveRecordReq req, String status)
		throws EncodeExceptionHandler;
	
	public long fetchNextRecord(String userRole, List<String> bbcLis,Timestamp dosTimestamp,
			Timestamp nextDaytTimestamp, Long visitids)
			throws EncodeExceptionHandler;
	
	public Reasons getWeaknessReasons() throws EncodeExceptionHandler;
	
	public Reasons getDeficiencyList() throws EncodeExceptionHandler;
	
	public Reasons getEscalateReasonsList() throws EncodeExceptionHandler;

	public Map<String, Object> getLastAppliedFilter(long userId) throws EncodeExceptionHandler;

	public void saveChartDetails(ChartDetailsReq req)throws EncodeExceptionHandler;

	public Reasons getModifiersReasonsList() throws EncodeExceptionHandler;
	
	public List<CPTCodes> searchCPTCodes(String searchText)
			throws EncodeExceptionHandler;

	public ChartDetails getCPTCodeList(ChartDetailsReq req) throws EncodeExceptionHandler;
	
	public PatientMedicalRecords getPatientMedicalRecord(long patientId,
			long visitId, String docType) throws EncodeExceptionHandler;
	public Long getTotalCount(int index, String taskType, String assignee, EscalatedChartDetailsReq req,
			List<String> bbcList)throws EncodeExceptionHandler;

	public List<Object[]> searchEscalatedChart(EscalatedChartDetailsReq req, int index, String taskType, String assignee,
			List<String> bbclist) throws EncodeExceptionHandler;
	
	public FacilityDetails isFacilityExists(String bluebookCode) throws EncodeExceptionHandler;

	public void updateFacilityRecord(String bluebookCode, int i,
			String updateFacilityActiveQuery) throws EncodeExceptionHandler;

	public void persistFacilityRecords(FacilityDetails newRecord) throws EncodeExceptionHandler;

	public void updateFacilityType(String bluebookCode, String facilityType,
			String updateFacilityTypeQuery) throws EncodeExceptionHandler;
	
	public List<Notes> getEscalationDetails(Long visitId)
			throws EncodeExceptionHandler;
	
	public String getRule1CptCodes(int id) throws EncodeExceptionHandler;
	
	public List<Long> fetchSameDayVisit(int facilityId, Long patientId,
			Timestamp dateOfService, Timestamp nextDayDOS)
			throws EncodeExceptionHandler;

	public void savePatientBalancesZero(ParsedDataDTO parsedData, Timestamp receivedTimestamp, String errorCode, String errorMessage) throws EncodeExceptionHandler;
	
	public void savePatientBalancesLatestDOS(ParsedDataDTO parsedData, Timestamp receivedTimestamp, String errorCode, String errorMessage) throws EncodeExceptionHandler;

	public int getFacilityIdByBBC(String facilityCode) throws EncodeExceptionHandler;

	public String fetchCptObjectByVisitId(Long otherDayVisit) throws EncodeExceptionHandler;
	
	public void updateReturnedStatus(Long visitId, String dashboardName);
	
	public ChartDetails getChartRecordByMessageId(Long messageId) throws EncodeExceptionHandler;
	
	public void saveMessageIdInChartDetails(Long visitId, Long messageId);
	
	public Notes getNoteByNoteId(Long visitId, int noteId) throws EncodeExceptionHandler;

	public List<Notes> getRetrieveNote(NoteListReq req) throws EncodeExceptionHandler;
	
	public void saveIncompleteEmailSentStatus(WeeklyIncompleteReportEmail emailStatus)
			throws EncodeExceptionHandler;

	public List<ICDCodesMaster> searchICDFromDB(String searchText, int searchType, int offset, int count) throws EncodeExceptionHandler;

	public int getTotalCount(String searchText, int searchType) throws EncodeExceptionHandler;

	public List<Object[]> getinsuranceTypeFromDashboard(IHealPatientLoadReq req)throws EncodeExceptionHandler;

	public Long fetchNextRecords(String userRole, List<String> facilityidlist, Timestamp dosTimestamp,
			Timestamp nextDaytTimestamp, Long visitids, ChartDetailsReq req)throws EncodeExceptionHandler;
	
	public DisparateFacilities getDisparateBBC(String bbc) throws EncodeExceptionHandler;

	List<PatientMedicalRecordsDTO> fetchSBRecords(long patientId, long visitId) throws EncodeExceptionHandler;

	public void updateRecord(CoderDashboardReq req)throws EncodeExceptionHandler;

	public void savePatientBalancesSummary(ParsedDataDTO parsedData, Timestamp receivedTimestamp,
			String errorCode, String errorMessage) throws EncodeExceptionHandler;

}
