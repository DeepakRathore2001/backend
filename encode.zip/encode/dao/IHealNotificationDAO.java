package com.healogics.encode.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.encode.dto.IHealPatientLoadObj;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.IHealPatientLoadRes;
import com.healogics.encode.dto.IHealPatientReloadReq;
import com.healogics.encode.dto.IHealSuperBillLoadObj;
import com.healogics.encode.dto.IHealVisitObject;
import com.healogics.encode.dto.PlaceOfServiceObj;
import com.healogics.encode.dto.PlaceOfServiceRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ReloadPatientInsuranceReq;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.IHealNotificationReq;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.Patient;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.ReloadCMCMetrics;
import com.healogics.encode.entity.ReloadCoderMetrics;
import com.healogics.encode.entity.ReloadMetrics;

public interface IHealNotificationDAO {

	boolean saveDocumentNotificationData(Notification superbill, boolean successStatus);

	void savePatientDetails(IHealSuperBillLoadObj iHealSuperBillLoadObj, IHealVisitObject visitDetails,
			IHealPatientLoadObj patient, String visitId, String facilityId, IHealNotificationReq superbillNotReq,
			boolean isRowExist, PlaceOfServiceRes placeOfServiceRes);

	boolean createDashboardRow(IHealNotificationReq superbillNotReq, String facilityId, String visitId,
			String patientId, Timestamp eventDateTime, String snfLocationName, boolean isPNHBOReceived);

	void saveVisitDetails(IHealSuperBillLoadObj iHealSuperBillLoadObj, IHealVisitObject iHealVisitObject,
			String facilityId, String string, IHealNotificationReq iHealNotificationReq, boolean isRowExist,
			String snfLocationName, PlaceOfServiceRes placeOfServiceRes);

	void savePatientRecords(Dashboard dasboardObj, String documentType, long docEntityId, String string,
			Timestamp timestamp, boolean b, PatientMedicalRecords pmr, IHealNotificationReq iHealNotificationReq);

	void saveSuperBillDetails(IHealSuperBillLoadObj superbill, String visitID, String facilityID,
			IHealNotificationReq iHealNotificationReq, IHealVisitObject iHealVisitObject,
			IHealPatientLoadObj iHealPatientLoadObj, boolean isRowExist, PlaceOfServiceRes placeOfServiceRes);

	void saveInsuranceCarriers(IHealPatientLoadObj patient, String visitID);

	Dashboard getDashboardRowIfExist(String visitID);

	void saveSuperbillHistory(IHealNotificationReq iHealNotificationReq, IHealPatientLoadObj iHealPatientLoadObj,
			IHealVisitObject iHealVisitObject);

	void saveDataInSuperbillVarianceTable(IHealPatientLoadObj patient, IHealVisitObject visit,
			IHealSuperBillLoadObj superbill, IHealNotificationReq iHealNotificationReq);

	public void saveDashboard(Dashboard dashbord, boolean updateStatus);

	public List<Notification> fetchNotificationsByvisitId(Long visitId);
	
	public void saveVisitDetailsReload(IHealSuperBillLoadObj superbill,
			IHealVisitObject visitDetails, String visitID,
			String facilityId, IHealNotificationReq iHealNotificationReq,
			boolean isRowExist, String snfLocationName,
			PlaceOfServiceRes placeOfServiceRes);
	
	public List<ReloadMetrics> fetchSuperBillReloadMetrics(int size);
	
	public List<ReloadMetrics> fetchDocumentReloadMetrics(int size);
	
	public void updateReloadMetrics(ReloadMetrics metrics);

	Patient getPatientRowIfExist(String visitID);

	boolean createPatientRow(IHealNotificationReq iHealNotificationReq, String facilityID, String visitID,
			String patientID, Timestamp eventDateTime);

	APIResponse reloadPatientInsurance(ReloadPatientInsuranceReq req);
	
	public void updateReloadCoderMetrics(ReloadCoderMetrics metrics);
	
	public void saveDashboardnTimeline(Dashboard dashbord, String recordStatus,
			String timelineDesc);

	APIResponse reloadPatient(ReloadPatientInsuranceReq req);

	public void updateReloadCmcMetrics(ReloadCMCMetrics metrics);
	
	public List<ReloadCoderMetrics> fetchReloadCoderMetrics(int size);
	
	public List<ReloadCMCMetrics> fetchReloadCmcMetrics(int size);

	APIResponse reloadDeficiency(ReloadPatientInsuranceReq req);

	void saveSBPatientMedicalRecords(IHealSuperBillLoadObj superbill, IHealPatientLoadObj iHealPatientLoadObj, IHealVisitObject iHealVisitObject, IHealNotificationReq iHealNotificationReq);

}
