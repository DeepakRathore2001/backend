package com.healogics.encode.dao;

import java.util.List;
import java.util.Map;

import com.healogics.encode.dto.CoderProductivityReportData;
import com.healogics.encode.dto.CoderProductivityReportReq;
import com.healogics.encode.dto.EncounterMonthlyReviewData;
import com.healogics.encode.dto.EncounterUnderReviewCount;
import com.healogics.encode.dto.EncounterUnderReviewData;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.GuidanceReportReq;
import com.healogics.encode.dto.MissingChartFilter;
import com.healogics.encode.dto.NurseAuditNotesReportData;
import com.healogics.encode.dto.NurseAuditNotesReportReq;
import com.healogics.encode.dto.ReconReportData;
import com.healogics.encode.dto.ReconReportFilter;
import com.healogics.encode.dto.ReconReportReq;
import com.healogics.encode.dto.ReportFilterReq;
import com.healogics.encode.dto.SuperbillVarianceCount;
import com.healogics.encode.dto.UnderReviewFilter;
import com.healogics.encode.dto.WeeklyIncompleteReportData;
import com.healogics.encode.dto.ecWSentReportData;
import com.healogics.encode.dto.ecWSentReportReq;
import com.healogics.encode.entity.EncounterNeedingGuidanceReport;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface ReportDAO {

	public List<ReconReportData> getReconciliationReport(ReconReportReq req, int pazeSize, int index,
			boolean isPagination) throws EncodeExceptionHandler;

	public List<Object[]> getMonthlyChargeSummaryReport(ReconReportReq req) throws EncodeExceptionHandler;

	public List<Object[]> getDrillDownMonthlyChargeSummaryReport(String cptCodes, ReconReportReq req) throws EncodeExceptionHandler;

	public List<String> getCPTCodesReports(ReconReportReq req) throws EncodeExceptionHandler;

	public List<Object[]> getFacilitynLocationDetails() throws EncodeExceptionHandler;

	public List<SuperbillVarianceCount> superbillVarianceReportData(ReconReportReq req) throws EncodeExceptionHandler;

	public List<Object[]> getMissingChartData(ReconReportReq req) throws EncodeExceptionHandler;

	public List<Object[]> getDrillDownMissingChartReport(ReconReportReq req) throws EncodeExceptionHandler;

	public List<String> getFiltersData() throws EncodeExceptionHandler;

	public List<Object[]> getDrillDownPostAuditReport(ReconReportReq req, boolean isExcel)
			throws EncodeExceptionHandler;

	public List<EncounterNeedingGuidanceReport> fetchReportsByCoderIds(GuidanceReportReq req)
			throws EncodeExceptionHandler;

	public List<Object[]> generateSuperbillVarianceReport(int facilityId, ReconReportReq req)
			throws EncodeExceptionHandler;

	public List<EncounterUnderReviewCount> getEncounterUnderReviewCount(ReconReportReq req)
			throws EncodeExceptionHandler;

	public List<EncounterMonthlyReviewData> getEncounterUnderReviewmonthly(ReconReportReq req)
			throws EncodeExceptionHandler;

	public List<EncounterUnderReviewData> getEncounterUnderReviewReport(ReconReportReq req)
			throws EncodeExceptionHandler;

	public List<Object[]> deficiencyAgingReport(ReconReportReq req) throws EncodeExceptionHandler;

	public long getReconreportDataCount(ReconReportReq req) throws EncodeExceptionHandler;

	public List<WeeklyIncompleteReportData> weeklyIncompleteReportExcel(ReconReportReq req)
			throws EncodeExceptionHandler;

	public List<WeeklyIncompleteReportData> getWeeklyIncompleteList(String facilityId) throws EncodeExceptionHandler;

	public List<ReconReportData> getReconciliationReports(ReconReportReq req) throws EncodeExceptionHandler;

	public List<Object[]> getprovidersFromDashboard() throws EncodeExceptionHandler;

	public FilterOptions getAuditReportFilterOptions(ReportFilterReq req) throws EncodeExceptionHandler;

	public Map<String, Object> getFilteredPostAuditReport(ReportFilterReq req) throws EncodeExceptionHandler;

	public MissingChartFilter getMissingChartFilterOption(ReconReportReq req) throws EncodeExceptionHandler;

	public ReconReportFilter getReconReportFilterOptions(ReconReportReq req, int pazeSize, int index,
			boolean isPagination) throws EncodeExceptionHandler;
	public FilterOptions getSuperbillVarianceMultiFilterOptions(ReportFilterReq req)throws EncodeExceptionHandler;

	public Map<String, Object> deficiencyAgingReportFilteredData(ReconReportReq req)throws EncodeExceptionHandler;

	public FilterOptions getDeficiencyAgingMultiFilterOptions(ReportFilterReq req) throws EncodeExceptionHandler;

	public UnderReviewFilter getEncounterUnderReviewFilterOption(ReconReportReq req) throws EncodeExceptionHandler;

	public Map<String, Object> getFilteredSuperbillVarianceReport(ReportFilterReq req)throws EncodeExceptionHandler;

	public FilterOptions getEncounterNeedingGuidenceFilterOptions(ReportFilterReq req, List<Integer> coderId)throws EncodeExceptionHandler;

	public List<EncounterMonthlyReviewData> getFilteredEncounterUnderReviewmonthly(ReconReportReq req)throws EncodeExceptionHandler;

	public List<NurseAuditNotesReportData> getNurseAuditNotesReport( NurseAuditNotesReportReq req) throws EncodeExceptionHandler;

	public FilterOptions getEncounterUnderReviewMthlyFilterOptions(ReconReportReq req)throws EncodeExceptionHandler;

	public List<ecWSentReportData> ecWSentReport(ecWSentReportReq req) throws EncodeExceptionHandler;

	public FilterOptions getNurseAuditNotesReportOptions(NurseAuditNotesReportReq req) throws EncodeExceptionHandler;

	public List<CoderProductivityReportData> getCoderProductivityReport(CoderProductivityReportReq req)throws EncodeExceptionHandler;

	public Map<String, Object> getCoderProductivityReportDrilldownData(ReportFilterReq req)throws EncodeExceptionHandler;

	public FilterOptions getCoderProductivityFilterOptions(ReportFilterReq req)throws EncodeExceptionHandler;


}
