package com.healogics.encode.dao;

import com.healogics.encode.dto.ClickStreamReq;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface ClickStreamDAO {

	void saveClickStreamData(ClickStreamReq req)throws EncodeExceptionHandler;

}
