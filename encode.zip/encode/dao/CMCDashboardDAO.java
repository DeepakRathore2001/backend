package com.healogics.encode.dao;

import java.util.List;
import java.util.Map;

import com.healogics.encode.dto.CMCData;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface CMCDashboardDAO {

	public Map<String, Object> getFilteredCMCList(DashboardReq req, int index,
			String taskType, String assignee,
			List<String> bbcs, boolean isApplyPagination, List<String> facilityIdList) throws EncodeExceptionHandler;

	public Long getTotalCount(int index, String taskType, String assignee,
			DashboardReq req, List<String> bbcList, List<String> facilityIdList)
			throws EncodeExceptionHandler;

	public List<Dashboard> getAllCMCRecords(DashboardReq req, int index,
			String taskType, String assignee, List<String> bbclist,
			boolean isApplyPagination, List<String> facilityIdList) throws EncodeExceptionHandler;

	public FilterOptions getFilterOptions(DashboardReq req, List<String> bbcList, List<String> facilityIdList)
			throws EncodeExceptionHandler;

	Reasons getPendingReasons() throws EncodeExceptionHandler;
	
	public CMCData getCMCRecordById(DashboardReq req);

	public Reasons getUnbillableReasons() throws EncodeExceptionHandler;

	public void saveUserPreferences(String userId, DashboardReq req) throws EncodeExceptionHandler;
	
	public UserFacilityRes getuserFacilities(String userId) throws EncodeExceptionHandler;

	String getUserBBCList(String userId) throws EncodeExceptionHandler;

	public EncodeUsers findByUserId(Long valueOf) throws EncodeExceptionHandler;
	
}
