package com.healogics.encode.dao;

import java.util.List;
import java.util.Set;

import com.healogics.encode.dto.AuditFilterDetails;
import com.healogics.encode.dto.AuditorDrillDownReq;
import com.healogics.encode.dto.AuditorDrillDownRes;
import com.healogics.encode.dto.Coder;
import com.healogics.encode.dto.DeleteFilterReq;
import com.healogics.encode.dto.EditFilterNameRes;
import com.healogics.encode.dto.FilterLogicReq;
import com.healogics.encode.dto.SaveAuditFilterReq;
import com.healogics.encode.dto.SaveAuditorFilterRes;
import com.healogics.encode.dto.VisitDetails;
import com.healogics.encode.entity.Filters;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface AuditorFiltetDAO {
	public SaveAuditorFilterRes saveAuditorFilter(AuditFilterDetails filter) throws EncodeExceptionHandler;

	public Filters getAuditFilters(int filterId) throws EncodeExceptionHandler;

	public List<String> getCodingTeam() throws EncodeExceptionHandler;
	
	public List<Coder> getCoders() throws EncodeExceptionHandler;
	
	public void saveAuditFilter(SaveAuditFilterReq filter) throws EncodeExceptionHandler;

	public EditFilterNameRes updateFilters(SaveAuditFilterReq filterReq) throws EncodeExceptionHandler;

	public AuditorDrillDownRes getDrillDownData(AuditorDrillDownReq auditorDrillDownReq) throws EncodeExceptionHandler;

	public List<Long> getFilteredVisitIdsExcludingAssigned(Filters filter, Set<Long> usedVisitIds)
			throws EncodeExceptionHandler;

	public List<Filters> getAllFilters(FilterLogicReq req) throws EncodeExceptionHandler;

	public List<VisitDetails> fetchVisitDetails(List<Long> uniqueVisitIds, int filterId, String codingTeam, String units) throws EncodeExceptionHandler;

	public EditFilterNameRes editFilter(AuditFilterDetails filterReq) throws EncodeExceptionHandler;

	public EditFilterNameRes deleteFilter(DeleteFilterReq filterReq) throws EncodeExceptionHandler;

	public void updateFilterLimit(Filters filter, int size) throws EncodeExceptionHandler ;

	public boolean checkFilterLimit(Filters filter) throws EncodeExceptionHandler;
}
