package com.healogics.encode.dao;

import java.util.List;

import com.healogics.encode.dto.HistoryTimelineData;
import com.healogics.encode.entity.HistoryTimeline;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface HistoryTimelineDAO {
	public List<HistoryTimeline> getTimelineListByVisitId(
			int index, long visitId) throws EncodeExceptionHandler;
	public Long getHistoryCount(long visitId)
			throws EncodeExceptionHandler;
	public void saveHistoryTimeline(HistoryTimelineData history)
			throws EncodeExceptionHandler;
}
