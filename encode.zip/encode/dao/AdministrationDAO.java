package com.healogics.encode.dao;

import java.util.List;
import java.util.Map;

import com.healogics.encode.dto.AdminDashboardReq;
import com.healogics.encode.dto.CampusIndicatorData;
import com.healogics.encode.dto.CampusIndicatorReq;
import com.healogics.encode.dto.FacilityDetailsReq;
import com.healogics.encode.dto.RoleAssignmentReq;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface AdministrationDAO {

	List<EncodeUsers> getCoderUsersData(String coderRole) throws Exception;

	public Map<String, Object> getFilteredEncodeUsers(AdminDashboardReq req) throws EncodeExceptionHandler;

	public List<EncodeUsers> getEncodeUsersData(AdminDashboardReq req) throws EncodeExceptionHandler;

	public Long totalEncodeUsers() throws EncodeExceptionHandler;
	
	public List<String> getRoleAssignmentFilterOptions(AdminDashboardReq req) throws EncodeExceptionHandler;

	void saveEncodeRole(List<RoleAssignmentReq> userRoles)throws EncodeExceptionHandler;
	
	public List<String> getEncodeRoles() throws EncodeExceptionHandler;

	public List<EncodeUsers> getNurseUsers(String nurseRole)throws Exception;
	
	public List<FacilityDetails> getFacilityDetails() throws EncodeExceptionHandler;

	void UpdateCampusIndicator(List<CampusIndicatorData> indecator)throws EncodeExceptionHandler;

	public List<FacilityDetails> getFilteredFacilityDetails(FacilityDetailsReq req)  throws EncodeExceptionHandler;

	public List<String> getFacilitySettingsFilterOptions(FacilityDetailsReq req) throws EncodeExceptionHandler;


}
