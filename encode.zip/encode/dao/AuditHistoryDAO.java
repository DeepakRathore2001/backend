package com.healogics.encode.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.encode.dto.AuditHistoryData;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.entity.SuperBillHistory;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface AuditHistoryDAO {

	void saveAuditHistory(AuditHistoryData data) throws EncodeExceptionHandler;

	List<SuperBillHistory> getBillHistoryData(BillHistoryReq req,
			Timestamp encodeStartTimestamp) throws EncodeExceptionHandler;
}
