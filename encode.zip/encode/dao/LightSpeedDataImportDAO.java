package com.healogics.encode.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.encode.dto.IHealPatientLoadObj;
import com.healogics.encode.dto.IHealPatientLoadRes;
import com.healogics.encode.dto.IHealSuperBillLoadObj;
import com.healogics.encode.dto.IHealSuperBillLoadRes;
import com.healogics.encode.dto.IHealVisitLoadRes;
import com.healogics.encode.dto.IHealVisitObject;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.LightSpeedImport;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface LightSpeedDataImportDAO {

	List<LightSpeedImport> findByLimitAndOffset(int limit, int offset) throws EncodeExceptionHandler;

	List<Dashboard> findBySnfLocationBBC(String snfLocationBBC) throws EncodeExceptionHandler;

	void dashboardImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitIdStr, IHealPatientLoadObj patientObj,
			IHealVisitObject visitDetails, IHealSuperBillLoadRes superBillLoadRes, String snfLocationBBC) throws EncodeExceptionHandler;

	void chartDetailsImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitIdStr, IHealPatientLoadObj patient, IHealVisitObject visitObject,
			IHealSuperBillLoadObj superbill, String snfLocationBBC) throws EncodeExceptionHandler;

	void superbillHistoryImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitIdStr, IHealPatientLoadObj iHealPatientLoadObj, IHealVisitObject iHealVisitObject,
			IHealSuperBillLoadObj superbill, String snfLocationBBC) throws EncodeExceptionHandler;

	void superbillVarianceImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitIdStr, IHealPatientLoadObj patient, IHealVisitObject visit,
			IHealSuperBillLoadObj superbill, String snfLocationBBC) throws EncodeExceptionHandler;

	void patientAndInsuranceImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitIdStr, IHealPatientLoadObj patientObj, IHealVisitObject visitDetails,
			IHealSuperBillLoadObj superbill, String snfLocationBBC) throws EncodeExceptionHandler;

	void updateImportStatus(int visitId, String string, String string2, String errorMessage, Timestamp timestamp) throws EncodeExceptionHandler;

}
