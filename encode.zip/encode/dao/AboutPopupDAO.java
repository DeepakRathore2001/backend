package com.healogics.encode.dao;

import com.healogics.encode.dto.SaveBuildDetailsReq;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface AboutPopupDAO {

	public void saveBuildDetails(SaveBuildDetailsReq req) throws EncodeExceptionHandler;

}
