package com.healogics.encode.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.healogics.encode.dto.EncounterStatusReportReq;
import com.healogics.encode.entity.EncounterStatusReport;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface EncounterStatusReportDAO {

	List<Object[]> getEncounterStatusReportdata() throws EncodeExceptionHandler;

	List<Object[]> generateEncounterReport(Date startDate, Date endDate, List<String> bbcList,
			List<String> facilityTypeList, List<String> providerNameList,
			List<String> providerIdList, List<Integer> facilityIdList, EncounterStatusReportReq req, List<String> facilityTypeList1)throws EncodeExceptionHandler;

	  Timestamp getEarliestDate();

	  Timestamp getLastDate();

}
