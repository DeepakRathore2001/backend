package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.BOConstants.ERRORCODE;
import static com.healogics.encode.constants.BOConstants.ERRORMESSAGE;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.DashboardDAO;
import com.healogics.encode.dao.IHealNotificationDAO;
import com.healogics.encode.dao.LightSpeedDataImportDAO;
import com.healogics.encode.dto.HistoryTimelineData;
import com.healogics.encode.dto.IHealGuarantorObj;
import com.healogics.encode.dto.IHealInsuranceObj;
import com.healogics.encode.dto.IHealInsuredObj;
import com.healogics.encode.dto.IHealPatientLoadObj;
import com.healogics.encode.dto.IHealPatientLoadRes;
import com.healogics.encode.dto.IHealSuperBillLoadObj;
import com.healogics.encode.dto.IHealSuperBillLoadRes;
import com.healogics.encode.dto.IHealUserFacilityListGetRes;
import com.healogics.encode.dto.IHealVisitLoadRes;
import com.healogics.encode.dto.IHealVisitObject;
import com.healogics.encode.dto.IhealFacility;
import com.healogics.encode.dto.IhealFacilityListGetReq;
import com.healogics.encode.dto.ProcedureProviderEMObj;
import com.healogics.encode.dto.UserFacilities;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.DisparateFacilities;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.entity.LightSpeedImport;
import com.healogics.encode.entity.Patient;
import com.healogics.encode.entity.PatientInsurance;
import com.healogics.encode.entity.PlaceOfServiceDetails;
import com.healogics.encode.entity.SuperBillHistory;
import com.healogics.encode.entity.SuperbillVariance;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.service.HistoryTimelineBO;

@Repository
@Transactional
public class LightSpeedDataImportDAOImpl implements LightSpeedDataImportDAO{
	

	private final Logger log = LoggerFactory
			.getLogger(IHealNotificationDAOImpl.class);

	private final SessionFactory sessionFactory;
	private final HistoryTimelineBO historyTimelineBO;
	private final DashboardDAO dashboardDAO;
	
	private final Environment env;
	private final RestTemplate restTemplate;


	@Autowired
	public LightSpeedDataImportDAOImpl(SessionFactory sessionFactory,
			HistoryTimelineBO historyTimelineBO, DashboardDAO dashboardDAO,
			Environment env, RestTemplate restTemplate) {
		this.sessionFactory = sessionFactory;
		this.historyTimelineBO = historyTimelineBO;
		this.dashboardDAO = dashboardDAO;
		this.env = env;
		this.restTemplate = restTemplate;
	}
	
	@Override
	public List<LightSpeedImport> findByLimitAndOffset(int limit, int offset) {

		Session session = this.sessionFactory.getCurrentSession();
		List<LightSpeedImport> lightSpeedImport = null;
		log.info("find by limit and offset");

		try {
			String hql = "FROM LightSpeedImport l order by visitId";

			Query<LightSpeedImport> query = session.createQuery(hql, LightSpeedImport.class);
			query.setFirstResult(offset);
			query.setMaxResults(limit);

			lightSpeedImport = query.list();
		} catch (Exception e) {
			log.error("Exception occured while find by limit and offset : {}", e.getMessage());
		}

		return lightSpeedImport;
	}

	@Override
	public List<Dashboard> findBySnfLocationBBC(String snfLocationBBC) throws EncodeExceptionHandler{
	    Session session = this.sessionFactory.getCurrentSession();
	    List<Dashboard> dashboards = null;
	    log.info("find by snf location bbc");
	    try {
	        String hql = "FROM Dashboard d WHERE d.snfLocationBBC = :snfLocationBBC";
	 
	        Query<Dashboard> query = session.createQuery(hql, Dashboard.class);
	        query.setParameter("snfLocationBBC", snfLocationBBC);

	        dashboards = query.list();
	 
	    } catch (Exception e) {
	        log.error("Exception occurred while fetching Dashboard details: {}", e.getMessage());
	    }
	 
	    return dashboards;
	}
	
	@Override
	public void dashboardImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitId, IHealPatientLoadObj patientObj,
			IHealVisitObject visitDetails, IHealSuperBillLoadRes superBillLoadRes, String snfLocationBBC)
			throws EncodeExceptionHandler {

		Session session = sessionFactory.getCurrentSession();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		LocalDateTime localDateTime = LocalDateTime.parse(patientObj.getPatientDOB(), formatter);
		Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
		log.info("Dashboard Import");

		try {
			// Create a new Dashboard entity
			Dashboard dashboard = new Dashboard();
			dashboard.setFacilityId(Integer.parseInt(facilityId));
			dashboard.setPatientId(Long.parseLong(patientId));
			dashboard.setVisitId(Long.parseLong(visitId));
			dashboard.setIsLocked(0);
			dashboard.setLastUpdatedByTimestamp(new Timestamp(System.currentTimeMillis()));
			dashboard.setLastUpdatedByUserFullName("Encode System");
			dashboard.setLastUpdatedByUserId("0");
			dashboard.setLastUpdatedByUsername("");
			dashboard.setMessageDatetime(new Timestamp(System.currentTimeMillis()));
			dashboard.setReceivedDate(new Timestamp(System.currentTimeMillis()));

			FacilityDetails facilityDetails = getFacilityDetails(facilityId);

			if (facilityDetails != null) {
				dashboard.setIhealConfig(facilityDetails.getCurrentIHealConfig());
				dashboard.setFacilityAlias(facilityDetails.getFacilityName());
				dashboard.setFacilityType(facilityDetails.getCurrentFacilityType());
				dashboard.setBluebookId(facilityDetails.getBluebookId());
			} else {
				dashboard.setIhealConfig(facilityType);
				dashboard.setBluebookId(bluebookId);
				dashboard.setFacilityAlias(facilityAlias);
				dashboard.setFacilityType(facilityType);

			}

			// Handling SNF location
			if (snfLocationName != null && snfLocationBBC != null && bluebookId != null) {
				dashboard.setSNFLocation(true);
				dashboard.setSnfLocationBBC(snfLocationBBC);
				dashboard.setSnfLocationName(snfLocationName);
			} else {
				log.debug("FacilityDetails: {}", facilityDetails);
				if (facilityDetails != null) {
					dashboard.setSnfLocationBBC(snfLocationBBC);
					dashboard.setSnfLocationName(facilityDetails.getFacilityName());
				}

			}

			// Handling patient details
			if (patientObj != null) {
				dashboard.setPatientFirstName(patientObj.getPatientFirstName());
				dashboard.setPatientLastName(patientObj.getPatientLastName());
				dashboard.setPatientName(patientObj.getPatientLastName() + ", " + patientObj.getPatientFirstName());
				dashboard.setPatientDOB(date);
				dashboard.setGender(patientObj.getPatientSex());
				dashboard.setMedicalRecordNumber(patientObj.getPatientNumber());
				for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
					if (insuranceObj.getSequence() == 1) {
						dashboard.setPrimaryInsurance(insuranceObj.getInsuranceName());
					} else if (insuranceObj.getSequence() == 2) {
						dashboard.setSecondaryInsurance(insuranceObj.getInsuranceName());
					}
				}
			}

			// Handling visit details
			if (visitDetails != null) {
				dashboard.setProviderId(String.valueOf(visitDetails.getProviderId()));
				dashboard.setProviderFirstName(visitDetails.getProviderFirstName());
				dashboard.setProviderLastName(visitDetails.getProviderLastName());
				dashboard.setProviderName(
						visitDetails.getProviderLastName() + ", " + visitDetails.getProviderFirstName());
				dashboard.setEncounterType(visitDetails.getVisitTypeDescription());
				dashboard.setServiceLine(visitDetails.getServiceLineDescription());

				String visitDateTime = visitDetails.getVisitDateTime();
				DateTimeFormatter formatter1 = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
				OffsetDateTime offsetDateTime = OffsetDateTime.parse(visitDateTime, formatter1);
				LocalDateTime localDateTime1 = offsetDateTime.toLocalDateTime();
				Timestamp dosTimestamp = Timestamp.valueOf(localDateTime1);

				log.info("Date Format for DOS Visit details : {} ", visitDetails.getVisitDateTime());
				log.info("Date Format for DOS Visit details After Format: {} ", dosTimestamp);

				dashboard.setDateOfService(dosTimestamp);
				dashboard.setEventDatetime(dosTimestamp);

			}

			// Save to the database without setting the status and timeline
			session.saveOrUpdate(dashboard);
			session.flush();
			log.info("Dashboard entry created successfully for VisitId: {}", visitId);

			// Now, update the status and timeline after saving the dashboard
			String fcilityConfig = "";

			UserFacilityRes facilityRes = getUserFacilities(
					env.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_USERID),
					env.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN));

			if (facilityRes != null && facilityRes.getResponseCode().equalsIgnoreCase("0")
					&& facilityRes.getFacilities() != null) {
				List<UserFacilities> facilities = facilityRes.getFacilities().stream().filter(
						f -> f != null && f.getFacilityId() != null && f.getFacilityId().equalsIgnoreCase(facilityId))
						.collect(Collectors.toList());

				if (facilities != null && facilities.size() > 0) {
					UserFacilities facility = facilities.get(0);
					log.debug("facility : " + facility);
					if (facility != null) {
						fcilityConfig = facility.getConfiguration();
						log.debug("fcilityConfig : " + fcilityConfig);
					}
				}
			}

			// Handle different visit types and update status
			if (visitDetails != null && visitDetails.getVisitTypeCode() == 8
					&& visitDetails.getVisitTypeDescription() != null
					&& visitDetails.getVisitTypeDescription().equalsIgnoreCase("Nurse Visit")) {
				dashboard.setStatus("Unbillable");
				dashboard.setLastStatusChangeRole("Coder");

				// Save timeline after setting status
				saveTimeline(Long.parseLong(visitId), "Unbillable", null, 0L, "i-heal", "New chart has been added",
						"Coder");

			} else if (visitDetails != null && visitDetails.getServiceLineDescription() != null
					&& (visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")
							|| visitDetails.getServiceLineDescription().equalsIgnoreCase("Inpatient"))) {

				dashboard.setStatus("New");
				dashboard.setLastStatusChangeRole("CMC");

				// Save timeline after setting status
				saveTimeline(Long.parseLong(visitId), "New", null, 0L, "i-heal", "New chart has been added", "CMC");

			} else if (!fcilityConfig.isEmpty()
					&& (fcilityConfig.equalsIgnoreCase("OT") || fcilityConfig.equalsIgnoreCase("POS"))) {

				dashboard.setStatus("New");
				dashboard.setLastStatusChangeRole("CMC");

				// Save timeline after setting status
				saveTimeline(Long.valueOf(visitId), "New", null, 0L, "i-heal", "New chart has been added", "CMC");

			} else {

				String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
				DisparateFacilities disparateFacilities = session.createQuery(hqlDisparate, DisparateFacilities.class)
						.setParameter("bluebookId", bluebookId).setMaxResults(1).uniqueResult();

				// Disparate facility

				if (disparateFacilities != null && visitDetails != null
						&& visitDetails.getServiceLineDescription() != null
						&& !visitDetails.getServiceLineDescription().equalsIgnoreCase("Outpatient")
						&& !fcilityConfig.isEmpty() && fcilityConfig.equalsIgnoreCase("EMR")) {

					dashboard.setStatus("New");
					dashboard.setLastStatusChangeRole("CMC");

					// Save timeline after setting status
					saveTimeline(Long.valueOf(visitId), "New", null, 0L, "i-heal", "New chart has been added", "CMC");

				} else {

					dashboard.setLastStatusChangeRole("Coder");
					dashboard.setStatus("Ready");

					// Save timeline after setting status
					saveTimeline(Long.valueOf(visitId), "Ready", null, 0L, "i-heal", "Chart ready", "Coder");

				}
			}

			// Save the updated status back to the dashboard after timeline
			session.update(dashboard);
			session.flush();

			log.info("Dashboard status and timeline updated successfully for VisitId: {}", visitId);

		} catch (Exception e) {
			log.error("Error inserting data into Dashboard table: {}", e.getMessage());
			throw new RuntimeException("Error while importing data to Dashboard", e);
		}

	}
	 
	
	@Override
	public void chartDetailsImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitId, IHealPatientLoadObj patientObj,
			IHealVisitObject visitObject, IHealSuperBillLoadObj superbill, String snfLocationBBC)
			throws EncodeExceptionHandler {

		Session session = sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		ObjectMapper objectMapper = new ObjectMapper();
		String actualCPTCode = "";
		log.info("Chart Details Import");

		try {
			
			DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
			OffsetDateTime offsetDateTime = OffsetDateTime
					.parse(visitObject.getVisitDateTime(), formatter);			
			Date dosDate =Date.from(offsetDateTime.toInstant());
			
			String sbillFacilityEM = null;
			if(superbill.getProcedureFacilityEM() != null) {
				try {
					sbillFacilityEM = objectMapper.writeValueAsString(superbill.getProcedureFacilityEM());
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillFacilityEM data JSON: {}" + e.getMessage());
				}
			}
			
			String sbillICDCodes = null;
			if(superbill.getCodeDiagnosis() != null && !superbill.getCodeDiagnosis().isEmpty()) {
				try {
					sbillICDCodes = objectMapper.writeValueAsString(superbill.getCodeDiagnosis());
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillICDCodes data JSON: {}" + e.getMessage());
				}
			}
			
			String sbillProviderCPTCodes = null;
			if(superbill.getProcedures() != null && !superbill.getProcedures().isEmpty()) {
				try {
					sbillProviderCPTCodes = objectMapper.writeValueAsString(superbill.getProcedures());
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillProviderCPTCodes data JSON: {}" + e.getMessage());
				}
			}
			
			String sbillProviderEM = null;
			if(superbill.getProcedureProviderEM() != null) {
				try {
					sbillProviderEM = objectMapper.writeValueAsString(superbill.getProcedureProviderEM());
					actualCPTCode = superbill.getProcedureProviderEM().getCode();
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillProviderEM data JSON: {}" + e.getMessage());
				}
			}
			
			String placeOfServiceString = null;
			FacilityDetails facilityDetails = getFacilityDetails(facilityId);
			if (facilityDetails != null
					&& "Outpatient Hospital".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())
					|| "Office".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {
				if( visitObject.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
					placeOfServiceString = "HSP Inpatient Consult";
				}
				
				if ("Home Visit".equals(visitObject.getLocationDescription())) {
						PlaceOfServiceDetails posDetails = getPlaceOfService("12");
						if (posDetails != null) {
							placeOfServiceString = posDetails.getPosName();
						}
				}
				if ("19".equals(facilityDetails.getPlaceOfService())) {
					PlaceOfServiceDetails posDetails = getPlaceOfService("19");
					if (posDetails != null) {
						placeOfServiceString = posDetails.getPosName();
					}
				}
				if ("22".equals(facilityDetails.getPlaceOfService())) {
					PlaceOfServiceDetails posDetails = getPlaceOfService("22");
					if (posDetails != null) {
						placeOfServiceString = posDetails.getPosName();
					}
				}

			}

			if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
				// Fetching place of Service from ENC DB
				if ("Skilled Nursing Facility".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {
					PlaceOfServiceDetails posDetails = getPlaceOfServiceSNF(superbill.getPlaceOfServiceCode().toString(), "SNF");
					if (posDetails != null) {
						placeOfServiceString = posDetails.getPosName();
					}else{
						posDetails = getPlaceOfService(superbill.getPlaceOfServiceCode().toString());
						if (posDetails != null) {
							placeOfServiceString = posDetails.getPosName();
				 		}
					}
				}
			}
			
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(Long.parseLong(patientId));
			newRecord.setVisitId(Long.parseLong(visitId));
			newRecord.setProviderName(visitObject.getProviderFirstName() + " " + visitObject.getProviderLastName());				
			newRecord.setLastUpdatedTimestamp(currentTime);
			newRecord.setSuperBillfacilityEM(sbillFacilityEM);
			newRecord.setSuperBillICDCodes(sbillICDCodes);
			newRecord.setSuperBillProviderCPTCodes(sbillProviderCPTCodes);
			newRecord.setSuperBillProviderEM(sbillProviderEM);
			newRecord.setPatientAdmitDate(dosDate);
			newRecord.setPlaceOfService(placeOfServiceString);
//			newRecord.setCocId(iHealNotificationReq.getCoc2Id());
			newRecord.setChildBluebookId(bluebookId);
			session.save(newRecord);
			log.debug("Saved SuperBillDetails Method in Chart Details:  {} {}" + visitId + " "
					+ superbill);
			

		} catch (Exception e) {
			log.error("Error inserting data into ChartDetails table: {}", e.getMessage());
			throw new RuntimeException("Error while importing data to ChartDetails", e);
		}

	}
	
	@Override
	public void superbillHistoryImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitId, IHealPatientLoadObj iHealPatientLoadObj,
			IHealVisitObject iHealVisitObject, IHealSuperBillLoadObj superbill, String snfLocationBBC)
			throws EncodeExceptionHandler {

		Session session = sessionFactory.getCurrentSession();
		log.info("Super Bill History Import");

		
        FacilityDetails facilityDetails = getFacilityDetails(facilityId);
		
		String facilityName = null;

		if (facilityDetails != null) {
			facilityName = facilityDetails.getFacilityName();
			bluebookId = facilityDetails.getBluebookId();
		} else {
			facilityName = facilityAlias;
		}

		try {

			SuperBillHistory newRecord = new SuperBillHistory();
			newRecord.setVisitId(Long.parseLong(visitId));
			DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
			OffsetDateTime offsetDateTime = OffsetDateTime.parse(iHealVisitObject.getVisitDateTime(), formatter);
			Timestamp dosTimestamp = Timestamp.from(offsetDateTime.toInstant());

			newRecord.setPatientDOS(dosTimestamp);
			newRecord.setPatientId(Long.parseLong(patientId));
			newRecord.setFacilityId(Integer.parseInt(facilityId));
			newRecord.setFacilityName(facilityName);
			newRecord.setBluebookId(bluebookId);
			newRecord.setPatientFirstName(iHealPatientLoadObj.getPatientFirstName());
			newRecord.setPatientLastName(iHealPatientLoadObj.getPatientLastName());
			newRecord.setPatientFullName(
					iHealPatientLoadObj.getPatientLastName() + ", " + iHealPatientLoadObj.getPatientFirstName());

			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
			LocalDateTime localDateTime = LocalDateTime.parse(iHealPatientLoadObj.getPatientDOB(), formatter1);
			Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());

			newRecord.setPatientDob(date);
			newRecord.setPatientMrn(iHealPatientLoadObj.getPatientNumber());
//			newRecord.setStatus(" ");
			newRecord.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
			newRecord.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
			newRecord.setClaimSentDate(new Timestamp(System.currentTimeMillis()));
			newRecord.setLastUpdatedByUser("Encode System");
			if (iHealVisitObject.getProviderId() == 0) {
				newRecord.setProviderId(0L);
			} else {
				newRecord.setProviderId(Long.valueOf(iHealVisitObject.getProviderId()));
			}
			newRecord.setProviderFirstName(iHealVisitObject.getProviderFirstName());
			newRecord.setProviderLastName(iHealVisitObject.getProviderLastName());

			session.saveOrUpdate(newRecord);

		} catch (Exception e) {
			log.error("Error inserting data into super bill history table: {}", e.getMessage());
			throw new RuntimeException("Error while importing data to super bill history table", e);
		}

	}
	
	@Override
	public void superbillVarianceImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitId, IHealPatientLoadObj patient,
			IHealVisitObject visit, IHealSuperBillLoadObj superbill, String snfLocationBBC)
			throws EncodeExceptionHandler {

		Session session = sessionFactory.getCurrentSession();
		log.info("Super Bill Variance Import");
		
		 FacilityDetails facilityDetails = getFacilityDetails(facilityId);
			
			String facilityName = null;

			if (facilityDetails != null) {
				facilityName = facilityDetails.getFacilityName();
				bluebookId = snfLocationBBC;
			} else {
				facilityName = facilityAlias;
				bluebookId = snfLocationBBC;
			}

		try {

			SuperbillVariance data = new SuperbillVariance();

			data.setVisitId(Long.parseLong(visitId));
			data.setFacilityId(Integer.parseInt(facilityId));
			data.setFacilityName(facilityName);
			data.setProviderId(visit.getProviderId());
			data.setBluebookId(bluebookId);
			String providerFullName = visit.getProviderFirstName() + ", " + visit.getProviderLastName();
			data.setProviderName(providerFullName);
			String patientFullName = patient.getPatientLastName() + ", " + patient.getPatientFirstName();
			data.setPatientName(patientFullName);
			ProcedureProviderEMObj obj = new ProcedureProviderEMObj();
			data.setPotentialCptCode(obj.getCode());
			DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
			OffsetDateTime offsetDateTime = OffsetDateTime.parse(visit.getVisitDateTime(), formatter);
			Timestamp dosTimestamp = Timestamp.from(offsetDateTime.toInstant());

			data.setDateOfService(dosTimestamp);

			ProcedureProviderEMObj obj1 = superbill.getProcedureProviderEM();
			data.setPotentialCptCode(obj1.getCode());
			session.saveOrUpdate(data);
			

		} catch (Exception e) {
			log.error("Error inserting data into super bill variance table: {}", e.getMessage());
			throw new RuntimeException("Error while importing data to super bill variance table", e);
		}

	}
	
	@Override
	public void patientAndInsuranceImport(String bluebookId, String facilityAlias, String facilityType, String snfLocationName,
			String facilityId, String patientId, String visitId, IHealPatientLoadObj patientObj,
			IHealVisitObject visitDetails, IHealSuperBillLoadObj superbill, String snfLocationBBC)
			throws EncodeExceptionHandler {

		Session session = sessionFactory.getCurrentSession();
		log.info("Patient and Insurance Import");
		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		DateTimeFormatter formatter = DateTimeFormatter
				.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		LocalDateTime localDateTime = LocalDateTime
				.parse(patientObj.getPatientDOB(), formatter);
		Date date = Date.from(localDateTime
				.atZone(ZoneId.systemDefault()).toInstant());
		FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
		try {
			    Patient patient = new Patient();
			 
		        patient.setVisitId(Long.parseLong(visitId));
		        patient.setFacilityId(Integer.parseInt(facilityId));
		        patient.setPatientId(patientId);
		      //  patient.setFacilityName(facilityAlias);
		        patient.setGivenName(patientObj.getPatientFirstName());
	            patient.setFamilyName(patientObj.getPatientLastName());
	            patient.setPatientGender(patientObj.getPatientSex());
	            patient.setDateOfBirth(date);
	            patient.setStreetAddress(patientObj.getAddress1());
	            patient.setCity(patientObj.getCity());
	            patient.setState(patientObj.getState());
	            patient.setZipCode(patientObj.getZip());
	            patient.setLocationDescription(patientObj.getLocationDescription());
	            patient.setPhone1(patientObj.getPhone1());
	            patient.setPhone2(patientObj.getPhone2());
	            patient.setEmailId(patientObj.getEmail());

	            if (patientObj.getGuarantor() != null) {
	                IHealGuarantorObj guarantor = patientObj.getGuarantor();
	                patient.setGuarantorGivenName(guarantor.getFirstName());
	                patient.setGuarantorFamilyName(guarantor.getLastName());
	                patient.setGuarantorStreetAddress(guarantor.getAddress1());
	                patient.setGuarantorCity(guarantor.getCity());
	                patient.setGuarantorState(guarantor.getState());
	                patient.setGuarantorZip(guarantor.getZip());
	                patient.setGuarantorRelation(guarantor.getRelationship());
	            }
	            
	            
	    		if (facilityDetails != null) {
					
					String blueBookIDPOS = null;
					
					if (visitDetails != null && visitDetails.getServiceLineDescription() != null
							&& visitDetails.getServiceLineDescription()
							.equalsIgnoreCase("HSP Inpatient Consult")) {
						
						blueBookIDPOS = "281_" + (snfLocationBBC != null ? snfLocationBBC : "");
						
					} else if (visitDetails != null && visitDetails.getLocationDescription() != null
							&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {
						
						blueBookIDPOS = "12" + (snfLocationBBC != null ? snfLocationBBC : "");
						
					} else if (facilityDetails != null
							&& facilityDetails.getCurrentFacilityType() != null
							&& "Skilled Nursing Facility"
									.equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

						if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
							blueBookIDPOS = superbill.getPlaceOfServiceCode()
									+ (snfLocationBBC != null ? snfLocationBBC : "");
						}
					} else {
						blueBookIDPOS = (snfLocationBBC != null ? snfLocationBBC : "");
					}
					
					patient.setBluebookId(blueBookIDPOS);
					patient.setFacilityName(facilityDetails.getFacilityName() != null ? facilityDetails.getFacilityName() : facilityAlias);
					patient.setPointOfCare(facilityDetails.getFacilityName() != null ? facilityDetails.getFacilityName() : facilityAlias);
					patient.setBed(blueBookIDPOS);
					patient.setFloor(facilityDetails.getFacilityName() != null ? facilityDetails.getFacilityName() : facilityAlias);
					patient.setBirthPlace(blueBookIDPOS);
				}
				patient.setAttendingDocId(String.valueOf(visitDetails.getProviderId()));
				patient.setAttendingDocName(
						visitDetails.getProviderFirstName() + " " + visitDetails.getProviderLastName());
				patient.setAdmittingDocId(String.valueOf(visitDetails.getProviderId()));
				patient.setAdmittingDocFamilyName(visitDetails.getProviderLastName());
				patient.setAdmittingDocGivenName(visitDetails.getProviderFirstName());
		        patient.setLastUpdatedTimestamp(currentTimestamp);
		        log.debug("Patient: {}", patient.toString());
		        session.saveOrUpdate(patient);
		        
		        String hqlDelete = "DELETE FROM PatientInsurance WHERE visitId = :visitId";
				Query query = session.createQuery(hqlDelete);
				query.setParameter("visitId", Long.valueOf(visitId));
				int deletedCount = query.executeUpdate();
				log.debug("Deleted {} PatientInsurance records with visitId {} {}", deletedCount, visitId);
				 
				// Save new PatientInsurance entities
				if (patientObj.getInsurance() != null && !patientObj.getInsurance().isEmpty()) {
				    for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
				        if (insuranceObj != null) { 
				            log.debug("Processing Insurance: {}", insuranceObj);
				            PatientInsurance patientInsurance = new PatientInsurance();
				            patientInsurance.setVisitId(Long.parseLong(visitId));
				            patientInsurance.setPatientId(patientObj.getPatientId());
				            patientInsurance.setFamilyName(patientObj.getPatientLastName());
				            patientInsurance.setGivenName(patientObj.getPatientFirstName());
				            patientInsurance.setFacilityId(facilityId);
				           
				            String blueBookIDPOS = null;
							if (visitDetails != null && visitDetails.getServiceLineDescription() != null
									&& visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
								blueBookIDPOS = "281_" + (snfLocationBBC != null ? snfLocationBBC : "");
							} else if (visitDetails != null && visitDetails.getLocationDescription() != null
									&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {
								blueBookIDPOS = "12" + (snfLocationBBC != null ? snfLocationBBC : "");
							} else if (facilityDetails != null && facilityDetails.getCurrentFacilityType() != null
									&& "Skilled Nursing Facility"
											.equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

								if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
									blueBookIDPOS = superbill.getPlaceOfServiceCode()
											+ (snfLocationBBC != null ? snfLocationBBC : "");
								}
							} else {
								blueBookIDPOS = (snfLocationBBC != null ? snfLocationBBC : "");

							}
							patientInsurance.setBluebookId(blueBookIDPOS);
				            patientInsurance.setInsuranceId(String.valueOf(insuranceObj.getInsuranceId()));
				            patientInsurance.setInsuranceName(insuranceObj.getInsuranceName());
				            patientInsurance.setStreetAddress(insuranceObj.getAddress1());
				            patientInsurance.setOtherDesignation(insuranceObj.getAddress2());
				            patientInsurance.setPriority(String.valueOf(insuranceObj.getSequence()));
				            patientInsurance.setCity(insuranceObj.getCity());
				            patientInsurance.setState(insuranceObj.getState());
				            patientInsurance.setZip(insuranceObj.getZip());
				            if (insuranceObj.getInsured() != null) {
				                IHealInsuredObj insuredObj = insuranceObj.getInsured();
				                patientInsurance.setInsuredFamilyName(insuredObj.getLastName());
				                patientInsurance.setInsuredGivenName(insuredObj.getFirstName());
				                patientInsurance.setInsuredRelation(insuredObj.getRelationship());
				                patientInsurance.setInsuredDOB(insuranceObj.getInsuredDOB());
				            }
				            patientInsurance.setPolicyNumber(insuranceObj.getPolicyNumber());
				            patientInsurance.setGroupNumber(insuranceObj.getGroupNumber());
				            patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
				            log.debug("Saving PatientInsurance Obj: {}", patientInsurance);
				            session.saveOrUpdate(patientInsurance);
				        }
		            }
				}

		} catch (Exception e) {
			log.error("Error inserting data into patient and patientInsurance table: {}", e.getMessage());
			throw new RuntimeException("Error while importing data to patient and patientInsurance table", e);
		}

	}
	
	@Override
	public void updateImportStatus(int visitId, String status, String errorCode, String errorMessage, Timestamp timestamp) {
	    Session session = sessionFactory.getCurrentSession();
	    try {
	        
	        String hql = "UPDATE LightSpeedImport SET status = :status, errorCode = :errorCode, errorMessage = :errorMessage, timestamp = :timestamp WHERE visitId = :visitId";

	        Query query = session.createQuery(hql);
	        query.setParameter("status", status);
	        query.setParameter("errorCode", errorCode);
	        query.setParameter("errorMessage", errorMessage);
	        query.setParameter("visitId", visitId);
	        query.setParameter("timestamp", timestamp);
	        int result = query.executeUpdate();

	        if (result > 0) {
	            log.info("Successfully updated import status for visitId {}: status={}, errorCode={}, errorMessage={}",
	                    visitId, status, errorCode, errorMessage);
	        } else {
	            log.warn("No records found with visitId {} to update.", visitId);
	        }
	    } catch (Exception e) {
	        log.error("Error updating import status for visitId {}: {}", visitId, e.getMessage());
	    }
	}
	
	private FacilityDetails getFacilityDetails(String facilityId) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside getFacilityDetails Method:  {} " + facilityId);
		FacilityDetails details = new FacilityDetails();
		try {

			String hql = " From FacilityDetails where facilityId = :facilityId " + " AND active = 1";
			FacilityDetails facilityDetails = session.createQuery(hql, FacilityDetails.class)
					.setParameter("facilityId", Integer.parseInt(facilityId)).setMaxResults(1).uniqueResult();
			if (facilityDetails != null) {
				details = facilityDetails;
			}

		} catch (Exception e) {
			log.error("Exception occurred while Fetching Facility Details: {} {}", facilityId, e.getMessage());
		}
		return details;
	}
	
	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}
	
	private UserFacilityRes getUserFacilities(String userId, String masterToken) {
		IHealUserFacilityListGetRes facilitiesResponse = null;

		String url = env.getProperty(BOConstants.IHEAL_USERFACILITIES_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		IhealFacilityListGetReq user = new IhealFacilityListGetReq();
		user.setMasterToken(masterToken);
		user.setUserId(userId);
		user.setPrivateKey(privateKey);
		UserFacilityRes userFacilityRes = new UserFacilityRes();
		try {
			log.info("IHeal userfacility URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(user, getHeaders());

			assert url != null;
			ResponseEntity<IHealUserFacilityListGetRes> sresponse = restTemplate.exchange(url, HttpMethod.POST, request,
					IHealUserFacilityListGetRes.class);
			facilitiesResponse = sresponse.getBody();
			//log.debug("SettingsV2:  " + sresponse.getBody().getFacilities().get(0).getSettingsV2());
			//log.debug("iHeal facilitiesResponse : " + facilitiesResponse);
		} catch (HttpClientErrorException e) {
			log.error(String.format("HttpClientErrorException occurred in getUserFacilities: %s", e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(String.format("HttpStatusCodeException occurred in getUserFacilities: %s", e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		if (facilitiesResponse != null && facilitiesResponse.getErrorCode() != null
				&& facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			List<UserFacilities> facilities = new ArrayList<>();
			for (IhealFacility facility : facilitiesResponse.getFacilities()) {
				UserFacilities fac = new UserFacilities();
				fac.setFacilityId(facility.getFacilityId());
				fac.setFacilityBluebookId(facility.getFacilityBluebookId());
				fac.setFacilityName(facility.getFacilityName());
				fac.setConfiguration(facility.getConfiguration());
				fac.setSettings(facility.getSettings());
				fac.setSettingsV2(facility.getSettingsV2());
				facilities.add(fac);
			}
			userFacilityRes.setFacilities(facilities);

			userFacilityRes.setResponseCode("0");
			userFacilityRes.setResponseDesc("Success");
		} else if (facilitiesResponse != null && facilitiesResponse.getErrorCode() != null
				&& !facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			userFacilityRes.setResponseCode(facilitiesResponse.getErrorCode());
			userFacilityRes.setResponseDesc(facilitiesResponse.getErrorMessage());
		}
		//log.debug("UserFacilityRes:  {}", userFacilityRes);
		return userFacilityRes;
	}
	
	private void saveTimeline(long visitId, String action, String userFullName,
			long userId, String userName,
			String chartDesc, String userRole) {
		log.debug("Inside saveTimeline Method:  {} " + visitId);
		try {
			Dashboard dashObj = dashboardDAO.getRecordByVisitId(visitId);

			if (dashObj != null) {

				String fullName = "";
				if (userFullName != null && !userFullName.isEmpty()) {
					
					if (userFullName.contains(",")) {
						String[] names = userFullName.split(",");

						if (names.length > 1) {
							String lastName = names[0];
							String firstName = names[1];

							if (action != null && action.equalsIgnoreCase("Escalate")) {
								firstName = names[0];
								lastName = names[1];
							}

							fullName = ((firstName != null) ? firstName.trim() : "") + " "
									+ ((lastName != null) ? lastName.trim() : "");

							log.info("fullName : " + fullName);
						}
					} else {
						fullName = userFullName;
					}
					
				}
  
				HistoryTimelineData timeline = new HistoryTimelineData();
				timeline.setBluebookId(dashObj.getBluebookId());
				timeline.setChartDescription(fullName + "#" + chartDesc);
				timeline.setChartStatus(action);
				timeline.setDateOfService(dashObj.getDateOfService());
				timeline.setFacilityId(dashObj.getFacilityId());
				timeline.setPatientId(dashObj.getPatientId());
				timeline.setPatientName(dashObj.getPatientName());
				timeline.setUserFullName(userFullName);
				timeline.setUserId(userId);
				timeline.setUserRole(userRole);
				timeline.setUserName(userName);
				timeline.setVisitId(visitId);
				log.debug("Saving History Timeline: {}", timeline);
				historyTimelineBO.saveHistoryTimeline(timeline);
			}
		} catch (Exception e) {
			log.error("Exception occured while Saving timeline: {}", e.getMessage());
		}
	}
	
	private PlaceOfServiceDetails getPlaceOfService(String code) {
		Session session = this.sessionFactory.getCurrentSession();
		PlaceOfServiceDetails details = null;
		try {
			log.debug("Checking PlaceOfServiceDetails: "+ code);
			// Check if the record with the given visitId already exists
			String hql = "FROM PlaceOfServiceDetails WHERE code = :code";
			Query query = session.createQuery(hql);
			query.setParameter("code",code);
			details = (PlaceOfServiceDetails) query.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Fetching Place of Service from DB: {}", e.getMessage());
		}
		return details;
	}
	
	private PlaceOfServiceDetails getPlaceOfServiceSNF(String code, String facilityType) {
		Session session = this.sessionFactory.getCurrentSession();
		PlaceOfServiceDetails details = null;
		try {
			log.debug("Checking PlaceOfServiceDetails: {}"+ code);
			// Check if the record with the given visitId already exists
			String hql = "FROM PlaceOfServiceDetails WHERE code = :code and facilityType = :facilityType";
			Query query = session.createQuery(hql);
			query.setParameter("code",code);
			query.setParameter("facilityType", facilityType);
			details = (PlaceOfServiceDetails) query.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Fetching Place of Service from DB: {}", e.getMessage());
		}
		return details;
	}
}
