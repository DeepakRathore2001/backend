
package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.EncounterStatusReportDAO;
import com.healogics.encode.dto.EncounterStatusReportReq;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class EncounterStatusReportDAOImpl implements EncounterStatusReportDAO {

	private final Logger log = LoggerFactory.getLogger(EncounterStatusReportDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public EncounterStatusReportDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Object[]> getEncounterStatusReportdata() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> reportdata = null;
		try {
			String hql = "SELECT DISTINCT(e.bluebookId),"
					//+ " CASE WHEN e.ihealConfig = 'EMR' THEN 'i-heal' ELSE 'non-i-heal' END AS facilityTypeAlias,"
					+ " e.ihealConfig, e.providerName,"
					+ " e.providerId, e.facilityId" 
					+ " FROM EncounterStatusReport e";
			Query<Object[]> query = session.createQuery(hql, Object[].class);
			log.info("query1 : {}", hql);
			reportdata = query.list();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Data: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return reportdata;
	}

	@Override
	public List<Object[]> generateEncounterReport(Date startDate, Date endDate, List<String> bbcList,
			List<String> facilityTypeList, List<String> providerNameList, List<String> providerIdList,
			List<Integer> facilityIdList, EncounterStatusReportReq req, List<String> facilityTypeList1)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> reportdata = null;
		List<String> codingTeamList= req.getCodingTeamList();
		log.debug("reportdata.........." + reportdata);
		try {
			String hql = "SELECT e.dateOfService, sum(case when status='Received' then 1 else 0 end) as received, "
					+ "sum(case when status='Ready' then 1 else 0 end) as ready, "
					+ "sum(case when status in('Deficiency', 'Nurse Deficiency', 'Nurse Review') then 1 else 0 end) as deficiency, "
					+ "sum(case when status in ('Completed', 'Audit Completed', 'Released') then 1 else 0 end) as completed, "
					+ "sum(case when status='Sent' then 1 else 0 end) as sent, "
					+ "sum(case when status='Unbillable' then 1 else 0 end) as unbillable, "
					+ "sum(case when status='New' then 1 else 0 end) as news, "
					+ "sum(case when status='Pending' then 1 else 0 end) as pending, "
					+ "sum(case when status='In Review' then 1 else 0 end) as in_review, "
					+ "sum(case when status='Returned' then 1 else 0 end) as returned, "
					+ "sum(case when status='Pending Superbill' then 1 else 0 end) as pendingSuperbill, "
					+ "e.snfLocationBBC"
					+ " FROM Dashboard e WHERE 1=1";

			if (startDate != null && endDate != null) {

				hql += " AND (e.dateOfService BETWEEN :startDate AND :endDate)";
			}
			if (bbcList != null && !bbcList.isEmpty()) {
				hql += " AND (e.snfLocationBBC IN (:bbcList))";
				// hql += " AND (e.bluebookId IN (:bbcList) OR
				// cd.childBluebookId IN (:bbcList))";
			}
			/*
			 * if (facilityTypeList != null && !facilityTypeList.isEmpty()) { if
			 * (req.getLocationTypeList().contains("i-heal") &&
			 * !req.getLocationTypeList().contains("non-i-heal")) { hql +=
			 * " AND ihealConfig IN :ihealConfig"; //
			 * query.setParameter("ihealConfig", "EMR"); } if
			 * (req.getLocationTypeList().contains("non-i-heal") &&
			 * !req.getLocationTypeList().contains("i-heal")) { hql +=
			 * " AND ihealConfig NOT IN :ihealConfig"; //
			 * parameters.put("ihealConfig", "EMR"); } // hql +=
			 * " AND e.ihealConfig IN (:facilityTypeList)"; }
			 */

			// if (facilityTypeList != null && !facilityTypeList.isEmpty()) {
			// hql += " AND (CASE WHEN ihealConfig = 'EMR' THEN 'i-heal' ELSE
			// 'non-i-heal' END) IN :facilityTypes";
			// }
			if (facilityTypeList != null && !facilityTypeList.isEmpty()) {
				hql += " AND (e.ihealConfig IN (:locationTypeList))";
			}

			if (providerNameList != null && !providerNameList.isEmpty()) {
				hql += " AND (e.providerName IN (:providerNameList))";
			}
			if (providerIdList != null && !providerIdList.isEmpty()) {
				hql += " AND (e.providerId IN (:providerIdList))";
			}
			if (facilityTypeList1 != null && !facilityTypeList1.isEmpty()) {
				hql += " AND (e.facilityType IN (:facilityTypeList1))";
			}
			if (facilityIdList != null && !facilityIdList.isEmpty()) {
				hql += " AND (e.facilityId IN (:facilityIdList))";
			}
			if (codingTeamList != null && !codingTeamList.isEmpty()) {
				hql += " AND (e.team IN (:codingTeamList))";
			}
			// hql += " GROUP BY e.bluebookId, e.dateOfService";
			hql += " GROUP BY e.dateOfService";
			Query<Object[]> query = session.createQuery(hql, Object[].class);

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			if (startDate != null && endDate != null) {
				// Date parsedEndDate =
				// inputDateFormat.parse(endDate.toString());
				if (endDate instanceof Date) {
					Calendar calendar = Calendar.getInstance();
					calendar.setTime((Date) endDate);
					calendar.set(Calendar.HOUR_OF_DAY, 23);
					calendar.set(Calendar.MINUTE, 59);
					calendar.set(Calendar.SECOND, 0);
					calendar.set(Calendar.MILLISECOND, 0);
					Date adjustedEndDate = calendar.getTime();

					// String formattedEndDate =
					// dateFormat.format(adjustedEndDate);

					log.debug("formattedEndDate...." + adjustedEndDate);
					query.setParameter("startDate", startDate);
					
					log.debug("startDate..........." + startDate);
					query.setParameter("endDate", adjustedEndDate);
				} else {
					throw new IllegalArgumentException("endDate must be a Date object");
				}
			}
			if (bbcList != null && !bbcList.isEmpty()) {
				query.setParameter("bbcList", bbcList);
			}
			if (facilityTypeList != null && !facilityTypeList.isEmpty()) {
				// query.setParameter("facilityTypeList", facilityTypeList);
				// query.setParameter("facilityIdList", facilityIdList);
				// query.setParameter("ihealConfig", "EMR");
				query.setParameter("locationTypeList", req.getLocationTypeList());
			}
			if (providerNameList != null && !providerNameList.isEmpty()) {
				query.setParameter("providerNameList", providerNameList);
			}
			if (providerIdList != null && !providerIdList.isEmpty()) {
				query.setParameter("providerIdList", providerIdList);
			}
			if (facilityTypeList1 != null && !facilityTypeList1.isEmpty()) {
				query.setParameter("facilityTypeList1", facilityTypeList1);
			}
			if (facilityIdList != null && !facilityIdList.isEmpty()) {
				query.setParameter("facilityIdList", facilityIdList);
				// query.setParameter("ihealConfig", "EMR");

			}
			if (codingTeamList != null && !codingTeamList.isEmpty()) {
				query.setParameter("codingTeamList", codingTeamList);
			}
			// query.setFirstResult(pageNumner * pageSize);
			// query.setMaxResults(pageSize);

			log.info("query1 : {}", hql);
			reportdata = query.list();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Encounter report data: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return reportdata;
	}

	@Override
	public Timestamp getEarliestDate() {
		String hql = "SELECT MIN(e.dateOfService) FROM Dashboard e";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (Timestamp) query.uniqueResult();
	}

	@Override
	public Timestamp getLastDate() {
		String hql = "SELECT MAX(e.dateOfService) FROM Dashboard e";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (Timestamp) query.uniqueResult();
	}

}