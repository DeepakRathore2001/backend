package com.healogics.encode.dao.impl;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.healogics.encode.dao.AboutPopupDAO;
import com.healogics.encode.dto.SaveBuildDetailsReq;
import com.healogics.encode.entity.BuildDetails;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class AboutPopupDAOImpl implements AboutPopupDAO {

	private final Logger log = LoggerFactory.getLogger(AboutPopupDAOImpl.class);

	private final DynamoDBMapper dynamoDBMapper;

	@Autowired
	public AboutPopupDAOImpl(DynamoDBMapper dynamoDBMapper) {
		this.dynamoDBMapper = dynamoDBMapper;
	}

	@Override
	public void saveBuildDetails(SaveBuildDetailsReq req) throws EncodeExceptionHandler {
		try {
            // Generate current timestamp in ISO 8601 format
            String currentTimestampStr = DateTimeFormatter.ISO_INSTANT.format(Instant.now());
 
            // Create BuildDetails object and set attributes
            BuildDetails details = new BuildDetails();
            details.setPk(req.getPk());
            details.setSk(currentTimestampStr);
            details.setApplicationName(req.getApplicationName());
            details.setApplicationPlatform(req.getApplicationPlatform());
            details.setApplicationVersion(req.getApplicationVersion());
            details.setBuildVersion(req.getBuildVersion());
            details.setComponent(req.getComponent());
            details.setEnvironment(req.getEnvironment());
            details.setLastUpdatedTimestamp(currentTimestampStr);
            details.setLastUpdatedUser(req.getLastUpdatedUser());
 
            // Create save expression to ensure the item exists before updating
            DynamoDBSaveExpression saveExpression = new DynamoDBSaveExpression()
                    .withExpectedEntry("pk", new ExpectedAttributeValue(new AttributeValue(req.getPk())));
 
            // Attempt to update the item
            try {
                dynamoDBMapper.save(details, saveExpression);
                log.info("Updated BuildDetails with pk: {}", req.getPk());
            } catch (ConditionalCheckFailedException e) {
                // If the item does not exist, save it without the conditional check
                log.info("Item with pk: {} does not exist. Creating new item.", req.getPk());
                dynamoDBMapper.save(details);
                log.info("Created new BuildDetails with pk: {}", req.getPk());
            }
 
        } catch (Exception e) {
            log.error("Exception occurred while saving build details: {}", e.getMessage());
            throw new EncodeExceptionHandler(e.getMessage());
        }
    }
}
