package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transaction;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.AdministrationDAO;
import com.healogics.encode.dto.AdminDashboardReq;
import com.healogics.encode.dto.CampusIndicatorData;
import com.healogics.encode.dto.CampusIndicatorReq;
import com.healogics.encode.dto.FacilityDetailsReq;
import com.healogics.encode.dto.FacilitySettingsFilterOptionsRes;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.RoleAssignmentReq;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.util.FilterRequestUtil;

@Repository
@Transactional
public class AdministrationDAOImpl implements AdministrationDAO {

	private final Logger log = LoggerFactory.getLogger(AdministrationDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public AdministrationDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<EncodeUsers> getCoderUsersData(String coderRole) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<EncodeUsers> list = new ArrayList<>();
		try {
			String hql = "FROM EncodeUsers WHERE encodeRole like :encodeRole AND status=1 ORDER BY userFullName ASC";
			log.info("query : {}", hql);

			list = (List<EncodeUsers>) session.createQuery(hql).setParameter("encodeRole", "%" + coderRole + "%")
					.list();

		} catch (Exception e) {
			log.error("GlobalExceptionHandler occured while fetching  Encode Users List: {}", e.getMessage());
			throw new Exception(e.getMessage());
		}
		return list;
	}

	private String sortList(AdminDashboardReq req, String hql) {
		if ("ihealRole".equals(req.getSortBy()) || "encodeRole".equals(req.getSortBy())) {
			return hql;
		} else {
			hql += " order by " + getFilterColumnName(req.getSortBy()) + "";

			if (req.getOrder() == 0) {
				hql += " desc";
			} else {
				hql += " asc";
			}
			return hql;
		}
	}

	private String getFilterColumnName(String parameter) {
		String column = "";
		switch (parameter) {

		// role assignment table
		case "userFullName":
			column = "userFullName";
			break;
		case "userName":
			column = "username";
			break;
		case "ihealRole":
			column = "ihealRole";
			break;
		case "encodeRole":
			column = "encodeRole";
			break;
		case "status":
			column = "status";
			break;
		case "codingTeam":
			column = "team";
			break;
		default:
			break;
		}
		return column;
	}

	@Override
	public Map<String, Object> getFilteredEncodeUsers(AdminDashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<EncodeUsers> list = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		try {
			StringBuilder query = new StringBuilder("FROM EncodeUsers u WHERE 1 = 1");

			// Set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					String filterString = getFilterColumnName(filterReq);
					switch (filterString) {
					case "userFullName": {
						List<String> userFullNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getUserFullName());
						query.append(" AND u.userFullName IN (:userFullName)");
						parameters.put("userFullName", userFullNameList);
						break;
					}
					case "username": {
						List<String> userNameLists = FilterRequestUtil.getListFromDelimitedStr(req.getUserName());
						query.append(" AND u.username IN (:userName)");
						parameters.put("userName", userNameLists);
						break;
					}
					case "status": {
						List<Integer> status = req.getStatus();
						query.append(" AND u.status IN (:status)");
						parameters.put("status", status);
						break;
					}
					case "team": {
						List<String> teams = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						query.append(" AND u.team IN (:team)");
						parameters.put("team", teams);
						break;
					}
					default:
						break;
					}
				}

				// Special handling for ihealRole and encodeRole
				if (filterList.contains("ihealRole")) {
					List<String> ihealRoleList = FilterRequestUtil.getListFromDelimiteRoles(req.getIhealRole(), "#");
					if (!ihealRoleList.isEmpty()) {
						query.append(" AND (");
						for (int i = 0; i < ihealRoleList.size(); i++) {
							if (i > 0)
								query.append(" OR ");
							query.append("u.ihealRole LIKE :ihealRole").append(i);
							parameters.put("ihealRole" + i, "%" + ihealRoleList.get(i) + "%");
						}
						query.append(")");
					}
				}
				if (filterList.contains("encodeRole")) {
					List<String> encodeRoleList = FilterRequestUtil.getListFromDelimiteRoles(req.getEncodeRole(), "#");
					if (!encodeRoleList.isEmpty()) {
						query.append(" AND (");
						for (int i = 0; i < encodeRoleList.size(); i++) {
							if (i > 0)
								query.append(" OR ");
							query.append("u.encodeRole LIKE :encodeRole").append(i);
							parameters.put("encodeRole" + i, "%" + encodeRoleList.get(i) + "%");
						}
						query.append(")");
					}
				}
				/*
				 * if (filterList.contains("team")) { List<String> teams =
				 * FilterRequestUtil.getListFromDelimiteRoles(req.getCodingTeam(), "#"); if
				 * (!teams.isEmpty()) { query.append(" AND ("); for (int i = 0; i <
				 * teams.size(); i++) { if (i > 0) query.append(" OR ");
				 * query.append("u.team LIKE :team").append(i); parameters.put("team" + i, "%" +
				 * teams.get(i) + "%"); } query.append(")"); } }
				 */
			}

			// Apply sorting
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				query = new StringBuilder(sortList(req, query.toString()));
			} else {
				query.append(" ORDER BY u.userFullName ASC");
			}

			log.debug("Query: {}", query);
			log.debug("Parameters: {}", parameters);

			Query hibQuery = session.createQuery(query.toString());

			// Set parameters
			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				if (entry.getValue() instanceof List) {
					hibQuery.setParameterList(entry.getKey(), (List) entry.getValue());
				} else {
					hibQuery.setParameter(entry.getKey(), entry.getValue());
				}
			}

			list = hibQuery.list();
			listCount.put("Count", list.size());
			listCount.put("data", list);

		} catch (Exception e) {
			log.error("Exception occurred while fetching Filtered Encode Users records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<EncodeUsers> getEncodeUsersData(AdminDashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<EncodeUsers> list = new ArrayList<>();
		try {
			String hql = "FROM EncodeUsers";

			// Apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortList(req, hql);
			} else {
				hql += " order by userFullName asc";
			}

			log.info("query : {}", hql);
			list = session.createQuery(hql).list();
			log.debug("list : {}", list, list.size());

		} catch (Exception e) {
			log.error("Encode ExceptionHandler occurred while fetching Encode Users List: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return list;
	}

	@Override
	public Long totalEncodeUsers() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;
		try {
			String hql = "SELECT count(*) FROM EncodeUsers ";

			taskCount = (Long) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching EncodeUsers count: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return taskCount;
	}

	@Override
	public List<String> getRoleAssignmentFilterOptions(AdminDashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> optionList = new ArrayList<>();
		Set<String> uniqueRoles = new HashSet<>();
		try {
			String query = " WHERE 1 = 1";
			String filterColumnString = getFilterColumnName(req.getFilterOptions());

			log.debug("Filter column string: {}", filterColumnString);

			if (filterColumnString.isEmpty()) {
				throw new EncodeExceptionHandler("Invalid filter option provided: " + req.getFilterOptions());
			}

			Map<String, Object> parameters = new HashMap<>();

			// Set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					String filterString = getFilterColumnName(filterReq);
					query += " AND ";

					switch (filterString) {
					case "userFullName": {
						List<String> userFullNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getUserFullName());
						query += "u.userFullName IN (:userFullName)";
						parameters.put("userFullName", userFullNameList);
						break;
					}
					case "username": {
						List<String> userNameLists = FilterRequestUtil.getListFromDelimitedStr(req.getUserName());
						query += "u.username IN (:username)";
						parameters.put("username", userNameLists);
						break;
					}
					case "ihealRole": {
						List<String> ihealRolesOptions = FilterRequestUtil.getListFromDelimitedStr(req.getIhealRole());

						for (String ihealRolesResponse : ihealRolesOptions) {
							List<String> rolesList = extractRolesFromResponse(ihealRolesResponse);
							uniqueRoles.addAll(rolesList);
						}
						break;
					}
					case "encodeRole": {
						List<String> encodeRolesOptions = FilterRequestUtil
								.getListFromDelimitedStr(req.getEncodeRole());
						for (String encodeRolesResponse : encodeRolesOptions) {
							List<String> rolesList = extractCommaSeparatedRoles(encodeRolesResponse);
							uniqueRoles.addAll(rolesList);
						}
						break;
					}
					case "team": {
						List<String> codingTeamsOptions = FilterRequestUtil
								.getListFromDelimitedStr(req.getCodingTeam());
						for (String codingTeamsResponse : codingTeamsOptions) {
							List<String> rolesList = extractCommaSeparatedRoles(codingTeamsResponse);
							uniqueRoles.addAll(rolesList);
						}
						break;
					}
					default:
						break;
					}
				}
			}
			log.debug("Query: {}", query);
			log.debug("Parameters: {}", parameters);

			if (filterColumnString.equals("status")) {
				try {
					String hql = "SELECT DISTINCT CASE WHEN u.status = 1 THEN 'Active' ELSE 'Inactive' END FROM EncodeUsers u ORDER BY u.status DESC";
					List<String> statusOptions = session.createQuery(hql, String.class).getResultList();
					optionList.addAll(statusOptions);

				} catch (Exception e) {
					log.error("Exception occurred while fetching status options: {}", e.getMessage());
					throw new EncodeExceptionHandler("Error fetching status options");
				}
			} else {
				String hql = "SELECT DISTINCT " + filterColumnString + " FROM EncodeUsers u " + query + " ORDER BY "
						+ filterColumnString + " asc";
				log.debug("HQL query: {}", hql);

				List<String> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();

				log.debug("Distinct values: {}", distinctValues);
				for (String distinctValue : distinctValues) {
					if (distinctValue != null && !distinctValue.isEmpty()) {
						if (filterColumnString.equals("ihealRole")) {
							List<String> rolesList = extractRolesFromResponse(distinctValue);
							uniqueRoles.addAll(rolesList);
						} else if (filterColumnString.equals("encodeRole")) {
							List<String> rolesList = extractCommaSeparatedRoles(distinctValue);
							uniqueRoles.addAll(rolesList);
						} else if (filterColumnString.equals("team")) {
							List<String> rolesList = extractCommaSeparatedRoles(distinctValue);
							uniqueRoles.addAll(rolesList);
						} else {
							optionList.add(distinctValue);
						}
					}
				}
			}

		} catch (Exception e) {
			log.error("Exception occurred while fetching Role Admin Dashboard filter options: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		if (!uniqueRoles.isEmpty()) {
			List<String> sortedUniqueRoles = new ArrayList<>(uniqueRoles);
			Collections.sort(sortedUniqueRoles);
			optionList.addAll(sortedUniqueRoles);
		}
		log.debug("Final options list: {}", optionList);
		return optionList;
	}

	private List<String> extractRolesFromResponse(String ihealRolesResponse) {
		List<String> rolesList = new ArrayList<>();
		try {
			if (ihealRolesResponse.startsWith("[") && ihealRolesResponse.endsWith("]")) {
				String rolesString = ihealRolesResponse.substring(1, ihealRolesResponse.length() - 1);
				// Split roles by comma and trim each role
				String[] rolesArray = rolesString.split(",");
				for (String role : rolesArray) {
					rolesList.add(role.trim());
				}
			}
		} catch (Exception e) {
			log.error("Error extracting roles from response: {}", e.getMessage());
		}
		return rolesList;
	}

	private List<String> extractCommaSeparatedRoles(String rolesResponse) {
		List<String> rolesList = new ArrayList<>();
		try {
			String[] rolesArray = rolesResponse.split(",");
			for (String role : rolesArray) {
				rolesList.add(role.trim());
			}
		} catch (Exception e) {
			log.error("Error extracting roles from response: {}", e.getMessage());
		}
		return rolesList;
	}

	@Override
	public void saveEncodeRole(List<RoleAssignmentReq> userRoles) throws EncodeExceptionHandler {
		Session session = sessionFactory.getCurrentSession();
		try {
			for (RoleAssignmentReq roleReq : userRoles) {
				// Convert List<String> to comma-separated String
				String encodedRoles = String.join(", ", roleReq.getEncodeRole());
				String CodingTeams = String.join(", ", roleReq.getCodingTeam());

				EncodeUsers encodeUsers = session.get(EncodeUsers.class, roleReq.getUserId());
				if (encodeUsers != null) {
					encodeUsers.setEncodeRole(encodedRoles);

					encodeUsers.setStatus(roleReq.getStatus());
					encodeUsers.setTeam(CodingTeams);
					session.save(encodeUsers);
				} else {

					throw new EntityNotFoundException("User not found with userId: " + roleReq.getUserId());
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public List<String> getEncodeRoles() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> encodeRoles = new ArrayList<>();
		try {
			String hql = "SELECT e.encodeRole FROM EncodeRoles e";
			encodeRoles = session.createQuery(hql, String.class).list();
		} catch (Exception e) {
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return encodeRoles;
	}

	@Override
	public List<EncodeUsers> getNurseUsers(String nurseRole) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<EncodeUsers> list = new ArrayList<>();
		try {
			String hql = "FROM EncodeUsers WHERE encodeRole like :encodeRole  ";
			log.info("query : {}", hql);

			list = (List<EncodeUsers>) session.createQuery(hql).setParameter("encodeRole", "%" + nurseRole + "%")
					.list();

		} catch (Exception e) {
			log.error("GlobalExceptionHandler occured while fetching  Encode Users List: {}", e.getMessage());
			throw new Exception(e.getMessage());
		}
		return list;
	}

	@Override
	public List<FacilityDetails> getFacilityDetails() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<FacilityDetails> facilityList = new ArrayList<>();
		try {
			String hql = "FROM FacilityDetails WHERE active = 1";
			log.info("query : {}", hql);

			facilityList = (List<FacilityDetails>) session.createQuery(hql).list();

		} catch (Exception e) {
			log.error("GlobalExceptionHandler occured while fetching  Encode Users List: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return facilityList;
	}

	@Override
	public void UpdateCampusIndicator(List<CampusIndicatorData> indicator) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
        try {
           for (CampusIndicatorData req : indicator) {
            	FacilityDetails encodeUsers = session.get(FacilityDetails.class, req.getId());
                if (encodeUsers != null) {
                	encodeUsers.setLastUpdatedTimestamp(currentTime);
                	if(req.getCampusCode() == 1){
                		encodeUsers.setPlaceOfService("22");
                		
                	}else if(req.getCampusCode() == 0){
                		encodeUsers.setPlaceOfService("19");
                	}else{
                		log.debug("please select Campus indicator");
                	}
                		
                    session.save(encodeUsers);
                } else {
                    
                    throw new EntityNotFoundException("indicator not found id: " + req.getId());
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred: " + e.getMessage());
            throw new EncodeExceptionHandler(e.getMessage());
        }
    }
	public List<FacilityDetails> getFilteredFacilityDetails(FacilityDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<FacilityDetails> facilityList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		try {
			String hql = "FROM FacilityDetails WHERE active = 1";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					String filterString = filterReq;
					switch (filterString) {
					case "facilityId": {
						
						List<String> facilityIdStrList = FilterRequestUtil.getListFromDelimitedStr(req.getFacilityId());
						 List<Integer> facilityIdList = facilityIdStrList.stream()
						            .map(Integer::parseInt) // Convert each string to an integer
						            .collect(Collectors.toList());
						hql += " AND facilityId IN (:facilityId)";
						parameters.put("facilityId", facilityIdList);
						break;
					}
					case "facilityName": {
						List<String> facilityNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityName());
						hql += " AND facilityName IN (:facilityName)";
						parameters.put("facilityName", facilityNameList);
						break;
					}
					case "facilityBBC": {
						List<String> facilityBBCList = FilterRequestUtil.getListFromDelimitedStr(req.getFacilityBBC());
						hql += " AND bluebookId IN (:facilityBBC)";
						parameters.put("facilityBBC", facilityBBCList);
						break;
					}
					case "facilityType": {
						List<String> facilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityType());
						hql += " AND currentFacilityType IN (:facilityType)";
						parameters.put("facilityType", facilityTypeList);
						break;
					}
					case "facilityConfig": {
						List<String> facilityConfigList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityConfig());
						hql += " AND currentIHealConfig IN (:facilityConfig)";
						parameters.put("facilityConfig", facilityConfigList);
						break;
					}
					case "campusCode": {
						int campusCodeInt = req.getCampusCode();
						String campusCodestr = String.valueOf(campusCodeInt);
						List<String> campusCodeList =  FilterRequestUtil
								.getListFromDelimitedStr(campusCodestr);
						 // Adjusting the logic to get Place of service from the getCampousCode method
					    List<String> placeOfServiceList = new ArrayList<>();
					    for (String campusCode : campusCodeList) {
					        placeOfServiceList.add(getPlaceOfService(campusCode));
					    }
						hql += " AND placeOfService IN (:placeOfService)";
						parameters.put("placeOfService", placeOfServiceList);
						break;
					}

					default:
						break;
					}
				}
			}

			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortFacilityList(req, hql);
			} else {
				hql += " order by LOWER(facilityName) asc";
			}

			log.info("query : {}", hql);

			facilityList = session.createQuery(hql).setProperties(parameters).list();
			log.debug("Facility List Size:   {} ", facilityList.size());

		} catch (Exception e) {
			log.error("Exception occurred while fetching Facility Details: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return facilityList;
	}

	private String sortFacilityList(FacilityDetailsReq req, String hql) {
		String sortBy = req.getSortBy();
		String order = req.getOrder() == 0 ? "desc" : "asc";

		switch (sortBy) {
		case "facilityId":
			hql += " order by LOWER(facilityId) " + order;
			break;
		case "facilityName":
			hql += " order by LOWER(facilityName)" + order;
			break;
		case "facilityBBC":
			hql += " order by LOWER(bluebookId) " + order;
			break;
		case "facilityType":
			hql += " order by LOWER(currentFacilityType) " + order;
			break;
		case "facilityConfig":
			hql += " order by LOWER(currentIHealConfig)" + order;
			break;
		case "campusCode":
			hql += " order by LOWER(placeOfService)" + order;
			break;
		default:
			hql += " order by LOWER(facilityName) " + order;
			break;
		}
		return hql;
	}

	@Override
	public List<String> getFacilitySettingsFilterOptions(FacilityDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> optionList = new ArrayList<>();
		Set<String> uniqueOptions = new HashSet<>();
		try {
			String query = " WHERE 1 = 1";
			String filterColumnString = req.getFilterOptions();

			log.debug("Filter column string: {}", filterColumnString);

			if (filterColumnString.isEmpty()) {
				throw new EncodeExceptionHandler("Invalid filter option provided: " + req.getFilterOptions());
			}

			Map<String, Object> parameters = new HashMap<>();

			// Set all filters in where clause

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					String filterString = filterReq;
					switch (filterString) {
					case "facilityId": {
						String facilityId = String.valueOf(req.getFacilityId());
						List<String> facilityIdStrList = FilterRequestUtil.getListFromDelimitedStr(facilityId);
						 List<Integer> facilityIdList = facilityIdStrList.stream()
						            .map(Integer::parseInt) // Convert each string to an integer
						            .collect(Collectors.toList());
						query += " AND facilityId IN (:facilityId)";
						parameters.put("facilityId", facilityIdList);
						break;
					}
					case "facilityName": {
						List<String> facilityNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityName());
						query += " AND facilityName IN (:facilityName)";
						parameters.put("facilityName", facilityNameList);
						break;
					}
					case "facilityBBC": {
						List<String> facilityBBCList = FilterRequestUtil.getListFromDelimitedStr(req.getFacilityBBC());
						query += " AND bluebookId IN (:facilityBBC)";
						parameters.put("facilityBBC", facilityBBCList);
						break;
					}
					case "facilityType": {
						List<String> facilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityType());
						query += " AND currentFacilityType IN (:facilityType)";
						parameters.put("facilityType", facilityTypeList);
						break;
					}
					case "facilityConfig": {
						List<String> facilityConfigList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityConfig());
						query += " AND currentIHealConfig IN (:facilityConfig)";
						parameters.put("facilityConfig", facilityConfigList);
						break;
					}
					case "campusCode": {
						int campusCodeInt = req.getCampusCode();
						String campusCodestr = String.valueOf(campusCodeInt);
						List<String> campusCodeList =  FilterRequestUtil
								.getListFromDelimitedStr(campusCodestr);
						 // Adjusting the logic to get Place of service from the getCampousCode method
					    List<String> placeOfServiceList = new ArrayList<>();
					    for (String campusCode : campusCodeList) {
					        placeOfServiceList.add(getPlaceOfService(campusCode));
					    }
						query += " AND placeOfService IN (:placeOfService)";
						parameters.put("placeOfService", placeOfServiceList);
						break;
					}
					

					default:
						break;
					}
				}
			}
			log.debug("Query: {}", query);
			log.debug("Parameters: {}", parameters);

			String hql = "";

			if (req.getFilterOptions().equalsIgnoreCase("facilityId")) {
				filterColumnString = "facilityId";
			}

			if (req.getFilterOptions().equalsIgnoreCase("facilityName")) {
				filterColumnString = "facilityName";
			}

			if (req.getFilterOptions().equalsIgnoreCase("facilityBBC")) {
				filterColumnString = "bluebookId";
			}
			if (req.getFilterOptions().equalsIgnoreCase("facilityType")) {
				filterColumnString = "currentFacilityType";
			}
			if (req.getFilterOptions().equalsIgnoreCase("facilityConfig")) {
				filterColumnString = "currentIHealConfig";
			}
			if (req.getFilterOptions().equalsIgnoreCase("campusCode")) {
				filterColumnString = "placeOfService";
			}
			  if (filterColumnString.equals("placeOfService")) {
		            hql = "SELECT DISTINCT " + filterColumnString + " FROM FacilityDetails " + query + " ORDER BY LOWER(" + filterColumnString + ") asc";
		            log.info("hql :{}", hql);

		            List<String> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();
		            distinctValues.removeIf(element -> element == null || element.isEmpty());
		            List<String> campusCodeList = new ArrayList<>();
		            for (String placeOfService : distinctValues) {
		                campusCodeList.add(getCampousCode(placeOfService));
		            }
		            optionList = campusCodeList;
		        }else if(filterColumnString.equals("facilityId")) {
		        //for FacilityID	
		        	hql = "SELECT DISTINCT " + filterColumnString + " FROM FacilityDetails " + query + " ORDER BY LOWER(" + filterColumnString + ") asc";
		        	    log.info("hql :{}", hql);
		        	    List<?> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();
		        	    log.debug("distinct Values: {}", distinctValues);
		        	    distinctValues.removeIf(element -> element == null || (element instanceof String && ((String) element).isEmpty()));

		        	    // Convert integers to strings if necessary
		        	    List<String> stringValues = distinctValues.stream()
		        	        .map(Object::toString)
		        	        .collect(Collectors.toList());
		        	    log.debug("string Values: {}", stringValues);
		        	    optionList = stringValues;
		        } else {
		            hql = "SELECT DISTINCT " + filterColumnString + " FROM FacilityDetails " + query + " ORDER BY LOWER(" + filterColumnString + ") asc";
		            log.info("hql :{}", hql);

		            List<String> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();
		            log.debug("distinct Values: {}", distinctValues);
		            distinctValues.removeIf(element -> element == null || element.isEmpty());
		            optionList = distinctValues;
		        }
		//		 uniqueOptions.addAll(distinctValues.stream()
//		            .map(Object::toString) // Convert all elements to String
//		            .filter(s -> s != null && !s.isEmpty()) // Filter out null and empty strings
//		            .collect(Collectors.toSet()));
			log.debug("options list: {}", optionList);
		} catch (Exception e) {
			log.error("Exception occurred while fetching Role Admin Dashboard filter options: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		log.debug("Final options list: {}", optionList);
		return optionList;
	}
	private String getCampousCode(String placeOfService) {
		String campousCode = "";

		switch (placeOfService) {
			case "22": {
				campousCode = "1";
				break;
			}
			case "19": {
				campousCode = "0";
				break;
			}
			default: {
				campousCode = "0";
			}
		}
		return campousCode;
	}
	private String getPlaceOfService(String campusCode) {
	    String placeOfService = "0"; 
	    switch (campusCode) {
	        case "1": {
	            placeOfService = "22";
	            break;
	        }
	        case "0": {
	            placeOfService = "19";
	            break;
	        }
	        default: {
	            placeOfService = "19";
	        }
	    }
	    return placeOfService;
	}
}
