package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.BOConstants.ERRORCODE;
import static com.healogics.encode.constants.BOConstants.ERRORMESSAGE;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.DashboardDAO;
import com.healogics.encode.dao.IHealNotificationDAO;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.HistoryTimelineData;
import com.healogics.encode.dto.IHealGetVisitsReq;
import com.healogics.encode.dto.IHealGuarantorObj;
import com.healogics.encode.dto.IHealInsuranceObj;
import com.healogics.encode.dto.IHealInsuredObj;
import com.healogics.encode.dto.IHealNotificationReq;
import com.healogics.encode.dto.IHealPatientLoadObj;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.IHealPatientLoadRes;
import com.healogics.encode.dto.IHealPatientReloadReq;
import com.healogics.encode.dto.IHealSuperBillLoadObj;
import com.healogics.encode.dto.IHealSuperBillLoadReq;
import com.healogics.encode.dto.IHealSuperBillLoadRes;
import com.healogics.encode.dto.IHealUserFacilityListGetRes;
import com.healogics.encode.dto.IHealVisitLoadRes;
import com.healogics.encode.dto.IHealVisitObject;
import com.healogics.encode.dto.IhealFacility;
import com.healogics.encode.dto.IhealFacilityListGetReq;
import com.healogics.encode.dto.PlaceOfServiceRes;
import com.healogics.encode.dto.ProcedureProviderEMObj;
import com.healogics.encode.dto.ReloadPatientInsuranceReq;
import com.healogics.encode.dto.UserFacilities;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.DeficiencyReload;
import com.healogics.encode.entity.DisparateFacilities;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.entity.InsuranceCarrier;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.Patient;
import com.healogics.encode.entity.PatientInsurance;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.PatientReload;
import com.healogics.encode.entity.PlaceOfServiceDetails;
import com.healogics.encode.entity.ReloadCMCMetrics;
import com.healogics.encode.entity.ReloadCoderMetrics;
import com.healogics.encode.entity.ReloadInsurance;
import com.healogics.encode.entity.ReloadMetrics;
import com.healogics.encode.entity.SuperBillHistory;
import com.healogics.encode.entity.SuperbillVariance;
import com.healogics.encode.service.HistoryTimelineBO;

@Repository
@Transactional
public class IHealNotificationDAOImpl implements IHealNotificationDAO {


	private final Logger log = LoggerFactory
			.getLogger(IHealNotificationDAOImpl.class);

	private final SessionFactory sessionFactory;
	private final HistoryTimelineBO historyTimelineBO;
	private final DashboardDAO dashboardDAO;
	
	private final Environment env;
	private final RestTemplate restTemplate;


	@Autowired
	public IHealNotificationDAOImpl(SessionFactory sessionFactory,
			HistoryTimelineBO historyTimelineBO, DashboardDAO dashboardDAO,
			Environment env, RestTemplate restTemplate) {
		this.sessionFactory = sessionFactory;
		this.historyTimelineBO = historyTimelineBO;
		this.dashboardDAO = dashboardDAO;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	@Override
	public boolean saveDocumentNotificationData(Notification notification,
			boolean successStatus) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside saveSuperbillNotificationData Method:  {} ", notification);
		boolean status = false;
		try {
			if (notification != null) {
				session.save(notification);
				status = true;
			}
			log.debug("Superbill Notification saved in DB: {}", notification);
		} catch (Exception e) {
			log.error(
					"Exception occurred while saving superbill notification: {} ",
					notification);
			status = false;
		}
		return status;
	}

	@Override
	public boolean createDashboardRow(
			IHealNotificationReq iHealNotificationReq,
			String facilityId, String visitID, String patientID,
			Timestamp eventDateTime, String snfLocationName, boolean isPNHBOReceived) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside createDashboardRow Method: {} {} {}" + visitID + " "
				+ patientID + "" + eventDateTime);
		boolean isCreated = false;
		try {
			Dashboard dashboard = new Dashboard();
			if (visitID != null && !visitID.isEmpty() && patientID != null
					&& !patientID.isEmpty() && eventDateTime != null) {
				dashboard.setVisitId(Long.valueOf(visitID));
				dashboard.setFacilityId(Integer.valueOf(facilityId));
				dashboard.setPatientId(Long.valueOf(patientID));
				dashboard.setEventDatetime(eventDateTime);
				dashboard.setMessageDatetime(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setBluebookId(
						iHealNotificationReq.getBlueBookId());
				dashboard.setIhealConfig(
						iHealNotificationReq.getFacilityType());
				dashboard.setFacilityAlias(
						iHealNotificationReq.getFacilityName());
				dashboard.setReceivedDate(new Timestamp(System.currentTimeMillis()));
				dashboard.setProviderFirstName("Provider First");
				dashboard.setProviderLastName("Provider Last");
				dashboard.setPatientFirstName("Patient First");
				dashboard.setPatientLastName("Patient Last");
				dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
				
				String status = "";
				
				if (isPNHBOReceived) {
					dashboard.setHBOSigned(true);
					dashboard.setProgNoteSigned(true);
					status ="ProgNo/HBO signed";
					dashboard.setStatus("Pending Superbill");
					dashboard.setLastStatusChangeRole("Coder");
				} else {
					dashboard.setHBOSigned(false);
					dashboard.setProgNoteSigned(false);
					dashboard.setIsSBSigned(true);
					status = "Chart received";
					dashboard.setStatus("Received");
					dashboard.setLastStatusChangeRole("Coder");
				}
				
				dashboard.setIsLocked(0);
				dashboard.setLastUpdatedByTimestamp(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setLastUpdatedByUserFullName("Encode System");
				dashboard.setLastUpdatedByUserId("0");
				dashboard.setLastUpdatedByUsername("");
				
			    if(iHealNotificationReq.getCoc2Id() != null
			    		&& !iHealNotificationReq.getCoc2Id().isEmpty()
			    		&& iHealNotificationReq.getBlueBookId() != null
			    		&& !iHealNotificationReq.getBlueBookId().isEmpty()) {
					dashboard.setSNFLocation(true);
					dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
					dashboard.setSnfLocationName(snfLocationName);
				} else {
					FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
					log.debug("FacilityDetails: {} {}",facilityDetails);
					
					if(facilityDetails != null) {
						dashboard.setBluebookId(facilityDetails.getBluebookId());
						dashboard.setFacilityAlias(facilityDetails.getFacilityName());
						dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
						dashboard.setSnfLocationName(facilityDetails.getFacilityName());
					}
				}
				
				log.debug("Dashboard: {}", dashboard.toString());
				session.save(dashboard);
				isCreated = true;
				
				/*String hqlNotification = "FROM Notification WHERE visitId = :visitId";
				List<Notification> notifications = session.createQuery(hqlNotification, Notification.class)
						.setParameter("visitId", Long.valueOf(visitID)).list();*/
				
				Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
				if (iHealNotificationReq.getDataType().equalsIgnoreCase("SuperBillDocument")) {
					// Create and save Patient entity
					Patient patient = new Patient();
					patient.setVisitId(Long.valueOf(visitID));
					patient.setFacilityId(Integer.valueOf(facilityId));
					patient.setBluebookId(iHealNotificationReq.getBlueBookId());
					patient.setPatientId(patientID);
					patient.setFacilityName(iHealNotificationReq.getFacilityName());
					patient.setLastUpdatedTimestamp(currentTimestamp);
					log.debug("Patient: {}", patient.toString());
					session.saveOrUpdate(patient);
				}
	            
	            if (isPNHBOReceived) {
	            	saveTimeline(Long.valueOf(visitID), "Pending Superbill", null,
		            		0L, "i-heal", status, "Coder");
	            }
			}

		} catch (Exception e) {
			log.error("Exception occurred while Creating Row : {} {} {}" + visitID
					+ " " + patientID + " " + eventDateTime);
			isCreated = false;
		}
		return isCreated;
	}
	
	
	@Override
	public boolean createPatientRow(
			IHealNotificationReq iHealNotificationReq,
			String facilityId, String visitID, String patientID,
			Timestamp eventDateTime) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside createPatientRow Method::: {} {} {}" + visitID + " "
				+ patientID + "" + eventDateTime);
		boolean isCreated = false;
		try {
			
			if (visitID != null && !visitID.isEmpty() && patientID != null
					&& !patientID.isEmpty() && eventDateTime != null) {	
				
				String hqlNotification = "FROM Notification WHERE visitId = :visitId";
				List<Notification> notifications = session.createQuery(hqlNotification, Notification.class)
				                                            .setParameter("visitId", Long.valueOf(visitID))
				                                            .list();
				Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
				
				    if (iHealNotificationReq.getDataType().equalsIgnoreCase("SuperBillDocument")) {
				        // Create and save Patient entity
				        Patient patient = new Patient();
				        patient.setVisitId(Long.valueOf(visitID));
				        patient.setFacilityId(Integer.valueOf(facilityId));
				        patient.setBluebookId(iHealNotificationReq.getBlueBookId());  
				        patient.setPatientId(patientID);
				        patient.setFacilityName(iHealNotificationReq.getFacilityName());
				        patient.setLastUpdatedTimestamp(currentTimestamp);
				        log.debug("Patient: {}", patient.toString());
				        session.save(patient);
				        
				    }
				        
				isCreated = true;           
			}

		} catch (Exception e) {
			log.error("Exception occurred while Creating Patient Row : {} {} {}" + visitID
					+ " " + patientID + " " + eventDateTime);
			isCreated = false;
		}
		return isCreated;
	}
	
	//@Override
	public boolean createDashboardRowRetry(
			IHealNotificationReq iHealNotificationReq,
			String facilityId, String visitID, String patientID,
			Timestamp eventDateTime, String snfLocationName, boolean isPNHBOReceived) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside createDashboardRow Method::: {} {} {} " + visitID + " "
				+ patientID + "" + eventDateTime);
		boolean isCreated = false;
		try {
			Dashboard dashboard = new Dashboard();
			if (visitID != null && !visitID.isEmpty() && patientID != null
					&& !patientID.isEmpty() && eventDateTime != null) {
				dashboard.setVisitId(Long.valueOf(visitID));
				dashboard.setFacilityId(Integer.valueOf(facilityId));
				dashboard.setPatientId(Long.valueOf(patientID));
				dashboard.setEventDatetime(eventDateTime);
				dashboard.setMessageDatetime(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setBluebookId(
						iHealNotificationReq.getBlueBookId());
				dashboard.setIhealConfig(
						iHealNotificationReq.getFacilityType());
				dashboard.setFacilityAlias(
						iHealNotificationReq.getFacilityName());
				dashboard.setReceivedDate(new Timestamp(System.currentTimeMillis()));
				dashboard.setProviderFirstName("Provider First");
				dashboard.setProviderLastName("Provider Last");
				dashboard.setPatientFirstName("Patient First");
				dashboard.setPatientLastName("Patient Last");
				dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
				String status = "";
				
				if (isPNHBOReceived) {
					dashboard.setHBOSigned(true);
					dashboard.setProgNoteSigned(true);
					status ="ProgNo/HBO signed";
					dashboard.setStatus("Pending Superbill");
				} else {
					dashboard.setHBOSigned(false);
					dashboard.setProgNoteSigned(false);
					status = "Chart received";
					dashboard.setStatus("Received");
				}
				
				dashboard.setIsLocked(0);
				dashboard.setLastUpdatedByTimestamp(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setLastUpdatedByUserFullName("Encode System");
				dashboard.setLastUpdatedByUserId("0");
				dashboard.setLastUpdatedByUsername("");
				
			    if(iHealNotificationReq.getCoc2Id() != null
			    		&& !iHealNotificationReq.getCoc2Id().isEmpty()
			    		&& iHealNotificationReq.getBlueBookId() != null
			    		&& !iHealNotificationReq.getBlueBookId().isEmpty()) {
					dashboard.setSNFLocation(true);
					dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
					dashboard.setSnfLocationName(snfLocationName);
				} else {
					FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
					log.debug("FacilityDetails: {}",facilityDetails);
					
					if(facilityDetails != null) {
						dashboard.setBluebookId(facilityDetails.getBluebookId());
						dashboard.setFacilityAlias(facilityDetails.getFacilityName());
						dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
						dashboard.setSnfLocationName(facilityDetails.getFacilityName());
					}
				}
				
				log.debug("Dashboard: {}", dashboard.toString());
				session.save(dashboard);
				isCreated = true;
				
				String hqlNotification = "FROM Notification WHERE visitId = :visitId";
				List<Notification> notifications = session.createQuery(hqlNotification, Notification.class)
				                                            .setParameter("visitId", Long.valueOf(visitID))
				                                            .list();
				Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis()); 
			    if (iHealNotificationReq.getDataType().equalsIgnoreCase("SuperBillDocument")) {
				        // Create and save Patient entity
				        Patient patient = new Patient();
				        patient.setVisitId(Long.valueOf(visitID));
				        patient.setFacilityId(Integer.valueOf(facilityId));
				        patient.setBluebookId(iHealNotificationReq.getBlueBookId());  
				        patient.setPatientId(patientID);
				        patient.setFacilityName(iHealNotificationReq.getFacilityName());
				        patient.setLastUpdatedTimestamp(currentTimestamp);
				        log.debug("Patient: {}", patient.toString());
				        session.saveOrUpdate(patient);

				}
	            
	            
	            
	            saveTimeline(Long.valueOf(visitID), "Received", null,
	            		0L, "i-heal", status, "Coder");
			}

		} catch (Exception e) {
			log.error("Exception occurred while Creating Row : {} {} {}" + visitID
					+ " " + patientID + " " + eventDateTime);
			isCreated = false;
		}
		return isCreated;
	}

	
	@Override
	public void savePatientDetails(IHealSuperBillLoadObj superbill,
			IHealVisitObject visitDetails,IHealPatientLoadObj patientObj,
			String visitId, String facilityId, IHealNotificationReq iHealNotificationReq
			, boolean isRowExist,PlaceOfServiceRes placeOfServiceRes) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside savePatientDetails Method:::  {} {}" + visitId + " "
				+ patientObj);
		try {
			String hql = "From Dashboard where visitId = :visitId ";
			Dashboard dashboard = session.createQuery(hql, Dashboard.class)
					.setParameter("visitId", Long.valueOf(visitId))
					.setMaxResults(1).uniqueResult();
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
			LocalDateTime localDateTime = LocalDateTime
					.parse(patientObj.getPatientDOB(), formatter);
			Date date = Date.from(localDateTime
					.atZone(ZoneId.systemDefault()).toInstant());
			if (dashboard != null) {
				log.debug("Update Patient Details: {}" + dashboard);
				dashboard.setPatientFirstName(patientObj.getPatientFirstName());
				dashboard.setPatientLastName(patientObj.getPatientLastName());

				dashboard.setPatientDOB(date);
				dashboard.setGender(patientObj.getPatientSex());
				dashboard.setMedicalRecordNumber(patientObj.getPatientNumber());
				dashboard.setLastUpdatedByTimestamp(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setLastUpdatedByUserFullName("Encode System");
				dashboard.setLastUpdatedByUserId("0");
				dashboard.setLastUpdatedByUsername("");
				dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
				//String primaryInsuranceDescription = null;
				//String secondaryInsuranceDescription = null;
				for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
					if (insuranceObj.getSequence() == 1) {
						//primaryInsuranceDescription = "primary :" + insuranceObj.getInsuranceName();
						dashboard.setPrimaryInsurance(insuranceObj.getInsuranceName());

					} else if (insuranceObj.getSequence() == 2) {
						//secondaryInsuranceDescription = "secondary :" + insuranceObj.getInsuranceName();
						dashboard.setSecondaryInsurance(insuranceObj.getInsuranceName());
					}
				}
					session.update(dashboard);
				log.debug("Updated PatientDetails Dashboard Obj:  {}" + dashboard);
				
				// Update Patient entity
		        String hqlPatient = "FROM Patient WHERE visitId = :visitId";
		        Patient patient = session.createQuery(hqlPatient, Patient.class)
		                .setParameter("visitId", Long.valueOf(visitId))
		                .setMaxResults(1).uniqueResult();
		        
		        if (patient != null) {
		            log.debug("Update Patient Details: " + patient);
		            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		            patient.setGivenName(patientObj.getPatientFirstName());
		            patient.setFamilyName(patientObj.getPatientLastName());
		            patient.setPatientGender(patientObj.getPatientSex());
		            patient.setDateOfBirth(date);
		            patient.setStreetAddress(patientObj.getAddress1());
		            patient.setCity(patientObj.getCity());
		            patient.setState(patientObj.getState());
		            patient.setZipCode(patientObj.getZip());
		            patient.setLocationDescription(patientObj.getLocationDescription());
		            patient.setPhone1(patientObj.getPhone1());
		            patient.setPhone2(patientObj.getPhone2());
		            patient.setEmailId(patientObj.getEmail());

		            if (patientObj.getGuarantor() != null) {
		                IHealGuarantorObj guarantor = patientObj.getGuarantor();
		                patient.setGuarantorGivenName(guarantor.getFirstName());
		                patient.setGuarantorFamilyName(guarantor.getLastName());
		                patient.setGuarantorStreetAddress(guarantor.getAddress1());
		                patient.setGuarantorCity(guarantor.getCity());
		                patient.setGuarantorState(guarantor.getState());
		                patient.setGuarantorZip(guarantor.getZip());
		                patient.setGuarantorRelation(guarantor.getRelationship());
		            }
		            patient.setLastUpdatedTimestamp(currentTimestamp);
		            session.update(patient);
		            log.debug("Updated PatientDetails Patient Obj: {} ", patient);

				}    
			}
			
			String hqlDelete = "DELETE FROM PatientInsurance WHERE visitId = :visitId";
			Query query = session.createQuery(hqlDelete);
			query.setParameter("visitId", Long.valueOf(visitId));
			int deletedCount = query.executeUpdate();
			log.debug("Deleted {} PatientInsurance records with visitId {} {}", deletedCount, visitId);
			 
			// Save new PatientInsurance entities
			if (patientObj.getInsurance() != null && !patientObj.getInsurance().isEmpty()) {
			    for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
			        if (insuranceObj != null) { 
			            log.debug("Processing Insurance: {}", insuranceObj);
			            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
			            PatientInsurance patientInsurance = new PatientInsurance();
			            patientInsurance.setVisitId(Long.valueOf(visitId));
			            patientInsurance.setPatientId(patientObj.getPatientId());
			            patientInsurance.setFamilyName(patientObj.getPatientLastName());
			            patientInsurance.setGivenName(patientObj.getPatientFirstName());
			            patientInsurance.setFacilityId(facilityId);
			            FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
			            String blueBookIDPOS = null;
//						if (visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
//							blueBookIDPOS = "281_" + dashboard.getSnfLocationBBC();
//						} else if (visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {
//							blueBookIDPOS = "12" + dashboard.getSnfLocationBBC();
//						} else if ("Skilled Nursing Facility"
//								.equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {
//
//							if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
//								blueBookIDPOS = superbill.getPlaceOfServiceCode() + dashboard.getSnfLocationBBC();
//							}
//						} else {
//							blueBookIDPOS = dashboard.getSnfLocationBBC();
//						}
						if (visitDetails != null && visitDetails.getServiceLineDescription() != null
								&& visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
							blueBookIDPOS = "281_" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						} else if (visitDetails != null && visitDetails.getLocationDescription() != null
								&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {
							blueBookIDPOS = "12" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						} else if (facilityDetails != null && facilityDetails.getCurrentFacilityType() != null
								&& "Skilled Nursing Facility"
										.equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

							if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
								blueBookIDPOS = superbill.getPlaceOfServiceCode()
										+ (dashboard != null ? dashboard.getSnfLocationBBC() : "");
							}
						} else {
							blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");

						}
			           // patientInsurance.setBluebookId(facilityDetails.getBluebookId());
						patientInsurance.setBluebookId(blueBookIDPOS);
			            patientInsurance.setInsuranceId(String.valueOf(insuranceObj.getInsuranceId()));
			            patientInsurance.setInsuranceName(insuranceObj.getInsuranceName());
			            patientInsurance.setStreetAddress(insuranceObj.getAddress1());
			            patientInsurance.setOtherDesignation(insuranceObj.getAddress2());
			            patientInsurance.setPriority(String.valueOf(insuranceObj.getSequence()));
			            patientInsurance.setCity(insuranceObj.getCity());
			            patientInsurance.setState(insuranceObj.getState());
			            patientInsurance.setZip(insuranceObj.getZip());
			            if (insuranceObj.getInsured() != null) {
			                IHealInsuredObj insuredObj = insuranceObj.getInsured();
			                patientInsurance.setInsuredFamilyName(insuredObj.getLastName());
			                patientInsurance.setInsuredGivenName(insuredObj.getFirstName());
			                patientInsurance.setInsuredRelation(insuredObj.getRelationship());
			                patientInsurance.setInsuredDOB(insuranceObj.getInsuredDOB());
			            }
			            patientInsurance.setPolicyNumber(insuranceObj.getPolicyNumber());
			            patientInsurance.setGroupNumber(insuranceObj.getGroupNumber());
			            patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
			            log.debug("Saving PatientInsurance Obj: {}", patientInsurance);
			            session.save(patientInsurance);
			        }
	            }
	        }

		} catch (Exception e) {
			log.error("Exception occurred while Saving Patient Details: {} {}", visitId, e.getMessage());
		}
	}
	
	@Override
	public void saveVisitDetails(IHealSuperBillLoadObj superbill,
			IHealVisitObject visitDetails, String visitID,
			String facilityId, IHealNotificationReq iHealNotificationReq,
			boolean isRowExist, String snfLocationName,
			PlaceOfServiceRes placeOfServiceRes) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside saveVisitDetails Method::  {} {}" + visitID + " "
				+ visitDetails);
		try {
			String hql = " From Dashboard where visitId = :visitId ";
			Dashboard dashboard = session.createQuery(hql, Dashboard.class)
					.setParameter("visitId", Long.valueOf(visitID))
					.setMaxResults(1).uniqueResult();
			
			FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
			log.debug("FacilityDetails: {}",facilityDetails);
			
			if (dashboard != null) {
				log.debug("Updating Visit Details: " + visitID);
				dashboard.setProviderId(String.valueOf(visitDetails.getProviderId()));
				dashboard.setProviderFirstName(
						visitDetails.getProviderFirstName());
				dashboard.setProviderLastName(
						visitDetails.getProviderLastName());
				dashboard.setEncounterType(
						visitDetails.getVisitTypeDescription());
				dashboard.setServiceLine(visitDetails.getServiceLineDescription());
				dashboard.setLastUpdatedByTimestamp(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setLastUpdatedByUserFullName("Encode System");
				dashboard.setLastUpdatedByUserId("0");
				dashboard.setLastUpdatedByUsername("");
				
				String visitDateTime = visitDetails.getVisitDateTime();
	            DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
	            OffsetDateTime offsetDateTime = OffsetDateTime.parse(visitDateTime, formatter);
	 
	            // Keep the local date-time as is (no conversion to UTC)
	            LocalDateTime localDateTime = offsetDateTime.toLocalDateTime();
	 
	            // Convert LocalDateTime to Timestamp (without any offset conversion)
	            Timestamp dosTimestamp = Timestamp.valueOf(localDateTime);
				 
				log.info("Date Format for DOS Visit details : {} ", visitDetails.getVisitDateTime());
				log.info("Date Format for DOS Visit details After Format: {} ", dosTimestamp);

				dashboard.setDateOfService(dosTimestamp);
				
				UserFacilityRes facilityRes = getUserFacilities(env
						.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_USERID),
						env.getProperty(
								BOConstants.NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN));
				
				String fcilityConfig = "";
				
				if (facilityRes != null && facilityRes.getResponseCode().equalsIgnoreCase("0")
						&& facilityRes.getFacilities() != null) {
					List<UserFacilities> facilities = facilityRes.getFacilities().stream().filter(
							f -> f != null
							&& f.getFacilityId() != null
							&& f.getFacilityId().equalsIgnoreCase(iHealNotificationReq.getFacilityID()))
							.collect(Collectors.toList());
					
					if (facilities != null && facilities.size() > 0) {
						UserFacilities facility = facilities.get(0);
						
						log.debug("facility : " +facility);
						
						if (facility != null) {
							fcilityConfig = facility.getConfiguration();
							log.debug("fcilityConfig : " +fcilityConfig);
						}
					}
				}
				
				//Moving Nurse Visit to Unbillable
				if (visitDetails != null
						&& visitDetails.getVisitTypeCode() == 8
						&& visitDetails.getVisitTypeDescription() != null
						&& visitDetails.getVisitTypeDescription()
							.equalsIgnoreCase("Nurse Visit")) {
					
					dashboard.setStatus("Unbillable");
					dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
					dashboard.setLastStatusChangeRole("Coder");
					log.info("timeline - 1");
					saveTimeline(Long.valueOf(visitID), "Unbillable", null,
							0L, "i-heal", "New chart has been added", "Coder");
					
				//ServiceLine is HSP Inpatient Consult or Inpatient
				} else if (visitDetails != null && visitDetails.getServiceLineDescription() != null
						&& (visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")
								|| visitDetails.getServiceLineDescription().equalsIgnoreCase("Inpatient"))) {
					
					// Saving New action in timeline
					if (isRowExist
							&& dashboard.getStatus() != null
							&& !dashboard.getStatus().isEmpty()) {
						
						if (dashboard.getStatus().equalsIgnoreCase("Pending Superbill")) {
							//PN or HBO doc exists and then move to Coder with Ready status
							boolean isDocumentTypeValid = checkIfDocumentTypeExists(Long.valueOf(visitID),dashboard.getPatientId(), "PN") || checkIfDocumentTypeExists(Long.valueOf(visitID),dashboard.getPatientId(), "HBO");
							
							if (isDocumentTypeValid) {
								dashboard.setStatus("Ready");
								dashboard.setLastStatusChangeRole("Coder");
								dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
								log.info("timeline - 2");
								saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
										"Superbill updated", "Coder");
							} else {
								log.info("timeline - 3");
								saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
										"Superbill updated", "CMC");
							}
						} else {
							log.info("timeline - 4");
							saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
									"Superbill updated", "CMC");
						}
						
						
					} else {
						dashboard.setStatus("New");
						dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
						dashboard.setLastStatusChangeRole("CMC");
						log.info("timeline - 5");
						saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
								"New chart has been added", "CMC");
					}
				
				} else if (!fcilityConfig.isEmpty() && (fcilityConfig.equalsIgnoreCase("OT")
						|| fcilityConfig.equalsIgnoreCase("POS"))) {
					
					// Saving New action in timeline
					if (isRowExist
							&& dashboard.getStatus() != null
							&& !dashboard.getStatus().isEmpty()) {
						log.info("timeline - 6");
						saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
								"Superbill updated", "CMC");
					} else {
						dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");
						log.info("timeline - 7");
						saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
								"New chart has been added", "CMC");
					}
					
				} else {
					String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
					DisparateFacilities disparateFacilities = session
							.createQuery(hqlDisparate, DisparateFacilities.class)
							.setParameter("bluebookId", iHealNotificationReq.getBlueBookId()).setMaxResults(1)
							.uniqueResult();
					
					//Disparate facility
					if (disparateFacilities != null && visitDetails != null
							&& visitDetails.getServiceLineDescription() != null
							&& !visitDetails.getServiceLineDescription().equalsIgnoreCase("Outpatient")
							&& !fcilityConfig.isEmpty()
							&& fcilityConfig.equalsIgnoreCase("EMR")) {
						// Saving New action in timeline
						if (isRowExist
								&& dashboard.getStatus() != null
								&& !dashboard.getStatus().isEmpty()) {
							
							if (dashboard.getStatus().equalsIgnoreCase("New")
									|| dashboard.getStatus().equalsIgnoreCase("Received")
									|| dashboard.getStatus().equalsIgnoreCase("Pending Superbill")) {
								
								//PN or HBO doc exists and then move to Coder with Ready status
								boolean isDocumentTypeValid = checkIfDocumentTypeExists(Long.valueOf(visitID),dashboard.getPatientId(), "PN") || checkIfDocumentTypeExists(Long.valueOf(visitID),dashboard.getPatientId(), "HBO");
								
								if (isDocumentTypeValid) {
									dashboard.setStatus("Ready");
									dashboard.setLastStatusChangeRole("Coder");
									dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
									log.info("timeline - 8");
									saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
											"Superbill updated", "Coder");
								} else {
									log.info("timeline - 9");
									saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
											"Superbill updated", "CMC");
								}
								
							} else {
								log.info("timeline - 10");
								saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
										"Superbill updated", "CMC");
							}
               		}else {
							dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
							dashboard.setStatus("New");
							dashboard.setLastStatusChangeRole("CMC");
							log.info("timeline - 11");
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
									"New chart has been added", "CMC");
						}
					} else {
						dashboard.setLastStatusChangeRole("Coder");

						// Saving Received action in timeline
						if (isRowExist) {
							if (dashboard.getStatus() != null
									&& dashboard.getStatus().equalsIgnoreCase("Pending Superbill")
									&& (dashboard.isHBOSigned() || dashboard.isProgNoteSigned())) {
								
								dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
								dashboard.setStatus("Ready");
								log.info("timeline - 12");
								saveTimeline(Long.valueOf(visitID), "Ready", null, 0L, "i-heal", "Superbill updated",
										"Coder");
							} else {
								log.info("timeline - 13");
								saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal", "Superbill updated",
										"Coder");
							}
							
						} else {
							dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
							dashboard.setStatus("Received");
							log.info("timeline - 14");
							saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal", "Chart received",
									"Coder");
						}
					}
				}
				
				/*
				FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
				log.debug("FacilityDetails: {}",facilityDetails);

				if (visitDetails != null
						&& visitDetails.getVisitTypeCode() == 8
						&& visitDetails.getVisitTypeDescription() != null
						&& visitDetails.getVisitTypeDescription()
							.equalsIgnoreCase("Nurse Visit")) {
					dashboard.setStatus("Unbillable");
					dashboard.setLastStatusChangeRole("Coder");
					
					saveTimeline(Long.valueOf(visitID), "Unbillable", null,
							0L, "i-heal", "New chart has been added", "Coder");
					
				} else if (facilityDetails != null && facilityDetails.getBluebookId() != null
						&& !facilityDetails.getBluebookId().isEmpty()) {
					
					log.debug("Updating using FacilityDetails Table");
					
					// Check if the bluebookId exists in the DisparateFacilities table
					log.info("bluebookId : {} " ,facilityDetails.getBluebookId());
					
					String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
					DisparateFacilities disparateFacilities = session
							.createQuery(hqlDisparate, DisparateFacilities.class)
							.setParameter("bluebookId", facilityDetails.getBluebookId()).setMaxResults(1)
							.uniqueResult();
 
					if (disparateFacilities != null) {
						log.info("disparateFacilities : {} ", disparateFacilities );
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");
						if (isRowExist) {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated", "CMC");
						} else {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "New chart has been added",
									"CMC");
						}
					} else if(facilityDetails.getCurrentFacilityType().equalsIgnoreCase("Outpatient Hospital")
							&& visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
						// ENC-2955
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");

						// Saving New action in timeline
						if (isRowExist) {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated",
									"CMC");
						} else {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
									"New chart has been added", "CMC");
						}
						
					} else if (facilityDetails.getCurrentIHealConfig().equalsIgnoreCase("EMR")) {
						if ((visitDetails.getServiceLineDescription().equalsIgnoreCase("Inpatient")) || 
								(visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) ) {
							dashboard.setStatus("New");
							dashboard.setLastStatusChangeRole("CMC");

							// Saving New action in timeline
							if (isRowExist) {
								saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated",
										"CMC");
							} else {
								saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
										"New chart has been added", "CMC");
							}
						} else {
							dashboard.setLastStatusChangeRole("Coder");

							// Saving Received action in timeline
							if (isRowExist) {
								if (dashboard.getStatus() != null
										&& dashboard.getStatus().equalsIgnoreCase("Pending Superbill")
										&& (dashboard.isHBOSigned() || dashboard.isProgNoteSigned())) {
									
									dashboard.setStatus("Ready");
									saveTimeline(Long.valueOf(visitID), "Ready", null, 0L, "i-heal", "Superbill updated",
											"Coder");
								} else {
									saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal", "Superbill updated",
											"Coder");
								}
								
							} else {
								dashboard.setStatus("Received");
								saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal", "Chart received",
										"Coder");
							}
						}
					} else {
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");

						// Saving New action in timeline
						if (isRowExist) {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated", "CMC");
						} else {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "New chart has been added",
									"CMC");
						}
					}
					*/
				
					dashboard.setBluebookId(facilityDetails.getBluebookId());
					dashboard.setIhealConfig(facilityDetails.getCurrentIHealConfig());
					dashboard.setFacilityAlias(facilityDetails.getFacilityName());
					dashboard.setFacilityType(facilityDetails.getCurrentFacilityType());
					
					if(iHealNotificationReq.getCoc2Id() != null
							&& !iHealNotificationReq.getCoc2Id().isEmpty()
							&& iHealNotificationReq.getBlueBookId() != null
							&& !iHealNotificationReq.getBlueBookId().isEmpty()) {
						dashboard.setSNFLocation(true);
						dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
						dashboard.setSnfLocationName(snfLocationName);
					} else {
						dashboard.setSnfLocationBBC(facilityDetails.getBluebookId());
						dashboard.setSnfLocationName(facilityDetails.getFacilityName());
					}
					
				}
			
				/*else {
					log.debug("Updating using SuperBill Notification API");
					
					//While reload Super bill, we dont have facility type in notification table
					
					if (iHealNotificationReq.getFacilityType().equalsIgnoreCase("EMR")) {
						dashboard.setStatus("Received");
						dashboard.setLastStatusChangeRole("Coder");
						
						// Saving Received action in timeline
						saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal",
								"Chart received", "Coder");
					} else {
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");

						// Saving New action in timeline
						saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", 
								"New chart has been added", "CMC");
					}
					dashboard.setBluebookId(iHealNotificationReq.getBlueBookId());
					//dashboard.setFacilityType(iHealNotificationReq.getFacilityType());
					dashboard.setFacilityAlias(iHealNotificationReq.getFacilityName());
				}*/
			
				session.update(dashboard);
				log.debug("Updated saveVisitDetails  in Dashboard:  {} {}" + visitID + " "
						+ visitDetails);
				
				  // Update Patient entity
	            String hqlPatient = "FROM Patient WHERE visitId = :visitId";
	            Patient patient = session.createQuery(hqlPatient, Patient.class)
	                    .setParameter("visitId", Long.valueOf(visitID))
	                    .setMaxResults(1).uniqueResult();
	 
				if (patient != null) {
					Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
					log.debug("Updating Patient Details: " + visitID);
					
					if (facilityDetails != null) {
						
						String blueBookIDPOS = null;
						
						if (visitDetails != null && visitDetails.getServiceLineDescription() != null
								&& visitDetails.getServiceLineDescription()
								.equalsIgnoreCase("HSP Inpatient Consult")) {
							
							blueBookIDPOS = "281_" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
							
						} else if (visitDetails != null && visitDetails.getLocationDescription() != null
								&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {
							
							blueBookIDPOS = "12" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
							
						} else if (facilityDetails != null
								&& facilityDetails.getCurrentFacilityType() != null
								&& "Skilled Nursing Facility"
										.equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

							if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
								blueBookIDPOS = superbill.getPlaceOfServiceCode()
										+ (dashboard != null ? dashboard.getSnfLocationBBC() : "");
							}
						} else {
							blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						}
						
						patient.setBluebookId(blueBookIDPOS);
						patient.setFacilityName(facilityDetails.getFacilityName());
						patient.setPointOfCare(facilityDetails.getFacilityName());
						//patient.setBed(facilityDetails.getBluebookId());
						patient.setBed(blueBookIDPOS);
						patient.setFloor(facilityDetails.getFacilityName());
						//patient.setBirthPlace(facilityDetails.getBluebookId());
						patient.setBirthPlace(blueBookIDPOS);
					}
					patient.setAttendingDocId(String.valueOf(visitDetails.getProviderId()));
					patient.setAttendingDocName(
							visitDetails.getProviderFirstName() + " " + visitDetails.getProviderLastName());
					patient.setAdmittingDocId(String.valueOf(visitDetails.getProviderId()));
					patient.setAdmittingDocFamilyName(visitDetails.getProviderLastName());
					patient.setAdmittingDocGivenName(visitDetails.getProviderFirstName());
                    patient.setLastUpdatedTimestamp(currentTimestamp);
					session.update(patient);
					log.debug("Updated saveVisitDetails in Patient: {} {}", visitID, visitDetails);
				}
				
			String hqlPatientInsurance = "FROM PatientInsurance WHERE visitId = :visitId";
			PatientInsurance patientInsurance = session.createQuery(hqlPatientInsurance, PatientInsurance.class)
					.setParameter("visitId", Long.valueOf(visitID)).setMaxResults(1).uniqueResult();

			if (patientInsurance != null) {
				Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
				log.debug("Updating Patient Details: " + visitID);
				
				if (facilityDetails != null) {
					
					String blueBookIDPOS = null;
					
					if (visitDetails != null && visitDetails.getServiceLineDescription() != null
							&& visitDetails.getServiceLineDescription()
							.equalsIgnoreCase("HSP Inpatient Consult")) {
						
						blueBookIDPOS = "281_" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						
					} else if (visitDetails != null && visitDetails.getLocationDescription() != null
							&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {
						
						blueBookIDPOS = "12" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						
					} else if (facilityDetails != null && facilityDetails.getCurrentFacilityType() != null
							&& "Skilled Nursing Facility".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

						if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
							blueBookIDPOS = superbill.getPlaceOfServiceCode()
									+ (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						}
					} else {
						blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");
					}
					patientInsurance.setBluebookId(blueBookIDPOS);
					patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
				}
				session.update(patient);
			}

		} catch (Exception e) {
			log.error("Exception occurred while Saving Visit Details: {} {}",
					visitID, e.getMessage());
		}

	}
	
	@Override
	public void saveVisitDetailsReload(IHealSuperBillLoadObj superbill,
			IHealVisitObject visitDetails, String visitID,
			String facilityId, IHealNotificationReq iHealNotificationReq,
			boolean isRowExist, String snfLocationName,
			PlaceOfServiceRes placeOfServiceRes) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside saveVisitDetails Method:  {} " + visitID + " "
				+ visitDetails);
		try {
			String hql = " From Dashboard where visitId = :visitId ";
			Dashboard dashboard = session.createQuery(hql, Dashboard.class)
					.setParameter("visitId", Long.valueOf(visitID))
					.setMaxResults(1).uniqueResult();
			
			FacilityDetails facilityDetails  = getFacilityDetails(facilityId);
			log.debug("FacilityDetails: {}",facilityDetails);
			
			if (dashboard != null) {
				log.debug("Updating Visit Details: " + visitID);
				dashboard.setProviderId(String.valueOf(visitDetails.getProviderId()));
				dashboard.setProviderFirstName(
						visitDetails.getProviderFirstName());
				dashboard.setProviderLastName(
						visitDetails.getProviderLastName());
				dashboard.setEncounterType(
						visitDetails.getVisitTypeDescription());
				dashboard.setServiceLine(visitDetails.getServiceLineDescription());
				dashboard.setLastUpdatedByTimestamp(
						new Timestamp(System.currentTimeMillis()));
				dashboard.setLastUpdatedByUserFullName("Encode System");
				dashboard.setLastUpdatedByUserId("0");
				dashboard.setLastUpdatedByUsername("");
				dashboard.setStatusChangeTimestamp(new Timestamp(System.currentTimeMillis()));
				
				String visitDateTime = visitDetails.getVisitDateTime();
	            DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
	            OffsetDateTime offsetDateTime = OffsetDateTime.parse(visitDateTime, formatter);
	 
	            // Keep the local date-time as is (no conversion to UTC)
	            LocalDateTime localDateTime = offsetDateTime.toLocalDateTime();
	 
	            // Convert LocalDateTime to Timestamp (without any offset conversion)
	            Timestamp dosTimestamp = Timestamp.valueOf(localDateTime);
				 
				log.info("Date Format for DOS Visit details : {} ", visitDetails.getVisitDateTime());
				log.info("Date Format for DOS Visit details After Format: {} ", dosTimestamp);

				dashboard.setDateOfService(dosTimestamp);
				
				UserFacilityRes facilityRes = getUserFacilities(env
						.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_USERID),
						env.getProperty(
								BOConstants.NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN));
				
				String fcilityConfig = "";
				
				if (facilityRes != null && facilityRes.getResponseCode().equalsIgnoreCase("0")
						&& facilityRes.getFacilities() != null) {
					List<UserFacilities> facilities = facilityRes.getFacilities().stream().filter(
							f -> f != null
							&& f.getFacilityId() != null
							&& f.getFacilityId().equalsIgnoreCase(iHealNotificationReq.getFacilityID()))
							.collect(Collectors.toList());
					
					if (facilities != null && facilities.size() > 0) {
						UserFacilities facility = facilities.get(0);
						
						log.debug("facility : " +facility);
						
						if (facility != null) {
							fcilityConfig = facility.getConfiguration();
							log.debug("fcilityConfig : " +fcilityConfig);
						}
					}
				}
				
				//Moving Nurse Visit to Unbillable
				if (visitDetails != null
						&& visitDetails.getVisitTypeCode() == 8
						&& visitDetails.getVisitTypeDescription() != null
						&& visitDetails.getVisitTypeDescription()
							.equalsIgnoreCase("Nurse Visit")) {
					
					dashboard.setStatus("Unbillable");
					dashboard.setLastStatusChangeRole("Coder");
					
					saveTimeline(Long.valueOf(visitID), "Unbillable", null,
							0L, "i-heal", "New chart has been added", "Coder");
					
				//ServiceLine is HSP Inpatient Consult or Inpatient
				} else if (visitDetails != null && visitDetails.getServiceLineDescription() != null
						&& (visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")
								|| visitDetails.getServiceLineDescription().equalsIgnoreCase("Inpatient"))) {
					
					// Saving New action in timeline
					if (isRowExist
							&& dashboard.getStatus() != null
							&& !dashboard.getStatus().isEmpty()) {
						
						saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
								"Superbill updated", "CMC");
					} else {
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");
						saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
								"New chart has been added", "CMC");
					}
				
				} else if (!fcilityConfig.isEmpty() && (fcilityConfig.equalsIgnoreCase("OT")
						|| fcilityConfig.equalsIgnoreCase("POS"))) {
					
					// Saving New action in timeline
					if (isRowExist
							&& dashboard.getStatus() != null
							&& !dashboard.getStatus().isEmpty()) {
						
						saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
								"Superbill updated", "CMC");
					} else {
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");
						saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
								"New chart has been added", "CMC");
					}
					
				} else {
					String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
					DisparateFacilities disparateFacilities = session
							.createQuery(hqlDisparate, DisparateFacilities.class)
							.setParameter("bluebookId", iHealNotificationReq.getBlueBookId()).setMaxResults(1)
							.uniqueResult();
					
					//Disparate facility
					if (disparateFacilities != null && visitDetails != null
							&& visitDetails.getServiceLineDescription() != null
							&& !visitDetails.getServiceLineDescription().equalsIgnoreCase("Outpatient")
							&& !fcilityConfig.isEmpty()
							&& fcilityConfig.equalsIgnoreCase("EMR")) {
						// Saving New action in timeline
						if (isRowExist
								&& dashboard.getStatus() != null
								&& !dashboard.getStatus().isEmpty()) {
							
							saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal",
									"Superbill updated", "CMC");
						} else {
							dashboard.setStatus("New");
							dashboard.setLastStatusChangeRole("CMC");
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
									"New chart has been added", "CMC");
						}
					} else {
						dashboard.setLastStatusChangeRole("Coder");

						// Saving Received action in timeline
						if (isRowExist) {
							if (dashboard.getStatus() != null
									&& dashboard.getStatus().equalsIgnoreCase("Pending Superbill")
									&& (dashboard.isHBOSigned() || dashboard.isProgNoteSigned())) {
								
								dashboard.setStatus("Ready");
								saveTimeline(Long.valueOf(visitID), "Ready", null, 0L, "i-heal", "Superbill updated",
										"Coder");
							} else {
								saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal", "Superbill updated",
										"Coder");
							}
							
						} else {
							dashboard.setStatus("Received");
							saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal", "Chart received",
									"Coder");
						}
					}
				}

				/*if (facilityDetails != null && facilityDetails.getBluebookId() != null
						&& !facilityDetails.getBluebookId().isEmpty()) {
					
					log.debug("Updating using FacilityDetails Table");
					
					// Check if the bluebookId exists in the DisparateFacilities table
					log.info("bluebookId : {} " ,facilityDetails.getBluebookId());
					
					String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
					DisparateFacilities disparateFacilities = session
							.createQuery(hqlDisparate, DisparateFacilities.class)
							.setParameter("bluebookId", facilityDetails.getBluebookId()).setMaxResults(1)
							.uniqueResult();
 
					if (disparateFacilities != null) {
						log.info("disparateFacilities : {} ", disparateFacilities );
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");
						if (isRowExist) {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated", "CMC");
						} else {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "New chart has been added",
									"CMC");
						}
					} else if(facilityDetails.getCurrentFacilityType().equalsIgnoreCase("Outpatient Hospital")
							&& visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
						// ENC-2955
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");

						// Saving New action in timeline
						if (isRowExist) {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated",
									"CMC");
						} else {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
									"New chart has been added", "CMC");
						}
						
					} else if (facilityDetails.getCurrentIHealConfig().equalsIgnoreCase("EMR")) {
						if ((visitDetails.getServiceLineDescription().equalsIgnoreCase("Inpatient")) || 
								(visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) ) {
							dashboard.setStatus("New");
							dashboard.setLastStatusChangeRole("CMC");

							// Saving New action in timeline
							if (isRowExist) {
								saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated",
										"CMC");
							} else {
								saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal",
										"New chart has been added", "CMC");
							}
						} else {
							dashboard.setLastStatusChangeRole("Coder");

							// Saving Received action in timeline
							if (isRowExist) {
								if (dashboard.getStatus() != null
										&& dashboard.getStatus().equalsIgnoreCase("Received")
										&& (dashboard.isHBOSigned() || dashboard.isProgNoteSigned())) {
									
									dashboard.setStatus("Ready");
									saveTimeline(Long.valueOf(visitID), "Ready", null, 0L, "i-heal", "Superbill updated",
											"Coder");
								} else {
									if (dashboard.getStatus() == null || dashboard.getStatus().isEmpty()) {
										saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal", "Superbill updated",
												"Coder");
									} else {
										saveTimeline(Long.valueOf(visitID), dashboard.getStatus(), null, 0L, "i-heal", "Superbill updated",
												"Coder");
									}
								}
								
							} else {
								dashboard.setStatus("Received");
								saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal", "Chart received",
										"Coder");
							}
						}
					} else {
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");

						// Saving New action in timeline
						if (isRowExist) {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "Superbill updated", "CMC");
						} else {
							saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", "New chart has been added",
									"CMC");
						}
					}*/

					/*dashboard.setBluebookId(facilityDetails.getBluebookId());
					dashboard.setIhealConfig(facilityDetails.getCurrentIHealConfig());
					dashboard.setFacilityAlias(facilityDetails.getFacilityName());
					dashboard.setFacilityType(facilityDetails.getCurrentFacilityType());
					
					if(iHealNotificationReq.getCoc2Id() != null
							&& !iHealNotificationReq.getCoc2Id().isEmpty()
							&& iHealNotificationReq.getBlueBookId() != null
							&& !iHealNotificationReq.getBlueBookId().isEmpty()) {
						dashboard.setSNFLocation(true);
						dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
						dashboard.setSnfLocationName(snfLocationName);
					} else {
						dashboard.setSnfLocationBBC(facilityDetails.getBluebookId());
						dashboard.setSnfLocationName(facilityDetails.getFacilityName());
					}*/
					
				} 
				
				/*else {
					log.debug("Updating using SuperBill Notification API");
					
					//While reload Super bill, we dont have facility type in notification table
					
					if (iHealNotificationReq.getFacilityType().equalsIgnoreCase("EMR")) {
						dashboard.setStatus("Received");
						dashboard.setLastStatusChangeRole("Coder");
						
						// Saving Received action in timeline
						saveTimeline(Long.valueOf(visitID), "Received", null, 0L, "i-heal",
								"Chart received", "Coder");
					} else {
						dashboard.setStatus("New");
						dashboard.setLastStatusChangeRole("CMC");

						// Saving New action in timeline
						saveTimeline(Long.valueOf(visitID), "New", null, 0L, "i-heal", 
								"New chart has been added", "CMC");
					}
					dashboard.setBluebookId(iHealNotificationReq.getBluebookID());
					//dashboard.setFacilityType(iHealNotificationReq.getFacilityType());
					dashboard.setFacilityAlias(iHealNotificationReq.getFacilityName());
				}*/
			
			dashboard.setBluebookId(facilityDetails.getBluebookId());
			dashboard.setIhealConfig(facilityDetails.getCurrentIHealConfig());
			dashboard.setFacilityAlias(facilityDetails.getFacilityName());
			dashboard.setFacilityType(facilityDetails.getCurrentFacilityType());
			
			if(iHealNotificationReq.getCoc2Id() != null
					&& !iHealNotificationReq.getCoc2Id().isEmpty()
					&& iHealNotificationReq.getBlueBookId() != null
					&& !iHealNotificationReq.getBlueBookId().isEmpty()) {
				dashboard.setSNFLocation(true);
				dashboard.setSnfLocationBBC(iHealNotificationReq.getBlueBookId());
				dashboard.setSnfLocationName(snfLocationName);
			} else {
				dashboard.setSnfLocationBBC(facilityDetails.getBluebookId());
				dashboard.setSnfLocationName(facilityDetails.getFacilityName());
			}
				
			session.update(dashboard);
			log.debug("Updated saveVisitDetails  in Dashboard:  {} {}" + visitID + " " + visitDetails);

			// Update Patient entity
			String hqlPatient = "FROM Patient WHERE visitId = :visitId";
			Patient patient = session.createQuery(hqlPatient, Patient.class)
					.setParameter("visitId", Long.valueOf(visitID)).setMaxResults(1).uniqueResult();

			if (patient != null) {
				Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
				log.debug("Updating Patient Details: " + visitID);

				if (facilityDetails != null) {

					String blueBookIDPOS = null;

					if (visitDetails != null && visitDetails.getServiceLineDescription() != null
							&& visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {

						blueBookIDPOS = "281_" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");

					} else if (visitDetails != null && visitDetails.getLocationDescription() != null
							&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {

						blueBookIDPOS = "12" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");

					} else if (facilityDetails != null && facilityDetails.getCurrentFacilityType() != null
							&& "Skilled Nursing Facility".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

						if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
							blueBookIDPOS = superbill.getPlaceOfServiceCode()
									+ (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						}
					} else {
						blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");
					}

					patient.setBluebookId(blueBookIDPOS);
					patient.setFacilityName(facilityDetails.getFacilityName());
					patient.setPointOfCare(facilityDetails.getFacilityName());
					// patient.setBed(facilityDetails.getBluebookId());
					patient.setBed(blueBookIDPOS);
					patient.setFloor(facilityDetails.getFacilityName());
					// patient.setBirthPlace(facilityDetails.getBluebookId());
					patient.setBirthPlace(blueBookIDPOS);
				}
				patient.setAttendingDocId(String.valueOf(visitDetails.getProviderId()));
				patient.setAttendingDocName(
						visitDetails.getProviderFirstName() + " " + visitDetails.getProviderLastName());
				patient.setAdmittingDocId(String.valueOf(visitDetails.getProviderId()));
				patient.setAdmittingDocFamilyName(visitDetails.getProviderLastName());
				patient.setAdmittingDocGivenName(visitDetails.getProviderFirstName());
				patient.setLastUpdatedTimestamp(currentTimestamp);
				session.update(patient);
				log.debug("Updated saveVisitDetails in Patient: {} {}", visitID, visitDetails);
			}

			String hqlPatientInsurance = "FROM PatientInsurance WHERE visitId = :visitId";
			PatientInsurance patientInsurance = session.createQuery(hqlPatientInsurance, PatientInsurance.class)
					.setParameter("visitId", Long.valueOf(visitID)).setMaxResults(1).uniqueResult();

			if (patientInsurance != null) {
				Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
				log.debug("Updating Patient Details: " + visitID);

				if (facilityDetails != null) {

					String blueBookIDPOS = null;

					if (visitDetails != null && visitDetails.getServiceLineDescription() != null
							&& visitDetails.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {

						blueBookIDPOS = "281_" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");

					} else if (visitDetails != null && visitDetails.getLocationDescription() != null
							&& visitDetails.getLocationDescription().equalsIgnoreCase("Home Visit")) {

						blueBookIDPOS = "12" + (dashboard != null ? dashboard.getSnfLocationBBC() : "");

					} else if (facilityDetails != null && facilityDetails.getCurrentFacilityType() != null
							&& "Skilled Nursing Facility".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {

						if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
							blueBookIDPOS = superbill.getPlaceOfServiceCode()
									+ (dashboard != null ? dashboard.getSnfLocationBBC() : "");
						}
					} else {
						blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");
					}
					patientInsurance.setBluebookId(blueBookIDPOS);
					patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
				}
				session.update(patient);
			}
		} catch (Exception e) {
			log.error("Exception occurred while Saving Visit Details: {} {}", visitID, e.getMessage());
		}
	}
	
	@Override
	public void saveDashboard(Dashboard dashbord, boolean updateStatus) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			if (updateStatus) {
				session.update(dashbord);
				
				saveTimeline(dashbord.getVisitId(), dashbord.getStatus(), null, 
						0L, "i-heal", "ProgNo/HBO signed", "Coder");
			} else {
				saveTimeline(dashbord.getVisitId(), dashbord.getStatus(), null,
						0L, "i-heal", "ProgNo/HBO signed", "Coder");
			}
		} catch (Exception e) {
			log.error("Exception occured : {}" ,e.getMessage());
		}
	}
	
	@Override
	public void saveDashboardnTimeline(Dashboard dashbord, String recordStatus,
			String timelineDesc) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			session.update(dashbord);
			
			saveTimeline(dashbord.getVisitId(), recordStatus, null, 
					0L, "i-heal", timelineDesc, "Coder");
		} catch (Exception e) {
			log.error("Exception occured : {}" ,e.getMessage());
		}
	}
	
	private FacilityDetails getFacilityDetails(String facilityId) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside getFacilityDetails Method:  {} " + facilityId );
		FacilityDetails details = new FacilityDetails();
		try {
			
			String hql = " From FacilityDetails where facilityId = :facilityId "
					+ " AND active = 1";
			FacilityDetails facilityDetails = session.createQuery(hql, FacilityDetails.class)
					.setParameter("facilityId", Integer.parseInt(facilityId))
					.setMaxResults(1).uniqueResult();
			if(facilityDetails != null) {
				details = facilityDetails;
			}
			
		} catch (Exception e) {
			log.error("Exception occurred while Fetching Facility Details: {} {}",
					facilityId, e.getMessage());
		}
		return details;
	}
	private Dashboard getSnfLocationBbc(String facilityId) {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("Inside getFacilityDetails Method:  {} " + facilityId );
		Dashboard details = new Dashboard();
		try {
			
			String hql = " From Dashboard where facilityId = :facilityId ";
			Dashboard facilityDetails = session.createQuery(hql, Dashboard.class)
					.setParameter("facilityId", Integer.parseInt(facilityId))
					.setMaxResults(1).uniqueResult();
			if(facilityDetails != null) {
				details = facilityDetails;
			}
			
		} catch (Exception e) {
			log.error("Exception occurred while Fetching Facility Details: {} {}",
					facilityId, e.getMessage());
		}
		return details;
	}

	
	@Override
	public void savePatientRecords(Dashboard dasboardObj, String documentType,
			long docEntityId, String docSource, Timestamp receivedTimestamp, boolean isRecordExists,
			PatientMedicalRecords patientMedicalRecords,IHealNotificationReq iHealNotificationReq) {
		log.debug("Inside savePatientRecords Method:  {} {}" + docEntityId + " "
				+ dasboardObj);
		log.info("isRecordExists : {} ", isRecordExists);
		Session session = this.sessionFactory.getCurrentSession();
		try {
			if (isRecordExists) {
				log.debug("Record Exist");
				String hql = "UPDATE PatientMedicalRecords d " + " SET d.documentContent = :documentContent, "
						+ " d.documentSource = :documentSource, "
						+ " d.lastUpdatedTimestamp = :lastUpdatedTimestamp," + " d.eventDatetime = :eventDatetime,"
						+ " d.receivedTimestamp = :receivedTimestamp, " + " d.isDocumentUpdated = 1"
						+ " WHERE d.patientId = :patientId " + " AND d.visitId = :visitId"
						+ " AND d.documentType = :documentType " + " AND d.documentId = :documentId"
						+ " AND d.documentSource = 'IHeal' ";

				Query query = session.createQuery(hql);
				query.setParameter("documentContent", " ");
				query.setParameter("documentSource", docSource);
				query.setParameter("lastUpdatedTimestamp", new Timestamp(System.currentTimeMillis()));
				query.setParameter("eventDatetime", new Timestamp(System.currentTimeMillis()));
				query.setParameter("receivedTimestamp", receivedTimestamp);
				query.setParameter("patientId", dasboardObj.getPatientId());
				query.setParameter("visitId", dasboardObj.getVisitId());
				query.setParameter("documentType", documentType);
				query.setParameter("documentId", patientMedicalRecords.getDocumentId());
				int rowsAffected = query.executeUpdate();

				if (rowsAffected > 0) {
					log.info("PatientMedicalRecords updated successfully with new Document Content");
				} else {
					log.info("No rows were affected while updating the dashboard.");
				}
				
			} else {
				
				log.debug("New Record ");
/*			try{
				
				PatientMedicalRecords pmr = new PatientMedicalRecords();
				pmr.setPatientId(dasboardObj.getPatientId());
				pmr.setVisitId(dasboardObj.getVisitId());
				pmr.setDocumentType(documentType);
				pmr.setDocumentId(docEntityId+"");
				pmr.setDocumentEntityId(docEntityId);
				pmr.setBluebookId(dasboardObj.getBluebookId());
				pmr.setDocumentContent("");
				pmr.setDocumentName(dasboardObj.getVisitId()+"_"+documentType);
				pmr.setDocumentSource(docSource);
				pmr.setEventDatetime(new Timestamp(System.currentTimeMillis()));
				pmr.setFacilityId(dasboardObj.getFacilityId());
				pmr.setIsDocumentUpdated(0);
				pmr.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
				// pmr.setPatientDob();
				pmr.setPatientDos(dasboardObj.getDateOfService());
				pmr.setPatientFullname(dasboardObj.getPatientLastName() + ", "
						+ dasboardObj.getPatientFirstName());
				pmr.setPatientId(dasboardObj.getPatientId());
				pmr.setReceivedTimestamp(receivedTimestamp);

				session.save(pmr);
				log.debug("Saved PatientRecords Method:  {} {}" + docEntityId + " "
						+ dasboardObj);
				}catch(Exception e){
					log.error("Exception in savePatientRecords new record: {} {}" + e.getMessage()
					+" " +dasboardObj);
				}*/
				  try {
				        if (iHealNotificationReq == null) {
				            log.error("iHealNotificationReq is null. Cannot save patient record.");
				            return;
				        }
				 
				        PatientMedicalRecords pmr = new PatientMedicalRecords();
				 
				        Long patientId = (dasboardObj != null && dasboardObj.getPatientId() != null)
				                ? dasboardObj.getPatientId()
				                : parseLongSafe(iHealNotificationReq.getPatientID());
				 
				        Long visitId = (dasboardObj != null && dasboardObj.getVisitId() != 0L)
				                ? dasboardObj.getVisitId()
				                : parseLongSafe(iHealNotificationReq.getVisitID());
				 
				        String bluebookId = (dasboardObj != null && dasboardObj.getBluebookId() != null)
				                ? dasboardObj.getBluebookId()
				                : iHealNotificationReq.getBlueBookId();
				 
				        Integer facilityId = (dasboardObj != null  && dasboardObj.getFacilityId() != 0)
				                ? dasboardObj.getFacilityId()
				                : parseIntSafe(iHealNotificationReq.getFacilityID());
				 
				        String patientLastName = (dasboardObj != null && dasboardObj.getPatientLastName() != null)
				                ? dasboardObj.getPatientLastName()
				                : "Patient Last";
				 
				        String patientFirstName = (dasboardObj != null && dasboardObj.getPatientFirstName() != null)
				                ? dasboardObj.getPatientFirstName()
				                : "Patient First";
				 
				        String fullName = patientLastName + ", " + patientFirstName;
				 
				        String documentName = (visitId == null || visitId == 0L)
				                ? iHealNotificationReq.getVisitID()
				                : visitId + "_" + documentType;
				 
				        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
				 
				        pmr.setPatientId(patientId);
				        pmr.setVisitId(visitId);
				        pmr.setDocumentType(documentType);
				        pmr.setDocumentId(String.valueOf(docEntityId));
				        pmr.setDocumentEntityId(docEntityId);
				        pmr.setBluebookId(bluebookId);
				        pmr.setDocumentContent("");
				        pmr.setDocumentName(documentName);
				        pmr.setDocumentSource(docSource);
				        pmr.setEventDatetime(currentTimestamp);
				        pmr.setFacilityId(facilityId);
				        pmr.setIsDocumentUpdated(0);
				        pmr.setLastUpdatedTimestamp(currentTimestamp);
				        pmr.setPatientDos(dasboardObj != null ? dasboardObj.getDateOfService() : null);
				        pmr.setPatientFullname(fullName);
				        pmr.setReceivedTimestamp(receivedTimestamp);
				 
				        //log values to verify
				        log.debug("Saving PMR: PatientID={}, VisitID={}, DocType={}, DocName={}, FullName={}, FacilityID={}, BluebookID={}",
				                patientId, visitId, documentType, documentName, fullName, facilityId, bluebookId);
				 
				        session.save(pmr);
				 
				        log.debug("Saved PatientRecords: docEntityId={}, dasboardObj={}", docEntityId, dasboardObj);
				 
				    } catch (NullPointerException npe) {
				        log.error("NullPointerException in savePatientRecords: {}", npe.getMessage(), npe);
				    } catch (Exception e) {
				        log.error("Exception in savePatientRecords new record", e);
				    }
				
			}

			// Updating Dashboard Table
			log.debug("Updating Dashboard Table: ");
			
			if (documentType.equalsIgnoreCase("PN")) {
				dasboardObj.setProgNoteSigned(true);
			} else if(documentType.equalsIgnoreCase("HBO")){
				dasboardObj.setHBOSigned(true);
			}
			
			dasboardObj.setLastUpdatedByUserFullName("Encode System");
			dasboardObj.setLastUpdatedByUserId("0");
			dasboardObj.setLastUpdatedByUsername("");
			dasboardObj.setLastUpdatedByTimestamp(
					new Timestamp(System.currentTimeMillis()));
			// Updating Dashboard Table
			log.debug("Updating Dashboard Table:  {}",dasboardObj);
			session.update(dasboardObj);
			
		} catch (Exception e) {
			log.error("Exception in savePatientRecords : {}" + e.getMessage());
		}
		
	}
	
	private Long parseLongSafe(String value) {
	    try {
	        return (value != null && !value.trim().isEmpty()) ? Long.valueOf(value) : null;
	    } catch (NumberFormatException e) {
	        log.warn("Invalid long format: {}", value);
	        return null;
	    }
	}
	
	private Integer parseIntSafe(String value) {
	    try {
	        return (value != null && !value.trim().isEmpty()) ? Integer.valueOf(value) : null;
	    } catch (NumberFormatException e) {
	        log.warn("Invalid int format: {}", value);
	        return null;
	    }
	}
	
	private void saveTimeline(long visitId, String action, String userFullName,
			long userId, String userName,
			String chartDesc, String userRole) {
		log.debug("Inside saveTimeline Method:  {} " + visitId);
		try {
			Dashboard dashObj = dashboardDAO.getRecordByVisitId(visitId);

			if (dashObj != null) {

				String fullName = "";
				if (userFullName != null && !userFullName.isEmpty()) {
					
					if (userFullName.contains(",")) {
						String[] names = userFullName.split(",");

						if (names.length > 1) {
							String lastName = names[0];
							String firstName = names[1];

							if (action != null && action.equalsIgnoreCase("Escalate")) {
								firstName = names[0];
								lastName = names[1];
							}

							fullName = ((firstName != null) ? firstName.trim() : "") + " "
									+ ((lastName != null) ? lastName.trim() : "");

							log.info("fullName : " + fullName);
						}
					} else {
						fullName = userFullName;
					}
				}
  
				HistoryTimelineData timeline = new HistoryTimelineData();
				timeline.setBluebookId(dashObj.getBluebookId());
				timeline.setChartDescription(fullName + "#" + chartDesc);
				timeline.setChartStatus(action);
				timeline.setDateOfService(dashObj.getDateOfService());
				timeline.setFacilityId(dashObj.getFacilityId());
				timeline.setPatientId(dashObj.getPatientId());
				timeline.setPatientName(dashObj.getPatientName());
				timeline.setUserFullName(userFullName);
				timeline.setUserId(userId);
				timeline.setUserRole(userRole);
				timeline.setUserName(userName);
				timeline.setVisitId(visitId);
				log.debug("Saving History Timeline: {}", timeline);
				historyTimelineBO.saveHistoryTimeline(timeline);
			}
		} catch (Exception e) {
			log.error("Exception occured while Saving timeline: {}", e.getMessage());
		}
	}
	
	@Override
	public void saveSuperBillDetails(IHealSuperBillLoadObj superbill,
			String visitID, String facilityID,
			IHealNotificationReq iHealNotificationReq, IHealVisitObject visitObject,
			IHealPatientLoadObj iHealPatientLoadObj, boolean isRowExist, PlaceOfServiceRes placeOfServiceRes) {
		log.debug("Inside saveSuperBillDetails Method:  {} " + visitID + " "
				+ superbill);
		
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		
		String hql = "FROM ChartDetails WHERE patientId = :patientId AND visitId = :visitId";
		Query<ChartDetails> query = session.createQuery(hql, ChartDetails.class);
		query.setParameter("patientId", Long.valueOf(iHealNotificationReq.getPatientID()));
		query.setParameter("visitId", Long.valueOf(visitID));
		ChartDetails existingRecord = query.uniqueResult();
		ObjectMapper objectMapper = new ObjectMapper();
		String actualCPTCode = "";
		try {
			
			DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
			OffsetDateTime offsetDateTime = OffsetDateTime
					.parse(visitObject.getVisitDateTime(), formatter);			
			Date dosDate =Date.from(offsetDateTime.toInstant());
			/*Date admitDate = null;
			if(iHealPatientLoadObj.getAdmissionDate() != null && !iHealPatientLoadObj.getAdmissionDate().isEmpty()) {
				DateTimeFormatter formatter = DateTimeFormatter
						.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
				LocalDateTime localDateTime = LocalDateTime
						.parse(iHealPatientLoadObj.getAdmissionDate(), formatter);
				admitDate = Date.from(localDateTime
						.atZone(ZoneId.systemDefault()).toInstant());
			}*/
			
			String sbillICDCodes = null;
			if(superbill.getCodeDiagnosis() != null && !superbill.getCodeDiagnosis().isEmpty()) {
				try {
					sbillICDCodes = objectMapper.writeValueAsString(superbill.getCodeDiagnosis());
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillICDCodes data JSON: {}" + e.getMessage());
				}
			}
			
			
			String sbillFacilityEM = null;
			if(superbill.getProcedureFacilityEM() != null) {
				try {
					sbillFacilityEM = objectMapper.writeValueAsString(superbill.getProcedureFacilityEM());
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillFacilityEM data JSON: {}" + e.getMessage());
				}
			}
			
			
			String sbillProviderEM = null;
			if(superbill.getProcedureProviderEM() != null) {
				try {
					sbillProviderEM = objectMapper.writeValueAsString(superbill.getProcedureProviderEM());
					actualCPTCode = superbill.getProcedureProviderEM().getCode();
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillProviderEM data JSON: {}" + e.getMessage());
				}
			}
			
			
			String sbillProviderCPTCodes = null;
			if(superbill.getProcedures() != null && !superbill.getProcedures().isEmpty()) {
				try {
					sbillProviderCPTCodes = objectMapper.writeValueAsString(superbill.getProcedures());
				} catch (JsonProcessingException e) {
					log.error("Exception occured while getting sbillProviderCPTCodes data JSON: {}" + e.getMessage());
				}
			}
		 	
			String placeOfServiceString = null;
			FacilityDetails facilityDetails = getFacilityDetails(facilityID);
			if (facilityDetails != null
					&& "Outpatient Hospital".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())
					|| "Office".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {
				if( visitObject.getServiceLineDescription().equalsIgnoreCase("HSP Inpatient Consult")) {
					placeOfServiceString = "HSP Inpatient Consult";
				}
				
				if ("Home Visit".equals(visitObject.getLocationDescription())) {
						PlaceOfServiceDetails posDetails = getPlaceOfService("12");
						if (posDetails != null) {
							placeOfServiceString = posDetails.getPosName();
						}
				}
				if ("19".equals(facilityDetails.getPlaceOfService())) {
					PlaceOfServiceDetails posDetails = getPlaceOfService("19");
					if (posDetails != null) {
						placeOfServiceString = posDetails.getPosName();
					}
				}
				if ("22".equals(facilityDetails.getPlaceOfService())) {
					PlaceOfServiceDetails posDetails = getPlaceOfService("22");
					if (posDetails != null) {
						placeOfServiceString = posDetails.getPosName();
					}
				}

			}

			if (superbill != null && superbill.getPlaceOfServiceCode() != null) {
				// Fetching place of Service from ENC DB
				if ("Skilled Nursing Facility".equalsIgnoreCase(facilityDetails.getCurrentFacilityType())) {
					PlaceOfServiceDetails posDetails = getPlaceOfServiceSNF(superbill.getPlaceOfServiceCode().toString(), "SNF");
					if (posDetails != null) {
						placeOfServiceString = posDetails.getPosName();
					}else{
						posDetails = getPlaceOfService(superbill.getPlaceOfServiceCode().toString());
						if (posDetails != null) {
							placeOfServiceString = posDetails.getPosName();
				 		}
					}
				}
			}
//				else {
//						if (placeOfServiceRes != null && placeOfServiceRes.getResponseCode() != null
//								&& placeOfServiceRes.getResponseCode().equalsIgnoreCase("0")) {
//							if (placeOfServiceRes.getPlaceOfServiceList() != null
//									&& !placeOfServiceRes.getPlaceOfServiceList().isEmpty()) {
//								for (PlaceOfServiceObj posObj : placeOfServiceRes.getPlaceOfServiceList()) {
//									if (posObj.getId().equalsIgnoreCase(superbill.getPlaceOfServiceCode().toString())) {
//										placeOfServiceString = posObj.getPlaceOfService();
//										break;
//									}
//								}
//							}
//						}
//					}
//			}
//					if ("HSP Inpatient Counsult (281_(BBC))".equalsIgnoreCase(placeOfServiceString)) {
//						String bluebookId = getBluebookIdFromDashboard(Long.valueOf(visitID));
//						if (bluebookId != null) {
//							placeOfServiceString = posDetails.getName() + " (281_" + bluebookId + ")";
//						}
//					}
			

			if (existingRecord != null) {
				// Update existing record
				existingRecord.setProviderName(visitObject.getProviderFirstName()+" "+visitObject.getProviderLastName());
				existingRecord.setPlaceOfService(placeOfServiceString);
				existingRecord.setLastUpdatedTimestamp(currentTime);
				existingRecord.setSuperBillfacilityEM(sbillFacilityEM);
				existingRecord.setSuperBillICDCodes(sbillICDCodes);
				existingRecord.setSuperBillProviderCPTCodes(sbillProviderCPTCodes);
				existingRecord.setSuperBillProviderEM(sbillProviderEM);
				existingRecord.setPatientAdmitDate(dosDate);
				existingRecord.setPlaceOfService(placeOfServiceString);
				existingRecord.setCocId(iHealNotificationReq.getCoc2Id());
				existingRecord.setChildBluebookId(iHealNotificationReq.getBlueBookId());
				session.update(existingRecord);
				log.debug("Updated SuperBillDetails Method in Chart Details:  {} {}" + visitID + " "
						+ superbill);
			} else {
				// Insert new record
				
				ChartDetails newRecord = new ChartDetails();
				newRecord.setPatientId(Long.valueOf(iHealNotificationReq.getPatientID()));
				newRecord.setVisitId(Long.valueOf(visitID));
				newRecord.setProviderName(visitObject.getProviderFirstName()+" "+visitObject.getProviderLastName());				
				newRecord.setLastUpdatedTimestamp(currentTime);
				newRecord.setSuperBillfacilityEM(sbillFacilityEM);
				newRecord.setSuperBillICDCodes(sbillICDCodes);
				newRecord.setSuperBillProviderCPTCodes(sbillProviderCPTCodes);
				newRecord.setSuperBillProviderEM(sbillProviderEM);
				newRecord.setPatientAdmitDate(dosDate);
				newRecord.setPlaceOfService(placeOfServiceString);
				newRecord.setCocId(iHealNotificationReq.getCoc2Id());
				newRecord.setChildBluebookId(iHealNotificationReq.getBlueBookId());
				session.save(newRecord);
				log.debug("Saved SuperBillDetails Method in Chart Details:  {} {}" + visitID + " "
						+ superbill);
			}
			
		} catch (Exception e) {
			log.error("Exception occured while Saving SuperBill Load: {}", e.getMessage());
		}
		
	}
	
	private String getBluebookIdFromDashboard(long visitId) {
        Session session = null;
        String bluebookId = null;
 
        try {
            session = sessionFactory.getCurrentSession();
            String hql = "SELECT d.bluebookId FROM Dashboard d WHERE d.visitId = :visitId";
            Query<String> query = session.createQuery(hql, String.class);
            query.setParameter("visitId", visitId);
            bluebookId = query.uniqueResult(); 
 
        } catch (Exception e) {
            log.error("Error fetching bluebookId from Dashboard for visitId: {} {}" + visitId, e);
        }
        return bluebookId;
    }

	
	private PlaceOfServiceDetails getPlaceOfService(String code) {
		Session session = this.sessionFactory.getCurrentSession();
		PlaceOfServiceDetails details = null;
		try {
			log.debug("Checking PlaceOfServiceDetails: "+ code);
			// Check if the record with the given visitId already exists
			String hql = "FROM PlaceOfServiceDetails WHERE code = :code";
			Query query = session.createQuery(hql);
			query.setParameter("code",code);
			details = (PlaceOfServiceDetails) query.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Fetching Place of Service from DB: {}", e.getMessage());
		}
		return details;
	}

	private PlaceOfServiceDetails getPlaceOfServiceSNF(String code, String facilityType) {
		Session session = this.sessionFactory.getCurrentSession();
		PlaceOfServiceDetails details = null;
		try {
			log.debug("Checking PlaceOfServiceDetails: {}"+ code);
			// Check if the record with the given visitId already exists
			String hql = "FROM PlaceOfServiceDetails WHERE code = :code and facilityType = :facilityType";
			Query query = session.createQuery(hql);
			query.setParameter("code",code);
			query.setParameter("facilityType", facilityType);
			details = (PlaceOfServiceDetails) query.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Fetching Place of Service from DB: {}", e.getMessage());
		}
		return details;
	}

	@Override
	public void saveInsuranceCarriers(IHealPatientLoadObj patientObj, String visitId) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			log.debug("Saving Insurance Carriers for visitId: {}", visitId);
			for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
				String hql = "FROM InsuranceCarrier WHERE insuranceDescription = :insuranceName";
				
				Query<InsuranceCarrier> query = session.createQuery(hql);
				query.setParameter("insuranceName", insuranceObj.getInsuranceName());
				List<InsuranceCarrier> existingInsuranceCarrier = query.list();
				
				if (existingInsuranceCarrier.isEmpty()) {

					InsuranceCarrier insuranceCarrier = new InsuranceCarrier();
					insuranceCarrier.setInsuranceDescription(insuranceObj.getInsuranceName());
					// insuranceCarrier.setId(insuranceObj.getInsuranceId());
					insuranceCarrier.setDeleteFlag(false);
					insuranceCarrier.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
					insuranceCarrier.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
					session.save(insuranceCarrier);
					log.debug("Insurance Carrier save Successfully: {}", insuranceCarrier);

				} else {
					for (InsuranceCarrier existingInsuranceCarriers : existingInsuranceCarrier) {
						existingInsuranceCarriers.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
						session.update(existingInsuranceCarrier);
					}

				}

			}
		} catch (Exception e) {
			log.error("Exception occured while Saving Insurance Carrier: {}", e.getMessage());
		}
	}


	@Override
	public Dashboard getDashboardRowIfExist(String visitID) {
		Session session = this.sessionFactory.getCurrentSession();
		Dashboard existingRecord = null;
		try {
			log.debug("Checking Dashbord Record for visitId: "+ visitID);
			// Check if the record with the given visitId already exists
			String hql = "FROM Dashboard WHERE visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId",Long.valueOf(visitID));
			existingRecord = (Dashboard) query.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Fetching Dashboard Record : {}", e.getMessage());
		}
		return existingRecord;
	}
	

	@Override
	public Patient getPatientRowIfExist(String visitID) {
		Session session = this.sessionFactory.getCurrentSession();
		Patient existingRecord = null;
		try {
			log.debug("Checking Patient Record for visitId: "+ visitID);
			// Check if the record with the given visitId already exists
			String hql = "FROM Patient WHERE visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId",Long.valueOf(visitID));
			existingRecord = (Patient) query.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Fetching Patient Record : {}", e.getMessage());
		}
		return existingRecord;
	} 

	@Override
	public void saveSuperbillHistory(IHealNotificationReq iHealNotificationReq, IHealPatientLoadObj iHealPatientLoadObj,
			IHealVisitObject iHealVisitObject) {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		FacilityDetails facilityDetails = getFacilityDetails(iHealNotificationReq. getFacilityID());
		String facilityName = null;
		String bluebookId = null;
		if (facilityDetails != null) {
			facilityName = facilityDetails.getFacilityName();
			bluebookId = facilityDetails.getBluebookId();
		} else {
			facilityName = "";
			bluebookId = "";
		}
		
		// Retrieve status from the dashboard table using visit_id
	    String statusHql = "SELECT d.status FROM Dashboard d WHERE d.visitId = :visitId";
	    log.debug("Executing HQL to fetch status: {}" + statusHql);
	    Query<String> statusQuery = session.createQuery(statusHql, String.class);
	    statusQuery.setParameter("visitId", Long.valueOf(iHealNotificationReq.getVisitID()));
	    String status = statusQuery.uniqueResult();  
	 
	    if (status == null) {
	        status = " ";  
	    }

		String hql = "FROM SuperBillHistory s WHERE s.visitId = :visitId";
		log.debug("Executing HQL: {}" + hql);
		Query<SuperBillHistory> query = session.createQuery(hql, SuperBillHistory.class);
		query.setParameter("visitId", Long.valueOf(iHealNotificationReq.getVisitID()));
		SuperBillHistory existingRecord = query.uniqueResult();
		try {
			if (existingRecord != null) {
				log.debug("Updating exesting superbill record");
				// Update existing record
				existingRecord.setVisitId(Long.valueOf(iHealNotificationReq.getVisitID()));
				DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
				OffsetDateTime offsetDateTime = OffsetDateTime.parse(iHealVisitObject.getVisitDateTime(), formatter);
				Timestamp dosTimestamp = Timestamp.from(offsetDateTime.toInstant());

				existingRecord.setPatientDOS(dosTimestamp);
				existingRecord.setPatientId(Long.valueOf(iHealNotificationReq.getPatientID()));
				existingRecord.setFacilityId(Integer.valueOf(iHealNotificationReq.getFacilityID()));
				existingRecord.setFacilityName(facilityName);
				existingRecord.setBluebookId(bluebookId);
				existingRecord.setPatientFirstName(iHealPatientLoadObj.getPatientFirstName());
				existingRecord.setPatientLastName(iHealPatientLoadObj.getPatientLastName());
				existingRecord.setPatientFullName(
						iHealPatientLoadObj.getPatientLastName() + ", " + iHealPatientLoadObj.getPatientFirstName());

				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
				LocalDateTime localDateTime = LocalDateTime.parse(iHealPatientLoadObj.getPatientDOB(), formatter1);
				Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());

				existingRecord.setPatientDob(date);
				existingRecord.setPatientMrn(iHealPatientLoadObj.getPatientNumber());
//				existingRecord.setStatus("Sent");
				existingRecord.setStatus(status);
				existingRecord.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
//				existingRecord.setClaimSentDate(new Timestamp(System.currentTimeMillis()));
				existingRecord.setLastUpdatedByUser("Encode System");
				if(iHealVisitObject.getProviderId() == 0){
					
					existingRecord.setProviderId(0L);
				}else{
				existingRecord.setProviderId(Long.valueOf(iHealVisitObject.getProviderId()));
				}
				existingRecord.setProviderFirstName(iHealVisitObject.getProviderFirstName());
				existingRecord.setProviderLastName(iHealVisitObject.getProviderLastName());

				session.update(existingRecord);
			} else {

				log.debug("creating new record");
				SuperBillHistory newRecord = new SuperBillHistory();
				newRecord.setVisitId(Long.valueOf(iHealNotificationReq.getVisitID()));
				DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
				OffsetDateTime offsetDateTime = OffsetDateTime.parse(iHealVisitObject.getVisitDateTime(), formatter);
				Timestamp dosTimestamp = Timestamp.from(offsetDateTime.toInstant());

				newRecord.setPatientDOS(dosTimestamp);
				newRecord.setPatientId(Long.valueOf(iHealNotificationReq.getPatientID()));
				newRecord.setFacilityId(Integer.valueOf(iHealNotificationReq.getFacilityID()));
				newRecord.setFacilityName(facilityName);
				newRecord.setBluebookId(bluebookId);
				newRecord.setPatientFirstName(iHealPatientLoadObj.getPatientFirstName());
				newRecord.setPatientLastName(iHealPatientLoadObj.getPatientLastName());
				newRecord.setPatientFullName(
						iHealPatientLoadObj.getPatientLastName() + ", " + iHealPatientLoadObj.getPatientFirstName());

				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
				LocalDateTime localDateTime = LocalDateTime.parse(iHealPatientLoadObj.getPatientDOB(), formatter1);
				Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());

				newRecord.setPatientDob(date);
				newRecord.setPatientMrn(iHealPatientLoadObj.getPatientNumber());
				// newRecord.setStatus(String.valueOf(iHealVisitObject.getVisitStatus()));
//				newRecord.setStatus("Sent");
				newRecord.setStatus(status);
				newRecord.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
				newRecord.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
//				newRecord.setClaimSentDate(new Timestamp(System.currentTimeMillis()));
				newRecord.setLastUpdatedByUser("Encode System");
				if (iHealVisitObject.getProviderId() == 0) {
					newRecord.setProviderId(0L);
				} else {
					newRecord.setProviderId(Long.valueOf(iHealVisitObject.getProviderId()));
				}
				//newRecord.setProviderId(iHealVisitObject.getProviderId());
				newRecord.setProviderFirstName(iHealVisitObject.getProviderFirstName());
				newRecord.setProviderLastName(iHealVisitObject.getProviderLastName());

				session.save(newRecord);
			}

		} catch (Exception e) {
			log.error("Exception occured while Saving SuperBill Load: {}", e.getMessage());
		}

	}

	@Override
	public void saveDataInSuperbillVarianceTable(IHealPatientLoadObj patient, IHealVisitObject visit,
			IHealSuperBillLoadObj superbill, IHealNotificationReq iHealNotificationReq) {
		Session session = this.sessionFactory.getCurrentSession();

		String hql = "FROM SuperbillVariance s WHERE s.visitId = :visitId";
		log.debug("Executing HQL: {}" + hql);
		Query<SuperbillVariance> query = session.createQuery(hql, SuperbillVariance.class);
		query.setParameter("visitId", Long.valueOf(iHealNotificationReq.getVisitID()));
		SuperbillVariance existingRecord = query.uniqueResult();

		// FacilityDetails facilityDetails =
		// getFacilityDetails(iHealNotificationReq. getFacilityID());
		// getSnfLocationBbc

		Dashboard facilityDetails = getSnfLocationBbc(iHealNotificationReq.getFacilityID());
		String facilityName = null;
		String bluebookId = null;
		if (facilityDetails != null) {
			facilityName = facilityDetails.getFacilityAlias();
			bluebookId = facilityDetails.getSnfLocationBBC();
		} else {
			facilityName = "";
			bluebookId = "";
		}
		try {
			if (existingRecord != null) {
				existingRecord.setVisitId(Long.valueOf(iHealNotificationReq.getVisitID()));
				existingRecord.setFacilityId(Integer.valueOf(iHealNotificationReq.getFacilityID()));
				existingRecord.setFacilityName(facilityName);
				existingRecord.setProviderId(visit.getProviderId());
				existingRecord.setBluebookId(bluebookId);
				String providerFullName = visit.getProviderFirstName() + "," + visit.getProviderLastName();
				existingRecord.setProviderName(providerFullName);
				String patientFullName = patient.getPatientFirstName() + "," + patient.getPatientLastName();
				existingRecord.setPatientName(patientFullName);
				ProcedureProviderEMObj obj = superbill.getProcedureProviderEM();
				existingRecord.setPotentialCptCode(obj.getCode());
				session.update(existingRecord);
			} else {

				SuperbillVariance data = new SuperbillVariance();

				data.setVisitId(Long.valueOf(iHealNotificationReq.getVisitID()));
				data.setFacilityId(Integer.valueOf(iHealNotificationReq.getFacilityID()));
				data.setFacilityName(facilityName);
				data.setProviderId(visit.getProviderId());
				data.setBluebookId(bluebookId);
				String providerFullName = visit.getProviderFirstName() + "," + visit.getProviderLastName();
				data.setProviderName(providerFullName);
				String patientFullName = patient.getPatientLastName() + ", " + patient.getPatientFirstName();
				data.setPatientName(patientFullName);
				ProcedureProviderEMObj obj = new ProcedureProviderEMObj();
				data.setPotentialCptCode(obj.getCode());
				DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
				OffsetDateTime offsetDateTime = OffsetDateTime.parse(visit.getVisitDateTime(), formatter);
				Timestamp dosTimestamp = Timestamp.from(offsetDateTime.toInstant());

				data.setDateOfService(dosTimestamp);

				ProcedureProviderEMObj obj1 = superbill.getProcedureProviderEM();
				data.setPotentialCptCode(obj1.getCode());
				session.save(data);
			}

		} catch (Exception e) {
			log.error("Exception occured while Saving SuperBill Load: {}", e.getMessage());
		}
		
	}
	
	@Override
	public List<Notification> fetchNotificationsByvisitId(Long visitId) {
		Session session = this.sessionFactory.getCurrentSession();
		List<Notification> notificationList = null;
	
		try {
			String hql = "From Notification where visitId = :visitId order by notificationId DESC";
			
			log.debug("hql : " +hql);
			
			notificationList = (List<Notification>) session.createQuery(hql)
					.setParameter("visitId", visitId).list();

		} catch (Exception e) {
			log.error("Exception occured in fetchNotificationByvisitId: {}" ,e.getMessage());
		}
		return notificationList;
	}
	
	@Override
	public List<ReloadMetrics> fetchSuperBillReloadMetrics(int size) {
		Session session = this.sessionFactory.getCurrentSession();
		List<ReloadMetrics> reloadVisitList = null;
	
		try {
			String hql = "From ReloadMetrics where superbillStatus = 0";
			
			log.debug("hql : " +hql);
			
			reloadVisitList = (List<ReloadMetrics>) session.createQuery(hql)
					.setMaxResults(size)
					.list();

		} catch (Exception e) {
			log.error("Exception occured in fetchSuperBillReloadMetrics: {}" ,e.getMessage());
		}
		return reloadVisitList;
	}
	
	@Override
	public List<ReloadCoderMetrics> fetchReloadCoderMetrics(int size) {
		Session session = this.sessionFactory.getCurrentSession();
		List<ReloadCoderMetrics> reloadVisitList = null;
	
		try {
			String hql = "From ReloadCoderMetrics where coderStatus = 0";
			
			log.debug("hql : " +hql);
			
			reloadVisitList = (List<ReloadCoderMetrics>) session.createQuery(hql)
					.setMaxResults(size)
					.list();

		} catch (Exception e) {
			log.error("Exception occured in fetchReloadCoderMetrics: {}" ,e.getMessage());
		}
		return reloadVisitList;
	}
	
	@Override
	public List<ReloadCMCMetrics> fetchReloadCmcMetrics(int size) {
		Session session = this.sessionFactory.getCurrentSession();
		List<ReloadCMCMetrics> reloadVisitList = null;
	
		try {
			String hql = "From ReloadCMCMetrics where cmcStatus = 0";
			
			log.debug("hql : " +hql);
			
			reloadVisitList = (List<ReloadCMCMetrics>) session.createQuery(hql)
					.setMaxResults(size)
					.list();

		} catch (Exception e) {
			log.error("Exception occured in fetchReloadCmcMetrics: {}" ,e.getMessage());
		}
		return reloadVisitList;
	}
	
	@Override
	public List<ReloadMetrics> fetchDocumentReloadMetrics(int size) {
		Session session = this.sessionFactory.getCurrentSession();
		List<ReloadMetrics> reloadVisitList = null;
	
		try {
			String hql = "From ReloadMetrics where documentStatus = 0";
			
			log.debug("hql : " +hql);
			
			reloadVisitList = (List<ReloadMetrics>) session.createQuery(hql).list();

		} catch (Exception e) {
			log.error("Exception occured in fetchDocumentReloadMetrics: {}" ,e.getMessage());
		}
		return reloadVisitList;
	}
	
	@Override
	public void updateReloadMetrics(ReloadMetrics metrics) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			session.update(metrics);
			
		} catch (Exception e) {
			log.error("Exception occured in updateReloadMetrics: {}" ,e.getMessage());
		}
	}
	
	@Override
	public void updateReloadCoderMetrics(ReloadCoderMetrics metrics) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			session.update(metrics);
			
		} catch (Exception e) {
			log.error("Exception occured in updateReloadCoderMetrics: {}" ,e.getMessage());
		}
	}
	
	@Override
	public void updateReloadCmcMetrics(ReloadCMCMetrics metrics) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			session.update(metrics);
			
		} catch (Exception e) {
			log.error("Exception occured in updateReloadCmcMetrics: {}" ,e.getMessage());
		}
	}
 	 
	@Override
	public APIResponse reloadPatientInsurance(ReloadPatientInsuranceReq req) {
	    Session session = this.sessionFactory.getCurrentSession();
	    APIResponse response = new APIResponse();
	    IHealPatientReloadReq patientReloadReq = new IHealPatientReloadReq();
	    try {
	        //Fetch records from reload_insurance table
	        String hql = "FROM ReloadInsurance ri";
	        Query<ReloadInsurance> query = session.createQuery(hql, ReloadInsurance.class);
	        
	        query.setFirstResult(req.getOffset());
	        query.setMaxResults(req.getLimit());
	        
	        log.info("Executing query: {} with offset: {} and limit: {}", hql, req.getOffset(), req.getLimit());
	      
	        // query.setParameter("status", "PENDING");  
	        List<ReloadInsurance> reloadInsurances = query.list();
	        
	        log.info("reloadInsurances : {} ", reloadInsurances);
	 
	        //Loop through the fetched reloadInsurances 
	        for (ReloadInsurance reloadInsurance : reloadInsurances) {
	            
	            String patientId = reloadInsurance.getPatientId();
	            String facilityId = reloadInsurance.getFacilityId();
	           // String bluebookId = reloadInsurance.getBluebookId();
	      
	            long visitId = reloadInsurance.getVisitId();
	 
	            //Check if visitId already exists in patient_insurance table
	            boolean exists = checkIfVisitIdExists(visitId);
	            if (exists) {
	                //If exists, skip processing and mark the status as "SUCCESS"
	                reloadInsurance.setStatus("Skipped");
	                reloadInsurance.setErrorCode(0);
	                reloadInsurance.setErrorMessage("Visit ID already exists in patient insurance table");
	                session.update(reloadInsurance);
	                continue;
	            }
	 
	            //Otherwise, we return patient id and facility id to BO layer for further processing
	            patientReloadReq.setVisitId(visitId);
	            patientReloadReq.setFacilityId(facilityId);
	            
 	            IHealPatientLoadReq patientLoadReq = new IHealPatientLoadReq();
	        	
	        	patientLoadReq.setFacilityId(facilityId);
	        	patientLoadReq.setPatientId(patientId);
	        	
	            //IHealPatientLoadRes patientLoadRes = getPatientLoad(patientLoadReq);
	        	
	        	  try {
	                  // Fetch patient load data
	                  IHealPatientLoadRes patientLoadRes = getPatientLoad(patientLoadReq);
	                  if (!patientLoadRes.getErrorCode().equalsIgnoreCase("0")) {
	                      
	                      reloadInsurance.setStatus("Skipped");
	                      reloadInsurance.setErrorCode(1);
	                      reloadInsurance.setErrorMessage("Error from iHeal: " + patientLoadRes.getErrorMessage() + patientLoadRes.getErrorCode());
	                      session.update(reloadInsurance);
	                      continue;
	                  }
	   
	                  // Proceed with inserting patient insurance data if no error
	                  insertPatientInsuranceData(patientLoadRes, patientReloadReq);
	              } catch (Exception e) {
	                 
	                  reloadInsurance.setStatus("Skipped");
	                  reloadInsurance.setErrorCode(1);
	                  reloadInsurance.setErrorMessage("Exception occurred in iHeal Patient Load: " + e.getMessage());
	                  session.update(reloadInsurance);
	                  continue;
	              }
	   
	            
	          //  insertPatientInsuranceData(patientLoadRes, patientReloadReq);
	            

	            response.setResponseCode("0");
	            response.setResponseMessage("Success");
	                      
	        }     
	 
	    } catch (Exception e) {
	        log.error("Exception occurred in reloadPatientInsurance: {}", e.getMessage());
	        response.setResponseCode("500");
	        response.setResponseMessage("Internal Server Error");
	
	    }
	 
	    return response;
	}
	 
	private boolean checkIfVisitIdExists(long visitId) {
	    // Check if the visitId is present in patient_insurance table
	    String hql = "SELECT count(1) FROM PatientInsurance pi WHERE pi.visitId = :visitId";
	    Session session = this.sessionFactory.getCurrentSession();
	    Query<Long> query = session.createQuery(hql, Long.class);
	    query.setParameter("visitId", visitId);
	    long count = query.uniqueResult();
	    return count > 0;
	}
	 
	private void insertPatientInsuranceData(IHealPatientLoadRes patientLoadRes, IHealPatientReloadReq patientReloadReq){
	    Session session = this.sessionFactory.getCurrentSession();
	    IHealPatientLoadObj patientObj = patientLoadRes.getPatient();
	    log.info("Inside insertPatientInsuranceData method : {} ", patientReloadReq);
	    log.info("patientObj : {} ",patientObj);
	    log.info("patientObj Insurance : {} ", patientObj.getInsurance());
	    try{
	    	
	    	// Fetch the patient data (to get the bluebookId)
	        Patient patient = session.get(Patient.class, patientReloadReq.getVisitId());
	        String bluebookId = null;
	        if (patient != null) {
	            bluebookId = patient.getBluebookId();
	            
	            log.debug("Fetched bluebookId: {}", bluebookId);
	        } else {
	            log.error("No Patient found for visitId: {}", patientReloadReq.getVisitId());
	        }
	        
	     // If bluebookId is null, update ReloadInsurance and return without saving PatientInsurance
	        if (bluebookId == null) {
	           
	            if (patientReloadReq.getVisitId() != null) {

	                ReloadInsurance reloadInsurance = session.get(ReloadInsurance.class, patientReloadReq.getVisitId());
	                if (reloadInsurance != null) {
	                    reloadInsurance.setStatus("Failed");
	                    reloadInsurance.setErrorCode(1);
	                    reloadInsurance.setErrorMessage("Bluebook ID is null");
	                    log.debug("Updating ReloadInsurance Obj with failure: {}", reloadInsurance);
	                    session.update(reloadInsurance); 
	                } else {
	                    log.error("No ReloadInsurance found for visitId: {}", patientReloadReq.getVisitId());
	                }
	            }
	            return; 
	        }
	        
	       
	        // Save new PatientInsurance entities
	        if (patientObj.getInsurance() != null && !patientObj.getInsurance().isEmpty()) {
	            for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
	                if (insuranceObj != null) { 
	                    log.debug("Processing Insurance: {}", insuranceObj);
	                    Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	                    PatientInsurance patientInsurance = new PatientInsurance();
	                    patientInsurance.setVisitId(Long.valueOf(patientReloadReq.getVisitId()));
	                    patientInsurance.setPatientId(patientObj.getPatientId());
	                    patientInsurance.setFamilyName(patientObj.getPatientLastName());
	                    patientInsurance.setGivenName(patientObj.getPatientFirstName());
	                    patientInsurance.setFacilityId(patientReloadReq.getFacilityId());
	                    patientInsurance.setBluebookId(bluebookId);
	                    patientInsurance.setInsuranceId(String.valueOf(insuranceObj.getInsuranceId()));
	                    patientInsurance.setInsuranceName(insuranceObj.getInsuranceName());
	                    patientInsurance.setStreetAddress(insuranceObj.getAddress1());
	                    patientInsurance.setOtherDesignation(insuranceObj.getAddress2());
	                    patientInsurance.setPriority(String.valueOf(insuranceObj.getSequence()));
	                    patientInsurance.setCity(insuranceObj.getCity());
	                    patientInsurance.setState(insuranceObj.getState());
	                    patientInsurance.setZip(insuranceObj.getZip());
	                    if (insuranceObj.getInsured() != null) {
	                        IHealInsuredObj insuredObj = insuranceObj.getInsured();
	                        patientInsurance.setInsuredFamilyName(insuredObj.getLastName());
	                        patientInsurance.setInsuredGivenName(insuredObj.getFirstName());
	                        patientInsurance.setInsuredRelation(insuredObj.getRelationship());
	                        patientInsurance.setInsuredDOB(insuranceObj.getInsuredDOB());
	                    }
	                    patientInsurance.setPolicyNumber(insuranceObj.getPolicyNumber());
	                    patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
	                    log.debug("Saving PatientInsurance Obj: {}", patientInsurance);
	                    session.save(patientInsurance);
	                }
	            }
	        }
	 
	        // After saving PatientInsurance, update the ReloadInsurance record
	        if (patientReloadReq.getVisitId() != null) {
	            ReloadInsurance reloadInsurance = session.get(ReloadInsurance.class, Integer.valueOf(patientReloadReq.getVisitId().intValue()));
	            if (reloadInsurance != null) {
	                reloadInsurance.setStatus("Completed"); 
	                reloadInsurance.setErrorCode(0); 
	                reloadInsurance.setErrorMessage("Success"); 
	                log.debug("Updating ReloadInsurance Obj: {}", reloadInsurance);
	                session.update(reloadInsurance); 
	            } else {
	                log.error("No ReloadInsurance found for visitId: {}", patientReloadReq.getVisitId());
	            }
	        }
	    } catch (Exception e){
	        log.error("Exception occurred in insertPatientInsuranceData: {}", e.getMessage());
	    }
	}
	
	private IHealPatientLoadRes getPatientLoad(
			IHealPatientLoadReq patientSearchReq) {
		IHealPatientLoadRes ihealVisitLoadRes = null;
		patientSearchReq.setUserId(env
				.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_USERID));
		patientSearchReq
				.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
		patientSearchReq.setFacilityId(patientSearchReq.getFacilityId());
		patientSearchReq.setMasterToken(env.getProperty(
				BOConstants.NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN));
		patientSearchReq.setPatientId(patientSearchReq.getPatientId());
		String url = env.getProperty(BOConstants.IHEAL_PATIENT_LOAD_URL);

		try {
			log.info("IHeal Patient Load URL post started");
			HttpEntity<Object> request = new HttpEntity<>(patientSearchReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealPatientLoadRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealPatientLoadRes.class);
			log.info("IHeal Patient Load URL post Completed");
			log.debug("iHeal Patient Load Response : {}", sresponse.getBody());
			ihealVisitLoadRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in iHealPatientLOAD - ",
					e);
			ihealVisitLoadRes = new IHealPatientLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealVisitLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealVisitLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in iHealPatientLOAD: ",
					e);
			ihealVisitLoadRes = new IHealPatientLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealVisitLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealVisitLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealVisitLoadRes;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}
	
	private UserFacilityRes getUserFacilities(String userId, String masterToken) {
		IHealUserFacilityListGetRes facilitiesResponse = null;

		String url = env.getProperty(BOConstants.IHEAL_USERFACILITIES_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		IhealFacilityListGetReq user = new IhealFacilityListGetReq();
		user.setMasterToken(masterToken);
		user.setUserId(userId);
		user.setPrivateKey(privateKey);
		UserFacilityRes userFacilityRes = new UserFacilityRes();
		try {
			log.info("IHeal userfacility URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(user, getHeaders());

			assert url != null;
			ResponseEntity<IHealUserFacilityListGetRes> sresponse = restTemplate.exchange(url, HttpMethod.POST, request,
					IHealUserFacilityListGetRes.class);
			facilitiesResponse = sresponse.getBody();
			//log.debug("SettingsV2:  " + sresponse.getBody().getFacilities().get(0).getSettingsV2());
			//log.debug("iHeal facilitiesResponse : " + facilitiesResponse);
		} catch (HttpClientErrorException e) {
			log.error(String.format("HttpClientErrorException occurred in getUserFacilities: %s", e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(String.format("HttpStatusCodeException occurred in getUserFacilities: %s", e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		if (facilitiesResponse != null && facilitiesResponse.getErrorCode() != null
				&& facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			List<UserFacilities> facilities = new ArrayList<>();
			for (IhealFacility facility : facilitiesResponse.getFacilities()) {
				UserFacilities fac = new UserFacilities();
				fac.setFacilityId(facility.getFacilityId());
				fac.setFacilityBluebookId(facility.getFacilityBluebookId());
				fac.setFacilityName(facility.getFacilityName());
				fac.setConfiguration(facility.getConfiguration());
				fac.setSettings(facility.getSettings());
				fac.setSettingsV2(facility.getSettingsV2());
				facilities.add(fac);
			}
			userFacilityRes.setFacilities(facilities);

			userFacilityRes.setResponseCode("0");
			userFacilityRes.setResponseDesc("Success");
		} else if (facilitiesResponse != null && facilitiesResponse.getErrorCode() != null
				&& !facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			userFacilityRes.setResponseCode(facilitiesResponse.getErrorCode());
			userFacilityRes.setResponseDesc(facilitiesResponse.getErrorMessage());
		}
		//log.debug("UserFacilityRes:  {}", userFacilityRes);
		return userFacilityRes;
	}
	
	@Override
	public APIResponse reloadPatient(ReloadPatientInsuranceReq req) {

	    Session session = this.sessionFactory.getCurrentSession();
	    APIResponse response = new APIResponse();
	    IHealPatientReloadReq patientReloadReq = new IHealPatientReloadReq();
	 
	    try {
	    	Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	        // Fetch records from reload_insurance table
	        String hql = "FROM PatientReload rp";

	        Query<PatientReload> query = session.createQuery(hql, PatientReload.class);
	        query.setFirstResult(req.getOffset());
	        query.setMaxResults(req.getLimit());

	        log.info("Executing query: {} with offset: {} and limit: {}", hql, req.getOffset(), req.getLimit());
	 
	        List<PatientReload> reloadPatients = query.list();

	        log.info("reloadPatient : {} ", reloadPatients);
	 
	        // Loop through the fetched reloadInsurances
	        for (PatientReload reloadPatient : reloadPatients) {
	        	Integer patientId = reloadPatient.getPatientId();
	            Integer facilityId = reloadPatient.getFacilityId();
	            long visitId = reloadPatient.getVisitId();
	 
	            // Check if visitId already exists in patient table
	            boolean exists = checkIfVisitIdExistsInPatient(visitId);
	 
	            if (exists) {

	                // If exists, skip processing and mark the status as "SUCCESS"
	                reloadPatient.setStatus("Skipped");
	                reloadPatient.setErrorCode(0);
	                reloadPatient.setErrorMessage("Visit ID already exists in patient table");
	                reloadPatient.setLastUpdatedTimestamp(currentTimestamp);
	                session.update(reloadPatient);
	                continue;

	            }
	 
	            // Otherwise, we return patient id and facility id to BO layer for further processing
	            patientReloadReq.setVisitId(visitId);
	            patientReloadReq.setFacilityId(String.valueOf(facilityId));
	            patientReloadReq.setPatientId(String.valueOf(patientId));
	 
	            IHealPatientLoadReq patientLoadReq = new IHealPatientLoadReq();

	            patientLoadReq.setFacilityId(String.valueOf(facilityId));
	            patientLoadReq.setPatientId(String.valueOf(patientId));
	 
	            IHealGetVisitsReq visitLoadReq = new IHealGetVisitsReq();

	            visitLoadReq.setFacilityId(String.valueOf(facilityId));
	            visitLoadReq.setPatientId(String.valueOf(patientId));
	            visitLoadReq.setVisitId(String.valueOf(visitId));
	            
	        	log.debug("Calling SuperBill Load API:  ");
				IHealSuperBillLoadReq iHealSuperBillLoadReq = new IHealSuperBillLoadReq();
				
				iHealSuperBillLoadReq.setFacilityId(String.valueOf(facilityId));
				iHealSuperBillLoadReq.setPatientId(String.valueOf(patientId));
				
				String hql1 = "FROM Notification n WHERE n.visitId = :visitId ORDER BY n.eventDateTime DESC";
				Query<Notification> query1 = session.createQuery(hql1, Notification.class);
				query1.setParameter("visitId", visitId);
				query1.setMaxResults(1); 
				List<Notification> notifications = query1.list();
				 
				if (!notifications.isEmpty()) {
				    Notification latestNotification = notifications.get(0);
				    String documentEntityId = latestNotification.getDocumentId();
				    log.info("Document Entity Id : {} ",documentEntityId);
				    iHealSuperBillLoadReq.setDocumentEntityId(documentEntityId);
				}
				
	 
	            try {

	                // Fetch patient load data
	                IHealVisitLoadRes visitLoadRes = getVisits(visitLoadReq);
	                IHealPatientLoadRes patientLoadRes = getPatientLoad(patientLoadReq);
	                IHealSuperBillLoadRes superBillLoadRes = getSuperBillLoadIHeal(iHealSuperBillLoadReq);
	 
	                if (!visitLoadRes.getErrorCode().equalsIgnoreCase("0") && !patientLoadRes.getErrorCode().equalsIgnoreCase("0") &&
	                		!superBillLoadRes.getErrorCode().equalsIgnoreCase("0")) {

	                    reloadPatient.setStatus("Failed");
	                    reloadPatient.setErrorCode(1);
	                    reloadPatient.setErrorMessage("Error from iHeal: " + visitLoadRes.getErrorMessage() + visitLoadRes.getErrorCode());
	                    reloadPatient.setLastUpdatedTimestamp(currentTimestamp);
	                    session.update(reloadPatient);
	                    continue;

	                }
	 
	                // If insertPatientData is successful, insert patient insurance data
	                insertPatientData(visitLoadRes, patientLoadRes, patientReloadReq,superBillLoadRes);
	 
	                // Now, insert patient insurance data if no issues
	                try {

	                    IHealPatientLoadRes insuranceLoadRes = getPatientLoad(patientLoadReq);

	                    if (!insuranceLoadRes.getErrorCode().equalsIgnoreCase("0")) {
	                        reloadPatient.setStatus("Failed");
	                        reloadPatient.setErrorCode(1);
	                        reloadPatient.setErrorMessage("Error from iHeal: " + insuranceLoadRes.getErrorMessage() + insuranceLoadRes.getErrorCode());
	                        reloadPatient.setLastUpdatedTimestamp(currentTimestamp);
	                        session.update(reloadPatient);
	                        continue;

	                    }
	 
	                    // Proceed with inserting patient insurance data if no error
	                    insertPatientInsurance(insuranceLoadRes, patientReloadReq);

	                    reloadPatient.setStatus("Success");
	                    reloadPatient.setErrorCode(0);
	                    reloadPatient.setErrorMessage("Patient and Insurance data inserted successfully.");
	                    reloadPatient.setLastUpdatedTimestamp(currentTimestamp);
	                    session.update(reloadPatient);
	 
	                } catch (Exception e) {

	                    reloadPatient.setStatus("Failed Inserting Insurance");
	                    reloadPatient.setErrorCode(1);
	                    reloadPatient.setErrorMessage("Exception occurred in iHeal Patient Insurance Load: " + e.getMessage());
	                    reloadPatient.setLastUpdatedTimestamp(currentTimestamp);
	                    session.update(reloadPatient);
	                    continue;

	                }
	 
	            } catch (Exception e) {

	                reloadPatient.setStatus("Failed Inserting Patient");
	                reloadPatient.setErrorCode(1);
	                reloadPatient.setErrorMessage("Exception occurred in iHeal Patient Load: " + e.getMessage());
	                reloadPatient.setLastUpdatedTimestamp(currentTimestamp);
	                session.update(reloadPatient);
	                continue;

	            }

	        }
	 
	        response.setResponseCode("0");
	        response.setResponseMessage("Success");
	 
	    } catch (Exception e) {

	        log.error("Exception occurred in reloadPatient: {}", e.getMessage());
	        response.setResponseCode("500");
	        response.setResponseMessage("Internal Server Error");

	    }
	 
	    return response;

	}
	
private IHealSuperBillLoadRes getSuperBillLoadIHeal(IHealSuperBillLoadReq superBillLoadReq) {
		
		IHealSuperBillLoadRes iHealSuperBillLoadRes = null;
		superBillLoadReq.setUserId(env
				.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_USERID));
		superBillLoadReq
				.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
		superBillLoadReq.setFacilityId(superBillLoadReq.getFacilityId());
		superBillLoadReq.setMasterToken(env.getProperty(
				BOConstants.NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN));
		superBillLoadReq.setPatientId(superBillLoadReq.getPatientId());
		superBillLoadReq.setDocumentEntityId(superBillLoadReq.getDocumentEntityId());

		String url = env.getProperty(BOConstants.IHEAL_SUPERBILL_LOAD_URL);

		try {
			log.info("IHeal SuperBill Load URL post started");
			HttpEntity<Object> request = new HttpEntity<>(superBillLoadReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealSuperBillLoadRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealSuperBillLoadRes.class);
			log.info("IHeal SuperBill Load URL post Completed");
			log.debug("iHeal SuperBill Load Response : {}", sresponse.getBody());
			iHealSuperBillLoadRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in ihealSuperBillLoad - ",
					e);
			iHealSuperBillLoadRes = new IHealSuperBillLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			iHealSuperBillLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			iHealSuperBillLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in ihealSuperBillLoad: ",
					e);
			iHealSuperBillLoadRes = new IHealSuperBillLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			iHealSuperBillLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			iHealSuperBillLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return iHealSuperBillLoadRes;
	}

	 
	
	private void insertPatientData(IHealVisitLoadRes visitLoadRes, IHealPatientLoadRes patientLoadRes,
			IHealPatientReloadReq patientReloadReq, IHealSuperBillLoadRes superBillLoadRes) {

		Session session = this.sessionFactory.getCurrentSession();
		IHealPatientLoadObj patientObj = patientLoadRes.getPatient();
		IHealVisitObject visitObj = visitLoadRes.getVisit();
		IHealSuperBillLoadObj superbill = superBillLoadRes.getSuperbill();
		log.info("Inside insertPatientData method");
		log.info("patientObj : {} ", patientObj);
		log.info("visitObj : {} ", visitObj);
		log.info("superbill : {} ", superbill);

		try {

			// Check if the patient already exists in the database
			String hqlPatient = "FROM Patient WHERE visitId = :visitId";
			Patient patient = session.createQuery(hqlPatient, Patient.class)
					.setParameter("visitId", patientReloadReq.getVisitId())
					.setMaxResults(1).uniqueResult();

			// If the patient doesn't exist, create a new Patient

			if (patient == null) {
				patient = new Patient();
				log.info("Patient not found. Creating new patient.");
			}

			// Convert DOB to Date

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
			LocalDateTime localDateTime = LocalDateTime.parse(patientObj.getPatientDOB(), formatter);
			Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
			
		     String hql = "From Dashboard where visitId = :visitId ";
			 Dashboard dashboard = session.createQuery(hql, Dashboard.class)
									.setParameter("visitId", patientReloadReq.getVisitId())
									.setMaxResults(1).uniqueResult();


			// Update Patient details
			Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
			patient.setGivenName(patientObj.getPatientFirstName());
			patient.setFamilyName(patientObj.getPatientLastName());
			patient.setPatientGender(patientObj.getPatientSex());
			patient.setDateOfBirth(date);
			patient.setStreetAddress(patientObj.getAddress1());
			patient.setCity(patientObj.getCity());
			patient.setState(patientObj.getState());
			patient.setZipCode(patientObj.getZip());
			patient.setLocationDescription(patientObj.getLocationDescription());
			patient.setPhone1(patientObj.getPhone1());
			patient.setPhone2(patientObj.getPhone2());
			patient.setEmailId(patientObj.getEmail());
			patient.setVisitId(patientReloadReq.getVisitId());
			patient.setPatientId(patientReloadReq.getPatientId());
		    int facilityIdInt = Integer.parseInt(patientReloadReq.getFacilityId());
			patient.setFacilityId(facilityIdInt);
			patient.setBluebookId(dashboard.getBluebookId());

			// Set Guarantor details if available
			if (patientObj.getGuarantor() != null) {
				IHealGuarantorObj guarantor = patientObj.getGuarantor();
				patient.setGuarantorGivenName(guarantor.getFirstName());
				patient.setGuarantorFamilyName(guarantor.getLastName());
				patient.setGuarantorStreetAddress(guarantor.getAddress1());
				patient.setGuarantorCity(guarantor.getCity());
				patient.setGuarantorState(guarantor.getState());
				patient.setGuarantorZip(guarantor.getZip());
				patient.setGuarantorRelation(guarantor.getRelationship());
			}

			log.debug("Updated PatientDetails Patient Obj: {} ", patient);

			// Query the ChartDetails table to get placeOfService for the given visitId
			String hqlChartDetails = "FROM ChartDetails WHERE visitId = :visitId";
			ChartDetails chartDetails = session.createQuery(hqlChartDetails, ChartDetails.class)
		                                       .setParameter("visitId", patientReloadReq.getVisitId())
			                                   .setMaxResults(1)
			                                    .uniqueResult();
			 
			// Set the blueBookIDPOS based on the placeOfService retrieved from ChartDetails
			String blueBookIDPOS = null;
		 
			// Check if placeOfService is available and not empty
			if (chartDetails != null && chartDetails.getPlaceOfService() != null && !chartDetails.getPlaceOfService().isEmpty()) {
			    String placeOfService = chartDetails.getPlaceOfService();
			    String posCode = extractPOSCode(placeOfService);			
			    if (posCode != null) {
			        // If POS code is found, append it with snfLocationBBC
			        blueBookIDPOS = posCode + (dashboard != null ? dashboard.getSnfLocationBBC() : "");
			    } else {
			        // If POS code is not found, fallback to snfLocationBBC
			        blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");
			    }
			} else {
			    // If placeOfService is null or empty, fallback to snfLocationBBC
			    blueBookIDPOS = (dashboard != null ? dashboard.getSnfLocationBBC() : "");
			}
			 
			    // Set the blueBookId for the patient
			    patient.setBluebookId(blueBookIDPOS);
			    FacilityDetails facilityDetails  = getFacilityDetails(patientReloadReq.getFacilityId());

				patient.setFacilityName(facilityDetails.getFacilityName());
				patient.setPointOfCare(facilityDetails.getFacilityName());
				patient.setBed(blueBookIDPOS);
				patient.setFloor(facilityDetails.getFacilityName());
				patient.setBirthPlace(blueBookIDPOS);

			// Set Attending Doctor details
			patient.setAttendingDocId(String.valueOf(visitObj.getProviderId()));
			patient.setAttendingDocName(visitObj.getProviderFirstName() + " " + visitObj.getProviderLastName());
			patient.setAdmittingDocId(String.valueOf(visitObj.getProviderId()));
			patient.setAdmittingDocFamilyName(visitObj.getProviderLastName());
			patient.setAdmittingDocGivenName(visitObj.getProviderFirstName());
			patient.setLastUpdatedTimestamp(currentTimestamp);

			// Save or Update the patient record
			session.saveOrUpdate(patient);

			log.debug("Saved/Updated Patient: {} {}", patient.getVisitId(), patient);

		} catch (Exception e) {
			log.error("Exception occurred in insertPatientData: {}", e.getMessage());
		}

	}

	private String extractPOSCode(String placeOfService) {
		// Regular expression to extract a number inside parentheses like (POS 19)
		Pattern pattern = Pattern.compile("\\(POS\\s*(\\d+)\\)");
		Matcher matcher = pattern.matcher(placeOfService);

		if (matcher.find()) {
			return matcher.group(1); // Return the number part inside the parentheses
		}
		return null; // Return null if no valid POS code is found
	}
 
	private boolean checkIfVisitIdExistsInPatient(long visitId) {
	    // Check if the visitId is present in patient table
	    String hql = "SELECT count(1) FROM Patient p WHERE p.visitId = :visitId";
	    Session session = this.sessionFactory.getCurrentSession();
	    Query<Long> query = session.createQuery(hql, Long.class);
	    query.setParameter("visitId", visitId);
	    long count = query.uniqueResult();
	    return count > 0;
	}

	private IHealVisitLoadRes getVisits(IHealGetVisitsReq searchReq) {
		IHealVisitLoadRes ihealVisitLoadRes = null;
		searchReq.setUserId(env
				.getProperty(BOConstants.NETHEALTH_SUPERBILL_SERVICE_USERID));
		searchReq.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
		searchReq.setFacilityId(searchReq.getFacilityId());
		searchReq.setVisitId(searchReq.getVisitId());
		searchReq.setPatientId(searchReq.getPatientId());
		searchReq.setMasterToken(env.getProperty(
				BOConstants.NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN));

		String url = env.getProperty(BOConstants.IHEAL_VISIT_LOAD_URL);

		try {
			log.info("IHeal Visit Load URL post started");
			HttpEntity<Object> request = new HttpEntity<>(searchReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealVisitLoadRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealVisitLoadRes.class);
			log.info("IHeal Visit Load URL post Completed");
			log.debug("iHeal Visit Load Response : {}", sresponse.getBody());
			ihealVisitLoadRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in iHealVISITLOAD - ",
					e);
			ihealVisitLoadRes = new IHealVisitLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealVisitLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealVisitLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in iHealVISITLOAD: ",
					e);
			ihealVisitLoadRes = new IHealVisitLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealVisitLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealVisitLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealVisitLoadRes;
	}
	
	private void insertPatientInsurance(IHealPatientLoadRes patientLoadRes, IHealPatientReloadReq patientReloadReq){
	    Session session = this.sessionFactory.getCurrentSession();
	    IHealPatientLoadObj patientObj = patientLoadRes.getPatient();
	    log.info("Inside insertPatientInsuranceData method : {} ", patientReloadReq);
	    log.info("patientObj : {} ",patientObj);
	    log.info("patientObj Insurance : {} ", patientObj.getInsurance());
	    try{
	    	  Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	    	// Fetch the patient data (to get the bluebookId)
	        Patient patient = session.get(Patient.class, patientReloadReq.getVisitId());
	        String bluebookId = null;
	        if (patient != null) {
	            bluebookId = patient.getBluebookId();
	            
	            log.debug("Fetched bluebookId: {}", bluebookId);
	        } else {
	            log.error("No Patient found for visitId: {}", patientReloadReq.getVisitId());
	        }
	        
	     // If bluebookId is null, update ReloadInsurance and return without saving PatientInsurance
	        if (bluebookId == null) {          
	            if (patientReloadReq.getVisitId() != null) {
	            	Integer visitId = patientReloadReq.getVisitId().intValue();
	                PatientReload reloadInsurance = session.get(PatientReload.class, visitId);
	                if (reloadInsurance != null) {
	                    reloadInsurance.setStatus("Failed");
	                    reloadInsurance.setErrorCode(1);
	                    reloadInsurance.setErrorMessage("Bluebook ID is null");
	                    reloadInsurance.setLastUpdatedTimestamp(currentTimestamp);
	                    log.debug("Updating ReloadInsurance Obj with failure: {}", reloadInsurance);
	                    session.update(reloadInsurance); 
	                } else {
	                    log.error("No ReloadInsurance found for visitId: {}", patientReloadReq.getVisitId());
	                }
	            }
	            return; 
	        }
	        
	        if(patientObj.getInsurance() == null && patientObj.getInsurance().isEmpty()){
	        	Integer visitId = patientReloadReq.getVisitId().intValue();
	        	PatientReload reloadInsurance = session.get(PatientReload.class, visitId);
	            if (reloadInsurance != null) {
	                reloadInsurance.setStatus("Success - Insurance is null"); 
	                reloadInsurance.setErrorCode(0); 
	                reloadInsurance.setErrorMessage("Success - Insurance is null"); 
	                reloadInsurance.setLastUpdatedTimestamp(currentTimestamp);
	                log.debug("Updating ReloadInsurance Obj: {}", reloadInsurance);
	                session.update(reloadInsurance); 
	            } else {
	                log.error("Insurance is null for visitId: {}", patientReloadReq.getVisitId());
	            }
	        }
	        
	        String hqlDelete = "DELETE FROM PatientInsurance WHERE visitId = :visitId";
			Query query = session.createQuery(hqlDelete);
			query.setParameter("visitId", patientReloadReq.getVisitId());
			int deletedCount = query.executeUpdate();
			log.debug("Deleted {} PatientInsurance records with visitId {} {}", deletedCount, patientReloadReq.getVisitId());
	       
	        // Save new PatientInsurance entities
	        if (patientObj.getInsurance() != null && !patientObj.getInsurance().isEmpty()) {
	            for (IHealInsuranceObj insuranceObj : patientObj.getInsurance()) {
	                if (insuranceObj != null) { 
	                    log.debug("Processing Insurance: {}", insuranceObj);
	                    //Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	                    PatientInsurance patientInsurance = new PatientInsurance();
	                    patientInsurance.setVisitId(Long.valueOf(patientReloadReq.getVisitId()));
	                    patientInsurance.setPatientId(patientObj.getPatientId());
	                    patientInsurance.setFamilyName(patientObj.getPatientLastName());
	                    patientInsurance.setGivenName(patientObj.getPatientFirstName());
	                    patientInsurance.setFacilityId(patientReloadReq.getFacilityId());
	                    patientInsurance.setBluebookId(bluebookId);
	                    patientInsurance.setInsuranceId(String.valueOf(insuranceObj.getInsuranceId()));
	                    patientInsurance.setInsuranceName(insuranceObj.getInsuranceName());
	                    patientInsurance.setStreetAddress(insuranceObj.getAddress1());
	                    patientInsurance.setOtherDesignation(insuranceObj.getAddress2());
	                    patientInsurance.setPriority(String.valueOf(insuranceObj.getSequence()));
	                    patientInsurance.setCity(insuranceObj.getCity());
	                    patientInsurance.setState(insuranceObj.getState());
	                    patientInsurance.setZip(insuranceObj.getZip());
	                    if (insuranceObj.getInsured() != null) {
	                        IHealInsuredObj insuredObj = insuranceObj.getInsured();
	                        patientInsurance.setInsuredFamilyName(insuredObj.getLastName());
	                        patientInsurance.setInsuredGivenName(insuredObj.getFirstName());
	                        patientInsurance.setInsuredRelation(insuredObj.getRelationship());
	                        patientInsurance.setInsuredDOB(insuranceObj.getInsuredDOB());
	                    }
	                    patientInsurance.setPolicyNumber(insuranceObj.getPolicyNumber());
	                    patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
	                    log.debug("Saving PatientInsurance Obj: {}", patientInsurance);
	                    session.saveOrUpdate(patientInsurance);
	                }
	            }
	        }
	 
	        // After saving PatientInsurance, update the ReloadInsurance record
	        if (patientReloadReq.getVisitId() != null) {
	        	Integer visitId = patientReloadReq.getVisitId().intValue();
	        	PatientReload reloadInsurance = session.get(PatientReload.class, visitId);
	            if (reloadInsurance != null) {
	                reloadInsurance.setStatus("Completed"); 
	                reloadInsurance.setErrorCode(0); 
	                reloadInsurance.setErrorMessage("Success"); 
	                reloadInsurance.setLastUpdatedTimestamp(currentTimestamp);
	                log.debug("Updating ReloadInsurance Obj: {}", reloadInsurance);
	                session.update(reloadInsurance); 
	            } else {
	                log.error("No ReloadInsurance found for visitId: {}", patientReloadReq.getVisitId());
	            }
	        }
	    } catch (Exception e){
	        log.error("Exception occurred in insertPatientInsuranceData: {}", e.getMessage());
	    }
	}
	

	@Override
	public APIResponse reloadDeficiency(ReloadPatientInsuranceReq req) {

	    Session session = this.sessionFactory.getCurrentSession();
	    APIResponse response = new APIResponse();

	    try {

	        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	
	        // Fetch records from deficiencyReload table
	        String hql = "FROM DeficiencyReload rd";
	        Query<DeficiencyReload> query = session.createQuery(hql, DeficiencyReload.class);
	        query.setFirstResult(req.getOffset());
	        query.setMaxResults(req.getLimit());

	        log.info("Executing query: {} with offset: {} and limit: {}", hql, req.getOffset(), req.getLimit());

	        List<DeficiencyReload> reloadDeficiencyList = query.list();

	        log.info("reloadDeficiency: {} ", reloadDeficiencyList);
	 
	        // Process each deficiency record
	        for (DeficiencyReload deficiency : reloadDeficiencyList) {

	            // Skip processing if the status is 'Returned'
	            if ("Returned".equals(deficiency.getStatus())) {
	                log.info("Skipping deficiency with visitId {} as it is already marked as Returned", deficiency.getVisitId());
	                continue;  // Skip this deficiency record and move to the next
	            }
	 
	            try {

	                // Fetch notifications that match visit_id and have PN or HBO in document_type
	                String notificationHQL = "FROM Notification n WHERE n.visitId = :visitId " +
	                                          "AND (n.documentType = 'PN' OR n.documentType = 'HBO') " +
	                                          "AND n.notificationTimestamp >= :deficiencyDate";

	                Query<Notification> notificationQuery = session.createQuery(notificationHQL, Notification.class);
	                notificationQuery.setParameter("visitId", Long.valueOf(deficiency.getVisitId()));
	                notificationQuery.setParameter("deficiencyDate", deficiency.getDeficiencyDate());
	                List<Notification> notifications = notificationQuery.list();
	 
	                // If no matching notifications were found
	                if (notifications.isEmpty()) {

	                    // Update the DeficiencyReload table with status "Not Found"
	                    deficiency.setStatus("Not Found");
	                    deficiency.setErrorCode("2");  
	                    deficiency.setErrorMessage("No matching document types (PN or HBO) found before deficiency date");
	                    deficiency.setLastUpdatedTimestamp(currentTimestamp.toString());

	                    session.update(deficiency);
	 
	                    log.info("No matching document types found for visitId: {}. Status updated to 'Not Found'.", deficiency.getVisitId());

	                    continue;  
	                }
	 
	                // If there are matching notifications, update the status in the Dashboard table
	                String dashboardHQL = "UPDATE Dashboard d SET d.status = :status WHERE d.visitId = :visitId";
	                Query dashboardQuery = session.createQuery(dashboardHQL);
	                dashboardQuery.setParameter("status", "Returned");
	                dashboardQuery.setParameter("visitId", Long.valueOf(deficiency.getVisitId()));

	                int rowsUpdated = dashboardQuery.executeUpdate();

	                log.info("Updated {} rows in Dashboard for visitId: {}", rowsUpdated, deficiency.getVisitId());
	 
	                saveTimeline(Long.valueOf(deficiency.getVisitId()), "Returned", null, 0L, "i-heal", "ProgNo/HBO signed", "Coder");
	 

	                deficiency.setStatus("Returned");
	                deficiency.setErrorCode("0");  // Success
	                deficiency.setErrorMessage("Success");
	                deficiency.setLastUpdatedTimestamp(currentTimestamp.toString());

	                session.update(deficiency);
	 
	                log.info("Updated DeficiencyReload table for visitId: {}", deficiency.getVisitId());
	 
	            } catch (Exception innerException) {

	                log.error("Exception occurred while processing visitId: {}. Error: {}", deficiency.getVisitId(), innerException.getMessage());
	 

	                deficiency.setStatus("Error");
	                deficiency.setErrorCode("1");  
	                deficiency.setErrorMessage(innerException.getMessage());
	                deficiency.setLastUpdatedTimestamp(currentTimestamp.toString());
	                session.update(deficiency);
	 
	                log.info("Error processing visitId: {}. DeficiencyReload table updated with error.", deficiency.getVisitId());

	            }
	        }
	        response.setResponseCode("0");
            response.setResponseMessage("Success");
	    } catch (Exception e) {
	        log.error("Exception occurred in reloadDeficiency: {}", e.getMessage());
	        response.setResponseCode("500");
	        response.setResponseMessage("Internal Server Error");
	    }
	    return response;
	}

	private boolean checkIfDocumentTypeExists(long visitId,long patientId, String documentType) {
	    Session session = this.sessionFactory.getCurrentSession();
	    String hql = "FROM PatientMedicalRecords pmr WHERE pmr.visitId = :visitId AND pmr.patientId = :patientId AND pmr.documentType = :documentType";
	    Query query = session.createQuery(hql);
	    query.setParameter("visitId", visitId);
	    query.setParameter("patientId", patientId);
	    query.setParameter("documentType", documentType);
	    log.info("checkIfDocumentTypeExists method: {}",query.uniqueResult());
	    // Return true if there are any results, false otherwise
	    return query.uniqueResult() != null;
	}
	
	private boolean checkIfDocumentTypeExistsNoti(long visitId, String documentType) {
	    Session session = this.sessionFactory.getCurrentSession();
	    String hql = "FROM Notification pmr WHERE pmr.visitId = :visitId AND pmr.documentType = :documentType";
	    Query query = session.createQuery(hql);
	    query.setParameter("visitId", visitId);
	    query.setParameter("documentType", documentType);
	    log.info("checkIfDocumentTypeExistsNoti method: {}",query.uniqueResult());
	    // Return true if there are any results, false otherwise
	    return query.uniqueResult() != null;
	}

	@Override
	public void saveSBPatientMedicalRecords(
	        IHealSuperBillLoadObj superbill,
	        IHealPatientLoadObj patientObj,
	        IHealVisitObject visitObject,
	        IHealNotificationReq iHealNotificationReq) {
	 
	    Session session = this.sessionFactory.getCurrentSession();
	    log.info("Inside saveSBPatientMedicalRecords");
	    try {
            log.info("Start the Transaction");
	 
	        // Parse patientId
	        long patientId = 0L;

	        try {
	            patientId = Long.parseLong(patientObj.getPatientId());
	        } catch (NumberFormatException e) {
	            log.error("Invalid patient ID format: {}", patientObj.getPatientId());
	            return;
	        }
	 
	        long visitId = visitObject.getVisitId();
	        String documentType = "SB";
	        Integer documentId = (superbill.getDocument() != null) ? superbill.getDocument().getVersionId() : null;
	 
	        if (documentId == null) {
	            log.warn("Document ID is null. Skipping save.");
	            return;
	        }
	 
	        // Fetch existing record
	        String hql = "FROM PatientMedicalRecords WHERE patientId = :patientId AND visitId = :visitId AND documentId = :documentId AND documentType = :documentType";

	        List<PatientMedicalRecords> records = session.createQuery(hql, PatientMedicalRecords.class)
	                .setParameter("patientId", patientId)
	                .setParameter("visitId", visitId)
	                .setParameter("documentId", String.valueOf(documentId)) 
	                .setParameter("documentType", documentType)
	                .list();
	        log.info("records.size : {} ", records.size());
	        if(records.isEmpty()){
			PatientMedicalRecords record = null;
	            record = new PatientMedicalRecords();
	            record.setPatientId(patientId);
	            record.setVisitId(visitId);
	            record.setDocumentId(String.valueOf(documentId));
	            record.setDocumentType(documentType);
	            
	            String hql1 = "From Dashboard where visitId = :visitId ";
				 Dashboard dashboard = session.createQuery(hql1, Dashboard.class)
										.setParameter("visitId",visitId )
										.setMaxResults(1).uniqueResult();
	 
	        // Convert JSON fields
	        ObjectMapper objectMapper = new ObjectMapper();
	        try {
	            record.setSbillICDCodes(superbill.getCodeDiagnosis() != null
	                    ? objectMapper.writeValueAsString(superbill.getCodeDiagnosis()) : null);
	            record.setSbillProviderEM(superbill.getProcedureProviderEM() != null
	                    ? objectMapper.writeValueAsString(superbill.getProcedureProviderEM()) : null);
	            record.setSbillProviderCPTCodes(superbill.getProcedures() != null
	                    ? objectMapper.writeValueAsString(superbill.getProcedures()) : null);
	        } catch (JsonProcessingException e) {
	            log.error("JSON conversion error: {}", e.getMessage());
	        }
	 
	        // Parse DOB and DOS
	        DateTimeFormatter dobFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
	        Date patientDob = Date.from(LocalDateTime.parse(patientObj.getPatientDOB(), dobFormatter)
	                .atZone(ZoneId.systemDefault()).toInstant());
	        DateTimeFormatter visitFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
	        Timestamp dosTimestamp = Timestamp.from(OffsetDateTime.parse(visitObject.getVisitDateTime(), visitFormatter).toInstant());
	  
	        // Set record fields
	        record.setSbillProviderFirstName(visitObject.getProviderFirstName());
	        record.setSbillProviderLastName(visitObject.getProviderLastName());
	        record.setBluebookId(dashboard.getBluebookId());
	        int facilityId = 0;
	        try {
	            if (iHealNotificationReq.getFacilityID() != null) {
	                facilityId = Integer.parseInt(iHealNotificationReq.getFacilityID());
	            }
	        } catch (NumberFormatException e) {
	            log.error("Invalid facility ID format: {}", iHealNotificationReq.getFacilityID());
	        }
	        record.setFacilityId(facilityId);
	        record.setDocumentSource("IHeal");
	        record.setPatientFullname(patientObj.getPatientLastName() + ", " + patientObj.getPatientFirstName());
	        record.setDocumentEntityId(superbill.getDocument().getDocumentEntityId());
	        record.setPatientDob(patientDob);
	        record.setPatientDos(dosTimestamp);
	        record.setReceivedTimestamp(new Timestamp(System.currentTimeMillis()));
	        record.setEventDatetime(iHealNotificationReq.getEventDateTime());
	        record.setDocumentName(visitId + "_SB");
	        record.setPatientFirstName(patientObj.getPatientFirstName());
	        record.setPatientLastName(patientObj.getPatientLastName());
	        record.setPatientMRN(patientObj.getPatientNumber());
	        record.setSbillProviderId(String.valueOf(visitObject.getProviderId()));
	        record.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis())); 

	        session.persist(record);
	        log.info("record for patientId={} visitId={} documentId={} saved successfully",
	                patientId, visitId, documentId);
	        }
	
	    } catch (Exception e) {
	        log.error("Error in saveSBPatientMedicalRecords: {}", e.getMessage(), e);
	    }
	}

		 
}
