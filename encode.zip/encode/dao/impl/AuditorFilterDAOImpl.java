package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.dao.AuditorFiltetDAO;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AuditFilterDetails;
import com.healogics.encode.dto.AuditorDrillDownReq;
import com.healogics.encode.dto.AuditorDrillDownRes;
import com.healogics.encode.dto.CPTObj;
import com.healogics.encode.dto.Coder;
import com.healogics.encode.dto.DeleteFilterReq;
import com.healogics.encode.dto.EditFilterNameRes;
import com.healogics.encode.dto.FacilityDetails;
import com.healogics.encode.dto.FilterLogicReq;
import com.healogics.encode.dto.SaveAuditFilterReq;
import com.healogics.encode.dto.SaveAuditorFilterRes;
import com.healogics.encode.dto.VisitDetails;
import com.healogics.encode.entity.AuditFilters;
import com.healogics.encode.entity.AuditFiltersSource;
import com.healogics.encode.entity.AuditQueue;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.FilterLimit;
import com.healogics.encode.entity.Filters;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class AuditorFilterDAOImpl implements AuditorFiltetDAO {
	private final Logger log = LoggerFactory.getLogger(AuditorFilterDAOImpl.class);

	private final SessionFactory sessionFactory;
	

	@Autowired
	public AuditorFilterDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public SaveAuditorFilterRes saveAuditorFilter(AuditFilterDetails filter) throws EncodeExceptionHandler {
		SaveAuditorFilterRes res = new SaveAuditorFilterRes();
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "SELECT COUNT(*) FROM Filters WHERE filterName = :filterName";
			Query query = session.createQuery(hql);
			query.setParameter("filterName", filter.getFilterName());
			Long count = (Long) query.uniqueResult();
			log.info("count : {}", count);
			
			if (count != null && count > 0) {
				res.setResponseCode("2");
				res.setResponseMessage("Filter name already exists");
			} else {
				long currentMillis = System.currentTimeMillis();
				Timestamp currentTime = new Timestamp(currentMillis);

				Filters filters = new Filters();
				filters.setFilterName(filter.getFilterName());
				filters.setActive(filter.getActive());
				//filters.setTeam(filter.getCodingTeam());
				filters.setCoders(filter.getCoders());
		        filters.setCoderFullName(filter.getCodersFullName());
				filters.setCount(filter.getCount());
				filters.setCptCodes(filter.getCptCodes());
				filters.setCreatedTimestamp(currentTime);
				filters.setCreatedUser(filter.getUserFullName());
				filters.setCreatedUsername(filter.getUsername());
				filters.setDowncoded(filter.getDowncoded());
				filters.setFacilities(filter.getFacilities());
				filters.setFilterName(filter.getFilterName());
				filters.setIcdCodes(filter.getIcdCodes());
				filters.setInsurance(filter.getInsurance());
				filters.setModifiers(filter.getModifiers());
				filters.setPercentage(filter.getPercentage());
				filters.setProviders(filter.getProviders());
				filters.setUnits(filter.getUnits());
				filters.setProviderId(filter.getProvidersId());
				filters.setFacilityId(filter.getFacilitiesId());
				filters.setCoderId(filter.getCodersId());
				filters.setCptName(filter.getCptName());
				filters.setModifierName(filter.getModifierName());
				
				if (filter.getNurseFilter() == 1 && (filter.getUnits() == null || filter.getUnits().isEmpty())) {
	                filters.setUnits("10#11#12"); 
	            } else {
	                filters.setUnits(filter.getUnits()); 
	            }
				
				if (filter.getNurseFilter() == 1) {
					filters.setFilterAudience("Nurse");
				} else {
					filters.setFilterAudience("Auditor");
				}				
	            
	            ObjectMapper objectMapper = new ObjectMapper();
	            try {
	                List<String> codingTeamList = filter.getCodingTeam(); 
	                String codingTeamJson = objectMapper.writeValueAsString(codingTeamList);
	                filters.setCodingTeam(codingTeamJson); 
	            } catch (JsonProcessingException e) {
	                log.error("Error serializing codingTeam: " + e.getMessage());
	                throw new EncodeExceptionHandler("Error serializing coding team data");
	            }
	            
	            try {
	                // If cptData is null, create an empty list
	                List<CPTObj> cptDataToSerialize = filter.getCptData() != null ? filter.getCptData() : Collections.emptyList();
	                String cptJson = objectMapper.writeValueAsString(cptDataToSerialize);
	                filters.setCptObject(cptJson); 
	            } catch (JsonProcessingException e) {
	                log.error("Error serializing CPTObj: " + e.getMessage());
	                throw new EncodeExceptionHandler("Error serializing CPT data");
	            }
				
               log.info("nurse Filter : {} ", filter.getNurseFilter());
				session.save(filters);

				res.setResponseCode("0");
				res.setResponseMessage("Success");
			}

		} catch (Exception e) {
			log.error("Exception occured while saving audit filter: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return res;
	}

	@Override
	public void saveAuditFilter(SaveAuditFilterReq filter) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			AuditFilters filters = new AuditFilters();
			filters.setFilterName(filter.getFilterName());
			filters.setActive(filter.getActive());
			filters.setBillingClient(filter.getBillingClient());

			ObjectMapper objectMapper = new ObjectMapper();

			String coderDetails = null;
			try {
				coderDetails = objectMapper.writeValueAsString(filter.getCoders());
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting CoderDetails JSON: " + e.getMessage());
			}

			filters.setCoders(coderDetails);
			filters.setCount(filter.getCount());

			objectMapper = new ObjectMapper();

			String cptDetails = null;
			try {
				cptDetails = objectMapper.writeValueAsString(filter.getCptCodes());
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting CoderDetails JSON: " + e.getMessage());
			}

			filters.setCptCodes(cptDetails);
			filters.setCreatedTimestamp(currentTime);
			filters.setCreatedUser(filter.getUserFullName());
			filters.setCreatedUsername(filter.getUsername());
			filters.setDowncoded(filter.getDowncoded());

			objectMapper = new ObjectMapper();

			String facilityDetails = null;
			try {
				facilityDetails = objectMapper.writeValueAsString(filter.getFacilities());
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting CoderDetails JSON: " + e.getMessage());
			}

			filters.setFacilities(facilityDetails);
			filters.setFilterName(filter.getFilterName());

			objectMapper = new ObjectMapper();

			String icdCodeDetails = null;
			try {
				icdCodeDetails = objectMapper.writeValueAsString(filter.getIcdCodes());
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting CoderDetails JSON: " + e.getMessage());
			}

			filters.setIcdCodes(icdCodeDetails);
			filters.setInsurance(filter.getInsurance());
			filters.setModifiers(filter.getModifiers());
			filters.setPercentage(filter.getPercentage());

			objectMapper = new ObjectMapper();

			String providerDetails = null;
			try {
				providerDetails = objectMapper.writeValueAsString(filter.getProviders());
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting CoderDetails JSON: " + e.getMessage());
			}

			filters.setProviders(providerDetails);
			filters.setUnits(filter.getUnits());

			session.save(filters);

		} catch (Exception e) {
			log.error("Exception occured while saving audit filter: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public Filters getAuditFilters(int filterId) throws EncodeExceptionHandler {
	    Session session = this.sessionFactory.getCurrentSession();
	    Filters filter = null;
	    try {
	        String hql = "FROM Filters f WHERE f.filterId = :filterId";
	        filter = (Filters) session.createQuery(hql)
	                                  .setParameter("filterId", filterId)
	                                  .uniqueResult(); 
	 
	    } catch (Exception e) {
	        log.error("Exception occurred while fetching audit filter: " + e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	    return filter;
	}

	@Override
	public List<String> getCodingTeam() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> codingTeam = new ArrayList<>();
		try {
			String hql = "SELECT t.clientName FROM Team t";
			codingTeam = session.createQuery(hql, String.class).list();
		} catch (Exception e) {
			log.error("Exception occurred while fetching coding team: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return codingTeam;
	}

	@Override
	public List<Coder> getCoders() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Coder> coders = new ArrayList<>();
		try {
			String hql = "SELECT eu.userId, eu.username, eu.userFullName FROM EncodeUsers eu WHERE eu.encodeRole LIKE :role";
			List<Object[]> results = session.createQuery(hql).setParameter("role", "%Coder%").list();
			for (Object[] result : results) {
				Coder coder = new Coder();
				coder.setUserId((Long) result[0]);
				coder.setUsername((String) result[1]);
				coder.setUserFullName((String) result[2]);
				coders.add(coder);
			}
		} catch (Exception e) {
			log.error("Exception occurred while fetching coders: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return coders;
	}

	@Override
	public EditFilterNameRes updateFilters(SaveAuditFilterReq filterReq) throws EncodeExceptionHandler {
		EditFilterNameRes res = new EditFilterNameRes();
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "SELECT COUNT(*) FROM Filters WHERE filterName = :filterName";
			Query query = session.createQuery(hql);
			query.setParameter("filterName", filterReq.getFilterName());
			Long count = (Long) query.uniqueResult();
			log.info("count : {}", count);
			
			if (count != null && count > 0) {
				res.setResponseCode("2");
				res.setResponseMessage("Filter name already exists");
			} else {
				long currentMillis = System.currentTimeMillis();
				Timestamp currentTime = new Timestamp(currentMillis);
				Integer filterId = filterReq.getFilterId().intValue();
				Filters filters = session.get(Filters.class, filterId);
				if (filters != null) {
					filters.setFilterName(filterReq.getFilterName());
					filters.setLastUpdatedTimestamp(currentTime);
					filters.setLastUpdatedUser(filterReq.getLastUpdatedUser());
					filters.setLastUpdatedUsername(filterReq.getLastUpdatedUsername());
					session.update(filters);
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				}
			}

		} catch (Exception e) {
			log.error("Exception occured while updating filter name: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return res;
	}
	
	@Override
	public EditFilterNameRes editFilter(AuditFilterDetails filterReq) throws EncodeExceptionHandler {
	    EditFilterNameRes res = new EditFilterNameRes();
	    Session session = this.sessionFactory.getCurrentSession();
	    ObjectMapper objectMapper = new ObjectMapper();
	    try {
	       // Integer filterId = filterReq.getFilterId().intValue();
	        Filters filters = session.get(Filters.class, filterReq.getFilterId());
	        if (filters != null) {
	            // If the filter name has changed
	            if (filterReq.getIsFilterNameChanged() == 1) { 
	                String hql = "SELECT COUNT(*) FROM Filters WHERE filterName = :filterName";
	                Query query = session.createQuery(hql);
	                query.setParameter("filterName", filterReq.getFilterName());
	                Long count = (Long) query.uniqueResult();
	                log.info("count : {}", count);
	                if (count != null && count > 0) {
	                    res.setResponseCode("2");
	                    res.setResponseMessage("Filter name already exists");
	                    return res; // Early return if name exists
	                }
	 
	                // Update the filter name
	                filters.setFilterName(filterReq.getFilterName());
	            }
	            
	            if (filterReq.getActive() != -1) {
	                filters.setActive(filterReq.getActive());
	            }
	            if (filterReq.getCodingTeam() != null) {
	            	 String codingTeam = objectMapper.writeValueAsString(filterReq.getCodingTeam());
	            	 filters.setCodingTeam(codingTeam);
	            }
	            if (filterReq.getCoders() != null) {
	                filters.setCoders(filterReq.getCoders());
	            }
	            if (filterReq.getCodersId() != null) {
	                filters.setCoderId(filterReq.getCodersId());
	            }
	            if (filterReq.getCodersFullName() != null) {
	                filters.setCoderFullName(filterReq.getCodersFullName());
	            }
	            if (filterReq.getProvidersId() != null) {
	                filters.setProviderId(filterReq.getProvidersId());
	            }
	            if (filterReq.getProviders() != null) {
	                filters.setProviders(filterReq.getProviders());
	            }
	            if (filterReq.getFacilities() != null) {
	                filters.setFacilities(filterReq.getFacilities());
	            }
	            if (filterReq.getFacilitiesId() != null) {
	                filters.setFacilityId(filterReq.getFacilitiesId());
	            }
	            if (filterReq.getCptCodes() != null) {
	                filters.setCptCodes(filterReq.getCptCodes());
	            }
	            if (filterReq.getIcdCodes() != null) {
	                filters.setIcdCodes(filterReq.getIcdCodes());
	            }
	            if (filterReq.getModifiers() != null) {
	                filters.setModifiers(filterReq.getModifiers());
	            }
	            if (filterReq.getUnits() != null && !filterReq.getUnits().isEmpty()) {
	                filters.setUnits(filterReq.getUnits());
	            }
	            if (filterReq.getInsurance() != null) {
	                filters.setInsurance(filterReq.getInsurance());
	            }
	            if (filterReq.getDowncoded() != -1) {
	                filters.setDowncoded(filterReq.getDowncoded());
	            }
	            if (filterReq.getPercentage() != -1) {
	                filters.setPercentage(filterReq.getPercentage());
	            }
	            if (filterReq.getCount() != -1) {
	                filters.setCount(filterReq.getCount());
	                
	                // Update FilterLimit table if count is modified
	                FilterLimit filterLimit = session.get(FilterLimit.class, filterReq.getFilterId());
	                Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	                Date currentDate = new Date();
	 
	                if (filterLimit == null) {
	                    filterLimit = new FilterLimit();
	                    filterLimit.setFilterId(filterReq.getFilterId());
	                    filterLimit.setDate(currentDate);
	                    filterLimit.setActualCount(filterReq.getCount());
	                    filterLimit.setCurrentCount(0);
	                    filterLimit.setExecFlag(true);
	                    filterLimit.setLastUpdatedTimestamp(currentTimestamp);
	                    session.save(filterLimit);
	                } else {
	                    if (!isSameDay(filterLimit.getDate(), currentDate)) {
	                        filterLimit.setDate(currentDate);
	                        filterLimit.setActualCount(filterReq.getCount());
	                        filterLimit.setCurrentCount(0);
	                        filterLimit.setExecFlag(true);
	                    }else{
	                    	filterLimit.setActualCount(filterReq.getCount());
	                        filterLimit.setCurrentCount(0);
	                        filterLimit.setExecFlag(true);
	                    }
	                    filterLimit.setLastUpdatedTimestamp(currentTimestamp);
	                    session.update(filterLimit);
	                }
	            }
	            if (filterReq.getUserFullName() != null) {
	                filters.setLastUpdatedUsername(filterReq.getUserFullName());
	            }
	            if (filterReq.getUsername() != null) {
	                filters.setLastUpdatedUser(filterReq.getUsername());
	            }
	            if (filterReq.getCreatedUserFullName() != null) {
	                filters.setCreatedUsername(filterReq.getCreatedUserFullName());
	            }
	            if (filterReq.getCreatedUserName() != null) {
	                filters.setCreatedUser(filterReq.getCreatedUserName());
	            }
	             
	            if (filterReq.getLastUpdatedUser() != null) {
	                filters.setLastUpdatedUser(filterReq.getLastUpdatedUser());
	            }
	            if (filterReq.getLastUpdatedUsername() != null) {
	                filters.setLastUpdatedUsername(filterReq.getLastUpdatedUsername());
	            }
	            if (filterReq.getNurseFilter() != -1) {
	            	if (filterReq.getNurseFilter() == 1) {
	                    filters.setFilterAudience("Nurse");
	                } else {
	                    filters.setFilterAudience("Auditor");
	                }
	            }
	            if (filterReq.getCptName() != null) {
	                filters.setCptName(filterReq.getCptName());
	            }
	            if (filterReq.getModifierName() != null) {
	                filters.setModifierName(filterReq.getModifierName());
	            }
	            if (filterReq.getCptData() != null && !filterReq.getCptData().isEmpty()) {
	                String cptDataJson = objectMapper.writeValueAsString(filterReq.getCptData());
	                filters.setCptObject(cptDataJson);  
	            }

	 
	            // Update the active status
	            filters.setActive(filterReq.getActive());
	            long currentMillis = System.currentTimeMillis();
	            Timestamp currentTime = new Timestamp(currentMillis);
	            filters.setLastUpdatedTimestamp(currentTime);
	            session.update(filters);
	            res.setResponseCode("0");
	            res.setResponseMessage("Success");
	        } else {
	            res.setResponseCode("1");
	            res.setResponseMessage("Filter not found");
	        }
	    } catch (Exception e) {
	        log.error("Exception occurred while updating filter name: " + e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	    return res;
	}
	
	private boolean isSameDay(Date date1, Date date2) {
	    return date1 != null && date2 != null &&
	           date1.toInstant().truncatedTo(ChronoUnit.DAYS).equals(date2.toInstant().truncatedTo(ChronoUnit.DAYS));
	}
	

	@Override
	public EditFilterNameRes deleteFilter(DeleteFilterReq filterReq) throws EncodeExceptionHandler {
	    EditFilterNameRes res = new EditFilterNameRes();
	    Session session = this.sessionFactory.getCurrentSession();
	    try {
	    	List<Integer> filterIds = filterReq.getFilterId();
	    	 
	        for (Integer filterId : filterIds) {
	            Filters auditFilter = session.get(Filters.class, filterId);
	            if (auditFilter != null) {
					FilterLimit filterLimit = session.get(FilterLimit.class, filterId);
					if (filterLimit != null) {
						session.delete(filterLimit);
						log.info("Deleted filter limit entry for Filter ID: {}", filterId);
					}
	                session.delete(auditFilter);
	                res.setResponseCode("0");
	                res.setResponseMessage("Success");
	            } else {
	                log.info("Filter with ID " + filterId + " not found.");
	                res.setResponseCode("1");
	                res.setResponseMessage("Filter with ID " + filterId + " not found.");
	            }
	        }
	    } catch (Exception e) {
	        log.error("Exception occurred while deleting filter: " + e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	    return res;
	}


	@Override
	public AuditorDrillDownRes getDrillDownData(AuditorDrillDownReq auditorDrillDownReq) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		AuditorDrillDownRes res = new AuditorDrillDownRes();
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			String hql;
			Query query;

			  if (auditorDrillDownReq.getFilters().contains("coder")) {
		            // Fetch facilities for specific coders
		            hql = "SELECT u.userFacilities FROM EncodeUsers u "
		                + "WHERE u.username IN (:coders) AND u.encodeRole LIKE '%Coder%'";
		            query = session.createQuery(hql);
		            query.setParameterList("coders", auditorDrillDownReq.getCoder().split("#"));
		            List<String> resultList = query.list();
		 
		            Set<FacilityDetails> facilities = new HashSet<>();
		            for (String result : resultList) {
		                if (result != null) {
		                    try {
		                        JsonNode nodes = objectMapper.readTree(result);
		                        for (JsonNode node : nodes) {
		                            FacilityDetails facility = new FacilityDetails();
		                            facility.setFacilityId(node.get("facilityId").asText());
		                            facility.setFacilityBluebookId(node.get("facilityBluebookId").asText());
		                            facility.setFacilityName(node.get("facilityName").asText());
		                            facility.setIhealConfig(node.get("configuration").asText());
		                            facilities.add(facility);
		                        }
		                    } catch (JsonProcessingException e) {
		                        log.error("Failed to parse facilities JSON for user: {}", result, e);
		                    }
		                } else {
		                    log.info("Facility data is null for a user.");
		                }
		            }
		            res.setFacilities(new ArrayList<>(facilities));
		 
		        }else {
				// Fetch coders for the team
				//if ("Healogics".equalsIgnoreCase(auditorDrillDownReq.getCodingTeam())) {
		        	if(auditorDrillDownReq.getCodingTeam()!= null && auditorDrillDownReq.getCodingTeam().contains("Healogics")){
	                hql = "SELECT u.userId, u.username, u.userFullName FROM EncodeUsers u "
	                    + "WHERE u.team IN ('Healogics', 'AGS', 'Infinx') AND u.encodeRole LIKE '%Coder%'";
	            } else {
	                hql = "SELECT u.userId, u.username, u.userFullName FROM EncodeUsers u "
	                    + "WHERE u.team IN (:team) AND u.encodeRole LIKE '%Coder%'";
	            }
	            query = session.createQuery(hql);
	           // if (!"Healogics".equalsIgnoreCase(auditorDrillDownReq.getCodingTeam())) {
	            if(!auditorDrillDownReq.getCodingTeam().contains("Healogics")){
	                query.setParameterList("team", auditorDrillDownReq.getCodingTeam());
	            }
				List<Object[]> resultList = query.list();
				List<Coder> coders = new ArrayList<>();
				for (Object[] result : resultList) {
					Coder coder = new Coder();
					coder.setUserId((Long) result[0]);
					coder.setUsername((String) result[1]);
					coder.setUserFullName((String) result[2]);
					coders.add(coder);
				}
				res.setCoder(coders);
			}

			res.setResponseCode("0");
			res.setResponseMessage("Success");
		} catch (Exception e) {
			log.error("Exception occured while fetch drill down data: " + e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch drill down data", e);
		}
		return res;
	}
	
//	@Override
//	public List<Filters> getAllFilters(FilterLogicReq req) {
//		Session session = sessionFactory.getCurrentSession();
//		Query<Filters> query = session.createQuery("FROM Filters", Filters.class);
//		return query.list();
//	}
	
	@Override
	public List<Filters> getAllFilters(FilterLogicReq req) {
		Session session = sessionFactory.getCurrentSession();
		StringBuilder hql = new StringBuilder("FROM Filters WHERE 1=1");

		if ("AGS".equals(req.getCodingTeam())) {
			hql.append(" AND codingTeam LIKE '%AGS%'");
		} else if ("Healogics".equals(req.getCodingTeam())) {

		} else if ("Infinx".equals(req.getCodingTeam())) {
			hql.append(" AND codingTeam LIKE '%Infinx%'");
		} else {
			return Collections.emptyList();
		}

		if (req.getAuditor() == 1 && req.getNurse() == 1) {
	        hql.append(" AND (filterAudience = 'Auditor' OR filterAudience = 'Nurse')");
	    } else {
	        if (req.getAuditor() == 1) {
	            hql.append(" AND filterAudience = 'Auditor'");
	        }
	 
	        if (req.getNurse() == 1) {
	            hql.append(" AND filterAudience = 'Nurse'");
	        }
	    }
		
		hql.append(" ORDER BY "
	            + "CASE WHEN icdCodes IS NOT NULL THEN 1 ELSE 0 END + "
	            + "CASE WHEN cptCodes IS NOT NULL THEN 1 ELSE 0 END + "
	            + "CASE WHEN modifiers IS NOT NULL THEN 1 ELSE 0 END + "
	            + "CASE WHEN units IS NOT NULL THEN 1 ELSE 0 END + "
	            + "CASE WHEN insurance IS NOT NULL THEN 1 ELSE 0 END DESC, "
	            + "CASE WHEN providerId IS NOT NULL THEN 1 ELSE 0 END + "
	            + "CASE WHEN coderId IS NOT NULL THEN 1 ELSE 0 END + "
	            + "CASE WHEN facilityId IS NOT NULL THEN 1 ELSE 0 END DESC, "
	            + "createdTimestamp ASC");
		
		Query<Filters> query = session.createQuery(hql.toString(), Filters.class);
		log.debug("filters : {} ", query.list());
		return query.list();

	}
	
	@Override
	public boolean checkFilterLimit(Filters filter) throws EncodeExceptionHandler {
	    try {
	        log.info("Check Filter Limit for filter ID: {}", filter.getFilterId());
	        Session session = sessionFactory.getCurrentSession();
	        FilterLimit filterLimit = session.get(FilterLimit.class, filter.getFilterId());
	        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	 
	        if (filterLimit == null) {
	            return true;
	        }
	 
	        Date currentDate = new Date();
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	 
	        if (!sdf.format(filterLimit.getDate()).equals(sdf.format(currentDate))) {
	            log.info("Resetting current count because date has changed from {} to {}", filterLimit.getDate(), currentDate);
	            filterLimit.setDate(currentDate);
	            filterLimit.setCurrentCount(0);
	            filterLimit.setExecFlag(true);
	            filterLimit.setLastUpdatedTimestamp(currentTimestamp);
	            session.merge(filterLimit);
	            session.flush(); // Ensure changes persist
	        }
	 
	        log.info("Filter Limit check result: {}", filterLimit.getExecFlag());
	        return filterLimit.getExecFlag();
	    } catch (Exception e) {
	        log.error("Exception occurred while checking filter limit: {}", e.getMessage(), e);
	        throw new EncodeExceptionHandler("Failed to check filter limit", e);
	    }
	}


	@Override
	public void updateFilterLimit(Filters filter, int visitCount) throws EncodeExceptionHandler {
	    try {
	        log.info("updateFilterLimit method called with filter ID: {}, visitCount: {}", filter.getFilterId(), visitCount);
	        Session session = sessionFactory.getCurrentSession();
	        FilterLimit filterLimit = session.get(FilterLimit.class, filter.getFilterId());
	        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
	 
	        if (filterLimit == null) {
	            log.info("No existing filter limit found, creating a new entry.");
	            filterLimit = new FilterLimit();
	            filterLimit.setFilterId(filter.getFilterId());
	            filterLimit.setDate(new Date());
	            filterLimit.setActualCount(filter.getCount());
	            filterLimit.setCurrentCount(visitCount);
	            filterLimit.setExecFlag(true);
	            filterLimit.setLastUpdatedTimestamp(currentTimestamp);
	            session.save(filterLimit);
	        } else {
	            log.info("Existing filter limit found. Current Count: {}, Actual Count: {}", 
	                      filterLimit.getCurrentCount(), filterLimit.getActualCount());
	 
	            // Update the current count
	            filterLimit.setCurrentCount(filterLimit.getCurrentCount() + visitCount);
	            filterLimit.setLastUpdatedTimestamp(currentTimestamp);
	 
	            // Now check if the new current count equals actual count
	            if (filterLimit.getCurrentCount() >= filterLimit.getActualCount()) {
	                log.info("Current count reached or exceeded actual count, setting execFlag to false.");
	                filterLimit.setExecFlag(false);
	            } else {
	                log.info("Current count is still less than actual count, keeping execFlag true.");
	                filterLimit.setExecFlag(true);
	            }
	 
	            session.update(filterLimit);
	        }
	 
	        session.flush(); // To Ensure changes are persisted immediately
	        log.info("Filter limit updated successfully.");
	 
	    } catch (Exception e) {
	        log.error("Exception occurred while updating filter limit: {}", e.getMessage(), e);
	        throw new EncodeExceptionHandler("Failed to update filter limit", e);
	    }
	}

	
	@Override
	public List<Long> getFilteredVisitIdsExcludingAssigned(Filters filter, Set<Long> usedVisitIds)
			throws EncodeExceptionHandler {
		log.info("Filter : {}", filter);

		// Extract filter values, defaulting to empty arrays if null
		String[] facilityIdsStr = Optional.ofNullable(filter.getFacilityId()).orElse("").split("#");
		String[] icdCodes = Optional.ofNullable(filter.getIcdCodes()).orElse("").split("#");
		String[] cptCodes = Optional.ofNullable(filter.getCptCodes()).orElse("").split("#");
		String[] modifiers = Optional.ofNullable(filter.getModifiers()).orElse("").split("#");
		String[] unitsStr = Optional.ofNullable(filter.getUnits()).orElse("").split("#");
		String insurance = Optional.ofNullable(filter.getInsurance()).orElse("");
		String[] providerIdsStr = Optional.ofNullable(filter.getProviderId()).orElse("").split("#");
		String[] coderIdsStr = Optional.ofNullable(filter.getCoderId()).orElse("").split("#");

		// Convert string arrays to appropriate types
		List<Integer> facilityIds = convertToIntegerList(facilityIdsStr);
		List<Integer> units = convertToIntegerList(unitsStr);
		List<Long> providerIds = convertToLongList(providerIdsStr);
		List<Long> coderIds = convertToLongList(coderIdsStr);

		int count = Optional.ofNullable(filter.getCount()).orElse(0);
		Integer percentage = Optional.ofNullable(filter.getPercentage()).orElse(0);

		Session session = sessionFactory.getCurrentSession();

		Timestamp filterExecutionTimestamp = filter.getFilterExecutionTimestamp();
		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

		try {
			// Construct HQL query dynamically with AND conditions and excluding
			// usedVisitIds
			StringBuilder hql = new StringBuilder("SELECT DISTINCT afs.visitId FROM AuditFiltersSource afs "
					+ "WHERE afs.recordActive = 1 AND afs.status = 'Completed' AND afs.auditQueue = 0");

			if (filterExecutionTimestamp != null) {
				hql.append(" AND afs.lastUpdatedTimestamp BETWEEN :filterExecutionTimestamp AND :currentTimestamp");
			}

			boolean hasCondition = false;

			if (!facilityIds.isEmpty()) {
				hql.append(" AND afs.facilityId IN (:facilityIds)");
				hasCondition = true;
			}
			if (icdCodes.length > 0 && !icdCodes[0].isEmpty()) {
				hql.append(" AND afs.icdCode IN (:icdCodes)");
				hasCondition = true;
			}
			if (cptCodes.length > 0 && !cptCodes[0].isEmpty()) {
				hql.append(" AND afs.cptCode IN (:cptCodes)");
				hasCondition = true;
			}
			if (modifiers.length > 0 && !modifiers[0].isEmpty()) {
				hql.append(" AND afs.modifier IN (:modifiers)");
				hasCondition = true;
			}
			if (!units.isEmpty()) {
				hql.append(" AND afs.unit IN (:units)");
				hasCondition = true;
			}
			if (!insurance.isEmpty()) {
				hql.append(" AND afs.insurance = :insurance");
				hasCondition = true;
			}
			if (!providerIds.isEmpty()) {
				hql.append(" AND afs.providerId IN (:providerIds)");
				hasCondition = true;
			}
			if (!coderIds.isEmpty()) {
				hql.append(" AND afs.coderUserId IN (:coderIds)");
				hasCondition = true;
			}

			if (usedVisitIds != null && !usedVisitIds.isEmpty()) {
				hql.append(" AND afs.visitId NOT IN (:usedVisitIds)");
			}

			hql.append(" ORDER BY RAND()");

			// If no conditions applied, return an empty result
			if (!hasCondition && (usedVisitIds == null || usedVisitIds.isEmpty())) {
				log.info("No filters applied. Returning empty result.");
				return new ArrayList<>();
			}

			// Dynamically constructed HQL query
			String queryString = hql.toString();
			log.info("Generated HQL Query: {}", queryString);

			Query<Long> query = session.createQuery(queryString, Long.class);

			// Set parameters if they exist
			if (!facilityIds.isEmpty()) {
				query.setParameterList("facilityIds", facilityIds);
			}
			if (icdCodes.length > 0 && !icdCodes[0].isEmpty()) {
				query.setParameterList("icdCodes", Arrays.asList(icdCodes));
			}
			if (cptCodes.length > 0 && !cptCodes[0].isEmpty()) {
				query.setParameterList("cptCodes", Arrays.asList(cptCodes));
			}
			if (modifiers.length > 0 && !modifiers[0].isEmpty()) {
				query.setParameterList("modifiers", modifiers);
			}
			if (!units.isEmpty()) {
				query.setParameterList("units", units);
			}
			if (!insurance.isEmpty()) {
				query.setParameter("insurance", insurance);
			}
			if (!providerIds.isEmpty()) {
				query.setParameterList("providerIds", providerIds);
			}
			if (!coderIds.isEmpty()) {
				query.setParameterList("coderIds", coderIds);
			}

			// Exclude previously assigned visit IDs
			if (usedVisitIds != null && !usedVisitIds.isEmpty()) {
				query.setParameterList("usedVisitIds", usedVisitIds);
			}
			if (filterExecutionTimestamp != null) {
				query.setParameter("filterExecutionTimestamp", filterExecutionTimestamp);
				query.setParameter("currentTimestamp", currentTimestamp);
			}
			// Apply limit if count is provided
			if (count > 0) {
				query.setMaxResults(count);
			}

			List<Long> results = query.list();
			log.info("Query Results: {}", results);

			// Apply percentage limit if percentage is provided
			if (percentage > 0) {
				int limit = (int) Math.ceil(results.size() * (percentage / 100.0));
				// if (limit < results.size()) {
				results = results.subList(0, limit);
				log.debug("percentage : {} ", percentage);
				log.debug("limit : {} ", limit);
				log.debug("results : {} ", results);
				// }
			}

			// Update auditQueue for the fetched visit IDs
			if (!results.isEmpty()) {
				String updateHql = "UPDATE AuditFiltersSource afs SET afs.auditQueue = :auditQueue WHERE afs.visitId IN (:visitIds)";
				Query updateQuery = session.createQuery(updateHql);
				updateQuery.setParameter("auditQueue", 1);
				updateQuery.setParameterList("visitIds", results);
				int updatedEntities = updateQuery.executeUpdate();
				log.info("Updated auditQueue for {} visit IDs", updatedEntities);
			}
			return results;

		} catch (Exception e) {
			log.error("Exception occurred while applying filter logic: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to fetch visits", e);
		}
	}

	
	private List<Integer> convertToIntegerList(String[] strings) {
		return Arrays.stream(strings).filter(s -> !s.isEmpty()).map(Integer::parseInt).collect(Collectors.toList());
	}

	private List<Long> convertToLongList(String[] strings) {
		return Arrays.stream(strings).filter(s -> !s.isEmpty()).map(Long::parseLong).collect(Collectors.toList());
	}

	public List<VisitDetails> fetchVisitDetails(List<Long> visitIds, int filterId, String codingTeam, String units) {
	    List<VisitDetails> visitDetailsList = new ArrayList<>();
	    if (!visitIds.isEmpty()) {
	        String hql = "FROM Dashboard d WHERE d.visitId IN (:visitIds)";
	        List<Dashboard> dashboards = sessionFactory.getCurrentSession()
	                .createQuery(hql, Dashboard.class)
	                .setParameterList("visitIds", visitIds)
	                .list();
	        for (Dashboard dashboard : dashboards) {
	            VisitDetails visitDetails = new VisitDetails();
	            visitDetails.setVisitId(dashboard.getVisitId());
	            visitDetails.setBluebookId(dashboard.getBluebookId());
	            visitDetails.setDOS(dashboard.getDateOfService()); // Assuming DOS is dateOfService
	            visitDetails.setStatus(dashboard.getStatus());
	            visitDetails.setMedicalRecordNumber(dashboard.getMedicalRecordNumber());
	            visitDetails.setPatientFirstName(dashboard.getPatientFirstName());
	            visitDetails.setPatientLastName(dashboard.getPatientLastName());
	            visitDetails.setPrimaryInsurance(dashboard.getPrimaryInsurance());
	            visitDetails.setSecondaryInsurance(dashboard.getSecondaryInsurance());
	            visitDetails.setFilterId(filterId);
	            visitDetails.setCodingTeam(codingTeam);
	            visitDetails.setPatientId(dashboard.getPatientId());
	            visitDetails.setPatientName(dashboard.getPatientName());
	            visitDetails.setFacilityId(dashboard.getFacilityId());
	            visitDetails.setFacilityAlias(dashboard.getFacilityAlias());
	            visitDetails.setFacilityType(dashboard.getIhealConfig());
	           
	            visitDetailsList.add(visitDetails);
	            
	            dashboard.setInAuditQueue(true);
	            sessionFactory.getCurrentSession().update(dashboard);  
	            
	        }
	        sessionFactory.getCurrentSession().flush();
	        saveToAuditQueue(visitIds, filterId, codingTeam, units);
	    }
	    return visitDetailsList;
	}
	
	private void saveToAuditQueue(List<Long> visitIds, int filterId, String codingTeam, String units) {
	    if (!visitIds.isEmpty()) {
	    	Session session = sessionFactory.getCurrentSession();
	        String hql = "FROM Dashboard d WHERE d.visitId IN (:visitIds)";
	        List<Dashboard> dashboards = sessionFactory.getCurrentSession()
	                .createQuery(hql, Dashboard.class)
	                .setParameterList("visitIds", visitIds)
	                .list();
	        for (Dashboard dashboard : dashboards) {
	            
	            AuditQueue auditQueue = sessionFactory.getCurrentSession()
	                    .get(AuditQueue.class, dashboard.getVisitId());
	            
	            if (auditQueue == null) {
	                auditQueue = new AuditQueue();
	                auditQueue.setVisitId(dashboard.getVisitId());
	            }
	            
	            auditQueue.setFilterId(filterId);
	            auditQueue.setPatientId(dashboard.getPatientId());
	            auditQueue.setPatientName(dashboard.getPatientName());
	            auditQueue.setFacilityId(dashboard.getFacilityId());
	            auditQueue.setBBC(dashboard.getBluebookId());
	            auditQueue.setFacilityAlias(dashboard.getFacilityAlias());
	 
	            
	            String insurance = dashboard.getPrimaryInsurance();
	            if (insurance == null || insurance.isEmpty()) {
	                insurance = dashboard.getSecondaryInsurance();
	            }
	            auditQueue.setInsurance(insurance);
	 
//	            auditQueue.setDateAdded(new Date(System.currentTimeMillis())); 
	            // Get the current date and time
	            Date currentDate = new Date(System.currentTimeMillis());
	     
	            // Convert current time to LocalDateTime without offset 
	            LocalDateTime localDateTime = LocalDateTime.now();
	     
	            // Convert LocalDateTime to Timestamp (without any offset conversion)
	            Timestamp dateAddedTimestamp = Timestamp.valueOf(localDateTime);
 
	            log.info("Date Format for Current Date Added : " + currentDate);
	            log.info("Date Format for Current Date Added (Local DateTime): " + dateAddedTimestamp);
	     
	            auditQueue.setDateAdded(dateAddedTimestamp);
	     
	            auditQueue.setDOS(dashboard.getDateOfService());
	            auditQueue.setMRN(dashboard.getMedicalRecordNumber());
	            auditQueue.setStatus(dashboard.getStatus());
	            auditQueue.setPatientFirstName(dashboard.getPatientFirstName());
	            auditQueue.setPatientLastName(dashboard.getPatientLastName());
	            auditQueue.setFacilityType(dashboard.getIhealConfig());
	            auditQueue.setTeam(codingTeam);
	            if (units != null && units.contains("#")) {
	                auditQueue.setUnits(""); 
	            } else {
	                auditQueue.setUnits(units); 
	            }
	            auditQueue.setProviderId(dashboard.getProviderId());
	            auditQueue.setProviderName(dashboard.getProviderName());
	            
	            session.saveOrUpdate(auditQueue);
	        }
	        
			// Update the filter execution timestamp 
			String updateHql = "UPDATE Filters f SET f.filterExecutionTimestamp = :currentTimestamp WHERE f.filterId = :filterId";
			int updatedEntities = session.createQuery(updateHql)
					.setParameter("currentTimestamp", new Timestamp(System.currentTimeMillis()))
					.setParameter("filterId", filterId).executeUpdate();

			log.info("Updated filter_execution_timestamp for filterId {}. Updated records: {}", filterId,
					updatedEntities);
	    }
	}


}
