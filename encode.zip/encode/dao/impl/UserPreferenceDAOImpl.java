package com.healogics.encode.dao.impl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.UserPreferenceDAO;
import com.healogics.encode.dto.UserPreferenceReq;
import com.healogics.encode.entity.UserPreference;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class UserPreferenceDAOImpl implements UserPreferenceDAO {

	private final Logger log = LoggerFactory
			.getLogger(UserPreferenceDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public UserPreferenceDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public boolean updateUserColorCodes(UserPreferenceReq req)
			throws EncodeExceptionHandler {
		log.debug("UserPreferenceReq Update Color Codes:  {}", req);
		boolean successFlag = false;
		DateTimeFormatter timeFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime currTime = LocalDateTime.now(ZoneOffset.UTC);
		String originalTime = currTime.atZone(ZoneOffset.UTC)
				.format(timeFormat);
		LocalDateTime currentTime = LocalDateTime.parse(originalTime,
				timeFormat);

		Session session = this.sessionFactory.getCurrentSession();
		UserPreference userPreference = new UserPreference();
		try {
			UserPreference userPref = session
					.createQuery("FROM UserPreference WHERE userId = :userId",
							UserPreference.class)
					.setParameter("userId", req.getUserId()).setMaxResults(1)
					.uniqueResult();

			if (userPref != null) {
				log.debug("userPref :   {}", userPref);

				if (req.getLastUpdatedBy() != null
						&& !req.getLastUpdatedBy().isEmpty()) {
					userPref.setLastUpdatedBy(req.getLastUpdatedBy());
				} else {
					userPref.setLastUpdatedBy(null);
				}
				userPref.setLastUpdatedTimestamp(currentTime);
				userPref.setAvatarColor(req.getColorCodes());
				session.update(userPref);
				successFlag = true;
			} else {
				log.debug("When UserPreference is not available:   {}",
						userPref);
				if (req.getUserId() != null) {
					userPreference.setUserId(req.getUserId());
				} else {
					userPreference.setUserId(null);
				}

				if (req.getLastUpdatedBy() != null
						&& !req.getLastUpdatedBy().isEmpty()) {
					userPreference.setLastUpdatedBy(req.getLastUpdatedBy());
				} else {
					userPreference.setLastUpdatedBy(null);
				}
				userPreference.setLastUpdatedTimestamp(currentTime);

				if (req.getUserFullname() != null
						&& !req.getUserFullname().isEmpty()) {
					userPreference.setUserFullname(req.getUserFullname());
				} else {
					userPreference.setUserFullname(null);
				}
				if (req.getUsername() != null && !req.getUsername().isEmpty()) {
					userPreference.setUsername(req.getUsername());
				} else {
					userPreference.setUsername(null);
				}
				userPreference.setAvatarColor(req.getColorCodes());
				session.save(userPreference);
				successFlag = true;
			}
			log.debug("Updated User Preference: ");
		} catch (Exception e) {
			log.error("Exception occurred during updateColorCode: {}", e);
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return successFlag;
	}

}
