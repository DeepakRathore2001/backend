package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.DAOConstants.NOTE_SIZE;
import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.DAOConstants;
import com.healogics.encode.dao.DashboardDAO;
import com.healogics.encode.dto.CPTChartDetails;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.EscalatedChartDetailsReq;
import com.healogics.encode.dto.ICD10Data;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.ParsedDataDTO;
import com.healogics.encode.dto.PatientMedicalRecordsDTO;
import com.healogics.encode.dto.SaveRecordReq;
import com.healogics.encode.entity.AuditFiltersSource;
import com.healogics.encode.entity.CPTCodes;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.DisparateFacilities;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.entity.FinancialTransaction;
import com.healogics.encode.entity.ICDCodesMaster;
import com.healogics.encode.entity.Notes;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.Patient;
import com.healogics.encode.entity.PatientBalancesLatestDOS;
import com.healogics.encode.entity.PatientBalancesZero;
import com.healogics.encode.entity.PatientInsurance;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.PlaceOfServiceDetails;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.entity.SuperbillVariance;
import com.healogics.encode.entity.UserPreference;
import com.healogics.encode.entity.WeeklyIncompleteReportEmail;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.service.AppNotificationBO;
import com.healogics.encode.util.FilterRequestUtil;
import java.sql.Timestamp;
import java.time.LocalDate;

@Repository
@Transactional
public class DashboardDAOImpl implements DashboardDAO {

	private final Logger log = LoggerFactory.getLogger(DashboardDAOImpl.class);

	private final SessionFactory sessionFactory;
	private final AppNotificationBO appNotificationBO;
	private Environment env;

	@Autowired
	public DashboardDAOImpl(SessionFactory sessionFactory,
			Environment env,
			AppNotificationBO appNotificationBO) {
		this.sessionFactory = sessionFactory;
		this.appNotificationBO = appNotificationBO;
		this.env = env;
		
	}

	@Override
	public void savePending(SaveRecordReq req, String status)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			String chartnotes = req.getPendReason();
			String hql = "UPDATE Dashboard d SET d.status = :status,"
					+ " d.pendReason = :pendReason,"
					+ " d.lastStatusChangeRole = :lastStatusChangeRole,"
					+ " d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp,"
					+ " d.lastUpdatedByUsername = :lastUpdatedByUsername,"
					+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
					+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName, "
					+ " d.statusChangeTimestamp = :statusChangeTimestamp, "
					+ " d.cmcNotes = :cmcNotes"
					+ " WHERE d.visitId = :visitId";

			Query query = session.createQuery(hql);
			query.setParameter("status", status);
			query.setParameter("pendReason", req.getPendReason());
			query.setParameter("lastStatusChangeRole", "CMC");
			query.setParameter("lastUpdatedByTimestamp",
					new Timestamp(System.currentTimeMillis()));
			query.setParameter("lastUpdatedByUsername", req.getUserName());
			query.setParameter("lastUpdatedByUserId", req.getUserId());
			query.setParameter("lastUpdatedByUserFullName", req.getUserFullName());
			query.setParameter("statusChangeTimestamp",
 					new Timestamp(System.currentTimeMillis()));
			query.setParameter("cmcNotes", chartnotes);
			query.setParameter("visitId", req.getVisitId());
			int rowsAffected = query.executeUpdate();
			
			String updateChartDetailsHql = "UPDATE ChartDetails c SET c.pendProviderId = :pendProviderId,"
	                + " c.pendProviderName = :pendProviderName"
	                + " WHERE c.visitId = :visitId";
	 
	        Query chartDetailsQuery = session.createQuery(updateChartDetailsHql);
	        chartDetailsQuery.setParameter("pendProviderId", req.getPendProviderId());
	        chartDetailsQuery.setParameter("pendProviderName", req.getPendProviderName());
	        chartDetailsQuery.setParameter("visitId", req.getVisitId());
	 
	        int chartDetailsRowsAffected = chartDetailsQuery.executeUpdate();

			Notes userNotes = new Notes();
			String notesDescription = String.format("Pending - %s ",
					req.getPendReason());
			userNotes.setDescription(notesDescription);
			userNotes.setPatientId(req.getPatientId());
			userNotes.setUserRole(req.getUserRole());
			userNotes.setVisitId(req.getVisitId());
			userNotes.setCreatedTimestamp(currentTime);
			userNotes.setUserName(req.getUserName());
			userNotes.setUserFullName(req.getUserFullName());
			userNotes.setCreatorUserId(Integer.valueOf(req.getUserId()));
			session.save(userNotes);
			int noteId = userNotes.getNoteId();
			log.debug("Generated NoteId: ", noteId);

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with Pending Status");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
			
		    if (chartDetailsRowsAffected > 0) {
	            log.info("ChartDetails updated successfully with pendProviderId and pendProviderName");
	        } else {
	            log.info("No rows were affected while updating the ChartDetails.");
	        }
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
 
	@Override
	public void saveUnbillable(SaveRecordReq req, String status) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			String chartnotes = req.getUnbillableReason();
			String hql = "UPDATE Dashboard d SET d.status = :status,"
					+ " d.unbillableReason = :unbillableReason,"
					+ " d.lastStatusChangeRole = :lastStatusChangeRole,"
					+ " d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp,"
					+ " d.lastUpdatedByUsername = :lastUpdatedByUsername,"
					+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
					+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName, "
					+ " d.statusChangeTimestamp = :statusChangeTimestamp, "
					+ " d.cmcNotes = :cmcNotes"
					+ " WHERE d.visitId = :visitId";

			Query query = session.createQuery(hql);
			query.setParameter("status", status);
			query.setParameter("unbillableReason", req.getUnbillableReason());
			query.setParameter("lastStatusChangeRole", "CMC");
			query.setParameter("lastUpdatedByTimestamp",
					new Timestamp(System.currentTimeMillis()));
			query.setParameter("lastUpdatedByUsername", req.getUserName());
			query.setParameter("lastUpdatedByUserId", req.getUserId());
			query.setParameter("lastUpdatedByUserFullName", req.getUserFullName());
			query.setParameter("statusChangeTimestamp",
 					new Timestamp(System.currentTimeMillis()));
			query.setParameter("cmcNotes", chartnotes);
			query.setParameter("visitId", req.getVisitId());
			int rowsAffected = query.executeUpdate();

			Notes userNotes = new Notes();
			String notesDescription = String.format("Unbillable - %s ",
					req.getUnbillableReason());
			userNotes.setDescription(notesDescription);
			userNotes.setPatientId(req.getPatientId());
			userNotes.setUserRole(req.getUserRole());
			userNotes.setVisitId(req.getVisitId());
			userNotes.setCreatedTimestamp(currentTime);
			userNotes.setUserName(req.getUserName());
			userNotes.setUserFullName(req.getUserFullName());
			userNotes.setCreatorUserId(Integer.valueOf(req.getUserId()));
			session.save(userNotes);
			int noteId = userNotes.getNoteId();
			log.debug("Generated NoteId: ", noteId);

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with Unbillable Status");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public void saveValidate(SaveRecordReq req, String status)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "UPDATE Dashboard d SET d.status = :status,"
					+ " d.lastStatusChangeRole = :lastStatusChangeRole,"
					+ " d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp,"
					+ " d.lastUpdatedByUsername = :lastUpdatedByUsername,"
					+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
					+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName,"
					+ " d.statusChangeTimestamp = :statusChangeTimestamp, "
					+ " d.validatedCMCUser = :lastUpdatedByUserFullName"
					+ " WHERE d.visitId = :visitId";

			Query query = session.createQuery(hql);
			query.setParameter("status", status);
			query.setParameter("lastStatusChangeRole", "Coder");
			query.setParameter("lastUpdatedByTimestamp",
					new Timestamp(System.currentTimeMillis()));
			query.setParameter("lastUpdatedByUsername", req.getUserName());
			query.setParameter("lastUpdatedByUserId", req.getUserId());
			String validatedCMCUser = req.getUserLastName() + ", " + req.getUserFirstName();
			query.setParameter("statusChangeTimestamp",
 					new Timestamp(System.currentTimeMillis()));
			query.setParameter("lastUpdatedByUserFullName", validatedCMCUser);
			query.setParameter("lastUpdatedByUserFullName", validatedCMCUser);
			query.setParameter("visitId", req.getVisitId());
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with Validated Status");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public Dashboard getRecordByVisitId(long visitId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Dashboard record = null;
		try {
			String hql = "FROM Dashboard a WHERE a.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);

			record = (Dashboard) query.uniqueResult();
			
			log.info("record: {}", record);

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}
	
	@Override
	public DisparateFacilities getDisparateBBC(String bbc) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		DisparateFacilities disparateFacilities = null;
		try {
			String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
			disparateFacilities = session
					.createQuery(hqlDisparate, DisparateFacilities.class)
					.setParameter("bluebookId", bbc).setMaxResults(1)
					.uniqueResult();

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return disparateFacilities;
	}

	@Override
	public int getFacilityIdByBBC(String facilityCode) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Integer facilityId = null;
		try {
			String hql = "SELECT fd.facilityId FROM FacilityDetails fd WHERE fd.bluebookId = :facilityCode AND fd.active = 1";
			Query query = session.createQuery(hql);
			query.setParameter("facilityCode", facilityCode);
			facilityId = (Integer) query.uniqueResult();
		} catch (Exception e) {
			throw new EncodeExceptionHandler("Error retrieving facility ID for code: " + facilityCode, e);
		}
		return facilityId ;
	}
	
	@Override
	public ChartDetails getChartRecordByVisitId(long visitId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		ChartDetails record = null;
		try {
			String hql = "FROM ChartDetails a WHERE a.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);

			record = (ChartDetails) query.uniqueResult();

			log.info("record: {}", record);

		} catch (Exception e) {
			log.error("Exception in getCoderRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}
	
	@Override
	public ChartDetails getChartRecordByMessageId(Long messageId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		ChartDetails record = null;
		try {
			String hql = "FROM ChartDetails a WHERE a.messageId = :messageId";
			Query query = session.createQuery(hql);
			query.setParameter("messageId", messageId);

			record = (ChartDetails) query.uniqueResult();

			log.info("record", record);

		} catch (Exception e) {
			log.error("Exception in getCoderRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}

	@Override
	public long fetchNextRecord(String userRole, List<String> bbcList,Timestamp dosTimestamp,
	Timestamp nextDaytTimestamp, Long visitids) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long visitId = 0L;

		switch (userRole) {
		case "CMC": {
			try {
				String hql = "SELECT d.visitId FROM Dashboard d " 
						+ "WHERE d.status IN ('New','Returned') "
						+ "AND d.status != 'Unbillable' " 
						+ "AND d.lastStatusChangeRole = 'CMC' "
						+ "AND d.bluebookId IN :bbcList "
						+ "ORDER BY d.receivedDate ASC";
				log.info("query .............: {}", hql.toString());

				Object visitIdObj = session.createQuery(hql).setParameter(
						"bbcList", bbcList).setMaxResults(1)
						.uniqueResult();
				log.info("query .............: {}", hql);
				log.info("visitIdObj : " + visitIdObj);

				if (visitIdObj != null) {
					visitId =  (long)visitIdObj;
				}

			} catch (Exception e) {
				log.error("Exception in while fetching next available record for CMC : {}",
						e.getMessage());
			}
		}
			break;

		case "Coder": {
			try {
				/**
				 * isLocked = 0 - Record is not locked Passing bbcList on which
				 * user have access Excluded below statuses for Coder, Escalated
				 * In Audit
				 */

				String mostrecentbbc = "SELECT snfLocationBBC FROM Dashboard " 
								+ "WHERE visitId = :visitId "
					        	+ "AND bluebookId IN :bbcList";

				Object bbcObj = session.createQuery(mostrecentbbc).setParameter("visitId", visitids)
						.setParameter("bbcList", bbcList).uniqueResult();
				log.info("fetch bbcObj...... {}", bbcObj);
				if (bbcObj != null) {
					String bbc = (String) bbcObj;

					String hql = "SELECT visitId FROM Dashboard" + " WHERE status IN ('Ready','Returned')"
								+ " AND lastStatusChangeRole = 'Coder'" 
								+ " AND snfLocationBBC = :bbc "
								+ " AND visitId != :visitId" 
								+ " AND dateOfService > :dateOfService"
								+ " AND dateOfService < :nextDayDateOfService"
								+ " AND isLocked = '0' order by receivedDate asc";

						Object visitIdObj = session.createQuery(hql).setParameter("bbc", bbc)
								.setParameter("visitId", visitids)
								.setParameter("dateOfService", dosTimestamp)
								.setParameter("nextDayDateOfService", nextDaytTimestamp).setMaxResults(1)
								.uniqueResult();
						log.info("query =====================: {}", hql);
						log.info("visitIdObj : " + visitIdObj);

						if (visitIdObj != null) {
							visitId = (long) visitIdObj;
						}

						if (visitIdObj == null) {

							hql = "SELECT visitId FROM Dashboard" 
							+ " WHERE status IN ('Ready','Returned')"
							+ " AND lastStatusChangeRole = 'Coder'" 
							+ " AND snfLocationBBC = :bbc "
							+ " AND isLocked = '0' order by receivedDate asc";

							visitIdObj = session.createQuery(hql)
								.setParameter("bbc", bbc)
								.setMaxResults(1).uniqueResult();
							log.info("query ...................: {}", hql);
							log.info("visitIdObj : " + visitIdObj);

							if (visitIdObj != null) {
								visitId = (long) visitIdObj;
							}
							if (visitIdObj == null) {

								hql = "SELECT visitId FROM Dashboard" 
								+ " WHERE status IN ('Ready','Returned')"
								+ " AND lastStatusChangeRole = 'Coder'" 
								+ " AND snfLocationBBC IN :bbcList "
								+ " AND isLocked = '0' order by receivedDate asc";

								log.info("query.......: {}", hql.toString());

								visitIdObj = session.createQuery(hql)
										.setParameter("bbcList", bbcList)
										.setMaxResults(1)
										.uniqueResult();
								log.info("visitIdObj : " + visitIdObj);

								if (visitIdObj != null) {
								visitId = (long) visitIdObj;
							}
						}
					}
				}
			} catch (Exception e) {
				log.error("Exception in while fetching next available record for Coder : {}", e.getMessage());
			}
		}
			break;

		default:
			break;

		}
		return visitId;
	}

	@Override
	public void savePatientRecords(Dashboard dasboardObj, String doctype, String docContent, String docName,
			String docSource, Timestamp receivedTimestamp, boolean isRecordExists, PatientMedicalRecords pntMedRecord)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			if (isRecordExists) {
				String hql = "UPDATE PatientMedicalRecords d " + " SET d.documentContent = :documentContent,"
						+ " d.lastUpdatedTimestamp = :lastUpdatedTimestamp," + " d.eventDatetime = :eventDatetime,"
						+ " d.receivedTimestamp = :receivedTimestamp, " + " d.isDocumentUpdated = 1"
						+ " WHERE d.patientId = :patientId" + " AND d.visitId = :visitId"
						+ " AND d.documentType = :documentType" + " AND d.documentId = :documentId";

				Query query = session.createQuery(hql);
				query.setParameter("documentContent", docContent);
				query.setParameter("lastUpdatedTimestamp", new Timestamp(System.currentTimeMillis()));
				query.setParameter("eventDatetime", new Timestamp(System.currentTimeMillis()));
				query.setParameter("receivedTimestamp", receivedTimestamp);
				query.setParameter("patientId", dasboardObj.getPatientId());
				query.setParameter("visitId", dasboardObj.getVisitId());
				query.setParameter("documentType", doctype);
				query.setParameter("documentId", pntMedRecord.getDocumentId());
				int rowsAffected = query.executeUpdate();

				if (rowsAffected > 0) {
					log.info("PatientMedicalRecords updated successfully with new Document Content");
				} else {
					log.info("No rows were affected while updating the dashboard.");
				}
			} else {
				PatientMedicalRecords pmr = new PatientMedicalRecords();
				pmr.setPatientId(dasboardObj.getPatientId());
				pmr.setVisitId(dasboardObj.getVisitId());
				pmr.setDocumentType(doctype);
				pmr.setDocumentId(UUID.randomUUID().toString());
				pmr.setBluebookId(dasboardObj.getBluebookId());
				pmr.setDocumentContent(docContent);
				pmr.setDocumentName(docName);
				pmr.setDocumentSource(docSource);
				pmr.setEventDatetime(new Timestamp(System.currentTimeMillis()));
				pmr.setFacilityId(dasboardObj.getFacilityId());
				pmr.setIsDocumentUpdated(0);
				pmr.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
				// pmr.setPatientDob();
				pmr.setPatientDos(dasboardObj.getDateOfService());
				pmr.setPatientFullname(dasboardObj.getPatientLastName() + ", " + dasboardObj.getPatientFirstName());
				pmr.setPatientId(dasboardObj.getPatientId());
				pmr.setReceivedTimestamp(receivedTimestamp);
				
				log.debug("pmr obj - #####: " +pmr);

				session.save(pmr);
			}

		} catch (Exception e) {
			log.error("Exception in savePatientRecords : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public void saveNotificationStatus(Notification notification) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();

		try {
			session.save(notification);
		} catch (Exception e) {
			log.error("Exception in saveNotificationStatus : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public void savePatientBalancesZero(ParsedDataDTO parsedData, Timestamp receivedTimestamp, String errorCode, String errorMessage) throws EncodeExceptionHandler{
		Session session = this.sessionFactory.getCurrentSession();
		//SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		try {
	     //   Map<String, String> rowData = parsedData.getRowData();
	      
	        PatientBalancesZero patientBalancesZero = new PatientBalancesZero();
	 
	        patientBalancesZero.setPatientName(parsedData.getPatientName());
	        patientBalancesZero.setPatientAcctNo(parsedData.getPatientAcctNo());
	        patientBalancesZero.setLsBillingNumber(parsedData.getLsBillingNumber());
	        String dobStr = parsedData.getPatientDOB();
	        log.info("dobStr : {} ",dobStr);
	        if (dobStr != null && !dobStr.trim().isEmpty()) {
	            Date dob = null;
	            // List of supported date formats
	            String[] dateFormats = {"yyyy-MM-dd", "M/d/yyyy", "MM/dd/yyyy"};
	            for (String format : dateFormats) {
	                try {
	                    SimpleDateFormat dateFormat = new SimpleDateFormat(format);
	                    dateFormat.setLenient(false);
	                    dob = dateFormat.parse(dobStr.trim());
	                    log.info("dob : {} ",dob);
	                    break; // Exit loop once parsed successfully
	                } catch (ParseException e) {
	                    log.error("Trying format {} for DOB '{}'", format, dobStr);
	                }
	            }
	         
	            if (dob != null) {
	                patientBalancesZero.setPatientDOB(dob);
	            } else {
	                log.error("Error parsing Patient DOB: '{}'. Invalid format.", dobStr);
	                patientBalancesZero.setPatientDOB(null);
	            }
	        }

	      //  patientBalancesZero.setPatientDOB(dob);
	        patientBalancesZero.setBbc(parsedData.getFacilityCode());
	        patientBalancesZero.setPreviousBalance(parsedData.getPreviousBalance());
	        patientBalancesZero.setCurrentBalance(parsedData.getCurrentBalance());
	        patientBalancesZero.setReceivedTimestamp(receivedTimestamp);
	        patientBalancesZero.setSentToIheal(1);
	        patientBalancesZero.setErrorCode(errorCode);
	        patientBalancesZero.setErrorMessage(errorMessage);
	        patientBalancesZero.setSentTimestamp(new Timestamp(System.currentTimeMillis()));
	 
	        session.save(patientBalancesZero);
	        log.info("Saved PatientBalancesZero with ID: {} "+patientBalancesZero.getId());
		} catch (Exception e) {
			log.error("Exception in savePatientBalancesZero : {} " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public void savePatientBalancesLatestDOS(ParsedDataDTO parsedData, Timestamp receivedTimestamp, String errorCode, String errorMessage)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		//SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		try {

			PatientBalancesLatestDOS patientBalancesLatestDOS = new PatientBalancesLatestDOS();

			patientBalancesLatestDOS.setFacilityName(parsedData.getFacility());
			patientBalancesLatestDOS.setClaimPatient(parsedData.getClaimPatient());
			patientBalancesLatestDOS.setBbc(parsedData.getFacilityCode());
			patientBalancesLatestDOS.setPatientName(parsedData.getPatientName());
			patientBalancesLatestDOS.setPatientAccNo(parsedData.getPatientAcctNo());
			patientBalancesLatestDOS.setLsBillingNumber(parsedData.getLsBillingNumber());
			patientBalancesLatestDOS.setPatientDOB(parsedData.getPatientDOB());
			patientBalancesLatestDOS.setPatientCellPhone(parsedData.getPatientCellPhone());
			patientBalancesLatestDOS.setPatientHomePhone(parsedData.getPatientHomePhone());
			patientBalancesLatestDOS.setPatientEmail(parsedData.getEmail());
			patientBalancesLatestDOS.setPatientAddress(parsedData.getPatientAddress());
			

//			String dosStr = parsedData.getLatestDateOfService();
//			Date dos = null;
//			try {
//				if (dosStr != null && !dosStr.isEmpty()) {
//					dos = dateFormat.parse(dosStr);
//				}
//			} catch (ParseException e) {
//				log.error("Error parsing Patient DOS: " + e.getMessage());
//			}
//			patientBalancesLatestDOS.setLatestDOS(dos);
 
			 String dosStr = parsedData.getLatestDateOfService();
		        log.info("dosStr : {} ",dosStr);
		        if (dosStr != null && !dosStr.trim().isEmpty()) {
		            Date dos = null;
		            // List of supported date formats
		            String[] dateFormats = {"yyyy-MM-dd", "M/d/yyyy", "MM/dd/yyyy"};
		            for (String format : dateFormats) {
		                try {
		                    SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		                    dateFormat.setLenient(false);
		                    dos = dateFormat.parse(dosStr.trim());
		                    log.info("dos : {} ",dos);
		                    break; // Exit loop once parsed successfully
		                } catch (ParseException e) {
		                    log.error("Trying format {} for DOS '{}'", format, dosStr);
		                }
		            }
		         
		            if (dos != null) {
		            	patientBalancesLatestDOS.setLatestDOS(dos);
		            } else {
		                log.error("Error parsing Patient DOS: '{}'. Invalid format.", dosStr);
		                patientBalancesLatestDOS.setLatestDOS(null);
		            }
		        }

			patientBalancesLatestDOS.setBalance(parsedData.getBalance());
			patientBalancesLatestDOS.setTotalBalance(parsedData.getTotalBalance());
			patientBalancesLatestDOS.setTotalPercentage(parsedData.getTotalPercentage());
			patientBalancesLatestDOS.setReceivedTimestamp(receivedTimestamp);
			patientBalancesLatestDOS.setErrorCode(errorCode);
			patientBalancesLatestDOS.setErrorMessage(errorMessage);
			patientBalancesLatestDOS.setSentToIheal(1);
			patientBalancesLatestDOS.setSentTimestamp(new Timestamp(System.currentTimeMillis()));

			session.save(patientBalancesLatestDOS);
			log.info("Saved savePatientBalancesLatestDOS with ID: {} " + patientBalancesLatestDOS.getId());
		} catch (Exception e) {
			log.error("Exception in savePatientBalancesLatestDOS : {} " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public void savePatientBalancesSummary(ParsedDataDTO parsedData, Timestamp receivedTimestamp,
			String errorCode, String errorMessage) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();

		try {
			PatientBalancesLatestDOS patientBalancesLatestDOS = new PatientBalancesLatestDOS();
			
            patientBalancesLatestDOS.setPatientName(parsedData.getPatientName());
        	patientBalancesLatestDOS.setBbc(parsedData.getFacilityCode());
            patientBalancesLatestDOS.setLsBillingNumber(parsedData.getLsBillingNumber());
			patientBalancesLatestDOS.setPatientDOB(parsedData.getPatientDOB());
			patientBalancesLatestDOS.setBalance(parsedData.getBalance());
			
			patientBalancesLatestDOS.setReceivedTimestamp(receivedTimestamp);
			patientBalancesLatestDOS.setErrorCode(errorCode);
			patientBalancesLatestDOS.setErrorMessage(errorMessage);
			patientBalancesLatestDOS.setSentToIheal(1);
			patientBalancesLatestDOS.setSentTimestamp(new Timestamp(System.currentTimeMillis()));

			String dosStr = parsedData.getLatestDateOfService();
			log.info("dosStr : {} ", dosStr);
			
			if (dosStr != null && !dosStr.trim().isEmpty()) {
				Date dos = null;
				// List of supported date formats
				String[] dateFormats = { "yyyy-MM-dd", "M/d/yyyy", "MM/dd/yyyy" };
				for (String format : dateFormats) {
					try {
						SimpleDateFormat dateFormat = new SimpleDateFormat(format);
						dateFormat.setLenient(false);
						dos = dateFormat.parse(dosStr.trim());
						log.info("dos : {} ", dos);
						break; // Exit loop once parsed successfully
					} catch (ParseException e) {
						log.error("Trying format {} for DOS '{}'", format, dosStr);
					}
				}

				if (dos != null) {
					patientBalancesLatestDOS.setLatestDOS(dos);
				} else {
					log.error("Error parsing Patient DOS: '{}'. Invalid format.", dosStr);
					patientBalancesLatestDOS.setLatestDOS(null);
				}
			}

			session.save(patientBalancesLatestDOS);
			log.info("Saved savePatientBalancesSummary with ID: {} " + patientBalancesLatestDOS.getId());
		} catch (Exception e) {
			log.error("Exception in savePatientBalancesSummary : {} " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public int saveNotes(NotesReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		int noteId = 0;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			Notes userNotes = new Notes();
			userNotes.setDescription(req.getDescription());
			userNotes.setPatientId(req.getPatientId());
			userNotes.setUserRole(req.getUserRole());
			userNotes.setVisitId(req.getVisitId());
			userNotes.setCreatedTimestamp(currentTime);
			userNotes.setUserName(req.getUserName());
			userNotes.setUserFullName(req.getUserFullName());
			userNotes.setCreatorUserId(req.getCreatorUserId());
			session.save(userNotes);

			noteId = userNotes.getNoteId();
			log.debug("Generated NoteId: {}", noteId);
			
			if(req.getUserRole().equals("Coder") || req.getUserRole().equals("TeamLead")) {
			updateCoderDashboardNotes(session, userNotes.getDescription(), userNotes.getVisitId());
			}else{
			updateCMCDashboardNotes(session, userNotes.getDescription(), userNotes.getVisitId());
			}
			/*
			 * if (req.getUserTaggedInNotes() != null &&
			 * req.getUserTaggedInNotes() == true) {
			 * appNotificationBO.saveAppNotifications(req, noteId); }
			 */
		} catch (Exception e) {
			log.error("Exception occured while saving notes:  {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return noteId;
	}

	private void updateCMCDashboardNotes(Session session, String lastSavedNotes, Long visitId) {
		try {
			String hql = "UPDATE Dashboard d SET d.cmcNotes = :lastSavedNotes" + " WHERE d.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("lastSavedNotes", lastSavedNotes);
			query.setParameter("visitId", visitId);
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with last saved notes.");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}

		} catch (Exception e) {
			log.error("Exception occured while updating dashboard with last saved notes: {}", e.getMessage());
		}

	}
	
	private void updateCoderDashboardNotes(Session session, String lastSavedNotes, Long visitId) {
		try {
			String hql = "UPDATE Dashboard d SET d.coderNotes = :lastSavedNotes" + " WHERE d.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("lastSavedNotes", lastSavedNotes);
			query.setParameter("visitId", visitId);
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with last saved notes For coder.");
			} else {
				log.info("No rows were affected while updating the dashboard For coder.");
			}

		} catch (Exception e) {
			log.error("Exception occured while updating dashboard with last saved notes For coder: {}", e.getMessage());
		}

	}

	@Override
	public List<Notes> getCMCRetrieveNote(NoteListReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Notes> retrieveNotes = new ArrayList<>();

		try {
			String hql = "FROM Notes WHERE visitId = :visitId AND userRole IN ('CMC', 'Coder', 'Nurse', 'Auditor')" + " order by createdTimestamp desc";
			  
			log.info("query : {}", hql);
			retrieveNotes = session.createQuery(hql).setParameter("visitId", req.getVisitId())
					.setFirstResult(req.getIndex()).setMaxResults(NOTE_SIZE).list();

			log.info("query : {}", hql);
		} catch (Exception e) {
			log.error("Exception occurred while retrieving note  details for userRole: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return retrieveNotes;
	}
	
	@Override
	public List<Notes> getRetrieveNote(NoteListReq req) throws EncodeExceptionHandler {
	    Session session = this.sessionFactory.getCurrentSession();
	    List<Notes> retrieveNotes = new ArrayList<>();
	 
	    try {
	        // Create a dynamic query based on the provided user roles
	        String hql = "FROM Notes WHERE visitId = :visitId AND userRole IN (:userRoles) ORDER BY createdTimestamp DESC";
	        log.info("query : {}", hql);
	 
	        // Create the query
	        Query<Notes> query = session.createQuery(hql, Notes.class)
	                .setParameter("visitId", req.getVisitId())
	                .setParameterList("userRoles", req.getUserRoles()) 
	                .setFirstResult(req.getIndex())
	                .setMaxResults(NOTE_SIZE);
	       
	        retrieveNotes = query.list();
	        log.info("Retrieved notes: {}", retrieveNotes);
	    } catch (Exception e) {
	        log.error("Exception occurred while retrieving note details for userRole: {}", e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	 
	    return retrieveNotes;
	}


	public Long getTotalCount(NoteListReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;

		try {
			String hql = "SELECT count(*) FROM Notes a WHERE a.visitId = :visitId";

			log.info("query1 : {}", hql);

			totalCount = (Long) session.createQuery(hql).setParameter("visitId", req.getVisitId()).uniqueResult();
			log.debug("totalCount :" + totalCount);
		} catch (Exception e) {
			log.error("Exception occured while fetching CMC Dashboard total count : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}
	
	@Override
	public Notes getNoteByNoteId(Long visitId, int noteId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Notes note = new Notes();

		try {
			String hql = "FROM Notes n WHERE n.noteId = :noteId AND n.visitId = :visitId";

			log.info("query : {}", hql);
			note = (Notes) session.createQuery(hql)
					.setParameter("noteId", noteId)
					.setParameter("visitId", visitId)
					.uniqueResult();

		} catch (Exception e) {
			log.error("Exception occurred while retrieving note details by noteId: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return note;
	}

	@Override
	public Reasons getWeaknessReasons() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons weaknessReasons = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "coder");
			query.setParameter("title", "weakness");
			weaknessReasons = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all weakness reasons: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return weaknessReasons;
	}
	
	@Override
	public Map<String, Object> getLastAppliedFilter(long userId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> filtersObject = new HashMap<String, Object>();
		try {
			String hql = "FROM UserPreference WHERE userId = :userId";
			log.debug("userId:  {}",userId);
			Query query = session.createQuery(hql);
			query.setParameter("userId", userId);
			UserPreference lastAppliedFilter = (UserPreference) query.uniqueResult();
			log.debug("UserPreference: {}",lastAppliedFilter);
			if (lastAppliedFilter != null) {
				if(lastAppliedFilter.getFilters() != null) {
				String filtersJson = lastAppliedFilter.getFilters();
				filtersObject = objectMapper.readValue(filtersJson,
						new TypeReference<Map<String, Object>>() {});
				}
//				Map<String, Object> response = new HashMap<>();
//				response.put("MY", filtersObject);
       			log.info("Response : {} ", filtersObject);
			}
		} catch (JsonProcessingException e) {
			log.error("Error processing JSON while fetching last applied filter: {} ", e.getMessage());
			throw new EncodeExceptionHandler("Error processing JSON while fetching last applied filter", e);
		} catch (Exception e) {
			log.error("Exception occurred while fetching last applied filter: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filtersObject;
	}


	@Override
	public void saveChartDetails(ChartDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);

		//Removing patientId from query since visitId is the only key
		String hql = "FROM ChartDetails WHERE visitId = :visitId";
		Query<ChartDetails> query = session.createQuery(hql, ChartDetails.class);
		//query.setParameter("patientId", req.getPatientId());
		query.setParameter("visitId", req.getVisitId());
		ChartDetails existingRecord = query.uniqueResult();
		switch (req.getAction()) {

		case "Escalation":
			performEscalationAction(req, existingRecord, session, currentTime);
			break;

		case "Weakness":
			performWeaknessAction(req, existingRecord, session, currentTime);
			break;

		case "Deficiency":
			log.debug("inside Deviciency block...........");
			performDeficiencyAction(req, existingRecord, session, currentTime);
			break;

		case "SaveChart":
			performSaveAction(req, existingRecord, session, currentTime);
			break;

		case "Complete":
			performSaveAction(req, existingRecord, session, currentTime);
			performCompleteAction(req, existingRecord, session, currentTime);
			saveInAuditFiltersSource(req, existingRecord, session, currentTime);
			saveFinancialTransaction(req, existingRecord, session, currentTime);
			break;

		case "Unbillable":
			performUnbillableAction(req, session, currentTime);
			break;

		case "Returned":
			performReturnedAction(req, existingRecord, session, currentTime);
			break;
			
		case "validation":
			performValidationAction(req, existingRecord, session, currentTime);
			break;
			
		case "MarkAsReady":
			log.info("MarkAsReady action started");
			performReadyAction(req, session, currentTime);
			break;

		default:
			break;
		}
	}
	//
	private void performReadyAction(ChartDetailsReq req, Session session, Timestamp currentTime) {
		try {

			String hql = "UPDATE Dashboard d SET d.status = :status,"
					+ " d.lastStatusChangeRole = :lastStatusChangeRole,"
					+ " d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp,"
					+ " d.lastUpdatedByUsername = :lastUpdatedByUsername,"
					+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
					+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName"
					+ " WHERE d.visitId = :visitId ";

			Query query = session.createQuery(hql);
			log.info(hql);
			query.setParameter("status", "Ready");
			query.setParameter("lastStatusChangeRole", "Coder");
			query.setParameter("lastUpdatedByTimestamp", currentTime);
			query.setParameter("lastUpdatedByUsername", req.getUserName());
			query.setParameter("lastUpdatedByUserId", req.getUserId() + "");
			query.setParameter("lastUpdatedByUserFullName", req.getUserFullname());
			query.setParameter("visitId", req.getVisitId());
//			query.setParameter("patientId", req.getPatientId());

			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with ready Status");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}

		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
		}

		
	}

	private void saveFinancialTransaction(ChartDetailsReq req, ChartDetails existingRecord, Session session,
			Timestamp currentTime)
			throws EncodeExceptionHandler {
		 
		try {
			String deletedCount = "DELETE FROM FinancialTransaction WHERE visitId IN :visitId";
			session.createQuery(deletedCount).setParameter("visitId", req.getVisitId().intValue()).executeUpdate();
			log.info("Deleted {} existing records for visitId: {}", deletedCount, req.getVisitId());
			Dashboard dashboard = session.get(Dashboard.class, req.getVisitId());
			Patient patient = session.get(Patient.class, req.getVisitId());
			Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
			for (CPTChartDetails cptDetail : req.getCptData()) {
				// Skip if cptCode is null, empty, or "99999"
	            if (cptDetail.getCptCode() == null || cptDetail.getCptCode().isEmpty() || "99999".equals(cptDetail.getCptCode())) {
	                log.info("Skipped creating FinancialTransaction for visitId: {}, due to invalid CPT code: {}", req.getVisitId(), cptDetail.getCptCode());
	                continue; // Skip this iteration and move to the next CPT detail
	            }
	            //ENC-7674
	           // Construct diagnosis code with added period only after the first 3 digits
	            List<String> icdCodes = new ArrayList<>();
	            for (ICD10Data icd : cptDetail.getSelectedICDs()) {
	                String icdCode = icd.getCode();
	                // Check if the ICD code has more than 3 digits and insert a period after the first 3 digits
	                if (icdCode != null && icdCode.length() > 3) {
	                    icdCode = icdCode.substring(0, 3) + "." + icdCode.substring(3);
	                }
	                icdCodes.add(icdCode); 
	            }
				
				String diagnosisCode = String.join("~", icdCodes);
				log.debug("Constructed diagnosis code: {}", diagnosisCode);
				
				List<String> modifiers = cptDetail.getModifier();
				List<String> firstTwoLetters = new ArrayList<>();
				if (modifiers != null && !modifiers.isEmpty()) {
			        for (String modifier : modifiers) {
			           
			            if (modifier.length() >= 2) {
			                firstTwoLetters.add(modifier.substring(0, 2));
			            } else {
			                firstTwoLetters.add(modifier); 
			            }
			        }
			    }
			  
			    String modifierCode = String.join("~", firstTwoLetters);
			    log.debug("Constructed modifier code (first two letters): {}", modifierCode);
  
				FinancialTransaction newTransaction = new FinancialTransaction();
				newTransaction.setVisitId(req.getVisitId().intValue());
				newTransaction.setId(getNextTransactionId(req.getVisitId(), session));
				newTransaction.setTransactionCode(cptDetail.getCptCode());
				newTransaction.setTransactionQuantity(String.valueOf(cptDetail.getUnit()));
				newTransaction.setTransactionType("CG");
				newTransaction.setCodedByFamilyName(req.getUserLastname());
				newTransaction.setCodedByGivenName(req.getUserFirstname());
				newTransaction.setProcedureCode(cptDetail.getCptCode());
				newTransaction.setDiagnosisCode(diagnosisCode);
				newTransaction.setModifier(modifierCode);
				newTransaction.setLastUpdatedTimestamp(currentTimestamp);
				if(patient != null){
					newTransaction.setPointOfCare(patient.getBluebookId());
				}

				if (dashboard != null) {
					//newTransaction.setPointOfCare(dashboard.getBluebookId());
					newTransaction.setTransactionDate(String.valueOf(dashboard.getDateOfService()));
					if (req.getProviderId() != null && !req.getProviderId().isEmpty()) {
						newTransaction.setPerformedById(req.getProviderId());
						newTransaction.setPerformedByFullName(req.getProviderName());
					}
					log.debug("Associated dashboard data: {}", dashboard);
				}

				session.save(newTransaction);
				session.flush();
				session.clear();
				log.info("Saved new FinancialTransaction for visitId: {}, transactionCode: {}",
						newTransaction.getVisitId(), newTransaction.getTransactionCode());
			}
			
			log.info("Transaction committed for visitId: {}", req.getVisitId());
			
		} catch (Exception e) {
			log.error("Exception occured while saving financial transaction:  {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

	}
	
	private int getNextTransactionId(Long visitId, Session session) {
	    Integer maxId = (Integer) session
	            .createQuery("SELECT MAX(id) FROM FinancialTransaction WHERE visitId = :visitId")
	            .setParameter("visitId", visitId.intValue())
	            .uniqueResult();
	    return (maxId != null) ? maxId + 1 : 1; 
	}

	private void performValidationAction(ChartDetailsReq req,
			ChartDetails existingRecord,
			Session session, Timestamp currentTime) {
		try {
			if (existingRecord != null) {
				// Update existing record
				existingRecord.setCodingValidations(req.getCptValidations());
				existingRecord.setCoderUserId(req.getUserId());
				existingRecord.setCoderUserName(req.getUserName());
				existingRecord.setLastUpdatedTimestamp(currentTime);
				session.update(existingRecord);
			} else {
				// Insert new record
				ChartDetails newRecord = new ChartDetails();
				newRecord.setPatientId(req.getPatientId());
				newRecord.setVisitId(req.getVisitId());
				newRecord.setCodingValidations(req.getCptValidations());
				newRecord.setCoderUserId(req.getUserId());
				newRecord.setCoderUserName(req.getUserName());
				newRecord.setLastUpdatedTimestamp(currentTime);
				session.save(newRecord);
			}
		} catch (Exception e) {
			log.error("Exception occured : " +e.getMessage());
		}
	}

	private void performEscalationAction(ChartDetailsReq req, ChartDetails existingRecord,
			Session session, Timestamp currentTime) {
		ObjectMapper objectMapper = new ObjectMapper();
		String taggedUsersJson = null;

		try {
			taggedUsersJson = objectMapper.writeValueAsString(req.getTaggedUsers());
		} catch (JsonProcessingException e) {
			log.error("Exception occured : " + e.getMessage());
		}

		if (existingRecord != null) {
			// Update existing record
			existingRecord.setWasEscalated(1);
			existingRecord.setIsEscalated(1);
			existingRecord.setEscalatedUserId(req.getUserId());
 			existingRecord.setEscalatedUsername(req.getUserName());
			existingRecord.setEscalationReason(req.getEscalationReason());
			existingRecord.setEscalationNote(req.getEscalationNote());
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			existingRecord.setTaggedUsers(taggedUsersJson);
			session.update(existingRecord);
		} else {
			// Insert new record
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(req.getPatientId());
			newRecord.setVisitId(req.getVisitId());
			newRecord.setWasEscalated(1);
			newRecord.setIsEscalated(1);
			newRecord.setEscalatedUserId(req.getUserId());
			newRecord.setEscalatedUsername(req.getUserName());
			newRecord.setEscalationReason(req.getEscalationReason());
			newRecord.setEscalationNote(req.getEscalationNote());
			newRecord.setCoderUserName(req.getUserName());
			newRecord.setCoderUserId(req.getUserId());
			newRecord.setLastUpdatedTimestamp(currentTime);
			newRecord.setTaggedUsers(taggedUsersJson);
			session.save(newRecord);
		}

		Notes userNotes = new Notes();

		String notesDescription = String.format("Requested Guidance "
				+ env.getProperty(DAOConstants.ESCALATION_NOTE_SEPARATOR)
				+ " %s " + env.getProperty(DAOConstants.ESCALATION_NOTE_SEPARATOR)
				+ " %s", req.getEscalationReason(), req.getEscalationNote());
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole(req.getUserRole());
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFullname());
		userNotes.setCreatorUserId(req.getUserId().intValue());

		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);
		
		if ("Ready".equalsIgnoreCase(req.getOldStatus()) || "Returned".equalsIgnoreCase(req.getOldStatus())) {
		    log.info("OldStatus is '{}', proceeding with time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());

		    updateDashboardTimeTracking(req.getVisitId(), session, 
		        req.getAction(), req.getUserId(), req.getEndTime());
		} else {
		    log.info("OldStatus is '{}', skipping time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());
		}

		updateDashboardStatus(req.getVisitId(), session, "Escalated", req.getUserFullname(), 
				req.getUserFirstname(),req.getUserLastname(), String.valueOf(req.getUserId()),req);
		

		if (req.getUserTaggedInNotes() != null && req.getUserTaggedInNotes() == true) {
			appNotificationBO.saveEscalateAppNotifications(req);
		}

	}

	private void performReturnedAction(ChartDetailsReq req, ChartDetails existingRecord, Session session,
			Timestamp currentTime) {
	    
		ObjectMapper objectMapper = new ObjectMapper();
		String taggedUsersJson = null;

		try {
			taggedUsersJson = objectMapper.writeValueAsString(req.getTaggedUsers());
		} catch (JsonProcessingException e) {
			log.error("Exception occured : " + e.getMessage());
		}

		if (existingRecord != null) {
			// Update existing record
			existingRecord.setReturnedNote(req.getReturnedNote());
			existingRecord.setReturnedUserName(req.getUserName());
			existingRecord.setReturnedUserId(req.getUserId());
			existingRecord.setReturnedUserFullName(req.getUserFullname());
			// existingRecord.setCoderUserName(req.getUserName());
			// existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			existingRecord.setTaggedUsers(taggedUsersJson);
			session.update(existingRecord);
		} else {
			// Insert new record
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(req.getPatientId());
			newRecord.setVisitId(req.getVisitId());
			newRecord.setReturnedNote(req.getReturnedNote());
			newRecord.setReturnedUserName(req.getUserName());
			newRecord.setReturnedUserId(req.getUserId());
			newRecord.setReturnedUserFullName(req.getUserFullname());
			newRecord.setLastUpdatedTimestamp(currentTime);
			newRecord.setTaggedUsers(taggedUsersJson);
			session.save(newRecord);
		}

		Notes userNotes = new Notes();
		String notesDescription = String.format("Returned "
				+ env.getProperty(DAOConstants.ESCALATION_NOTE_SEPARATOR)
				+ " %s ", req.getReturnedNote());
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole(req.getUserRole());
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFullname());
		userNotes.setCreatorUserId(req.getUserId().intValue());

		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);

		updateDashboardStatus(req.getVisitId(), session, "Returned", req.getUserFullname(), 
				req.getUserFirstname(),req.getUserLastname(), String.valueOf(req.getUserId()),req);

		if (req.getUserTaggedInNotes() != null && req.getUserTaggedInNotes() == true) {
			appNotificationBO.saveEscalateAppNotifications(req);
		}

	}

	private void performWeaknessAction(ChartDetailsReq req, ChartDetails existingRecord,
			Session session, Timestamp currentTime) {

		ObjectMapper objectMapper = new ObjectMapper();
		String weaknessReasonString = null;		
		String icd10Code = req.getIcdData().stream().map(ICD10Data::getCode).collect(Collectors.joining(", "));

		String cptCode = req.getCptData().stream().map(CPTChartDetails::getCptCode).collect(Collectors.joining(", "));

		String modifierData = req.getCptData().stream().flatMap(cpt -> cpt.getModifier().stream())
				.map(modifier -> modifier.split(" ")[0])
				.collect(Collectors.joining(", "));

		String unit = req.getCptData().stream().map(cpt -> String.valueOf(cpt.getUnit()))
				.collect(Collectors.joining(", "));

		String icd10String = null;
		try {
			icd10String = objectMapper.writeValueAsString(req.getIcdData());
		} catch (JsonProcessingException e) {
			log.error("Exception occured  while getting ICD10 data JSON: " + e.getMessage());
		}

		String cptString = null;
		try {
			cptString = objectMapper.writeValueAsString(req.getCptData());
		} catch (JsonProcessingException e) {
			log.error("Exception occured while getting CPT data JSON: " + e.getMessage());
		}

		Date patientAdminDate = null;
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		if (req.getPatientAdmitDate() != null && !req.getPatientAdmitDate().isEmpty()) {
			try {
				patientAdminDate = format.parse(req.getPatientAdmitDate());
			} catch (ParseException e) {
				log.error("Exception occured: " + e.getMessage());
				patientAdminDate = null;
			}
		} else {
			patientAdminDate = null;
		}

		Date accOrIllnessDate = null;
		if (req.getAccidentOrIllnessDate() != null && !req.getAccidentOrIllnessDate().isEmpty()) {
			try {
				accOrIllnessDate = format.parse(req.getAccidentOrIllnessDate());
			} catch (ParseException e) {
				log.error("Exception occured: " + e.getMessage());
				accOrIllnessDate = null;
			}
		} else {
			accOrIllnessDate = null;
		}

		String accidentCategory = "";
		if (req.getAccidentOrIllness() != null
				&& !req.getAccidentOrIllness().isEmpty()
				&& req.getAccidentOrIllness().equalsIgnoreCase("Accident")) {
			accidentCategory = req.getAccidentCategory();
		}

		if (existingRecord != null) {
			// Update existing record
			existingRecord.setProviderName(req.getProviderName());
			existingRecord.setPatientAdmitDate(patientAdminDate);
			existingRecord.setPlaceOfService(req.getPlaceOfService());
			existingRecord.setAccidentOrIllness(req.getAccidentOrIllness());
			existingRecord.setAccidentCategory(accidentCategory);
			existingRecord.setAccidentIllnessDate(accOrIllnessDate);

			existingRecord.setTimeDocChart((req.getTimeDocInChart() == 1) ? 1 : 0);
			existingRecord.setTimeEmLevel((req.getTimeUsedToCodeEMLevel() == 1) ? 1 : 0);

			existingRecord.setIcdCodes(icd10String);
			existingRecord.setCptObject(cptString);
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			session.update(existingRecord);
			
			Dashboard dashboardRecord = session.get(Dashboard.class, existingRecord.getVisitId());
	        if (dashboardRecord != null) {
	            dashboardRecord.setIcdCode(icd10Code);
	            dashboardRecord.setCptCode(cptCode);
	            dashboardRecord.setModifier(modifierData);
	            dashboardRecord.setUnit(unit);
	            session.update(dashboardRecord);
	        } else {
	            Dashboard newDashboardRecord = new Dashboard();
	            newDashboardRecord.setVisitId(existingRecord.getVisitId());
	            newDashboardRecord.setIcdCode(icd10Code);
	            newDashboardRecord.setModifier(modifierData);
	            newDashboardRecord.setUnit(unit);
	            session.save(newDashboardRecord);
	        }
		}
		try {
			weaknessReasonString = objectMapper.writeValueAsString(req.getWeaknessReason());
		} catch (JsonProcessingException e) {
			log.error("Exception occured : " + e.getMessage());
		}

		if (existingRecord != null) {
			// Update existing record
			existingRecord.setProviderCPTCode(req.getProviderCPTCode());
			existingRecord.setWeaknessReason(weaknessReasonString);
			existingRecord.setWeaknessNote(req.getWeaknessNote());
			existingRecord.setCoderCPTCode(req.getCoderCPTCode());
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			session.update(existingRecord);
		} else {
			// Insert new record
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(req.getPatientId());
			newRecord.setVisitId(req.getVisitId());
			newRecord.setProviderCPTCode(req.getProviderCPTCode());
			newRecord.setWeaknessReason(weaknessReasonString);
			newRecord.setWeaknessNote(req.getWeaknessNote());
			newRecord.setCoderCPTCode(req.getCoderCPTCode());
			newRecord.setCoderUserName(req.getUserName());
			newRecord.setCoderUserId(req.getUserId());
			newRecord.setLastUpdatedTimestamp(currentTime);
			session.save(newRecord);
		}
		
		String hql = "FROM SuperbillVariance WHERE visitId = :visitId";
		Query<SuperbillVariance> query = session.createQuery(hql, SuperbillVariance.class);
		//query.setParameter("patientId", req.getPatientId());
		query.setParameter("visitId", req.getVisitId());
		SuperbillVariance existingRecords = query.uniqueResult();
		
		if (existingRecords != null) {
			// Update existing record
			existingRecords.setVarianceReason(weaknessReasonString);
			existingRecords.setComment(req.getWeaknessNote());
			existingRecords.setActualCptCode(req.getCoderCPTCode());
			session.update(existingRecords);
		} else {
			// Insert new record
			SuperbillVariance sb = new SuperbillVariance();
			sb.setVarianceReason(weaknessReasonString);
			sb.setComment(req.getWeaknessNote());
			sb.setActualCptCode(req.getCoderCPTCode());
			session.save(sb);
		}
		
		
		Notes userNotes = new Notes();

		String notesDescription;
		if (req.getWeaknessNote() != null && !req.getWeaknessNote().isEmpty()) {

			notesDescription = String.format("Weakness - %s - %s", req.getWeaknessReason(),
					req.getWeaknessNote());
		} else {
			notesDescription = String.format("Weakness - %s", req.getWeaknessReason());

		}
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole(req.getUserRole());
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFullname());
		userNotes.setCreatorUserId(req.getUserId().intValue());
		
		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);
		
		if ("Ready".equalsIgnoreCase(req.getOldStatus()) || "Returned".equalsIgnoreCase(req.getOldStatus())) {
		    log.info("OldStatus is '{}', proceeding with time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());

		    updateDashboardTimeTracking(req.getVisitId(), session, 
		        req.getAction(), req.getUserId(), req.getEndTime());
		} else {
		    log.info("OldStatus is '{}', skipping time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());
		}
		
		if (req.getUserTaggedInNotes() != null && req.getUserTaggedInNotes() == true) {
			appNotificationBO.saveWeaknessAppNotifications(req);
		}
	}

	private void performDeficiencyAction(ChartDetailsReq req, ChartDetails existingRecord,
			Session session, Timestamp currentTime) {
		ObjectMapper objectMapper = new ObjectMapper();
		String deficiencyString = null;
		try {
			deficiencyString = objectMapper.writeValueAsString(req.getDeficiencyReason());
			log.debug("deficiencyString.........."+deficiencyString);
		} catch (JsonProcessingException e) {
			log.error("Exception occured in performDeficiencyAction: " + e.getMessage());
		}
 
		if (existingRecord != null) {
			existingRecord.setDeficiencyReason(deficiencyString);
			existingRecord.setDeficientProviderUserId(req.getDeficientProviderUserId());
			existingRecord.setDeficientProviderName(req.getDeficientProviderName());
			existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserFullName(req.getUserFullname());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			existingRecord.setDeficientNote(req.getDeficientNote());
			existingRecord.setIsDeficient(1);
			existingRecord.setWasDeficient(1);
			existingRecord.setDeficiencyStartDate(currentTime);
			session.update(existingRecord);
 
		} else {
			ChartDetails chartdetails = new ChartDetails();
			chartdetails.setPatientId(req.getPatientId());
			chartdetails.setVisitId(req.getVisitId());
			chartdetails.setDeficiencyReason(deficiencyString);
			chartdetails.setDeficientProviderUserId(req.getDeficientProviderUserId());
			chartdetails.setDeficientProviderName(req.getDeficientProviderName());
			chartdetails.setCoderUserId(req.getUserId());
			chartdetails.setCoderUserName(req.getUserName());
			chartdetails.setCoderUserFullName(req.getUserFullname());
			chartdetails.setLastUpdatedTimestamp(currentTime);
			chartdetails.setDeficientNote(req.getDeficientNote());
			chartdetails.setIsDeficient(1);
			chartdetails.setWasDeficient(1);
			chartdetails.setDeficiencyStartDate(currentTime);
			session.save(chartdetails);
		}
		
		Notes userNotes = new Notes();
		String notesDescription = String.format("Deficiency - %s - %s",
				req.getDeficiencyReason(), req.getDeficientNote());
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole(req.getUserRole());
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFullname());
		userNotes.setCreatorUserId(req.getUserId().intValue());

		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);
		
		if ("Ready".equalsIgnoreCase(req.getOldStatus()) || "Returned".equalsIgnoreCase(req.getOldStatus())) {
		    log.info("OldStatus is '{}', proceeding with time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());

		    updateDashboardTimeTracking(req.getVisitId(), session, 
		        req.getAction(), req.getUserId(), req.getEndTime());
		} else {
		    log.info("OldStatus is '{}', skipping time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());
		}	
		
		Dashboard dashboard = null;
		try {
			dashboard = getRecordByVisitId(req.getVisitId());
			log.debug("dashboard..........."+dashboard);
		} catch (EncodeExceptionHandler e) {
			log.error("Exception occured: " +e.getMessage());
		}
		
		if (dashboard != null) {
			boolean isIhealConfigMatch = dashboard.getIhealConfig() != null
					&& (dashboard.getIhealConfig().equalsIgnoreCase("OT")
						|| dashboard.getIhealConfig().equalsIgnoreCase("POS")
						|| (dashboard.getIhealConfig().equalsIgnoreCase("EMR")
								&& dashboard.getServiceLine() != null
								&& (dashboard.getServiceLine().equalsIgnoreCase("HSP Inpatient Consult")
										|| dashboard.getServiceLine().equalsIgnoreCase("Inpatient"))));

			if (isIhealConfigMatch && req.getDeficiencyReason() != null
					&& req.getDeficiencyReason().contains("Needs addendum")) {

				updateDashboardStatusforCMC(req.getVisitId(), session, "Pending",
						req.getUserFullname(), String.valueOf(req.getUserId()),
						req.getUserFirstname(), req.getUserLastname(), req);

			} else if (isIhealConfigMatch && req.getDeficiencyReason() != null
					&& !req.getDeficiencyReason().contains("Needs addendum")) {

				updateDashboardStatus(req.getVisitId(), session, "Deficiency",
						req.getUserFullname(), String.valueOf(req.getUserId()),
						req.getUserFirstname(), req.getUserLastname(), req);
				
			} else if (dashboard.getServiceLine() != null
					&& dashboard.getIhealConfig() != null
					&& !"HSP Inpatient Consult".equalsIgnoreCase(dashboard.getServiceLine())
					&& (!"OT".equalsIgnoreCase(dashboard.getIhealConfig()))
					&& (!"POS".equalsIgnoreCase(dashboard.getIhealConfig()))) {
				
				updateDashboardStatus(req.getVisitId(), session, "Deficiency", req.getUserFullname(),
						String.valueOf(req.getUserId()), req.getUserFirstname(), req.getUserLastname(), req);
			} else {
				log.debug("default block of Deficiency");
				log.debug("visitId : " +req.getVisitId());
				log.debug("dashboard.getServiceLine() : " +dashboard.getServiceLine());
				log.debug("dashboard.getIhealConfig() : " +dashboard.getIhealConfig());
				
				updateDashboardStatus(req.getVisitId(), session, "Deficiency", req.getUserFullname(),
						String.valueOf(req.getUserId()), req.getUserFirstname(), req.getUserLastname(), req);
			}
		}
		
	}

	private void updateDashboardStatus(long visitId, Session session,
			String status, String userFullName , String userFirstName, String userLastName, String userId, ChartDetailsReq req) {
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			String hql;
			String lastStatusChangeRole = "Coder";
			
			if ("escalated".equalsIgnoreCase(status)) {
				String auditQuery = "SELECT COUNT(*) FROM AuditQueue WHERE visitId = :visitId";
				Query<Long> queryAudit = session.createQuery(auditQuery, Long.class);
				queryAudit.setParameter("visitId", visitId);
				Long count = queryAudit.uniqueResult();
				if (count == 0) {
					log.info("Visit ID {} not found in audit_queue. Status update for 'escalated' will not proceed.", visitId);
				} else {
					String deleteAuditQueue = "DELETE FROM AuditQueue a WHERE a.visitId = :visitId";
					Query deleteAuditQuery = session.createQuery(deleteAuditQueue);
					deleteAuditQuery.setParameter("visitId", visitId);
					int auditRowsAffected = deleteAuditQuery.executeUpdate();
					if (auditRowsAffected > 0) {
						log.info("Row deleted from audit_queue for visitId: {}", visitId);
					} else {
						log.error("Failed to delete row from audit_queue for visitId: {}", visitId);
					}
				}
			}
	//		
			switch (status.toLowerCase()) {
			case "returned":
				log.info("Status updated as Returned");
				hql = "UPDATE Dashboard d SET d.status = 'Returned', d.isLocked = 0, "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " 
						+ "WHERE d.visitId = :visitId";
				break;
			case "escalated":
				log.info("Status updated as In Review");
				hql = "UPDATE Dashboard d SET d.status = 'In Review', d.isLocked = 1, "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp, " 
						+ "d.coderUserName = :userName, "
						+ "d.coderFirstName = :coderFirstName, "
						+ "d.coderLastName = :coderLastName, "
						+ "d.coderUserId = :userId, "
						+ "d.guidanceNotes = :guidanceNotes, "
						+ "d.reviewReason = :reviewReason, "
						+ "d.guidanceDate = :guidanceDate "
						+ "WHERE d.visitId = :visitId";
				break;
			case "deficiency":
				hql = "UPDATE Dashboard d SET d.status = 'Deficiency', "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " 
						+ "WHERE d.visitId = :visitId";
				break;
			case "completed":
				log.info("Status updated as completed");
				hql = "UPDATE Dashboard d SET d.status = 'Completed', "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp, " 
						+ "d.completedCoderUser = :lastUpdatedByUserFullName, "
						+ "d.completedCoderUserId = :userId, "
						+ "d.coderUserId = :userId, "
						+ "d.coderUserName = :userName, "
						+ "d.coderFirstName = :userFirstName, "
						+ "d.coderLastName = :userLastName, "
						+ "d.team = :codingTeam "
						+ "WHERE d.visitId = :visitId";
				break;
			case "pending":
				log.info("Status updated as Pending");
				hql = "UPDATE Dashboard d SET d.status = 'Pending', d.isLocked = 0, "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.cmcNotes = :cmcNotes, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " 
						+ "WHERE d.visitId = :visitId";
				break;
			default:
				log.error("Unknown status: {}", status);
				return;
			}
			log.info(hql);
			Query query = session.createQuery(hql);
			
			query.setParameter("visitId", visitId);
			query.setParameter("lastStatusChangeRole", lastStatusChangeRole);
			
			if (status.toLowerCase().equalsIgnoreCase("completed")) {
				query.setParameter("lastUpdatedByUserFullName", userFullName);
				query.setParameter("userId", userId);
				query.setParameter("userName", userFullName);
				query.setParameter("userFirstName", userFirstName);
				query.setParameter("userLastName", userLastName);
				query.setParameter("codingTeam", req.getCodingTeam());
			}
			log.debug("query :{}", query);
			if (status.toLowerCase().equalsIgnoreCase("pending")) {
				log.info("Inside pending for cmcNotes");
				query.setParameter("cmcNotes", req.getDeficiencyReason() + " - " + req.getDeficientNote());
				log.info("cmcNotes : {} ",  req.getDeficiencyReason() + " - " + req.getDeficientNote());
			}
			
			if (status.toLowerCase().equalsIgnoreCase("escalated")) {
				query.setParameter("guidanceDate", new Timestamp(System.currentTimeMillis()));
				query.setParameter("userId", userId);
				query.setParameter("userName", req.getUserFullname());
				query.setParameter("coderFirstName", req.getUserFirstname());
				query.setParameter("coderLastName", req.getUserLastname());
				query.setParameter("reviewReason", req.getEscalationReason());
				String escalationNote = req.getEscalationNote().replaceAll("\\[.*?\\]", "").trim();
				query.setParameter("guidanceNotes", req.getEscalationReason() + " - " + escalationNote);
			}
			
			log.debug("lastStatusChangeRole..........."+lastStatusChangeRole);
			query.setParameter("lastUpdatedByTimestamp",
					new Timestamp(System.currentTimeMillis()));
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Status saved Successfully!");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
		} catch (Exception e) {
			log.error("Exception occured while saving status: {}", e.getMessage());
		}
	}
	
	private void updateDashboardStatusforCMC(long visitId, Session session,
			String status, String userFullName , String userFirstName,
			String userLastName, String userId, ChartDetailsReq req) {
		try {
			log.debug("status........"+status);
			String hql;
			String lastStatusChangeRole = "CMC";
			
			switch (status.toLowerCase()) {
			case "pending":
				log.info("Status updated as Pending");
				hql = "UPDATE Dashboard d SET d.status = 'Pending', d.isLocked = 0, "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.cmcNotes = :cmcNotes, "
						+ " d.statusChangeTimestamp = :statusChangeTimestamp, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " 
						+ "WHERE d.visitId = :visitId";
				break;
			default:
				log.error("Unknown status: {}", status);
				return;
			}

			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);
			query.setParameter("lastStatusChangeRole", lastStatusChangeRole);
			query.setParameter("cmcNotes", req.getDeficiencyReason() + " - " + req.getDeficientNote());
			query.setParameter("statusChangeTimestamp",
 					new Timestamp(System.currentTimeMillis()));
			
			if (status.toLowerCase().equalsIgnoreCase("completed")) {
				query.setParameter("lastUpdatedByUserFullName", userFullName);
				query.setParameter("userId", userId);
				query.setParameter("userName", userFullName);
				query.setParameter("userFirstName", userFirstName);
				query.setParameter("userLastName", userLastName);
				
			}
			log.debug("lastStatusChangeRole..........."+lastStatusChangeRole);
			query.setParameter("lastUpdatedByTimestamp",
					new Timestamp(System.currentTimeMillis()));
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Status saved Successfully!");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
		} catch (Exception e) {
			log.error("Exception occured while saving status: {}", e.getMessage());
		}
	}
	
	private long calculateTimeInterval(Timestamp startTime, Timestamp endTime) {
	    log.debug("StartTime from DB: {}", startTime);
	    log.debug("EndTime from DB: {}", endTime);

	    if (startTime != null && endTime != null) {
	        // Normalize timestamps to match database rounding behavior
	        long roundedStartMillis = Math.round(startTime.getTime() / 1000.0) * 1000;
	        long roundedEndMillis = Math.round(endTime.getTime() / 1000.0) * 1000;

	        Timestamp normalizedStartTime = new Timestamp(roundedStartMillis);
	        Timestamp normalizedEndTime = new Timestamp(roundedEndMillis);

	        log.debug("Rounded StartTime (ms): {}", normalizedStartTime);
	        log.debug("Rounded EndTime (ms): {}", normalizedEndTime);

	        // Calculate the time interval
	        long timeInterval = normalizedEndTime.getTime() - normalizedStartTime.getTime();
	        log.debug("Final timeInterval (milliseconds): {}", timeInterval);
	        return timeInterval;
	    }

	    log.warn("StartTime or EndTime is null, returning default timeInterval as 0");
	    return 0; // Default case if either timestamp is null
	}
	
	private void updateDashboardTimeTracking(long visitId, Session session, String action, Long userId, Timestamp endTime) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    try {
	        log.info("Starting updateDashboardTimeTracking for visitId={} and userId={}", visitId, userId);

	        String hql = "FROM Dashboard WHERE visitId = :visitId";
	        Query query = session.createQuery(hql, Dashboard.class);
	        query.setParameter("visitId", visitId);
	        Dashboard dashboardRecord = (Dashboard) query.uniqueResult();

	        log.debug("Fetched dashboardRecord: {}", dashboardRecord);

	        if (dashboardRecord != null) {
	            // Step 1: Store the new endTime **with precise rounding**
	           // Timestamp preciseEndTime = new Timestamp(endTime.getTime());
	            dashboardRecord.setEndTime(endTime);
	            //dashboardRecord.setEndDate(endTime);
	            session.update(dashboardRecord);
	            log.info("Stored precise endTime={} in database for visitId={}", endTime, visitId);

	            // Step 2: Retrieve updated record with rounded timestamps
	            query = session.createQuery(hql, Dashboard.class);
	            query.setParameter("visitId", visitId);
	            dashboardRecord = (Dashboard) query.uniqueResult();

	            Timestamp startTime = dashboardRecord.getStartTime();
	            //Timestamp fetchedEndTime = dashboardRecord.getEndTime();
	            Timestamp storedEndTime = dashboardRecord.getEndTime();

	         // Normalize to match database rounding behavior
	         long roundedMillis = Math.round(storedEndTime.getTime() / 1000.0) * 1000;
	         Timestamp normalizedEndTime = new Timestamp(roundedMillis);

	         log.debug("Fetched exact EndTime from DB (rounded): {}", normalizedEndTime);
	            log.debug("Fetched StartTime from DB: {}", startTime);
	            log.debug("Fetched precise EndTime from DB: {}", normalizedEndTime);

	            long timeInterval = calculateTimeInterval(startTime, normalizedEndTime);
	            log.debug("Calculated timeInterval (in milliseconds): {}", timeInterval);

	            // Preserve existing timeInMs value
	            Long existingTimeInMs = dashboardRecord.getTimeInMs();
	            log.debug("Existing timeInMs: {}", existingTimeInMs);

	            if (existingTimeInMs != null) {
	                timeInterval += existingTimeInMs; // Add previous timeInMs value to new interval
	            }

	            log.debug("Final timeInterval after adding existing timeInMs: {}", timeInterval);

	            // Step 4: Update coderId & timeInMs in the DB
	            dashboardRecord.setCoderId(userId.intValue());
	            dashboardRecord.setTimeInMs(timeInterval);
	            session.update(dashboardRecord);
	            log.info("Successfully updated coderId and timeInMs for visitId={}", visitId);
	        } else {
	            log.warn("No dashboard record found for visitId={}. Creating a new one.", visitId);

	            Dashboard newDashboardRecord = new Dashboard();
	            newDashboardRecord.setVisitId(visitId);
	            newDashboardRecord.setCoderId(userId.intValue());
	            newDashboardRecord.setTimeInMs(0L); // Default to zero if no previous record exists
	            newDashboardRecord.setEndTime(endTime);

	            session.save(newDashboardRecord);
	            log.info("New dashboard record saved successfully for visitId={}", visitId);
	        }

	    } catch (Exception e) {
	        log.error("Exception occurred while updating time tracking for visitId={}: {}", visitId, e.getMessage(), e);
	    }
	}
	
	@Override
	public void updateReturnedStatus(Long visitId, String dashboardName) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "UPDATE Dashboard d SET d.status = 'Returned', d.isLocked = 0, "
					+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
					+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " 
					+ "WHERE d.visitId = :visitId";
		
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);
			query.setParameter("lastStatusChangeRole", dashboardName);
			query.setParameter("lastUpdatedByTimestamp",
					new Timestamp(System.currentTimeMillis()));
			
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Status saved Successfully!");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
			
		} catch (Exception e) {
			log.error("Exception occured while saving Dashboard Status: {}", e.getMessage());
		}
	}
	
	@Override
	public void saveMessageIdInChartDetails(Long visitId, Long messageId) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "UPDATE ChartDetails d SET d.messageId = :messageId" 
					+ " WHERE d.visitId = :visitId";
		
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);
			query.setParameter("messageId", messageId);
			
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Status saved Successfully!");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
			
		} catch (Exception e) {
			log.error("Exception occured while saving Dashboard Status: {}", e.getMessage());
		}
	}

	private void performSaveAction(ChartDetailsReq req, ChartDetails existingRecord, Session session,
			Timestamp currentTime) {
		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		String icd10Code = req.getIcdData().stream().map(ICD10Data::getCode).collect(Collectors.joining(", "));

		String cptCode = req.getCptData().stream().map(CPTChartDetails::getCptCode).collect(Collectors.joining(", "));

		String modifierData = req.getCptData().stream().flatMap(cpt -> cpt.getModifier().stream())
				.map(modifier -> modifier.split(" ")[0])
				.collect(Collectors.joining(", "));

		String unit = req.getCptData().stream().map(cpt -> String.valueOf(cpt.getUnit()))
				.collect(Collectors.joining(", "));

		String icd10String = null;
		try {
			icd10String = objectMapper.writeValueAsString(req.getIcdData());
		} catch (JsonProcessingException e) {
			log.error("Exception occured  while getting ICD10 data JSON: " + e.getMessage());
		}

		String cptString = null;
		try {
			cptString = objectMapper.writeValueAsString(req.getCptData());
		} catch (JsonProcessingException e) {
			log.error("Exception occured while getting CPT data JSON: " + e.getMessage());
		}

		Date patientAdminDate = null;
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		if (req.getPatientAdmitDate() != null && !req.getPatientAdmitDate().isEmpty()) {
			try {
				patientAdminDate = format.parse(req.getPatientAdmitDate());
			} catch (ParseException e) {
				log.error("Exception occured: " + e.getMessage());
				patientAdminDate = null;
			}
		} else {
			patientAdminDate = null;
		}

		Date accOrIllnessDate = null;
		if (req.getAccidentOrIllnessDate() != null && !req.getAccidentOrIllnessDate().isEmpty()) {
			try {
				accOrIllnessDate = format.parse(req.getAccidentOrIllnessDate());
			} catch (ParseException e) {
				log.error("Exception occured: " + e.getMessage());
				accOrIllnessDate = null;
			}
		} else {
			accOrIllnessDate = null;
		}

		String accidentCategory = "";
		if (req.getAccidentOrIllness() != null
				&& !req.getAccidentOrIllness().isEmpty()
				&& req.getAccidentOrIllness().equalsIgnoreCase("Accident")) {
			accidentCategory = req.getAccidentCategory();
		}

		if (existingRecord != null) {
			// Update existing record
			if (req.getProviderId() != null && !req.getProviderId().isEmpty()) {
				existingRecord.setProviderName(req.getProviderLastName() + ", " + req.getProviderFirstName());
				existingRecord.setProviderId(req.getProviderId());
				existingRecord.setProviderFirstName(req.getProviderFirstName());
				existingRecord.setProviderLastName(req.getProviderLastName());
				existingRecord.setProviderFullName(req.getProviderFirstName() + " " + req.getProviderLastName());
			}
			existingRecord.setPatientAdmitDate(patientAdminDate);
			
			try{
				if(req.getProviderId() != null){
				Patient patient = session.get(Patient.class, existingRecord.getVisitId());
				if (patient != null) {
					patient.setAttendingDocId(req.getProviderId());
					patient.setAttendingDocName(req.getProviderFirstName() + " " + req.getProviderLastName());
					patient.setAdmittingDocId(req.getProviderId());
					patient.setAdmittingDocFamilyName(req.getProviderLastName());
					patient.setAdmittingDocGivenName(req.getProviderFirstName());
					patient.setLastUpdatedTimestamp(currentTimestamp);
					session.update(patient);
				}
				}
			}catch(Exception e){
				log.error("Exception occured  while setting provider details : " + e.getMessage());
			}
			// existingRecord.setPlaceOfService(req.getPlaceOfService());
			try{
			String existingPlaceOfService = existingRecord.getPlaceOfService();
			String reqPlaceOfService = req.getPlaceOfService();

			if (reqPlaceOfService != null
					&& (existingPlaceOfService == null || !existingPlaceOfService.equals(reqPlaceOfService))) {
				if ("HSP Inpatient Consult".equals(reqPlaceOfService)) {
					Dashboard dashboardRecord = session.get(Dashboard.class, existingRecord.getVisitId());
					if (dashboardRecord != null) {
						String bluebookId = dashboardRecord.getSnfLocationBBC();
						// Update Patient table with "281_" + bluebookId
						Patient patient = session.get(Patient.class, existingRecord.getVisitId());
						if (patient != null) {
							patient.setBluebookId("281_" + bluebookId);
							patient.setBed("281_" + bluebookId);
							patient.setBirthPlace("281_" + bluebookId);
							patient.setLastUpdatedTimestamp(currentTimestamp);
							session.update(patient);
						}
						// Update PatientInsurance table with new bluebookId
						Long visitId = existingRecord.getVisitId();  // Get the visitId
						
						String hql = "FROM PatientInsurance WHERE visitId = :visitId";
						Query query = session.createQuery(hql);
						query.setParameter("visitId", visitId);  
						 
						// Fetch the list of records
						List<PatientInsurance> patientInsuranceList = query.list();
						 
						// Iterate over the list and update each record
						for (PatientInsurance patientInsurance : patientInsuranceList) {
						    log.info("Patient Insurance: {} ", patientInsurance);
						    if (patientInsurance != null) {
						  
						        patientInsurance.setBluebookId("281_" + bluebookId);
						        patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
			
						        session.update(patientInsurance);
						    }
						}
					}
				} else { 
					Dashboard dashboardRecord = session.get(Dashboard.class, existingRecord.getVisitId());
					if("Skilled Nursing Facility".equals(dashboardRecord.getFacilityType())){
					// If it's a different place of service, find the
					// corresponding posCode
					PlaceOfServiceDetails placeOfServiceDetails = session
							.createQuery("FROM PlaceOfServiceDetails WHERE posName = :posName",
									PlaceOfServiceDetails.class)
							.setParameter("posName", reqPlaceOfService).uniqueResult();
					if (placeOfServiceDetails != null) {
						String posCode = placeOfServiceDetails.getCode();
						
						if (dashboardRecord != null) {
							String bluebookId = dashboardRecord.getSnfLocationBBC();
							
							// Update Patient table with posCode + bluebookId
							Patient patient = session.get(Patient.class, existingRecord.getVisitId());
							if (patient != null) {
								patient.setBluebookId(posCode + bluebookId);
								patient.setBed(posCode + bluebookId);
								patient.setBirthPlace(posCode + bluebookId);
								patient.setLastUpdatedTimestamp(currentTimestamp);
								session.update(patient);
							}
							// Update PatientInsurance table with new bluebookId					 
							Long visitId = existingRecord.getVisitId();  // Get the visitId
					
							String hql = "FROM PatientInsurance WHERE visitId = :visitId";
							Query query = session.createQuery(hql);
							query.setParameter("visitId", visitId);  
							 
							// Fetch the list of records
							List<PatientInsurance> patientInsuranceList = query.list();
							 
							// Iterate over the list and update each record
							for (PatientInsurance patientInsurance : patientInsuranceList) {
							    log.info("Patient Insurance: {} ", patientInsurance);
							    if (patientInsurance != null) {
							  
							        patientInsurance.setBluebookId(patient.getBluebookId());
							        patientInsurance.setLastUpdatedTimestamp(currentTimestamp);
				
							        session.update(patientInsurance);
							    }
							}
						}
					}
					}
				}
				existingRecord.setPlaceOfService(reqPlaceOfService);
			}}catch(Exception e){
				log.error("Exception occured  while setting place of service: " + e.getMessage());
			}
	 
	        
			existingRecord.setAccidentOrIllness(req.getAccidentOrIllness());
			existingRecord.setAccidentCategory(accidentCategory);
			existingRecord.setAccidentIllnessDate(accOrIllnessDate);

			existingRecord.setTimeDocChart((req.getTimeDocInChart() == 1) ? 1 : 0);
			existingRecord.setTimeEmLevel((req.getTimeUsedToCodeEMLevel() == 1) ? 1 : 0);

			existingRecord.setIcdCodes(icd10String);
			existingRecord.setCptObject(cptString);
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			session.update(existingRecord);
			
			Dashboard dashboardRecord = session.get(Dashboard.class, existingRecord.getVisitId());
	        if (dashboardRecord != null) {
	            dashboardRecord.setIcdCode(icd10Code);
	            dashboardRecord.setCptCode(cptCode);
	            dashboardRecord.setModifier(modifierData);
	            dashboardRecord.setUnit(unit);
	            session.update(dashboardRecord);
	        } else {
	            Dashboard newDashboardRecord = new Dashboard();
	            newDashboardRecord.setVisitId(existingRecord.getVisitId());
	            newDashboardRecord.setIcdCode(icd10Code);
	            newDashboardRecord.setModifier(modifierData);
	            newDashboardRecord.setUnit(unit);
	            session.save(newDashboardRecord);
	        }
		} else {
			// Insert new record
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(req.getPatientId());
			newRecord.setVisitId(req.getVisitId());
			if (req.getProviderId() != null && !req.getProviderId().isEmpty()) {
				newRecord.setProviderName(req.getPatientLastName() + ", " + req.getProviderFirstName());
				newRecord.setProviderId(req.getProviderId());
				newRecord.setProviderFirstName(req.getProviderFirstName());
				newRecord.setProviderLastName(req.getProviderLastName());
				newRecord.setProviderFullName(req.getProviderFirstName() + " " + req.getProviderLastName());
			}
			newRecord.setPatientAdmitDate(patientAdminDate);
			newRecord.setPlaceOfService(req.getPlaceOfService());
			newRecord.setAccidentOrIllness(req.getAccidentOrIllness());
			newRecord.setAccidentCategory(accidentCategory);
			newRecord.setAccidentIllnessDate(accOrIllnessDate);

			newRecord.setTimeDocChart((req.getTimeDocInChart() == 1) ? 1 : 0);

			newRecord.setTimeEmLevel((req.getTimeUsedToCodeEMLevel() == 1) ? 1 : 0);

			newRecord.setTimeEmLevel((req.getTimeUsedToCodeEMLevel() == 1) ? 1 : 0);

			newRecord.setIcdCodes(icd10String);
			newRecord.setCptObject(cptString);
			newRecord.setCoderUserName(req.getUserName());
			newRecord.setCoderUserId(req.getUserId());
			newRecord.setLastUpdatedTimestamp(currentTime);
			session.save(newRecord);
		}
		//SuperbillVariance sb1 = new SuperbillVariance();
		//sb1.setActualCptCode(cptCode);
		//log.debug("setActualCptCode............"+cptCode);
		//session.save(sb1);
		
			updateDashboardTimeTracking(req.getVisitId(), session, 
				    req.getAction(), req.getUserId(), req.getEndTime());
	}
	
	


	private void performCompleteAction(ChartDetailsReq req, ChartDetails existingRecord,
			Session session, Timestamp currentTime) {
		if (existingRecord != null) {
			// Update existing record
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(req.getUserId());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			session.update(existingRecord);
		} else {
			// Insert new record
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(req.getPatientId());
			newRecord.setVisitId(req.getVisitId());
			newRecord.setCoderUserName(req.getUserName());
			newRecord.setCoderUserId(req.getUserId());
			newRecord.setLastUpdatedTimestamp(currentTime);
			session.save(newRecord);
		}
		updateDashboardTimeTracking(req.getVisitId(), session, 
			    req.getAction(), req.getUserId(), req.getEndTime());
		
		updateDashboardStatus(req.getVisitId(), session, "Completed", req.getUserFullname() , 
				req.getUserFirstname(),req.getUserLastname(), String.valueOf(req.getUserId()),req);
		
	}

	private void performUnbillableAction(ChartDetailsReq req, Session session, Timestamp currentTime) {

		try {

			String hql = "UPDATE Dashboard d SET d.status = :status," + " d.unbillableReason = :unbillableReason,"
					+ " d.lastStatusChangeRole = :lastStatusChangeRole,"
					+ " d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp,"
					+ " d.lastUpdatedByUsername = :lastUpdatedByUsername,"
					+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
					+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName"
					+ " WHERE d.visitId = :visitId AND d.patientId = :patientId";

			Query query = session.createQuery(hql);

			query.setParameter("status", "Unbillable");
			query.setParameter("unbillableReason", req.getUnbillableReason());
			query.setParameter("lastStatusChangeRole", "Coder");
			query.setParameter("lastUpdatedByTimestamp", currentTime);
			query.setParameter("lastUpdatedByUsername", req.getUserName());
			query.setParameter("lastUpdatedByUserId", req.getUserId() + "");
			query.setParameter("lastUpdatedByUserFullName", req.getUserFullname());
			query.setParameter("visitId", req.getVisitId());
			query.setParameter("patientId", req.getPatientId());

			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Dashboard updated successfully with Unbillable Status");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}

			Notes userNotes = new Notes();

			//String notesDescription = String.format("Unbillable - %s", req.getUnbillableReason());
			String notesDescription = String.format("Change Request - %s", req.getUnbillableReason());
			userNotes.setDescription(notesDescription);
			userNotes.setPatientId(req.getPatientId());
			userNotes.setUserRole(req.getUserRole());
			userNotes.setVisitId(req.getVisitId());
			userNotes.setCreatedTimestamp(currentTime);
			userNotes.setUserName(req.getUserName());
			userNotes.setUserFullName(req.getUserFullname());
			userNotes.setCreatorUserId(req.getUserId().intValue());

			session.save(userNotes);

			int noteId = userNotes.getNoteId();
			log.debug("Generated NoteId: ", noteId);
			
			if ("Ready".equalsIgnoreCase(req.getOldStatus()) || "Returned".equalsIgnoreCase(req.getOldStatus())) {
			    log.info("OldStatus is '{}', proceeding with time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());

			    updateDashboardTimeTracking(req.getVisitId(), session, 
			        req.getAction(), req.getUserId(), req.getEndTime());
			} else {
			    log.info("OldStatus is '{}', skipping time tracking update for visitId={}", req.getOldStatus(), req.getVisitId());
			}	
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
		}

	}
 	 
	
	@Override
	public Reasons getDeficiencyList() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons deficiencyList = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "Coder");
			query.setParameter("title", "Deficiency");
			deficiencyList = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Deficiency List: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return deficiencyList;
	}

	@Override
	public Reasons getEscalateReasonsList() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons escalateReasonsList = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "Coder");
			query.setParameter("title", "Escalate");
			escalateReasonsList = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Escalate Reasons List: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return escalateReasonsList;
	}

	@Override
	public Reasons getModifiersReasonsList() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons modifiersReasonsList = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "Coder");
			query.setParameter("title", "Modifiers");
			modifiersReasonsList = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Modifiers Reasons List: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return modifiersReasonsList;
	}

	@Override
	public List<CPTCodes> searchCPTCodes(String searchText) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<CPTCodes> cptCodes = null;
		log.info("searchText: " + searchText);
		try {
			String hql = "FROM CPTCodes WHERE active = 1 AND"
					+ " (cptCode like :searchText OR description like :searchText)";

			Query query = session.createQuery(hql);
			query.setParameter("searchText", searchText);

			log.info("hql: " + hql);
			log.info("query.toString(): " + query.toString());

			cptCodes = (List<CPTCodes>) query.list();

			log.info("cptCodes: " + cptCodes);
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Modifiers Reasons List: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return cptCodes;
	}

	private void saveInAuditFiltersSource(ChartDetailsReq req, ChartDetails existingRecord, Session session,
			Timestamp currentTime) throws EncodeExceptionHandler {
		try {
			log.info("Starting to save audit filter source for visitId: {}", req.getVisitId());

			// Deactivate previous records for the visitId
			String deactivateQuery = "UPDATE AuditFiltersSource SET recordActive = 0 WHERE visitId = :visitId";
			int updatedRows = session.createQuery(deactivateQuery).setParameter("visitId", req.getVisitId())
					.executeUpdate();
			log.info("Deactivated previous records: {} rows updated for visitId: {}", updatedRows, req.getVisitId());

			// Fetch associated data from the Dashboard table
			Dashboard dashboard = session.get(Dashboard.class, req.getVisitId());
			if (dashboard == null) {
				log.info("No dashboard found for visitId: {}", req.getVisitId());
				return;
			}

			long providerId = 0L;
			if (dashboard.getProviderId() != null && !dashboard.getProviderId().isEmpty()) {
				providerId = Long.parseLong(dashboard.getProviderId());
				log.info("Provider ID retrieved: {}", providerId);
			} else {
				log.info("Provider ID is null or empty for visitId: {}", req.getVisitId());
			}

			// Save CPT records, modifiers, and ICDs
			for (CPTChartDetails cptData : req.getCptData()) {
				log.info("Processing CPT data: {}", cptData);

				List<String> modifiers = cptData.getModifier();
				boolean hasModifiers = !modifiers.isEmpty();

				// If there are modifiers, save for each one; otherwise, save
				// without modifier
				if (hasModifiers) {
					for (String modifier : modifiers) {
						saveCPTAuditRecord(session, req, currentTime, dashboard, providerId, cptData, modifier);
					}
				} else {
					log.info("No modifiers found for CPT code: {}. Saving without modifier.", cptData.getCptCode());
					saveCPTAuditRecord(session, req, currentTime, dashboard, providerId, cptData, null);
				}

				// Save associated insurance records if they exist
				if (dashboard.getPrimaryInsurance() != null && !dashboard.getPrimaryInsurance().isEmpty()) {
					log.info("Saving primary insurance with ICD records for CPT code: {}", cptData.getCptCode());
					saveInsuranceWithICDRecords(session, req, currentTime, dashboard, providerId, cptData.getCptCode(),
							dashboard.getPrimaryInsurance(), cptData.getSelectedICDs(),
							hasModifiers ? modifiers.get(0) : null, cptData.getUnit());
				}

				if (dashboard.getSecondaryInsurance() != null && !dashboard.getSecondaryInsurance().isEmpty()) {
					log.info("Saving secondary insurance with ICD records for CPT code: {}", cptData.getCptCode());
					saveInsuranceWithICDRecords(session, req, currentTime, dashboard, providerId, cptData.getCptCode(),
							dashboard.getSecondaryInsurance(), cptData.getSelectedICDs(),
							hasModifiers ? modifiers.get(0) : null, cptData.getUnit());
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred while saving details in auditor filter source table: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	private void saveCPTAuditRecord(Session session, ChartDetailsReq req, Timestamp currentTime, Dashboard dashboard,
			long providerId, CPTChartDetails cptData, String modifier) {
		try {
			log.info("Saving CPT record for CPT code: {} with modifier: {}", cptData.getCptCode(), modifier);
			// Create a base record for each CPT
			AuditFiltersSource cptAuditRecord = new AuditFiltersSource();
			cptAuditRecord.setVisitId(req.getVisitId());
			cptAuditRecord.setCptCode(cptData.getCptCode());
			cptAuditRecord.setModifier(modifier != null ? modifier.split(" ")[0] : null);
			cptAuditRecord.setUnit(cptData.getUnit());
			cptAuditRecord.setFacilityId(dashboard.getFacilityId());
			cptAuditRecord.setBluebookId(dashboard.getBluebookId());
			cptAuditRecord.setProviderId(providerId);
			cptAuditRecord.setProviderName(dashboard.getProviderName());
			cptAuditRecord.setCoderUserId(req.getUserId());
			cptAuditRecord.setLastUpdatedTimestamp(currentTime);
			cptAuditRecord.setPatientDOS(dashboard.getDateOfService());
			cptAuditRecord.setRecordActive(1);
			if (dashboard.getIhealConfig() != null && !dashboard.getIhealConfig().isEmpty()) {
				cptAuditRecord.setIhealConfig(dashboard.getIhealConfig());
			} else {
				cptAuditRecord.setIhealConfig("");
			}
			cptAuditRecord.setStatus("Completed");

			session.save(cptAuditRecord);
			session.flush();
			session.clear();
			log.info("Saved CPT audit record for CPT code: {}", cptData.getCptCode());
		} catch (Exception e) {
			log.error("Exception occurred while saving CPT audit record: {}", e.getMessage());
		}
	}

	private void saveInsuranceWithICDRecords(Session session, ChartDetailsReq req, Timestamp currentTime,
			Dashboard dashboard, long providerId, String cptCode, String insurance, List<ICD10Data> selectedICDs,
			String modifier, int unit) {
		try {
			log.info("Saving insurance record for CPT code: {} with insurance: {}", cptCode, insurance);

			// Save the insurance record
			AuditFiltersSource insuranceRecord = new AuditFiltersSource();
			insuranceRecord.setVisitId(req.getVisitId());
			insuranceRecord.setFacilityId(dashboard.getFacilityId());
			insuranceRecord.setBluebookId(dashboard.getBluebookId());
			insuranceRecord.setProviderId(providerId);
			insuranceRecord.setProviderName(dashboard.getProviderName());
			insuranceRecord.setCoderUserId(req.getUserId());
			insuranceRecord.setInsurance(insurance);
			insuranceRecord.setLastUpdatedTimestamp(currentTime);
			insuranceRecord.setPatientDOS(dashboard.getDateOfService());
			insuranceRecord.setRecordActive(1);
			insuranceRecord.setStatus("Completed");
			insuranceRecord.setCptCode(cptCode);
			insuranceRecord.setModifier(modifier != null ? modifier.split(" ")[0] : null);
			insuranceRecord.setUnit(unit);
			if (dashboard.getIhealConfig() != null && !dashboard.getIhealConfig().isEmpty()) {
				insuranceRecord.setIhealConfig(dashboard.getIhealConfig());
			} else {
				insuranceRecord.setIhealConfig("");
			}
			session.save(insuranceRecord);
			session.flush();
			session.clear();
			//log.info("Saved insurance record for CPT code: {}", cptCode);

			// Save associated ICD records
			if (selectedICDs != null) {
				for (ICD10Data icd : selectedICDs) {
					log.info("Saving ICD record for CPT code: {} with ICD code: {}", cptCode, icd.getCode());
					AuditFiltersSource icdRecord = new AuditFiltersSource();
					icdRecord.setVisitId(req.getVisitId());
					icdRecord.setCptCode(cptCode);
					icdRecord.setFacilityId(dashboard.getFacilityId());
					icdRecord.setBluebookId(dashboard.getBluebookId());
					icdRecord.setProviderId(providerId);
					icdRecord.setProviderName(dashboard.getProviderName());
					icdRecord.setCoderUserId(req.getUserId());
					icdRecord.setLastUpdatedTimestamp(currentTime);
					icdRecord.setPatientDOS(dashboard.getDateOfService());
					icdRecord.setRecordActive(1);
					icdRecord.setStatus("Completed");
					icdRecord.setInsurance(insurance);
					icdRecord.setIcdCode(icd.getCode());
					icdRecord.setModifier(modifier != null ? modifier.split(" ")[0] : null);
					icdRecord.setUnit(unit);

					session.save(icdRecord);
					session.flush();
					session.clear();
					log.info("Saved ICD record for CPT code: {} with ICD code: {}", cptCode, icd.getCode());
				}
			} else {
				log.info("No ICD records to save for CPT code: {}", cptCode);
			}
		} catch (Exception e) {
			log.error("Exception occurred while saving insurance with ICD records: {}", e.getMessage());
		}
	}


	
	@Override
	public ChartDetails getCPTCodeList(ChartDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		ChartDetails details = new ChartDetails();
		try {
			if (req.getVisitId() != null) {
				String hql = " FROM ChartDetails WHERE visitId = :visitId ";
				details = session.createQuery(hql, ChartDetails.class).setParameter("visitId", req.getVisitId())
						.setMaxResults(1).uniqueResult();
			}
			log.debug("details: {}", details);
		} catch (Exception e) {
			log.error("Exception occurred while fetching all CPT Codes List: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return details;
	}

	@Override
	public PatientMedicalRecords getPatientMedicalRecord(long patientId, long visitId, String docType)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		PatientMedicalRecords record = null;
		try {
			String hql = "FROM PatientMedicalRecords a WHERE a.patientId = :patientId"
					+ " AND a.visitId = :visitId AND a.documentType = :documentType";
			Query query = session.createQuery(hql);
			query.setParameter("patientId", patientId);
			query.setParameter("visitId", visitId);
			query.setParameter("documentType", docType);

			record = (PatientMedicalRecords) query.uniqueResult();

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}
	
	@Override
	public List<Object[]> searchEscalatedChart(EscalatedChartDetailsReq req, int index,
			String taskType, String assignee, List<String> bbclist) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> dashboard = new ArrayList<>();

		log.debug("dashboard.........."+dashboard);
		try {
			String hql = "SELECT DISTINCT a.visitId,a.patientId,a.patientName,a.facilityAlias,a.receivedDate,a.providerName, " +
					"a.status,a.dateOfService,a.medicalRecordNumber,a.encounterType,a.assigneeUsername,a.assigneeUserId,a.assigneeUserFullname, " +
					"a.accountNumber,a.gender,a.ihealConfig,a.facilityId,a.bluebookId,a.lastStatusChangeRole, " +
					"CASE WHEN a.primaryInsurance IS NOT NULL THEN a.primaryInsurance ELSE a.secondaryInsurance END,a.patientFirstName,a.patientLastName,a.patientDOB,a.isLocked,a.lastUpdatedByUserFullName " +
					"FROM Dashboard a " +
					"WHERE a.status = 'In Review' " +
					"AND a.lastStatusChangeRole = 'Coder'";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.bluebookId IN :bbcList ";

				log.info("query : {}", hql);

			}
			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				dashboard = session.createQuery(hql)
						.setParameter("bbcList", bbclist).setFirstResult(index)
						.setMaxResults(PAGE_SIZE).list();
			} else {
				dashboard = session.createQuery(hql).setFirstResult(index)
						.setMaxResults(PAGE_SIZE).list();
			}
			log.info("query : {}", hql);
			
		} catch (Exception e) {
			log.error("Exception occured while fetching EscalationChartDetails: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return dashboard;
	}
	public Long getTotalCount(int index, String taskType,
			String assigneeUsername, EscalatedChartDetailsReq req,
			List<String> bbcList) throws EncodeExceptionHandler{
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;

		try {
			String hql = "SELECT count(*) FROM Dashboard a WHERE " +
					"a.status = 'In Review' " +
					 "AND a.lastStatusChangeRole = 'Coder'";
			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.bluebookId IN :bbcList";
				// AND a.assigneeUsername ='" + req.getUsername() + "'";

				totalCount = (Long) session.createQuery(hql)
						.setParameter("bbcList", bbcList).uniqueResult();
				log.debug("totalCount..........."+totalCount);
			} else {
				totalCount = (Long) session.createQuery(hql).uniqueResult();
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching EscalationChartDetails total count : {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public FacilityDetails isFacilityExists(String bluebookId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FacilityDetails record = null;
		try {
			String hql = "FROM FacilityDetails f where active = 1 AND f.bluebookId = :bluebookId";
			
			record = (FacilityDetails) session.createQuery(hql)
					.setParameter("bluebookId", bluebookId)
					.uniqueResult();

		} catch (Exception e) {
			log.error(String.format("Exception occured in isFacilityExists: %s", e.getMessage()));
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}
	
	@Override
	public void persistFacilityRecords(FacilityDetails facRecord) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			session.save(facRecord);
		} catch (Exception e) {
			log.error(String.format("Exception occured while persistFacilityRecords: %s", e.getMessage()));
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public void updateFacilityRecord(String bbc,
			int activeFlag, String updateFacilityActiveQuery) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			Query query = session.createQuery(updateFacilityActiveQuery);
			
			query.setParameter("bluebookId", bbc);
			query.setParameter("activeFlag", activeFlag);
			
			query.executeUpdate();

		} catch (Exception e) {
			log.error("Exception occured : " +e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public void updateFacilityType(String bbc, String facilityType,
			String updateFacilityTypeQuery) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			Query query = session.createQuery(updateFacilityTypeQuery);
			
			query.setParameter("bluebookId", bbc);
			query.setParameter("facilityType", facilityType);
			
			query.executeUpdate();

		} catch (Exception e) {
			log.error("Exception occured in updateFacilityType: " +e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public List<Notes> getEscalationDetails(Long visitId)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Notes> notesList = new ArrayList<>();

		try {
			String hql = "FROM Notes WHERE visitId = :visitId"
					+ " AND (description like 'Requested Guidance%'"
						+ " OR description like 'Returned%')"
					+ " order by createdTimestamp desc";

			log.info("query : {}", hql);
			notesList = session.createQuery(hql)
					.setParameter("visitId", visitId)
					.list();

			log.info("query : {}", hql);
		} catch (Exception e) {
			log.error("Exception occurred while retrieving escalation details{}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return notesList;
	}
	
	@Override
	public String getRule1CptCodes(int id) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		String cptCodes = new String();

		try {
			String hql = "SELECT cptCodes FROM ChartValidate WHERE id = :id";

			log.info("query : {}", hql);
			cptCodes = (String) session.createQuery(hql)
					.setParameter("id", id)
					.uniqueResult();

			log.info("query : {}", hql);
		} catch (Exception e) {
			log.error("Exception occurred while retrieving CPT Code rules: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return cptCodes;
	}
	
	@Override
	public List<Long> fetchSameDayVisit(int facilityId, Long patientId,
			Timestamp dateOfService, 
			Timestamp nextDayDOS)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Long> records = null;
		try {
			String hql = "SELECT visitId FROM Dashboard a"
					+ " WHERE a.facilityId = :facilityId"
					+ " AND a.patientId = :patientId"
					+ " AND a.dateOfService > :dateOfService"
					+ " AND a.dateOfService < :nextDayDOS";

			Query query = session.createQuery(hql);
			query.setParameter("facilityId", facilityId);
			query.setParameter("patientId", patientId);
			query.setParameter("dateOfService", dateOfService);
			query.setParameter("nextDayDOS", nextDayDOS);
			
			records = (List<Long>) query.list();

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return records;
	}
	
	public String fetchCptObjectByVisitId(Long visitId) throws EncodeExceptionHandler {
		try {
			log.info("Inside fetchCptObjectByVisitId Method");
			String hql = "SELECT c.cptObject FROM ChartDetails c WHERE c.visitId = :visitId";
			return (String) sessionFactory.getCurrentSession().createQuery(hql).setParameter("visitId", visitId)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public void saveIncompleteEmailSentStatus(WeeklyIncompleteReportEmail emailStatus)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			session.save(emailStatus);
		} catch (Exception e) {
			log.error("Exception in saveIncompleteEmailSentStatus : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
	
	@Override
	public List<ICDCodesMaster> searchICDFromDB(String searchText, int searchType, int offset, int count) throws EncodeExceptionHandler {
	    Session session = this.sessionFactory.getCurrentSession();
	    try {
	        String query = "";
	        switch (searchType) {
	            case 0:
	                query = "FROM ICDCodesMaster WHERE icdCode LIKE :searchText AND active = 1";
	                break;
	            case 1:
	                query = "FROM ICDCodesMaster WHERE description LIKE :searchText AND active = 1";
	                break;
	            case 2:
	                query = "FROM ICDCodesMaster WHERE codeDescription LIKE :searchText AND active = 1";
	                break;
	            default:
	                return new ArrayList<>();
	        }
	 

	        Query<ICDCodesMaster> jpaQuery = session.createQuery(query, ICDCodesMaster.class);
	        jpaQuery.setParameter("searchText", "%" + searchText + "%");
	 
	        jpaQuery.setFirstResult(offset);  
	        jpaQuery.setMaxResults(count);    

	        return jpaQuery.getResultList();
	    } catch (Exception e) {
	        log.error("Exception in searchICDFromDB: " + e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	}
	
	@Override
	public int getTotalCount(String searchText, int searchType) throws EncodeExceptionHandler {
	    Session session = this.sessionFactory.getCurrentSession();
	    try {
	        String countQuery = "";
	        switch (searchType) {
	            case 0:
	                countQuery = "SELECT COUNT(*) FROM ICDCodesMaster WHERE icdCode LIKE :searchText AND active = 1";
	                break;
	            case 1:
	                countQuery = "SELECT COUNT(*) FROM ICDCodesMaster WHERE description LIKE :searchText AND active = 1";
	                break;
	            case 2:
	                countQuery = "SELECT COUNT(*) FROM ICDCodesMaster WHERE codeDescription LIKE :searchText AND active = 1";
	                break;
	            default:
	                return 0;
	        }
	 
	        Query query = session.createQuery(countQuery);
	        query.setParameter("searchText", "%" + searchText + "%");
	        Long count = (Long) query.getSingleResult();
	        return count.intValue();
	    } catch (Exception e) {
	        log.error("Exception in getTotalCount: " + e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	}

	@Override
	public List<Object[]> getinsuranceTypeFromDashboard(IHealPatientLoadReq req) throws EncodeExceptionHandler {
		//String hql = "Select d.primaryInsurance,d.secondaryInsurance,d.providerId FROM Dashboard d where d.patientId =:patientId";
		String hql = "Select d.primaryInsurance,d.secondaryInsurance,d.providerId,d.patientName FROM Dashboard d where d.visitId =:visitId";
		Session session = sessionFactory.getCurrentSession();
		Query<Object[]> query= session.createQuery(hql, Object[].class);
		//query.setParameter("patientId", Long.valueOf(req.getPatientId()));
		query.setParameter("visitId", req.getVisitId());
		log.info("query : {}", hql);
		return query.getResultList();
	}

	@Override
	public Long fetchNextRecords(String userRole, List<String> facilityidlist, Timestamp dosTimestamp,
			Timestamp nextDaytTimestamp, Long visitids,ChartDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long visitId = 0L;
		 List<Integer> facilityIdListInt = facilityidlist.stream()
		            .map(Integer::parseInt)
		            .collect(Collectors.toList());
		 SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		 log.debug("facilityIdListInt......"+facilityIdListInt);
		 Map<String, Object> parameters = new HashMap<>();
		switch (userRole) {
		case "CMC": {
			try {
				String hql = "SELECT d.visitId FROM Dashboard d " 
						+ "WHERE d.status IN ('New','Returned') "
						+ "AND d.status != 'Unbillable' " 
						+ "AND d.lastStatusChangeRole = 'CMC' "
						+ "AND d.facilityId IN :facilityIdListInt "
						+ "ORDER BY d.receivedDate ASC";
				log.info("query .............: {}", hql.toString());

				Object visitIdObj = session.createQuery(hql).setParameter(
						"facilityIdListInt", facilityIdListInt).setMaxResults(1)
						.uniqueResult();
				log.info("query .............: {}", hql);
				log.info("visitIdObj : " + visitIdObj);

				if (visitIdObj != null) {
					visitId =  (long)visitIdObj;
				}

			} catch (Exception e) {
				log.error("Exception in while fetching next available record for CMC : {}",
						e.getMessage());
			}
		}
			break;

		case "Coder": {
			try {

				String mostrecentbbc = "SELECT snfLocationBBC FROM Dashboard " 
								+ "WHERE visitId = :visitId "
					        	+ "AND facilityId IN :facilityIdListInt";

				Object bbcObj = session.createQuery(mostrecentbbc).setParameter("visitId", visitids)
						.setParameter("facilityIdListInt", facilityIdListInt).uniqueResult();
				log.info("fetch bbcObj...... {}", bbcObj);
				if (bbcObj != null) {
					String bbcobj1 = (String) bbcObj;

					String hql = "SELECT visitId FROM Dashboard" + " WHERE status IN ('Ready','Returned')"
								+ " AND lastStatusChangeRole = 'Coder'" 
								+ " AND snfLocationBBC IN :bbcobj1 "
								+ " AND visitId != :visitId" 
								+ " AND dateOfService > :dateOfService"
								+ " AND dateOfService < :nextDayDateOfService"
								+ " AND isLocked = '0'";
					
					if (req.getFilters() != null && !req.getFilters().isEmpty()) {

						List<String> filterList = FilterRequestUtil.
								getListFromDelimitedStr(req.getFilters());

						for (String filterReq : filterList) {

							//hql += " AND ";

							/*switch (filterReq) {
							case "bbc" : {
								List<String> bbcList = FilterRequestUtil
										.getListFromDelimitedStr(req.getBbc());
								hql += " snfLocationBBC IN :bbcs ";
								parameters.put("bbcs", bbcList);
							}
								break;
							case "facilityId": {
								List<String> fscilityIdList = FilterRequestUtil
										.getListFromDelimitedStr(req.getFacilityIds());
								List<Integer> intfacilityIdList = new ArrayList<>();
								for (String s : fscilityIdList) {
									intfacilityIdList.add(Integer.valueOf(s));
								}
								hql += " facilityId IN :facilityId ";
								parameters.put("facilityId", intfacilityIdList);
							}
								break;
							case "facilityName": {
								List<String> facilityList = FilterRequestUtil
										.getListFromDelimitedStr(req.getFacilityName());
								hql += " snfLocationName IN :facilityAlias ";
								parameters.put("facilityAlias", facilityList);
							}
								break;
							case "ihealConfig": {
								List<String> facilityTypeList = FilterRequestUtil
										.getListFromDelimitedStr(req.getIhealConfig());
								hql += " ihealConfig IN :ihealConfig";
								parameters.put("ihealConfig", facilityTypeList);
							}
								break;

							default:
								break;
							}*/
							switch (filterReq) {
							case "bbc" : {
								List<String> bbcs = FilterRequestUtil
										.getListFromDelimitedStr(req.getBbc());
								hql += " AND snfLocationBBC IN :bbc ";
								parameters.put("bbc", bbcs);
							}
								break;
							case "interfaceDate" : {
								hql += " AND receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
								parameters.put("startInterfaceDate", dateFormat
										.parse(req.getStartInterfaceDate()));
								parameters.put("endInterfaceDate", dateFormat
										.parse(req.getEndInterfaceDate()));
							}
								break;
								
							case "age" : {
								hql += " AND dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
								parameters.put("ageStartDate",
										dateFormat.parse(req.getAgeStartDate()));
								parameters.put("ageEndDate",
										dateFormat.parse(req.getAgeEndDate()));
							}
								break;
							case "providerName" : {
								List<String> providerNameList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getProviderName());
								hql += " AND providerName IN :providerName ";
								parameters.put("providerName", providerNameList);
							}
								break;

							case "patientName" : {
								List<String> patientNameList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getPatientName());
								hql += " AND patientName IN :patientName ";
								parameters.put("patientName", patientNameList);
							}
								break;
							case "visitId" : {

								List<String> visitIdList = FilterRequestUtil
										.getListFromDelimitedStr(req.getVisitIds());
								List<Long> intvisitIdList = new ArrayList<>();
								for (String s : visitIdList) {
									intvisitIdList.add(Long.valueOf(s));
								}
								hql += " AND visitId IN :visitId ";
								parameters.put("visitId", intvisitIdList);
							}
								break;
							case "dateOfService" : {
								hql += " AND dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
								parameters.put("startDOSDate",
										new Timestamp(dateFormat
												.parse(req.getStartDOSDate())
												.getTime()));
								parameters.put("endDOSDate",
										new Timestamp(dateFormat
												.parse(req.getEndDOSDate())
												.getTime()));
							}
								break;

							case "medicalRecordNumber" : {
								List<String> medicalRecordNumberList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getMedicalRecordNumber());
								hql += " AND medicalRecordNumber IN :medicalRecordNumber ";
								parameters.put("medicalRecordNumber",
										medicalRecordNumberList);
							}
								break;

							case "encounterType" : {
								List<String> encounterTypeList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getEncounterType());
								hql += " AND encounterType IN :encounterType ";
								parameters.put("encounterType", encounterTypeList);
							}
								break;
							case "serviceLine" : {
								List<String> serviceLineList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getServiceLine());
								hql += " AND serviceLine IN :serviceLine ";
								parameters.put("serviceLine", serviceLineList);
							}
								break;

							case "chartNotes" : {
								List<String> cmcNotesList = FilterRequestUtil
										.getListFromDelimitedStr(req.getChartNotes());
								hql += " AND coderNotes IN :coderNotes ";
								parameters.put("coderNotes", cmcNotesList);
							}
								break;

							case "status" : {
								List<String> statusList = FilterRequestUtil
										.getListFromDelimitedStr(req.getStatus());
								hql += " AND status IN :status ";
								parameters.put("status", statusList);
							}
								break;

							case "ihealConfig" : {
								List<String> facilityTypeList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getIhealConfig());
								hql += " AND ihealConfig IN :ihealConfig ";
								parameters.put("ihealConfig", facilityTypeList);
							}
								break;

							default :
								break;
						}
					}
				}

					hql += " order by receivedDate asc"; 

						Object visitIdObj = session.createQuery(hql).setParameter("bbcobj1", bbcobj1)
								.setParameter("visitId", visitids)
								.setParameter("dateOfService", dosTimestamp)
								.setParameter("nextDayDateOfService", nextDaytTimestamp)
								.setProperties(parameters)
								.setMaxResults(1)
								.uniqueResult();
						log.info("query =====================: {}", hql);
						log.info("visitIdObj : " + visitIdObj);

						if (visitIdObj != null) {
							visitId = (long) visitIdObj;
						}

						if (visitIdObj == null) {

							hql = "SELECT visitId FROM Dashboard" 
							+ " WHERE status IN ('Ready','Returned')"
							+ " AND lastStatusChangeRole = 'Coder'" 
							+ " AND snfLocationBBC IN :bbcobj1 "
							+ " AND isLocked = '0'";
							
							if (req.getFilters() != null && !req.getFilters().isEmpty()) {

								List<String> filterList = FilterRequestUtil.
										getListFromDelimitedStr(req.getFilters());

								for (String filterReq : filterList) {

									//hql += " AND ";

									/*switch (filterReq) {
									case "bbc" : {
										List<String> bbcList = FilterRequestUtil
												.getListFromDelimitedStr(req.getBbc());
										hql += " snfLocationBBC IN :bbcs ";
										parameters.put("bbcs", bbcList);
									}
										break;
									case "facilityId": {
										List<String> fscilityIdList = FilterRequestUtil
												.getListFromDelimitedStr(req.getFacilityIds());
										List<Integer> intfacilityIdList = new ArrayList<>();
										for (String s : fscilityIdList) {
											intfacilityIdList.add(Integer.valueOf(s));
										}
										hql += " facilityId IN :facilityId ";
										parameters.put("facilityId", intfacilityIdList);
									}
										break;
									case "facilityName": {
										List<String> facilityList = FilterRequestUtil
												.getListFromDelimitedStr(req.getFacilityName());
										hql += " snfLocationName IN :facilityAlias ";
										parameters.put("facilityAlias", facilityList);
									}
										break;
									case "ihealConfig": {
										List<String> facilityTypeList = FilterRequestUtil
												.getListFromDelimitedStr(req.getIhealConfig());
										hql += " ihealConfig IN :ihealConfig";
										parameters.put("ihealConfig", facilityTypeList);
									}
										break;

									default:
										break;
									}*/
									switch (filterReq) {
									case "bbc" : {
										List<String> bbcs = FilterRequestUtil
												.getListFromDelimitedStr(req.getBbc());
										hql += " AND snfLocationBBC IN :bbc ";
										parameters.put("bbc", bbcs);
									}
										break;
									case "interfaceDate" : {
										hql += " AND receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
										parameters.put("startInterfaceDate", dateFormat
												.parse(req.getStartInterfaceDate()));
										parameters.put("endInterfaceDate", dateFormat
												.parse(req.getEndInterfaceDate()));
									}
										break;
										
									case "age" : {
										hql += " AND dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
										parameters.put("ageStartDate",
												dateFormat.parse(req.getAgeStartDate()));
										parameters.put("ageEndDate",
												dateFormat.parse(req.getAgeEndDate()));
									}
										break;
									case "providerName" : {
										List<String> providerNameList = FilterRequestUtil
												.getListFromDelimitedStr(
														req.getProviderName());
										hql += " AND providerName IN :providerName ";
										parameters.put("providerName", providerNameList);
									}
										break;

									case "patientName" : {
										List<String> patientNameList = FilterRequestUtil
												.getListFromDelimitedStr(
														req.getPatientName());
										hql += " AND patientName IN :patientName ";
										parameters.put("patientName", patientNameList);
									}
										break;
									case "visitId" : {

										List<String> visitIdList = FilterRequestUtil
												.getListFromDelimitedStr(req.getVisitIds());
										List<Long> intvisitIdList = new ArrayList<>();
										for (String s : visitIdList) {
											intvisitIdList.add(Long.valueOf(s));
										}
										hql += " AND visitId IN :visitId ";
										parameters.put("visitId", intvisitIdList);
									}
										break;
									case "dateOfService" : {
										hql += " AND dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
										parameters.put("startDOSDate",
												new Timestamp(dateFormat
														.parse(req.getStartDOSDate())
														.getTime()));
										parameters.put("endDOSDate",
												new Timestamp(dateFormat
														.parse(req.getEndDOSDate())
														.getTime()));
									}
										break;

									case "medicalRecordNumber" : {
										List<String> medicalRecordNumberList = FilterRequestUtil
												.getListFromDelimitedStr(
														req.getMedicalRecordNumber());
										hql += " AND medicalRecordNumber IN :medicalRecordNumber ";
										parameters.put("medicalRecordNumber",
												medicalRecordNumberList);
									}
										break;

									case "encounterType" : {
										List<String> encounterTypeList = FilterRequestUtil
												.getListFromDelimitedStr(
														req.getEncounterType());
										hql += " AND encounterType IN :encounterType ";
										parameters.put("encounterType", encounterTypeList);
									}
										break;

									case "serviceLine" : {
										List<String> serviceLineList = FilterRequestUtil
												.getListFromDelimitedStr(
														req.getServiceLine());
										hql += " AND serviceLine IN :serviceLine ";
										parameters.put("serviceLine", serviceLineList);
									}
										break;

									case "chartNotes" : {
										List<String> cmcNotesList = FilterRequestUtil
												.getListFromDelimitedStr(req.getChartNotes());
										hql += " AND coderNotes IN :coderNotes ";
										parameters.put("coderNotes", cmcNotesList);
									}
										break;

									case "status" : {
										List<String> statusList = FilterRequestUtil
												.getListFromDelimitedStr(req.getStatus());
										hql += " AND status IN :status ";
										parameters.put("status", statusList);
									}
										break;

									case "ihealConfig" : {
										List<String> facilityTypeList = FilterRequestUtil
												.getListFromDelimitedStr(
														req.getIhealConfig());
										hql += " AND ihealConfig IN :ihealConfig ";
										parameters.put("ihealConfig", facilityTypeList);
									}
										break;

									default :
										break;
								}
							}
						}

							hql += " order by receivedDate asc";
							
							visitIdObj = session.createQuery(hql)
								.setParameter("bbcobj1", bbcobj1)
								.setProperties(parameters)
								.setMaxResults(1).uniqueResult();
							log.info("query ...................: {}", hql);
							log.info("visitIdObj : " + visitIdObj);

							if (visitIdObj != null) {
								visitId = (long) visitIdObj;
							}
							if (visitIdObj == null) {

								hql = "SELECT visitId FROM Dashboard" 
								+ " WHERE status IN ('Ready','Returned')"
								+ " AND lastStatusChangeRole = 'Coder'" 
								+ " AND facilityId IN :facilityIdListInt "
								+ " AND isLocked = '0'";

								if (req.getFilters() != null && !req.getFilters().isEmpty()) {

									List<String> filterList = FilterRequestUtil.
											getListFromDelimitedStr(req.getFilters());

									for (String filterReq : filterList) {

										//hql += " AND ";

										/*switch (filterReq) {
										case "bbc" : {
											List<String> bbcList = FilterRequestUtil
													.getListFromDelimitedStr(req.getBbc());
											hql += " snfLocationBBC IN :bbcs ";
											parameters.put("bbcs", bbcList);
										}
											break;
										case "facilityId": {
											List<String> fscilityIdList = FilterRequestUtil
													.getListFromDelimitedStr(req.getFacilityIds());
											List<Integer> intfacilityIdList = new ArrayList<>();
											for (String s : fscilityIdList) {
												intfacilityIdList.add(Integer.valueOf(s));
											}
											hql += " facilityId IN :facilityId ";
											parameters.put("facilityId", intfacilityIdList);
										}
											break;
										case "facilityName": {
											List<String> facilityList = FilterRequestUtil
													.getListFromDelimitedStr(req.getFacilityName());
											hql += " snfLocationName IN :facilityAlias ";
											parameters.put("facilityAlias", facilityList);
										}
											break;
										case "ihealConfig": {
											List<String> facilityTypeList = FilterRequestUtil
													.getListFromDelimitedStr(req.getIhealConfig());
											hql += " ihealConfig IN :ihealConfig";
											parameters.put("ihealConfig", facilityTypeList);
										}
											break;

										default:
											break;
										}*/
										switch (filterReq) {
										case "bbc" : {
											List<String> bbcs = FilterRequestUtil
													.getListFromDelimitedStr(req.getBbc());
											hql += " AND snfLocationBBC IN :bbc ";
											parameters.put("bbc", bbcs);
										}
											break;
										case "interfaceDate" : {
											hql += " AND receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
											parameters.put("startInterfaceDate", dateFormat
													.parse(req.getStartInterfaceDate()));
											parameters.put("endInterfaceDate", dateFormat
													.parse(req.getEndInterfaceDate()));

										}
											break;
											
										case "age" : {
											hql += " AND dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
											parameters.put("ageStartDate",
													dateFormat.parse(req.getAgeStartDate()));
											parameters.put("ageEndDate",
													dateFormat.parse(req.getAgeEndDate()));
										}
											break;
										case "providerName" : {
											List<String> providerNameList = FilterRequestUtil
													.getListFromDelimitedStr(
															req.getProviderName());
											hql += " AND providerName IN :providerName ";
											parameters.put("providerName", providerNameList);
										}
											break;


										case "patientName" : {
											List<String> patientNameList = FilterRequestUtil
													.getListFromDelimitedStr(
															req.getPatientName());
											hql += " AND patientName IN :patientName ";
											parameters.put("patientName", patientNameList);
										}
											break;
										case "visitId" : {

											List<String> visitIdList = FilterRequestUtil
													.getListFromDelimitedStr(req.getVisitIds());
											List<Long> intvisitIdList = new ArrayList<>();
											for (String s : visitIdList) {
												intvisitIdList.add(Long.valueOf(s));
											}
											hql += " AND visitId IN :visitId ";
											parameters.put("visitId", intvisitIdList);
										}
											break;
										case "dateOfService" : {
											hql += " AND dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
											parameters.put("startDOSDate",
													new Timestamp(dateFormat
															.parse(req.getStartDOSDate())
															.getTime()));
											parameters.put("endDOSDate",
													new Timestamp(dateFormat
															.parse(req.getEndDOSDate())
															.getTime()));
										}
											break;

										case "medicalRecordNumber" : {
											List<String> medicalRecordNumberList = FilterRequestUtil
													.getListFromDelimitedStr(
															req.getMedicalRecordNumber());
											hql += " AND medicalRecordNumber IN :medicalRecordNumber ";
											parameters.put("medicalRecordNumber",
													medicalRecordNumberList);
										}
											break;

										case "encounterType" : {
											List<String> encounterTypeList = FilterRequestUtil
													.getListFromDelimitedStr(
															req.getEncounterType());
											hql += " AND encounterType IN :encounterType ";
											parameters.put("encounterType", encounterTypeList);
										}
											break;
										case "serviceLine" : {
											List<String> serviceLineList = FilterRequestUtil
													.getListFromDelimitedStr(
															req.getServiceLine());
											hql += " AND serviceLine IN :serviceLine ";
											parameters.put("serviceLine", serviceLineList);
										}
											break;

										case "chartNotes" : {
											List<String> cmcNotesList = FilterRequestUtil
													.getListFromDelimitedStr(req.getChartNotes());
											hql += " AND coderNotes IN :coderNotes ";
											parameters.put("coderNotes", cmcNotesList);
										}
											break;

										case "status" : {
											List<String> statusList = FilterRequestUtil
													.getListFromDelimitedStr(req.getStatus());
											hql += " AND status IN :status ";
											parameters.put("status", statusList);
										}
											break;

										case "ihealConfig" : {
											List<String> facilityTypeList = FilterRequestUtil
													.getListFromDelimitedStr(
															req.getIhealConfig());
											hql += " AND ihealConfig IN :ihealConfig ";
											parameters.put("ihealConfig", facilityTypeList);
										}
											break;

										default :
											break;
									}
								}
							}

								hql += " order by receivedDate asc";
								
								log.info("query.......: {}", hql.toString());

								visitIdObj = session.createQuery(hql)
										.setParameter("facilityIdListInt", facilityIdListInt)
										.setProperties(parameters)
										.setMaxResults(1)
										.uniqueResult();
								log.info("visitIdObj : " + visitIdObj);

								if (visitIdObj != null) {
								visitId = (long) visitIdObj;
							}
						}
					}
				}
			} catch (Exception e) {
				log.error("Exception in while fetching next available record for Coder : {}", e.getMessage());
			}
		}
			break;

		default:
			break;

		}
		return visitId;
	}

	@Override
	public void updateRecord(CoderDashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
	    
	    try {
	        log.info("Updating startTime for visitId={}", req.getVisitId());

	        // Step 1: Update startTime if not null
	        if (req.getStartTime() != null) {
	            String hql = "UPDATE Dashboard a SET a.startTime = :startTime WHERE a.visitId = :visitId";
	            Query query = session.createQuery(hql);
	            query.setParameter("visitId", Long.valueOf(req.getVisitId()));
	            query.setParameter("startTime", req.getStartTime());

	            int rowsAffected = query.executeUpdate();
	            log.info("Start time updated for visitId={}, Rows affected={}", req.getVisitId(), rowsAffected);
	        }

	        // Step 2: Retrieve the updated dashboard record
	        String fetchQuery = "FROM Dashboard WHERE visitId = :visitId";
	        Query<Dashboard> fetchRecordQuery = session.createQuery(fetchQuery, Dashboard.class);
	        fetchRecordQuery.setParameter("visitId", Long.valueOf(req.getVisitId()));
	        Dashboard dashboardRecord = fetchRecordQuery.uniqueResult();

	        if (dashboardRecord != null) {
	            log.info("Fetched dashboard record: {}", dashboardRecord);

	            // Step 3: Convert userId (String) to int for comparison
	           Integer userIdInt;
	            try {
	                userIdInt = Integer.parseInt(req.getUserId()); // Convert String to int safely
	                log.debug("Converted userId to int: {}", userIdInt);
	            } catch (NumberFormatException e) {
	                log.error("Invalid userId format: {}, skipping update.", req.getUserId(), e);
	                return; // Exit if userId is not a valid integer
	            }
	         // Step 2: Ensure coderId is not null before comparing
	            Integer coderId = dashboardRecord.getCoderId();
	            if (coderId == null) {
	                log.warn("CoderId is null for visitId={}. Skipping update.", req.getVisitId());
	                return; // Exit early
	            }

	            // Step 4: Compare userIdInt with stored coderId
	            if (!userIdInt.equals(coderId)) {
	                log.info("UserId does not match coderId, resetting timeInMs to 0 for visitId={}", req.getVisitId());

	                String resetQuery = "UPDATE Dashboard a SET a.timeInMs = 0 WHERE a.visitId = :visitId";
	                Query resetTimeQuery = session.createQuery(resetQuery);
	                resetTimeQuery.setParameter("visitId", Long.valueOf(req.getVisitId()));
	                resetTimeQuery.executeUpdate();
	            }

	            log.info("Dashboard record updated successfully for visitId={}", req.getVisitId());
	        } else {
	            log.warn("No dashboard record found for visitId={}", req.getVisitId());
	        }

	    } catch (Exception e) {
	        log.error("Exception occurred in updateRecord: {}", e.getMessage(), e);
	        throw new EncodeExceptionHandler("Error updating record for visitId: " + req.getVisitId(), e);
	    }
	}

	@Override
	public List<PatientMedicalRecordsDTO> fetchSBRecords(long patientId, long visitId) throws EncodeExceptionHandler {
	    Session session = this.sessionFactory.getCurrentSession();
	    List<PatientMedicalRecordsDTO> records = new ArrayList<>();

	    try {
	        String hql = "SELECT new com.healogics.encode.dto.PatientMedicalRecordsDTO(" +
	                     "pmr.documentId, pmr.patientId, pmr.visitId, pmr.documentType, " +
	                     "pmr.sbillProviderFirstName, pmr.sbillProviderLastName, pmr.sbillProviderId, " +
	                     "pmr.eventDatetime) " +
	                     "FROM PatientMedicalRecords pmr " +
	                     "WHERE pmr.visitId = :visitId AND pmr.patientId = :patientId AND pmr.documentType = :documentType";
	 
	        Query<PatientMedicalRecordsDTO> query = session.createQuery(hql, PatientMedicalRecordsDTO.class);
	        query.setParameter("visitId", visitId);
	        query.setParameter("patientId", patientId);
	        query.setParameter("documentType", "SB");
	        records = query.list();
	        log.info("Fetched SB records for patientId={} visitId={} count={}", patientId, visitId, records.size());
	        log.info("Records: {}", records);
	        log.info("HQL: {}", hql);
	 
	    } catch (Exception e) {
	        log.error("Exception in fetchSBRecords: {}", e.getMessage(), e);
	        throw new EncodeExceptionHandler("Error fetching SB records");
	    }
	    return records;
	}

	 

	 
}

