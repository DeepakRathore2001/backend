package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.CoderDashboardDAO;
import com.healogics.encode.dto.CoderDashboardFilter;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.entity.AuditQueue;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.PlaceOfServiceDetails;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.util.FilterRequestUtil;
 
@Repository 
@Transactional
public class CoderDashboardDAOImpl implements CoderDashboardDAO {
 
	private final Logger log = LoggerFactory
			.getLogger(CoderDashboardDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public CoderDashboardDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public List<Object[]> getAllCoderRecords(CoderDashboardReq req, int index,
			String taskType, String assignee, List<String> bbclist,List<String>FacilityIdList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> coderDashboard = new ArrayList<>();

		LocalDate sevenDate = LocalDate.now().minusDays(7);
		Date sevenDaysDate = Date.from(sevenDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Timestamp sevTimestamp = new Timestamp(sevenDaysDate.getTime());
		try {
			
			String hqlString = "SELECT r.bluebookId,r.facilityId,coalesce(NULLIF(r.facilityAlias,''),'') AS facilityAlias,COUNT(*) AS totalCount, COUNT(CASE WHEN status IN ('Ready','Returned') THEN 1 END) AS count, MIN(r.dateOfService) AS dateOfService,"
					+ " CASE WHEN MIN(r.dateOfService) IS NOT NULL AND MIN(r.dateOfService) < :sevTimestamp THEN true ELSE false END AS overDueFlag,r.ihealConfig,"
					+ " coalesce(NULLIF(r.snfLocationBBC,''),''), r.snfLocationName, r.isSNFLocation"
					+ " FROM Dashboard r WHERE r.status IN ('Ready','Returned')"
					+ " AND r.lastStatusChangeRole = 'Coder' ";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				//hqlString += " AND r.bluebookId IN :bbcList ";
				hqlString += " AND r.facilityId IN :FacilityIdList ";
				log.debug("hqlString..... :" + hqlString);
			}
			
			hqlString =	hqlString + " GROUP BY coalesce(NULLIF(r.snfLocationBBC,''),'') ";
			
			//apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hqlString = sortList(req, hqlString);

			} else {
				hqlString += " order by LOWER(snfLocationBBC) asc";
			}

			log.info("query : {}", hqlString);

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				List<Integer> facilityIdListInt = FacilityIdList.stream()
			            .map(Integer::parseInt)
			            .collect(Collectors.toList());
				coderDashboard = session.createQuery(hqlString)
						//.setParameter("bbcList", bbclist)
						.setParameter("FacilityIdList", facilityIdListInt)
						.setParameter("sevTimestamp", sevTimestamp).setFirstResult(index)
						.setMaxResults(PAGE_SIZE).list();
			} else {
				coderDashboard = session.createQuery(hqlString)
						.setParameter("sevTimestamp", sevTimestamp)
						.setFirstResult(index)
						.setMaxResults(PAGE_SIZE).list();
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching all Coder records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return coderDashboard;
	}

	/*private String sortList(CoderDashboardReq req, String hql) {
		//String sortBy = req.getSortBy().toLowerCase();
		String sortBy = req.getSortBy();

		if (sortBy.equals("bbc")) {
			hql += " order by LOWER(snfLocationBBC) ";
		} else if (sortBy.equals("facilityName")) {
			hql += " order by LOWER(snfLocationName) ";
		} else if (sortBy.equals("ihealConfig")) {
			hql += " order by LOWER(ihealConfig) ";
		} else {
			hql += " order by LOWER(" + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}*/
	private String sortList(CoderDashboardReq req, String hql) {
	    String sortBy = req.getSortBy();
	    String order = (req.getOrder() == 0) ? "desc" : "asc";
	 
	    switch (sortBy.toLowerCase()) {
	        case "assignedto":
	            hql += " order by LOWER(assigneeUserFullname) " + order;
	            break;
	        case "bbc":
	            hql += " order by LOWER(snfLocationBBC) " + order;
	            break;
	        case "facilityname":
	            hql += " order by LOWER(facilityAlias) " + order;
	            break;
	        case "providername":
	            hql += " order by LOWER(providerName) " + order;
	            break;
	        case "patientname":
	            hql += " order by LOWER(patientName) " + order;
	            break;
	        case "visitid":
	            hql += " order by LOWER(visitId) " + order;
	            break;
	        case "dateofservice":
	            hql += " order by dateOfService " + order;
	            break;
	        case "medicalrecordnumber":
	            hql += " order by LOWER(medicalRecordNumber) " + order;
	            break;
	        case "encountertype":
	            hql += " order by LOWER(encounterType) " + order;
	            break;
	        case "serviceline":
	            hql += " order by LOWER(serviceLine) " + order;
	            break;
	        case "status":
	            hql += " order by LOWER(status) " + order;
	            break;
	        case "ihealconfig":
	            hql += " order by LOWER(ihealConfig) " + order;
	            break;
	        case "age":
	        	 hql += " order by dateOfService " + order; 
		            break;
	        case "interfacedate":
	            hql += " order by receivedDate " + order; 
	            break;
	        case "facilitytype":
	            hql += " order by LOWER(facilityType) " + order;
	            break;
	        default:
	            hql += " order by LOWER(" + sortBy + ") " + order;
	            break;
	    }
	 
	    return hql;
	}
	
	public Long getTotalItemCountPerFacility(String bbc, String taskType,
			String assignee) {
		Long totalItemCount = 0L;

		Session session = this.sessionFactory.getCurrentSession();
		try {
			/*String hql = "SELECT Count(a) FROM Dashboard a Where a.snfLocationBBC = :bluebookId"
					+ " AND a.status IN ('Ready','Review','Returned','Completed',"
					+ "'In Review','Sent','Unbillable','Received','Deficiency','Pending') "
					+ " AND a.lastStatusChangeRole = 'Coder'";*/
			String hql = "SELECT Count(a) FROM Dashboard a Where a.snfLocationBBC = :bluebookId"
					+ " AND a.status IN ('Ready','Returned') "
					+ " AND a.lastStatusChangeRole = 'Coder'";

			log.debug("hql..... :" + hql);

			totalItemCount = (Long) session.createQuery(hql)
					.setParameter("bluebookId", bbc).uniqueResult();
			
			log.debug("totalItemCount : " +totalItemCount);
			
		} catch (Exception e) {
			log.error(
					"Exception occourred while fetching total items per facility: {}",
					e.getMessage());
		}
		return totalItemCount;
	}

//	private String sortList(CoderDashboardReq req, String hql) {
//
//		if (req.getSortBy().equalsIgnoreCase("bbc")) {
//			hql += " order by bluebookId ";
//
//		} else if (req.getSortBy().equalsIgnoreCase("facilityName")) {
//			hql += " order by facilityAlias ";
//
//		} else {
//			hql += " order by " + req.getSortBy() + "";
//
//		}
//		if (req.getOrder() == 0) {
//			hql += " desc";
//		} else {
//			hql += " asc";
//		}
//		return hql;
//	}

//	private String excelSortList(DashboardReq req, String hql) {
//
//		if (req.getSortBy().equalsIgnoreCase("bbc")) {
//			hql += " order by bluebookId ";
//
//		} else if (req.getSortBy().equalsIgnoreCase("facilityName")) {
//			hql += " order by facilityAlias ";
//
//		} else {
//			hql += " order by " + req.getSortBy() + "";
//
//		}
//		if (req.getOrder() == 0) {
//			hql += " desc";
//		} else {
//			hql += " asc";
//		}
//		return hql;
//	}
	
	private String excelSortList(DashboardReq req, String hql) {
		//String sortBy = req.getSortBy().toLowerCase();
		String sortBy = req.getSortBy();
	    String order = (req.getOrder() == 0) ? "desc" : "asc";
	 
	    switch (sortBy.toLowerCase()) {
	        case "assignedto":
	            hql += " order by LOWER(assigneeUserFullname) " + order;
	            break;
	        case "bbc":
	            hql += " order by LOWER(snfLocationBBC) " + order;
	            break;
	        case "facilityname":
	            hql += " order by LOWER(facilityAlias) " + order;
	            break;
	        case "providername":
	            hql += " order by LOWER(providerName) " + order;
	            break;
	        case "patientname":
	            hql += " order by LOWER(patientName) " + order;
	            break;
	        case "visitid":
	            hql += " order by LOWER(visitId) " + order;
	            break;
	        case "dateofservice":
	            hql += " order by dateOfService " + order;
	            break;
	        case "medicalrecordnumber":
	            hql += " order by LOWER(medicalRecordNumber) " + order;
	            break;
	        case "encountertype":
	            hql += " order by LOWER(encounterType) " + order;
	            break;
	        case "serviceline":
	            hql += " order by LOWER(serviceLine) " + order;
	            break;
	        case "status":
	            hql += " order by LOWER(status) " + order;
	            break;
	        case "ihealconfig":
	            hql += " order by LOWER(ihealConfig) " + order;
	            break;
	        case "age":
	        	 hql += " order by dateOfService " + order; 
		            break;
	        case "interfacedate":
	            hql += " order by receivedDate " + order; 
	            break;
	        case "facilitytype":
	            hql += " order by LOWER(facilityType) " + order;
	            break;
	        default:
	            hql += " order by LOWER(" + sortBy + ") " + order;
	            break;
	    }
	 
	    return hql;
	}

	public Map<String, Object> getFilteredCoderList(CoderDashboardReq req,
			int index, String taskType, String assigneeUsername,
			List<String> bbcs,List<String>FacilityIdList) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> coderDashboard = new ArrayList<>();
		List<Object[]> allCoderList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		try {
			String hql = "SELECT DISTINCT a.bluebookId, a.facilityId ,a.facilityAlias ,a.ihealConfig,"
					+ " a.snfLocationBBC, a.snfLocationName, a.isSNFLocation"
					+ " FROM Dashboard a WHERE"
					+ " a.status IN ('Ready','Review','Returned','Completed','In Review','Sent','Unbillable','Received','Deficiency','Pending') "
					+ " AND a.lastStatusChangeRole = 'Coder'";

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {

				//hql += " AND a.snfLocationBBC IN :bbcs";
				hql += " AND a.facilityId IN :FacilityIdList";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcList = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							hql += " a.snfLocationBBC IN :bbc ";
							parameters.put("bbc", bbcList);
						}
							break;
						case "facilityName" : {
							List<String> facilityList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getFacilityName());
							hql += " a.snfLocationName IN :facilityAlias ";
							parameters.put("facilityAlias", facilityList);
						}
							break;
						case "ihealConfig" : {
							List<String> facilityTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getIhealConfig());
							hql += " a.ihealConfig IN :ihealConfig";
							parameters.put("ihealConfig", facilityTypeList);
						}
							break;

						default :
							break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by LOWER(snfLocationBBC) asc";
			}

			log.info("query : {}", hql);

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				//parameters.put("bbcs", bbcs);
				 List<Integer> facilityIdListInt = FacilityIdList.stream()
				            .map(Integer::parseInt)
				            .collect(Collectors.toList());
				parameters.put("FacilityIdList", facilityIdListInt);
			}
			
			log.info("parameters : " +parameters);

			coderDashboard = session.createQuery(hql).setFirstResult(index)
					.setProperties(parameters).setMaxResults(PAGE_SIZE).list();

			allCoderList = session.createQuery(hql).setFirstResult(index)
					.setProperties(parameters).list();

			int count = allCoderList.size() + index;

			listCount.put("Count", count);
			listCount.put("data", coderDashboard);
			log.debug("coderDashboard List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	public Long getTotalCount(int index, String taskType,
			String assigneeUsername, CoderDashboardReq req,
			List<String> bbcList,List<String>FacilityIdList) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;
		List<Integer> facilityIdListInt = FacilityIdList.stream()
	            .map(Integer::parseInt)
	            .collect(Collectors.toList());
		try {
			String hql = "SELECT count(*) FROM Dashboard a WHERE"
					+ " a.status IN ('Ready','Returned')"
					+ " AND a.lastStatusChangeRole = 'Coder'";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				//hql += " AND a.bluebookId IN :bbcList";
				hql += " AND a.facilityId IN :FacilityIdList";
				totalCount = (Long) session.createQuery(hql)
						.setParameter("FacilityIdList", facilityIdListInt).uniqueResult();
			} else {
				totalCount = (Long) session.createQuery(hql).uniqueResult();
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Coder Dashboard total count : {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public Reasons getUnbillableReasons() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons unbillableReasons = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "coder");
			query.setParameter("title", "unbillable");
			unbillableReasons = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error(
					"Exception occurred while fetching all unbillable reasons: {} ",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return unbillableReasons;
	}

	@Override
	public List<Dashboard> getCollapseDetails(String bbc, String assigneeName,
			String taskType, DashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> collapseDetails = new ArrayList<>();
		try {
			String hql = "FROM Dashboard a WHERE a.snfLocationBBC = :bluebookId AND a.ihealConfig = :ihealConfig AND a.status IN ('Ready','Returned')"
					     + " AND a.lastStatusChangeRole = 'Coder'";
			
			// apply sorting here
						if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
							hql = sortLists(req, hql);

						} else {
							log.debug("No requestfound...................");
							hql += " order by a.receivedDate asc";
						}
						
			collapseDetails = session.createQuery(hql)
					.setParameter("bluebookId", bbc)
					.setParameter("ihealConfig", req.getIhealConfig()).list();
			log.info("query : {}", hql);
			
			log.info("collapseDetails list size : {}", collapseDetails.size());
			
		} catch (Exception e) {
			log.error(
					"Exception occurred while fetching collapsible section details for bluebookId: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return collapseDetails;
	}

	@Override
	public CoderDashboardFilter retrieveCoderDashboardFilterOptions(
			CoderDashboardReq req, List<String> bbcList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		CoderDashboardFilter coderDashboardFilter = new CoderDashboardFilter();
		try {
			// String query = " WHERE 1 = 1";
			String query = "WHERE status IN ('Ready','Review','Returned','Completed','In Review',"
					+ "'Sent','Unbillable','Received','Deficiency','Pending') "
					+ " AND lastStatusChangeRole = 'Coder'";
			String filterColumn = req.getFilterOptions();

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				query += " AND bluebookId IN :bbcList";
			}

			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcs = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							query += " snfLocationBBC IN :bbc ";
							parameters.put("bbc", bbcs);
						}
							break;
						case "facilityName" : {
							List<String> facilityList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getFacilityName());
							query += " snfLocationName IN :facilityAlias ";
							parameters.put("facilityAlias", facilityList);
						}
							break;
						case "ihealConfig" : {
							List<String> facilityTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getIhealConfig());
							query += " ihealConfig IN :ihealConfig ";
							parameters.put("ihealConfig", facilityTypeList);
						}
							break;

						default :
							break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("assignedTo")) {
				filterColumn = "assigneeUserFullname";
			}
			if (req.getFilterOptions().equalsIgnoreCase("facilityName")) {
				filterColumn = "snfLocationName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "snfLocationBBC";
			}
			if (req.getFilterOptions().equalsIgnoreCase("ihealConfig")) {
				filterColumn = "ihealConfig";
			}

			hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard " + query
					+ " ORDER BY LOWER(" + filterColumn + ") asc";

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				parameters.put("bbcList", bbcList);
			}

			List<String> distinctValues = session.createQuery(hql)
					.setProperties(parameters).getResultList();
			coderDashboardFilter.setOptions(distinctValues);
			coderDashboardFilter.getOptions()
					.removeIf(element -> element == null
							|| (element != null && element.isEmpty()));
		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return coderDashboardFilter;
	}
	// Method for Finding minimum Service date

	@Override
	public Date getMinServiceDate(String bbc) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Date minDueDate;
		try {
			String hql = "SELECT min(dateOfService) FROM Dashboard"
					+ " WHERE snfLocationBBC = :bluebookId AND status IN ('Ready','Review','Returned',"
					+ "'Completed','In Review','Sent','Unbillable','Received','Deficiency','Pending')"
					+ " AND lastStatusChangeRole = 'Coder' group by snfLocationBBC";
			minDueDate = (Date) session.createQuery(hql)
					.setParameter("bluebookId", bbc).uniqueResult();
			log.debug("minDueDate :" + minDueDate);
		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Coder Dashboard total count : {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return minDueDate;
	}

	@Override
	public List<PlaceOfServiceDetails> getPlaceOfServices() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<PlaceOfServiceDetails> placeOfService = null;
		try {
			String hql = "FROM PlaceOfServiceDetails";
			Query query = session.createQuery(hql);
			placeOfService = query.list();
			log.debug("Query :" + query);
		} catch (Exception e) {
			log.error(
					"Exception occurred while fetching all place Of Services: {} ",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return placeOfService;
	}
 
	@Override
	public void saveLockStatus(DashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			// Check if the record with the given visitId already exists
			String hql = "FROM Dashboard WHERE visitId = :visitId";
			Query <Dashboard> query = session.createQuery(hql, Dashboard.class);
			query.setParameter("visitId", req.getVisitId());
			Dashboard existingRecord =  query.uniqueResult();

			if (existingRecord != null) {
				// If record exists, update the columns
				String updateHql = "UPDATE Dashboard SET isLocked = :isLocked, "
						+ "lastUpdatedByUserId = :lastUpdatedByUserId, "
						+ "lastUpdatedByUsername = :lastUpdatedByUsername, "
						+ "lastUpdatedByUserFullName = :lastUpdatedByUserFullName, "
						+ "lastAccessedTimestamp = :lastAccessedTimestamp "
						+ "WHERE visitId = :visitId";

				Query updateQuery = session.createQuery(updateHql);
				updateQuery.setParameter("isLocked", req.getIsLocked());
				updateQuery.setParameter("lastUpdatedByUserId", req.getLastUpdatedByUserId());
				updateQuery.setParameter("lastUpdatedByUsername", req.getLastUpdatedByUsername());
				updateQuery.setParameter("lastUpdatedByUserFullName", req.getLastUpdatedByUserFullName());
				updateQuery.setParameter("lastAccessedTimestamp", new Timestamp(System.currentTimeMillis()));
				updateQuery.setParameter("visitId", req.getVisitId());
				int rowsUpdated = updateQuery.executeUpdate();
				log.info("Rows updated: {}", rowsUpdated);
			} else {
				// If record doesn't exist, save a new record
				Dashboard details = new Dashboard();
				details.setVisitId(req.getVisitId());
				details.setLastUpdatedByUserId(req.getLastUpdatedByUserId());
				details.setLastUpdatedByUsername(req.getLastUpdatedByUsername());
				details.setLastUpdatedByUserFullName(req.getLastUpdatedByUserFullName());
				details.setIsLocked(req.getIsLocked());
				details.setLastAccessedTimestamp(new Timestamp(System.currentTimeMillis()));

				session.save(details);
			}

			// Save to the AuditQueue if isFromAuditor id true
			if (Boolean.TRUE.equals(req.getIsFromAuditor())) {
				String auditHql = "FROM AuditQueue WHERE visitId = :visitId";
				Query<AuditQueue> audiQuery = session.createQuery(auditHql, AuditQueue.class);
				audiQuery.setParameter("visitId", req.getVisitId());
				AuditQueue existingRecords = audiQuery.uniqueResult();

				if (existingRecords != null) {
					String updateHql = "UPDATE AuditQueue SET isLocked = :isLocked, "
							+ "lastUpdatedByUserId = :lastUpdatedByUserId, "
							+ "lastUpdatedByUserName = :lastUpdatedByUserName, "
							+ "lastUpdatedByUserFullName = :lastUpdatedByUserFullName, " 
							+ "lastAccessedTimestamp = :lastAccessedTimestamp "
							+ "WHERE visitId = :visitId";

					Query updateQuery = session.createQuery(updateHql);
					updateQuery.setParameter("isLocked", req.getIsLocked());
					updateQuery.setParameter("lastUpdatedByUserId", req.getLastUpdatedByUserId());
					updateQuery.setParameter("lastUpdatedByUserName", req.getLastUpdatedByUsername());
					updateQuery.setParameter("lastUpdatedByUserFullName", req.getLastUpdatedByUserFullName());
					updateQuery.setParameter("lastAccessedTimestamp", new Timestamp(System.currentTimeMillis()));
					updateQuery.setParameter("visitId", req.getVisitId());
					int rowsUpdated = updateQuery.executeUpdate();
					log.info("Rows updated: {}", rowsUpdated);
				} else {
					AuditQueue auditQueue = new AuditQueue();
					auditQueue.setVisitId(req.getVisitId());
					auditQueue.setIsLocked(req.getIsLocked());
					auditQueue.setLastUpdatedByUserId(req.getLastUpdatedByUserId());
					auditQueue.setLastUpdatedByUserName(req.getLastUpdatedByUsername());
					auditQueue.setLastUpdatedByUserFullName(req.getLastUpdatedByUserFullName());

					log.debug("initial isLocked status : {}", req.getIsLocked());
					session.save(auditQueue);
					log.debug("AuditQueue entry saved successfully for visitId : {}", req.getVisitId());

				}
			}

		} catch (Exception e) {
			log.error("Exception occurred while saving or updating lock status: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getSearchedCoderList(
			CoderDashboardReq coderDashboardReq, List<String> bbcList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> coderDashboard = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			//String hql = " SELECT a, b.cocId, b.childBluebookId FROM Dashboard a"
					//+" JOIN ChartDetails b ON a.visitId = b.visitId WHERE 1 = 1";
			
			String hql = " FROM Dashboard a WHERE 1 = 1";

			if (coderDashboardReq.getTaskType() != null
					&& coderDashboardReq.getTaskType().equalsIgnoreCase("MY")) {

				hql += " AND a.bluebookId IN :bbcs";
			}

			if (coderDashboardReq.getFilters() != null
					&& !coderDashboardReq.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(
								coderDashboardReq.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
						case "bbc" : {
							hql += "(a.snfLocationBBC = :bbc)";
							
							//hql += "( a.bluebookId = :bbc OR b.childBluebookId = :bbc)";
							parameters.put("bbc", coderDashboardReq.getBbc());
						}
							break;
						case "visitId" : {
							hql += "( a.visitId = :visitId )";
							long visitIdLong = Long.parseLong(coderDashboardReq.getVisitId());
					        parameters.put("visitId", visitIdLong);
							//parameters.put("visitId",
								//	coderDashboardReq.getVisitId());
						}
							break;

						case "patientFirstName" : {
							hql += " (a.patientFirstName LIKE :patientFirstName )";
							parameters.put("patientFirstName",
									"%"+coderDashboardReq.getPatientFirstName()+"%");
						}
							break;

						case "patientLastName" : {
							hql += "( a.patientLastName LIKE :patientLastName )";
							parameters.put("patientLastName","%"+
									coderDashboardReq.getPatientLastName()+"%");
						}
							break;
						case "medicalRecordNumber": {
							List<String> medicalRecordNumberList = FilterRequestUtil
									.getListFromDelimitedStr(coderDashboardReq.getMedicalRecordNumber());
							hql += " a.medicalRecordNumber IN :medicalRecordNumber ";
							parameters.put("medicalRecordNumber", medicalRecordNumberList);
						}
							break;
						case "status": {
							List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(coderDashboardReq.getStatus());
							hql += " a.status IN :status ";
							parameters.put("status", statusList);
						}
							break;

						case "dateOfService" : {
							LocalDate localDate = coderDashboardReq
									.getDateOfService().toLocalDateTime()
									.toLocalDate();
							log.debug("localDate.............."+localDate);
							java.sql.Date sqlDOS = java.sql.Date.valueOf(localDate);
							hql += "( DATE(a.dateOfService) = :dateOfService )";
							parameters.put("dateOfService", sqlDOS);
						}
							break;
						case "dos" : {
							hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
							parameters.put("startDOSDate",
									new Timestamp(dateFormat
											.parse(coderDashboardReq.getStartDOSDate())
											.getTime()));
							parameters.put("endDOSDate",
									new Timestamp(dateFormat
											.parse(coderDashboardReq.getEndDOSDate())
											.getTime()));
						}
							break;

						case "dateOfBirth" : {
							LocalDate localDate = coderDashboardReq
									.getDateOfBirth().toLocalDateTime()
									.toLocalDate();
							log.debug("localDate.............."+localDate);
							java.sql.Date sqlDOB = java.sql.Date.valueOf(localDate);
							hql += "( DATE(a.patientDOB) = :dateOfBirth )";
							parameters.put("dateOfBirth", sqlDOB);
						}
							break;

						default :
							break;
					}
				}
			}

			// apply sorting here
			if (coderDashboardReq.getSortBy() != null
					&& !coderDashboardReq.getSortBy().isEmpty()) {

				hql = sortLists(coderDashboardReq, hql);

			} else {
				hql += " order by LOWER(a.snfLocationBBC) asc";
			}

			log.info("query : {}", hql.toString());

			if (coderDashboardReq.getTaskType() != null
					&& coderDashboardReq.getTaskType().equalsIgnoreCase("MY")) {
				parameters.put("bbcs", bbcList);
			}
			
			log.debug("parameters : " +parameters);

			coderDashboard = session.createQuery(hql).setProperties(parameters)
					.list();

			int count = coderDashboard.size() + coderDashboardReq.getIndex();

			listCount.put("Count", count);
			listCount.put("data", coderDashboard);
			log.debug("coderDashboard List Size:   {} ", count);
		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Search Coder Dashboard Records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public FilterOptions retrieveCollapsibleFilterOption(DashboardReq req, List<String> bbcList,String bbc)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			// String query = " WHERE 1 = 1";
			String query = " WHERE status IN ('Ready','Review','Returned','Completed','In Review',"
					+ "'Sent','Unbillable','Received','Deficiency','Pending') " 
					+ " AND lastStatusChangeRole = 'Coder'";
			
			//if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				//query += " AND bluebookId IN :bbcList";
			//}
			
			query += " AND snfLocationBBC =:bluebookId AND ihealConfig = :ihealConfig";
			
			Map<String, Object> parameters = new HashMap<>();

			String filterColumn = req.getFilterOptions();
 
			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {

					case "age": {
						query += " dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
						parameters.put("ageStartDate", dateFormat.parse(req.getAgeStartDate()));
						parameters.put("ageEndDate", dateFormat.parse(req.getAgeEndDate()));
					}
						break;

					case "dateOfService": {
						query += " dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "medicalRecordNumber": {
						List<String> medicalRecordNumberList = FilterRequestUtil
								.getListFromDelimitedStr(req.getMedicalRecordNumber());
						query += " medicalRecordNumber IN :medicalRecordNumber ";
						parameters.put("medicalRecordNumber", medicalRecordNumberList);
					}
						break;
					case "assignedTo": {
						if (!req.getTaskType().equalsIgnoreCase("MY")) {
							List<String> assignedToList = FilterRequestUtil
									.getListFromDelimitedStr(req.getAssignedTo());
							query += " assigneeUserFullname IN :assignedTo ";
							parameters.put("assignedTo", assignedToList);
						} else {
							query += " 1 = 1 ";
						}
					}
						break;
					case "status": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						query += " status IN :status ";
						parameters.put("status", statusList);
					}
						break;
					case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						query += " patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						query += " patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitIds());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "insurance": {

						List<String> insuranceList = FilterRequestUtil.getListFromDelimitedStr(req.getInsurance());
						query += " (primaryInsurance IN :primaryInsurance OR secondaryInsurance IN :secondaryInsurance) ";
						parameters.put("primaryInsurance", insuranceList);
						parameters.put("secondaryInsurance", insuranceList);
					}
						break;

					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("assignedTo")) {
				filterColumn = "assigneeUserFullname";
			}
			//if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				//parameters.put("bbcList", bbcList);
			//}
			if (req.getFilterOptions().equalsIgnoreCase("medicalRecordNumber")) {
				filterColumn = "medicalRecordNumber";
			}
			if (req.getFilterOptions().equalsIgnoreCase("status")) {
				filterColumn = "status";
			}
			if (req.getFilterOptions().equalsIgnoreCase("patientFirstName")) {
				filterColumn = "patientFirstName";
			}
			
			if (req.getFilterOptions().equalsIgnoreCase("insurance")) {
				hql = "SELECT DISTINCT CASE WHEN primaryInsurance IS NOT NULL THEN primaryInsurance ELSE secondaryInsurance END FROM Dashboard "
						+ query
						+ " ORDER BY LOWER( CASE WHEN primaryInsurance IS NOT NULL THEN primaryInsurance ELSE secondaryInsurance END ) ASC";
				List<String> insuranceValues = session.createQuery(hql).setParameter("bluebookId", bbc)
						                       .setParameter("ihealConfig", req.getIhealConfig())
						                       .setProperties(parameters).getResultList();
				log.debug("insuranceValues.........", insuranceValues);
				filterOptions.setOptions(insuranceValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

			else if ((req.getFilterOptions().equalsIgnoreCase("age"))
					|| (req.getFilterOptions().equalsIgnoreCase("interfaceDate"))) {
				String dateHql = "SELECT MIN(receivedDate), MAX(receivedDate) FROM Dashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("bluebookId", bbc)
						                 .setParameter("ihealConfig", req.getIhealConfig())
						                 .setProperties(parameters).uniqueResult();

				filterOptions.setMinReceivedDate((Date) object[0]);
				filterOptions.setMaxReceivedDate((Date) object[1]);
			} else if (req.getFilterOptions().equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(dateOfService), MAX(dateOfService) FROM Dashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("bluebookId", bbc)
						                                  .setParameter("ihealConfig", req.getIhealConfig())
						                                 .setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM Dashboard " + query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setParameter("bluebookId", bbc)
						                    .setParameter("ihealConfig", req.getIhealConfig())
						                    .setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard " + query + " ORDER BY LOWER(" + filterColumn
						+ ") asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("bluebookId", bbc)
						                 .setParameter("ihealConfig", req.getIhealConfig())
						                 .setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	private String sortLists(DashboardReq req, String hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("firstName")) {
			hql += " order by LOWER(a.patientFirstName) ";
		} else if (sortBy.equals("lastName")) {
			hql += " order by LOWER(a.patientLastName) ";
		} else if (sortBy.equals("status")) {
			hql += " order by LOWER(a.status) ";
		} else if (sortBy.equals("age")) {
			hql += " order by LOWER(a.receivedDate) ";
		} else if (sortBy.equals("insurance")) {
			hql += " order by CASE WHEN primaryInsurance IS NOT NULL THEN LOWER(a.primaryInsurance) ELSE LOWER(a.secondaryInsurance) END ";
		} else {
			hql += " order by LOWER(a." + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public Map<String, Object> getCollapsibleFilteredData(DashboardReq req, int index, String taskType, String assignee,
			List<String> bbcs, boolean isApplyPagination, String bbc) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> collapsibleSection = new ArrayList<>();
		List<Dashboard> alldata = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			
			String hql = "FROM Dashboard a WHERE a.snfLocationBBC = :bluebookId AND a.ihealConfig = :ihealConfig AND a.lastStatusChangeRole = 'Coder'";
			
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			}else{
				hql += " AND a.status IN ('Ready','Returned')";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				
				log.debug("filterList............."+filterList);

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "age": {
						hql += " a.receivedDate BETWEEN :ageStartDate AND :ageEndDate ";
						parameters.put("ageStartDate", dateFormat.parse(req.getAgeStartDate()));
						parameters.put("ageEndDate", dateFormat.parse(req.getAgeEndDate()));
					}
						break;

					case "dateOfService": {
						hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;
					case "medicalRecordNumber": {
						List<String> medicalRecordNumberList = FilterRequestUtil
								.getListFromDelimitedStr(req.getMedicalRecordNumber());
						hql += " a.medicalRecordNumber IN :medicalRecordNumber ";
						parameters.put("medicalRecordNumber", medicalRecordNumberList);
					}
						break;
					case "assignedTo": {
						if (!taskType.equalsIgnoreCase("MY")) {
							List<String> assignedToList = FilterRequestUtil
									.getListFromDelimitedStr(req.getAssignedTo());
							hql += " a.assigneeUserFullname IN :assignedTo ";
							parameters.put("assignedTo", assignedToList);
						} else {
							hql += " 1 = 1 ";
						}
					}
						break;
					case "status": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						hql += " a.status IN :status ";
						parameters.put("status", statusList);
					}
						break;
					case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						log.debug("firstNames...."+firstNames);
						hql += " a.patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						hql += " a.patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;

					case "visitId": {
						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitIds());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}

						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "insurance": {

						List<String> insuranceList = FilterRequestUtil.getListFromDelimitedStr(req.getInsurance());
						log.debug("insuranceList..........."+insuranceList);

						hql += "(CASE WHEN a.primaryInsurance IS NOT NULL THEN a.primaryInsurance ELSE  a.secondaryInsurance END) IN (:insuranceList)";
						parameters.put("insuranceList", insuranceList);
					}
						break;

					default:
						break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortLists(req, hql);

			} else {
				log.debug("No request found...................");
				hql += " order by receivedDate asc";
			}
			log.info("query : {}", hql);

			collapsibleSection = session.createQuery(hql)
					.setParameter("bluebookId", bbc)
					.setParameter("ihealConfig", req.getIhealConfig())
					.setProperties(parameters).list();

			//alldata = session.createQuery(hql)
					//.setFirstResult(index)
					//.setProperties(parameters).list();

			int count = collapsibleSection.size();

			listCount.put("Count", count);
			listCount.put("data", collapsibleSection);
			log.debug("coderDashboard List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}
	
	@Override
	public FilterOptions advanceSearchFilterOption(CoderDashboardReq req, List<String> bbcList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = " WHERE 1 = 1";
			
			Map<String, Object> parameters = new HashMap<>();

			String filterColumn = req.getFilterOptions();
			log.debug("filterColumn..............."+filterColumn);
			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					
					//query += " AND ";

					switch (filterReq) {

					case "patientDOB": {
						query += " AND patientDOB BETWEEN :ageStartDate AND :ageEndDate ";
						parameters.put("ageStartDate", dateFormat.parse(req.getAgeStartDate()));
						parameters.put("ageEndDate", dateFormat.parse(req.getAgeEndDate()));
						//parameters.put("ageStartDate", req.getAgeStartDate());
						//parameters.put("ageEndDate", req.getAgeEndDate());
					}
						break;
						
					case "bbc": {
						List<String> bbcs = FilterRequestUtil
								.getListFromDelimitedStr(req.getBbc());
						log.debug("bbcs============="+bbcs);
						query += " AND snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;

					case "dateOfService": {
						query += " AND dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "medicalRecordNumber": {
						List<String> medicalRecordNumberList = FilterRequestUtil
								.getListFromDelimitedStr(req.getMedicalRecordNumber());
						query += " AND medicalRecordNumber IN :medicalRecordNumber ";
						parameters.put("medicalRecordNumber", medicalRecordNumberList);
					}
						break;
					case "status": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						query += " AND status IN :status ";
						parameters.put("status", statusList);
					}
						break;
					/*case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						log.debug("firstNames..............."+firstNames);
						query += " patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						query += " patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;*/
						
					case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						log.debug("firstNames...."+firstNames);
						query += " AND patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						query += " AND patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;
						
					case "chartLocation": {
 						List<String> locations = FilterRequestUtil.getListFromDelimitedStr(req.getChartLocation());
 						query += " AND lastStatusChangeRole IN :lastStatusChangeRole ";
 						parameters.put("lastStatusChangeRole", locations);
 					}
 						break;
						
					case "visitId" : {
						List<String> visitIdList = FilterRequestUtil
								.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " AND visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("assignedTo")) {
				filterColumn = "assigneeUserFullname";
			}
			//if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				//parameters.put("bbcList", bbcList);
			//}
			if (req.getFilterOptions().equalsIgnoreCase("medicalRecordNumber")) {
				filterColumn = "medicalRecordNumber";
			}
			if (req.getFilterOptions().equalsIgnoreCase("status")) {
				filterColumn = "status";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "snfLocationBBC";
			}
			
			 if (req.getFilterOptions().equalsIgnoreCase("patientDOB")) {
				String dateHql = "SELECT MIN(patientDOB), MAX(patientDOB) FROM Dashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						                 .setProperties(parameters).uniqueResult();

				filterOptions.setMinDOB((Date) object[0]);
				filterOptions.setMaxDOB((Date) object[1]);
			}else if (req.getFilterOptions()
					.equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(dateOfService), MAX(dateOfService) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			}else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM Dashboard " + query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1)
						                    .setProperties(parameters)
						                    .getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
				
		} else if (req.getFilterOptions().equalsIgnoreCase("chartLocation")) {
			    hql = "SELECT DISTINCT CASE " +
			            "WHEN lastStatusChangeRole = 'CMC' THEN 'CMC' " +
			            "WHEN lastStatusChangeRole = 'Coder' THEN 'Coder' " +
			            "WHEN lastStatusChangeRole IN ('Auditor', 'Nurse') THEN 'Auditor' " +
			            "ELSE lastStatusChangeRole END " +
			            "FROM Dashboard " + query + " ORDER BY LOWER(lastStatusChangeRole) asc";
			      List<String> distinctValues = session.createQuery(hql)
			                           .setProperties(parameters).getResultList();
			      filterOptions.setOptions(distinctValues);
			      filterOptions.getOptions()
			              .removeIf(element -> element == null || (element != null && element.isEmpty()));
			}else {
				
				hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard " 
				 + query + " ORDER BY LOWER(" + filterColumn
						+ ") asc";
				List<String> distinctValues = session.createQuery(hql)
						                 .setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}	

	/*@Override
	public Map<String, Object> searchCoderfilterData(CoderDashboardReq req, int index, String taskType, String assignee,
			List<String> bbcList1, boolean isApplyPagination) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> collapsibleSection = new ArrayList<>();
		List<Dashboard> alldata = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			
			//String hql = "FROM Dashboard a WHERE a.snfLocationBBC = :bluebookId AND a.ihealConfig = :ihealConfig AND a.lastStatusChangeRole = 'Coder'";
			String hql = "FROM Dashboard a WHERE 1=1";
			
			/*if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			}else{
				hql += " AND a.status IN ('Ready','Returned')";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				
				log.debug("filterList............."+filterList);

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "PatientDOB": {
						hql += " a.patientDOB BETWEEN :ageStartDate AND :ageEndDate ";
						parameters.put("ageStartDate", dateFormat.parse(req.getAgeStartDate()));
						parameters.put("ageEndDate", dateFormat.parse(req.getAgeEndDate()));
					}
						break;
						
					case "bbc/location": {
						List<String> bbcs = FilterRequestUtil
								.getListFromDelimitedStr(req.getBbc());
						log.debug("bbcs============="+bbcs);
						hql += " a.snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;

					case "dateOfService": {
						hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "medicalRecordNumber": {
						List<String> medicalRecordNumberList = FilterRequestUtil
								.getListFromDelimitedStr(req.getMedicalRecordNumber());
						hql += " a.medicalRecordNumber IN :medicalRecordNumber ";
						parameters.put("medicalRecordNumber", medicalRecordNumberList);
					}
						break;
					case "status": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						hql += " a.status IN :status ";
						parameters.put("status", statusList);
					}
						break;
					case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						log.debug("firstNames..............."+firstNames);
						hql += " a.patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						hql += " a.patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitIds());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					default:
						break;
					}
				}
			}
			log.debug("query :  {}", hql);
			log.debug("parameters:   {}", parameters);
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				//hql = sortListForSearch(req, hql);

			} else {
				log.debug("No request found...................");
				hql += " order by receivedDate asc";
			}
			log.info("query : {}", hql);

			collapsibleSection = session.createQuery(hql)
					.setProperties(parameters).list();
			int count = collapsibleSection.size();

			listCount.put("Count", count);
			listCount.put("data", collapsibleSection);
			log.debug("coderDashboard List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}*/

	private String sortLists(CoderDashboardReq req, String hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("firstName")) {
			hql += " order by LOWER(a.patientFirstName) ";
		} else if (sortBy.equals("lastName")) {
			hql += " order by LOWER(a.patientLastName) ";
		} else if (sortBy.equals("status")) {
			hql += " order by LOWER(a.status) ";
		} else if (sortBy.equals("patientDOB")) {
			hql += " order by LOWER(a.patientDOB) ";
		} else if (sortBy.equals("bbc")) {
			hql += " order by LOWER(snfLocationBBC) ";
		} else if (sortBy.equals("facilityName")) {
			hql += " order by LOWER(snfLocationName) ";
		} else if (sortBy.equals("ihealConfig")) {
			hql += " order by LOWER(ihealConfig) ";
		}else if (sortBy.equals("chartLocation")) {
 			//hql += " order by LOWER(lastStatusChangeRole) ";
 			 hql += " order by CASE WHEN LOWER(lastStatusChangeRole) = 'nurse' "
 			 		+ "THEN 'auditor' ELSE LOWER(lastStatusChangeRole) END ";
		} else if (sortBy.equals("dateOfService")) {
			hql += " order by LOWER(a.dateOfService) ";
		} else {
			hql += " order by LOWER(a." + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public Map<String, Object> getSearchedCoderdataList(CoderDashboardReq req, List<String> bbcList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> coderDashboard = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			//String hql = " SELECT a, b.cocId, b.childBluebookId FROM Dashboard a"
					//+" JOIN ChartDetails b ON a.visitId = b.visitId WHERE 1 = 1";
			
			String hql = " FROM Dashboard a WHERE 1 = 1";

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {

				hql += " AND a.bluebookId IN :bbcs";
			}

			if (req.getFilters() != null
					&& !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(
								req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcList1 = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							hql += " a.snfLocationBBC IN :bbc";
							parameters.put("bbc", bbcList1);
						}
							break;
						case "visitId" : {
							List<String> visitIdList = FilterRequestUtil
									.getListFromDelimitedStr(req.getVisitId());
							List<Long> intvisitIdList = new ArrayList<>();
							for (String s : visitIdList) {
								intvisitIdList.add(Long.valueOf(s));
							}
							hql += " a.visitId IN :visitId ";
							parameters.put("visitId", intvisitIdList);
						}
							break;

						case "patientFirstName": {
							List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
							log.debug("firstNames...."+firstNames);
							hql += " a.patientFirstName IN :patientFirstName ";
							parameters.put("patientFirstName", firstNames);
						}
							break;
						case "patientLastName": {
							List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
							hql += " patientLastName IN :patientLastName ";
							parameters.put("patientLastName", lastNames);
						}
							break;
						case "medicalRecordNumber": {
							List<String> medicalRecordNumberList = FilterRequestUtil
									.getListFromDelimitedStr(req.getMedicalRecordNumber());
							hql += " a.medicalRecordNumber IN :medicalRecordNumber ";
							parameters.put("medicalRecordNumber", medicalRecordNumberList);
						}
							break;
						case "status": {
							List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
							hql += " a.status IN :status ";
							parameters.put("status", statusList);
						}
							break;
						case "chartLocation": {
 							List<String> locations = FilterRequestUtil.getListFromDelimitedStr(req.getChartLocation());
 							hql += " a.lastStatusChangeRole IN :lastStatusChangeRole ";
 							parameters.put("lastStatusChangeRole", locations);
 						}
 							break;

						case "dateOfService" : {
							LocalDate localDate = req
									.getDateOfService().toLocalDateTime()
									.toLocalDate();
							log.debug("localDate.............."+localDate);
							java.sql.Date sqlDOS = java.sql.Date.valueOf(localDate);
							hql += "( DATE(a.dateOfService) = :dateOfService )";
							parameters.put("dateOfService", sqlDOS);
						}
							break;
						case "dos" : {
							hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
							parameters.put("startDOSDate",
									new Timestamp(dateFormat
											.parse(req.getStartDOSDate())
											.getTime()));
							parameters.put("endDOSDate",
									new Timestamp(dateFormat
											.parse(req.getEndDOSDate())
											.getTime()));
						}
							break;
						case "patientDOB": {
							hql += " a.patientDOB BETWEEN :ageStartDate AND :ageEndDate ";
							parameters.put("ageStartDate", (dateFormat.parse(req.getAgeStartDate())));
							parameters.put("ageEndDate", (dateFormat.parse(req.getAgeEndDate())));
						}
							break;

						default :
							break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null
					&& !req.getSortBy().isEmpty()) {

				hql = sortLists(req, hql);

			} else {
				hql += " order by LOWER(a.snfLocationBBC) asc";
			}

			log.info("query : {}", hql.toString());

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				parameters.put("bbcs", bbcList);
			}
			
			log.debug("parameters : " +parameters);

			coderDashboard = session.createQuery(hql)
					.setProperties(parameters)
					.list();
			int count = coderDashboard.size() + req.getIndex();
			listCount.put("Count", count);
			listCount.put("data", coderDashboard);
			log.debug("coderDashboard List Size:   {} ", count);
		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Search Coder Dashboard Records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<Object[]> getAllCoderRecord(CoderDashboardReq req, int index,
			String taskType, String assignee, List<String> bbclist,List<String>FacilityIdList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> coderDashboard = new ArrayList<>();

		LocalDate sevenDate = LocalDate.now().minusDays(7);
		Date sevenDaysDate = Date.from(sevenDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Timestamp sevTimestamp = new Timestamp(sevenDaysDate.getTime());
		try {
			
			String hqlString = "SELECT r.bluebookId,r.facilityId,coalesce(NULLIF(r.facilityAlias,''),'') AS facilityAlias,r.ihealConfig,"
					+ " r.snfLocationBBC,r.snfLocationName, r.isSNFLocation,r.receivedDate,r.providerName,r.providerId,r.visitId,"
					+ " r.medicalRecordNumber,r.encounterType,r.serviceLine,r.coderNotes,r.status,r.patientDOB,r.dateOfService,r.patientId,"
					+ "r.patientName,r.isLocked,r.lastUpdatedByUserFullName"
					+ " FROM Dashboard r WHERE r.status IN ('Ready','Returned')"
					+ " AND r.lastStatusChangeRole = 'Coder' ";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				//hqlString += " AND r.bluebookId IN :bbcList ";
				hqlString += " AND r.facilityId IN :FacilityIdList ";
				log.debug("hqlString..... :" + hqlString);
			}
			
			//hqlString =	hqlString + " GROUP BY coalesce(NULLIF(r.snfLocationBBC,''),'') ";
			
			//apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hqlString = sortList(req, hqlString);

			} else {
				//hqlString += " order by LOWER(receivedDate) asc";
				hqlString += " order by receivedDate asc";
			}

			log.info("query : {}", hqlString);

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				List<Integer> facilityIdListInt = FacilityIdList.stream()
			            .map(Integer::parseInt)
			            .collect(Collectors.toList());
				coderDashboard = session.createQuery(hqlString)
						.setParameter("FacilityIdList", facilityIdListInt)
						//.setParameter("sevTimestamp", sevTimestamp)
						.setFirstResult(index)
						.setMaxResults(PAGE_SIZE).list();
			} else {
				coderDashboard = session.createQuery(hqlString)
						.setFirstResult(index)
						.setMaxResults(PAGE_SIZE)
						.list();
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching all Coder records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return coderDashboard;
	}

	@Override
	public FilterOptions retrieveCoderDashboardFilterOption(CoderDashboardReq req, List<String> bbcList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			// String query = " WHERE 1 = 1";
			String query = "WHERE status IN ('Ready','Review','Returned','Completed','In Review',"
					+ "'Sent','Unbillable','Received','Deficiency','Pending') "
					+ " AND lastStatusChangeRole = 'Coder'";
			String filterColumn = req.getFilterOptions();

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				query += " AND bluebookId IN :bbcList";
			}

			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());
				log.debug("filterList============="+filterList);
				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcs = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							query += " snfLocationBBC IN :bbc ";
							parameters.put("bbc", bbcs);
						}
							break;
						case "interfaceDate" : {
							query += " receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
							parameters.put("startInterfaceDate", dateFormat
									.parse(req.getStartInterfaceDate()));
							parameters.put("endInterfaceDate", dateFormat
									.parse(req.getEndInterfaceDate()));
						}
							break;
							
						case "age" : {
							query += " dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
							parameters.put("ageStartDate",
									dateFormat.parse(req.getAgeStartDate()));
							parameters.put("ageEndDate",
									dateFormat.parse(req.getAgeEndDate()));
						}
							break;
						case "providerName" : {
							List<String> providerNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getProviderName());
							query += " providerName IN :providerName ";
							parameters.put("providerName", providerNameList);
						}
							break;

						case "patientName" : {
							List<String> patientNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getPatientName());
							query += " patientName IN :patientName ";
							parameters.put("patientName", patientNameList);
						}
							break;
						case "visitId" : {

							List<String> visitIdList = FilterRequestUtil
									.getListFromDelimitedStr(req.getVisitIds());
							List<Long> intvisitIdList = new ArrayList<>();
							for (String s : visitIdList) {
								intvisitIdList.add(Long.valueOf(s));
							}
							query += " visitId IN :visitId ";
							parameters.put("visitId", intvisitIdList);
						}
							break;
						case "dateOfService" : {
							query += " dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
							parameters.put("startDOSDate",
									new Timestamp(dateFormat
											.parse(req.getStartDOSDate())
											.getTime()));
							parameters.put("endDOSDate",
									new Timestamp(dateFormat
											.parse(req.getEndDOSDate())
											.getTime()));
						}
							break;

						case "medicalRecordNumber" : {
							List<String> medicalRecordNumberList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getMedicalRecordNumber());
							query += " medicalRecordNumber IN :medicalRecordNumber ";
							parameters.put("medicalRecordNumber",
									medicalRecordNumberList);
						}
							break;

						case "encounterType" : {
							List<String> encounterTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getEncounterType());
							query += " encounterType IN :encounterType ";
							parameters.put("encounterType", encounterTypeList);
						}
							break;
						case "serviceLine" : {
							List<String> serviceLineList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getServiceLine());
							query += " serviceLine IN :serviceLine ";
							parameters.put("serviceLine", serviceLineList);
						}
							break;

						case "chartNotes" : {
							List<String> cmcNotesList = FilterRequestUtil
									.getListFromDelimitedStr(req.getChartNotes());
							query += " coderNotes IN :coderNotes ";
							parameters.put("coderNotes", cmcNotesList);
						}
							break;

						case "status" : {
							List<String> statusList = FilterRequestUtil
									.getListFromDelimitedStr(req.getStatus());
							query += " status IN :status ";
							parameters.put("status", statusList);
						}
							break;

						case "ihealConfig" : {
							List<String> facilityTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getIhealConfig());
							query += " ihealConfig IN :ihealConfig ";
							parameters.put("ihealConfig", facilityTypeList);
						}
							break;

						default :
							break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			/*if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				//List<Integer> facilityIdListInt = facilityIdList.stream()
			            //.map(Integer::parseInt)
			           // .collect(Collectors.toList());
				//parameters.put("bbcList", bbcList);
				//parameters.put("FacilityIdList", facilityIdListInt);
			}*/
			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				parameters.put("bbcList", bbcList);
			}

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("assignedTo")) {
				filterColumn = "assigneeUserFullname";
			}
			if (req.getFilterOptions().equalsIgnoreCase("facilityName")) {
				filterColumn = "snfLocationName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "snfLocationBBC";
			}
			if (req.getFilterOptions().equalsIgnoreCase("chartNotes")) {
				filterColumn = "coderNotes";
			}
			if (req.getFilterOptions().equalsIgnoreCase("ihealConfig")) {
				filterColumn = "ihealConfig";
			}
			if ((req.getFilterOptions().equalsIgnoreCase("age"))) {
				String dateHql = "SELECT MIN(dateOfService), MAX(dateOfService) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);
			}else if ((req.getFilterOptions().equalsIgnoreCase("interfaceDate"))) {
				String dateHql = "SELECT MIN(receivedDate), MAX(receivedDate) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinReceivedDate((Date) object[0]);
				filterOptions.setMaxReceivedDate((Date) object[1]);
			
			
			}else if (req.getFilterOptions()
					.equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(dateOfService), MAX(dateOfService) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1)
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard "
						+ query + " ORDER BY LOWER(" + filterColumn + ") asc";
				
				List<String> distinctValues = session.createQuery(hql)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null
								|| (element != null && element.isEmpty()));
				}

			/*if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				parameters.put("bbcList", bbcList);
			}*/

			
		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public Map<String, Object> getFilteredCoderLists(CoderDashboardReq req, int index, String taskType, String assignee,
			List<String> bbcList, List<String> facilityIdList) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> coderDashboard = new ArrayList<>();
		List<Object[]> allCoderList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			
			String query = "SELECT r.bluebookId,r.facilityId,coalesce(NULLIF(r.facilityAlias,''),'') AS facilityAlias,r.ihealConfig,"
					+ " r.snfLocationBBC,r.snfLocationName, r.isSNFLocation,r.receivedDate,r.providerName,r.providerId,r.visitId,"
					+ " r.medicalRecordNumber,r.encounterType,r.serviceLine,r.coderNotes,r.status,r.patientDOB,r.dateOfService,r.patientId,"
					+ "r.patientName,r.isLocked,r.lastUpdatedByUserFullName"
					+ " FROM Dashboard r WHERE r.status IN ('Ready','Review','Returned','Completed','In Review','Sent','Unbillable','Received','Deficiency','Pending')"
					+ " AND r.lastStatusChangeRole = 'Coder' ";
			
			/*String hql = "SELECT DISTINCT a.bluebookId, a.facilityId ,a.facilityAlias ,a.ihealConfig,"
					+ " a.snfLocationBBC, a.snfLocationName, a.isSNFLocation"
					+ " FROM Dashboard a WHERE"
					+ " a.status IN ('Ready','Review','Returned','Completed','In Review','Sent','Unbillable','Received','Deficiency','Pending') "
					+ " AND a.lastStatusChangeRole = 'Coder'";*/

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {

				//hql += " AND a.snfLocationBBC IN :bbcs";
				query += " AND r.facilityId IN :FacilityIdList";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					//query += " AND ";

					switch (filterReq) {
					case "bbc" : {
						List<String> bbcs = FilterRequestUtil
								.getListFromDelimitedStr(req.getBbc());
						query += " AND snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "interfaceDate" : {
						query += " AND receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
						parameters.put("startInterfaceDate", dateFormat
								.parse(req.getStartInterfaceDate()));
						parameters.put("endInterfaceDate", dateFormat
								.parse(req.getEndInterfaceDate()));
					}
						break;
						
					case "age" : {
						query += " AND dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
						parameters.put("ageStartDate",
								dateFormat.parse(req.getAgeStartDate()));
						parameters.put("ageEndDate",
								dateFormat.parse(req.getAgeEndDate()));
					}
						break;
					case "providerName" : {
						List<String> providerNameList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getProviderName());
						query += " AND providerName IN :providerName ";
						parameters.put("providerName", providerNameList);
					}
						break;

					case "patientName" : {
						List<String> patientNameList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getPatientName());
						query += " AND patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;
					case "visitId" : {

						List<String> visitIdList = FilterRequestUtil
								.getListFromDelimitedStr(req.getVisitIds());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " AND visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "dateOfService" : {
						query += " AND dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat
										.parse(req.getStartDOSDate())
										.getTime()));
						parameters.put("endDOSDate",
								new Timestamp(dateFormat
										.parse(req.getEndDOSDate())
										.getTime()));
					}
						break;

					case "medicalRecordNumber" : {
						List<String> medicalRecordNumberList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getMedicalRecordNumber());
						query += " AND medicalRecordNumber IN :medicalRecordNumber ";
						parameters.put("medicalRecordNumber",
								medicalRecordNumberList);
					}
						break;

					case "encounterType" : {
						List<String> encounterTypeList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getEncounterType());
						query += " AND encounterType IN :encounterType ";
						parameters.put("encounterType", encounterTypeList);
					}
						break;
					case "serviceLine" : {
						List<String> serviceLineList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getServiceLine());
						query += " AND serviceLine IN :serviceLine ";
						parameters.put("serviceLine", serviceLineList);
					}
						break;

					case "chartNotes" : {
						List<String> cmcNotesList = FilterRequestUtil
								.getListFromDelimitedStr(req.getChartNotes());
						query += " AND coderNotes IN :coderNotes ";
						parameters.put("coderNotes", cmcNotesList);
					}
						break;

					case "status" : {
						List<String> statusList = FilterRequestUtil
								.getListFromDelimitedStr(req.getStatus());
						query += " AND status IN :status ";
						parameters.put("status", statusList);
					}
						break;

					case "ihealConfig" : {
						List<String> facilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getIhealConfig());
						query += " AND ihealConfig IN :ihealConfig ";
						parameters.put("ihealConfig", facilityTypeList);
					}
						break;

					default :
						break;
				}
			}
		}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				query = sortList(req, query);

			} else {
				query += " order by LOWER(snfLocationBBC) asc";
			}

			log.info("query : {}", query);

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				//parameters.put("bbcs", bbcs);
				 List<Integer> facilityIdListInt = facilityIdList.stream()
				            .map(Integer::parseInt)
				            .collect(Collectors.toList());
				parameters.put("FacilityIdList", facilityIdListInt);
			}
			
			log.info("parameters : " +parameters);

			coderDashboard = session.createQuery(query).setFirstResult(index)
					.setProperties(parameters).setMaxResults(PAGE_SIZE).list();

			allCoderList = session.createQuery(query).setFirstResult(index)
					.setProperties(parameters).list();

			int count = allCoderList.size() + index;

			listCount.put("Count", count);
			listCount.put("data", coderDashboard);
			log.debug("coderDashboard List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public Map<String, Object> getFilteredCoderExcelList(CoderDashboardReq req, int index,
			String taskType, String assignee, boolean isApplyPagination,
			List<String> facilityIdList) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> coderDashboard = new ArrayList<>();
		List<Dashboard> allCoderList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String hql = "FROM Dashboard a WHERE"
					+ " status IN ('Ready','Review','Returned','Completed',"
					+ "'In Review','Sent','Unbillable','Received','Deficiency','Pending')"
					+ " AND a.lastStatusChangeRole = 'Coder'";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.facilityId IN :FacilityIdList";

				log.debug("hql..... :" + hql);
			}
			
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					//hql += " AND ";

					switch (filterReq) {
					case "bbc" : {
						List<String> bbcs = FilterRequestUtil
								.getListFromDelimitedStr(req.getBbc());
						hql += " AND snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "interfaceDate" : {
						hql += " AND receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
						parameters.put("startInterfaceDate", dateFormat
								.parse(req.getStartInterfaceDate()));
						parameters.put("endInterfaceDate", dateFormat
								.parse(req.getEndInterfaceDate()));
					}
						break;
						
					case "age" : {
						hql += " AND dateOfService BETWEEN :ageStartDate AND :ageEndDate ";
						parameters.put("ageStartDate",
								dateFormat.parse(req.getAgeStartDate()));
						parameters.put("ageEndDate",
								dateFormat.parse(req.getAgeEndDate()));
					}
						break;
					case "providerName" : {
						List<String> providerNameList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getProviderName());
						hql += " AND providerName IN :providerName ";
						parameters.put("providerName", providerNameList);
					}
						break;

					case "patientName" : {
						List<String> patientNameList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getPatientName());
						hql += " AND patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;
					case "visitId" : {

						List<String> visitIdList = FilterRequestUtil
								.getListFromDelimitedStr(req.getVisitIds());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " AND visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "dateOfService" : {
						hql += " AND dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat
										.parse(req.getStartDOSDate())
										.getTime()));
						parameters.put("endDOSDate",
								new Timestamp(dateFormat
										.parse(req.getEndDOSDate())
										.getTime()));
					}
						break;

					case "medicalRecordNumber" : {
						List<String> medicalRecordNumberList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getMedicalRecordNumber());
						hql += " AND medicalRecordNumber IN :medicalRecordNumber ";
						parameters.put("medicalRecordNumber",
								medicalRecordNumberList);
					}
						break;

					case "encounterType" : {
						List<String> encounterTypeList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getEncounterType());
						hql += " AND encounterType IN :encounterType ";
						parameters.put("encounterType", encounterTypeList);
					}
						break;
					case "serviceLine" : {
						List<String> serviceLineList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getServiceLine());
						hql += " AND serviceLine IN :serviceLine ";
						parameters.put("serviceLine", serviceLineList);
					}
						break;

					case "chartNotes" : {
						List<String> cmcNotesList = FilterRequestUtil
								.getListFromDelimitedStr(req.getChartNotes());
						hql += " AND coderNotes IN :coderNotes ";
						parameters.put("coderNotes", cmcNotesList);
					}
						break;

					case "status" : {
						List<String> statusList = FilterRequestUtil
								.getListFromDelimitedStr(req.getStatus());
						hql += " AND status IN :status ";
						parameters.put("status", statusList);
					}
						break;

					case "ihealConfig" : {
						List<String> facilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(
										req.getIhealConfig());
						hql += " AND ihealConfig IN :ihealConfig ";
						parameters.put("ihealConfig", facilityTypeList);
					}
						break;

					default :
						break;
				}
			}
		}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);
			} else {
				hql += " order by receivedDate asc";
			}
			
			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				List<Integer> facilityIdListInt = facilityIdList.stream()
			            .map(Integer::parseInt)
			            .collect(Collectors.toList());
			parameters.put("FacilityIdList", facilityIdListInt);

			}
			
			log.info("query : {}", hql);
			
			int count;

			if (isApplyPagination) {
				coderDashboard = session.createQuery(hql).setFirstResult(index)
						.setProperties(parameters).setMaxResults(PAGE_SIZE)
						.list();

				allCoderList = session.createQuery(hql).setFirstResult(index)
						.setProperties(parameters).list();

				count = allCoderList.size() + index;
			} else {
				coderDashboard = session.createQuery(hql).setFirstResult(index)
						.setProperties(parameters).list();

				count = coderDashboard.size() + index;
			}

			listCount.put("Count", count);
			listCount.put("data", coderDashboard);
			log.debug("coderDashboard List Size:   {} ", count);

		} catch (IllegalArgumentException e) {
			log.error("Requested Filter cannot be applied for coder dashboard");
			throw new EncodeExceptionHandler(e.getMessage());

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<Dashboard> getAllCoderExcelRecords(CoderDashboardReq req, int index,
			String taskType, String assignee, boolean isApplyPagination,
			List<String> FacilityIdList) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> coderDashboard = new ArrayList<>();

		try {
			String hql = "FROM Dashboard a WHERE"
					//+ " status IN ('Ready','Review','Returned','Completed',"
					    + " a.status IN ('Ready','Returned')"
					//+ "'In Review','Sent','Unbillable','Received','Deficiency','Pending')"
					+ " AND a.lastStatusChangeRole = 'Coder'";
			
			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.facilityId IN :FacilityIdList ";

				log.debug("hql..... :" + hql);
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by receivedDate asc";
			}

			log.info("query : {}", hql);

			if (isApplyPagination) {
				if (taskType != null && taskType.equalsIgnoreCase("MY")) {
					List<Integer> facilityIdListInt = FacilityIdList.stream()
				            .map(Integer::parseInt)
				            .collect(Collectors.toList());
					coderDashboard = session.createQuery(hql)
							.setFirstResult(index)
							//.setParameter("bbcList", bbcList)
							.setParameter("FacilityIdList", facilityIdListInt)
							.setMaxResults(PAGE_SIZE).list();
				} else {
					coderDashboard = session.createQuery(hql)
							.setFirstResult(index)
							.setMaxResults(PAGE_SIZE).list();
				}
				
			} else {
				if (taskType != null && taskType.equalsIgnoreCase("MY")) {
					List<Integer> facilityIdListInt = FacilityIdList.stream()
				            .map(Integer::parseInt)
				            .collect(Collectors.toList());
					coderDashboard = session.createQuery(hql)
							.setFirstResult(index)
							//.setParameter("bbcList", bbcList)
							.setParameter("FacilityIdList", facilityIdListInt)
							.list();
				} else {
					coderDashboard = session.createQuery(hql)
							.setFirstResult(index)
							.list();
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching all Coder records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return coderDashboard;
	}

	
	@Override
	public EncodeUsers findByUserId(Long userId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
        EncodeUsers user = null;
        try {
            String hql = "FROM EncodeUsers WHERE userId = :userId";
            Query<EncodeUsers> query = session.createQuery(hql, EncodeUsers.class);
            query.setParameter("userId", userId);
            user = query.uniqueResult();
        } catch (Exception e) {
        	log.error("Exception occured while fetching user details: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
        }
        return user;
    }
	
	@Override
	public boolean coderDocPresent(Long visitId, Long patientId, String documentName) throws EncodeExceptionHandler {
	    log.info("Inside coderDocPresent Method");
		try {
	        Session session = this.sessionFactory.getCurrentSession();
	        String hql = "SELECT COUNT(p) FROM PatientMedicalRecords p " +
	                     "WHERE LOWER(p.documentSource) = LOWER(:docName) " +
	                     "AND p.visitId = :visitId " +
	                     "AND p.patientId = :patientId";
	 
	        Long count = session.createQuery(hql, Long.class)
	                .setParameter("docName", documentName)
	                .setParameter("visitId", visitId)
	                .setParameter("patientId", patientId)
	                .getSingleResult();
	 
	        log.info("count: {}", count);
	        log.info("hql: {}",hql);
	        return count != null && count > 0;
	 
	    } catch (Exception e) {
	        log.error("Exception occurred while checking isCoderDocPresent : {} ", e.getMessage());
	        throw new EncodeExceptionHandler(e.getMessage());
	    }
	}

	@Override
	public PatientMedicalRecords getSBRecordByVersion(Long patientId, Long visitId, String versionId)
			throws EncodeExceptionHandler {
		Session session = sessionFactory.getCurrentSession();
		try {
			String hql = "FROM PatientMedicalRecords pmr "
					+ "WHERE pmr.patientId = :patientId AND pmr.visitId = :visitId "
					+ "AND pmr.documentId = :versionId AND pmr.documentType = 'SB'";

			Query<PatientMedicalRecords> query = session.createQuery(hql, PatientMedicalRecords.class);
			query.setParameter("patientId", patientId);
			query.setParameter("visitId", visitId);
			query.setParameter("versionId", versionId);

			return query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occurred while getting sb record by version : {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}


}
