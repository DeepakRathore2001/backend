package com.healogics.encode.dao.impl;

import java.net.InetAddress;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.dao.UserLoginDAO;
import com.healogics.encode.dto.IHealUserObj;
import com.healogics.encode.dto.LoginUser;
import com.healogics.encode.dto.UserFacilities;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.UserLogin;

@Repository
public class UserLoginDAOImpl implements UserLoginDAO {
	private final Logger log = LoggerFactory.getLogger(UserLoginDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public UserLoginDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveUserLogin(LoginUser loginUser) {
		Session session = this.sessionFactory.getCurrentSession();
		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");

		try {
			UserLogin userLogin = new UserLogin();
			userLogin.setCreatedTimestamp(LocalDateTime.now());
			userLogin.setDeviceId(loginUser.getDeviceId());
			userLogin.setDeviceIP(loginUser.getDeviceIp());
			userLogin.setDeviceType(loginUser.getDeviceType());
			userLogin.setLoginType(loginUser.getLoginType());
			userLogin.setEmailId(loginUser.getEmailId());
			userLogin.setEmployedBy(loginUser.getEmployedBy());
			userLogin.setErrorCode(loginUser.getErrorCode());
			userLogin.setErrorMessage(loginUser.getErrorMessage());
			userLogin.setFacilityId(0);

			// if (loginUser.getLastLoginTimestamp() != null) {
			// String lastLoginTime = loginUser.getLastLoginTimestamp();
			// String finalLastTime = lastLoginTime.replaceAll("\\.\\d{2,3}$",
			// "");
			// LocalDateTime lastLogin = LocalDateTime.parse(finalLastTime,
			// timeFormat);
			// userLogin.setLastLoginTimestamp(lastLogin);
			// }


			/*LocalDateTime lastLoginTimestamp = LocalDateTime.parse(loginUser.getLastLoginTimestamp(),
					DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"));

			String formattedLastLoginTimestamp = lastLoginTimestamp
					.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));*/

			userLogin.setLastLoginTimestamp(loginUser.getLastLoginTimestamp());

			// userLogin.setLastLoginTimestamp(loginUser.getLastLoginTimestamp());
			userLogin.setLoginStatus(loginUser.getLoginStatus());
			userLogin.setServerIP(

					(InetAddress.getLocalHost() == null) ? "" : InetAddress.getLocalHost()
							.getHostAddress());

			userLogin.setUserFullName(loginUser.getUserFullname());
			userLogin.setUserId(loginUser.getUserId());
			userLogin.setUsername(loginUser.getUsername());
			userLogin.setUserRole(loginUser.getUserRole());
			userLogin.setRestricted(loginUser.isRestricted());

			log.debug("userLogin : {}", userLogin);

			session.save(userLogin);
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
		}
	}

	@Override
	public void saveEncodeUserLogin(IHealUserObj user) {
		Session session = this.sessionFactory.getCurrentSession();
		EncodeUsers record = null;

		try {
			String hql = "FROM EncodeUsers a where a.userId=" + user.getUserId();

			record = (EncodeUsers) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetch RetrieveUsers : {}", e.getMessage());
		}

		try {
			
			if (record == null) { 
				record = new EncodeUsers();
				record.setUsername(user.getUserName());
				record.setUserId(Long.valueOf(user.getUserId()));
				record.setUserFullName(user.getLastName() + ", " + user.getFirstName());
				record.setEmailId(user.getEmail());
				record.setLastLoggedInTimestamp(user.getLastLogonTime());
				record.setEncodeRole("User");
				record.setEncodeRoleDesc("EnCode User");
				if (user.getRoles() != null && !user.getRoles().isEmpty()) {
					String roles = user.getRoles().toString();
					record.setIhealRole(roles);
				}

				session.save(record);
			} else {
				/*LocalDateTime lastLoginTimestamp = LocalDateTime.parse(user.getLastLogonTime(),
						DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"));

				String formattedLastLoginTimestamp = lastLoginTimestamp
						.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));*/
				
				String hql = "UPDATE EncodeUsers r SET r.username=:username,"
						+ "r.userFullName=:userFullName, r.emailId=:emailId,"
						+ "r.lastLoggedInTimestamp=:lastLoggedInTimestamp," 
						+ "r.ihealRole=:ihealRole where r.userId=:userId";

				Query query = session.createQuery(hql);

				query.setParameter("username", user.getUserName());
				query.setParameter("userFullName", user.getLastName() + ", " + user.getFirstName());
				query.setParameter("emailId", user.getEmail());
				query.setParameter("lastLoggedInTimestamp", user.getLastLogonTime());
				
				if (user.getRoles() != null && !user.getRoles().isEmpty()) {
	                String roles = String.join(",", user.getRoles());
	                query.setParameter("ihealRole", roles);
	            } else {
	                query.setParameter("ihealRole", "");
	            }
				
				query.setParameter("userId", Long.valueOf(user.getUserId()));

				query.executeUpdate();
			}
		} catch (Exception e) {
			log.error("Exception occured :  {}", e.getMessage());
		}
	}

	@Override
	public int saveUserFacilities(String userId, List<UserFacilities> facilities) {
		Session session = this.sessionFactory.getCurrentSession();
		int rows = 0;
		List<String> facilityIdList = new ArrayList<String>();
		List<String> bbcList = new ArrayList<String>();
		String facilityIdString = null;
		String bbcIdString = null;
		try {
			if (userId != null && !userId.isEmpty() && facilities != null
					&& !facilities.isEmpty()) {
				
				for(UserFacilities fac : facilities) {
					facilityIdList.add(fac.getFacilityId());
					bbcList.add(fac.getFacilityBluebookId());
				}
				
				if(facilityIdList != null && !facilityIdList.isEmpty()) {
					facilityIdString = String.join(",", facilityIdList);
				}
				
				if(bbcList != null && !bbcList.isEmpty()) {
					bbcIdString = String.join(",", bbcList);
				}

				String userFac = null;
				try {
					userFac = new ObjectMapper().writeValueAsString(facilities);
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception:   {}", e);
				}

				String hql = "UPDATE EncodeUsers r SET r.userFacilities=:userFacilities,"
						+ " facilityIdList = :facilityIdList, "
						+ " bluebookIdList = :bluebookIdList "
						+ "where r.userId=:userId";

				Query query = session.createQuery(hql);

				query.setParameter("userFacilities", userFac);
				query.setParameter("userId", Long.valueOf(userId));
				query.setParameter("facilityIdList", facilityIdString);
				query.setParameter("bluebookIdList", bbcIdString);

				rows = query.executeUpdate();
				log.debug("Updated user facilities in DB for the userId:  {}",userId);
			}
		} catch (Exception e) {
			log.error("Exception occured while saving user facilities:  {}",
					e.getMessage());
		}
		return rows;
	}
}
