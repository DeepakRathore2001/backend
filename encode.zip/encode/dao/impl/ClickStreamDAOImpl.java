package com.healogics.encode.dao.impl;

import java.sql.Timestamp;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.ClickStreamDAO;
import com.healogics.encode.dto.ClickStreamReq;
import com.healogics.encode.entity.ClickStream;
import com.healogics.encode.exception.EncodeExceptionHandler;


@Repository
@Transactional
public class ClickStreamDAOImpl implements ClickStreamDAO {
	
	private final Logger log = LoggerFactory.getLogger(ClickStreamDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public ClickStreamDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveClickStreamData(ClickStreamReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			ClickStream stream = new ClickStream();
			if (req.getBluebookId() == null || req.getBluebookId().isEmpty()) {
				stream.setBluebookId("");
			} else {
				stream.setBluebookId(req.getBluebookId());
			}
			stream.setCreatedTimestamp(currentTime);
			if (req.getFacilityId()== 0) {
				stream.setFacilityId(0);
			} else {
				stream.setFacilityId(req.getFacilityId());
			}
			stream.setModuleDescription(req.getModuleDescription());
			stream.setModuleName(req.getModuleName());
			stream.setUserId(req.getUserId());
			if (req.getPatientId()== 0) {
				stream.setPatientId(0);
			} else {
				stream.setPatientId(req.getPatientId());
			}
			//stream.setPatientId(req.getPatientId());
			if (req.getVisitId() == null || req.getVisitId().isEmpty()) {
				stream.setVisitId(0L);
			} else {
				stream.setVisitId(Long.parseLong(req.getVisitId()));
			}
			//stream.setVisitId(req.getVisitId());
			stream.setRole(req.getRole());

			session.save(stream);

		} catch (Exception e) {
			log.error("Exception occured while saving clickstream data: {}" , e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
}
