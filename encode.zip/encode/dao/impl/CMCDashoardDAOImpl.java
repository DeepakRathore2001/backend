package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.CMCDashboardDAO;
import com.healogics.encode.dto.CMCData;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.UserFacilities;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.DisparateFacilities;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.entity.UserPreference;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.util.FilterRequestUtil;

@Repository
@Transactional
public class CMCDashoardDAOImpl implements CMCDashboardDAO {
	private final Logger log = LoggerFactory
			.getLogger(CMCDashoardDAOImpl.class);

	private final SessionFactory sessionFactory;
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	@PersistenceContext
	private EntityManager entitymanager;
	

	@Autowired
	public CMCDashoardDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Dashboard> getAllCMCRecords(DashboardReq req, int index, String taskType,
			String assignee, List<String> bbclist, boolean isApplyPagination,List<String> facilityIdList)
					throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> cmcDashboard = new ArrayList<>();
		try {
			String hql = "FROM Dashboard a WHERE a.status IN ('New','Pending','Returned') "
					+ " AND a.lastStatusChangeRole = 'CMC'";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				//hql += " AND a.bluebookId IN :bbcList ";
				hql += " AND a.facilityId IN :FacilityIdList ";
				log.debug("hql..... :" + hql);
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by receivedDate asc";
			}

			log.info("query : {}", hql);

			if (isApplyPagination) {
				if (taskType != null && taskType.equalsIgnoreCase("MY")) {
					List<Integer> facilityIdListInt = facilityIdList.stream()
				            .map(Integer::parseInt)
				            .collect(Collectors.toList());
					cmcDashboard = session.createQuery(hql)
							//.setParameter("bbcList", bbclist)
							.setParameter("FacilityIdList", facilityIdListInt)
							.setFirstResult(index)
							.setMaxResults(PAGE_SIZE).list();
				} else {
					cmcDashboard = session.createQuery(hql).setFirstResult(index)
							.setMaxResults(PAGE_SIZE).list();
				}
			} else {
				if (taskType != null && taskType.equalsIgnoreCase("MY")) {
					if (taskType != null && taskType.equalsIgnoreCase("MY")) {
						List<Integer> facilityIdListInt = facilityIdList.stream()
					            .map(Integer::parseInt)
					            .collect(Collectors.toList());
					cmcDashboard = session.createQuery(hql)
							//.setParameter("bbcList", bbclist)
							.setParameter("FacilityIdList", facilityIdListInt)
							.setFirstResult(index)
							.list();
				} else {
					cmcDashboard = session.createQuery(hql).setFirstResult(index)
							.list();
					}
				}
			}
			

		} catch (Exception e) {
			log.error("Exception occured while fetching all CMC records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return cmcDashboard;
	}
	
	private String sortList(DashboardReq req, String hql) {
	    String sortBy = req.getSortBy();
	    String order = (req.getOrder() == 0) ? "desc" : "asc";
	 
	    switch (sortBy.toLowerCase()) {
	        case "assignedto":
	            hql += " order by LOWER(assigneeUserFullname) " + order;
	            break;
	        case "bbc":
	            hql += " order by LOWER(snfLocationBBC) " + order;
	            break;
	        case "facilityname":
	            hql += " order by LOWER(facilityAlias) " + order;
	            break;
	        case "age":
	        	 hql += " order by receivedDate " + order; 
		            break;
	        case "interfacedate":
	            hql += " order by receivedDate " + order; 
	            break;
	        case "facilitytype":
	            hql += " order by LOWER(facilityType) " + order;
	            break;
	        default:
	            hql += " order by LOWER(" + sortBy + ") " + order;
	            break;
	    }
	 
	    return hql;
	}


	@Override
	public Map<String, Object> getFilteredCMCList(DashboardReq req, int index,
			String taskType, String assigneeUsername,
			List<String> bbcs, boolean isApplyPagination, List<String> facilityIdList) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> cmcDashboard = new ArrayList<>();
		List<Dashboard> allCMCList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String hql = "FROM Dashboard a WHERE a.status IN ('New','Pending','Returned','Unbillable') "
					+ " AND a.lastStatusChangeRole = 'CMC'";

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				//hql += " AND a.bluebookId IN :bbcs";
				hql += " AND a.facilityId IN :FacilityIdList ";
				log.debug("hql..... :" + hql);
				
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcList = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							hql += " a.snfLocationBBC IN :bbc ";
							parameters.put("bbc", bbcList);
						}
							break;
						case "facilityName" : {
							List<String> facilityList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getFacilityName());
							hql += " a.facilityAlias IN :facilityAlias ";
							parameters.put("facilityAlias", facilityList);
						}
							break;
						case "ihealConfig" : {
							List<String> facilityTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getIhealConfig());
							hql += " a.ihealConfig IN :ihealConfig ";
							parameters.put("ihealConfig", facilityTypeList);
						}
							break;

						case "interfaceDate" : {
							hql += " a.receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
							parameters.put("startInterfaceDate", dateFormat
									.parse(req.getStartInterfaceDate()));
							parameters.put("endInterfaceDate", dateFormat
									.parse(req.getEndInterfaceDate()));
						}
							break;

						case "age" : {
							hql += " a.statusChangeTimestamp BETWEEN :ageStartDate AND :ageEndDate ";
							parameters.put("ageStartDate",
									dateFormat.parse(req.getAgeStartDate()));
							parameters.put("ageEndDate",
									dateFormat.parse(req.getAgeEndDate()));
						}
							break;

						case "providerName" : {
							List<String> providerNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getProviderName());
							hql += " a.providerName IN :providerName ";
							parameters.put("providerName", providerNameList);
						}
							break;

						case "patientName" : {
							List<String> patientNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getPatientName());
							hql += " a.patientName IN :patientName ";
							parameters.put("patientName", patientNameList);
						}
							break;

						case "dateOfService" : {
							hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
							parameters.put("startDOSDate",
									new Timestamp(dateFormat
											.parse(req.getStartDOSDate())
											.getTime()));
							parameters.put("endDOSDate",
									new Timestamp(dateFormat
											.parse(req.getEndDOSDate())
											.getTime()));
						}
							break;

						case "medicalRecordNumber" : {
							List<String> medicalRecordNumberList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getMedicalRecordNumber());
							hql += " a.medicalRecordNumber IN :medicalRecordNumber ";
							parameters.put("medicalRecordNumber",
									medicalRecordNumberList);
						}
							break;

						case "encounterType" : {
							List<String> encounterTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getEncounterType());
							hql += " a.encounterType IN :encounterType ";
							parameters.put("encounterType", encounterTypeList);
						}
							break;

						case "assignedTo" : {
							if (!taskType.equalsIgnoreCase("MY")) {
								List<String> assignedToList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getAssignedTo());
								hql += " a.assigneeUserFullname IN :assignedTo ";
								parameters.put("assignedTo", assignedToList);
							} else {
								hql += " 1 = 1 ";
							}
						}
							break;
						case "serviceLine" : {
							List<String> serviceLineList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getServiceLine());
							hql += " a.serviceLine IN :serviceLine ";
							parameters.put("serviceLine", serviceLineList);
						}
							break;


						case "cmcNotes" : {
							List<String> cmcNotesList = FilterRequestUtil
									.getListFromDelimitedStr(req.getCmcNotes());
							hql += " a.cmcNotes IN :cmcNotes ";
							parameters.put("cmcNotes", cmcNotesList);
						}
							break;

						case "status" : {
							List<String> statusList = FilterRequestUtil
									.getListFromDelimitedStr(req.getStatus());
							hql += " a.status IN :status ";
							parameters.put("status", statusList);
						}
							break;

						case "visitId" : {
							List<String> visitIdList = FilterRequestUtil
									.getListFromDelimitedStr(req.getVisitIds());
							List<Long> intvisitIdList = new ArrayList<>();
							for (String s : visitIdList) {
								intvisitIdList.add(Long.valueOf(s));
							}

							// List<Long> visitIdList =
							// FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
							hql += " a.visitId IN :visitId ";
							parameters.put("visitId", intvisitIdList);
						}
							break;

						default :
							break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by receivedDate asc";
			}

			log.info("query : {}", hql);

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				List<Integer> facilityIdListInt = facilityIdList.stream()
			            .map(Integer::parseInt)
			            .collect(Collectors.toList());
				//parameters.put("bbcs", bbcs);
				parameters.put("FacilityIdList", facilityIdListInt);
			}
			
			if (isApplyPagination) {
				cmcDashboard = session.createQuery(hql).setFirstResult(index)
						.setProperties(parameters).setMaxResults(PAGE_SIZE).list();
			} else {
				cmcDashboard = session.createQuery(hql).setFirstResult(index)
						.setProperties(parameters).list();
			}

			allCMCList = session.createQuery(hql).setFirstResult(index)
					.setProperties(parameters).list();

			int count = allCMCList.size() + index;

			listCount.put("Count", count);
			listCount.put("data", cmcDashboard);
			log.debug("coderDashboard List Size:   {} ", count);

			listCount.put("Count", count);
			listCount.put("data", cmcDashboard);
			log.debug("cmcDashboard List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public Long getTotalCount(int index, String taskType,
			String assigneeUsername, DashboardReq req, List<String> bbcList,List<String> facilityIdList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;
  
		try {
			String hql = "SELECT count(*) FROM Dashboard a WHERE a.status IN ('New','Pending','Returned') "
					+ " AND a.lastStatusChangeRole = 'CMC'";

			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				List<Integer> facilityIdListInt = facilityIdList.stream()
			            .map(Integer::parseInt)
			            .collect(Collectors.toList());
				// hql += " AND a.assigneeUsername ='" + assigneeUsername + "'";
				//hql += " AND a.bluebookId IN :bbcList";
				hql += " AND a.facilityId IN :FacilityIdList";
				totalCount = (Long) session.createQuery(hql)
						//.setParameter("bbcList", bbcList)
						.setParameter("FacilityIdList", facilityIdListInt)
						.uniqueResult();
			} else {
				totalCount = (Long) session.createQuery(hql).uniqueResult();
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching CMC Dashboard total count : {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public FilterOptions getFilterOptions(DashboardReq req, List<String> bbcList,List<String> facilityIdList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {

			String query = " WHERE status IN ('New','Pending','Returned','Unbillable')"
					+ " AND lastStatusChangeRole = 'CMC'";
			String filterColumn = req.getFilterOptions();

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				//query += " AND bluebookId IN :bbcList";
				query += " AND facilityId IN :FacilityIdList ";
			}

			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcs = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							query += " snfLocationBBC IN :bbc ";
							parameters.put("bbc", bbcs);
						}
							break;
						case "facilityName" : {
							List<String> facilityList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getFacilityName());
							query += " facilityAlias IN :facilityAlias ";
							parameters.put("facilityAlias", facilityList);
						}
							break;
						case "ihealConfig" : {
							List<String> facilityTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getIhealConfig());
							query += " ihealConfig IN :ihealConfig ";
							parameters.put("ihealConfig", facilityTypeList);
						}
							break;

						case "interfaceDate" : {
							query += " receivedDate BETWEEN :startInterfaceDate AND :endInterfaceDate ";
							parameters.put("startInterfaceDate", dateFormat
									.parse(req.getStartInterfaceDate()));
							parameters.put("endInterfaceDate", dateFormat
									.parse(req.getEndInterfaceDate()));
						}
							break;

						case "age" : {
							query += " statusChangeTimestamp BETWEEN :ageStartDate AND :ageEndDate ";
							parameters.put("ageStartDate",
									dateFormat.parse(req.getAgeStartDate()));
							parameters.put("ageEndDate",
									dateFormat.parse(req.getAgeEndDate()));
						}
							break;

						case "providerName" : {
							List<String> providerNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getProviderName());
							query += " providerName IN :providerName ";
							parameters.put("providerName", providerNameList);
						}
							break;

						case "patientName" : {
							List<String> patientNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getPatientName());
							query += " patientName IN :patientName ";
							parameters.put("patientName", patientNameList);
						}
							break;

						case "dateOfService" : {
							query += " dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
							parameters.put("startDOSDate",
									new Timestamp(dateFormat
											.parse(req.getStartDOSDate())
											.getTime()));
							parameters.put("endDOSDate",
									new Timestamp(dateFormat
											.parse(req.getEndDOSDate())
											.getTime()));
						}
							break;

						case "medicalRecordNumber" : {
							List<String> medicalRecordNumberList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getMedicalRecordNumber());
							query += " medicalRecordNumber IN :medicalRecordNumber ";
							parameters.put("medicalRecordNumber",
									medicalRecordNumberList);
						}
							break;

						case "encounterType" : {
							List<String> encounterTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getEncounterType());
							query += " encounterType IN :encounterType ";
							parameters.put("encounterType", encounterTypeList);
						}
							break;

						case "assignedTo" : {
							if (!req.getTaskType().equalsIgnoreCase("MY")) {
								List<String> assignedToList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getAssignedTo());
								query += " assigneeUserFullname IN :assignedTo ";
								parameters.put("assignedTo", assignedToList);
							} else {
								query += " 1 = 1 ";
							}
						}
							break;
							
						case "serviceLine" : {
							List<String> serviceLineList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getServiceLine());
							query += " serviceLine IN :serviceLine ";
							parameters.put("serviceLine", serviceLineList);
						}
							break;

						case "cmcNotes" : {
							List<String> cmcNotesList = FilterRequestUtil
									.getListFromDelimitedStr(req.getCmcNotes());
							query += " cmcNotes IN :cmcNotes ";
							parameters.put("cmcNotes", cmcNotesList);
						}
							break;

						case "status" : {
							List<String> statusList = FilterRequestUtil
									.getListFromDelimitedStr(req.getStatus());
							query += " status IN :status ";
							parameters.put("status", statusList);
						}
							break;

						case "visitId" : {

							List<String> visitIdList = FilterRequestUtil
									.getListFromDelimitedStr(req.getVisitIds());
							List<Long> intvisitIdList = new ArrayList<>();
							for (String s : visitIdList) {
								intvisitIdList.add(Long.valueOf(s));
							}
							query += " visitId IN :visitId ";
							parameters.put("visitId", intvisitIdList);
						}
							break;

						default :
							break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			
			if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				List<Integer> facilityIdListInt = facilityIdList.stream()
			            .map(Integer::parseInt)
			            .collect(Collectors.toList());
				//parameters.put("bbcList", bbcList);
				parameters.put("FacilityIdList", facilityIdListInt);
			}

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("assignedTo")) {
				filterColumn = "assigneeUserFullname";
			}
			if (req.getFilterOptions().equalsIgnoreCase("facilityName")) {
				filterColumn = "facilityAlias";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "snfLocationBBC";
			}
			if ((req.getFilterOptions().equalsIgnoreCase("age")) || (req
					.getFilterOptions().equalsIgnoreCase("interfaceDate"))) {
				String dateHql = "SELECT MIN(statusChangeTimestamp), MAX(statusChangeTimestamp) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinReceivedDate((Date) object[0]);
				filterOptions.setMaxReceivedDate((Date) object[1]);
			} else if (req.getFilterOptions()
					.equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(dateOfService), MAX(dateOfService) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM Dashboard "
						+ query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1)
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard "
						+ query + " ORDER BY LOWER(" + filterColumn + ") asc";
				List<String> distinctValues = session.createQuery(hql)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null
						|| (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}",
					e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}
	
	public void saveUserPreferences(String userId, DashboardReq req) throws EncodeExceptionHandler {
		ObjectMapper objectMapper = new ObjectMapper();
		Session session = sessionFactory.getCurrentSession();
		log.info(" Dashboard Req : {}",req);
		try {
			DashboardReq filteredReq= new DashboardReq();
			
			filteredReq.setTaskType(req.getTaskType());
			filteredReq.setUsername(req.getUsername());
			filteredReq.setUserId(req.getUserId());
			filteredReq.setIndex(req.getIndex());
			filteredReq.setOrder(req.getOrder());
			filteredReq.setSortBy(req.getSortBy());
			filteredReq.setFilters(req.getFilters());
			filteredReq.setBbc(req.getBbc());
			filteredReq.setFacilityName(req.getFacilityName());
			filteredReq.setProviderName(req.getProviderName());
			filteredReq.setPatientName(req.getPatientName());
			filteredReq.setMedicalRecordNumber(req.getMedicalRecordNumber());
			filteredReq.setEncounterType(req.getEncounterType());
			filteredReq.setAssignedTo(req.getAssignedTo());
			filteredReq.setCmcNotes(req.getCmcNotes());
			filteredReq.setStatus(req.getStatus());
			filteredReq.setIhealConfig(req.getIhealConfig());
			filteredReq.setVisitIds(req.getVisitIds());
			filteredReq.setStartInterfaceDate(req.getStartInterfaceDate());
			filteredReq.setEndInterfaceDate(req.getEndInterfaceDate());
			filteredReq.setAgeStartDate(req.getAgeStartDate());
			filteredReq.setAgeEndDate(req.getAgeEndDate());
			filteredReq.setStartDOSDate(req.getStartDOSDate());
			filteredReq.setEndDOSDate(req.getEndDOSDate());
			
			// Convert request object to JSON string
			String filters = objectMapper.writeValueAsString(filteredReq);
			
			Long userIdLong = Long.valueOf(userId);

			UserPreference userPreference = session.get(UserPreference.class, userIdLong);
			if (userPreference != null) {
				userPreference.setFilters(filters);
				userPreference.setLastUpdatedTimestamp(LocalDateTime.now());
				userPreference.setUsername(req.getUsername());

			} else {
				userPreference = new UserPreference();
				userPreference.setUserId(userIdLong);
				userPreference.setFilters(filters);
				userPreference.setLastUpdatedTimestamp(LocalDateTime.now());
				userPreference.setUsername(req.getUsername());

			}
			session.saveOrUpdate(userPreference);
		} catch (Exception e) {
			log.error("Exception occurred while saving filters in user preference: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public Reasons getPendingReasons() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons pendingReasons = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "coordinator");
			query.setParameter("title", "pending");
			pendingReasons = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error(
					"Exception occurred while fetching all pending reasons: {} ",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return pendingReasons;
	}

	@Override
	public CMCData getCMCRecordById(DashboardReq req) {
		Session session = sessionFactory.getCurrentSession();
		CMCData res = new CMCData();

		try {
			String hql = "FROM Dashboard WHERE visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", req.getVisitId());
			List<Dashboard> records = query.list();

			res.setVisitId(req.getVisitId());

			if (!records.isEmpty()) {
				Dashboard record = records.get(0);

				res.setPatientId(record.getPatientId());
				res.setBbc(record.getBluebookId());
				res.setBlueBookId(record.getSnfLocationBBC());
				res.setPatientFirstName(record.getPatientFirstName());
				res.setPatientLastName(record.getPatientLastName());
				res.setMedicalRecordNumber(record.getMedicalRecordNumber());
				res.setSex(record.getGender());
				res.setPatientDOB(record.getPatientDOB());
				res.setDateOfService(record.getDateOfService());
				res.setPrimaryInsurance(record.getPrimaryInsurance());
				res.setSecondaryInsurance(record.getSecondaryInsurance());
				res.setFacilityId(record.getFacilityId());
				res.setIhealConfig(record.getIhealConfig());
				res.setStatus(record.getStatus());
				res.setDashboardName(record.getLastStatusChangeRole());
				res.setEncounterType(record.getEncounterType());
				res.setUserId(record.getLastUpdatedByUserId());
				res.setUserName(record.getLastUpdatedByUsername());
				res.setServiceLine(record.getServiceLine());
				if (record.getFacilityType() == null
						|| record.getFacilityType().isEmpty()) {
					res.setFacilityType("");
				} else {
					res.setFacilityType(record.getFacilityType());

				}
				log.debug("setFacilityType===="+record.getFacilityType());
				
				String cmcUserFullName = record.getValidatedCMCUser();
				if (cmcUserFullName != null && cmcUserFullName.contains(",")) {
					String[] nameparts = cmcUserFullName.split(",");
					if (nameparts.length == 2) {
						String formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
						res.setValidatedCMCUser(formattedName);
					} else {
						res.setValidatedCMCUser(cmcUserFullName);
					}
				}
				String coderUserFullName = record.getCompletedCoderUser();
				if (coderUserFullName != null && coderUserFullName.contains(",")) {
					String[] nameparts = coderUserFullName.split(",");
					if (nameparts.length == 2) {
						String formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
						res.setCompletedCoderUser(formattedName);
					} else {
						res.setCompletedCoderUser(coderUserFullName);
					}
				}
				 
				String userFullName = record.getLastUpdatedByUserFullName();
				if (userFullName != null && userFullName.contains(",")) {
					String[] nameparts = userFullName.split(",");
					if (nameparts.length == 2) {
						String formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
						res.setUserFullName(formattedName);
					} else {
						res.setUserFullName(userFullName);
					}
				}
				res.setProgNoteSigned(record.getIsProgNoteSigned());
				res.setHboSigned(record.getIsHBOSigned());
				String hql1 = "FROM ChartDetails WHERE visitId =:visitId";
				Query query1 = session.createQuery(hql1);
				query1.setParameter("visitId", req.getVisitId());
				List<ChartDetails> ChartRecord = query1.list();
				if (!ChartRecord.isEmpty()) {
					ChartDetails record1 = ChartRecord.get(0);


					if (record1.getCocId() == null || record1.getCocId().isEmpty()) {
						res.setCoc2Id("");
					} else {
						res.setCoc2Id(record1.getCocId());

					}
					if (record1.getChildBluebookId() == null || record1.getChildBluebookId().isEmpty()) {
						res.setBlueBookId("");
					} else {
						res.setBlueBookId(record1.getChildBluebookId());

					}
				}
				
				
				DisparateFacilities disparateFacility = getDisparateBBC(
						record.getSnfLocationBBC());
				
				log.debug("disparateFacility : " +disparateFacility);
				
				if (disparateFacility != null) {
					res.setDisparate(true);
				} else {
					res.setDisparate(false);
				}

				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage("No document found");
			}
		} catch (Exception e) {
			log.error(
					"Exception occured while fetching CMC Record from database: {}",
					e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	public DisparateFacilities getDisparateBBC(String bbc) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		DisparateFacilities disparateFacilities = null;
		try {
			String hqlDisparate = "FROM DisparateFacilities WHERE bbc = :bluebookId";
			disparateFacilities = session
					.createQuery(hqlDisparate, DisparateFacilities.class)
					.setParameter("bluebookId", bbc).setMaxResults(1)
					.uniqueResult();

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return disparateFacilities;
	}
	
	@Override
	public Reasons getUnbillableReasons() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons pendingReasons = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "coordinator");
			query.setParameter("title", "Unbillable");
			pendingReasons = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error(
					"Exception occurred while fetching all unbillable reasons: {} ",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return pendingReasons;
	}
	
	@Override
	public UserFacilityRes getuserFacilities(String userId) throws EncodeExceptionHandler {
		UserFacilityRes response = new UserFacilityRes();

		try {
			String query = "SELECT u.userFacilities FROM EncodeUsers u WHERE u.userId = :userId";
			TypedQuery<String> typedQuery = entitymanager.createQuery(query, String.class);
			typedQuery.setParameter("userId", Long.parseLong(userId));

			String userFacilitiesJson = typedQuery.getSingleResult();

			List<Map<String, Object>> facilitiesData = objectMapper.readValue(userFacilitiesJson,
					new TypeReference<List<Map<String, Object>>>() {
					});
			List<UserFacilities> facilities = new ArrayList<>();

			for (Map<String, Object> facilityData : facilitiesData) {
				UserFacilities facility = new UserFacilities();
				facility.setFacilityBluebookId((String) facilityData.get("facilityBluebookId"));
				facilities.add(facility);
			}
			response.setFacilities(facilities);
			response.setResponseCode("0");
			response.setResponseDesc("Success");
		} catch (Exception e) {
			log.error("Exception occurred while fetching facilities: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return response;

	}
	
	@Override
	public String getUserBBCList(String userId) throws EncodeExceptionHandler{
		String bbcString = null;
		String facilityIdString = null;
		
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String userHql = "From EncodeUsers r WHERE "
					+ " userId = :userId ";

			EncodeUsers encodeUsers = session
					.createQuery(userHql, EncodeUsers.class)
					.setParameter("userId",
							Long.valueOf(userId))
					.setMaxResults(1).uniqueResult();
			
			if(encodeUsers != null) {
				bbcString = encodeUsers.getBluebookIdList();
				facilityIdString = encodeUsers.getFacilityIdList();
			}
		
		} catch (Exception e) {
			log.error("Exception occurred while fetching BBCString: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return facilityIdString;
	}
	
	
	@Override
	public EncodeUsers findByUserId(Long userId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
        EncodeUsers user = null;
        try {
            String hql = "FROM EncodeUsers WHERE userId = :userId";
            Query<EncodeUsers> query = session.createQuery(hql, EncodeUsers.class);
            query.setParameter("userId", userId);
            user = query.uniqueResult();
        } catch (Exception e) {
        	log.error("Exception occured while fetching user details: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
        }
        return user;
    }
}
