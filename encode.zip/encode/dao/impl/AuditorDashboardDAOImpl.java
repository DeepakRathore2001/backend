package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.AuditorDashboardDAO;
import com.healogics.encode.dto.AuditorCollapsibleSectionData;
import com.healogics.encode.dto.AuditorCollapsibleSectionReq;
import com.healogics.encode.dto.AuditorDashboardFilter;
import com.healogics.encode.dto.AuditorDashboardReq;
import com.healogics.encode.dto.CMCData;
import com.healogics.encode.dto.CPTChartDetails;
import com.healogics.encode.dto.ChartByStatusReq;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.ICD10Data;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.ReleaseByFilterChartReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.dto.SaveAuditDetailsRes;
import com.healogics.encode.dto.UpdateChartstatusReq;
import com.healogics.encode.dto.addOrRemovePinnedFilterReq;
import com.healogics.encode.entity.AuditQueue;
import com.healogics.encode.entity.ChartDetails;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.DisparateFacilities;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.Filters;
import com.healogics.encode.entity.FinancialTransaction;
import com.healogics.encode.entity.InsuranceCarrier;
import com.healogics.encode.entity.Notes;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.Patient;
import com.healogics.encode.entity.PatientInsurance;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.PlaceOfServiceDetails;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.entity.SuperbillVariance;
import com.healogics.encode.entity.UserPreference;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.service.AppNotificationBO;
import com.healogics.encode.util.FilterRequestUtil;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

@Repository
@Transactional
public class AuditorDashboardDAOImpl implements AuditorDashboardDAO {

	private final Logger log = LoggerFactory.getLogger(AuditorFilterDAOImpl.class);
	private final AppNotificationBO appNotificationBO;

	private final SessionFactory sessionFactory;

	@Autowired
	public AuditorDashboardDAOImpl(SessionFactory sessionFactory, AppNotificationBO appNotificationBO) {
		this.sessionFactory = sessionFactory;
		this.appNotificationBO = appNotificationBO;
	}

	@Override
	public List<InsuranceCarrier> getInsuranceCarrier() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<InsuranceCarrier> insuranceCarrier = null;
		try {
			String hql = "FROM InsuranceCarrier ORDER BY insuranceDescription ASC";
			Query<InsuranceCarrier> query = session.createQuery(hql, InsuranceCarrier.class);
			log.info("hql: " + hql);
			List<InsuranceCarrier> allCarriers = query.list();
			Map<String, InsuranceCarrier> uniqueCarrierMap = new LinkedHashMap<>();

			for (InsuranceCarrier carrier : allCarriers) {
				uniqueCarrierMap.putIfAbsent(carrier.getInsuranceDescription(), carrier);
			}

			insuranceCarrier = new ArrayList<>(uniqueCarrierMap.values());
		} catch (Exception e) {
			log.error("Exception occurred while fetching coders: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return insuranceCarrier;
	}

	@Override
	public List<Reasons> getAuditorReasons() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Reasons> reasonsList = new ArrayList<>();
		try {
			String hql = " FROM Reasons WHERE role = :role AND title IN ('Added','Downcoded','Removed','Upcoded','Other')";
			Query<Reasons> query = session.createQuery(hql, Reasons.class);
			query.setParameter("role", "Auditor");
			reasonsList = query.getResultList();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all weakness reasons: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return reasonsList;
	}

	@Override
	public SaveAuditDetailsRes saveAuditDetails(SaveAuditDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		SaveAuditDetailsRes res = new SaveAuditDetailsRes();
		try {
			// Fetch the existing ChartDetails entity by visitId
			String hql = "FROM ChartDetails WHERE visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", req.getVisitId());
			ChartDetails chartDetails = (ChartDetails) query.uniqueResult();

			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			switch (req.getAction()) {
			case "Save":
				handelSaveAction(req, chartDetails);
				break;
			case "Complete":
				handleCompleteAction(req, chartDetails, "Auditor Complete");
				break;
			case "Assign Nurse":
				assignNurse(req);
				break;
			case "Nurse Deficiency":
				saveNurseDeficiency(req, chartDetails);
				break;
			case "Nurse Complete":
				handleCompleteAction(req, chartDetails, "Nurse Complete");
				break;
			case "Weakness":
				performWeaknessAction(req, chartDetails, session, currentTime);
				break;
			case "Deficiency":
				performDeficiencyAction(req, chartDetails, session, currentTime);
				break;

			default:

			}

			session.saveOrUpdate(chartDetails);

			res.setResponseCode("0");
			res.setResponseMessage("Success");
		} catch (Exception e) {
			log.error("Exception occurred while saving audit details: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to save audit details", e);
		}
		return res;
	}

	private void saveNurseDeficiency(SaveAuditDetailsReq req, ChartDetails chartDetails) throws EncodeExceptionHandler {
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		Session session = sessionFactory.getCurrentSession();
		try {
			chartDetails.setNurseDeficiencyReason(req.getNurseDeficiencyReason());
			chartDetails.setLastUpdatedTimestamp(currentTime);
			UpdateDashboardStatus("nursedeficiency", req);
			UpdateNurseDeficiencyStatus(req.getVisitId(), "Nurse Deficiency");
			assignNurse(req);
		} catch (Exception e) {
			log.error("Failed to convert audit details to JSON", e);
			throw new EncodeExceptionHandler("Failed to process audit details", e);
		}
		Notes userNotes = new Notes();
		String notesDescription = String.format("Nurse Deficiency - %s ", req.getNurseDeficiencyReason());
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole("Nurse");
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFirstName() + " " + req.getUserLastName());
		userNotes.setCreatorUserId((Integer.parseInt(req.getUserId())));
		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);

	}

	private void assignNurse(SaveAuditDetailsReq req) throws EncodeExceptionHandler {
		Session session = sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			Dashboard dashboard = session.get(Dashboard.class, req.getVisitId());
			if (dashboard != null) {
				dashboard.setAssigneeUserId(Long.parseLong(req.getNurseUserId()));
				dashboard.setAssigneeUsername(req.getNurseUserName());
				dashboard.setAssigneeUserFullname(req.getNurseUserFullName());
				dashboard.setAssigneeRole("Nurse");
				dashboard.setLastUpdatedByUsername(req.getUserName());
				dashboard.setLastUpdatedByUserId(req.getUserId());
				dashboard.setLastUpdatedByUserFullName(req.getUserFullName());
				dashboard.setLastUpdatedByTimestamp(currentTime);
				session.update(dashboard);
			}
			AuditQueue auditQueue = session.get(AuditQueue.class, req.getVisitId());
			if (auditQueue != null) {
				auditQueue.setAssigneeUserId(Long.parseLong(req.getNurseUserId()));
				auditQueue.setAssigneeUserName(req.getNurseUserName());
				auditQueue.setAssigneeUserFullName(req.getNurseUserFullName());
				session.update(auditQueue);
			}
		} catch (Exception e) {
			log.error("Exception occurred while saving nurse details: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to save nurse details", e);
		}
	}

	public void handleCompleteAction(SaveAuditDetailsReq req, ChartDetails chartDetails, String action)
			throws EncodeExceptionHandler {
		try {
			switch (action) {
			case "Auditor Complete":
				handelSaveAction(req, chartDetails);
				// saveAuditNotes(req, chartDetails);
				saveCoderInfo(req, chartDetails);
				// saveInAuditFiltersSource(req, chartDetails);
				UpdateAuditQueueStatus(req.getVisitId(), "Audit Completed");
				UpdateDashboardStatus("completed", req);
				saveFinancialTransaction(req, chartDetails);
				break;

			case "Nurse Complete":
				assignNurse(req);
				addResolution(req);
				UpdateNurseDeficiencyStatus(req.getVisitId(), "Ready for Audit");
				UpdateDashboardStatus("Ready for Audit", req);
				break;

			default:
				throw new EncodeExceptionHandler("Invalid action: " + action);
			}
		} catch (Exception e) {
			log.error("Exception occurred while handling complete action: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to handle complete action", e);
		}
	}

	private void saveFinancialTransaction(SaveAuditDetailsReq req, ChartDetails chartDetails)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String deletedCount = "DELETE FROM FinancialTransaction WHERE visitId IN :visitId";
			session.createQuery(deletedCount).setParameter("visitId", req.getVisitId().intValue()).executeUpdate();

			log.info("Deleted {} existing records for visitId: {}", deletedCount, req.getVisitId());

			Dashboard dashboard = session.get(Dashboard.class, req.getVisitId());
			Patient patient = session.get(Patient.class, req.getVisitId());
			Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
			for (CPTChartDetails cptDetail : req.getCptData()) {
				// Skip if cptCode is null, empty, or "99999"
				if (cptDetail.getCptCode() == null || cptDetail.getCptCode().isEmpty()
						|| "99999".equals(cptDetail.getCptCode())) {
					log.info("Skipped creating FinancialTransaction for visitId: {}, due to invalid CPT code: {}",
							req.getVisitId(), cptDetail.getCptCode());
					continue; // Skip this iteration and move to the next CPT detail
				}

				// ENC-7674
				// Construct diagnosis code with added period only after the first 3 digits
				List<String> icdCodes = new ArrayList<>();
				for (ICD10Data icd : cptDetail.getSelectedICDs()) {
					String icdCode = icd.getCode();
					// Check if the ICD code has more than 3 digits and insert a period after the
					// first 3 digits
					if (icdCode != null && icdCode.length() > 3) {
						icdCode = icdCode.substring(0, 3) + "." + icdCode.substring(3);
					}
					icdCodes.add(icdCode);
				}
				String diagnosisCode = String.join("~", icdCodes);
				log.debug("Constructed diagnosis code: {}", diagnosisCode);

				List<String> modifiers = cptDetail.getModifier();
				List<String> firstTwoLetters = new ArrayList<>();
				if (modifiers != null && !modifiers.isEmpty()) {
					for (String modifier : modifiers) {

						if (modifier.length() >= 2) {
							firstTwoLetters.add(modifier.substring(0, 2));
						} else {
							firstTwoLetters.add(modifier);
						}
					}
				}

				String modifierCode = String.join("~", firstTwoLetters);
				log.debug("Constructed modifier code (first two letters): {}", modifierCode);

				FinancialTransaction newTransaction = new FinancialTransaction();
				newTransaction.setVisitId(req.getVisitId().intValue());
				newTransaction.setId(getNextTransactionId(req.getVisitId(), session));
				newTransaction.setTransactionCode(cptDetail.getCptCode());
				newTransaction.setTransactionQuantity(String.valueOf(cptDetail.getUnit()));
				newTransaction.setTransactionType("CG");
				newTransaction.setCodedByFamilyName(req.getUserLastName());
				newTransaction.setCodedByGivenName(req.getUserFirstName());
				newTransaction.setProcedureCode(cptDetail.getCptCode());
				newTransaction.setDiagnosisCode(diagnosisCode);
				newTransaction.setModifier(modifierCode);
				newTransaction.setLastUpdatedTimestamp(currentTimestamp);
				if (dashboard != null) {
					newTransaction.setTransactionDate(String.valueOf(dashboard.getDateOfService()));
					newTransaction.setPerformedById(dashboard.getProviderId());
					newTransaction.setPerformedByFullName(
							dashboard.getProviderFirstName() + " " + dashboard.getProviderLastName());
					log.debug("Associated dashboard data: {}", dashboard);
				}

				if (patient != null) {
					newTransaction.setPointOfCare(patient.getBluebookId());
				}

				session.save(newTransaction);
				session.flush();
				session.clear();

				log.info("Saved new FinancialTransaction for visitId: {}, transactionCode: {}",
						newTransaction.getVisitId(), newTransaction.getTransactionCode());
			}

			log.info("Transaction committed for visitId: {}", req.getVisitId());

		} catch (Exception e) {
			log.error("Exception occured while saving financial transaction:  {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	private int getNextTransactionId(Long visitId, Session session) {
		Integer maxId = (Integer) session
				.createQuery("SELECT MAX(id) FROM FinancialTransaction WHERE visitId = :visitId")
				.setParameter("visitId", visitId.intValue()).uniqueResult();
		return (maxId != null) ? maxId + 1 : 1;
	}

	private void saveAuditNotes(SaveAuditDetailsReq req, ChartDetails chartDetails) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			for (CPTChartDetails cptDetail : req.getCptData()) {

				if (cptDetail.getSaveAuditNote() != null && !cptDetail.getSaveAuditNote().isEmpty()) {
					Notes notesReq = new Notes();

					notesReq.setDescription(cptDetail.getSaveAuditNote());
					notesReq.setPatientId(req.getPatientId());
					notesReq.setVisitId(req.getVisitId());
					notesReq.setUserRole("Auditor");
					notesReq.setCreatedTimestamp(currentTime);
					notesReq.setUserName(req.getUserId());
					notesReq.setUserFullName(req.getUserFullName());
					notesReq.setCreatorUserId(Integer.parseInt(req.getUserId()));

					session.save(notesReq);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while saving notes:  {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

	}

	public void saveCoderInfo(SaveAuditDetailsReq req, ChartDetails chartDetails) throws EncodeExceptionHandler {
		if (req.getInAudit() == 1) {

			Session session = this.sessionFactory.getCurrentSession();

			String icd10Code = req.getIcdData().stream().map(ICD10Data::getCode).collect(Collectors.joining(", "));

			String cptCode = req.getCptData().stream().map(CPTChartDetails::getCptCode)
					.collect(Collectors.joining(", "));

			String modifierData = req.getCptData().stream().flatMap(cpt -> cpt.getModifier().stream())
					.map(modifier -> modifier.split(" ")[0]).collect(Collectors.joining(", "));

			String unit = req.getCptData().stream().map(cpt -> String.valueOf(cpt.getUnit()))
					.collect(Collectors.joining(", "));

			Dashboard dashboardRecord = session.get(Dashboard.class, chartDetails.getVisitId());
			if (dashboardRecord != null) {
				dashboardRecord.setIcdCode(icd10Code);
				dashboardRecord.setCptCode(cptCode);
				dashboardRecord.setModifier(modifierData);
				dashboardRecord.setUnit(unit);
				session.update(dashboardRecord);
			} else {
				Dashboard newDashboardRecord = new Dashboard();
				newDashboardRecord.setVisitId(chartDetails.getVisitId());
				newDashboardRecord.setIcdCode(icd10Code);
				newDashboardRecord.setModifier(modifierData);
				newDashboardRecord.setUnit(unit);
				session.save(newDashboardRecord);
			}
		}

	}

	public void handelSaveAction(SaveAuditDetailsReq req, ChartDetails chartDetails) throws EncodeExceptionHandler {

		if (req.getInAudit() == 1) {
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				// Convert ICD data to JSON
				String icdJson = objectMapper.writeValueAsString(req.getIcdData());
				chartDetails.setAuditorICDCodes(icdJson);
				chartDetails.setIcdCodes(icdJson);

				// Convert CPT data to JSON
				String cptJson = objectMapper.writeValueAsString(req.getCptData());
				chartDetails.setAuditorCPTCodes(cptJson);
				chartDetails.setCptObject(cptJson);
				chartDetails.setAuditorUserId(Long.parseLong(req.getUserId()));
				chartDetails.setAuditorUserName(req.getUserName());
				chartDetails.setAuditorUserFullName(req.getUserFullName());
			} catch (JsonProcessingException e) {
				log.error("Failed to convert audit details to JSON", e);
				throw new EncodeExceptionHandler("Failed to process audit details", e);
			}

		} else {
			chartDetails.setAuditorICDCodes(null);
			chartDetails.setAuditorCPTCodes(null);
			chartDetails.setAuditorUserId(Long.parseLong(req.getUserId()));
			chartDetails.setAuditorUserName(req.getUserName());
			chartDetails.setAuditorUserFullName(req.getUserFullName());
		}

	}

	public void UpdateAuditQueueStatus(long visitId, String status) throws EncodeExceptionHandler {

		Session session = this.sessionFactory.getCurrentSession();
		LocalDateTime localDateTime = LocalDateTime.now();
		Timestamp currentTimestamp = Timestamp.valueOf(localDateTime);
		try {
			String hql = "UPDATE AuditQueue d SET d.status = :status, d.lastUpdatedTimestamp = :lastUpdatedTimestamp, d.auditComplete = 1 where d.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("status", status);
			query.setParameter("lastUpdatedTimestamp", currentTimestamp);
			query.setParameter("visitId", visitId);
			query.executeUpdate();
		} catch (Exception e) {
			log.error("Exception occurred while updating status: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	public void UpdateNurseDeficiencyStatus(long visitId, String status) throws EncodeExceptionHandler {

		Session session = this.sessionFactory.getCurrentSession();
		LocalDateTime localDateTime = LocalDateTime.now();
		Timestamp currentTimestamp = Timestamp.valueOf(localDateTime);
		try {
			String hql = "UPDATE AuditQueue d SET d.status = :status, d.lastUpdatedTimestamp = :lastUpdatedTimestamp where d.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("status", status);
			query.setParameter("lastUpdatedTimestamp", currentTimestamp);
			query.setParameter("visitId", visitId);
			query.executeUpdate();
		} catch (Exception e) {
			log.error("Exception occurred while updating status: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	public void UpdateDashboardStatus(String action, SaveAuditDetailsReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "";
			String status = "";
			String lastStatusChangeRole = "";

			switch (action.toLowerCase()) {
			case "nursedeficiency":
				hql = "UPDATE Dashboard d SET d.status = :status, " + "d.lastStatusChangeRole = :lastStatusChangeRole "
						+ "WHERE d.visitId = :visitId";
				status = "Nurse Deficiency";
				lastStatusChangeRole = "Nurse";
				break;

			case "completed":
				hql = "UPDATE Dashboard d SET d.status = :status, d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp, "
						+ "d.lastUpdatedByUsername = :lastUpdatedByUserName, "
						+ "d.lastUpdatedByUserId = :lastUpdatedByUserId, "
						+ "d.lastUpdatedByUserFullName = :lastUpdateByUserFullName, "
						+ "d.inAuditQueue = :inAuditQueue, " + "d.lastStatusChangeRole = :lastStatusChangeRole "
						+ "WHERE d.visitId = :visitId";

				status = "Audit Completed";
				lastStatusChangeRole = "Auditor";
				break;

			case "ready for audit":
				hql = "UPDATE Dashboard d SET d.status = :status, " + "d.lastStatusChangeRole = :lastStatusChangeRole "
						+ "WHERE d.visitId = :visitId";

				status = "Ready for Audit";
				lastStatusChangeRole = "Nurse";
				break;

			default:
				throw new EncodeExceptionHandler("Invalid action: " + action);
			}

			Query query = session.createQuery(hql);

			query.setParameter("status", status);
			query.setParameter("visitId", req.getVisitId());
			query.setParameter("lastStatusChangeRole", lastStatusChangeRole);

			if ("completed".equalsIgnoreCase(action)) {
//	            query.setParameter("userId", req.getUserId());
//	            query.setParameter("userFullName", req.getUserFullName());
//	            query.setParameter("userFirstName", req.getUserFirstName());
//	            query.setParameter("userLastName", req.getUserLastName());
				query.setParameter("lastUpdatedByUserName", req.getUserName());
				query.setParameter("lastUpdatedByUserId", req.getUserId());
				query.setParameter("lastUpdateByUserFullName", req.getUserFullName());
				query.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
				query.setParameter("inAuditQueue", false);
			}

			query.executeUpdate();
		} catch (Exception e) {
			log.error("Exception occurred while updating status: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getFilteredAuditorList(AuditorDashboardReq req, int index)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> listCount = new HashMap<>();
		List<Map<String, Object>> filteredAuditorList = new ArrayList<>();
		try {
			Map<String, Object> parameters = new HashMap<>();
			StringBuilder hqlBase = new StringBuilder("FROM Filters a WHERE 1=1");

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					switch (filterReq) {
					case "codingTeam": {
						List<String> teamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						if (!teamList.isEmpty()) {
							StringBuilder condition = new StringBuilder(" AND (");
							for (int i = 0; i < teamList.size(); i++) {
								condition.append(" a.codingTeam LIKE :team").append(i);
								if (i < teamList.size() - 1) {
									condition.append(" OR ");
								}
								parameters.put("team" + i, "%" + teamList.get(i) + "%");
							}
							condition.append(")");
							hqlBase.append(condition);
						}
						break;
					}
					case "filterId": {
						List<Integer> filterIdList = req.getFilterId();
						if (!filterIdList.isEmpty()) {
							hqlBase.append(" AND a.filterId IN (:filterIdList) ");
							parameters.put("filterIdList", filterIdList);
						}
						break;
					}
					case "filterAudience": {
						List<String> filterAudienceList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFilterAudience());
						if (!filterAudienceList.isEmpty()) {
							hqlBase.append(" AND a.filterAudience IN (:filterAudienceList) ");
							parameters.put("filterAudienceList", filterAudienceList);
						}
						break;
					}
					case "filterState": {
						List<Integer> filterStateList = req.getFilterState();
						if (!filterStateList.isEmpty()) {
							hqlBase.append(" AND a.active IN (:filterStateList) ");
							parameters.put("filterStateList", filterStateList);
						}
						break;
					}
					default:
						break;
					}
				}
			}
			// Create the main query
			StringBuilder hql = new StringBuilder("SELECT a.filterId, a.filterName, a.codingTeam, a.createdTimestamp ")
					.append(hqlBase);
			hql.append(sortList(req)); // Sorting if applicable
			log.info("Query: {}", hql);

			Query query = session.createQuery(hql.toString());
			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				if (entry.getValue() instanceof List) {
					query.setParameterList(entry.getKey(), (List<?>) entry.getValue());
				} else {
					query.setParameter(entry.getKey(), entry.getValue());
				}
			}

			query.setFirstResult(index).setMaxResults(PAGE_SIZE);
			List<Object[]> results = query.list();

			// Iterate over the results and add audit status information
			for (Object[] result : results) {
				Map<String, Object> map = new HashMap<>();
				Integer filterId = (Integer) result[0];
				map.put("filterId", filterId);
				map.put("filterName", (String) result[1]);
				map.put("codingTeam", (String) result[2]);
				map.put("filterDate", result[3]);

				// Check if the filterId exists in the AuditQueue with status "In Audit"
				Query auditQueueQuery = session
						.createQuery("FROM AuditQueue WHERE filterId = :filterId AND status = 'In Audit'");
				auditQueueQuery.setParameter("filterId", filterId);
				List<AuditQueue> auditQueueResults = auditQueueQuery.list();

				// If there is an entry with status 'In Audit', set auditRecordExists to 1
				if (!auditQueueResults.isEmpty()) {
					map.put("auditRecordExists", 1);
				} else {
					map.put("auditRecordExists", 0);
				}

				filteredAuditorList.add(map);
			}

			// Create the count query
			String countHql = "SELECT COUNT(DISTINCT a.filterId) " + hqlBase.toString();
			Query countQuery = session.createQuery(countHql);
			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				if (entry.getValue() instanceof List) {
					countQuery.setParameterList(entry.getKey(), (List<?>) entry.getValue());
				} else {
					countQuery.setParameter(entry.getKey(), entry.getValue());
				}
			}

			int totalCount = ((Number) countQuery.uniqueResult()).intValue();
			listCount.put("Count", totalCount);
			listCount.put("data", filteredAuditorList);
			log.debug("Filtered Auditor List Size: {}", totalCount);
			log.debug("Filtered Auditor List : {}", filteredAuditorList);
		} catch (Exception e) {
			log.error("Exception occurred while fetching filtered records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public Map<String, Object> getFilteredAuditorReleaseList(AuditorDashboardReq req, int index)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> listCount = new HashMap<>();
		List<Map<String, Object>> filteredAuditorList = new ArrayList<>();

		try {
			Map<String, Object> parameters = new HashMap<>();
			// Join with AuditQueue and set base query
			StringBuilder hqlBase = new StringBuilder(
					"FROM Filters a JOIN AuditQueue aq ON a.filterId = aq.filterId WHERE 1=1");

			// Apply filter criteria from request
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					switch (filterReq) {
					case "codingTeam": {
						List<String> teamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						if (!teamList.isEmpty()) {
							StringBuilder condition = new StringBuilder(" AND (");
							for (int i = 0; i < teamList.size(); i++) {
								condition.append(" a.codingTeam LIKE :team").append(i);
								if (i < teamList.size() - 1) {
									condition.append(" OR ");
								}
								parameters.put("team" + i, "%" + teamList.get(i) + "%");
							}
							condition.append(")");
							hqlBase.append(condition);
						}
						break;
					}

					case "filterId": {
						List<Integer> filterIdList = req.getFilterId();
						if (!filterIdList.isEmpty()) {
							hqlBase.append(" AND a.filterId IN (:filterIdList) ");
							parameters.put("filterIdList", filterIdList);
						}
						break;
					}

					case "filterAudience": {
						List<String> filterAudienceList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFilterAudience());
						if (!filterAudienceList.isEmpty()) {
							hqlBase.append(" AND a.filterAudience IN (:filterAudienceList) ");
							parameters.put("filterAudienceList", filterAudienceList);
						}
						break;
					}
					case "filterState": {
						List<Integer> filterStateList = req.getFilterState();
						if (!filterStateList.isEmpty()) {
							hqlBase.append(" AND a.active IN (:filterStateList) ");
							parameters.put("filterStateList", filterStateList);
						}
						break;
					}
					default:
						break;
					}
				}
			}

			// Add audit status condition from AuditQueue
			List<String> validStatuses = Arrays.asList("Completed", "Ready for Audit", "In Audit");
			hqlBase.append(" AND aq.status IN (:validStatuses) ");
			parameters.put("validStatuses", validStatuses);

			// Build the final data query
			StringBuilder hql = new StringBuilder(
					"SELECT DISTINCT a.filterId, a.filterName, a.codingTeam, a.createdTimestamp ").append(hqlBase);

			hql.append(sortList(req)); // Optional sorting if implemented
			log.info("Query: {}", hql);
			Query query = session.createQuery(hql.toString());

			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				if (entry.getValue() instanceof List) {
					query.setParameterList(entry.getKey(), (List<?>) entry.getValue());
				} else {
					query.setParameter(entry.getKey(), entry.getValue());
				}
			}

			query.setFirstResult(index).setMaxResults(PAGE_SIZE);
			List<Object[]> results = query.list();

			// Transform query results into response map
			for (Object[] result : results) {
				Map<String, Object> map = new HashMap<>();
				map.put("filterId", result[0]);
				map.put("filterName", result[1]);
				map.put("codingTeam", result[2]);
				map.put("filterDate", result[3]);
				filteredAuditorList.add(map);
			}

			// Count query — includes JOIN and status filter
			String countHql = "SELECT COUNT(DISTINCT a.filterId) " + hqlBase;

			Query countQuery = session.createQuery(countHql);

			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				if (entry.getValue() instanceof List) {
					countQuery.setParameterList(entry.getKey(), (List<?>) entry.getValue());
				} else {
					countQuery.setParameter(entry.getKey(), entry.getValue());
				}
			}
			int totalCount = ((Number) countQuery.uniqueResult()).intValue();

			// Final response
			listCount.put("Count", totalCount);
			listCount.put("data", filteredAuditorList);
			log.debug("Filtered Auditor List Size: {}", totalCount);
			log.debug("Filtered Auditor List : {}", filteredAuditorList);
		} catch (Exception e) {
			log.error("Exception occurred while fetching filtered records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public Map<String, Object> getAllFilteredAuditorList(AuditorDashboardReq req, int index, boolean includeAllData)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> listCount = new HashMap<>();
		List<Map<String, Object>> filteredAuditorList = new ArrayList<>();
		try {
			String filterHql = "SELECT f.filterId, f.filterName, f.codingTeam FROM Filters f WHERE 1=1 ";
			Map<String, Object> parameters = new HashMap<>();

			if (req.getCodingTeam() != null && !req.getCodingTeam().isEmpty()) {
				List<String> teamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
				StringBuilder conditions = new StringBuilder();
				for (int i = 0; i < teamList.size(); i++) {
					if (i > 0)
						conditions.append(" OR ");
					conditions.append("f.codingTeam LIKE :team").append(i);
					parameters.put("team" + i, "%" + teamList.get(i) + "%");
				}
				filterHql += " AND (" + conditions.toString() + ") ";
			}

			if (req.getFilterAudience() != null && !req.getFilterAudience().isEmpty()) {
				List<String> filterAudience = FilterRequestUtil.getListFromDelimitedStr(req.getFilterAudience());
				filterHql += " AND f.filterAudience IN (:filterAudience) ";
				parameters.put("filterAudience", filterAudience);
			}

			if (req.getFilterState() != null && !req.getFilterState().isEmpty()) {
				filterHql += " AND f.active IN (:filterStateList) ";
				parameters.put("filterStateList", req.getFilterState());
			}

			if (req.getFilterId() != null && !req.getFilterId().isEmpty()) {
				filterHql += " AND f.filterId IN (:filterIdList) ";
				parameters.put("filterIdList", req.getFilterId());
			}

			String order = (req.getOrder() == 0) ? "desc" : "asc";
			filterHql += " ORDER BY LOWER(f.codingTeam) " + order + ", f.createdTimestamp ASC";

			List<Object[]> filterResults = session.createQuery(filterHql).setProperties(parameters).list();

			String auditHql = "SELECT a.filterId, a.visitId, a.patientId, a.patientName, a.facilityId, a.BBC, "
					+ "a.facilityAlias, a.DOS, a.status, a.MRN, a.patientFirstName, a.patientLastName, "
					+ "a.insurance, a.dateAdded, a.assigneeUserFullName "
					+ "FROM AuditQueue a WHERE a.auditComplete = 0 AND a.filterId IN (:filterIds) ";

			// Role-based status filtering - ENC-7669
			if (req.getRoles() != null && !req.getRoles().isEmpty()) {
				if (req.getRoles().size() == 1 && req.getRoles().contains("Nurse")) {
					auditHql += " AND a.status IN ('Completed','Nurse Review','Nurse Deficiency','Ready for Audit')";
				} else if (req.getRoles().contains("Nurse")) {
					auditHql += " AND a.status IN ('Completed','Ready for Audit','In Audit','Nurse Review','Nurse Deficiency')";
				} else if (req.getRoles().size() == 1 && req.getRoles().contains("Auditor")) {
					auditHql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				} else {
					auditHql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				}
			} else {
				auditHql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
			}

			auditHql += " ORDER BY a.DOS ASC";

			List<Integer> filterIds = filterResults.stream().map(filter -> (Integer) filter[0])
					.collect(Collectors.toList());

			Query auditQuery = session.createQuery(auditHql);
			auditQuery.setParameterList("filterIds", filterIds);
			List<Object[]> auditResults = auditQuery.list();

			Map<Integer, List<Object[]>> auditMap = new HashMap<>();
			for (Object[] result : auditResults) {
				Integer filterId = (Integer) result[0];
				auditMap.computeIfAbsent(filterId, k -> new ArrayList<>()).add(result);
			}

			for (Object[] filter : filterResults) {
				Integer filterId = (Integer) filter[0];
				String filterName = (String) filter[1];
				String team = (String) filter[2];

				if (auditMap.containsKey(filterId)) {
					for (Object[] audit : auditMap.get(filterId)) {
						Map<String, Object> map = new HashMap<>();
						map.put("filterId", filterId);
						map.put("filterName", filterName);
						map.put("codingTeam", team);
						map.put("visitId", (Long) audit[1]);
						map.put("patientId", (Long) audit[2]);
						map.put("patientName", (String) audit[3]);
						map.put("facilityId", (Integer) audit[4]);
						map.put("BBC", (String) audit[5]);
						map.put("facilityAlias", (String) audit[6]);
						map.put("DOS", audit[7]);
						map.put("status", (String) audit[8]);
						map.put("MRN", (String) audit[9]);
						map.put("patientFirstName", (String) audit[10]);
						map.put("patientLastName", (String) audit[11]);
						map.put("insurance", (String) audit[12]);
						map.put("dateAdded", audit[13]);
						map.put("assigneeUserFullName", (String) audit[14]);
						filteredAuditorList.add(map);
					}
				} else {
					Map<String, Object> map = new HashMap<>();
					map.put("filterId", filterId);
					map.put("filterName", filterName);
					map.put("codingTeam", team);
					map.put("visitId", null);
					map.put("patientId", null);
					map.put("patientName", null);
					map.put("facilityId", null);
					map.put("BBC", null);
					map.put("facilityAlias", null);
					map.put("DOS", null);
					map.put("status", null);
					map.put("MRN", null);
					map.put("patientFirstName", null);
					map.put("patientLastName", null);
					map.put("insurance", null);
					map.put("dateAdded", null);
					map.put("assigneeUserFullName", null);
					filteredAuditorList.add(map);
				}
			}

			int totalCount = filteredAuditorList.size();
			listCount.put("Count", totalCount);
			listCount.put("data", filteredAuditorList);
			log.debug("Filtered Auditor List Size: {}", totalCount);
			log.debug("Filtered Auditor List : {}", filteredAuditorList);
		} catch (Exception e) {
			log.error("Exception occurred while fetching filtered records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<Filters> getAllAuditRecords(AuditorDashboardReq req, int index, boolean includeAllData)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Filters> auditorDashboard = new ArrayList<>();
		try {
			if (!includeAllData) {
				StringBuilder hqlBase = new StringBuilder("SELECT DISTINCT a FROM Filters a WHERE 1=1");

				if (req.getFilterAudience() != null && !req.getFilterAudience().isEmpty()) {
					hqlBase.append(" AND a.filterAudience = :filterAudience ");
				} else {
					hqlBase.append(" AND a.filterAudience = 'Auditor' ");
				}

				hqlBase.append(" GROUP BY a.filterId, a.filterName, a.team");

				if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
					hqlBase.append(sortList(req));
				} else {
					hqlBase.append(" ORDER BY LOWER(a.team) ASC");
				}

				log.info("Query: {}", hqlBase);

				Query<Filters> query = session.createQuery(hqlBase.toString(), Filters.class);

				if (req.getFilterAudience() != null && !req.getFilterAudience().isEmpty()) {
					query.setParameter("filterAudience", req.getFilterAudience());
				}

				auditorDashboard = query.setFirstResult(index).setMaxResults(PAGE_SIZE).list();
			}

		} catch (Exception e) {
			log.error("Exception occurred while fetching all Auditor records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return auditorDashboard;
	}

	@Override
	public List<Object[]> getExcelAllAuditRecords(AuditorDashboardReq req, int index, boolean includeAllData)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> auditorDashboard = new ArrayList<>();
		try {
			StringBuilder hql = new StringBuilder(
					"SELECT f.filterId, f.filterName, f.team, a.visitId, a.patientId, a.patientName, "
							+ "a.facilityId, a.BBC, a.facilityAlias, a.DOS, a.status, a.MRN, "
							+ "a.patientFirstName, a.patientLastName, a.insurance, a.dateAdded, "
							+ "a.assigneeUserId, a.assigneeUserName, a.assigneeUserFullName "
							+ "FROM Filters f LEFT JOIN AuditQueue a ON f.filterId = a.filterId WHERE 1=1 ");

			if (req.getFilterAudience() != null && !req.getFilterAudience().isEmpty()) {
				hql.append(" AND f.filterAudience = :filterAudience ");
			} else {
				hql.append(" AND f.filterAudience = 'Auditor' ");
			}

			// ENC-7669
			if (req.getRoles() != null && !req.getRoles().isEmpty()) {
				if (req.getRoles().size() == 1 && req.getRoles().contains("Nurse")) {
					hql.append(" AND a.status IN ('Completed','Nurse Review','Nurse Deficiency','Ready for Audit')");
				} else if (req.getRoles().contains("Nurse")) {
					hql.append(
							" AND a.status IN ('Completed','Ready for Audit','In Audit','Nurse Review','Nurse Deficiency')");
				} else if (req.getRoles().size() == 1 && req.getRoles().contains("Auditor")) {
					hql.append(" AND a.status IN ('Completed','Ready for Audit','In Audit')");
				} else {
					hql.append(" AND a.status IN ('Completed','Ready for Audit','In Audit')");
				}
			} else {
				hql.append(" AND a.status IN ('Completed','Ready for Audit','In Audit')");
			}

			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql.append(excelsortList(req));
			} else {
				hql.append(" ORDER BY LOWER(f.team) ASC, f.createdTimestamp, a.DOS ASC");
			}

			log.info("Query: {}", hql);

			Query<Object[]> query = session.createQuery(hql.toString(), Object[].class);

			if (!includeAllData) {
				query.setFirstResult(index).setMaxResults(PAGE_SIZE);
			}

			auditorDashboard = query.list();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Excel Auditor records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return auditorDashboard;
	}

	@Override
	public Long getTotalCount(int index, AuditorDashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;

		try {
			StringBuilder hql = new StringBuilder("SELECT count(DISTINCT a.filterId) FROM Filters a WHERE 1=1");

			if (req.getFilterAudience() != null && !req.getFilterAudience().isEmpty()) {
				hql.append(" AND a.filterAudience = :filterAudience ");
			} else {
				hql.append(" AND a.filterAudience = 'Auditor' ");
			}

			log.info("Count Query: {}", hql);

			Query<Long> query = session.createQuery(hql.toString(), Long.class);
			if (req.getFilterAudience() != null && !req.getFilterAudience().isEmpty()) {
				query.setParameter("filterAudience", req.getFilterAudience());
			}

			totalCount = query.uniqueResult();

		} catch (Exception e) {
			log.error("Exception occurred while fetching Auditor Dashboard total count : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}

	private String sortList(AuditorDashboardReq req) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "desc" : "asc";
		if (sortBy == null || sortBy.isEmpty()) {
			return " ORDER BY LOWER(a.codingTeam) ASC, a.createdTimestamp DESC";
		} else {
			switch (sortBy.toLowerCase()) {
			case "codingteam":
				return " ORDER BY LOWER(a.codingTeam) " + order + ",a.createdTimestamp ASC";
			case "filterid":
				return " ORDER BY LOWER(a.filterName) " + order + ",a.createdTimestamp ASC";
			default:
				return " ORDER BY LOWER(a." + sortBy + ") " + order + ",a.createdTimestamp ASC";
			}
		}
	}

	private String excelsortList(AuditorDashboardReq req) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "desc" : "asc";
		if (sortBy == null || sortBy.isEmpty()) {
			return " ORDER BY LOWER(f.team) ASC, f.createdTimestamp DESC, a.DOS ASC";
		} else {
			switch (sortBy.toLowerCase()) {
			case "codingteam":
				return " ORDER BY LOWER(f.team) " + order + ", f.createdTimestamp ASC, a.DOS ASC";
			case "filterid":
				return " ORDER BY LOWER(f.filterName) " + order + ", f.createdTimestamp ASC, a.DOS ASC";
			default:
				return " ORDER BY LOWER(f." + sortBy + ") " + order + ", f.createdTimestamp ASC, a.DOS ASC";
			}
		}
	}

	@Override
	public List<AuditQueue> getCollapseDetails(int filterId, AuditorCollapsibleSectionReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<AuditQueue> collapseDetails = new ArrayList<>();
		try {
			String hql = "SELECT DISTINCT a FROM AuditQueue a WHERE a.filterId = :filterId AND a.auditComplete = 0";

			// Add role-based status conditions - ENC-7669
			if (req.getRoles() != null && !req.getRoles().isEmpty()) {
				if (req.getRoles().size() == 1 && req.getRoles().contains("Nurse")) {
					hql += " AND a.status IN ('Completed','Nurse Review','Nurse Deficiency','Ready for Audit')";
				} else if (req.getRoles().contains("Nurse")) {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit','Nurse Review','Nurse Deficiency')";
				} else if (req.getRoles().size() == 1 && req.getRoles().contains("Auditor")) {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				} else {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				}
			} else {
				hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
			}

			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortLists(req, hql);

			} else {
				log.debug("No requestfound...................");
				hql += " ORDER BY a.DOS ASC";
			}

			collapseDetails = session.createQuery(hql, AuditQueue.class).setParameter("filterId", filterId).list();
		} catch (Exception e) {
			log.error("Exception occurred while fetching collapsible section details for filterId: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return collapseDetails;
	}

	public Long getCountOfAuditQueueByFilterId(int filterId, AuditorDashboardReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long count = 0L;
		try {
			String hql = "SELECT COUNT(DISTINCT a) FROM AuditQueue a WHERE a.filterId = :filterId AND a.auditComplete = 0";

			// Add role-based status conditions - ENC-7669
			if (req.getRoles() != null && !req.getRoles().isEmpty()) {
				if (req.getRoles().size() == 1 && req.getRoles().contains("Nurse")) {
					hql += " AND a.status IN ('Completed','Nurse Review','Nurse Deficiency','Ready for Audit')";
				} else if (req.getRoles().contains("Nurse")) {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit','Nurse Review','Nurse Deficiency')";
				} else if (req.getRoles().size() == 1 && req.getRoles().contains("Auditor")) {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				} else {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				}
			} else {
				hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
			}

			count = session.createQuery(hql, Long.class).setParameter("filterId", filterId).getSingleResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching count of AuditQueue for filterId: {}", filterId, e);
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return count;
	}

	public Long getCountOfAuditQueueByFilterIdRelease(int filterId, AuditorDashboardReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long count = 0L;
		try {
			String hql = "SELECT COUNT(DISTINCT a) FROM AuditQueue a WHERE a.filterId = :filterId AND a.auditComplete = 0";

			hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";

			count = session.createQuery(hql, Long.class).setParameter("filterId", filterId).getSingleResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching count of AuditQueue for filterId to release: {}", filterId, e);
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return count;
	}

	@Override
	public AuditorDashboardFilter getAuditorFilterOptions(AuditorDashboardReq req) throws EncodeExceptionHandler {
		Session session = sessionFactory.getCurrentSession();
		AuditorDashboardFilter filterOptions = new AuditorDashboardFilter();
		try {
			StringBuilder baseQuery = new StringBuilder("SELECT DISTINCT ");
			String filterColumn;

			if ("codingTeam".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("a.codingTeam");
				filterColumn = "a.codingTeam";
			} else if ("filterId".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("a.filterId, a.filterName");
				filterColumn = "a.filterName";
			} else {
				throw new EncodeExceptionHandler("Unsupported filter option: " + req.getFilterOptions());
			}

			baseQuery.append(" FROM Filters a WHERE 1=1 ");
			Map<String, Object> parameters = new HashMap<>();

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					baseQuery.append(" AND ");
					switch (filterReq) {
					case "codingTeam":
						List<String> teamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						if (!teamList.isEmpty()) {
							StringBuilder condition = new StringBuilder("(");
							for (int i = 0; i < teamList.size(); i++) {
								condition.append(" a.codingTeam LIKE :team").append(i);
								if (i < teamList.size() - 1) {
									condition.append(" OR ");
								}
								parameters.put("team" + i, "%" + teamList.get(i) + "%");
							}
							condition.append(")");
							baseQuery.append(condition);
						}
						break;
					case "filterId":
						List<Integer> filterIdList = req.getFilterId();
						baseQuery.append("a.filterId IN :filterId ");
						parameters.put("filterId", filterIdList);
						break;
					case "filterAudience":
						List<String> filterAudienceList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFilterAudience());
						if (!filterAudienceList.isEmpty()) {
							baseQuery.append("a.filterAudience IN (:filterAudienceList) ");
							parameters.put("filterAudienceList", filterAudienceList);
						}
						break;
					default:
						break;
					}
				}
			}

			baseQuery.append(" ORDER BY LOWER(").append(filterColumn).append(") ASC");
			Query<?> q = session.createQuery(baseQuery.toString());
			log.info("query .............: {}", baseQuery);

			// Set parameters to the query
			if (!parameters.isEmpty()) {
				for (Map.Entry<String, Object> entry : parameters.entrySet()) {
					if (entry.getValue() instanceof List) {
						q.setParameterList(entry.getKey(), (List<?>) entry.getValue());
					} else {
						q.setParameter(entry.getKey(), entry.getValue());
					}
				}
			}

			List<?> results = q.getResultList();
			Set<String> uniqueTeams = new TreeSet<>(); // TreeSet to maintain natural order

			if ("codingTeam".equalsIgnoreCase(req.getFilterOptions())) {
				for (Object result : results) {
					String jsonString = result.toString();

					List<String> teams = new ObjectMapper().readValue(jsonString, new TypeReference<List<String>>() {
					});
					uniqueTeams.addAll(teams);
				}
				filterOptions.setCodingTeamOptions(new ArrayList<>(uniqueTeams));
			} else if ("filterId".equalsIgnoreCase(req.getFilterOptions())) {
				List<Object> options = new ArrayList<>();
				for (Object result : results) {
					Object[] obj = (Object[]) result;
					Map<String, Object> option = new HashMap<>();
					option.put("filterId", obj[0]);
					option.put("filterName", obj[1]);
					options.add(option);
				}
				filterOptions.setCodingTeamOptions(options);
			}
		} catch (Exception e) {
			throw new EncodeExceptionHandler("Error fetching filter options: " + e.getMessage(), e);
		}
		return filterOptions;
	}

	@Override
	public void updateAuditChartStatus(UpdateChartstatusReq req, String auditStatus, String role)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();

		LocalDateTime localDateTime = LocalDateTime.now();
		String hql = "UPDATE AuditQueue d SET d.status = :status," + " d.lastUpdatedTimestamp = :lastUpdatedTimestamp,"
				+ " d.lastUpdatedByUserName = :lastUpdatedByUserName,"
				+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, " + " d.auditComplete = :auditComplete, "
				+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName" + " WHERE d.visitId = :visitId";

		String hql1 = "UPDATE Dashboard d SET d.status = :status, "
				+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp, "
				+ "d.lastStatusChangeRole = :lastStatusChangeRole " + "WHERE d.visitId = :visitId";

		for (long visitId : req.getVisitId()) {
			try {

				Timestamp currentTimestamp = Timestamp.valueOf(localDateTime);
				log.info("Current Timestamp (LocalDateTime): " + currentTimestamp);

				Query query = session.createQuery(hql);
				query.setParameter("status", auditStatus);
				query.setParameter("lastUpdatedTimestamp", currentTimestamp);
				query.setParameter("lastUpdatedByUserName", req.getUserName());
				query.setParameter("lastUpdatedByUserId", req.getUserId());
				query.setParameter("lastUpdatedByUserFullName", req.getUserFullName());
				query.setParameter("visitId", visitId);
				query.setParameter("auditComplete", 0);
				int rowsAffected = query.executeUpdate();

				if (rowsAffected > 0) {
					log.info("Auditor Dashboard updated successfully with In Audit Status");
				} else {
					log.info("No rows were affected while updating the auditor dashboard.");
				}

				if ("Nurse".equalsIgnoreCase(role)) {
//	                java.sql.Date auditDate = new java.sql.Date(System.currentTimeMillis());

					Timestamp auditDate = Timestamp.valueOf(localDateTime);

					String hqlUpdateAuditDate = "UPDATE AuditQueue d SET d.auditDate = :auditDate WHERE d.visitId = :visitId";
					Query updateAuditDateQuery = session.createQuery(hqlUpdateAuditDate);
					updateAuditDateQuery.setParameter("auditDate", auditDate);
					updateAuditDateQuery.setParameter("visitId", visitId);

					int rowsAffectedAuditDate = updateAuditDateQuery.executeUpdate();
					if (rowsAffectedAuditDate > 0) {
						log.info("Audit Date updated successfully for Nurse role.");
					} else {
						log.info("No rows were affected while updating the auditDate for Nurse.");
					}
				}

				String dashboardHql = "FROM Dashboard WHERE visitId = :visitId";
				Query<Dashboard> dashboardQuery = session.createQuery(dashboardHql, Dashboard.class);
				dashboardQuery.setParameter("visitId", visitId);
				Dashboard existingDashboardRecord = dashboardQuery.uniqueResult();

				if (existingDashboardRecord != null) {
					Query query1 = session.createQuery(hql1);
					query1.setParameter("status", auditStatus);
					query1.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
					query1.setParameter("visitId", visitId);
					query1.setParameter("lastStatusChangeRole", role);

					int rowsAffected1 = query1.executeUpdate();

					if (rowsAffected1 > 0) {
						log.info("Status saved Successfully in Dashboard!");
					} else {
						log.info("No rows were affected while updating the dashboard.");
					}
				}

			} catch (Exception e) {
				log.error("Exception occured : " + e.getMessage());
				throw new EncodeExceptionHandler(e.getMessage());
			}
		}
	}

	@Override
	public void updatedCompletedStatus(UpdateChartstatusReq req, String completedStatus) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		LocalDateTime localDateTime = LocalDateTime.now();
		String hql = "UPDATE AuditQueue d SET d.status = :status, d.isLocked = 0,"
				+ " d.lastUpdatedTimestamp = :lastUpdatedTimestamp,"
				+ " d.lastUpdatedByUserName = :lastUpdatedByUserName,"
				+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
				+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName" + " WHERE d.visitId = :visitId";

		String hql1 = "UPDATE Dashboard d SET d.status = :status, d.inAuditQueue = :inAuditQueue,"
				+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " + "WHERE d.visitId = :visitId";

		String dashboardHql = "FROM Dashboard WHERE visitId = :visitId";

		for (long visitId : req.getVisitId()) {

			try {
				Timestamp currentTimestamp = Timestamp.valueOf(localDateTime);
				Query query = session.createQuery(hql);
				query.setParameter("status", completedStatus);
				query.setParameter("lastUpdatedTimestamp", currentTimestamp);
				query.setParameter("lastUpdatedByUserName", req.getUserName());
				query.setParameter("lastUpdatedByUserId", req.getUserId());
				query.setParameter("lastUpdatedByUserFullName", req.getUserFullName());
				query.setParameter("visitId", visitId);
				int rowsAffected = query.executeUpdate();

				if (rowsAffected > 0) {
					log.info("Auditor Dashboard updated successfully with completed Status");

				} else {
					log.info("No rows were affected while updating the dashboard.");
				}

				Query<Dashboard> dashboardQuery = session.createQuery(dashboardHql, Dashboard.class);
				dashboardQuery.setParameter("visitId", visitId);
				Dashboard existingDashboardRecord = dashboardQuery.uniqueResult();

				if (existingDashboardRecord != null) {
					Query query1 = session.createQuery(hql1);
					query1.setParameter("status", completedStatus);
					query1.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
					query1.setParameter("visitId", visitId);
					query1.setParameter("inAuditQueue", false);

					int rowsAffected1 = query1.executeUpdate();

					if (rowsAffected1 > 0) {
						log.info("Status saved Successfully in Dashboard!");
					} else {
						log.info("No rows were affected while updating the dashboard.");
					}
				}
			}

			catch (Exception e) {
				log.error("Exception occured : " + e.getMessage());
				throw new EncodeExceptionHandler(e.getMessage());
			}
		}
	}

	@Override
	public void updatedDashboardStatus(UpdateChartstatusReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			for (long visitId : req.getVisitId()) {
				String hql = "UPDATE Dashboard d SET d.status = :status, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " + "WHERE d.visitId = :visitId";
				log.info("query .............: {}", hql.toString());
				Query query = session.createQuery(hql);

				Dashboard dashboard = session.get(Dashboard.class, visitId);

				if (dashboard != null) {
					String newStatus;
					if ("CMC".equalsIgnoreCase(dashboard.getLastStatusChangeRole())) {
						newStatus = "New";
					} else if ("Coder".equalsIgnoreCase(dashboard.getLastStatusChangeRole())) {
						newStatus = "Ready";
					} else {
						log.info("No status change required for visitId: " + visitId);
						continue;
					}
					query.setParameter("status", newStatus);
					query.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
					query.setParameter("visitId", visitId);

					int rowsAffected = query.executeUpdate();

					log.info("query .............: {}", hql);
					if (rowsAffected > 0) {
						log.info("Dashboard updated successfully with new Status");

					} else {
						log.info("No rows were affected while updating the dashboard.");
					}

				} else {
					log.info("No dashboard record found for visitId: " + visitId);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public AuditQueue getRecordByVisitId(long visitId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		AuditQueue record = null;
		try {
			String hql = "FROM AuditQueue a WHERE a.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);

			record = (AuditQueue) query.uniqueResult();

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}

	@Override
	public long fetchNextRecord(int filterId, Long currentVisitId, String role) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long visitId = 0L;

		try {
			String hql = "";
			List<String> statuses = new ArrayList<>();

			switch (role.toLowerCase()) {
			case "auditor":
				statuses.add("In Audit");
				statuses.add("Completed");
				statuses.add("Ready for Audit");
				break;
			case "nurse":
				statuses.add("Nurse Review");
				statuses.add("Ready for Audit");
				statuses.add("Nurse Deficiency");
				statuses.add("Completed");
				break;

			default:
				throw new EncodeExceptionHandler("Invalid role: " + role);
			}

			hql = "SELECT a.visitId FROM AuditQueue a WHERE a.filterId = :filterId " + "AND a.status IN :statuses "
					+ "ORDER BY a.DOS DESC";
			log.info("query .............: {}", hql);

			List<Long> visitIds = session.createQuery(hql, Long.class).setParameter("filterId", filterId)
					.setParameterList("statuses", statuses).list();
			log.info("visitIds: {}", visitIds);

			if (visitIds != null && !visitIds.isEmpty()) {
				int currentIndex = visitIds.indexOf(currentVisitId);

				if (currentIndex > 0) {
					visitId = visitIds.get(currentIndex - 1);
				} else if (currentIndex == 0) {
					log.info("Reached end of records (start) for filterId: {}", filterId);
					visitId = 0L;
					// throw new EncodeExceptionHandler("Reached end of records.");
				} else {
					visitId = visitIds.get(visitIds.size() - 1);
				}
			}
		} catch (Exception e) {
			log.error("Exception while fetching previous record for {}: {}", role, e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return visitId;
	}

	@Override
	public Dashboard getDashboardByVisitId(Long visitId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Dashboard dashboard = null;
		try {
			String hql = "FROM Dashboard d WHERE d.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);
			dashboard = (Dashboard) query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception in while retrieve data for visitId : {}", e.getMessage());
		}
		return dashboard;
	}

	public List<Notes> getAuditNotes(NoteListReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Notes> retrieveNotes = new ArrayList<>();

		try {
			String hql = "FROM Notes WHERE visitId = :visitId AND userRole = :userRole"
					+ " order by createdTimestamp desc";

			log.info("query : {}", hql);
			retrieveNotes = session.createQuery(hql).setParameter("visitId", req.getVisitId())
					.setParameter("userRole", req.getUserRole()).list();

			log.info("query : {}", hql);
		} catch (Exception e) {
			log.error("Exception occurred while retrieving audit note  details for userRole: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return retrieveNotes;
	}

	@Override
	public FilterOptions retrieveCollapsibleFilterOption(AuditorCollapsibleSectionReq req, int filterId)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			// String query = " WHERE 1 = 1";
			String query = " WHERE filterId =:filterId AND auditComplete = 0";

			// Add role-based status conditions - ENC-7669
			if (req.getRoles() != null && !req.getRoles().isEmpty()) {
				if (req.getRoles().size() == 1 && req.getRoles().contains("Nurse")) {
					query += " AND status IN ('Completed','Nurse Review','Nurse Deficiency','Ready for Audit')";
				} else if (req.getRoles().contains("Nurse")) {
					query += " AND status IN ('Completed','Ready for Audit','In Audit','Nurse Review','Nurse Deficiency')";
				} else if (req.getRoles().size() == 1 && req.getRoles().contains("Auditor")) {
					query += " AND status IN ('Completed','Ready for Audit','In Audit')";
				} else {
					query += " AND status IN ('Completed','Ready for Audit','In Audit')";
				}
			} else {
				query += " AND status IN ('Completed','Ready for Audit','In Audit')";
			}

			Map<String, Object> parameters = new HashMap<>();

			String filterColumn = req.getFilterOptions();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {

					case "dateOfService": {
						query += " DOS BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "dateQueued": {
						query += " dateAdded BETWEEN :startInterfaceDate AND :endInterfaceDate ";
						parameters.put("startInterfaceDate", dateFormat.parse(req.getStartDateQueued()));
						parameters.put("endInterfaceDate", dateFormat.parse(req.getEndDateQueued()));
					}
						break;

					case "mrn": {
						List<String> medicalRecordNumberList = FilterRequestUtil.getListFromDelimitedStr(req.getMrn());
						query += " MRN IN :MRN ";
						parameters.put("MRN", medicalRecordNumberList);
					}
						break;
					case "bbc": {
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " BBC IN :BBC ";
						parameters.put("BBC", bbcList);
					}
						break;
					case "status": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						query += " status IN :status ";
						parameters.put("status", statusList);
					}
						break;
					case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						query += " patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						query += " patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;

					case "assignedNurse": {
						List<String> assignedNurseList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssignedNurse());
						query += " assigneeUserFullName IN :assigneeUserFullName ";
						parameters.put("assigneeUserFullName", assignedNurseList);
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "insurance": {
						List<String> insuranceList = FilterRequestUtil.getListFromDelimitedStr(req.getInsurance());
						query += " insurance IN :insurance";
						parameters.put("insurance", insuranceList);
					}
						break;

					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("status")) {
				filterColumn = "status";
			}
			if (req.getFilterOptions().equalsIgnoreCase("patientFirstName")) {
				filterColumn = "patientFirstName";
			}

			if (req.getFilterOptions().equalsIgnoreCase("insurance")) {
				filterColumn = "insurance";
			}

			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "BBC";
			}

			if (req.getFilterOptions().equalsIgnoreCase("mrn")) {
				filterColumn = "MRN";
			}

			if (req.getFilterOptions().equalsIgnoreCase("assignedNurse")) {
				filterColumn = "assigneeUserFullName";
			}

			if (req.getFilterOptions().equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(DOS), MAX(DOS) FROM AuditQueue " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("filterId", filterId)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if ((req.getFilterOptions().equalsIgnoreCase("dateQueued"))) {
				String dateHql = "SELECT MIN(dateAdded), MAX(dateAdded) FROM AuditQueue " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("filterId", filterId)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinReceivedDate((Date) object[0]);
				filterOptions.setMaxReceivedDate((Date) object[1]);
			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM AuditQueue " + query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setParameter("filterId", filterId)
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM AuditQueue " + query + " ORDER BY LOWER("
						+ filterColumn + ") asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("filterId", filterId)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}
			log.debug("hql..... :  {}", hql);

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	private String sortLists(AuditorCollapsibleSectionReq req, String hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("firstName")) {
			hql += " order by LOWER(a.patientFirstName) ";
		} else if (sortBy.equals("lastName")) {
			hql += " order by LOWER(a.patientLastName) ";
		} else if (sortBy.equals("bbc")) {
			hql += " order by LOWER(a.BBC) ";
		} else if (sortBy.equals("status")) {
			hql += " order by LOWER(a.status) ";
		} else if (sortBy.equals("dateOfService")) {
			hql += " order by LOWER(a.DOS) ";
		} else if (sortBy.equals("mrn")) {
			hql += " order by LOWER(a.MRN) ";
		} else if (sortBy.equals("assignedNurse")) {
			hql += " order by LOWER(a.assigneeUserFullName) ";
		} else if (sortBy.equals("age")) {
			hql += " order by LOWER(a.receivedDate) ";
		} else if (sortBy.equals("insurance")) {
			hql += " order by LOWER(a.insurance) ";
		} else {
			hql += " order by LOWER(a." + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public Map<String, Object> getCollapsibleFilteredData(int filterId, AuditorCollapsibleSectionReq req, int index,
			boolean isApplyPagination) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<AuditQueue> collapsibleSection = new ArrayList<>();
		List<AuditQueue> alldata = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String hql = "SELECT DISTINCT a FROM AuditQueue a WHERE a.filterId = :filterId AND a.auditComplete = 0";

			// Add role-based status conditions- ENC-7669
			if (req.getRoles() != null && !req.getRoles().isEmpty()) {
				if (req.getRoles().size() == 1 && req.getRoles().contains("Nurse")) {
					hql += " AND a.status IN ('Completed','Nurse Review','Nurse Deficiency','Ready for Audit')";
				} else if (req.getRoles().contains("Nurse")) {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit','Nurse Review','Nurse Deficiency')";
				} else if (req.getRoles().size() == 1 && req.getRoles().contains("Auditor")) {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				} else {
					hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
				}
			} else {
				hql += " AND a.status IN ('Completed','Ready for Audit','In Audit')";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				log.debug("filterList............." + filterList);

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "dateOfService": {
						hql += " a.DOS BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "dateQueued": {
						hql += " a.dateAdded BETWEEN :startInterfaceDate AND :endInterfaceDate ";
						parameters.put("startInterfaceDate", dateFormat.parse(req.getStartDateQueued()));
						parameters.put("endInterfaceDate", dateFormat.parse(req.getEndDateQueued()));
					}
						break;

					case "mrn": {
						List<String> medicalRecordNumberList = FilterRequestUtil.getListFromDelimitedStr(req.getMrn());
						hql += " a.MRN IN :MRN ";
						parameters.put("MRN", medicalRecordNumberList);
					}
						break;
					case "assignedNurse": {
						List<String> assignedNurseList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssignedNurse());
						hql += " a.assigneeUserFullName IN :assigneeUserFullName ";
						parameters.put("assigneeUserFullName", assignedNurseList);
					}
						break;
					case "bbc": {
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.BBC IN :BBC ";
						parameters.put("BBC", bbcList);
					}
						break;
					case "status": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						hql += " a.status IN :status ";
						parameters.put("status", statusList);
					}
						break;
					case "patientFirstName": {
						List<String> firstNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientFirstName());
						hql += " a.patientFirstName IN :patientFirstName ";
						parameters.put("patientFirstName", firstNames);
					}
						break;
					case "patientLastName": {
						List<String> lastNames = FilterRequestUtil.getListFromDelimitedStr(req.getPatientLastName());
						hql += " a.patientLastName IN :patientLastName ";
						parameters.put("patientLastName", lastNames);
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "insurance": {
						List<String> insuranceList = FilterRequestUtil.getListFromDelimitedStr(req.getInsurance());
						hql += " a.insurance IN :insurance";
						parameters.put("insurance", insuranceList);
					}
						break;

					default:
						break;
					}
				}
			}
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortLists(req, hql);

			} else {
				log.debug("No request found...................");
				hql += " ORDER BY a.DOS ASC";
			}
			log.info("query : {}", hql);

			collapsibleSection = session.createQuery(hql).setParameter("filterId", filterId).setProperties(parameters)
					.list();

			log.debug("collapsibleSection..........." + collapsibleSection);

			// alldata = session.createQuery(hql)
			// .setFirstResult(index)
			// .setProperties(parameters).list();

			int count = collapsibleSection.size();

			listCount.put("Count", count);
			listCount.put("data", collapsibleSection);
			log.debug("coderDashboard List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<AuditorCollapsibleSectionData> getALLInAuditRecords() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<AuditorCollapsibleSectionData> inAuditData = new ArrayList<>();
		try {
			String hql = "FROM AuditQueue WHERE status = :status";
			Query<AuditQueue> query = session.createQuery(hql, AuditQueue.class);
			query.setParameter("status", "In Audit");

			List<AuditQueue> auditQueueList = query.getResultList();
			if (auditQueueList != null && !auditQueueList.isEmpty()) {
				for (AuditQueue auditQueue : auditQueueList) {
					AuditorCollapsibleSectionData sectionData = new AuditorCollapsibleSectionData();
					sectionData.setFilterId(auditQueue.getFilterId());
					sectionData.setVisitId(auditQueue.getVisitId());
					sectionData.setPatientId(auditQueue.getPatientId());
					sectionData.setPatientName(auditQueue.getPatientName());
					sectionData.setFacilityId(auditQueue.getFacilityId());
					sectionData.setBbc(auditQueue.getBBC());
					sectionData.setFacilityAlias(auditQueue.getFacilityAlias());
					sectionData.setInsurance(auditQueue.getInsurance());
					sectionData.setDateOfService(auditQueue.getDOS());
					sectionData.setStatus(auditQueue.getStatus());
					sectionData.setMedicalRecordNumber(auditQueue.getMRN());
					sectionData.setPatientFirstName(auditQueue.getPatientFirstName());
					sectionData.setPatientLastName(auditQueue.getPatientLastName());
					sectionData.setIsLocked(auditQueue.getIsLocked());
					sectionData.setDateQueued(auditQueue.getDateAdded());
					sectionData.setUserFullName(auditQueue.getLastUpdatedByUserFullName());
					sectionData.setAssigneeUserId(auditQueue.getAssigneeUserId());
					sectionData.setAssigneeUserName(auditQueue.getAssigneeUserName());
					sectionData.setAssigneeUserFullName(auditQueue.getAssigneeUserFullName());
					inAuditData.add(sectionData);
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred while fetching records from audit_queue: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return inAuditData;
	}

	@Override
	public List<AuditorCollapsibleSectionData> getChartByStatus(ChartByStatusReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<AuditorCollapsibleSectionData> data = new ArrayList<>();
		try {
			List<String> statuses = req.getStatus();
			if (statuses != null && !statuses.isEmpty()) {
				String hql = "FROM AuditQueue WHERE status IN :statuses";
				Query<AuditQueue> query = session.createQuery(hql, AuditQueue.class);
				query.setParameter("statuses", statuses);

				List<AuditQueue> auditQueueList = query.getResultList();
				if (auditQueueList != null && !auditQueueList.isEmpty()) {
					for (AuditQueue auditQueue : auditQueueList) {
						AuditorCollapsibleSectionData sectionData = new AuditorCollapsibleSectionData();
						sectionData.setFilterId(auditQueue.getFilterId());
						sectionData.setVisitId(auditQueue.getVisitId());
						sectionData.setPatientId(auditQueue.getPatientId());
						sectionData.setPatientName(auditQueue.getPatientName());
						sectionData.setFacilityId(auditQueue.getFacilityId());
						sectionData.setBbc(auditQueue.getBBC());
						sectionData.setFacilityAlias(auditQueue.getFacilityAlias());
						sectionData.setInsurance(auditQueue.getInsurance());
						sectionData.setDateOfService(auditQueue.getDOS());
						sectionData.setStatus(auditQueue.getStatus());
						sectionData.setMedicalRecordNumber(auditQueue.getMRN());
						sectionData.setPatientFirstName(auditQueue.getPatientFirstName());
						sectionData.setPatientLastName(auditQueue.getPatientLastName());
						sectionData.setIsLocked(auditQueue.getIsLocked());
						sectionData.setDateQueued(auditQueue.getDateAdded());
						sectionData.setUserFullName(auditQueue.getLastUpdatedByUserFullName());
						sectionData.setAssigneeUserId(auditQueue.getAssigneeUserId());
						sectionData.setAssigneeUserName(auditQueue.getAssigneeUserName());
						sectionData.setAssigneeUserFullName(auditQueue.getAssigneeUserFullName());
						data.add(sectionData);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred while fetching records from chart by status: " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return data;
	}

	@Override
	public Reasons getNurseDispositionList() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Reasons nurseDisposition = null;
		try {
			String hql = "FROM Reasons WHERE role = :role AND title = :title";
			Query query = session.createQuery(hql);
			query.setParameter("role", "Nurse");
			query.setParameter("title", "Disposition");
			nurseDisposition = (Reasons) query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching all nurse disposition: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return nurseDisposition;
	}

	private void addResolution(SaveAuditDetailsReq req) throws EncodeExceptionHandler {
		Session session = sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			AuditQueue auditQueue = session.get(AuditQueue.class, req.getVisitId());
			if (auditQueue != null) {
				auditQueue.setResolution(req.getResolution());
				auditQueue.setLastUpdatedTimestamp(currentTime);
				auditQueue.setLastUpdatedByUserId(req.getUserId());
				auditQueue.setLastUpdatedByUserName(req.getUserName());
				auditQueue.setLastUpdatedByUserFullName(req.getUserFullName());
				session.update(auditQueue);
			}
		} catch (Exception e) {
			log.error("Exception occurred while saving nurse disposition: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to save nurse disposition", e);
		}
	}

	@Override
	public List<Notification> fetchNotificationsByvisitId(Long visitId) {
		Session session = this.sessionFactory.getCurrentSession();
		List<Notification> notificationList = null;

		try {
			String hql = "From Notification where visitId = :visitId AND documentType = 'SuperBill' order by notificationId DESC";

			log.debug("hql : " + hql);

			notificationList = (List<Notification>) session.createQuery(hql).setParameter("visitId", visitId).list();

		} catch (Exception e) {
			log.error("Exception occured in fetchNotificationByvisitId: {}", e.getMessage());
		}
		return notificationList;
	}

	@Override
	public PatientMedicalRecords getPatientMedicalRecord(Long patientId, Long visitId, List<String> docTypeList)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		PatientMedicalRecords record = null;
		try {
			String hql = "FROM PatientMedicalRecords a WHERE a.patientId = :patientId" + " AND a.visitId = :visitId ";
			log.info(hql);
			Query query = session.createQuery(hql);
			query.setParameter("patientId", patientId);
			query.setParameter("visitId", visitId);
//			query.setParameter("documentType", docTypeList);

			record = (PatientMedicalRecords) query.uniqueResult();
			log.debug("record={}", record);

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}

	@Override
	public void updateStatus(UpdateChartstatusReq req, String status) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			for (long visitId : req.getVisitId()) {
				String hql = "UPDATE Dashboard d SET d.status = :status, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " + "WHERE d.visitId = :visitId";
				log.info("query .............: {}", hql.toString());
				Query query = session.createQuery(hql);

				Dashboard dashboard = session.get(Dashboard.class, visitId);

				if (dashboard != null) {

					query.setParameter("status", status);
					query.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
					query.setParameter("visitId", visitId);

					int rowsAffected = query.executeUpdate();

					log.info("query .............: {}", hql);
					if (rowsAffected > 0) {
						log.info("Dashboard updated successfully with " + status + " Status");

					} else {
						log.info("No rows were affected while updating the dashboard.");
					}

				} else {
					log.info("No dashboard record found for visitId: " + visitId);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	@Override
	public Long getPatientId(Long visitId) {
		Session session = sessionFactory.getCurrentSession();
		Long patientId = 0L;
		try {
			String hql = "FROM Dashboard WHERE visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);
			List<Dashboard> records = query.list();

			if (!records.isEmpty()) {
				Dashboard record = records.get(0);

				patientId = record.getPatientId();

				log.info(BOConstants.SUCCESS);
			} else {

				log.info("No record found");
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching CMC Record from database: {}", e.getMessage());

		}
		return patientId;
	}

	@Override
	public void releaseByFilterChart(ReleaseByFilterChartReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		LocalDateTime localDateTime = LocalDateTime.now();
		Timestamp currentTimestamp = Timestamp.valueOf(localDateTime);

		String updateAuditQueueHql = "UPDATE AuditQueue d SET d.status = :status, d.isLocked = 0, "
				+ "d.lastUpdatedTimestamp = :lastUpdatedTimestamp, " + "d.lastUpdatedByUserName = :userName, "
				+ "d.lastUpdatedByUserId = :userId, " + "d.lastUpdatedByUserFullName = :fullName "
				+ "WHERE d.visitId = :visitId";

		String updateDashboardHql = "UPDATE Dashboard d SET d.status = :status, d.inAuditQueue = :inAuditQueue, "
				+ "d.lastUpdatedByUserId = :lastUpdatedByUserId, "
				+ "d.lastUpdatedByUsername = :lastUpdatedByUsername, "
				+ "d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName, "
				+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " + "WHERE d.visitId = :visitId";

		try {
			Set<Long> visitIdsToUpdate = new HashSet<>();

			// 1. From chartSelection (direct visit IDs)
			if (req.getChartSelection() != null) {
				for (Integer visitId : req.getChartSelection()) {
					visitIdsToUpdate.add(visitId.longValue());
				}
			}

			// 2. From filterSelection (via AuditQueue since Dashboard doesn't have
			// filterId)
			if (req.getFilterSelection() != null && !req.getFilterSelection().isEmpty()) {
				String filterVisitQueryStr = "SELECT d.visitId FROM AuditQueue d WHERE d.filterId IN (:filterIds) "
						+ "AND d.status IN (:statuses)";

				Query<Long> filterVisitQuery = session.createQuery(filterVisitQueryStr, Long.class);
				filterVisitQuery.setParameter("filterIds", req.getFilterSelection());
				filterVisitQuery.setParameter("statuses", Arrays.asList("Completed", "In Audit", "Ready for Audit"));
				List<Long> filterVisitIds = filterVisitQuery.getResultList();
				visitIdsToUpdate.addAll(filterVisitIds);
			}

			// 3. Final update loop
			for (Long visitId : visitIdsToUpdate) {

				// Update AuditQueue
				Query auditQuery = session.createQuery(updateAuditQueueHql);
				auditQuery.setParameter("status", "Released");
				auditQuery.setParameter("lastUpdatedTimestamp", currentTimestamp);
				auditQuery.setParameter("userName", req.getUserName());
				auditQuery.setParameter("userId", req.getUserId());
				auditQuery.setParameter("fullName", req.getUserFullName());
				auditQuery.setParameter("visitId", visitId);
				auditQuery.executeUpdate();

				// Update Dashboard
				Query dashboardQuery = session.createQuery(updateDashboardHql);
				dashboardQuery.setParameter("status", "Released");
				dashboardQuery.setParameter("inAuditQueue", false);
				dashboardQuery.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
				dashboardQuery.setParameter("lastUpdatedByUserId", req.getUserId());
				dashboardQuery.setParameter("lastUpdatedByUsername", req.getUserName());
				dashboardQuery.setParameter("lastUpdatedByUserFullName", req.getUserFullName());
				dashboardQuery.setParameter("visitId", visitId);
				dashboardQuery.executeUpdate();
				log.info("Visit ID {} status updated to Released.", visitId);
			}
		} catch (Exception e) {
			log.error("Error updating chart statuses to Released: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

	private void performWeaknessAction(SaveAuditDetailsReq req, ChartDetails existingRecord, Session session,
			Timestamp currentTime) {

		ObjectMapper objectMapper = new ObjectMapper();
		String weaknessReasonString = null;
		String icd10Code = req.getIcdData().stream().map(ICD10Data::getCode).collect(Collectors.joining(", "));

		String cptCode = req.getCptData().stream().map(CPTChartDetails::getCptCode).collect(Collectors.joining(", "));

		String modifierData = req.getCptData().stream().flatMap(cpt -> cpt.getModifier().stream())
				.map(modifier -> modifier.split(" ")[0]).collect(Collectors.joining(", "));

		String unit = req.getCptData().stream().map(cpt -> String.valueOf(cpt.getUnit()))
				.collect(Collectors.joining(", "));

		String icd10String = null;
		try {
			icd10String = objectMapper.writeValueAsString(req.getIcdData());
		} catch (JsonProcessingException e) {
			log.error("Exception occured  while getting ICD10 data JSON: " + e.getMessage());
		}

		String cptString = null;
		try {
			cptString = objectMapper.writeValueAsString(req.getCptData());
		} catch (JsonProcessingException e) {
			log.error("Exception occured while getting CPT data JSON: " + e.getMessage());
		}

		Long coderUserId = null;
		Integer creatorUserId = null;

		if (req.getUserId() != null && !req.getUserId().isEmpty()) {
			try {
				coderUserId = Long.valueOf(req.getUserId());
				creatorUserId = Integer.valueOf(req.getUserId());
			} catch (NumberFormatException e) {
				log.info("Invalid userId format: {}", req.getUserId(), e);
			}
		}

		if (existingRecord != null) {
			// Update existing record
			existingRecord.setIcdCodes(icd10String);
			existingRecord.setCptObject(cptString);
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(coderUserId);
			existingRecord.setLastUpdatedTimestamp(currentTime);
			session.update(existingRecord);

			Dashboard dashboardRecord = session.get(Dashboard.class, existingRecord.getVisitId());
			if (dashboardRecord != null) {
				dashboardRecord.setIcdCode(icd10Code);
				dashboardRecord.setCptCode(cptCode);
				dashboardRecord.setModifier(modifierData);
				dashboardRecord.setUnit(unit);
				session.update(dashboardRecord);
			} else {
				Dashboard newDashboardRecord = new Dashboard();
				newDashboardRecord.setVisitId(existingRecord.getVisitId());
				newDashboardRecord.setIcdCode(icd10Code);
				newDashboardRecord.setModifier(modifierData);
				newDashboardRecord.setUnit(unit);
				session.save(newDashboardRecord);
			}
		}
		try {
			weaknessReasonString = objectMapper.writeValueAsString(req.getWeaknessReason());
		} catch (JsonProcessingException e) {
			log.error("Exception occured : " + e.getMessage());
		}

		if (existingRecord != null) {
			// Update existing record
			existingRecord.setProviderCPTCode(req.getProviderCPTCode());
			existingRecord.setWeaknessReason(weaknessReasonString);
			existingRecord.setWeaknessNote(req.getWeaknessNote());
			existingRecord.setCoderCPTCode(req.getCoderCPTCode());
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserId(coderUserId);
			existingRecord.setLastUpdatedTimestamp(currentTime);
			session.update(existingRecord);
		} else {
			// Insert new record
			ChartDetails newRecord = new ChartDetails();
			newRecord.setPatientId(req.getPatientId());
			newRecord.setVisitId(req.getVisitId());
			newRecord.setProviderCPTCode(req.getProviderCPTCode());
			newRecord.setWeaknessReason(weaknessReasonString);
			newRecord.setWeaknessNote(req.getWeaknessNote());
			newRecord.setCoderCPTCode(req.getCoderCPTCode());
			newRecord.setCoderUserName(req.getUserName());
			newRecord.setCoderUserId(coderUserId);
			newRecord.setLastUpdatedTimestamp(currentTime);
			session.save(newRecord);
		}

		String hql = "FROM SuperbillVariance WHERE visitId = :visitId";
		Query<SuperbillVariance> query = session.createQuery(hql, SuperbillVariance.class);
		// query.setParameter("patientId", req.getPatientId());
		query.setParameter("visitId", req.getVisitId());
		SuperbillVariance existingRecords = query.uniqueResult();

		if (existingRecords != null) {
			// Update existing record
			existingRecords.setVarianceReason(weaknessReasonString);
			existingRecords.setComment(req.getWeaknessNote());
			existingRecords.setActualCptCode(req.getCoderCPTCode());
			session.update(existingRecords);
		} else {
			// Insert new record
			SuperbillVariance sb = new SuperbillVariance();
			sb.setVarianceReason(weaknessReasonString);
			sb.setComment(req.getWeaknessNote());
			sb.setActualCptCode(req.getCoderCPTCode());
			session.save(sb);
		}

		Notes userNotes = new Notes();

		String notesDescription;
		if (req.getWeaknessNote() != null && !req.getWeaknessNote().isEmpty()) {

			notesDescription = String.format("Weakness - %s - %s", req.getWeaknessReason(), req.getWeaknessNote());
		} else {
			notesDescription = String.format("Weakness - %s", req.getWeaknessReason());

		}
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole(req.getUserRole());
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFirstName() + " " + req.getUserLastName());
		userNotes.setCreatorUserId(creatorUserId);

		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);

		if (req.getUserTaggedInNotes() != null && req.getUserTaggedInNotes() == true) {
			appNotificationBO.saveWeaknessAppNotificationsAuditor(req);
		}
	}

	private void performDeficiencyAction(SaveAuditDetailsReq req, ChartDetails existingRecord, Session session,
			Timestamp currentTime) {
		ObjectMapper objectMapper = new ObjectMapper();
		String deficiencyString = null;
		try {
			deficiencyString = objectMapper.writeValueAsString(req.getDeficiencyReason());
			log.debug("deficiencyString.........." + deficiencyString);
		} catch (JsonProcessingException e) {
			log.error("Exception occured in performDeficiencyAction: " + e.getMessage());
		}

		Long coderUserId = null;
		Integer creatorUserId = null;

		if (req.getUserId() != null && !req.getUserId().isEmpty()) {
			try {
				coderUserId = Long.valueOf(req.getUserId());
				creatorUserId = Integer.valueOf(req.getUserId());
			} catch (NumberFormatException e) {
				log.info("Invalid userId format: {}", req.getUserId(), e);
			}
		}

		if (existingRecord != null) {
			existingRecord.setDeficiencyReason(deficiencyString);
			existingRecord.setDeficientProviderUserId(req.getDeficientProviderUserId());
			existingRecord.setDeficientProviderName(req.getDeficientProviderName());
			existingRecord.setCoderUserId(coderUserId);
			existingRecord.setCoderUserName(req.getUserName());
			existingRecord.setCoderUserFullName(req.getUserFullName());
			existingRecord.setLastUpdatedTimestamp(currentTime);
			existingRecord.setDeficientNote(req.getDeficientNote());
			existingRecord.setIsDeficient(1);
			existingRecord.setWasDeficient(1);
			existingRecord.setDeficiencyStartDate(currentTime);
			session.update(existingRecord);

		} else {
			ChartDetails chartdetails = new ChartDetails();
			chartdetails.setPatientId(req.getPatientId());
			chartdetails.setVisitId(req.getVisitId());
			chartdetails.setDeficiencyReason(deficiencyString);
			chartdetails.setDeficientProviderUserId(req.getDeficientProviderUserId());
			chartdetails.setDeficientProviderName(req.getDeficientProviderName());
			chartdetails.setCoderUserId(coderUserId);
			chartdetails.setCoderUserName(req.getUserName());
			chartdetails.setCoderUserFullName(req.getUserFullName());
			chartdetails.setLastUpdatedTimestamp(currentTime);
			chartdetails.setDeficientNote(req.getDeficientNote());
			chartdetails.setIsDeficient(1);
			chartdetails.setWasDeficient(1);
			chartdetails.setDeficiencyStartDate(currentTime);
			session.save(chartdetails);
		}

		Notes userNotes = new Notes();
		String notesDescription = String.format("Deficiency - %s - %s", req.getDeficiencyReason(),
				req.getDeficientNote());
		userNotes.setDescription(notesDescription);
		userNotes.setPatientId(req.getPatientId());
		userNotes.setUserRole(req.getUserRole());
		userNotes.setVisitId(req.getVisitId());
		userNotes.setCreatedTimestamp(currentTime);
		userNotes.setUserName(req.getUserName());
		userNotes.setUserFullName(req.getUserFirstName() + " " + req.getUserLastName());
		userNotes.setCreatorUserId(creatorUserId);

		session.save(userNotes);

		int noteId = userNotes.getNoteId();
		log.debug("Generated NoteId: ", noteId);

		Dashboard dashboard = null;
		try {
			dashboard = getRecordByVisitIdDashboard(req.getVisitId());
			log.debug("dashboard..........." + dashboard);
		} catch (EncodeExceptionHandler e) {
			log.error("Exception occured: " + e.getMessage());
		}

		if (dashboard != null) {
			boolean isIhealConfigMatch = dashboard.getIhealConfig() != null
					&& (dashboard.getIhealConfig().equalsIgnoreCase("OT")
							|| dashboard.getIhealConfig().equalsIgnoreCase("POS")
							|| (dashboard.getIhealConfig().equalsIgnoreCase("EMR") && dashboard.getServiceLine() != null
									&& (dashboard.getServiceLine().equalsIgnoreCase("HSP Inpatient Consult")
											|| dashboard.getServiceLine().equalsIgnoreCase("Inpatient"))));

			if (isIhealConfigMatch && req.getDeficiencyReason() != null
					&& req.getDeficiencyReason().contains("Needs addendum")) {

				updateDashboardStatusforCMC(req.getVisitId(), session, "Pending", req.getUserFullName(),
						String.valueOf(req.getUserId()), req.getUserFirstName(), req.getUserLastName(), req);
				try {
					UpdateAuditQueueStatus(req.getVisitId(), "Pending");
				} catch (EncodeExceptionHandler e) {
					log.error("Status not updated in Audit Queue table");
				}

			} else if (isIhealConfigMatch && req.getDeficiencyReason() != null
					&& !req.getDeficiencyReason().contains("Needs addendum")) {

				updateDashboardStatus(req.getVisitId(), session, "Deficiency", req.getUserFullName(),
						String.valueOf(req.getUserId()), req.getUserFirstName(), req.getUserLastName(), req);
				try {
					UpdateAuditQueueStatus(req.getVisitId(), "Deficiency");
				} catch (EncodeExceptionHandler e) {
					log.error("Status not updated in Audit Queue table");
				}

			} else if (dashboard.getServiceLine() != null && dashboard.getIhealConfig() != null
					&& !"HSP Inpatient Consult".equalsIgnoreCase(dashboard.getServiceLine())
					&& (!"OT".equalsIgnoreCase(dashboard.getIhealConfig()))
					&& (!"POS".equalsIgnoreCase(dashboard.getIhealConfig()))) {

				updateDashboardStatus(req.getVisitId(), session, "Deficiency", req.getUserFullName(),
						String.valueOf(req.getUserId()), req.getUserFirstName(), req.getUserLastName(), req);

				try {
					UpdateAuditQueueStatus(req.getVisitId(), "Deficiency");
				} catch (EncodeExceptionHandler e) {
					log.error("Status not updated in Audit Queue table");
				}

			} else {
				log.debug("default block of Deficiency");
				log.debug("visitId : " + req.getVisitId());
				log.debug("dashboard.getServiceLine() : " + dashboard.getServiceLine());
				log.debug("dashboard.getIhealConfig() : " + dashboard.getIhealConfig());

				updateDashboardStatus(req.getVisitId(), session, "Deficiency", req.getUserFullName(),
						String.valueOf(req.getUserId()), req.getUserFirstName(), req.getUserLastName(), req);

				try {
					UpdateAuditQueueStatus(req.getVisitId(), "Deficiency");
				} catch (EncodeExceptionHandler e) {
					log.error("Status not updated in Audit Queue table");
				}
			}
		}

	}

	@Override
	public Dashboard getRecordByVisitIdDashboard(long visitId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Dashboard record = null;
		try {
			String hql = "FROM Dashboard a WHERE a.visitId = :visitId";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);

			record = (Dashboard) query.uniqueResult();

			log.info("record: {}", record);

		} catch (Exception e) {
			log.error("Exception in getRecordByVisitId : " + e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return record;
	}

	private void updateDashboardStatusforCMC(long visitId, Session session, String status, String userFullName,
			String userFirstName, String userLastName, String userId, SaveAuditDetailsReq req) {
		try {
			log.debug("status........" + status);
			String hql;
			String lastStatusChangeRole = "CMC";

			switch (status.toLowerCase()) {
			case "pending":
				log.info("Status updated as Pending");
				hql = "UPDATE Dashboard d SET d.status = 'Pending', d.isLocked = 0, "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, " + "d.cmcNotes = :cmcNotes, "
						+ " d.statusChangeTimestamp = :statusChangeTimestamp, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " + "WHERE d.visitId = :visitId";
				break;
			default:
				log.error("Unknown status: {}", status);
				return;
			}

			Query query = session.createQuery(hql);
			query.setParameter("visitId", visitId);
			query.setParameter("lastStatusChangeRole", lastStatusChangeRole);
			query.setParameter("cmcNotes", req.getDeficiencyReason() + " - " + req.getDeficientNote());
			query.setParameter("statusChangeTimestamp", new Timestamp(System.currentTimeMillis()));

			if (status.toLowerCase().equalsIgnoreCase("completed")) {
				query.setParameter("lastUpdatedByUserFullName", userFullName);
				query.setParameter("userId", userId);
				query.setParameter("userName", userFullName);
				query.setParameter("userFirstName", userFirstName);
				query.setParameter("userLastName", userLastName);

			}
			log.debug("lastStatusChangeRole..........." + lastStatusChangeRole);
			query.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Status saved Successfully!");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
		} catch (Exception e) {
			log.error("Exception occured while saving status: {}", e.getMessage());
		}
	}

	private void updateDashboardStatus(long visitId, Session session, String status, String userFullName,
			String userFirstName, String userLastName, String userId, SaveAuditDetailsReq req) {

		try {
			String hql;
			String lastStatusChangeRole = "Coder";

			switch (status.toLowerCase()) {
			case "deficiency":
				hql = "UPDATE Dashboard d SET d.status = 'Deficiency', "
						+ "d.lastStatusChangeRole = :lastStatusChangeRole, "
						+ "d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp " + "WHERE d.visitId = :visitId";
				break;
			default:
				log.error("Unknown status: {}", status);
				return;
			}
			log.info(hql);
			Query query = session.createQuery(hql);

			query.setParameter("visitId", visitId);
			query.setParameter("lastStatusChangeRole", lastStatusChangeRole);

			log.debug("query :{}", query);

			log.debug("lastStatusChangeRole..........." + lastStatusChangeRole);
			query.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
			int rowsAffected = query.executeUpdate();

			if (rowsAffected > 0) {
				log.info("Status saved Successfully!");
			} else {
				log.info("No rows were affected while updating the dashboard.");
			}
		} catch (Exception e) {
			log.error("Exception occured while saving status: {}", e.getMessage());
		}
	}

	@Override
	public EncodeUsers findByUserId(Long userId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		EncodeUsers user = null;
		try {
			String hql = "FROM EncodeUsers WHERE userId = :userId";
			Query<EncodeUsers> query = session.createQuery(hql, EncodeUsers.class);
			query.setParameter("userId", userId);
			user = query.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching user details: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return user;
	}

	@Override
	public void performUnbillableAction(UpdateChartstatusReq req,String auditStatus, String role) throws EncodeExceptionHandler{
		Session session = this.sessionFactory.getCurrentSession();
		LocalDateTime localDateTime = LocalDateTime.now();
		Timestamp currentTimestamp = Timestamp.valueOf(localDateTime);
		log.info("Current Timestamp (LocalDateTime): " + currentTimestamp);

		String auditHql = "FROM AuditQueue WHERE visitId = :visitId";
		String dashboardHql = "FROM Dashboard WHERE visitId = :visitId";

		String hqlAuditUpdate = "UPDATE AuditQueue d SET d.status = :status, d.lastUpdatedTimestamp = :lastUpdatedTimestamp, "
				+ "d.lastUpdatedByUserName = :lastUpdatedByUserName, d.lastUpdatedByUserId = :lastUpdatedByUserId, "
				+ "d.auditComplete = :auditComplete, d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName "
				+ "WHERE d.visitId = :visitId";

		String hqlDashboardUpdate = "UPDATE Dashboard d SET d.status = :status, d.lastUpdatedByTimestamp = :lastUpdatedByTimestamp, "
				+ "d.lastStatusChangeRole = :lastStatusChangeRole "
				+ " d.lastUpdatedByUsername = :lastUpdatedByUsername,"
				+ " d.lastUpdatedByUserId = :lastUpdatedByUserId, "
				+ " d.lastUpdatedByUserFullName = :lastUpdatedByUserFullName"
				+ "WHERE d.visitId = :visitId";

		for (long visitId : req.getVisitId()) {
			try {
				Query<AuditQueue> auditQuery = session.createQuery(auditHql, AuditQueue.class);
				auditQuery.setParameter("visitId", visitId);
				AuditQueue existingAuditQueueRecord = auditQuery.uniqueResult();

				if (existingAuditQueueRecord != null) {
					Query query = session.createQuery(hqlAuditUpdate);
					query.setParameter("status", auditStatus);
					query.setParameter("lastUpdatedTimestamp", currentTimestamp);
					query.setParameter("lastUpdatedByUserName", req.getUserName());
					query.setParameter("lastUpdatedByUserId", req.getUserId());
					query.setParameter("lastUpdatedByUserFullName", req.getUserFullName());
					query.setParameter("visitId", visitId);
					query.setParameter("auditComplete", 0);

					int rowsAffected = query.executeUpdate();
					log.info(rowsAffected > 0 ? "Auditor Dashboard updated successfully with In Audit Status"
							: "No rows affected while updating the auditor dashboard.");
				}

				Query<Dashboard> dashboardQuery = session.createQuery(dashboardHql, Dashboard.class);
				dashboardQuery.setParameter("visitId", visitId);
				Dashboard existingDashboardRecord = dashboardQuery.uniqueResult();

				if (existingDashboardRecord != null) {
					Query query1 = session.createQuery(hqlDashboardUpdate);
					query1.setParameter("status", auditStatus);
					query1.setParameter("lastUpdatedByTimestamp", new Timestamp(System.currentTimeMillis()));
					query1.setParameter("visitId", visitId);
					query1.setParameter("lastStatusChangeRole", role);
					query1.setParameter("lastUpdatedByUserName", req.getUserName());
					query1.setParameter("lastUpdatedByUserId", req.getUserId());
					query1.setParameter("lastUpdatedByUserFullName", req.getUserFullName());

					int rowsAffected1 = query1.executeUpdate();
					log.info(rowsAffected1 > 0 ? "Status saved successfully in Dashboard!"
							: "No rows affected while updating the dashboard.");
				}

			} catch (Exception e) {
				log.error("Exception occurred: " + e.getMessage(), e);
				throw new EncodeExceptionHandler(e.getMessage());
			}
		}
	}
	
	@Override
	public void addOrRemovePinnedFilter(addOrRemovePinnedFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
	    ObjectMapper objectMapper = new ObjectMapper();
	 
	    try {
	        Long userId = Long.parseLong(req.getUserId());
	 
	        UserPreference userPreference = session.get(UserPreference.class, userId);
	 
	        if (userPreference == null) {
	            userPreference = new UserPreference();
	            userPreference.setUserId(userId);
	            userPreference.setPinnedFilterIds("[]");
	        }
	 
	        // Parse current pinned filter IDs
	        List<Integer> pinnedFilters = new ArrayList<>();
	        String pinnedFilterJson = userPreference.getPinnedFilterIds();
	 
	        if (pinnedFilterJson != null && !pinnedFilterJson.isEmpty()) {
	            pinnedFilters = objectMapper.readValue(pinnedFilterJson, new TypeReference<List<Integer>>() {});
	        }
	 
	        // Add filter if pinFilter is > 0 and not already present
	        if (req.getPinFilter() > 0 && !pinnedFilters.contains(req.getPinFilter())) {
	            pinnedFilters.add(req.getPinFilter());
	        }
	 
	        // Remove filter if unpinFilter is > 0 and exists
	        if (req.getUnpinFilter() > 0) {
	            pinnedFilters.removeIf(filterId -> filterId == req.getUnpinFilter());
	        }
	 
	        // Convert list back to JSON and update entity
	        String updatedJson = objectMapper.writeValueAsString(pinnedFilters);
	        userPreference.setPinnedFilterIds(updatedJson);
	 
	        session.saveOrUpdate(userPreference);
		} catch (Exception e) {
			log.error("Error add or Remove Pinned Filter: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}

}
