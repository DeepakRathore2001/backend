package com.healogics.encode.dao.impl;

import static com.healogics.encode.constants.DAOConstants.HISTORY_SIZE;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.HistoryTimelineDAO;
import com.healogics.encode.dto.HistoryTimelineData;
import com.healogics.encode.entity.HistoryTimeline;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class HistoryTimelineDAOImpl implements HistoryTimelineDAO {
	private final Logger log = LoggerFactory.getLogger(HistoryTimelineDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public HistoryTimelineDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public List<HistoryTimeline> getTimelineListByVisitId(int index, long visitId)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<HistoryTimeline> historyList = new ArrayList<>();
		try {
			String hql = "FROM HistoryTimeline WHERE visitId = :visitId "
					+ " order by lastUpdatedTimestamp desc";

			log.info("query : {}", hql);
			historyList = session.createQuery(hql).setParameter("visitId", visitId)
					.setFirstResult(index).setMaxResults(HISTORY_SIZE).list();
		} catch (Exception e) {
			log.error("Exception occured in getTimelineListByVisitId: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return historyList;
	}
	
	@Override
	public Long getHistoryCount(long visitId)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;

		try {
			String hql = "SELECT count(*) FROM HistoryTimeline a WHERE a.visitId = :visitId";

			log.info("query1 : {}", hql);

			totalCount = (Long) session.createQuery(hql).setParameter("visitId",
					visitId).uniqueResult();
			log.debug("totalCount :" + totalCount);
		} catch (Exception e) {
			log.error("Exception occured getHistoryCount : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}
	
	@Override
	public void saveHistoryTimeline(HistoryTimelineData history)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		log.info("history : " +history);

		try {
			HistoryTimeline timeline = new HistoryTimeline();
			timeline.setBluebookId(history.getBluebookId());
			timeline.setChartNotes(history.getChartDescription());
			timeline.setChartStatus(history.getChartStatus());
			timeline.setDateOfService(history.getDateOfService());
			timeline.setFacilityId(""+ history.getFacilityId());
			timeline.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
			timeline.setLastUpdatedUserFullname(history.getUserFullName());
			timeline.setLastUpdatedUserid(history.getUserId());
			timeline.setLastUpdatedUsername(history.getUserName());
			timeline.setLastUpdatedUserRole(history.getUserRole());
			timeline.setPatientId(history.getPatientId());
			timeline.setPatientName(history.getPatientName());
			timeline.setVisitId(history.getVisitId());
			
			log.info("timeline : " +timeline);
			
			session.save(timeline);
		} catch (Exception e) {
			log.error("Exception occured in saveHistoryTimeline : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
	}
}
