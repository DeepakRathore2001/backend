package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.AuditHistoryDAO;
import com.healogics.encode.dto.AuditHistoryData;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.entity.AuditHistory;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.Notes;
import com.healogics.encode.entity.SuperBillHistory;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class AuditHistoryDAOImpl implements AuditHistoryDAO {
	
	private final Logger log = LoggerFactory.getLogger(AuditHistoryDAOImpl.class);
	
	private final SessionFactory sessionFactory;

	@Autowired
	public AuditHistoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveAuditHistory(AuditHistoryData data) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		log.info("data : " +data);
		try {
			String hql = "FROM AuditHistory where visitId = :visitId";

			String hql1 = "FROM Dashboard where visitId = :visitId";

			AuditHistory dashboard = session.createQuery(hql, AuditHistory.class)
					.setParameter("visitId", data.getVisitId()).setMaxResults(1).uniqueResult();

			Dashboard dashboard1 = session.createQuery(hql1, Dashboard.class).setParameter("visitId", data.getVisitId())
					.setMaxResults(1).uniqueResult();
			
			if(dashboard != null) {
				dashboard.setCoderName(dashboard1.getCompletedCoderUser());
				dashboard.setBillingClientAbbr(data.getBillingClientAbbr());
				dashboard.setAccountNumber(data.getAccountNumber());
				dashboard.setProvider(data.getProvider());
				dashboard.setSendingFacility(data.getSendingFacility());
				dashboard.setDos(data.getDos());
				dashboard.setChartCodes(data.getChartCodes());
				dashboard.setAuditNotes(data.getAuditNotes());
				dashboard.setCoderUserName(dashboard1.getCompletedCoderUser());
				dashboard.setCoderUserId(Integer.parseInt(dashboard1.getCompletedCoderUserId()));
				
				dashboard.setCodingError(data.isCodingError());
				dashboard.setAuditCompleted(data.isAuditCompleted());
				dashboard.setFilterName(data.getFilterName());
				
				log.info("history : " +dashboard);
				
				session.update(dashboard);
				
				if (data.getAuditNotes() != null && !data.getAuditNotes().isEmpty()) {
		            updateNotetable(data);
		        }else{
		        	log.debug("No need to update Notes table");
		        }	
				
			} else {
				AuditHistory history = new AuditHistory();
				
				history.setVisitId(data.getVisitId());
				history.setCoderName(dashboard1.getCompletedCoderUser());
				history.setBillingClientAbbr(data.getBillingClientAbbr());
				history.setAccountNumber(data.getAccountNumber());
				history.setProvider(data.getProvider());
				history.setSendingFacility(data.getSendingFacility());
				history.setDos(data.getDos());
				history.setChartCodes(data.getChartCodes());
				history.setAuditNotes(data.getAuditNotes());
				history.setCoderUserName(dashboard1.getCompletedCoderUser());
				history.setCoderUserId(Integer.parseInt(dashboard1.getCompletedCoderUserId()));
				
				history.setCodingError(data.isCodingError());
				history.setAuditCompleted(data.isAuditCompleted());
				history.setFilterName(data.getFilterName());
				
				log.info("history : " +history);
				
				session.save(history);
				
			}
			if (data.getAuditNotes() != null && !data.getAuditNotes().isEmpty()) {
	            updateNotetable(data);
	        }else{
	        	log.debug("No need to update Notes table");
	        }
			
		} catch (Exception e) {
			log.error("Exception occured in saveHistoryTimeline : {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		
	}
	
	private void updateNotetable(AuditHistoryData data) {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);

		String hql1 = "SELECT a.patientId, a.lastUpdatedByUserFullName, a.lastUpdatedByUserName "
				+ "FROM AuditQueue a"
				+ " WHERE a.visitId = :visitId AND a.lastUpdatedByUserId =:lastUpdatedByUserId";
		
		Query query = session.createQuery(hql1);
		query.setParameter("lastUpdatedByUserId", String.valueOf(data.getCoderUserId()));
		query.setParameter("visitId", data.getVisitId());
		Object[] record = (Object[]) query.uniqueResult();
		
		if (record != null) {
			long patientId = (Long) record[0];
			String userFullName = (String) record[1];
			String userName = (String) record[2];

			String chcekNoteHql = "FROM Notes n WHERE n.visitId =:visitId "
					+ "AND n.creatorUserId =:creatorUserId ORDER BY n.creatorUserId DESC ";
			Query checkNoteQuery = session.createQuery(chcekNoteHql);

			checkNoteQuery.setParameter("visitId", data.getVisitId());
			checkNoteQuery.setParameter("creatorUserId", data.getCoderUserId());

			Notes existingNotes = (Notes) checkNoteQuery.uniqueResult();

			if (existingNotes != null) {
				String existingNote = existingNotes.getDescription();
				String newNotes = data.getAuditNotes();
				log.debug("newNotes======"+newNotes);
				existingNotes.setDescription(newNotes);
				existingNotes.setCreatedTimestamp(currentTime);
				session.update(existingNotes);
			} else {
				Notes userNotes = new Notes();
				// String notesDescription = String.format("Requested Guidance -
				// %s - %s",
				// req.getEscalationReason(), req.getEscalationNote());
				userNotes.setDescription(data.getAuditNotes());
				userNotes.setPatientId(patientId);
				userNotes.setUserRole("Auditor");
				userNotes.setVisitId(data.getVisitId());
				userNotes.setCreatedTimestamp(currentTime);
				userNotes.setUserName(userName);
				userNotes.setUserFullName(userFullName);
				userNotes.setCreatorUserId(data.getCoderUserId());

				session.save(userNotes);

				int noteId = userNotes.getNoteId();
				log.debug("Generated NoteId: ", noteId);
			}
		}
	}

	@Override
	public List<SuperBillHistory> getBillHistoryData(BillHistoryReq req,
			Timestamp encodeStartTimestamp) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<SuperBillHistory> billHistoryDetails = new ArrayList<>();
		try {
			String hql = "FROM SuperBillHistory s WHERE s.patientId = :patientId "
					+ "AND s.patientDOS >= :encodeStartTimestamp";
			
			log.debug("Executing HQl : {}", hql);
			
			billHistoryDetails = session.createQuery(hql, SuperBillHistory.class)
					.setParameter("patientId", Long.parseLong(req.getPatientId()))
					.setParameter("encodeStartTimestamp", encodeStartTimestamp).list();
			
		} catch (Exception e) {
			log.error("Exception occurred while fetching previous bill history details: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}

		return billHistoryDetails;
	}
}

