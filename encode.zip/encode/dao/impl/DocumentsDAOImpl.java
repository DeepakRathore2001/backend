package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.DocumentsDAO;
import com.healogics.encode.dto.DBDocumentContentRes;
import com.healogics.encode.dto.DBDocumentListReq;
import com.healogics.encode.dto.DBDocumentListRes;
import com.healogics.encode.dto.Document;
import com.healogics.encode.dto.DocumentDeleteReq;
import com.healogics.encode.dto.DocumentDeleteRes;
import com.healogics.encode.dto.DocumentsListReq;
import com.healogics.encode.dto.IHealCustomScanListReq;
import com.healogics.encode.dto.IHealDebridementRes;
import com.healogics.encode.dto.IHealProgressNotesListGetRes;
import com.healogics.encode.dto.IHealWoundAssessmentListGetResponse;
import com.healogics.encode.dto.IHealWoundListGetRes;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.exception.EncodeExceptionHandler;

import static com.healogics.encode.constants.DAOConstants.ERRORCODE;
import static com.healogics.encode.constants.DAOConstants.ERRORMESSAGE;

@Repository
@Transactional
public class DocumentsDAOImpl implements DocumentsDAO {

	private final Logger log = LoggerFactory.getLogger(DocumentsDAOImpl.class);

	private final SessionFactory sessionFactory;

	private final Environment env;

	private final RestTemplate restTemplate;

	@Autowired
	public DocumentsDAOImpl(SessionFactory sessionFactory, Environment env, RestTemplate restTemplate) {
		this.sessionFactory = sessionFactory;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')), tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	@Override
	public IHealProgressNotesListGetRes getProgressNotesLoad(DocumentsListReq req) {
		IHealProgressNotesListGetRes progressNotesListRes = null;

		String url = env.getProperty(BOConstants.IHEAL_PROGRESSNOTES_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());

		try {
			log.info("IHeal ProgressNotesListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealProgressNotesListGetRes> sresponse = restTemplate.exchange(url, HttpMethod.POST,
					request, IHealProgressNotesListGetRes.class);
			log.info("IHeal ProgressNotesListGet URL post Completed ");
			log.debug("iHeal ProgressNotesListGet Response : {}", sresponse.getBody());
			progressNotesListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in ProgressNotesListGet API - ", e);
			progressNotesListRes = new IHealProgressNotesListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			progressNotesListRes.setErrorCode(errorResponse.get(ERRORCODE));
			progressNotesListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in ProgressNotesListGet API: ", e);
			progressNotesListRes = new IHealProgressNotesListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			progressNotesListRes.setErrorCode(errorResponse.get(ERRORCODE));
			progressNotesListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return progressNotesListRes;
	}

	@Override
	public IHealWoundListGetRes getWoundList(DocumentsListReq req) {
		IHealWoundListGetRes res = null;

		String url = env.getProperty(BOConstants.IHEAL_WOUND_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq.setActiveOnly("true");

		try {
			log.info("IHeal WoundList URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealWoundListGetRes> sresponse = restTemplate.exchange(url, HttpMethod.POST, request,
					IHealWoundListGetRes.class);
			log.info("IHeal WoundList URL post Completed ");
			log.debug("iHeal WoundList Response : {}", sresponse.getBody());
			res = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in WoundList API - ", e);
			res = new IHealWoundListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in WoundList API: ", e);
			res = new IHealWoundListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return res;
	}

	@Override
	public IHealWoundAssessmentListGetResponse getWoundAssessmentLoad(int entity, DocumentsListReq req) {
		IHealWoundAssessmentListGetResponse res = null;

		String startDateString = "";
		String endDateString = "";
		if (req.getStartDate() != null && req.getEndDate() != null && !req.getStartDate().isEmpty()
				&& !req.getEndDate().isEmpty()) {
			startDateString = req.getStartDate();
			endDateString = req.getEndDate();
		} else {
			startDateString = "";
			endDateString = "";
		}
		log.debug("WoundAssessmentList startDateString:   " + startDateString);
		log.debug("WoundAssessmentList endDateString:   " + endDateString);

		String url = env.getProperty(BOConstants.IHEAL_WOUND_ASSESSMENT_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		// customScanReq.setWoundDocumentEntityId(entity + "");
		customScanReq.setWoundDocumentEntityId(req.getWoundDocumentEntityId());
		customScanReq.setStartDate(startDateString);
		customScanReq.setEndDate(endDateString);

		try {
			log.info("IHeal WoundAssessmentList URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealWoundAssessmentListGetResponse> sresponse = restTemplate.exchange(url, HttpMethod.POST,
					request, IHealWoundAssessmentListGetResponse.class);
			log.info("IHeal WoundAssessmentList URL post Completed ");
			log.debug("iHeal WoundAssessmentList Response : {}", sresponse.getBody());
			res = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in WoundAssessmentList API - ", e);
			res = new IHealWoundAssessmentListGetResponse();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in WoundAssessmentList API: ", e);
			res = new IHealWoundAssessmentListGetResponse();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return res;
	}

	@Override
	public IHealDebridementRes getDebridementLoad(DocumentsListReq req, int id) {
		IHealDebridementRes res = null;

		String url = env.getProperty(BOConstants.IHEAL_DEBRIDEMENTS_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq.setConditionDocumentEntityId(req.getWoundDocumentEntityId());

		try {
			log.info("IHeal DebridementsList URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealDebridementRes> sresponse = restTemplate.exchange(url, HttpMethod.POST, request,
					IHealDebridementRes.class);
			log.info("IHeal DebridementsList URL post Completed ");
			log.debug("iHeal DebridementsList Response : {}", sresponse.getBody());
			res = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in DebridementsList API - ", e);
			res = new IHealDebridementRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in DebridementsList API: ", e);
			res = new IHealDebridementRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return res;
	}

	@Override
	public DBDocumentListRes getDBDocumentList(DBDocumentListReq req) {
		Session session = sessionFactory.getCurrentSession();
		DBDocumentListRes res = new DBDocumentListRes();

		try {
			String hql = "SELECT documentType, documentSource,receivedTimestamp,"
					+ "isDocumentUpdated,lastUpdatedTimestamp,documentName,documentEntityId,documentId "
					+ " FROM PatientMedicalRecords"
					+ " WHERE patientId = :patientId AND visitId = :visitId ORDER BY receivedTimestamp asc";

			Query query = session.createQuery(hql);
			query.setParameter("patientId", req.getPatientId());
			query.setParameter("visitId", req.getVisitId());
			List<Object[]> records = query.list();

			log.info("record : {}", records);
			List<Document> documents = new ArrayList<>();
			
			Map<String, Integer> docNameMap = new HashMap<>();

			for (Object[] record : records) {
				log.debug("Record: {}",record);
				Document doc = new Document();
				doc.setDocumentType((String) record[0]);
				log.debug("setDocumentType: {}",record[0]);
				doc.setDocumentSource((String) record[1]);
				log.debug("setDocumentSource: {}",record[1]);
				doc.setReceivedTimestamp((Timestamp) record[2]);
				log.debug("setReceivedTimestamp: {}",record[2]);
				doc.setIsDocumentUpdated((Integer) record[3]);
				log.debug("setIsDocumentUpdated: {}",record[3]);
				doc.setLastUpdatedTimestamp((Timestamp) record[4]);
				log.debug("setLastUpdatedTimestamp: {}",record[4]);
				String documentName = (String) record[5];
				log.debug("documentName: {}",record[5]);
				if (documentName != null && !documentName.isEmpty()) {
					String[] docNameArr = documentName.split("\\.");
					String docName;
					String docExt;
					if(docNameArr.length > 1) {
						docName = docNameArr[0];
						docExt = docNameArr[1];
					}else {
						docName = documentName;
						docExt = "pdf";
					}
				
						docName = docName.toUpperCase();
						
						if (docNameMap.containsKey(docName)) {
							Integer count = docNameMap.get(docName);
							count = count + 1;
							docNameMap.put(docName, count);
							
							doc.setDocumentName(docName + "_"
									+ count + "." + docExt);
						} else {
							docNameMap.put(docName, 1);

							//Remove _1 for first document per doc type
							doc.setDocumentName(docName
									+ "." + docExt);
						}
				}
				log.debug("setDocumentName: {}",doc.getDocumentName());
				doc.setDocumentEntityId((Long) record[6]);
				log.debug("setDocumentEntityId: {}",record[6]);
				doc.setDocumentId((String) record[7]);
				log.debug("setDocumentId: {}",record[7]);
				doc.setDocumentContent("");
				documents.add(doc);
			}

			res.setPatientId(req.getPatientId());
			res.setVisitId(req.getVisitId());
			res.setDocuments(documents);
			log.debug("GetDocumentList Res: {}",res.toString());
			if (!documents.isEmpty()) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}

		} catch (Exception e) {
			log.error("Exception occurred while fetching document list from database: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}

		return res;
	}

	@Override
	public DBDocumentContentRes getDBDocumentContent(DBDocumentListReq req) {
		Session session = sessionFactory.getCurrentSession();
		DBDocumentContentRes res = new DBDocumentContentRes();
		try {
			String hql = "FROM PatientMedicalRecords WHERE patientId = :patientId"
					+ " AND visitId = :visitId AND documentType = :documentType"
					+ " AND documentId = :documentId";

			Query query = session.createQuery(hql);
			query.setParameter("patientId", req.getPatientId());
			query.setParameter("visitId", req.getVisitId());
			query.setParameter("documentType", req.getDocumentType());
			query.setParameter("documentId", req.getDocumentId());

			List<PatientMedicalRecords> records = query.list();

			res.setPatientId(req.getPatientId());
			res.setVisitId(req.getVisitId());

			if (!records.isEmpty()) {
				PatientMedicalRecords record = records.get(0);
				Document doc = new Document();

				doc.setDocumentType(record.getDocumentType());
				doc.setDocumentContent(record.getDocumentContent());
				doc.setDocumentName(record.getDocumentName());

				res.setDocument(doc);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setDocument(null);
				res.setResponseCode("1");
				res.setResponseMessage("No document found");
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching document content from database: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

@Override
	public DocumentDeleteRes deleteDBDocumentList(DocumentDeleteReq req) {
		Session session = sessionFactory.getCurrentSession();
		DocumentDeleteRes response = new DocumentDeleteRes();
		try {

			String hql = "DELETE FROM PatientMedicalRecords WHERE visitId = :visitId "
					+ "AND documentType IN (:documentNames) AND patientId = :patientId "
					+ "AND documentId IN (:documentIds)";
			Query query = session.createQuery(hql);
			query.setParameter("visitId", req.getVisitId());
			query.setParameterList("documentNames", req.getDocumentType());
			query.setParameter("patientId", req.getPatientId());
			query.setParameterList("documentIds", req.getDocumentId());
			int result = query.executeUpdate();
			

			if (result > 0) {
				response.setResponseCode("0");
				response.setResponseMessage("Documents deleted successfully");
			} else {
				response.setResponseCode("0");
				response.setResponseMessage("No documents found to delete");
			}
		} catch (Exception e) {
			log.error("Exception occurred while deleting documents: {}", e.getMessage());
			response.setResponseCode("500");
			response.setResponseMessage("Internal server error: " + e.getMessage());
		}
		return response;
	}
}
