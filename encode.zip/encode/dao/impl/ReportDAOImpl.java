package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.text.Collator;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.hibernate.query.Query;
import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.ReportDAO;
import com.healogics.encode.dto.CoderProductivityReportData;
import com.healogics.encode.dto.CoderProductivityReportReq;
import com.healogics.encode.dto.DrillDownMissingChartObj;
import com.healogics.encode.dto.DrillDownMissingChartReportRes;
import com.healogics.encode.dto.EncounterMonthlyReviewData;
import com.healogics.encode.dto.EncounterUnderReviewCount;
import com.healogics.encode.dto.EncounterUnderReviewData;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.GuidanceReportReq;
import com.healogics.encode.dto.MissingChartFilter;
import com.healogics.encode.dto.MissingChartFilterOptionsRes;
import com.healogics.encode.dto.NurseAuditNotesReportData;
import com.healogics.encode.dto.NurseAuditNotesReportReq;
import com.healogics.encode.dto.ReconReportData;
import com.healogics.encode.dto.ReconReportFilter;
import com.healogics.encode.dto.ReconReportReq;
import com.healogics.encode.dto.ReportFilterReq;
import com.healogics.encode.dto.SuperbillVarianceCount;
import com.healogics.encode.dto.SuperbillVarianceReportData;
import com.healogics.encode.dto.UnderReviewFilter;
import com.healogics.encode.dto.WeeklyIncompleteReportData;
import com.healogics.encode.dto.ecWSentReportData;
import com.healogics.encode.dto.ecWSentReportReq;
import com.healogics.encode.entity.AuditHistory;
import com.healogics.encode.entity.CoderProductivityReport;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncounterNeedingGuidanceReport;
import com.healogics.encode.entity.MonthlyChargeSummaryProcedureReport;
import com.healogics.encode.entity.NurseAuditNotesReport;
import com.healogics.encode.entity.SuperbillVariance;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.util.FilterRequestUtil;

@Repository
@Transactional
public class ReportDAOImpl implements ReportDAO {

	private static final int PAGE_SIZE = 0;

	private final Logger log = LoggerFactory.getLogger(ReportDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public ReportDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public long getReconreportDataCount(ReconReportReq req) throws EncodeExceptionHandler {
		long totalRecords = 0;
		Map<String, Object> param = new HashMap<>();
		try {
			StringBuilder hql = new StringBuilder(
					"SELECT COUNT(r) FROM ReconReport r left join ChartDetails cd on(r.visitId = cd.visitId) WHERE 1=1 AND r.patientDos BETWEEN :startDate AND :endDate");

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND (r.snfLocationBBC IN :bluebookIds)");
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND r.providerName IN :providerNames");
			}
			if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
				hql.append(" AND r.patientName IN :patientNames");
			}
			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				List<Long> visitIds = req.getVisitIdList().stream().map(Long::valueOf).collect(Collectors.toList());
				hql.append(" AND r.visitId IN :visitIds");
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND r.ihealConfig IN :locationTypeList");
			}
			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
				hql.append(" AND r.facilityType IN :facilityTypeList");
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				hql.append(" AND r.status IN :status");
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND r.providerId IN :providerIds");
			}
			if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
				hql.append(" AND r.facilityId IN :facilityIds");
			}
			if (req.getServiceLineList() != null && !req.getServiceLineList().isEmpty()) {
				hql.append(" AND r.serviceLine IN :serviceLine");
			}
			if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
				hql.append(" AND r.team IN :codingTeamList");
			}
			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				hql.append(" AND r.coderUserFullname IN :coderFullnameList");
			}
			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				hql.append(" AND (");
				for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
					hql.append("r.deficiencyReason like :deficiencyReason" + i);
					if (i < req.getDeficiencyReason().size() - 1) {
						hql.append(" OR ");
					}
					param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
				}
				hql.append(")");
			}
			if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
				hql.append(" AND r.pendingReason IN :pendingReason");
			}

			Query<Long> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Long.class);
			query.setParameter("startDate", req.getStartDate());
			query.setParameter("endDate", req.getEndDate());
			query.setProperties(param);

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query.setParameterList("providerNames", req.getProviderNameList());
			}
			if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
				query.setParameterList("patientNames", req.getPatientNameList());
			}
			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				// Set the converted Long list for visitIdList
				List<Long> visitIds = req.getVisitIdList().stream().map(Long::valueOf) // Convert each String to Long
						.collect(Collectors.toList());
				query.setParameterList("visitIds", visitIds);
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query.setParameterList("locationTypeList", req.getLocationTypeList());
			}
			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
				query.setParameterList("facilityTypeList", req.getFacilityTypeList());
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				query.setParameterList("status", req.getStatus());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				query.setParameterList("providerIds", req.getProviderIdList());
			}
			if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
				query.setParameterList("facilityIds", req.getFacilityIdList());
			}
			if (req.getServiceLineList() != null && !req.getServiceLineList().isEmpty()) {
				query.setParameterList("serviceLine", req.getServiceLineList());
			}
			if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
				query.setParameterList("codingTeamList", req.getCodingTeamList());
			}
			if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
				query.setParameterList("pendingReason", req.getPendingReason());
			}
			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				query.setParameterList("coderFullnameList", req.getCoderFullnameList());
			}

			totalRecords = query.getSingleResult();
		} catch (Exception e) {
			log.error("Exception occurred while fetching reconciliation report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch reconciliation report", e);
		}
		return totalRecords;
	}

//	@Override
//	public List<ReconReportRes> getReconciliationReport(ReconReportReq req) throws EncodeExceptionHandler {
//		List<ReconReportRes> reportList = new ArrayList<>();
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//		try {
//
//			StringBuilder hql = new StringBuilder("SELECT r.visitId, r.bluebookId, r.facilityType, r.facilityId, "
//					+ "r.medicalRecordNumber, r.patientDos, r.patientName, r.status, " + "r.providerName, r.providerId "
//					+ "FROM ReconReport r WHERE r.patientDos BETWEEN :startDate AND :endDate");
//
//			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
//				hql.append(" AND r.bluebookId IN :bluebookIds");
//			}
//			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
//				hql.append(" AND r.providerName IN :providerNames");
//			}
//			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
//				hql.append(
//						" AND CASE WHEN r.facilityType = 'EMR' THEN 'i-heal' ELSE 'non-i-heal' END IN :facilityTypes");
//			}
//			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
//				hql.append(" AND r.status IN :status");
//			}
//
//			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
//			query.setParameter("startDate", req.getStartDate());
//			query.setParameter("endDate", req.getEndDate());
//
//			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
//				query.setParameterList("bluebookIds", req.getBbcList());
//			}
//			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
//				query.setParameterList("providerNames", req.getProviderNameList());
//			}
//			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
//				query.setParameterList("facilityTypes", req.getFacilityTypeList());
//			}
//			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
//				query.setParameterList("status", req.getStatus());
//			}
//
//			List<Object[]> results = query.list();
//
//			reportList = results.stream().map(result -> {
//				ReconReportRes res = new ReconReportRes();
//				res.setVisitId((Long) result[0]);
//				res.setBluebookId((String) result[1]);
//				res.setFacilityType((String) result[2]);
//				res.setFacilityId((Integer) result[3]);
//				res.setMedicalRecordNumber((String) result[4]);
//				Date patientDos = (Date) result[5];
//				res.setPatientDos(dateFormat.format(patientDos));
//				res.setPatientName((String) result[6]);
//				res.setStatus((String) result[7]);
//				res.setProviderName((String) result[8]);
//				res.setProviderId((String) result[9]);
//				return res;
//			}).collect(Collectors.toList());
//
//		} catch (Exception e) {
//			log.error("Exception occurred while fetching reconciliation report: {}", e.getMessage());
//			throw new EncodeExceptionHandler("Failed to fetch reconciliation report", e);
//		}
//		return reportList;
//	}

	@Override
	public List<ReconReportData> getReconciliationReport(ReconReportReq req, int pazeSize, int index,
			boolean isPagination) throws EncodeExceptionHandler {
		List<ReconReportData> reportList = new ArrayList<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		Map<String, Object> param = new HashMap<>();
		// Mapping sortBy values to actual column names
		Map<String, String> sortColumnMapping = new HashMap<>();
		sortColumnMapping.put("bluebookId", "r.snfLocationBBC");
		sortColumnMapping.put("visitId", "r.visitId");
		sortColumnMapping.put("patientDos", "r.patientDos");
		sortColumnMapping.put("patientName", "r.patientName");
		sortColumnMapping.put("status", "r.status");
		sortColumnMapping.put("serviceLine", "r.serviceLine");
		sortColumnMapping.put("codingTeam", "r.team");
		sortColumnMapping.put("deficiencyReason", "r.deficiencyReason");
		sortColumnMapping.put("pendingReason", "r.pendingReason");
		sortColumnMapping.put("providerName", "r.providerName");
		sortColumnMapping.put("coderFullname", "r.coderUserFullname");

		try {
			// Fetch min and max dates if either startDate or endDate is null
			if (startDate == null || endDate == null) {
				StringBuilder dateQuery = new StringBuilder(
						"SELECT MIN(r.patientDos), MAX(r.patientDos) FROM ReconReport r WHERE 1=1");
				if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
					dateQuery.append(" AND (r.snfLocationBBC IN :bluebookIds)");
				}
				if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
					dateQuery.append(" AND r.providerName IN :providerNames");
				}
				if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
					dateQuery.append(" AND r.ihealConfig IN :locationTypeList");
				}
				if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
					dateQuery.append(" AND r.facilityType IN :facilityTypeList");
				}
				if (req.getStatus() != null && !req.getStatus().isEmpty()) {
					dateQuery.append(" AND r.status IN :status");
				}
				if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
					dateQuery.append(" AND r.providerId IN :providerIds");
				}
				if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
					dateQuery.append(" AND r.facilityId IN :facilityIds");
				}
				if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
					dateQuery.append(" AND r.team IN :codingTeamList");
				}
				if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
					dateQuery.append(" AND r.coderUserFullname IN :coderFullnameList");
				}
				if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
					dateQuery.append(" AND (");
					for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
						dateQuery.append("r.deficiencyReason like :deficiencyReason" + i);
						if (i < req.getDeficiencyReason().size() - 1) {
							dateQuery.append(" OR ");
						}
						param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
					}
					dateQuery.append(")");
				}
				if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
					dateQuery.append(" AND r.pendingReason IN :pendingReason");
				}

				log.debug("query : ", dateQuery);
				Query<Object[]> dateQueryResult = sessionFactory.getCurrentSession().createQuery(dateQuery.toString(),
						Object[].class);
				setCommonParameters(dateQueryResult, req);
				List<Object[]> dateResults = dateQueryResult.list();
				if (!dateResults.isEmpty()) {
					Object[] dateRange = dateResults.get(0);
					if (startDate == null && dateRange[0] != null) {
						startDate = (Date) dateRange[0];
					}
					if (endDate == null && dateRange[1] != null) {
						endDate = (Date) dateRange[1];
					}
				}
			}

			// main HQL query
			StringBuilder hql = new StringBuilder("SELECT r.visitId, r.snfLocationBBC, r.ihealConfig, r.facilityId, "
					+ "r.medicalRecordNumber, r.patientDos, r.patientName, r.status, r.providerName, r.providerId, r.serviceLine, r.team, r.deficiencyReason, r.pendingReason, r.coderUserId, r.coderUserFullname "
					+ "FROM ReconReport r WHERE (r.patientDos BETWEEN :startDate AND :endDate)");

			// conditions for filters
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND (r.snfLocationBBC IN :bluebookIds)");
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND r.providerName IN :providerNames");
			}
			if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
				hql.append(" AND r.patientName IN :patientNames");
			}
			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				List<Long> visitIds = req.getVisitIdList().stream().map(Long::valueOf).collect(Collectors.toList());
				hql.append(" AND r.visitId IN :visitIds");
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND r.ihealConfig IN :locationTypeList");
			}
			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
				hql.append(" AND r.facilityType IN :facilityTypeList");
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				hql.append(" AND r.status IN :status");
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND r.providerId IN :providerIds");
			}
			if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
				hql.append(" AND r.facilityId IN :facilityIds");
			}
			if (req.getServiceLineList() != null && !req.getServiceLineList().isEmpty()) {
				hql.append(" AND r.serviceLine IN :serviceLine");
			}
			if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
				hql.append(" AND r.team IN :codingTeamList");
			}
			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				hql.append(" AND r.coderUserFullname IN :coderFullnameList");
			}
//			if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
//				hql.append(" AND r.pendingReason IN :pendReason");
//				}
			if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
				hql.append(" AND (");
				for (int i = 0; i < req.getPendingReason().size(); i++) {
					hql.append("r.pendingReason =:pendingReason" + i);
					if (i < req.getPendingReason().size() - 1) {
						hql.append(" OR ");
					}
					param.put("pendingReason" + i, req.getPendingReason().get(i));
				}
				hql.append(")");
			}
			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				hql.append(" AND (");
				for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
					hql.append("r.deficiencyReason like :deficiencyReason" + i);
					if (i < req.getDeficiencyReason().size() - 1) {
						hql.append(" OR ");
					}
					param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
				}
				hql.append(")");
			}

			// sorting logic
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				if ("bluebookId".equals(req.getSortBy())) {
					// Skip adding sorting in the query for bluebookId
				} else {
					String sortByColumn = sortColumnMapping.get(req.getSortBy());
					if (sortByColumn != null) {
						hql.append(" ORDER BY ").append(sortByColumn);
						if (req.getOrder() == 0) {
							hql.append(" ASC");
						} else {
							hql.append(" DESC");
						}
					}
				}
			}
			log.debug("hql=== " + hql);
			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);

//			if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
//				query.setParameterList("pendReason", req.getPendingReason());
//			}
//			
			query.setParameter("startDate", startDate);
			query.setParameter("endDate", endDate);
			setCommonParameters(query, req);
			query.setProperties(param);

			log.debug("result: {}", query);
			// converted visitIdList
			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				List<Long> visitIds = req.getVisitIdList().stream().map(Long::valueOf).collect(Collectors.toList());
				query.setParameterList("visitIds", visitIds);
			}

			if (isPagination) {
				query.setFirstResult(index);
				query.setMaxResults(pazeSize);
			}

			// Fetch results
			List<Object[]> results = query.list();
			reportList = results.stream().map(result -> {
				/*
				 * String childBbc = null; String hql1 =
				 * "Select c.childBluebookId FROM ChartDetails c where c.visitId =:visitId";
				 * Query query1 = sessionFactory.getCurrentSession().createQuery(hql1);
				 * query1.setParameter("visitId", (Long) result[0]); childBbc = (String)
				 * query1.uniqueResult(); if (childBbc != null && !childBbc.isEmpty()) {
				 * res.setBluebookId(childBbc); } else { res.setBluebookId((String) result[1]);
				 * }
				 */

				ReconReportData res = new ReconReportData();
				res.setVisitId((Long) result[0]);
				res.setBluebookId((String) result[1]);
				res.setFacilityType((String) result[2]);
				res.setFacilityId((Integer) result[3]);
				res.setMedicalRecordNumber((String) result[4]);
				Date patientDos = (Date) result[5];
				res.setPatientDos(dateFormat.format(patientDos));
				res.setPatientName((String) result[6]);
				res.setStatus((String) result[7]);
				res.setProviderName((String) result[8]);
				res.setProviderId((String) result[9]);
				res.setServiceLine((String) result[10]);
				res.setCodingTeam((String) result[11]);
				String deficiencyReason = (String) result[12];
				log.debug("deficiencyReason=========" + deficiencyReason);
				if (deficiencyReason != null) {

					String cleanDeficiencyReason = deficiencyReason.replaceAll("[\\[\\]\"]", "").replace("\\", "");
					List<String> deficiencyReasonList = Arrays.asList(cleanDeficiencyReason.split(","));

					log.debug("deficiencyReason=========" + deficiencyReasonList);
					res.setDeficiencyReason(deficiencyReasonList);
				} else {
					List<String> reasons = new ArrayList<>();
					res.setDeficiencyReason(reasons);
				}
				log.debug("pending reason" + result[13]);
				res.setPendingReason((String) result[13]);
				res.setCoderUserId((String) result[14]);
				res.setCoderFullname((String) result[15]);
				return res;
			}).collect(Collectors.toList());

			// If sorting by bluebookId, sort the results manually
			if ("bluebookId".equals(req.getSortBy())) {
				if (req.getOrder() == 0) {
					// Ascending order
					reportList.sort(Comparator.comparing(ReconReportData::getBluebookId));
				} else {
					// Descending order
					reportList.sort(Comparator.comparing(ReconReportData::getBluebookId).reversed());
				}
			}

		} catch (Exception e) {
			log.error("Exception occurred while fetching reconciliation report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch reconciliation report", e);
		}

		return reportList;
	}

	private void setCommonParameters(Query query, ReconReportReq req) {
		if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
			query.setParameterList("bluebookIds", req.getBbcList());
		}
		if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
			query.setParameterList("providerNames", req.getProviderNameList());
		}
		if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
			query.setParameterList("patientNames", req.getPatientNameList());
		}
		if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
			// Set the converted Long list for visitIdList
			List<Long> visitIds = req.getVisitIdList().stream().map(Long::valueOf) // Convert each String to Long
					.collect(Collectors.toList());
			query.setParameterList("visitIds", visitIds);
		}
		if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
			query.setParameterList("locationTypeList", req.getLocationTypeList());
		}
		if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
			query.setParameterList("facilityTypeList", req.getFacilityTypeList());
		}
		if (req.getStatus() != null && !req.getStatus().isEmpty()) {
			query.setParameterList("status", req.getStatus());
		}
		if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
			query.setParameterList("providerIds", req.getProviderIdList());
		}
		if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
			query.setParameterList("facilityIds", req.getFacilityIdList());
		}
		if (req.getServiceLineList() != null && !req.getServiceLineList().isEmpty()) {
			query.setParameterList("serviceLine", req.getServiceLineList());
		}
		if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
			query.setParameterList("codingTeamList", req.getCodingTeamList());
		}
		if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
			query.setParameterList("coderFullnameList", req.getCoderFullnameList());
		}
//		if (req.getPendingReason() != null && !req.getPendingReason().isEmpty()) {
//			query.setParameterList("pendReason", req.getPendingReason());
//		}
	}
	//

	@Override
	public List<Object[]> getDrillDownMonthlyChargeSummaryReport(String cptCodes, ReconReportReq req)
			throws EncodeExceptionHandler {
		List<MonthlyChargeSummaryProcedureReport> reports = null;
		List<Object[]> results = null;
		Session session = this.sessionFactory.getCurrentSession();
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();

		try {
			String hql = "SELECT DISTINCT(s.visitId),s.bluebookId,s.cptCode,"
					+ " s.patientDOS,cd.childBluebookId,s.providerName FROM AuditFiltersSource s left join ChartDetails cd on(s.visitId = cd.visitId) "
					+ "WHERE 1=1 ";
			// + "AND s.cptCode = :cptCode "
			// + " AND s.bluebookId IS NOT NULL ";

			if (cptCodes != null && !cptCodes.isEmpty()) {
				hql += "AND s.cptCode = :cptCode";
			}
			if (startDate != null) {
				hql += " AND s.patientDOS >= :startDate";
			}

			if (endDate != null) {
				hql += " AND s.patientDOS <= :endDate";
			}

			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql += " AND s.providerId IN :providerIds";

			}
			log.info("MonthlyChargeSummaryQuery : {}", hql);
			Query query = session.createQuery(hql);

			if (cptCodes != null && !cptCodes.isEmpty()) {
				query.setParameter("cptCode", cptCodes);
			}

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				List<String> providerIdList = req.getProviderIdList();
				List<Long> providerIdLongList = providerIdList.stream().map(Long::parseLong)
						.collect(Collectors.toList());
				query.setParameter("providerIds", providerIdLongList);
			}

			// results = session.createQuery(hql).setParameter("cptCode", cptCodes).list();
			results = query.list();

		} catch (Exception e) {
			log.error("Exception occurred while fetching DrillDOwnMonthlyChargeSummary report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch DrillDownMonthlyChargeSummary report", e);
		}
		return results;
	}

	@Override
	public List<String> getCPTCodesReports(ReconReportReq req) throws EncodeExceptionHandler {
		List<String> reports = null;
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();

		try {
			String hql = "SELECT DISTINCT(cptCode) FROM MonthlyChargeSummaryProcedureReport WHERE 1=1 ";

			if (req.getStartDate() != null && req.getEndDate() != null) {
				hql += " AND dateOfService BETWEEN :startDate AND :endDate";
				parameters.put("startDate", req.getStartDate());
				parameters.put("endDate", req.getEndDate());
			}

			log.info("MonthlyChargeSummaryQUery : {}", hql);
			reports = session.createQuery(hql).setProperties(parameters).list();

		} catch (Exception e) {
			log.error("Exception occurred while fetching MonthlyChargeSummary report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch MonthlyChargeSummary report", e);
		}
		return reports;
	}

	@Override
	public List<Object[]> getFacilitynLocationDetails() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> reportdata = null;
		try {
			String hql = "SELECT DISTINCT(snfLocationBBC),facilityId,snfLocationName," + " ihealConfig, facilityType"
					+ " FROM Dashboard";
			Query<Object[]> query = session.createQuery(hql, Object[].class);
			log.info("query1 : {}", hql);
			reportdata = query.list();
			log.debug("reportdata....." + reportdata);
		} catch (Exception e) {
			log.error("Exception occurred while fetching all Data: {} ", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return reportdata;
	}

	@Override
	public List<SuperbillVarianceCount> superbillVarianceReportData(ReconReportReq req) throws EncodeExceptionHandler {
		List<SuperbillVarianceCount> reportList = new ArrayList<>();
		// SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		try {

			StringBuilder hql = new StringBuilder("SELECT ");

			if ("provider".equalsIgnoreCase(req.getViewBy())) {
				hql.append(
						"s.providerId, s.providerName, s.bluebookId, s.facilityId, s.facilityName, COUNT(*) AS totalVariances ");
			} else if ("facility".equalsIgnoreCase(req.getViewBy())) {
				hql.append(
						"s.bluebookId, s.facilityId, s.facilityName, s.providerId, s.providerName, COUNT(*) AS totalVariances ");

			}

			hql.append("FROM SuperbillVariance s WHERE 1=1 AND s.potentialCptCode != s.actualCptCode");

			if (startDate != null) {
				hql.append(" AND s.dateOfService >= :startDate");
			}

			if (endDate != null) {
				hql.append(" AND s.dateOfService <= :endDate");
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND s.bluebookId IN :bluebookIds");
				// hql.append(" AND (s.bluebookId IN :bluebookIds OR cd.childBluebookId IN
				// :bluebookIds)");
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND s.providerName IN :providerNames");
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND s.providerId IN :providerIds");
			}
			if (req.getFacilityIdList() != null) {
				hql.append(" AND s.facilityId IN :facilityId");
			}
			// if (req.getLocationTypeList() != null &&
			// !req.getLocationTypeList().isEmpty()) {
			// hql.append(" AND CASE WHEN s.ihealConfig = 'EMR' THEN 'i-heal' ELSE
			// 'non-i-heal' END IN :ihealConfig");
			// }

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND s.ihealConfig IN :locationTypeList");
			}

			if ("provider".equalsIgnoreCase(req.getViewBy())) {
				hql.append(" Group By s.providerId");

			} else if ("facility".equalsIgnoreCase(req.getViewBy())) {
				hql.append(" Group By s.facilityId");
			}

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			log.info("query1 : {}", hql);

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				List<String> names = req.getProviderNameList();
				List<String> formattedNames = new ArrayList<>();

				for (String name : names) {
					if (name.contains(",")) {
						String[] nameParts = name.split(",");
						if (nameParts.length == 2) {
							String formattedName = nameParts[1].trim() + " " + nameParts[0].trim();
							formattedNames.add(formattedName);
						} else {
							formattedNames.add(name.trim());
						}
					} else {
						formattedNames.add(name.trim());
					}
				}

				if (!formattedNames.isEmpty()) {
					log.debug("formattedNames=================" + formattedNames);
					query.setParameterList("providerNames", formattedNames);
				} else {
					log.debug("Error: No valid provider names found");
				}
			} else {
				log.debug("Error: Provider name list is null or empty");
			}
			// query.setParameterList("providerNames", req.getProviderNameList());
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query.setParameterList("locationTypeList", req.getLocationTypeList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {

				List<String> providerIdList = req.getProviderIdList();
				List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
						.collect(Collectors.toList());
				query.setParameterList("providerIds", providerIdIntList);
			}
			if (req.getFacilityIdList() != null) {
				query.setParameterList("facilityId", req.getFacilityIdList());
			}
			log.info("query1 : {}", hql);

			List<Object[]> results = query.list();

			log.debug("results............." + results);

			reportList = results.stream().map(result -> {
				SuperbillVarianceCount sb = new SuperbillVarianceCount();

				if ("provider".equalsIgnoreCase(req.getViewBy())) {
					sb.setProviderId((Integer) result[0]);
					sb.setProviderName((String) result[1]);
					sb.setBluebookId((String) result[2]);
					sb.setFacilityId((Integer) result[3]);
					sb.setFacilityName((String) result[4]);
					sb.setTotalVariance(((Long) result[5]).intValue());
				} else if ("facility".equalsIgnoreCase(req.getViewBy())) {
					sb.setBluebookId((String) result[0]);
					sb.setFacilityName((String) result[2]);
					sb.setFacilityId((Integer) result[1]);
					sb.setProviderId((Integer) result[3]);
					sb.setProviderName((String) result[4]);
					sb.setTotalVariance(((Long) result[5]).intValue());
				}
				return sb;
			}).collect(Collectors.toList());

		} catch (Exception e) {
			log.error("Exception occurred while fetching Superbill Variance report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch reconciliation report", e);
		}
		return reportList;
	}

	@Override
	public List<Object[]> getMissingChartData(ReconReportReq req) throws EncodeExceptionHandler {
		List<Object[]> reports = null;
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();

		try {
			String hql = "SELECT cast(m.dateOfService as date) AS dateOfService, count(0) AS missingChart"
					+ " FROM Dashboard m" + " LEFT JOIN ChartDetails cd ON m.visitId = cd.visitId WHERE 1=1"
					+ " AND m.status IN ('New', 'Received') AND m.encounterType != 'Nurse Visit'";

			if (req.getIsAll() != null && !req.getIsAll()) {

				if (req.getStartDate() != null && req.getEndDate() != null) {

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(req.getStartDate());
					calendar.set(Calendar.HOUR_OF_DAY, 0);
					calendar.set(Calendar.MINUTE, 0);
					calendar.set(Calendar.SECOND, 0);
					calendar.set(Calendar.MILLISECOND, 0);
					Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

					calendar.setTime(req.getEndDate());
					calendar.set(Calendar.HOUR_OF_DAY, 23);
					calendar.set(Calendar.MINUTE, 59);
					calendar.set(Calendar.SECOND, 59);
					calendar.set(Calendar.MILLISECOND, 999);
					Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

					hql += " AND m.dateOfService BETWEEN :startDate AND :endDate";
					parameters.put("startDate", startOfDay);
					parameters.put("endDate", endOfDay);

					/*
					 * hql += " AND m.dateOfService BETWEEN :startDate AND :endDate";
					 * parameters.put("startDate", req.getStartDate()); parameters.put("endDate",
					 * req.getEndDate());
					 */

				}

				if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
					hql += " AND m.snfLocationBBC IN :bbcList";
					// hql += " AND (m.bluebookId IN (:bbcList) OR cd.childBluebookId IN
					// (:bbcList))";
					parameters.put("bbcList", req.getBbcList());
				}
				if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
					hql += " AND m.providerName IN :providerNameList";
					parameters.put("providerNameList", req.getProviderNameList());
				}

				if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
					hql += " AND m.providerId IN :providerIds";
					parameters.put("providerIds", req.getProviderIdList());

				}
				/*
				 * if (req.getLocationTypeList() != null &&
				 * !req.getLocationTypeList().isEmpty()) { if
				 * (req.getLocationTypeList().contains("i-heal") && !req
				 * .getLocationTypeList().contains("non-i-heal")) { hql +=
				 * " AND m.ihealConfig IN :ihealConfig"; parameters.put("ihealConfig", "EMR"); }
				 * if (req.getLocationTypeList().contains("non-i-heal") &&
				 * !req.getLocationTypeList().contains("i-heal")) { hql +=
				 * " AND m.ihealConfig NOT IN :ihealConfig"; parameters.put("ihealConfig",
				 * "EMR"); } }
				 */

				if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
					hql += " AND m.ihealConfig IN :locationTypeList";
					parameters.put("locationTypeList", req.getLocationTypeList());
				}
				if (req.getFacilityIdList() != null) {
					hql += " AND m.facilityId IN :facilityIdList";
					parameters.put("facilityIdList", req.getFacilityIdList());
				}

				hql += " group by cast(m.dateOfService as date) order by m.dateOfService";
			}

			log.info("MissingChartReportQuery : {}", hql);
			reports = session.createQuery(hql).setProperties(parameters).list();
			log.debug("Reports Size:  {}", reports.size());
			log.debug("reports:  {}", reports);

		} catch (Exception e) {
			log.error("Exception occurred while fetching MissingChartReport report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch MissingChartReport report", e);
		}
		return reports;
	}

	@Override
	public List<Object[]> getDrillDownMissingChartReport(ReconReportReq req) throws EncodeExceptionHandler {
		List<Object[]> results = null;
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();

		try {
			String hql = "SELECT DISTINCT(s.visitId),s.snfLocationBBC,s.snfLocationName,"
					// + " s.providerName,s.dateOfService,s.patientName,cd.childBluebookId,s.status
					// FROM Dashboard s left join ChartDetails cd on(s.visitId = cd.visitId) WHERE
					// 1=1";
					+ " s.providerName,s.dateOfService,s.patientName,s.status FROM Dashboard s WHERE 1=1";

			/*
			 * if (req.getStartDate() != null && req.getEndDate() != null) { hql +=
			 * " AND s.dateOfService BETWEEN :startDOSDate AND :endDOSDate";
			 * parameters.put("startDOSDate", req.getStartDate());
			 * parameters.put("endDOSDate", req.getEndDate()); }
			 */

			// if (req.getAllChart() != null && req.getAllChart()) {
			if (req.getAllChart() == true) {
				// Apply filters for all dates of service
				if (req.getStartDate() != null && req.getEndDate() != null) {
					/*
					 * hql += " AND s.dateOfService BETWEEN :startDOSDate AND :endDOSDate";
					 * parameters.put("startDOSDate", req.getStartDate());
					 * parameters.put("endDOSDate", req.getEndDate());
					 */
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(req.getStartDate());
					calendar.set(Calendar.HOUR_OF_DAY, 0);
					calendar.set(Calendar.MINUTE, 0);
					calendar.set(Calendar.SECOND, 0);
					calendar.set(Calendar.MILLISECOND, 0);
					Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

					calendar.setTime(req.getEndDate());
					calendar.set(Calendar.HOUR_OF_DAY, 23);
					calendar.set(Calendar.MINUTE, 59);
					calendar.set(Calendar.SECOND, 59);
					calendar.set(Calendar.MILLISECOND, 999);
					Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

					hql += " AND s.dateOfService BETWEEN :startDate AND :endDate";
					parameters.put("startDate", startOfDay);
					parameters.put("endDate", endOfDay);
				}
				// } else if (req.getDateOfService() != null) {
			} else if (req.getDateOfService() != null) {
				// Apply filter for specific date of service
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(req.getDateOfService());
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				calendar.set(Calendar.MILLISECOND, 999);
				Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

				hql += " AND s.dateOfService BETWEEN :startDate AND :endDate";
				parameters.put("startDate", startOfDay);
				parameters.put("endDate", endOfDay);
			}
			// Apply filter for BBC List
//			  if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
//			      List<String> bbcList = new ArrayList<>();
//			      List<String> facilityList = new ArrayList<>();
//			      for (String bbc : req.getBbcList()) {
//			          String[] parts = bbc.split(" - ");
//			          if (parts.length == 2) {
//			              bbcList.add(parts[0]);
//			              facilityList.add(parts[1]);
//			          }
//			      }
//			// Apply filter for BBC List
//			  if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
//			      List<String> bbcList = new ArrayList<>();
//			      List<String> facilityList = new ArrayList<>();
//			      for (String bbc : req.getBbcList()) {
//			          int lastHyphenIndex = bbc.lastIndexOf(" - ");
//			          if (lastHyphenIndex != -1) {
//			              String bbcPart = bbc.substring(0, lastHyphenIndex);
//			              String facilityPart = bbc.substring(lastHyphenIndex + 3); // +3 to skip " - "
//			              bbcList.add(bbcPart);
//			              facilityList.add(facilityPart);
//			          }
//			      }
			// if (!bbcList.isEmpty() && !facilityList.isEmpty()) {
//		          hql += " AND s.snfLocationBBC IN :bbcList AND s.snfLocationName IN :facilityList";
//		          parameters.put("bbcList", bbcList);
//		          parameters.put("facilityList", facilityList);
//		      }
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql += " AND s.snfLocationBBC IN :bbcList";
				parameters.put("bbcList", req.getBbcList());
			}
			if (req.getFacilityIdList() != null) {
				hql += " AND s.facilityId IN :facilityIdList";
				parameters.put("facilityIdList", req.getFacilityIdList());
			}

			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql += " AND s.providerName IN :providerNameList";
				parameters.put("providerNameList", req.getProviderNameList());
			}

			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql += " AND s.providerId IN :providerIds";
				parameters.put("providerIds", req.getProviderIdList());
			}
			/*
			 * if (req.getLocationTypeList() != null &&
			 * !req.getLocationTypeList().isEmpty()) { if
			 * (req.getLocationTypeList().contains("i-heal") && !req
			 * .getLocationTypeList().contains("non-i-heal")) { hql +=
			 * " AND s.ihealConfig IN :ihealConfig"; parameters.put("ihealConfig", "EMR"); }
			 * if (req.getLocationTypeList().contains("non-i-heal") &&
			 * !req.getLocationTypeList().contains("i-heal")) { hql +=
			 * " AND s.ihealConfig NOT IN :ihealConfig"; parameters.put("ihealConfig",
			 * "EMR"); } }
			 */

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql += " AND s.ihealConfig IN :locationTypeList";
				parameters.put("locationTypeList", req.getLocationTypeList());
			}

			hql += " AND s.status IN ('New', 'Received') AND s.encounterType != 'Nurse Visit'";

			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				// Convert visitIdList to Long if necessary
				List<Long> visitIdList = req.getVisitIdList().stream().map(Long::valueOf).collect(Collectors.toList());
				hql += " AND s.visitId IN :visitIdList";
				parameters.put("visitIdList", visitIdList);
			}
			if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
				hql += " AND s.patientName IN :patientNameList";
				parameters.put("patientNameList", req.getPatientNameList());
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by s.receivedDate asc";
			}

			log.info("MissingChartReport : {}", hql);
			results = session.createQuery(hql).setProperties(parameters).list();
			log.debug("Results Sizes:   {}", results.size());
			log.debug("Results:   {}", results);

		} catch (Exception e) {
			log.error("Exception occurred while fetching MissingChartReport report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch MissingChartReport report", e);
		}
		return results;
	}

	private String sortList(ReconReportReq req, String hql) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "asc" : "desc";

		switch (sortBy.toLowerCase()) {
		case "bluebookid":
			hql += " order by LOWER(s.snfLocationBBC) " + order;
			break;
		case "facilityname":
			hql += " order by LOWER(s.facilityAlias) " + order;
			break;
		case "providername":
			hql += " order by LOWER(s.providerName) " + order;
			break;
		case "patientname":
			hql += " order by LOWER(s.patientName) " + order;
			break;
		case "dateofservice":
			hql += " order by s.dateOfService " + order;
			break;
		case "visitid":
			hql += " order by s.visitId " + order;
			break;
		default:
			hql += " order by LOWER(" + sortBy + ") " + order;
			break;
		}

		return hql;
	}

	@Override
	public List<String> getFiltersData() throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> history = new ArrayList<>();
		try {
			String hql = "SELECT DISTINCT(filterName) FROM AuditCompliancePostAuditReport WHERE 1=1 ORDER BY filterName ASC";

			log.info("AuditHistoryQuery : {}", hql);
			history = session.createQuery(hql).list();

		} catch (Exception e) {
			log.error("Exception occurred while fetching AuditHistoryFilters report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch AuditHistoryFilters report", e);
		}
		return history;
	}

	@Override
	public List<Object[]> getDrillDownPostAuditReport(ReconReportReq req, boolean isExcel)
			throws EncodeExceptionHandler {
		List<Object[]> results = null;
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();

		try {
			String hql = "SELECT DISTINCT(visitId),coderName,team,"
					+ " provider,sendingFacility,dos,chartCodes,codingError,auditNotes,filterName,auditDate FROM AuditCompliancePostAuditReport WHERE 1=1";

			if (req.getStartDate() != null && req.getEndDate() != null) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(req.getStartDate());
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

				calendar.setTime(req.getEndDate());
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				calendar.set(Calendar.MILLISECOND, 999);
				Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

				hql += " AND auditDate BETWEEN :startDate AND :endDate";
				parameters.put("startDate", startOfDay);
				parameters.put("endDate", endOfDay);
			}
			if (req.getFilterName() != null && !req.getFilterName().isEmpty()) {
				hql += " AND filterName IN :filterName";
				parameters.put("filterName", req.getFilterName());
			}

			log.info("PostAuditReport : {}", hql);
			results = session.createQuery(hql).setProperties(parameters).list();
			log.debug("Results:   {}", results.size());

		} catch (Exception e) {
			log.error("Exception occurred while fetching PostAudit report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch PostAudit report", e);
		}
		return results;
	}

	public List<EncounterNeedingGuidanceReport> fetchReportsByCoderIds(GuidanceReportReq req)
			throws EncodeExceptionHandler {
//		Session session = this.sessionFactory.getCurrentSession();
//		List<EncounterNeedingGuidanceReport> reports = new ArrayList<>();
//		try {
//             List<Integer> coderId= req.getCoderId();
//			List<String> coderIdStrings = coderId.stream().map(String::valueOf).collect(Collectors.toList());
//			String hql = "FROM EncounterNeedingGuidanceReport e WHERE e.coderUserId IN :coderId";
//			
//			
//			//
		Session session = this.sessionFactory.getCurrentSession();
		List<EncounterNeedingGuidanceReport> reports = new ArrayList<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = "FROM EncounterNeedingGuidanceReport a WHERE 1=1 AND a.coderUserId IN :coderId";
			List<Integer> coderId = req.getCoderId();
			List<String> coderIdStrings = coderId.stream().map(String::valueOf).collect(Collectors.toList());

			Map<String, Object> parameters = new HashMap<>();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					switch (filterReq) {
					case "blueBookId": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBlueBookId());
						query += " AND a.blueBookId IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "coderFullName": {
						List<String> coderList = FilterRequestUtil.getListFromDelimitedStr(req.getCoderFullName());
						query += " AND a.coderUserName IN :coder ";
						parameters.put("coder", coderList);
					}
						break;
					case "guidanceDate": {
						query += " AND a.guidanceDate BETWEEN :startGuidanceDate AND :endGuidanceDate ";
						parameters.put("startGuidanceDate",
								new Timestamp(dateFormat.parse(req.getStartGuidanceDate()).getTime()));
						parameters.put("endGuidanceDate",
								new Timestamp(dateFormat.parse(req.getEndGuidanceDate()).getTime()));
					}
						break;
					case "daysInGuidance": {
						List<String> daysList = FilterRequestUtil.getListFromDelimitedStr(req.getDaysInGuidance());
						List<Integer> intnosOfDaysList = new ArrayList<>();
						for (String s : daysList) {
							intnosOfDaysList.add(Integer.valueOf(s));
						}
						query += " AND a.daysInGuidance IN :daysInGuidance ";
						parameters.put("daysInGuidance", intnosOfDaysList);
					}
						break;

					case "dateOfService": {
						query += " AND a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " AND a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					default:
						break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				query = sortEncounterNeedingGuidanceReport(req, query);

			} else {
				query += " order by LOWER(a.coderUserName) asc";
			}
			log.info("EncounterReportQuery : {}", query);
			log.debug("parameters: ", parameters);

			reports = session.createQuery(query, EncounterNeedingGuidanceReport.class)
					.setParameter("coderId", coderIdStrings).setProperties(parameters).getResultList();
		} catch (Exception e) {
			log.error("Exception occurred while fetching encounters needing guidance report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch encounters needing guidance report", e);
		}
		return reports;
	}

	private String sortEncounterNeedingGuidanceReport(GuidanceReportReq req, String hql) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "desc" : "asc";

		switch (sortBy.toLowerCase()) {
		case "bluebookid":
			hql += " order by LOWER(a.blueBookId) " + order;
			break;
		case "coderfullname":
			hql += " order by LOWER(a.coderUserName) " + order;
			break;
		case "guidancedate":
			hql += " order by a.guidanceDate " + order;
			break;
		case "daysinguidance":
			hql += " order by a.daysInGuidance " + order;
			break;
		case "dateofservice":
			hql += " order by a.dateOfService " + order;
			break;
		case "visitid":
			hql += " order by a.visitId " + order;
			break;
		default:
			hql += " order by LOWER(" + sortBy + ") " + order;
			break;
		}
		return hql;
	}

	@Override
	public List<Object[]> generateSuperbillVarianceReport(int facilityId, ReconReportReq req)
			throws EncodeExceptionHandler {
		List<SuperbillVarianceReportData> reports = null;
		List<Object[]> results = null;
		Session session = this.sessionFactory.getCurrentSession();
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();

		try {
			String hql = "SELECT DISTINCT(s.visitId),s.bluebookId,s.facilityId,s.providerId,"
					+ "s.facilityName,s.providerName,s.dateOfService,s.patientName,s.dateBilled,"
					+ "s.potentialCptCode,s.actualCptCode,s.varianceReason,s.comment"
					+ " FROM SuperbillVariance s WHERE 1=1 "
					+ " AND s.bluebookId IS NOT NULL AND s.actualCptCode != s.potentialCptCode";

			if (facilityId > 0) {
				hql += " AND s.facilityId = :facilityId";
			}

			if (req.getProviderId() != 0) {
				hql += " AND s.providerId = :providerId";
			}

			if (startDate != null) {
				hql += " AND s.dateOfService >= :startDate";
			}

			if (endDate != null) {
				hql += " AND s.dateOfService <= :endDate";
			}
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				// hql+= " AND (s.bluebookId IN (:bluebookIds) OR cd.childBluebookId IN
				// (:bluebookIds))";
				hql += " AND s.bluebookId IN :bluebookIds";
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql += " AND s.providerName IN (:providerNames)";
			}
			log.info("supervillvarianceReportQuery : {}", hql);
			Query query = session.createQuery(hql);

			if (facilityId > 0) {
				query.setParameter("facilityId", facilityId);

			}

			if (req.getProviderId() != 0) {
				query.setParameter("providerId", req.getProviderId());
			}

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query.setParameterList("providerNames", req.getProviderNameList());
			}

			results = query.list();

		} catch (Exception e) {
			log.error("Exception occurred while fetching Superbill Variance report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch Superbill Variance report", e);
		}
		return results;
	}

	@Override
	public List<EncounterUnderReviewCount> getEncounterUnderReviewCount(ReconReportReq req)
			throws EncodeExceptionHandler {
		List<EncounterUnderReviewCount> reportList = new ArrayList<>();
		// SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		Map<String, Object> param = new HashMap<>();
		try {

			StringBuilder hql = new StringBuilder("SELECT ");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
				hql.append(
						"s.patientId, s.patientName, c.deficientProviderName, COUNT(c.deficientProviderName) AS total ");
			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
				hql.append(
						"s.patientId, s.patientName, c.deficientProviderName, COUNT(c.deficientProviderName) AS total ");

			}

			// hql.append("FROM Dashboard s WHERE 1=1");
			hql.append(
					"FROM Dashboard s LEFT JOIN ChartDetails AS c ON s.visitId = c.visitId WHERE 1=1 AND s.status IN ('Deficiency','Pending') AND c.deficientProviderName IS NOT NULL ");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND DATE(c.deficiencyStartDate) >= :startDate");
				}

				if (endDate != null) {
					// hql.append(" AND s.deficiencyDate <= :endDate");
					hql.append(" AND DATE(c.deficiencyStartDate) <= :endDate");

				}

			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND s.dateOfService >= :startDate");
				}

				if (endDate != null) {
					hql.append(" AND s.dateOfService <= :endDate");
				}

			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND s.snfLocationBBC IN :bluebookIds");
				// hql.append(" AND (s.bluebookId IN :bluebookIds OR c.childBluebookId IN
				// :bluebookIds)");
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND c.deficientProviderName IN :providerNames");
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND c.deficientProviderUserId IN :providerIds");
			}
			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				// hql.append(" AND c.deficiencyReason IN :deficiencyReasons");
				if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
					hql.append(" AND (");
					for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
						hql.append("c.deficiencyReason like :deficiencyReason" + i);
						if (i < req.getDeficiencyReason().size() - 1) {
							hql.append(" OR ");
						}
						param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
					}
					hql.append(")");
				}
			}
			// if (req.getLocationTypeList() != null &&
			// !req.getLocationTypeList().isEmpty()) {
			// hql.append(" AND CASE WHEN s.ihealConfig = 'EMR' THEN 'i-heal' ELSE
			// 'non-i-heal' END IN :ihealConfig");
			// }

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND s.ihealConfig IN :locationTypeList");
			}

			if (req.getFacilityIdList() != null) {
				hql.append(" AND s.facilityId IN :facilityIdList");
			}

			// if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
			// hql.append(" Group By s.eventDatetime, s.providerName ");

			// } else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
			hql.append(" Group By c.deficientProviderName ");
			// }

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			log.info("query1 : {}", hql);

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query.setParameterList("providerNames", req.getProviderNameList());
			}

			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				List<String> providerIdList = req.getProviderIdList();
				List<Long> providerIdLongList = providerIdList.stream().map(Long::parseLong)
						.collect(Collectors.toList());
				query.setParameter("providerIds", providerIdLongList);
			}

			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
					query.setParameter("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
				}
				query.setProperties(param);
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query.setParameterList("locationTypeList", req.getLocationTypeList());
			}
			if (req.getFacilityIdList() != null) {
				query.setParameterList("facilityIdList", req.getFacilityIdList());
			}

			log.info("query1 : {}", hql);

			List<Object[]> results = query.list();

			log.debug("results............." + results);

			reportList = results.stream().map(result -> {
				EncounterUnderReviewCount sb = new EncounterUnderReviewCount();

				if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {

					sb.setPatientId((long) result[0]);
					sb.setPatientName((String) result[1]);
					sb.setProviderName((String) result[2]);
					sb.setTotal((Long) result[3]);
				} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
					sb.setPatientId((long) result[0]);
					sb.setPatientName((String) result[1]);
					sb.setProviderName((String) result[2]);
					sb.setTotal((Long) result[3]);
				}
				return sb;
			}).collect(Collectors.toList());

		} catch (Exception e) {
			log.error("Exception occurred while fetching Encounter Under Review Count: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch encounter under review count", e);
		}
		return reportList;
	}

	@Override
	public List<EncounterMonthlyReviewData> getEncounterUnderReviewmonthly(ReconReportReq req)
			throws EncodeExceptionHandler {
		List<EncounterMonthlyReviewData> reportList = new ArrayList<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		try {

			StringBuilder hql = new StringBuilder("SELECT ");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
				hql.append(
						"s.visitId, s.childBluebookId, s.patientId, s.patientName, s.providerName, s.dateOfService, s.deficiencyDate, s.deficiencyNote, s.deficiencyReason, s.coderUserId, s.coderUserFullname ");
			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
				hql.append(
						"s.visitId, s.childBluebookId, s.patientId, s.patientName, s.providerName, s.dateOfService, s.deficiencyDate, s.deficiencyNote, s.deficiencyReason, s.coderUserId, s.coderUserFullname ");

			}

			hql.append("FROM EncounterUnderReviewReport s WHERE 1=1");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND s.deficiencyDate >= :startDate");
				}

				if (endDate != null) {
					hql.append(" AND s.deficiencyDate <= :endDate");
				}

			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND s.dateOfService >= :startDate");
				}

				if (endDate != null) {
					hql.append(" AND s.dateOfService <= :endDate");
				}

			}

			if (req.getStartDOSDate() != null) {
				hql.append(" AND s.dateOfService >= :StartDOSDate");

			}
			if (req.getEndDOSDate() != null) {
				hql.append(" AND s.dateOfService <= :endDOSDate");

			}
			if (req.getDeficiencyStartDate() != null) {
				hql.append(" AND s.deficiencyDate >= :deficiencyStartDate");

			}
			if (req.getDeficiencyEndDate() != null) {
				hql.append(" AND s.deficiencyDate <= :deficiencyEndDate");

			}
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND s.childBluebookId IN :bluebookIds");
				// hql.append(" AND (s.bluebookId IN :bluebookIds OR c.childBluebookId IN
				// :bluebookIds)");
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND s.providerName IN :providerNames");
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND s.providerId IN :providerIds");
			}
			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				hql.append(" AND s.coderUserFullname IN :coderUserFullname");
			}
			// if (req.getLocationTypeList() != null &&
			// !req.getLocationTypeList().isEmpty()) {
			// hql.append(" AND CASE WHEN s.ihealConfig = 'EMR' THEN 'i-heal' ELSE
			// 'non-i-heal' END IN :ihealConfig");
			// }

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND s.ihealConfig IN :locationTypeList");
			}
			if (req.getFacilityIdList() != null) {
				hql.append(" AND s.facilityId IN :facilityIdList");
			}
			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				// Convert visitIdList to Long if necessary
				hql.append(" AND s.visitId IN :visitIdList");
			}
			/*
			 * if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
			 * hql.append(" Group By s.deficiencyDate");
			 * 
			 * } else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
			 * hql.append(" Group By s.dateOfService"); }
			 */
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortListformonthly(req, hql);

			} else {
				hql.append(" order by LOWER(s.childBluebookId) asc");
			}
			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			log.info("query1 : {}", hql);

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}
			if (req.getStartDOSDate() != null) {
				query.setParameter("StartDOSDate", dateFormat.parse(req.getStartDOSDate()));
			}
			if (req.getEndDOSDate() != null) {
				query.setParameter("endDOSDate", dateFormat.parse(req.getEndDOSDate()));
			}

			if (req.getDeficiencyStartDate() != null) {
				query.setParameter("deficiencyStartDate", dateFormat.parse(req.getDeficiencyStartDate()));
			}
			if (req.getDeficiencyEndDate() != null) {
				query.setParameter("deficiencyEndDate", dateFormat.parse(req.getDeficiencyEndDate()));
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query.setParameterList("providerNames", req.getProviderNameList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				List<String> providerIdList = req.getProviderIdList();
				List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
						.collect(Collectors.toList());
				query.setParameter("providerIds", providerIdIntList);
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query.setParameterList("locationTypeList", req.getLocationTypeList());
			}
			if (req.getFacilityIdList() != null) {
				query.setParameterList("facilityIdList", req.getFacilityIdList());
			}
			if (req.getVisitIdList() != null && !req.getVisitIdList().isEmpty()) {
				List<Long> visitIdList = req.getVisitIdList().stream().map(Long::valueOf).collect(Collectors.toList());
				query.setParameterList("visitIdList", visitIdList);
			}
			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				query.setParameterList("coderUserFullname", req.getCoderFullnameList());
			}
			log.info("query1 : {}", hql);

			List<Object[]> results = query.list();

			log.debug("results............." + results);

			reportList = results.stream().map(result -> {
				// String childBbc = null;
				// String hql1 = "Select c.childBluebookId FROM ChartDetails c where c.visitId
				// =:visitId";
				// Query query1 = sessionFactory.getCurrentSession().createQuery(hql1);
				// query1.setParameter("visitId",(Long) result[0]);
				// childBbc = (String)query1.uniqueResult();
				EncounterMonthlyReviewData sb = new EncounterMonthlyReviewData();
				if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
					sb.setVisitId((Long) result[0]);
					// if(childBbc != null && !childBbc.isEmpty()){
					// sb.setBluebookId(childBbc);
					// }else{
					sb.setBluebookId((String) result[1]);
					// }
					sb.setPatientId((Integer) result[2]);
					sb.setPatientName((String) result[3]);
					sb.setProviderName((String) result[4]);
					sb.setDateOfService((Date) result[5]);
					sb.setDeficiencyDate((Date) result[6]);
					sb.setDeficiencyNote((String) result[7]);
					sb.setDeficiencyReason((String) result[8]);
					sb.setCoderUserId((String) result[9]);
					sb.setCoderFullname((String) result[10]);

				} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
					sb.setVisitId((Long) result[0]);
					// if(childBbc != null && !childBbc.isEmpty()){
					// sb.setBluebookId(childBbc);
					// }else{
					// sb.setBluebookId((String) result[1]);
					// }
					sb.setBluebookId((String) result[1]);
					sb.setPatientId((Integer) result[2]);
					sb.setPatientName((String) result[3]);
					sb.setProviderName((String) result[4]);
					sb.setDateOfService((Date) result[5]);
					sb.setDeficiencyDate((Date) result[6]);
					sb.setDeficiencyNote((String) result[7]);
					sb.setDeficiencyReason((String) result[8]);
					sb.setCoderUserId((String) result[9]);
					sb.setCoderFullname((String) result[10]);
				}
				return sb;
			}).collect(Collectors.toList());

		} catch (Exception e) {
			log.error("Exception occurred while fetching Encounter Under Review Monthly report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch encounter under review monthly report", e);
		}
		return reportList;
	}

	private StringBuilder sortListformonthly(ReconReportReq req, StringBuilder hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("bluebookId")) {
			hql.append(" order by LOWER(s.childBluebookId) ");
		} else if (sortBy.equals("visitId")) {
			hql.append(" order by LOWER(s.visitId) ");
		} else if (sortBy.equals("providerName")) {
			hql.append(" order by LOWER(s.providerName) ");
		} else if (sortBy.equals("patientName")) {
			hql.append(" order by LOWER(s.patientName) ");
		} else if (sortBy.equals("dateOfService")) {
			hql.append(" order by LOWER(s.dateOfService) ");
		} else if (sortBy.equals("deficiencyDate")) {
			hql.append(" order by LOWER(s.deficiencyDate) ");
		}  else if (sortBy.equals("coderFullname")) {
			hql.append(" order by LOWER(s.coderUserFullname) ");
		} 
		else {
			hql.append(" order by LOWER(s." + sortBy + ") ");
		}

		if (req.getOrder() == 0) {
			hql.append(" desc");
		} else {
			hql.append(" asc");
		}
		return hql;
	}

	@Override
	public List<EncounterUnderReviewData> getEncounterUnderReviewReport(ReconReportReq req)
			throws EncodeExceptionHandler {

		List<EncounterUnderReviewData> reportList = new ArrayList<>();
		// SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		Map<String, Object> param = new HashMap<>();
		try {
			//
			Map<String, String> sortColumnMapping = new HashMap<>();
			sortColumnMapping.put("bluebookId", "s.snfLocationBBC");
			sortColumnMapping.put("visitId", "s.visitId");
			sortColumnMapping.put("dos", "s.dateOfService");
			sortColumnMapping.put("patientName", "s.patientName");
			sortColumnMapping.put("start", "c.deficiencyStartDate");
			sortColumnMapping.put("providerName", "c.deficientProviderName");
			sortColumnMapping.put("coderUserId", "c.coderUserId");
			sortColumnMapping.put("coderFullname", "s.coderUserFullname");

			StringBuilder hql = new StringBuilder("SELECT ");
			hql.append(
					"s.snfLocationBBC, s.visitId, s.patientId, s.patientName, c.deficientProviderUserId, c.deficientProviderName, DATE(c.deficiencyStartDate) AS deficiencyDate, DATEDIFF(CURDATE(), c.deficiencyStartDate) AS daysInReview, s.dateOfService,c.deficiencyReason, c.deficientNote, c.childBluebookId, s.coderUserId, s.coderUserFullname ");

			hql.append(
					"FROM Dashboard s LEFT JOIN ChartDetails AS c ON s.visitId = c.visitId WHERE 1=1 AND status IN ('Deficiency','Pending') AND c.deficientProviderName IS NOT NULL");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND DATE(c.deficiencyStartDate) >= :startDate");
				}

				if (endDate != null) {
					hql.append(" AND DATE(c.deficiencyStartDate) <= :endDate");
				}

			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND s.dateOfService >= :startDate");
				}

				if (endDate != null) {
					hql.append(" AND s.dateOfService <= :endDate");
				}
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND (s.snfLocationBBC IN :bluebookIds)");
			}

			if (req.getVisitIds() != null && !req.getVisitIds().isEmpty()) {
				hql.append(" AND s.visitId IN :visitIds");
			}

			if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
				hql.append(" AND s.patientName IN :patientNames");
			}

			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND c.deficientProviderUserId IN :providerIds");
			}

			if (req.getDaysList() != null && !req.getDaysList().isEmpty()) {
				hql.append(" AND (DATEDIFF(CURDATE(), c.deficiencyStartDate) IN :days)");
			}

			if (req.getDefStartDate() != null) {
				hql.append(" AND (DATE(c.deficiencyStartDate) >= :defStartDate)");
			}

			if (req.getDefEndDate() != null) {
				hql.append(" AND (DATE(c.deficiencyStartDate) <= :defEndDate)");
			}

			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND c.deficientProviderName IN :providerNames");
			}
			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				hql.append(" AND (");
				for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
					hql.append("c.deficiencyReason like :deficiencyReason" + i);
					if (i < req.getDeficiencyReason().size() - 1) {
						hql.append(" OR ");
					}
					param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
				}
				hql.append(")");
			}

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND CASE WHEN s.ihealConfig = 'EMR' THEN 'i-heal' ELSE 'non-i-heal' END IN :ihealConfig");
			}

			if (req.getFacilityIdList() != null) {
				hql.append(" AND s.facilityId IN :facilityIdList");
			}

			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				hql.append(" AND s.coderUserFullname IN :coderFullname");
			}

			hql.append(" Group By s.visitId, c.deficientProviderName");

			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				if (!req.getSortBy().equalsIgnoreCase("days")) {
					String sortByColumn = sortColumnMapping.get(req.getSortBy());
					if (sortByColumn != null) {
						hql.append(" ORDER BY ").append(sortByColumn);
						if (req.getOrder() == 0) {
							hql.append(" ASC");
						} else {
							hql.append(" DESC");
						}
					}
				}
			}

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			log.info("query1 : {}", hql);

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query.setParameterList("providerNames", req.getProviderNameList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				List<String> providerIdList = req.getProviderIdList();
				List<Long> providerIdLongList = providerIdList.stream().map(Long::parseLong)
						.collect(Collectors.toList());
				query.setParameter("providerIds", providerIdLongList);
			}

			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
					query.setParameter("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
				}
				query.setProperties(param);
				// query.setParameterList("deficiencyReasons", req.getDeficiencyReason());
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query.setParameterList("ihealConfig", req.getLocationTypeList());
			}
			if (req.getFacilityIdList() != null) {
				query.setParameterList("facilityIdList", req.getFacilityIdList());
			}

			if (req.getVisitIds() != null && !req.getVisitIds().isEmpty()) {
				query.setParameterList("visitIds", req.getVisitIds());
			}

			if (req.getPatientNameList() != null && !req.getPatientNameList().isEmpty()) {
				query.setParameterList("patientNames", req.getPatientNameList());
			}

			if (req.getDaysList() != null && !req.getDaysList().isEmpty()) {
				query.setParameterList("days", req.getDaysList());
			}

			if (req.getDefStartDate() != null) {
				Date defStartDate = req.getDefStartDate();
				query.setParameter("defStartDate", defStartDate);
			}

			if (req.getDefEndDate() != null) {
				Date defEndDate = req.getDefEndDate();
				query.setParameter("defEndDate", defEndDate);
			}
			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				query.setParameterList("coderFullname", req.getCoderFullnameList());
			}

			log.info("query1 : {}", hql);

			List<Object[]> results = query.list();

			log.debug("results............." + results);
			int count = 1;
			for (Object[] result : results) {
				EncounterUnderReviewData sb = new EncounterUnderReviewData();
				if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
					/*
					 * String childBbc = (String) result[11]; if (childBbc != null &&
					 * !childBbc.isEmpty()) { sb.setBluebookId(childBbc); } else {
					 * sb.setBluebookId((String) result[0]); }
					 */
					sb.setBluebookId((String) result[0]);
					sb.setVisitId((long) result[1]);
					sb.setPatientId((long) result[2]);
					sb.setPatientName((String) result[3]);
					sb.setProviderId((Long) result[4]);
					sb.setProviderName((String) result[5]);
					Date deficiencyDate = (result[6] != null) ? (Date) result[6] : null;
					sb.setDeficiencyDate(deficiencyDate);
					// sb.setDeficiencyDate((Date) result[6]);
					Integer daysInReview = (result[7] != null) ? (Integer) result[7] : 0;
					sb.setDaysInReview(daysInReview);
					// sb.setDaysInReview((Integer) result[7]);
					sb.setDateOfService((Timestamp) result[8]);
					String deficiencyReasons = (String) result[9];

					if (deficiencyReasons != null) {

						String cleandeficiencyReasons = deficiencyReasons.replaceAll("[\\[\\]\"]", "").replace("\\",
								"");
						List<String> deficiencyReaonsList = Arrays.asList(cleandeficiencyReasons.split(","));

						log.debug("varianceReason=========" + cleandeficiencyReasons);
						sb.setDeficiencyReason(deficiencyReaonsList);
					} else {
						// Set an empty list if no deficiency reason is present
						sb.setDeficiencyReason(Collections.emptyList());
					}
					sb.setDeficientNote((String) result[10]);
					sb.setCoderUserId((String) result[12]);
					sb.setCoderFullname((String) result[13]);

				} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
					/*
					 * String childBbc = (String) result[11]; if (childBbc != null &&
					 * !childBbc.isEmpty()) { sb.setBluebookId(childBbc); } else {
					 * sb.setBluebookId((String) result[0]); }
					 */
					sb.setBluebookId((String) result[0]);
					sb.setVisitId((long) result[1]);
					sb.setPatientId((long) result[2]);
					sb.setPatientName((String) result[3]);
					sb.setProviderId(result[4] != null ? (Long) result[4] : null);
					sb.setProviderName(result[5] != null ? (String) result[5] : null);
					Date deficiencyDate = (result[6] != null) ? (Date) result[6] : null;
					sb.setDeficiencyDate(deficiencyDate);
					Integer daysInReview = (result[7] != null) ? (Integer) result[7] : 0;
					sb.setDaysInReview(daysInReview);
					// sb.setDeficiencyDate((Date) result[6]);
					// sb.setDaysInReview((Integer) result[7]);
					sb.setDateOfService((Timestamp) result[8]);
					String deficiencyReasons = (String) result[9];

					if (deficiencyReasons != null) {

						String cleandeficiencyReasons = deficiencyReasons.replaceAll("[\\[\\]\"]", "").replace("\\",
								"");
						List<String> deficiencyReaonsList = Arrays.asList(cleandeficiencyReasons.split(","));

						log.debug("varianceReason=========" + cleandeficiencyReasons);
						sb.setDeficiencyReason(deficiencyReaonsList);
						// sb.setDeficiencyReason(deficiencyReaonsList);
					}
					sb.setDeficientNote((String) result[10]);
					sb.setCoderUserId((String) result[12]);
					sb.setCoderFullname((String) result[13]);
				}
				reportList.add(sb);
				count = count + 1;
			}

			// days sorting to be applied
			if ("days".equals(req.getSortBy())) {
				if (req.getOrder() == 0) {
					reportList.sort(Comparator.comparing(EncounterUnderReviewData::getDaysInReview));
				} else {
					reportList.sort(Comparator.comparing(EncounterUnderReviewData::getDaysInReview).reversed());
				}
			}

		} catch (Exception e) {
			log.error("Exception occurred while fetching Encounter Under Review report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch encounter under review report", e);
		}
		return reportList;
	}

	@Override
	public List<Object[]> deficiencyAgingReport(ReconReportReq req) throws EncodeExceptionHandler {
		List<Object[]> reports = null;
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		boolean isPagination = req.isPagination();
		int pageSize = 25;
		Map<String, Object> listCount = new HashMap<>();

		try {
			String hql = "SELECT db.visitId, db.snfLocationBBC, db.facilityId, db.facilityAlias, db.patientId, db.patientName, db.ihealConfig,"
					+ " db.providerId, db.providerName, db.medicalRecordNumber,"
					+ " DATE(db.lastUpdatedByTimestamp) AS lastModified,"
					+ " DATE(cd.deficiencyStartDate) AS deficiencyDate," + " DATE(db.dateOfService) AS dateOfService,"
					+ "cd.childBluebookId," + "cd.deficiencyReason" + " FROM Dashboard AS db"
					+ " LEFT JOIN ChartDetails AS cd ON db.visitId = cd.visitId"
					+ " WHERE db.status = 'Deficiency' AND db.eventDatetime < :endDate";

			// if(req.getStartDate() !=null && req.getEndDate() !=null){
			// hql += " AND db.dateOfService BETWEEN :startDate AND :endDate";
			// parameters.put("startDate", req.getStartDate());
			parameters.put("endDate", req.getEndDate());
			// }
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql += " AND db.snfLocationBBC IN :bbcList";
				parameters.put("bbcList", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql += " AND db.providerName IN :providerNameList";
				parameters.put("providerNameList", req.getProviderNameList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql += " AND db.providerId IN :providerIds";
				parameters.put("providerIds", req.getProviderIdList());
			}
			/*
			 * if(req.getLocationTypeList() !=null && !req.getLocationTypeList().isEmpty())
			 * { if(req.getLocationTypeList().contains("i-heal") &&
			 * !req.getLocationTypeList().contains("non-i-heal")) { hql +=
			 * " AND db.ihealConfig IN :ihealConfig"; parameters.put("ihealConfig", "EMR");
			 * } if(req.getLocationTypeList().contains("non-i-heal") &&
			 * !req.getLocationTypeList().contains("i-heal")){ hql +=
			 * " AND db.ihealConfig NOT IN :ihealConfig"; parameters.put("ihealConfig",
			 * "EMR"); } }
			 */

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql += " AND db.ihealConfig IN :locationTypeList";
				parameters.put("locationTypeList", req.getLocationTypeList());
			}
			// LocalDate thirtyDaysAgo = LocalDate.now().minusDays(30);

			// Calendar calendar = Calendar.getInstance();
			// calendar.add(Calendar.DAY_OF_YEAR, - 30);
			// Date thirtyDayAgoDate = calendar.getTime();
			// log.debug("thirtyDayAgoDate======="+thirtyDayAgoDate);
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";
					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " db.snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "facilityName": {
						List<String> facilityNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityName());
						hql += " db.facilityAlias IN :facilityAlias ";
						parameters.put("facilityAlias", facilityNameList);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						hql += " db.patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;
					case "providerName": {
						/*
						 * List<String> providerNameList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName()); hql +=
						 * " db.providerName IN :providerName ";
						 */
						hql += " db.providerId IN :providerIds";
						parameters.put("providerIds", req.getProviderIdList());
					}
						break;

					case "dateOfService":
						hql += " db.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate", dateFormat.parse(req.getStartDOSDate()));
						parameters.put("endDOSDate", dateFormat.parse(req.getEndDOSDate()));
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " db.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;

					default:
						break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList2(req, hql);

			} else {
				hql += " order by LOWER(db.receivedDate) asc";
			}

			// new comment

			log.debug("parameters : " + parameters);

			log.info("Deficiency Aging Report Query : {}", hql);
			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			query.setProperties(parameters);
			if (isPagination) {
				query.setFirstResult(req.getIndex());
				query.setMaxResults(pageSize);
			}
			reports = query.list();

			int count = reports.size() + req.getIndex();
			listCount.put("Count", count);
			listCount.put("data", reports);
			// reports = session.createQuery(hql).setProperties(parameters).list();

		} catch (Exception e) {
			log.error("Exception occurred while fetching DeficiencyAging report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch Deficiencyaging report", e);
		}
		return reports;
	}

	private String sortList2(ReconReportReq req, String hql) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "desc" : "asc";

		switch (sortBy.toLowerCase()) {
		case "bbc":
			hql += " order by LOWER(db.snfLocationBBC) " + order;
			break;
		case "facilityname":
			hql += " order by LOWER(db.facilityAlias) " + order;
			break;
		case "providername":
			hql += " order by LOWER(db.providerName) " + order;
			break;
		case "patientname":
			hql += " order by LOWER(db.patientName) " + order;
			break;
		case "dateofservice":
			hql += " order by db.dateOfService " + order;
			break;
		case "visitid":
			hql += " order by db.visitId " + order;
			break;
		default:
			hql += " order by LOWER(" + sortBy + ") " + order;
			break;
		}
		return hql;
	}

	@Override
	public List<WeeklyIncompleteReportData> weeklyIncompleteReportExcel(ReconReportReq req)
			throws EncodeExceptionHandler {
		List<WeeklyIncompleteReportData> reportList = new ArrayList<>();
		// SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		try {

			StringBuilder hql = new StringBuilder("SELECT ");

			hql.append(
					"s.bluebookId, s.facilityId, s.facilityAlias, s.providerName, s.visitId, s.patientName, s.dateOfService ");

			hql.append("FROM Dashboard s");

			if (startDate != null) {
				hql.append(" WHERE s.dateOfService >= :startDate");
			}

			if (endDate != null) {
				hql.append(" AND s.dateOfService <= :endDate");
			}

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			log.info("query1 : {}", hql);

			if (startDate != null) {
				query.setParameter("startDate", startDate);
			}
			if (endDate != null) {
				query.setParameter("endDate", endDate);
			}
			log.info("query1 : {}", hql);

			List<Object[]> results = query.list();

			log.debug("results............." + results);

			reportList = results.stream().map(result -> {
				WeeklyIncompleteReportData sb = new WeeklyIncompleteReportData();

				sb.setBluebookId((String) result[0]);
				sb.setFacilityId((Integer) result[1]);
				sb.setFacilityAlias((String) result[2]);
				sb.setProviderName((String) result[3]);
				sb.setVisitId((long) result[4]);
				sb.setPatientName((String) result[5]);
				sb.setDateOfService((Timestamp) result[6]);

				return sb;
			}).collect(Collectors.toList());

		} catch (Exception e) {
			log.error("Exception occurred while fetching Weekly Incomplete Report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch weekly incomplete report", e);
		}
		return reportList;
	}

	@Override
	public List<WeeklyIncompleteReportData> getWeeklyIncompleteList(String facilityId) throws EncodeExceptionHandler {
		List<WeeklyIncompleteReportData> reportList = new ArrayList<>();
		try {

			StringBuilder hql = new StringBuilder("SELECT");

			hql.append(" s.bluebookId, s.facilityId, s.facilityAlias, s.providerName, "
					+ "s.visitId, s.patientName, s.dateOfService");

			hql.append(" FROM Dashboard s WHERE s.status = 'Received' " + "AND s.encounterType != 'Nurse Visit'");

			if (facilityId != null && !facilityId.isEmpty()) {
				hql.append(" AND s.facilityId = :facilityId");
			}

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);

			log.info("query1 : {}", hql);

			if (facilityId != null && !facilityId.isEmpty()) {
				query.setParameter("facilityId", Integer.parseInt(facilityId));
			}

			log.info("query1 : {}", hql);

			List<Object[]> results = query.list();

			log.debug("results............." + results);

			reportList = results.stream().map(result -> {
				WeeklyIncompleteReportData sb = new WeeklyIncompleteReportData();

				sb.setBluebookId((String) result[0]);
				sb.setFacilityId((Integer) result[1]);
				sb.setFacilityAlias((String) result[2]);
				sb.setProviderName((String) result[3]);
				sb.setVisitId((long) result[4]);
				sb.setPatientName((String) result[5]);
				sb.setDateOfService((Timestamp) result[6]);

				return sb;
			}).collect(Collectors.toList());

			Collections.sort(reportList, new Comparator<WeeklyIncompleteReportData>() {
				public int compare(WeeklyIncompleteReportData o1, WeeklyIncompleteReportData o2) {
					return o1.getDateOfService().compareTo(o2.getDateOfService());
				}
			});

		} catch (Exception e) {
			log.error("Exception occurred while fetching Weekly Incomplete Report by facilityId: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch weekly incomplete report", e);
		}
		return reportList;
	}

	@Override
	public List<ReconReportData> getReconciliationReports(ReconReportReq req) throws EncodeExceptionHandler {
		List<ReconReportData> reportList = new ArrayList<>();
		Map<String, Object> param = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		Map<String, String> sortColumnMapping = new HashMap<>();
		sortColumnMapping.put("bluebookId", "r.snfLocationBBC");
		sortColumnMapping.put("visitId", "r.visitId");
		sortColumnMapping.put("patientDos", "r.patientDos");
		sortColumnMapping.put("patientName", "r.patientName");
		sortColumnMapping.put("status", "r.status");
		sortColumnMapping.put("serviceLine", "r.serviceLine");
		sortColumnMapping.put("codingTeam", "r.team");
		sortColumnMapping.put("providerName", "r.providerName");
		sortColumnMapping.put("deficiencyReason", "r.deficiencyReason");
		try {
			// Fetch min and max dates if either startDate or endDate is null
			if (startDate == null || endDate == null) {
				StringBuilder dateQuery = new StringBuilder(
						"SELECT MIN(r.patientDos), MAX(r.patientDos) FROM ReconReport r WHERE 1=1");

				if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
					dateQuery.append(" AND r.snfLocationBBC IN :bluebookIds");
				}
				if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
					dateQuery.append(" AND r.providerName IN :providerNames");
				}
				// if (req.getFacilityTypeList() != null &&
				// !req.getFacilityTypeList().isEmpty()) {
				// dateQuery.append(" AND CASE WHEN r.ihealConfig = 'EMR' THEN 'i-heal' ELSE
				// 'non-i-heal' END IN :ihealConfig");
				// }
				if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
					dateQuery.append(" AND r.ihealConfig IN :locationTypeList");
				}
				if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
					dateQuery.append(" AND r.facilityType IN :facilityTypeList");
				}
				if (req.getStatus() != null && !req.getStatus().isEmpty()) {
					dateQuery.append(" AND r.status IN :status");
				}
				if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
					dateQuery.append(" AND r.providerId IN :providerIds");
				}
				if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
					dateQuery.append(" AND r.facilityId IN :facilityIds");
				}
				if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
					dateQuery.append(" AND r.team IN :codingTeamList");
				}
				if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
					dateQuery.append(" AND (");
					for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
						dateQuery.append("r.deficiencyReason like :deficiencyReason" + i);
						if (i < req.getDeficiencyReason().size() - 1) {
							dateQuery.append(" OR ");
						}
						param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
					}
					dateQuery.append(")");
				}

				Query<Object[]> dateQueryResult = sessionFactory.getCurrentSession().createQuery(dateQuery.toString(),
						Object[].class);

				if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
					dateQueryResult.setParameterList("bluebookIds", req.getBbcList());
				}
				if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
					dateQueryResult.setParameterList("providerNames", req.getProviderNameList());
				}
				if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
					dateQueryResult.setParameterList("locationTypeList", req.getLocationTypeList());
				}
				if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
					dateQueryResult.setParameterList("facilityTypeList", req.getFacilityTypeList());
				}
				if (req.getStatus() != null && !req.getStatus().isEmpty()) {
					dateQueryResult.setParameterList("status", req.getStatus());
				}
				if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
					dateQueryResult.setParameterList("providerIds", req.getProviderIdList());
				}
				if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
					dateQueryResult.setParameterList("facilityIds", req.getFacilityIdList());
				}
				if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
					dateQueryResult.setParameterList("codingTeamList", req.getCodingTeamList());
				}

				List<Object[]> dateResults = dateQueryResult.list();
				if (!dateResults.isEmpty()) {
					Object[] dateRange = dateResults.get(0);
					if (startDate == null && dateRange[0] != null) {
						startDate = (Date) dateRange[0];
					}
					if (endDate == null && dateRange[1] != null) {
						endDate = (Date) dateRange[1];
					}
				}
			}

			StringBuilder hql = new StringBuilder("SELECT r.visitId, r.snfLocationBBC, r.ihealConfig, r.facilityId, "
					+ "r.medicalRecordNumber, r.patientDos, r.patientName, r.status, r.providerName, r.providerId, r.serviceLine, r.team, r.deficiencyReason "
					+ "FROM ReconReport r WHERE (r.patientDos BETWEEN :startDate AND :endDate)");

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND r.snfLocationBBC IN :bluebookIds");
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND r.providerName IN :providerNames");
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND r.ihealConfig IN :locationTypeList");
			}
			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
				hql.append(" AND r.facilityType IN :facilityTypeList");
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				hql.append(" AND r.status IN :status");
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND r.providerId IN :providerIds");
			}
			if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
				hql.append(" AND r.facilityId IN :facilityIds");
			}
			if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
				hql.append(" AND r.team IN :codingTeamList");
			}
			if (req.getDeficiencyReason() != null && !req.getDeficiencyReason().isEmpty()) {
				hql.append(" AND (");
				for (int i = 0; i < req.getDeficiencyReason().size(); i++) {
					hql.append("r.deficiencyReason like :deficiencyReason" + i);
					if (i < req.getDeficiencyReason().size() - 1) {
						hql.append(" OR ");
					}
					param.put("deficiencyReason" + i, "%" + req.getDeficiencyReason().get(i) + "%");
				}
				hql.append(")");
			}
			// Sorting logic
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				String sortByColumn = sortColumnMapping.get(req.getSortBy());
				if (sortByColumn != null) {
					hql.append(" ORDER BY ").append(sortByColumn);
					if (req.getOrder() == 0) {
						hql.append(" ASC");
					} else {
						hql.append(" DESC");
					}
				}
			}

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);

			query.setParameter("startDate", startDate);
			query.setParameter("endDate", endDate);
			query.setProperties(param);
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query.setParameterList("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query.setParameterList("providerNames", req.getProviderNameList());
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query.setParameterList("locationTypeList", req.getLocationTypeList());
			}
			if (req.getFacilityTypeList() != null && !req.getFacilityTypeList().isEmpty()) {
				query.setParameterList("facilityTypeList", req.getFacilityTypeList());
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				query.setParameterList("status", req.getStatus());
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				query.setParameterList("status", req.getStatus());
			}
			if (req.getStatus() != null && !req.getStatus().isEmpty()) {
				query.setParameterList("status", req.getStatus());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				query.setParameterList("providerIds", req.getProviderIdList());
			}
			if (req.getFacilityIdList() != null && !req.getFacilityIdList().isEmpty()) {
				query.setParameterList("facilityIds", req.getFacilityIdList());
			}
			if (req.getCodingTeamList() != null && !req.getCodingTeamList().isEmpty()) {
				query.setParameterList("codingTeamList", req.getCodingTeamList());
			}

			log.debug("query : " + query);

			List<Object[]> results = query.list();

			reportList = results.stream().map(result -> {
				/*
				 * String childBbc = null; String hql1 =
				 * "Select c.childBluebookId FROM ChartDetails c where c.visitId =:visitId";
				 * Query query1 = sessionFactory.getCurrentSession().createQuery(hql1);
				 * query1.setParameter("visitId",(Long) result[0]); childBbc =
				 * (String)query1.uniqueResult();
				 * 
				 * if(childBbc != null && !childBbc.isEmpty()){ res.setBluebookId(childBbc);
				 * }else{ res.setBluebookId((String) result[1]);
				 * 
				 * }
				 */
				ReconReportData res = new ReconReportData();
				res.setVisitId((Long) result[0]);
				res.setBluebookId((String) result[1]);
				res.setFacilityType((String) result[2]);
				res.setFacilityId((Integer) result[3]);
				res.setMedicalRecordNumber((String) result[4]);
				Date patientDos = (Date) result[5];
				res.setPatientDos(dateFormat.format(patientDos));
				res.setPatientName((String) result[6]);
				res.setStatus((String) result[7]);
				res.setProviderName((String) result[8]);
				res.setProviderId((String) result[9]);
				res.setServiceLine((String) result[10]);
				res.setCodingTeam((String) result[11]);
				String deficiencyReason = (String) result[12];
				log.debug("deficiencyReason=========" + deficiencyReason);
				if (deficiencyReason != null) {

					String cleanDeficiencyReason = deficiencyReason.replaceAll("[\\[\\]\"]", "").replace("\\", "");
					List<String> deficiencyReasonList = Arrays.asList(cleanDeficiencyReason.split(","));

					log.debug("deficiencyReason=========" + deficiencyReasonList);
					res.setDeficiencyReason(deficiencyReasonList);
				} else {
					List<String> reasons = new ArrayList<>();
					res.setDeficiencyReason(reasons);
				}
				return res;
			}).collect(Collectors.toList());
		} catch (Exception e) {
			log.error("Exception occurred while fetching reconciliation report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch reconciliation report", e);
		}
		return reportList;
	}

//
	@Override
	public List<Object[]> getprovidersFromDashboard() throws EncodeExceptionHandler {
		String hql = "Select d.providerId,d.providerName FROM Dashboard d";
		Session session = sessionFactory.getCurrentSession();
		Query<Object[]> query = session.createQuery(hql, Object[].class);
		log.info("query : {}", hql);
		return query.getResultList();
	}

	@Override
	public List<Object[]> getMonthlyChargeSummaryReport(ReconReportReq req) throws EncodeExceptionHandler {

		List<Object[]> reports = new ArrayList<>();
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();

		try {
			/*
			 * String hql =
			 * "SELECT m.codeCount, m.cptCode FROM MonthlyChargeSummaryProcedureReport m " +
			 * "LEFT JOIN ChartDetails cd ON m.visitId = cd.visitId WHERE 1=1 ";
			 */
			String hql = "SELECT COUNT(DISTINCT m.visitId) AS codeCount, m.cptCode FROM AuditFiltersSource m "
					+ "LEFT JOIN ChartDetails cd ON m.visitId = cd.visitId WHERE 1=1 ";

			if (req.getIsAll() != null && !req.getIsAll()) {
				if (req.getCptCodes() != null && !req.getCptCodes().isEmpty()) {
					if (req.getCptCodes().contains(",")) {
						String[] cptCodes = req.getCptCodes().split(",");

						hql += " AND m.cptCode IN :cptCode";
						parameters.put("cptCode", Arrays.asList(cptCodes));
					} else {
						hql += " AND m.cptCode = :cptCode";
						parameters.put("cptCode", req.getCptCodes());
					}
				}
				if (req.getStartDate() != null && req.getEndDate() != null) {
					// hql += " AND m.dateOfService BETWEEN :startDate AND :endDate";
					hql += " AND m.patientDOS BETWEEN :startDate AND :endDate";
					parameters.put("startDate", req.getStartDate());
					parameters.put("endDate", req.getEndDate());
				}
				if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
					// hql += " AND m.bluebookId IN :bbcList";
					hql += " AND (m.bluebookId IN (:bbcList) OR cd.childBluebookId IN (:bbcList))";
					parameters.put("bbcList", req.getBbcList());
				}
				if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
					hql += " AND m.providerName IN :providerNameList";
					parameters.put("providerNameList", req.getProviderNameList());
				}
				if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
					hql += " AND m.providerId IN :providerIds";
					List<String> providerIdList = req.getProviderIdList();
					List<Long> providerIdLongList = providerIdList.stream().map(Long::parseLong)
							.collect(Collectors.toList());
					parameters.put("providerIds", providerIdLongList);
				}

				/*
				 * if(req.getLocationTypeList() !=null && !req.getLocationTypeList().isEmpty())
				 * { if(req.getLocationTypeList().contains("i-heal") &&
				 * !req.getLocationTypeList().contains("non-i-heal")) { hql +=
				 * " AND m.ihealConfig IN :ihealConfig"; parameters.put("ihealConfig", "EMR"); }
				 * if(req.getLocationTypeList().contains("non-i-heal") &&
				 * !req.getLocationTypeList().contains("i-heal")){ hql +=
				 * " AND m.ihealConfig NOT IN :ihealConfig"; parameters.put("ihealConfig",
				 * "EMR"); } }
				 */
				if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
					hql += " AND m.ihealConfig IN :locationTypeList";
					parameters.put("locationTypeList", req.getLocationTypeList());
				}
				if (req.getFacilityIdList() != null) {
					hql += " AND m.facilityId IN :facilityIdList";
					parameters.put("facilityIdList", req.getFacilityIdList());
				}
			}
			hql += " GROUP BY m.cptCode";
			log.info("MonthlyChargeSummaryQUery : {}", hql);
			Query<Object[]> query = session.createQuery(hql, Object[].class);
			parameters.forEach(query::setParameter);
			reports = query.list();

		} catch (Exception e) {
			log.error("Exception occurred while fetching MonthlyChargeSummary report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch MonthlyChargeSummary report", e);
		}
		return reports;
	}

	@Override
	public FilterOptions getAuditReportFilterOptions(ReportFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Map<String, Object> parameters = new HashMap<>();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = " WHERE 1=1";
			if (req.getStartDate() != null && req.getEndDate() != null) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(req.getStartDate());
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

				calendar.setTime(req.getEndDate());
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				calendar.set(Calendar.MILLISECOND, 999);
				Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

				query += " AND auditDate BETWEEN :startDate AND :endDate";
				parameters.put("startDate", startOfDay);
				parameters.put("endDate", endOfDay);
			}
			if (req.getFilterName() != null && !req.getFilterName().isEmpty()) {
				query += " AND filterName IN :filterName";
				parameters.put("filterName", req.getFilterName());
			}
			String filterColumn = req.getFilterOptions();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";
					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " sendingFacility IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "coderName": {
						List<String> coderNameList = FilterRequestUtil.getListFromDelimitedStr(req.getCoderName());
						query += " coderName IN :coderName ";
						parameters.put("coderName", coderNameList);
					}
						break;
					case "codingTeam": {
						List<String> codingTeamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						query += " team IN :team ";
						parameters.put("team", codingTeamList);
					}
						break;

					case "providerName": {
						List<String> providerNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getProviderName());
						query += " provider IN :provider ";
						parameters.put("provider", providerNameList);
					}
						break;

					case "dateOfService": {
						query += " dos BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					/*
					 * case "codingError" : { List<String> medicalRecordNumberList =
					 * FilterRequestUtil .getListFromDelimitedStr( req.get)); query +=
					 * " medicalRecordNumber IN :medicalRecordNumber ";
					 * parameters.put("medicalRecordNumber", medicalRecordNumberList); } break;
					 */
					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;

					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("providerName")) {
				filterColumn = "provider";
			}
			if (req.getFilterOptions().equalsIgnoreCase("coderName")) {
				filterColumn = "coderName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("codingTeam")) {
				filterColumn = "team";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "sendingFacility";
			}
			if (req.getFilterOptions().equalsIgnoreCase("codingError")) {
				filterColumn = "codingError";
			}
			if (req.getFilterOptions().equalsIgnoreCase("filterName")) {
				filterColumn = "filterName";
			}

			if (req.getFilterOptions().equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(dos), MAX(dos) FROM AuditCompliancePostAuditReport " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM AuditCompliancePostAuditReport " + query
						+ "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else if (req.getFilterOptions().equalsIgnoreCase("codingError")) {
				String hql1 = "SELECT DISTINCT CASE WHEN codingError = true THEN 'Yes' ELSE 'No' END FROM AuditCompliancePostAuditReport "
						+ query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM AuditCompliancePostAuditReport " + query
						+ " ORDER BY LOWER(" + filterColumn + ") asc";
				log.debug("hql:................  {}", hql);
				List<String> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}", e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public Map<String, Object> getFilteredPostAuditReport(ReportFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<AuditHistory> auditReport = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			// String hql = " SELECT a, b.cocId, b.childBluebookId FROM Dashboard a"
			// +" JOIN ChartDetails b ON a.visitId = b.visitId WHERE 1 = 1";

			String hql = " FROM AuditCompliancePostAuditReport a WHERE 1 = 1";
			// String hql = "SELECT DISTINCT(visitId),coderName,team,"
			// + " provider,sendingFacility,dos,chartCodes,codingError,auditNotes FROM
			// AuditCompliancePostAuditReport WHERE 1=1";

			if (req.getStartDate() != null && req.getEndDate() != null) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(req.getStartDate());
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

				calendar.setTime(req.getEndDate());
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				calendar.set(Calendar.MILLISECOND, 999);
				Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

				hql += " AND a.auditDate BETWEEN :startDate AND :endDate";
				parameters.put("startDate", startOfDay);
				parameters.put("endDate", endOfDay);
			}
			if (req.getFilterName() != null && !req.getFilterName().isEmpty()) {
				hql += " AND a.filterName IN :filterName";
				parameters.put("filterName", req.getFilterName());
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "bbc": {
						List<String> bbcList1 = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.sendingFacility IN :bbc";
						parameters.put("bbc", bbcList1);
					}
						break;
					case "visitId": {
						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;

					case "coderName": {
						List<String> names = FilterRequestUtil.getListFromDelimitedStr(req.getCoderName());
						log.debug("firstNames...." + names);
						hql += " a.coderName IN :coderName ";
						parameters.put("coderName", names);
					}
						break;
					case "codingTeam": {
						List<String> codingTeams = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						hql += " team IN :team ";
						parameters.put("team", codingTeams);
					}
						break;
					case "providerName": {
						List<String> providerList = FilterRequestUtil.getListFromDelimitedStr(req.getProviderName());
						hql += " a.provider IN :provider ";
						parameters.put("provider", providerList);
					}
						break;
					case "codingError": {
						List<String> codingErrorList = FilterRequestUtil
								.getListFromDelimitedStr(String.valueOf(req.getCodingError()));
						// List<String> codingErrorList =
						// FilterRequestUtil.getListFromDelimitedStr(req.getCodingError());
						log.debug("codingErrorList==========" + codingErrorList);
						List<Boolean> booleanList = new ArrayList<>();
						for (String str : codingErrorList) {
							booleanList.add(Boolean.parseBoolean(str));
						}
						hql += " a.codingError IN :codingError ";
						parameters.put("codingError", booleanList);
					}
						break;
					/*
					 * case "codingError": { List<String> codingErrorList =
					 * FilterRequestUtil.getListFromDelimitedStr(req.getCodingErrors());
					 * log.debug("codingErrorList=========="+codingErrorList); List<Boolean>
					 * booleanList = new ArrayList<>(); for (String str : codingErrorList) {
					 * booleanList.add(Boolean.parseBoolean(str)); } hql +=
					 * " a.codingError IN :codingError "; parameters.put("codingError",booleanList);
					 * } break;
					 */

					case "dateOfService": {
						hql += " a.dos BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;
					default:
						break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortLists(req, hql);

			} else {
				hql += " order by LOWER(a.sendingFacility) asc";
			}

			log.info("query : {}", hql.toString());

			log.debug("parameters : " + parameters);

			auditReport = session.createQuery(hql).setProperties(parameters).list();
			int count = auditReport.size() + req.getIndex();
			listCount.put("Count", count);
			listCount.put("data", auditReport);
			log.debug("coderDashboard List Size:   {} ", count);
		} catch (Exception e) {
			log.error("Exception occured while fetching filtered report Records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	private String sortLists(ReportFilterReq req, String hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("bbc")) {
			hql += " order by LOWER(a.sendingFacility) ";
		} else if (sortBy.equals("visitId")) {
			hql += " order by LOWER(a.visitId) ";
		} else if (sortBy.equals("coderName")) {
			hql += " order by LOWER(a.coderName) ";
		} else if (sortBy.equals("codingTeam")) {
			hql += " order by LOWER(a.team) ";
		} else if (sortBy.equals("providerName")) {
			hql += " order by LOWER(provider) ";
		} else if (sortBy.equals("dateOfService")) {
			hql += " order by LOWER(a.dos) ";
		} else if (sortBy.equals("auditDate")) {
			hql += " order by LOWER(a.auditDate) ";
		} else if (sortBy.equals("filterName")) {
			hql += " order by LOWER(a.filterName) ";
		} else {
			hql += " order by LOWER(a." + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public ReconReportFilter getReconReportFilterOptions(ReconReportReq req, int pazeSize, int index,
			boolean isPagination) throws EncodeExceptionHandler {
		ReconReportFilter reconReportFilter = new ReconReportFilter();
		try {

			List<ReconReportData> reportList = getReconciliationReport(req, pazeSize, index, isPagination);

			Set<String> distinctValues = new HashSet<>();

			switch (req.getFilterOptions().toLowerCase()) {
			case "bluebookid":
				distinctValues = reportList.stream().map(ReconReportData::getBluebookId).filter(Objects::nonNull)
						.collect(Collectors.toSet());
				break;
			case "visitid":
				distinctValues = reportList.stream().map(report -> String.valueOf(report.getVisitId()))
						.collect(Collectors.toSet());
				break;
			case "patientname":
				distinctValues = reportList.stream().map(ReconReportData::getPatientName).filter(Objects::nonNull)
						.collect(Collectors.toSet());
				break;
			case "status":
				distinctValues = reportList.stream().map(ReconReportData::getStatus).filter(Objects::nonNull)
						.collect(Collectors.toSet());
				break;
			case "serviceline":
				distinctValues = reportList.stream().map(ReconReportData::getServiceLine).filter(Objects::nonNull)
						.collect(Collectors.toSet());
				break;

			case "deficiencyreason":

				for (ReconReportData report : reportList) {
					for (String reason : report.getDeficiencyReason()) {
						log.debug(reason);
						distinctValues.add(reason);
					}
				}
				log.debug("distinct={}", distinctValues);
				break;
			case "providername":
				distinctValues = reportList.stream().map(ReconReportData::getProviderName).filter(Objects::nonNull)
						.collect(Collectors.toSet());

				break;
			case "pendingreason":

				distinctValues = reportList.stream().map(ReconReportData::getPendingReason).filter(Objects::nonNull)
						.collect(Collectors.toSet());

				log.debug("distinct={}", distinctValues);
				break;
			case "coderfullname":

				distinctValues = reportList.stream().map(ReconReportData::getCoderFullname).filter(Objects::nonNull)
						.collect(Collectors.toSet());

				log.debug("distinct={}", distinctValues);
				break;

			default:

				log.warn("Unknown filter column: {}", req.getFilterOptions());
				break;
			}
			// Sort the distinct values such that uppercase letters come before lowercase
			// ones
			List<String> sortedDistinctValues = new ArrayList<>(distinctValues);
			Collections.sort(sortedDistinctValues, new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					// Custom comparator to handle case-insensitive sorting but keep case order
					return Collator.getInstance(Locale.ENGLISH).compare(o1, o2);
				}
			});

			reconReportFilter.setOptions(sortedDistinctValues);
		} catch (Exception e) {
			log.error("Exception occurred while fetching filter options: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch filter options", e);
		}
		return reconReportFilter;
	}

	@Override
	public MissingChartFilter getMissingChartFilterOption(ReconReportReq req) throws EncodeExceptionHandler {
		MissingChartFilter missingChartFilter = new MissingChartFilter();
		MissingChartFilterOptionsRes res = new MissingChartFilterOptionsRes();
		List<DrillDownMissingChartObj> reportsList = new ArrayList<>();
		try {
			log.info("Fetching missing chart filter options for request: {}", req);

			List<Object[]> reportList = getDrillDownMissingChartReport(req);
			log.info("getMissingChartFilterOption called");

			if (reportList == null) {
				log.warn("The reportList is null.");
			} else if (reportList.isEmpty()) {
				log.warn("The reportList is empty.");
			} else {
				log.info("Fetched report data: {}", reportList);
			}

			try {
				if (reportList != null && !reportList.isEmpty()) {

					for (Object[] report : reportList) {
						DrillDownMissingChartObj summaryObj = new DrillDownMissingChartObj();

						summaryObj.setBluebookId((String) report[1]);
						summaryObj.setVisitId((long) report[0]);
						summaryObj.setFacilityName((String) report[2]);
						summaryObj.setDateOfService((Date) report[4]);
						summaryObj.setProviderName((String) report[3]);
						summaryObj.setPatientName((String) report[5]);
						summaryObj.setStatus((String) report[6]);

						reportsList.add(summaryObj);
					}

				}
			} catch (Exception e) {
				log.error("Exception occurred while mapping missing chart : {}", e.getMessage());
				throw new EncodeExceptionHandler("Failed to fetch missing chart ", e);
			}
			Set<String> distinctValues = new HashSet<>();
			// Selecting distinct filter options based on the filter column
			log.info("Processing filter option: {}", req.getFilterOptions());
			switch (req.getFilterOptions().toLowerCase()) {
			case "bluebookid":
				distinctValues = reportsList.stream().map(report -> report.getBluebookId()).filter(Objects::nonNull)
						.collect(Collectors.toSet());
				log.info("Distinct bluebookId values: {}", distinctValues);
				break;
			case "providername":
				distinctValues = reportsList.stream().map(DrillDownMissingChartObj::getProviderName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				log.info("Distinct providerName values: {}", distinctValues);
				break;
			case "visitid":
				distinctValues = reportsList.stream().map(report -> String.valueOf(report.getVisitId()))
						.collect(Collectors.toSet());
				log.info("Distinct visitId values: {}", distinctValues);
				break;
			case "patientname":
				distinctValues = reportsList.stream().map(DrillDownMissingChartObj::getPatientName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				log.info("Distinct patientName values: {}", distinctValues);
				break;
			default:
				log.warn("Unknown filter column: {}", req.getFilterOptions());
				break;
			}
			// Sorting the distinct values in a case-insensitive manner
			List<String> sortedDistinctValues = new ArrayList<>(distinctValues);
			Collections.sort(sortedDistinctValues, new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					return Collator.getInstance(Locale.ENGLISH).compare(o1, o2);
				}
			});
			log.info("Sorted distinct values: {}", sortedDistinctValues);
			missingChartFilter.setOptions(sortedDistinctValues);

		} catch (Exception e) {
			log.error("Exception occurred while fetching missing chart filter options: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
			throw new EncodeExceptionHandler("Failed to fetch missing chart filter options", e);

		}
		log.info("Returning missing chart filter options: {}", missingChartFilter);
		return missingChartFilter;
	}

	public FilterOptions getDeficiencyAgingMultiFilterOptions(ReportFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = " WHERE 1=1 AND status = 'Deficiency' AND eventDatetime < :endDate";
			String filterColumn = req.getFilterOptions();
			Map<String, Object> parameters = new HashMap<>();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";
					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "facilityName": {
						List<String> facilityNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityName());
						query += " facilityAlias IN :facilityAlias ";
						parameters.put("facilityAlias", facilityNameList);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						query += " patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;

					case "providerName": {
						/*
						 * List<String> providerNameList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName());
						 */
						query += " providerId IN :providerIds ";
						parameters.put("providerIds", req.getProviderIdList());
					}
						break;

					case "dateOfService": {
						query += " dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;

					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("patientName")) {
				filterColumn = "patientName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("providerName")) {
				filterColumn = "providerName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("facilityName")) {
				filterColumn = "facilityAlias";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "snfLocationBBC";
			}
			if (req.getFilterOptions().equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(dateOfService), MAX(dateOfService) FROM Dashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("endDate", req.getEndDate())
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(visitId as string) FROM Dashboard " + query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setParameter("endDate", req.getEndDate())
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard " + query + " ORDER BY LOWER(" + filterColumn
						+ ") asc";
				log.debug("hql:................  {}", hql);
				List<String> distinctValues = session.createQuery(hql).setParameter("endDate", req.getEndDate())
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options for eficiency Aging Report : {}",
					e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public FilterOptions getSuperbillVarianceMultiFilterOptions(ReportFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		Map<String, Object> parameters = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = " WHERE 1=1 AND a.potentialCptCode != a.actualCptCode";
			if (req.getStartDate() != null) {
				query += " AND a.dateOfService >= :startDate";
			}

			if (req.getEndDate() != null) {
				query += " AND a.dateOfService <= :endDate";
			}
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				// hql+= " AND (s.bluebookId IN (:bluebookIds) OR cd.childBluebookId IN
				// (:bluebookIds))";
				query += " AND a.bluebookId IN :bluebookIds";
				parameters.put("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query += " AND a.providerName IN (:providerNames)";
				parameters.put("providerNames", req.getProviderNameList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				query += " AND a.providerId IN :providerIds";
				List<String> providerIdList = req.getProviderIdList();
				List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
						.collect(Collectors.toList());
				parameters.put("providerIds", providerIdIntList);
			}
			if (req.getFacilityIdList() != null) {
				query += " AND a.facilityId IN (:facilityId)";
				parameters.put("facilityId", req.getFacilityIdList());
			}

			if (req.getFacilityId() > 0) {
				query += " AND a.facilityId = :facilityId";
				parameters.put("facilityId", req.getFacilityId());
			}

			if (req.getProviderId() != 0) {
				query += " AND a.providerId = :providerId";
				parameters.put("providerId", req.getProviderId());
			}
			String filterColumn = req.getFilterOptions();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";
					switch (filterReq) {
					case "bluebookId": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBluebookId());
						query += " a.bluebookId IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "providerName": {
						/*
						 * List<String> primaryproviderList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName()); query +=
						 * " a.providerName IN :providerName "; parameters.put("providerName",
						 * primaryproviderList);
						 */
						query += " a.providerId IN :providerIds";
						List<String> providerIdList = req.getProviderIdList();
						List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
								.collect(Collectors.toList());
						parameters.put("providerIds", providerIdIntList);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						query += " a.patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;

					case "dos": {
						query += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "dateBilled": {
						query += " a.dateBilled BETWEEN :startDateBilled AND :endDateBilled ";
						parameters.put("startDateBilled",
								new Timestamp(dateFormat.parse(req.getStartDateBilled()).getTime()));
						parameters.put("endDateBilled",
								new Timestamp(dateFormat.parse(req.getEndDateBilled()).getTime()));
					}
						break;

					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("patientName")) {
				filterColumn = "a.patientName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("providerName")) {
				filterColumn = "a.providerName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bluebookId")) {
				filterColumn = "a.bluebookId";
			}
			if (req.getFilterOptions().equalsIgnoreCase("dos")) {
				String dateHql = "SELECT MIN(a.dateOfService), MAX(a.dateOfService) FROM SuperbillVariance a " + query
						+ "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("startDate", req.getStartDate())
						.setParameter("endDate", req.getEndDate()).setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("dateBilled")) {
				String dateHql = "SELECT MIN(a.dateBilled), MAX(a.dateBilled) FROM SuperbillVariance a " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("startDate", req.getStartDate())
						.setParameter("endDate", req.getEndDate()).setProperties(parameters).uniqueResult();

				filterOptions.setMinReceivedDate((Timestamp) object[0]);
				filterOptions.setMaxReceivedDate((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(a.visitId as string) FROM SuperbillVariance a " + query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setParameter("startDate", req.getStartDate())
						.setParameter("endDate", req.getEndDate()).setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM SuperbillVariance a " + query + " ORDER BY LOWER("
						+ filterColumn + ") asc";
				log.debug("hql:................  {}", hql);
				List<String> distinctValues = session.createQuery(hql).setParameter("startDate", req.getStartDate())
						.setParameter("endDate", req.getEndDate()).setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options for eficiency Aging Report : {}",
					e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public Map<String, Object> deficiencyAgingReportFilteredData(ReconReportReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> report = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		int pazeSize = PAGE_SIZE;
		boolean isPagination = req.isPagination();
		try {
			// String hql = " SELECT a, b.cocId, b.childBluebookId FROM Dashboard a"
			// +" JOIN ChartDetails b ON a.visitId = b.visitId WHERE 1 = 1";

//			String hql = "SELECT a, cd.deficiencyStartDate, cd.deficiencyReason FROM Dashboard a LEFT JOIN ChartDetails AS cd ON a.visitId = cd.visitId WHERE 1 = 1 AND cd.deficiencyStartDate < :endDate";
			String hql = "SELECT a.visitId, a.snfLocationBBC, a.facilityId, a.facilityAlias, a.patientId, a.patientName, a.ihealConfig,"
					+ " a.providerId, a.providerName, a.medicalRecordNumber,"
					+ " DATE(a.lastUpdatedByTimestamp) AS lastModified,"
					+ " DATE(cd.deficiencyStartDate) AS deficiencyDate," + " DATE(a.dateOfService) AS dateOfService,"
					+ "cd.childBluebookId," + "cd.deficiencyReason" + " FROM Dashboard AS a"
					+ " LEFT JOIN ChartDetails AS cd ON a.visitId = cd.visitId"
					+ " WHERE a.status = 'Deficiency' AND a.eventDatetime < :endDate";
			parameters.put("endDate", req.getEndDate());

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				log.debug("filterList=========" + filterList);

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "facilityName": {
						List<String> facilityNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getFacilityName());
						hql += " a.facilityAlias IN :facilityAlias ";
						parameters.put("facilityAlias", facilityNameList);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						hql += " a.patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;

					case "providerName": {
						/*
						 * List<String> providerNameList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName()); hql +=
						 * " a.providerName IN :providerName ";
						 */
						hql += " a.providerId IN :providerIds";
						parameters.put("providerIds", req.getProviderIdList());
					}
						break;

					case "dateOfService": {
						hql += " a.dateOfService BETWEEN :a.startDOSDate AND :a.endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;

					default:
						break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortListfordeficiencyAging(req, hql);

			} else {
				hql += " order by LOWER(a.receivedDate) asc";
			}

			log.info("query : {}", hql.toString());

			log.debug("parameters : " + parameters);

			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			query.setParameter("endDate", req.getEndDate());
			query.setProperties(parameters);
			if (isPagination) {
				query.setFirstResult(req.getIndex());
				query.setMaxResults(pazeSize);
			}
			report = query.list();
//			report = session.createQuery(hql).setParameter("endDate", req.getEndDate()).setProperties(parameters)
//					.list();

			int count = report.size() + req.getIndex();
			listCount.put("Count", count);
			listCount.put("data", report);
			log.debug("coderDashboard List Size:   {} ", count);
		} catch (Exception e) {
			log.error("Exception occured while fetching filtered report Records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	private String sortListfordeficiencyAging(ReconReportReq req, String hql) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "desc" : "asc";

		switch (sortBy.toLowerCase()) {
		case "bbc":
			hql += " order by LOWER(a.snfLocationBBC) " + order;
			break;
		case "facilityname":
			hql += " order by LOWER(a.facilityAlias) " + order;
			break;
		case "providername":
			hql += " order by LOWER(a.providerName) " + order;
			break;
		case "patientname":
			hql += " order by LOWER(a.patientName) " + order;
			break;
		case "dateofservice":
			hql += " order by a.dateOfService " + order;
			break;
		case "visitid":
			hql += " order by a.visitId " + order;
			break;
		default:
			hql += " order by LOWER(" + sortBy + ") " + order;
			break;
		}

		return hql;
	}

	@Override
	public UnderReviewFilter getEncounterUnderReviewFilterOption(ReconReportReq req) throws EncodeExceptionHandler {
		UnderReviewFilter reconReportFilter = new UnderReviewFilter();
		try {

			List<EncounterUnderReviewData> reportList = getEncounterUnderReviewReport(req);

			Set<String> distinctValues = new HashSet<>();

			switch (req.getFilterOptions().toLowerCase()) {
			case "bluebookid":
				distinctValues = reportList.stream().map(EncounterUnderReviewData::getBluebookId)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;
			case "visitid":
				distinctValues = reportList.stream().map(report -> String.valueOf(report.getVisitId()))
						.collect(Collectors.toSet());
				break;
			case "patientname":
				distinctValues = reportList.stream().map(EncounterUnderReviewData::getPatientName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;
			case "providername":
				distinctValues = reportList.stream().map(EncounterUnderReviewData::getProviderName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;
			case "daysinreview":
				distinctValues = reportList.stream().map(report -> String.valueOf(report.getDaysInReview()))
						.collect(Collectors.toSet());
				break;
			case "coderfullname":
				distinctValues = reportList.stream().map(report -> String.valueOf(report.getCoderFullname()))
						.collect(Collectors.toSet());
				break;
			default:
				log.warn("Unknown filter column: {}", req.getFilterOptions());
				break;
			}

			List<String> sortedDistinctValues = new ArrayList<>(distinctValues);
			Collections.sort(sortedDistinctValues, new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					// Custom comparator to handle case-insensitive sorting but keep case order
					return Collator.getInstance(Locale.ENGLISH).compare(o1, o2);
				}
			});

			reconReportFilter.setOptions(sortedDistinctValues);
		} catch (Exception e) {
			log.error("Exception occurred while fetching Encounter Under Review filter options: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch filter options", e);
		}
		return reconReportFilter;
	}

	@Override
	public Map<String, Object> getFilteredSuperbillVarianceReport(ReportFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<SuperbillVariance> superbillReport = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		try {

			String hql = " FROM SuperbillVariance a WHERE 1 = 1 AND a.potentialCptCode != a.actualCptCode ";

			if (req.getStartDate() != null) {
				hql += " AND a.dateOfService >= :startDate";
			}

			if (req.getEndDate() != null) {
				hql += " AND a.dateOfService <= :endDate";
			}
			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				// hql+= " AND (s.bluebookId IN (:bluebookIds) OR cd.childBluebookId IN
				// (:bluebookIds))";
				hql += " AND a.bluebookId IN :bluebookIds";
				parameters.put("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql += " AND a.providerName IN (:providerNames)";
				parameters.put("providerNames", req.getProviderNameList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql += " AND a.providerId IN :providerIds";

				List<String> providerIdList = req.getProviderIdList();
				List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
						.collect(Collectors.toList());
				parameters.put("providerIds", providerIdIntList);
			}
			if (req.getFacilityIdList() != null) {
				hql += " AND a.facilityId IN (:facilityIds)";
				parameters.put("facilityIds", req.getFacilityIdList());
			}
			if (req.getFacilityId() > 0) {
				hql += " AND a.facilityId = :facilityId";
				parameters.put("facilityId", req.getFacilityId());
			}

			if (req.getProviderId() != 0) {
				hql += " AND a.providerId = :providerId";
				parameters.put("providerId", req.getProviderId());
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "bluebookId": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBluebookId());
						hql += " a.bluebookId IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "providerName": {
						/*
						 * List<String> primaryproviderList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName()); hql +=
						 * " a.providerName IN :providerName "; parameters.put("providerName",
						 * primaryproviderList);
						 */

						hql += " a.providerId IN :providerIds";

						List<String> providerIdList = req.getProviderIdList();
						List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
								.collect(Collectors.toList());
						parameters.put("providerIds", providerIdIntList);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						hql += " a.patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;

					case "dos": {
						hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "dateBilled": {
						hql += " a.dateBilled BETWEEN :startDateBilled AND :endDateBilled ";
						parameters.put("startDateBilled",
								new Timestamp(dateFormat.parse(req.getStartDateBilled()).getTime()));
						parameters.put("endDateBilled",
								new Timestamp(dateFormat.parse(req.getEndDateBilled()).getTime()));
					}
						break;

					default:
						break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortListForSuperbillVariance(req, hql);

			} else {
				hql += " order by LOWER(a.bluebookId) asc";
			}

			log.info("query : {}", hql.toString());

			log.debug("parameters : " + parameters);

			superbillReport = session.createQuery(hql).setParameter("startDate", req.getStartDate())
					.setParameter("endDate", req.getEndDate()).setProperties(parameters).list();
			int count = superbillReport.size() + req.getIndex();
			listCount.put("Count", count);
			listCount.put("data", superbillReport);
			log.debug("superbillReport List Size:   {} ", count);
		} catch (Exception e) {
			log.error("Exception occured while fetching filtered report Records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	private String sortListForSuperbillVariance(ReportFilterReq req, String hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("bluebookId")) {
			hql += " order by LOWER(a.bluebookId) ";
		} else if (sortBy.equals("visitId")) {
			hql += " order by LOWER(a.visitId) ";
		} else if (sortBy.equals("providerName")) {
			hql += " order by LOWER(a.providerName) ";
		} else if (sortBy.equals("patientName")) {
			hql += " order by LOWER(a.patientName) ";
		} else if (sortBy.equals("dateBilled")) {
			hql += " order by LOWER(a.dateBilled) ";
		} else if (sortBy.equals("dos")) {
			hql += " order by LOWER(a.dateOfService) ";
		} else {
			hql += " order by LOWER(a." + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public FilterOptions getEncounterNeedingGuidenceFilterOptions(ReportFilterReq req, List<Integer> coderId)
			throws EncodeExceptionHandler {

		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = " WHERE 1=1 AND a.coderUserId IN :coderId";
			List<String> coderIdStrings = coderId.stream().map(String::valueOf).collect(Collectors.toList());
			String filterColumn = req.getFilterOptions();
			Map<String, Object> parameters = new HashMap<>();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";
					switch (filterReq) {
					case "blueBookId": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBlueBookId());
						query += " a.blueBookId IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "coderFullName": {
						List<String> coderList = FilterRequestUtil.getListFromDelimitedStr(req.getCoderFullName());
						query += " a.coderUserName IN :coder ";
						parameters.put("coder", coderList);
					}
						break;
					case "guidanceDate": {
						query += " a.guidanceDate BETWEEN :startGuidanceDate AND :endGuidanceDate ";
						parameters.put("startGuidanceDate",
								new Timestamp(dateFormat.parse(req.getStartGuidanceDate()).getTime()));
						parameters.put("endGuidanceDate",
								new Timestamp(dateFormat.parse(req.getEndGuidanceDate()).getTime()));
					}
						break;
					case "daysInGuidance": {
						List<String> daysList = FilterRequestUtil.getListFromDelimitedStr(req.getDaysInGuidance());
						List<Integer> intnosOfDaysList = new ArrayList<>();
						for (String s : daysList) {
							intnosOfDaysList.add(Integer.valueOf(s));
						}
						query += " a.daysInGuidance IN :daysInGuidance ";
						parameters.put("daysInGuidance", intnosOfDaysList);
					}
						break;

					case "dateOfService": {
						query += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("coderFullName")) {
				filterColumn = "a.coderUserName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("blueBookId")) {
				filterColumn = "a.blueBookId";
			}
			if (req.getFilterOptions().equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(a.dateOfService), MAX(a.dateOfService) FROM EncounterNeedingGuidanceReport a "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("coderId", coderIdStrings)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("guidanceDate")) {
				String dateHql = "SELECT MIN(a.guidanceDate), MAX(a.guidanceDate) FROM EncounterNeedingGuidanceReport a "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("coderId", coderIdStrings)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinGuidanceDate((Timestamp) object[0]);
				filterOptions.setMaxGuidanceDate((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(a.visitId as string) FROM EncounterNeedingGuidanceReport a " + query
						+ "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setParameter("coderId", coderIdStrings)
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else if (req.getFilterOptions().equalsIgnoreCase("daysInGuidance")) {
				String hql1 = "SELECT DISTINCT CAST(a.daysInGuidance as string) FROM EncounterNeedingGuidanceReport a "
						+ query + "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setParameter("coderId", coderIdStrings)
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM EncounterNeedingGuidanceReport a " + query
						+ " ORDER BY LOWER(" + filterColumn + ") asc";
				log.debug("hql:................  {}", hql);
				List<String> distinctValues = session.createQuery(hql).setProperties(parameters)
						.setParameter("coderId", coderIdStrings).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options for Encounters Needing Guidance : {}",
					e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public List<EncounterMonthlyReviewData> getFilteredEncounterUnderReviewmonthly(ReconReportReq req)
			throws EncodeExceptionHandler {
		List<EncounterMonthlyReviewData> reportList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		try {

			StringBuilder hql = new StringBuilder("SELECT ");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
				hql.append(
						"s.visitId, s.childBluebookId, s.patientId, s.patientName, s.providerName, s.dateOfService, s.deficiencyDate, s.deficiencyNote, s.deficiencyReason, s.coderUserId, s.coderUserFullname ");
			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
				hql.append(
						"s.visitId, s.childBluebookId, s.patientId, s.patientName, s.providerName, s.dateOfService, s.deficiencyDate, s.deficiencyNote, s.deficiencyReason, s.coderUserId, s.coderUserFullname  ");

			}

			hql.append("FROM EncounterUnderReviewReport s WHERE 1=1");

			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND s.deficiencyDate >= :startDate");
					parameters.put("startDate", req.getStartDate());
				}

				if (endDate != null) {
					hql.append(" AND s.deficiencyDate <= :endDate");
					parameters.put("endDate", req.getEndDate());
				}

			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					hql.append(" AND s.dateOfService >= :startDate");
					parameters.put("startDate", req.getStartDate());
				}

				if (endDate != null) {
					hql.append(" AND s.dateOfService <= :endDate");
					parameters.put("endDate", req.getEndDate());
				}

			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				hql.append(" AND s.childBluebookId IN :bluebookIds");
				// hql.append(" AND (s.bluebookId IN :bluebookIds OR c.childBluebookId IN
				// :bluebookIds)");
				parameters.put("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				hql.append(" AND s.providerName IN :providerNames");
				parameters.put("providerNames", req.getProviderNameList());
			}

			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				hql.append(" AND s.providerId IN :providerIds");
				List<String> providerIdList = req.getProviderIdList();
				List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
						.collect(Collectors.toList());
				parameters.put("providerIds", providerIdIntList);
			}

			if (req.getCoderFullnameList() != null && !req.getCoderFullnameList().isEmpty()) {
				hql.append(" AND s.coderUserFullname IN :coderUserFullname");

				parameters.put("coderUserFullname", req.getCoderFullnameList());
			}
			// if (req.getLocationTypeList() != null &&
			// !req.getLocationTypeList().isEmpty()) {
			// hql.append(" AND CASE WHEN s.ihealConfig = 'EMR' THEN 'i-heal' ELSE
			// 'non-i-heal' END IN :ihealConfig");
			// }

			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				hql.append(" AND s.ihealConfig IN :locationTypeList");
				parameters.put("locationTypeList", req.getLocationTypeList());
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					// hql += " AND ";

					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql.append(" AND s.childBluebookId IN :bbc ");
						parameters.put("bbc", bbcs);
					}
						break;
					case "providerName": {
						/*
						 * List<String> primaryproviderList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName());
						 * hql.append(" AND s.providerName IN :providerName ");
						 * parameters.put("providerName", primaryproviderList);
						 */
						hql.append(" AND s.providerId  IN :providerIds ");
						List<String> providerIdList = req.getProviderIdList();
						List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
								.collect(Collectors.toList());
						parameters.put("providerIds", providerIdIntList);
					}
						break;

					case "dos": {
						hql.append(" AND s.dateOfService BETWEEN :startDOSDate AND :endDOSDate ");
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "deficiencyDate": {
						hql.append(" AND s.deficiencyDate BETWEEN :deficiencyStartDate AND :deficiencyEndDate ");
						parameters.put("deficiencyStartDate",
								new Timestamp(dateFormat.parse(req.getDeficiencyStartDate()).getTime()));
						parameters.put("deficiencyEndDate",
								new Timestamp(dateFormat.parse(req.getDeficiencyEndDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql.append(" AND s.visitId IN :visitId ");
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "coderFullname": {

						hql.append(" AND s.coderUserFullname  IN :coderUserFullname ");
						parameters.put("coderUserFullname", req.getCoderFullnameList());
					}
						break;

					default:
						break;
					}
				}
			}
			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
				hql.append(" Group By s.deficiencyDate");

			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
				hql.append(" Group By s.dateOfService");
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortListfordeficiencyAgings(req, hql);

			} else {
				hql.append(" order by LOWER(s.childBluebookId) asc");
			}

			log.info("query : {}", hql.toString());

			log.debug("parameters : " + parameters);
			Query<Object[]> query = sessionFactory.getCurrentSession().createQuery(hql.toString(), Object[].class);
			log.info("query1 : {}", hql);
			// superbillReport = session.createQuery(hql)
			// .setParameter("startDate", req.getStartDate())
			// .setParameter("endDate", req.getEndDate())
			// .setProperties(parameters)
			// .list();
			// int count = query.size() + req.getIndex();
			// listCount.put("Count", count);
			// listCount.put("data", superbillReport);
			// log.debug("superbillReport List Size: {} ", count);
			// log.info("query1 : {}", hql);

			List<Object[]> results = query.setProperties(parameters).list();

			log.debug("results............." + results);

			reportList = results.stream().map(result -> {
				// String childBbc = null;
				// String hql1 = "Select c.childBluebookId FROM ChartDetails c where c.visitId
				// =:visitId";
				// Query query1 = sessionFactory.getCurrentSession().createQuery(hql1);
				// query1.setParameter("visitId",(Long) result[0]);
				// childBbc = (String)query1.uniqueResult();
				EncounterMonthlyReviewData sb = new EncounterMonthlyReviewData();
				if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {
					sb.setVisitId((Long) result[0]);
					// if(childBbc != null && !childBbc.isEmpty()){
					// sb.setBluebookId(childBbc);
					// }else{
					sb.setBluebookId((String) result[1]);
					// }
					sb.setPatientId((Integer) result[2]);
					sb.setPatientName((String) result[3]);
					sb.setProviderName((String) result[4]);
					sb.setDateOfService((Date) result[5]);
					sb.setDeficiencyDate((Date) result[6]);
					sb.setDeficiencyNote((String) result[7]);
					sb.setDeficiencyReason((String) result[8]);
					sb.setCoderUserId((String) result[9]);
					sb.setCoderFullname((String) result[10]);

				} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {
					sb.setVisitId((Long) result[0]);
					// if(childBbc != null && !childBbc.isEmpty()){
					// sb.setBluebookId(childBbc);
					// }else{
					// sb.setBluebookId((String) result[1]);
					// }
					sb.setBluebookId((String) result[1]);
					sb.setPatientId((Integer) result[2]);
					sb.setPatientName((String) result[3]);
					sb.setProviderName((String) result[4]);
					sb.setDateOfService((Date) result[5]);
					sb.setDeficiencyDate((Date) result[6]);
					sb.setDeficiencyNote((String) result[7]);
					sb.setDeficiencyReason((String) result[8]);
					sb.setCoderUserId((String) result[9]);
					sb.setCoderFullname((String) result[10]);

				}
				return sb;
			}).collect(Collectors.toList());

		} catch (Exception e) {
			log.error("Exception occurred while fetching Encounter Under Review Monthly report: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch encounter under review monthly report", e);
		}
		return reportList;
	}

	private StringBuilder sortListfordeficiencyAgings(ReconReportReq req, StringBuilder hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("bbc")) {
			hql.append(" order by LOWER(s.bluebookId) ");
		} else if (sortBy.equals("visitId")) {
			hql.append(" order by LOWER(s.visitId) ");
		} else if (sortBy.equals("providerName")) {
			hql.append(" order by LOWER(s.providerName) ");
		} else if (sortBy.equals("patientName")) {
			hql.append(" order by LOWER(s.patientName) ");
		} else if (sortBy.equals("dos")) {
			hql.append(" order by LOWER(s.dateOfService) ");
		} else if (sortBy.equals("deficiencyDate")) {
			hql.append(" order by LOWER(s.deficiencyDate) ");
		} else if (sortBy.equals("coderFullname")) {
			hql.append(" order by LOWER(s.coderUserFullname) ");
		} else {
			hql.append(" order by LOWER(s." + sortBy + ") ");
		}

		if (req.getOrder() == 0) {
			hql.append(" desc");
		} else {
			hql.append(" asc");
		}
		return hql;
	}

//
	@Override
	public List<NurseAuditNotesReportData> getNurseAuditNotesReport(NurseAuditNotesReportReq req)
			throws EncodeExceptionHandler {
		List<NurseAuditNotesReportData> reportList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Session session = this.sessionFactory.getCurrentSession();

		try {
			StringBuilder hql = new StringBuilder("FROM NurseAuditNotesReport n WHERE 1=1");

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					// hql += " AND ";

					switch (filterReq) {
					case "auditDate": {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(req.getStartAuditDate());
						calendar.set(Calendar.HOUR_OF_DAY, 0);
						calendar.set(Calendar.MINUTE, 0);
						calendar.set(Calendar.SECOND, 0);
						calendar.set(Calendar.MILLISECOND, 0);
						Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

						calendar.setTime(req.getEndAuditDate());
						calendar.set(Calendar.HOUR_OF_DAY, 23);
						calendar.set(Calendar.MINUTE, 59);
						calendar.set(Calendar.SECOND, 59);
						calendar.set(Calendar.MILLISECOND, 999);
						Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

						hql.append(" AND n.auditDate BETWEEN :startAuditDate AND :endAuditDate ");
						parameters.put("startAuditDate", startOfDay);
						parameters.put("endAuditDate", endOfDay);
					}

						break;
					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Integer> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Integer.valueOf(s));
						}
						hql.append(" AND n.visitId IN :visitId ");
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "facility": {
						List<String> primaryproviderList = FilterRequestUtil.getListFromDelimitedStr(req.getFacility());
						hql.append(" AND n.facilityAlias IN :facilityAlias ");
						parameters.put("facilityAlias", primaryproviderList);
					}
						break;

					case "dos": {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(req.getStartDOS());
						calendar.set(Calendar.HOUR_OF_DAY, 0);
						calendar.set(Calendar.MINUTE, 0);
						calendar.set(Calendar.SECOND, 0);
						calendar.set(Calendar.MILLISECOND, 0);
						Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

						calendar.setTime(req.getEndDOS());
						calendar.set(Calendar.HOUR_OF_DAY, 23);
						calendar.set(Calendar.MINUTE, 59);
						calendar.set(Calendar.SECOND, 59);
						calendar.set(Calendar.MILLISECOND, 999);
						Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

						hql.append(" AND n.dateOfService BETWEEN :startDOSDate AND :endDOSDate ");
						parameters.put("startDOSDate", startOfDay);
						parameters.put("endDOSDate", endOfDay);
					}
						break;

					case "queuedDate": {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(req.getStartQueuedDate());
						calendar.set(Calendar.HOUR_OF_DAY, 0);
						calendar.set(Calendar.MINUTE, 0);
						calendar.set(Calendar.SECOND, 0);
						calendar.set(Calendar.MILLISECOND, 0);
						Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

						calendar.setTime(req.getEndQueuedDate());
						calendar.set(Calendar.HOUR_OF_DAY, 23);
						calendar.set(Calendar.MINUTE, 59);
						calendar.set(Calendar.SECOND, 59);
						calendar.set(Calendar.MILLISECOND, 999);
						Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

						hql.append(" AND n.queuedDate BETWEEN :StartqueuedDate AND :EndqueuedDate ");
						parameters.put("StartqueuedDate", startOfDay);
						parameters.put("EndqueuedDate", endOfDay);
					}
						break;

					case "provider": {
						List<String> providerList = FilterRequestUtil.getListFromDelimitedStr(req.getProvider());
						hql.append(" AND n.providerName IN :providerName ");
						parameters.put("providerName", providerList);
					}
						break;
					case "resolution": {
						List<String> resolutionList = FilterRequestUtil.getListFromDelimitedStr(req.getResolution());
						hql.append(" AND n.resolution IN :resolution ");
						parameters.put("resolution", resolutionList);
					}
						break;
					case "units": {
						List<String> unitsList = FilterRequestUtil.getListFromDelimitedStr(req.getUnits());
						hql.append(" AND n.units IN :units");
						parameters.put("units", unitsList);
					}
						break;

					case "nurseComments": {
						List<String> nurseCommentsList = FilterRequestUtil
								.getListFromDelimitedStr(req.getNurseComments());
						hql.append(" AND n.nurseComments IN :nurseComments ");
						parameters.put("nurseComments", nurseCommentsList);
					}
						break;
					case "assignedNurse": {
						List<String> assignedNurseFullNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssignedNurse());
						hql.append(" AND n.assignedNurseFullName IN :assignedNurseFullName ");
						parameters.put("assignedNurseFullName", assignedNurseFullNameList);
					}
						break;

					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						hql.append(" AND n.patientName IN :patientName ");
						parameters.put("patientName", patientNameList);
					}
						break;
					default:
						break;
					}
				}
			}

			// sorting logic
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				sortListforNurseAuditNotes(req, hql);
			} else {
				hql.append("order by LOWER(n.auditDate) ");
				if (req.getOrder() == 0) {
					hql.append(" desc");
				} else {
					hql.append(" asc");
				}
			}
			log.debug("hql=== " + hql);
			log.info("Starting to fetch nurse audit notes report.");

			Query<NurseAuditNotesReport> query = session.createQuery(hql.toString(), NurseAuditNotesReport.class);
			query.setProperties(parameters);
			List<NurseAuditNotesReport> results = query.getResultList();
			if (results != null && !results.isEmpty()) {
				log.info("Found {} records in the nurse audit notes report.", results.size());
				for (NurseAuditNotesReport entity : results) {
					NurseAuditNotesReportData data = new NurseAuditNotesReportData();

					data.setVisitId(entity.getVisitId() > 0 ? entity.getVisitId() : 0);
					data.setFacilityId(entity.getFacilityId() > 0 ? entity.getFacilityId() : 0);
					data.setFacilityName(entity.getFacilityAlias() != null ? entity.getFacilityAlias() : "");

					data.setAuditDate(entity.getAuditDate() != null ? dateFormat.format(entity.getAuditDate()) : "");
					data.setDateOfService(
							entity.getDateOfService() != null ? dateFormat.format(entity.getDateOfService()) : "");
					data.setQueuedDate(entity.getQueuedDate() != null ? dateFormat.format(entity.getQueuedDate()) : "");

					data.setUnits(entity.getUnits() != null ? entity.getUnits() : "");
					data.setProviderId(entity.getProviderId() != null ? entity.getProviderId() : "");
					data.setProviderName(entity.getProviderName() != null ? entity.getProviderName() : "");
					data.setResolution(entity.getResolution() != null ? entity.getResolution() : "");
					data.setNurseComments(entity.getNurseComments() != null ? entity.getNurseComments() : "");
					data.setAssignedNurseId(entity.getAssignedNurseId() != null ? entity.getAssignedNurseId() : 0L);
					data.setAssignedNurseUserName(
							entity.getAssignedNurseUserName() != null ? entity.getAssignedNurseUserName() : "");
					data.setAssignedNurseFullName(
							entity.getAssignedNurseFullName() != null ? entity.getAssignedNurseFullName() : "");
					data.setPatientId(entity.getPatientId() != null ? entity.getPatientId() : 0L);
					data.setPatientName(entity.getPatientName() != null ? entity.getPatientName() : "");

					reportList.add(data);
				}
			} else {
				log.warn("No records found in the nurse audit notes report.");
			}
		} catch (Exception e) {
			log.error("Exception occurred while fetching nurse audit notes report: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to fetch nurse audit notes report", e);
		}
		log.info("Nurse audit notes report fetching completed.");
		return reportList;
	}

//
	private StringBuilder sortListforNurseAuditNotes(NurseAuditNotesReportReq req, StringBuilder hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equalsIgnoreCase("auditDate")) {
			hql.append("order by LOWER(n.auditDate) ");
		} else if (sortBy.equalsIgnoreCase("visitId")) {
			hql.append("order by LOWER(n.visitId) ");
		} else if (sortBy.equalsIgnoreCase("facility")) {
			hql.append("order by LOWER(n.facilityAlias) ");
		} else if (sortBy.equalsIgnoreCase("queuedDate")) {
			hql.append("order by LOWER(n.queuedDate) ");
		} else if (sortBy.equalsIgnoreCase("dos")) {
			hql.append("order by LOWER(n.dateOfService) ");
		} else if (sortBy.equalsIgnoreCase("provider")) {
			hql.append("order by LOWER(n.providerName) ");
		} else if (sortBy.equalsIgnoreCase("nurseComments")) {
			hql.append("order by LOWER(n.nurseComments) ");
		} else if (sortBy.equalsIgnoreCase("assignedNurse")) {
			hql.append("order by LOWER(n.assignedNurseFullName) ");
		} else if (sortBy.equalsIgnoreCase("resolution")) {
			hql.append("order by LOWER(n.resolution) ");
		} else if (sortBy.equalsIgnoreCase("units")) {
			hql.append("order by LOWER(n.units) ");
		} else if (sortBy.equalsIgnoreCase("patientName")) {
			hql.append("order by LOWER(n.patientName) ");
		}

		if (req.getOrder() == 0) {
			hql.append(" desc");
		} else {
			hql.append(" asc");
		}
		return hql;
	}

	@Override
	public FilterOptions getEncounterUnderReviewMthlyFilterOptions(ReconReportReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		Map<String, Object> parameters = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Date startDate = req.getStartDate();
		Date endDate = req.getEndDate();
		try {
			String query = " WHERE 1=1 ";
			if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					query += " AND s.deficiencyDate >= :startDate";
					parameters.put("startDate", req.getStartDate());
				}

				if (endDate != null) {
					query += " AND s.deficiencyDate <= :endDate";
					parameters.put("endDate", req.getEndDate());
				}

			} else if ("DateOfService".equalsIgnoreCase(req.getDateType())) {

				if (startDate != null) {
					query += " AND s.dateOfService >= :startDate";
					parameters.put("startDate", req.getStartDate());
				}

				if (endDate != null) {
					query += " AND s.dateOfService <= :endDate";
					parameters.put("endDate", req.getEndDate());
				}

			}

			if (req.getBbcList() != null && !req.getBbcList().isEmpty()) {
				query += " AND s.childBluebookId IN :bluebookIds";
				parameters.put("bluebookIds", req.getBbcList());
			}
			if (req.getProviderNameList() != null && !req.getProviderNameList().isEmpty()) {
				query += " AND s.providerName IN :providerNames";
				parameters.put("providerNames", req.getProviderNameList());
			}
			if (req.getProviderIdList() != null && !req.getProviderIdList().isEmpty()) {
				query += " AND s.providerId IN :providerIds";
				List<String> providerIdList = req.getProviderIdList();
				List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
						.collect(Collectors.toList());
				parameters.put("providerIds", providerIdIntList);
			}
			if (req.getLocationTypeList() != null && !req.getLocationTypeList().isEmpty()) {
				query += " AND s.ihealConfig IN :locationTypeList";
				parameters.put("locationTypeList", req.getLocationTypeList());
			}
			if (req.getFacilityIdList() != null) {
				query += " AND s.facilityId IN :facilityIdList";
				parameters.put("facilityIdList", req.getFacilityIdList());
			}

			if (req.getStartDOSDate() != null) {
				query += " AND s.dateOfService >= :StartDOSDate";

			}
			if (req.getEndDOSDate() != null) {
				query += " AND s.dateOfService <= :endDOSDate";

			}
			if (req.getDeficiencyStartDate() != null) {
				query += " AND s.deficiencyDate >= :deficiencyStartDate";

			}
			if (req.getDeficiencyEndDate() != null) {
				query += " AND s.deficiencyDate <= :deficiencyEndDate";

			}

			String filterColumn = req.getFilterOptions();

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					// hql += " AND ";

					switch (filterReq) {
					case "bluebookId": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " AND s.childBluebookId IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "providerName": {
						/*
						 * List<String> primaryproviderList = FilterRequestUtil
						 * .getListFromDelimitedStr(req.getProviderName()); query +=
						 * " AND s.providerName IN :providerName "; parameters.put("providerName",
						 * primaryproviderList);
						 */
						query += " AND s.providerId IN :providerIds";
						List<String> providerIdList = req.getProviderIdList();
						List<Integer> providerIdIntList = providerIdList.stream().map(Integer::parseInt)
								.collect(Collectors.toList());
						parameters.put("providerIds", providerIdIntList);
					}
						break;

					case "dateOfService": {
						query += " AND s.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "deficiencyDate": {
						query += " AND s.deficiencyDate BETWEEN :deficiencyStartDate AND :deficiencyEndDate ";
						parameters.put("deficiencyStartDate",
								new Timestamp(dateFormat.parse(req.getDeficiencyStartDate()).getTime()));
						parameters.put("deficiencyEndDate",
								new Timestamp(dateFormat.parse(req.getDeficiencyEndDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " AND s.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "coderFullname": {
						query += " AND s.coderUserFullname IN :coderFullname";
						List<String> coderNameList = req.getCoderFullnameList();
						parameters.put("coderFullname", coderNameList);
					}
						break;

					default:
						break;
					}
				}
			}
			/*
			 * if ("DeficiencyDate".equalsIgnoreCase(req.getDateType())) { query
			 * +=" Group By s.deficiencyDate";
			 * 
			 * } else if ("DateOfService".equalsIgnoreCase(req.getDateType())) { query
			 * +=" Group By s.dateOfService"; }
			 */

			if (req.getStartDOSDate() != null) {
				// query.setParameter("StartDOSDate", dateFormat
				// .parse(req.getStartDOSDate()));
				parameters.put("StartDOSDate", dateFormat.parse(req.getStartDOSDate()));
			}
			if (req.getEndDOSDate() != null) {
				parameters.put("endDOSDate", dateFormat.parse(req.getEndDOSDate()));
				// query.setParameter("endDOSDate", dateFormat
				// .parse(req.getEndDOSDate()));
			}

			if (req.getDeficiencyStartDate() != null) {
				parameters.put("deficiencyStartDate", dateFormat.parse(req.getDeficiencyStartDate()));
				// query.setParameter("deficiencyStartDate", dateFormat
				// .parse(req.getDeficiencyStartDate()));
			}
			if (req.getDeficiencyEndDate() != null) {
				parameters.put("deficiencyEndDate", dateFormat.parse(req.getDeficiencyEndDate()));
				// query.setParameter("deficiencyEndDate", dateFormat
				// .parse(req.getDeficiencyEndDate()));
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("bluebookId")) {
				filterColumn = "s.childBluebookId";
			}
			if (req.getFilterOptions().equalsIgnoreCase("providerName")) {
				filterColumn = "s.providerName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("dateOfService")) {
				String dateHql = "SELECT MIN(s.dateOfService), MAX(s.dateOfService) FROM EncounterUnderReviewReport s "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("deficiencyDate")) {
				String dateHql = "SELECT MIN(s.deficiencyDate), MAX(s.deficiencyDate) FROM EncounterUnderReviewReport s "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setProperties(parameters).uniqueResult();

				filterOptions.setMinReceivedDate((Timestamp) object[0]);
				filterOptions.setMaxReceivedDate((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(s.visitId as string) FROM EncounterUnderReviewReport s " + query
						+ "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1).setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM EncounterUnderReviewReport s " + query
						+ " ORDER BY LOWER(" + filterColumn + ") asc";
				log.debug("hql:................  {}", hql);
				List<String> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options for Encounters Needing Guidance : {}",
					e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public List<ecWSentReportData> ecWSentReport(ecWSentReportReq req) throws EncodeExceptionHandler {
		List<ecWSentReportData> resultList = new ArrayList<>();
		Session session = this.sessionFactory.getCurrentSession();
		log.info("Inside ecWSentReport");
		try {

			// HQL query to group by messageDate and count total messages per date
			String hql = "SELECT m.messageDate, COUNT(m) " + "FROM MessageHistory m "
					+ "WHERE m.messageDate BETWEEN :startDate AND :endDate " + "GROUP BY m.messageDate "
					+ "ORDER BY m.messageDate DESC";

			// Create and set parameters for the query
			Query<Object[]> query = session.createQuery(hql, Object[].class);
			query.setParameter("startDate", req.getStartDate());
			query.setParameter("endDate", req.getEndDate());

			// Fetch results
			List<Object[]> rows = query.getResultList();

			// Map results
			for (Object[] row : rows) {
				Date messageDate = (Date) row[0];
				Long totalCount = (Long) row[1];

				ecWSentReportData data = new ecWSentReportData();
				data.setDate(messageDate);
				data.setTotalSent(totalCount);

				resultList.add(data);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching ecWSentReport Data : {}", e.getMessage());
			throw new EncodeExceptionHandler("Error fetching ecWSentReport data", e);
		}

		return resultList;
	}

	@Override
	public FilterOptions getNurseAuditNotesReportOptions(NurseAuditNotesReportReq req) throws EncodeExceptionHandler {

		FilterOptions filterOptions = new FilterOptions();
		try {
			List<NurseAuditNotesReportData> reportList = getNurseAuditNotesReport(req);

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			Set<String> distinctValues = new HashSet<>();

			switch (req.getFilterOption().toLowerCase()) {
			case "auditdate":
				Optional<Date> minAuditDate = reportList.stream().map(report -> {
					try {
						return dateFormat.parse(report.getAuditDate()); // Convert String to Date
					} catch (ParseException e) {
						log.error("Error parsing audit date: {}", report.getAuditDate(), e);
						return null;
					}
				}).filter(Objects::nonNull).min(Comparator.naturalOrder());

				Optional<Date> maxAuditDate = reportList.stream().map(report -> {
					try {
						return dateFormat.parse(report.getAuditDate());
					} catch (ParseException e) {
						log.error("Error parsing audit date: {}", report.getAuditDate(), e);
						return null;
					}
				}).filter(Objects::nonNull).max(Comparator.naturalOrder());
				// Set the min and max audit dates in filterOptions
				if (minAuditDate.isPresent()) {
					filterOptions.setMinAuditDate(new Timestamp(minAuditDate.get().getTime())); // Convert Date →
																								// Timestamp
				}
				if (maxAuditDate.isPresent()) {
					filterOptions.setMaxAuditDate(new Timestamp(maxAuditDate.get().getTime())); // Convert Date →
																								// Timestamp

				}
				log.debug("MinAuditDate: {}", minAuditDate);
				log.debug("MaxAuditDate: {}", maxAuditDate);
				break;

			case "queueddate":

				Optional<Date> minQueuedDate = reportList.stream().map(report -> {
					try {
						return dateFormat.parse(report.getQueuedDate()); // Convert String to Date
					} catch (ParseException e) {
						log.error("Error parsing queued date: {}", report.getQueuedDate(), e);
						return null;
					}
				}).filter(Objects::nonNull).min(Comparator.naturalOrder());

				Optional<Date> maxQueuedDate = reportList.stream().map(report -> {
					try {
						return dateFormat.parse(report.getQueuedDate());
					} catch (ParseException e) {
						log.error("Error parsing queued date: {}", report.getQueuedDate(), e);
						return null;
					}
				}).filter(Objects::nonNull).max(Comparator.naturalOrder());
//

				// Convert Dates to Strings before setting them in filterOptions
				if (minQueuedDate.isPresent()) {
					filterOptions.setMinQueuedDate(new Timestamp(minQueuedDate.get().getTime())); // Convert Date →
																									// Timestamp
				}
				if (maxQueuedDate.isPresent()) {
					filterOptions.setMaxQueuedDate(new Timestamp(maxQueuedDate.get().getTime())); // Convert Date →
																									// Timestamp
				}
				log.debug("MinQueuedDate: {}", minQueuedDate);
				log.debug("MaxQueuedDate: {}", maxQueuedDate);

				break;
			case "dos":
				Optional<Date> minDOS = reportList.stream().map(report -> {
					try {
						return dateFormat.parse(report.getDateOfService()); // Convert String to Date
					} catch (ParseException e) {
						log.error("Error parsing DOS: {}", report.getDateOfService(), e);
						return null;
					}
				}).filter(Objects::nonNull).min(Comparator.naturalOrder());

				Optional<Date> maxDOS = reportList.stream().map(report -> {
					try {
						return dateFormat.parse(report.getDateOfService());
					} catch (ParseException e) {
						log.error("Error parsing DOS: {}", report.getDateOfService(), e);
						return null;
					}
				}).filter(Objects::nonNull).max(Comparator.naturalOrder());

				if (minDOS.isPresent()) {
					filterOptions.setMinDOS(new Timestamp(minDOS.get().getTime())); // Convert Date → Timestamp
				}
				if (maxDOS.isPresent()) {
					filterOptions.setMaxDOS(new Timestamp(maxDOS.get().getTime())); // Convert Date → Timestamp
				}
				break;
			case "visitid":
				distinctValues = reportList.stream().map(report -> String.valueOf(report.getVisitId()))
						.collect(Collectors.toSet());
				break;

			case "facility":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getFacilityName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;

			case "provider":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getProviderName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;

			case "nursecomments":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getNurseComments)
						.filter(Objects::nonNull).collect(Collectors.toSet());

				break;
			case "assignednurse":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getAssignedNurseFullName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;
			case "units":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getUnits).filter(Objects::nonNull)
						.collect(Collectors.toSet());

				break;
			case "resolution":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getResolution)
						.filter(Objects::nonNull).collect(Collectors.toSet());

				break;
			case "patientname":
				distinctValues = reportList.stream().map(NurseAuditNotesReportData::getPatientName)
						.filter(Objects::nonNull).collect(Collectors.toSet());
				break;

			default:

				log.warn("Unknown filter column: {}", req.getFilterOption());
				break;
			}

			// Sort the distinct values such that uppercase letters come before lowercase
			// ones
			log.debug("distinct={}", distinctValues);
			List<String> sortedDistinctValues = new ArrayList<>(distinctValues);
			Collections.sort(sortedDistinctValues, new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					// Custom comparator to handle case-insensitive sorting but keep case order
					return Collator.getInstance(Locale.ENGLISH).compare(o1, o2);
				}
			});

			filterOptions.setOptions(sortedDistinctValues);
		} catch (Exception e) {
			log.error("Exception occurred while fetching filter options: {}", e.getMessage());
			throw new EncodeExceptionHandler("Failed to fetch filter options", e);
		}
		return filterOptions;
	}

	@Override
	public List<CoderProductivityReportData> getCoderProductivityReport(CoderProductivityReportReq req)
			throws EncodeExceptionHandler {
		List<CoderProductivityReportData> reportList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Session session = this.sessionFactory.getCurrentSession();

		try {
			StringBuilder hql = new StringBuilder("FROM CoderProductivityReport n WHERE 1=1");

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(req.getStartDate());
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());

			calendar.setTime(req.getEndDate());
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MINUTE, 59);
			calendar.set(Calendar.SECOND, 59);
			calendar.set(Calendar.MILLISECOND, 999);
			Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

			hql.append(" AND n.endDate BETWEEN :startDate AND :endDate ");
			parameters.put("startDate", startOfDay);
			parameters.put("endDate", endOfDay);

			// Add condition to filter by coderId if provided
			if (req.getCoderId() != null && !req.getCoderId().isEmpty()) {
				hql.append(" AND n.coderId IN (:coderIds) ");
				parameters.put("coderIds", req.getCoderId());
			}

			log.debug("hql=== " + hql);
			log.info("Starting to fetch nurse audit notes report.");

			Query<CoderProductivityReport> query = session.createQuery(hql.toString(), CoderProductivityReport.class);
			query.setProperties(parameters);
			List<CoderProductivityReport> results = query.getResultList();
			if (results != null && !results.isEmpty()) {
				log.info("Found {} records in the nurse audit notes report.", results.size());
				for (CoderProductivityReport entity : results) {
					CoderProductivityReportData data = new CoderProductivityReportData();

					data.setCoderId(entity.getCoderId() > 0 ? entity.getCoderId() : 0);
					data.setCoderName(entity.getCoder() != null ? entity.getCoder() : "");
					data.setCompleted(entity.getCompleted() > 0 ? entity.getCompleted() : 0);
					data.setDeficiency(entity.getDeficiency() > 0 ? entity.getDeficiency() : 0);
					data.setInReview(entity.getInReview() > 0 ? entity.getInReview() : 0);
					data.setSent(entity.getSent() > 0 ? entity.getSent() : 0);
					data.setOther(entity.getOther() > 0 ? entity.getOther() : 0);
					data.setUnbillable(entity.getUnbillable() > 0 ? entity.getUnbillable() : 0);
					data.setAvgTimeHrs(entity.getAvgTimeHrs() > 0 ? entity.getAvgTimeHrs() : 0);
					data.setAvgTimeMins(entity.getAvgTimeMins() > 0 ? entity.getAvgTimeMins() : 0);
					data.setTotal(entity.getTotal() > 0 ? entity.getTotal() : 0);
					data.setEndDate(entity.getEndDate() != null ? dateFormat.format(entity.getEndDate()) : "");
					reportList.add(data);
				}
			} else {
				log.warn("No records found in the nurse audit notes report.");
			}
		} catch (Exception e) {
			log.error("Exception occurred while fetching nurse audit notes report: {}", e.getMessage(), e);
			throw new EncodeExceptionHandler("Failed to fetch nurse audit notes report", e);
		}
		log.info("Nurse audit notes report fetching completed.");
		return reportList;
	}

	@Override
	public Map<String, Object> getCoderProductivityReportDrilldownData(ReportFilterReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<Dashboard> superbillReport = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		try {

			String hql = " FROM Dashboard a WHERE 1 = 1";

			/*
			 * if (req.getStartDate() != null && req.getEndDate() != null) { Calendar
			 * calendar = Calendar.getInstance(); calendar.setTime(req.getStartDate());
			 * calendar.set(Calendar.HOUR_OF_DAY, 0); calendar.set(Calendar.MINUTE, 0);
			 * calendar.set(Calendar.SECOND, 0); calendar.set(Calendar.MILLISECOND, 0);
			 * Timestamp startOfDay = new Timestamp(calendar.getTimeInMillis());
			 */

			if (req.getEndDate() != null) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(req.getEndDate());
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				calendar.set(Calendar.MILLISECOND, 999);
				Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

				// hql +=" AND a.endDate BETWEEN :startDate AND :endDate ";
				hql +=" AND a.endDate =:endDate ";
				//parameters.put("startDate", startOfDay);
				parameters.put("endDate", req.getEndDate());
			}
			if(req.getStatusList() != null && !req.getStatusList().isEmpty()){
				hql +=" AND a.status IN (:statusList) ";
				parameters.put("statusList", req.getStatusList());
			}
			if (req.getCoderId() != null && !req.getCoderId().isEmpty()) {
				hql += " AND a.coderId IN (:coderIds)";
				parameters.put("coderIds", req.getCoderId());
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						hql += " a.patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;

					case "dos": {
						hql += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						hql += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "mrn": {
						List<String> mrnList = FilterRequestUtil.getListFromDelimitedStr(req.getMrn());
						hql += " a.medicalRecordNumber IN :mrn ";
						parameters.put("mrn", mrnList);
					}
						break;

					case "status": {
						//List<String>statusList = FilterRequestUtil.getListFromDelimitedStr(req.getStatus());
						List<String>statusList = req.getStatusList();
						hql += " a.status IN :recordstatus ";
						parameters.put("recordstatus", statusList);
					}
						break;

					case "codingTeam": {
						List<String> codingTeamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						hql += " a.team IN :team ";
						parameters.put("team", codingTeamList);
					}
						break;

					default:
						break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortListForCoderproductivityReport(req, hql);

			} else {
				hql += " order by LOWER(a.snfLocationBBC) asc";
			}

			log.info("query : {}", hql.toString());

			log.debug("parameters : " + parameters);

			superbillReport = session.createQuery(hql)
					// .setParameter("startDate", req.getStartDate())
					// .setParameter("endDate", req.getEndDate())
					// .setParameter("endDates", req.getEndDate())
					.setProperties(parameters).list();
			int count = superbillReport.size() + req.getIndex();
			listCount.put("Count", count);
			listCount.put("data", superbillReport);
			log.debug("CoderProductivity Report List Size:   {} ", count);
		} catch (Exception e) {
			log.error("Exception occured while fetching filtered report Records: {}", e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return listCount;
	}

	private String sortListForCoderproductivityReport(ReportFilterReq req, String hql) {
		String sortBy = req.getSortBy();
		log.debug("sortBy........" + sortBy);
		if (sortBy.equals("bbc")) {
			hql += " order by LOWER(a.snfLocationBBC) ";
		} else if (sortBy.equals("visitId")) {
			hql += " order by LOWER(a.visitId) ";
		} else if (sortBy.equals("patientName")) {
			hql += " order by LOWER(a.patientName) ";
		} else if (sortBy.equals("codingTeam")) {
			hql += " order by LOWER(a.team) ";
		} else if (sortBy.equals("status")) {
			hql += " order by LOWER(a.status) ";
		}else if (sortBy.equals("mrn")) {
			hql += " order by LOWER(a.medicalRecordNumber) ";
		} else if (sortBy.equals("dos")) {
			hql += " order by LOWER(a.dateOfService) ";
		} else {
			hql += " order by LOWER(a." + sortBy + ") ";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public FilterOptions getCoderProductivityFilterOptions(ReportFilterReq req) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String query = " WHERE 1=1 ";
			
			if(req.getEndDate() != null){
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(req.getEndDate());
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
				calendar.set(Calendar.MILLISECOND, 999);
				Timestamp endOfDay = new Timestamp(calendar.getTimeInMillis());

				//hql +=" AND a.endDate BETWEEN :startDate AND :endDate ";
				query +=" AND a.endDate =:endDate ";
				//parameters.put("endDate", endOfDay);
			}
			if (req.getCoderId() != null && !req.getCoderId().isEmpty()) {
				query+=" AND a.coderId IN (:coderIds)";
	           // parameters.put("coderIds", req.getCoderId());
	        }
	
			String filterColumn = req.getFilterOptions();
			Map<String, Object> parameters = new HashMap<>();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {
					case "bbc": {
						List<String> bbcs = FilterRequestUtil.getListFromDelimitedStr(req.getBluebookId());
						query += " a.snfLocationBBC IN :bbc ";
						parameters.put("bbc", bbcs);
					}
						break;
					case "patientName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						query += " a.patientName IN :patientName ";
						parameters.put("patientName", patientNameList);
					}
						break;

					case "dos": {
						query += " a.dateOfService BETWEEN :startDOSDate AND :endDOSDate ";
						parameters.put("startDOSDate",
								new Timestamp(dateFormat.parse(req.getStartDOSDate()).getTime()));
						parameters.put("endDOSDate", new Timestamp(dateFormat.parse(req.getEndDOSDate()).getTime()));
					}
						break;

					case "visitId": {

						List<String> visitIdList = FilterRequestUtil.getListFromDelimitedStr(req.getVisitId());
						List<Long> intvisitIdList = new ArrayList<>();
						for (String s : visitIdList) {
							intvisitIdList.add(Long.valueOf(s));
						}
						query += " a.visitId IN :visitId ";
						parameters.put("visitId", intvisitIdList);
					}
						break;
					case "mrn": {
						List<String> mrnList = FilterRequestUtil.getListFromDelimitedStr(req.getMrn());
						query += " a.medicalRecordNumber IN :mrn ";
						parameters.put("mrn", mrnList);
					}
						break;
						
					case "status": {
						List<String> statusList = req.getStatusList();
						query += " a.status IN :recordstatus";
						parameters.put("recordstatus", statusList);
					}
						break;
						
					case "codingTeam": {
						List<String> codingTeamList = FilterRequestUtil.getListFromDelimitedStr(req.getCodingTeam());
						query += " a.team IN :team ";
						parameters.put("team", codingTeamList);
					}
						break;

					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);
			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("bbc")) {
				filterColumn = "a.snfLocationBBC";
			}
			if (req.getFilterOptions().equalsIgnoreCase("mrn")) {
				filterColumn = "a.medicalRecordNumber";
			}
			if (req.getFilterOptions().equalsIgnoreCase("codingTeam")) {
				filterColumn = "a.team";
			}
			if (req.getFilterOptions().equalsIgnoreCase("dos")) {
				String dateHql = "SELECT MIN(a.dateOfService), MAX(a.dateOfService) FROM Dashboard a "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql)
						.setParameter("coderIds", req.getCoderId())
						.setParameter("endDate", req.getEndDate())
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinDOS((Timestamp) object[0]);
				filterOptions.setMaxDOS((Timestamp) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("visitId")) {
				String hql1 = "SELECT DISTINCT CAST(a.visitId as string) FROM Dashboard a " + query
						+ "";
				log.debug("dateHql:................  {}", hql1);
				List<String> distinctValues = session.createQuery(hql1)
						.setParameter("coderIds", req.getCoderId())
						.setParameter("endDate", req.getEndDate())
						.setProperties(parameters).getResultList();

				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);
			}  else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM Dashboard a " + query
						+ " ORDER BY LOWER(" + filterColumn + ") asc";
				log.debug("hql:................  {}", hql);
				List<String> distinctValues = session.createQuery(hql).setProperties(parameters)
						.setParameter("coderIds", req.getCoderId())
						.setParameter("endDate", req.getEndDate())
						.getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options for Coder Productivity : {}",
					e.getMessage());
			e.printStackTrace();
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return filterOptions;
	}

}
