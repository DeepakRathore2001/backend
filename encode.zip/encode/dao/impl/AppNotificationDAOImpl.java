package com.healogics.encode.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.healogics.encode.dao.AppNotificationDAO;
import com.healogics.encode.dto.AppNotificationsReq;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.dto.TaggedUsers;
import com.healogics.encode.entity.AppNotification;
import com.healogics.encode.entity.UserPreference;
import com.healogics.encode.exception.EncodeExceptionHandler;

@Repository
@Transactional
public class AppNotificationDAOImpl implements AppNotificationDAO {

	private final Logger log = LoggerFactory
			.getLogger(AppNotificationDAOImpl.class);

	private final Environment env;

	private final SessionFactory sessionFactory;

	@Autowired
	public AppNotificationDAOImpl(Environment env, SessionFactory sf) {
		this.env = env;
		this.sessionFactory = sf;
	}

	@Override
	public Boolean saveNoteNotifications(NotesReq req, int noteId)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			log.debug("Saving App Notification: ", req, " noteId", noteId);
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getTaggedUsers() != null
					&& !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("visitId=");
				sb.append(req.getVisitId());

				sb.append("&patientId=");
				sb.append(req.getPatientId());

				sb.append("&noteId=");
				sb.append(noteId);

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				// reqURL.append("&src=email");

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (TaggedUsers users : req.getTaggedUsers()) {
					AppNotification appNotifications = new AppNotification();
					// appNotifications.setNotificationId(1L);
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications
							.setCreatorUserFullname(req.getUserFullName());
					appNotifications.setCreatorUserId(
							Long.valueOf(req.getCreatorUserId()));
					appNotifications.setCreatorUsername(req.getUserName());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications
							.setUserFullname(users.getTaggedUserFullName());
					appNotifications.setUserId(users.getTaggedUserId());
					appNotifications.setUsername(users.getTaggedUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					appNotifications.setNotificationTitle("TAGGED");
					appNotifications
							.setNotificationDescription(req.getDescription());
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"GlobalExceptionHandler occured at Saving Note APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return status;
	}

	@Override
	public Boolean saveEscalateNoteNotifications(ChartDetailsReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			log.debug("Saving App Notification: ", req);
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getTaggedUsers() != null
					&& !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("visitId=");
				sb.append(req.getVisitId());

				sb.append("&patientId=");
				sb.append(req.getPatientId());

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				// reqURL.append("&src=email");

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (TaggedUsers users : req.getTaggedUsers()) {
					AppNotification appNotifications = new AppNotification();
					// appNotifications.setNotificationId(1L);
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications
							.setCreatorUserFullname(req.getUserFullname());
					appNotifications
							.setCreatorUserId(Long.valueOf(req.getUserId()));
					appNotifications.setCreatorUsername(req.getUserName());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications
							.setUserFullname(users.getTaggedUserFullName());
					appNotifications.setUserId(users.getTaggedUserId());
					appNotifications.setUsername(users.getTaggedUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					if ("Escalation".equalsIgnoreCase(req.getAction())) {
	                    appNotifications.setNotificationTitle("ESCALATION");
	                    appNotifications.setNotificationDescription(
	                        req.getEscalationReason() + "$n#" + req.getEscalationNote());
	                } else if ("Returned".equalsIgnoreCase(req.getAction())) {
	                    appNotifications.setNotificationTitle("RETURNED");
	                    appNotifications.setNotificationDescription(req.getReturnedNote());
	                } else {
	                    log.error("Unknown action: {}", req.getAction());
	                    continue;
	                }
//					appNotifications.setNotificationTitle("ESCALATION");
//					appNotifications.setNotificationDescription(
//							req.getEscalationReason() + "$n#"
//									+ req.getEscalationNote());
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"EncodeExceptionHandler occured at Saving Escalated Note APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return status;
	}
	
	@Override
	public Boolean saveWeaknessAppNotifications(ChartDetailsReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			log.debug("Saving App Notification: ", req);
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getTaggedUsers() != null
					&& !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("visitId=");
				sb.append(req.getVisitId());

				sb.append("&patientId=");
				sb.append(req.getPatientId());

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				// reqURL.append("&src=email");

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (TaggedUsers users : req.getTaggedUsers()) {
					AppNotification appNotifications = new AppNotification();
					// appNotifications.setNotificationId(1L);
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications
							.setCreatorUserFullname(req.getUserFullname());
					appNotifications
							.setCreatorUserId(Long.valueOf(req.getUserId()));
					appNotifications.setCreatorUsername(req.getUserName());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications
							.setUserFullname(users.getTaggedUserFullName());
					appNotifications.setUserId(users.getTaggedUserId());
					appNotifications.setUsername(users.getTaggedUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					if ("Weakness".equalsIgnoreCase(req.getAction())) {
	                    appNotifications.setNotificationTitle("WEAKNESS");
	                    appNotifications.setNotificationDescription(
	                        req.getWeaknessReason() + "$n#" + req.getWeaknessNote());
					} else {
	                    log.error("Unknown action: {}", req.getAction());
	                    continue;
	                }
//					appNotifications.setNotificationTitle("ESCALATION");
//					appNotifications.setNotificationDescription(
//							req.getEscalationReason() + "$n#"
//									+ req.getEscalationNote());
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"EncodeExceptionHandler occured at Saving Weakness Note APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return status;
	}
	
	@Override
	public Long updateNotifications(AppNotificationsReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long count = 1L;
		UserPreference userPreference = new UserPreference();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getClearedFlag()) {
				UserPreference userPref = session
						.createQuery(
								"FROM UserPreference WHERE userId = :userId",
								UserPreference.class)
						.setParameter("userId", Long.valueOf(req.getUserId()))
						.setMaxResults(1).uniqueResult();
				if (userPref != null) {
					userPref.setClearNotificationTimestamp(currentTime);
					session.update(userPref);
				} else {
					userPreference.setUserId(Long.valueOf(req.getUserId()));
					userPreference.setClearNotificationTimestamp(currentTime);
					//session.update(userPreference);
					session.save(userPreference);
				}
				Long userId = Long.valueOf(req.getUserId());
				String hql = "UPDATE AppNotification SET "
						+ " readFlag = :readFlag, "
						+ " lastUpdatedTimestamp = :lastUpdatedTimestamp "
						+ " WHERE " + " userId = :userId ";
				session.createQuery(hql).setParameter("readFlag", true)
						.setParameter("lastUpdatedTimestamp", currentTime)
						.setParameter("userId", userId).executeUpdate();

			} else if (req.getReadFlag()) {
				for (String id : req.getNotificationId()) {
					Long notificationId = Long.valueOf(id);
					Long userId = Long.valueOf(req.getUserId());
					String hql = "UPDATE AppNotification SET "
							+ " readFlag = :readFlag, "
							+ " lastUpdatedTimestamp = :lastUpdatedTimestamp "
							+ " WHERE notificationId = :notificationId "
							+ " AND userId = :userId ";
					session.createQuery(hql).setParameter("readFlag", true)
							.setParameter("lastUpdatedTimestamp", currentTime)
							.setParameter("notificationId", notificationId)
							.setParameter("userId", userId).executeUpdate();
				}
				count = 0L;
				log.debug("Updated Notifications.............");
			}

		} catch (Exception e) {
			log.error(
					"EncodeExceptionHandler occured at Updating APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return count;
	}

	@Override
	public List<AppNotification> getAppNotification(Long userId,
			Timestamp clearNotificationTimestamp,
			String last30DaysDate) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		List<AppNotification> notifications = new ArrayList<>();
		try {
			String hql = "";
			if (clearNotificationTimestamp != null) {
				hql = "FROM AppNotification n WHERE n.userId=" + userId
						+ " AND n.createdTimestamp > '" + clearNotificationTimestamp
						+ "' AND n.createdTimestamp > '" + last30DaysDate + "'"
						+ " order by createdTimestamp desc";
			} else {
				hql = "FROM AppNotification n WHERE n.userId=" + userId
						+ " AND n.createdTimestamp > '" + last30DaysDate
						+ "'" + " order by createdTimestamp desc";
			}
			log.info("query : {}", hql);
			notifications = session.createQuery(hql).list();
		} catch (Exception e) {
			log.error("EncodeExceptionHandler occured at Fetching APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return notifications;
	}
	
	@Override
	public Long getNotificationCount(Long userId) throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;
		try {
			// last 30 days data only
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_MONTH, -30);
			Date last30DaysDate = calendar.getTime();
			Timestamp last30DaysTimestamp = new Timestamp(last30DaysDate.getTime());
			log.info("last30DaysTimestamp :  {}", last30DaysTimestamp);
			
			String hql = "SELECT count(*) FROM AppNotification WHERE userId = :userId"
					+ " AND createdTimestamp > :createdTimestamp"
					+ " AND readFlag = false";
			
			totalCount = (Long) session.createQuery(hql)
					.setParameter("userId", Long.valueOf(userId))
					.setParameter("createdTimestamp", last30DaysTimestamp)
					.uniqueResult();

		} catch (Exception e) {
			log.error(
					"GlobalExceptionHandler occured at count APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return totalCount;
	}
	
	@Override
	public Boolean saveProviderResponseNotifications(NotesReq req, int noteId)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			log.debug("Saving App Notification: ", req, " noteId", noteId);
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			
			if (req.getTaggedUsers() != null
					&& !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("visitId=");
				sb.append(req.getVisitId());

				sb.append("&patientId=");
				sb.append(req.getPatientId());

				sb.append("&noteId=");
				sb.append(noteId);

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				// reqURL.append("&src=email");

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (TaggedUsers users : req.getTaggedUsers()) {
					AppNotification appNotifications = new AppNotification();
					// appNotifications.setNotificationId(1L);
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications
							.setCreatorUserFullname(req.getUserFullName());
					appNotifications.setCreatorUserId(
							Long.valueOf(req.getCreatorUserId()));
					appNotifications.setCreatorUsername(req.getUserName());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications
							.setUserFullname(users.getTaggedUserFullName());
					appNotifications.setUserId(users.getTaggedUserId());
					appNotifications.setUsername(users.getTaggedUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					appNotifications.setNotificationTitle("PROVIDER-RESPONSE");
					appNotifications
							.setNotificationDescription(req.getDescription());
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"GlobalExceptionHandler occured at Saving Note APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return status;
	}
	
	@Override
	public Boolean saveWeaknessAppNotificationsAuditor(SaveAuditDetailsReq req)
			throws EncodeExceptionHandler {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			log.debug("Saving App Notification: ", req);
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getTaggedUsers() != null
					&& !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("visitId=");
				sb.append(req.getVisitId());

				sb.append("&patientId=");
				sb.append(req.getPatientId());

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				// reqURL.append("&src=email");

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (TaggedUsers users : req.getTaggedUsers()) {
					AppNotification appNotifications = new AppNotification();
					// appNotifications.setNotificationId(1L);
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications
							.setCreatorUserFullname(req.getUserFullName());
					appNotifications
							.setCreatorUserId(Long.valueOf(req.getUserId()));
					appNotifications.setCreatorUsername(req.getUserName());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications
							.setUserFullname(users.getTaggedUserFullName());
					appNotifications.setUserId(users.getTaggedUserId());
					appNotifications.setUsername(users.getTaggedUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					if ("Weakness".equalsIgnoreCase(req.getAction())) {
	                    appNotifications.setNotificationTitle("WEAKNESS");
	                    appNotifications.setNotificationDescription(
	                        req.getWeaknessReason() + "$n#" + req.getWeaknessNote());
					} else {
	                    log.error("Unknown action: {}", req.getAction());
	                    continue;
	                }
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"EncodeExceptionHandler occured at Saving Weakness Note APP notifications: {}",
					e.getMessage());
			throw new EncodeExceptionHandler(e.getMessage());
		}
		return status;
	}
}
