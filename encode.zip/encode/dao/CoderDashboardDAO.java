package com.healogics.encode.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;


import com.healogics.encode.dto.CoderDashboardFilter;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.PlaceOfServiceDetails;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface CoderDashboardDAO {

	public Map<String, Object> getFilteredCoderList(CoderDashboardReq req, int index,
			String taskType, String assignee, List<String> bbcs,List<String>FacilityIdList)
			throws EncodeExceptionHandler;

	public Long getTotalCount(int index, String taskType, String assignee,
			CoderDashboardReq req, List<String> bbcList, List<String>FacilityIdList)
			throws EncodeExceptionHandler;

	public List<Object[]> getAllCoderRecords(CoderDashboardReq req, int index, String taskType, String assignee, List<String> bbclist, List<String>FacilityIdList)
			throws EncodeExceptionHandler;

	Long getTotalItemCountPerFacility(String bbc, String taskType, String assignee);

	public List<Dashboard> getCollapseDetails(String bbc, String assigneeName, String taskType, DashboardReq req) throws EncodeExceptionHandler;

	Reasons getUnbillableReasons() throws EncodeExceptionHandler;
	
	List<PlaceOfServiceDetails> getPlaceOfServices() throws EncodeExceptionHandler;

	public CoderDashboardFilter retrieveCoderDashboardFilterOptions(CoderDashboardReq req,
			List<String> bbcList)
			throws EncodeExceptionHandler;

	public Date getMinServiceDate(String bbc) throws EncodeExceptionHandler;

	public void saveLockStatus(DashboardReq req) throws EncodeExceptionHandler;

	public Map<String, Object> getSearchedCoderList(
			CoderDashboardReq coderDashboardReq, List<String> bbcList) throws EncodeExceptionHandler;

	public FilterOptions retrieveCollapsibleFilterOption(DashboardReq req, List<String> bbcList, String bbc)
			throws EncodeExceptionHandler;

	public Map<String, Object> getCollapsibleFilteredData(DashboardReq req, int index, String taskType, String assignee,
			List<String> bbcList, boolean isApplyPagination, String bbc)throws EncodeExceptionHandler;

	public FilterOptions advanceSearchFilterOption(CoderDashboardReq req, List<String> bbcList)throws EncodeExceptionHandler;

	public Map<String, Object> getSearchedCoderdataList(CoderDashboardReq req, List<String> bbcList)throws EncodeExceptionHandler;

	public List<Object[]> getAllCoderRecord(CoderDashboardReq req, int index, String taskType, String assignee, List<String> bbclist, List<String>FacilityIdList)
			throws EncodeExceptionHandler;

	public FilterOptions retrieveCoderDashboardFilterOption(CoderDashboardReq req, List<String> bbcList)throws EncodeExceptionHandler;

	public Map<String, Object> getFilteredCoderLists(CoderDashboardReq req, int index, String taskType, String assignee,
			List<String> bbcList, List<String> facilityIdList)throws EncodeExceptionHandler;

	public Map<String, Object> getFilteredCoderExcelList(CoderDashboardReq req, int index, String taskType, String assignee, boolean isApplyPagination,
			List<String> FacilityIdList)throws EncodeExceptionHandler;

	public List<Dashboard> getAllCoderExcelRecords(CoderDashboardReq req, int index,
			String taskType, String assignee, boolean isApplyPagination,
			List<String> FacilityIdList)throws EncodeExceptionHandler;

	public EncodeUsers findByUserId(Long valueOf) throws EncodeExceptionHandler;

	boolean coderDocPresent(Long visitId, Long patientId, String documentName) throws EncodeExceptionHandler;

	public PatientMedicalRecords getSBRecordByVersion(Long patientId, Long visitId, String versionId) throws EncodeExceptionHandler;


	
}
