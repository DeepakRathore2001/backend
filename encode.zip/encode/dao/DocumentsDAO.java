package com.healogics.encode.dao;

import com.healogics.encode.dto.DBDocumentContentRes;
import com.healogics.encode.dto.DBDocumentListReq;
import com.healogics.encode.dto.DBDocumentListRes;
import com.healogics.encode.dto.DocumentDeleteReq;
import com.healogics.encode.dto.DocumentDeleteRes;
import com.healogics.encode.dto.DocumentsListReq;
import com.healogics.encode.dto.IHealDebridementRes;
import com.healogics.encode.dto.IHealProgressNotesListGetRes;
import com.healogics.encode.dto.IHealWoundAssessmentListGetResponse;
import com.healogics.encode.dto.IHealWoundListGetRes;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface DocumentsDAO {

	public IHealProgressNotesListGetRes getProgressNotesLoad(DocumentsListReq req);

	public IHealWoundAssessmentListGetResponse getWoundAssessmentLoad(int entity, DocumentsListReq req);

	public IHealDebridementRes getDebridementLoad(DocumentsListReq req, int entity);

	public IHealWoundListGetRes getWoundList(DocumentsListReq req);
	
	public DBDocumentListRes getDBDocumentList(DBDocumentListReq req);
	
	public DBDocumentContentRes getDBDocumentContent(DBDocumentListReq req);

	public DocumentDeleteRes deleteDBDocumentList(DocumentDeleteReq req);


}
