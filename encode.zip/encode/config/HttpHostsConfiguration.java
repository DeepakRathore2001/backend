package com.healogics.encode.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HttpHostsConfiguration {
	
	@Value("${httpconnpool.maxtotal}")
	private Integer maxTotal;
	
	@Value("${httpconnpool.defaultmaxperroute}")
	private Integer defaultMaxPerRoute;
	
	@Value("${httpconnpool.timeout}")
	private Integer timeOut;
	
	public Integer getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(Integer timeOut) {
		this.timeOut = timeOut;
	}

	public Integer getMaxTotal() {
		return this.maxTotal;
	}

	public void setMaxTotal(Integer maxTotal) {
		this.maxTotal = maxTotal;
	}

	public Integer getDefaultMaxPerRoute() {
		return this.defaultMaxPerRoute;
	}

	public void setDefaultMaxPerRoute(Integer defaultMaxPerRoute) {
		this.defaultMaxPerRoute = defaultMaxPerRoute;
	}
}
