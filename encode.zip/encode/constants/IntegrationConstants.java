package com.healogics.encode.constants;

public class IntegrationConstants {
	public static final int STATUS_SUCCESS = 0;

	public static final int STATUS_ERROR = 1;

	public static final String ERROR_MSG = "REQUIRED PARAMETERS ARE MISSING";
	public static final String INVALID_TOKEN = "Master Token has expired";
	public static final String INTERNAl_SERVER_ERROR_CODE = "500";
	public static final String SUCCESS_CODE_WITH_NO_CONTENT = "200";
	public static final String INVALID_PARAMETERS = "501";
}
