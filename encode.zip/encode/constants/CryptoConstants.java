package com.healogics.encode.constants;

public class CryptoConstants {
	
	 private CryptoConstants() {

	    }
	    public static final String AES_SALT = "a1b2c3d4e5f61234";
	    public static final String AES_PASPHRASE = "1afc06aa242190566105ab3f971056e3e4d5471b36a4667ea5b8a2eca318959e";
	    public static final int AES_KEY_SIZE = 128;
	    public static final int AES_ITERATION_COUNT = 1023;

}
