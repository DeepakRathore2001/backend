package com.healogics.encode.constants;

public class ControllerConstants {
	private ControllerConstants() {
	}

	public static final String TIMESTAMP = "timestamp";
	public static final String ACTION = "action";
	public static final String SUCCESS_CODE = "200";
	public static final String SUCCESS_DESC = "Success";
	public static final String LOGIN = "login";
	public static final String API_RESPONSE = "apiresponse";
	public static final String MSG_HEADER = "messageheader";
	public static final String RESPONSE = "Response";
	public static final String INVALID_CREDENTIALS = "Invalid Credentials";

	public static final String ZERO_ERROR_CODE = "0";
	public static final String INVALID_PARAMETERS = "Invalid parameters";
	public static final String INVALID_PARAMETERS_CODE = "400";
	public static final String ERROR_CODE_NUMBER = "501";

	public static final String INTERNAL_SERVER_ERROR_CODE = "500";

	public static final String ACCEPT_TERMSANDCONDITIONS = "Accept TermsAndConditions";

	public static final String CMC_FILTER_DASHBOARD = "CMC Filter Dashboard";
	public static final String FILTER_OPTIONS = "Filter Options";

	public static final String CODER_FILTER_DASHBOARD = "Coder Filter Dashboard";

	public static final String ADMIN_FILTER_DASHBOARD = "Admin Filter Dashboard";
	public static final String ADMIN_FILTER_FACILITY_DETAILS = "Admin Filter Facility Details";
	public static final String IHEAL_WOUNDASSESSMENT_LIST = "IHeal Wound Assessment List";
	public static final String IHEAL_DEBRIDEMENTS_LIST = "IHeal Debridements List";
	public static final String WOUND_LIST = "Wound List";
	public static final String IHEAL_PROGRESS_NOTES_LIST = "IHeal Progress Notes List";
	public static final String GET_DOC_URL = "Get Document URL";
	public static final String EXPORT_EXCEL = "Export Excel";
	public static final String CODER_UNBILLABLE_REASONS = "Coder Unbillable Reasons";
	public static final String CODER_WEAKNESS_REASONS = "Coder Weakness Reasons";
	public static final String CODER_MODIFIERS_REASONS = "Coder Modifiers Reasons";
	public static final String CODER_PENDING_REASONS = "Coder Pending Reasons";
	public static final String GET_DOCUMENT_LIST = "Get Document List";
	public static final String IHEAL_VISIT_DOCUMENT_LIST = "IHeal Visit Document List";
	public static final String DELETE_DOCUMENT_LIST = "Delete Document List";

	public static final String SAVE_FILTER = "Save Filter";
	public static final String VIEW_FILTER = "View Filter";
	public static final String UPDATE_FILTER = "Update Filter";
	public static final String EDIT_FILTER = "Edit Filter";
	public static final String DELETE_FILTER = "Delete Filter";

	public static final String COLLAPSIBLE_SECTION = "Collapsible Section";

	public static final String GET_NOTIFICATION = "Get Notification";
	public static final String CODERDASHBOARD_FILTER_OPTIONS = "CODERDASHBOARD_FILTER_OPTIONS";
	public static final String SAVE_NOTES = "Save Notes";
	public static final String SAVE_LOCK_STATUS = "Save Lock Status";

	public static final String BUILD_DETAILS = "build_details";
	public static final String SAVE_BUILD_DETAILS = "save_build_details";

	public static final String PROVIDER_LIST_GET = "Provider List Get";
	public static final String PATIENT_LOAD = "Patient Load";
	public static final String VISIT_LOAD = "Visit Load";
	public static final String PLACE_OF_SERVICE_LIST_GET = "Place of Service List Get";
	public static final String NURSE_ROLE = "Nurse Role";

	public static final String SAVE_RECORD = "Save Record";
	public static final String IHEAL_USER_FACILITY_LIST_GET = "IHEAL USER FACILITY LIST GET";
	public static final String GET_CMC_RECORD = "get_cmc_record";

	public static final String SEARCH_CODER_DASHBOARD = "Search Coder Dashboard";
	public static final String HISTORY_TIMELINE_LIST = "HistoryTimeline List";

	public static final String RETRIEVE_NOTES = "Retrieve Notes";
	public static final String NOTE_DETAIL = "Note Detail";
	public static final String SAVE_CHART_DETAILS = "Save Chart Details";
	public static final String DEFICIENCY_LIST = "Deficiency List";

	public static final String UPDATE_APP_NOTIFICATION = "Update App Notification";
	public static final String CODER_RECORD = "Coder Record";
	public static final String ESCALATE_REASONS_LIST = "Escalate Reasons List";
	public static final String ADMINISTRATION_ENCODE_USERS = "Administration Encode Users";
	public static final String APP_NOTIFICATIONS = "App Notifications";

	public static final String CODER_PLACE_OF_SERVICES = "Coder Place of Services";
	public static final String PLACE_OF_SERVICES = "Place of Services";
	public static final String SEARCH_ICD10_CODES = "Search ICD10 Codes";
	public static final String SEARCH_CPT_CODES = "Search CPT Codes";
	public static final String APP_NOTIFICATION_STATUS = "App Notification Status";
	public static final String NOTIFICATION_LIST = "Notification List";
	public static final String NOTIFICATION_CREATION = "Notification Creation";
	public static final String NOTIFICATION_DELETE = "Notification Delete";
	public static final String USER_NOTIFICATION_CREATION = "User Notification creation";
	
	public static final String ENCODEROLE = "EncodeRole";
	public static final String ENCODE_ROLES = "Encode Roles";
	public static final String SEARCH_ESCALATED_STATUS = "Search Escalated Status";


	public static final String UPDATE_COLOR_CODES = "Update Color Codes";
	public static final String GET_LAST_APPLIED_FILTER = "get last applied filter";

	public static final String AUDITOR_SEARCH_VALUES = "Auditor Search Values";
	public static final String AUDITOR_SEARCH_FACILITIES = "Auditor Search Facilities";
	public static final String AUDITOR_SEARCH_CODING_TEAM = "Auditor Search Coding Team";
	public static final String AUDITOR_SEARCH_CODERS = "Auditor Search Coders";
	public static final String AUDITOR_DRILLDOWN = "Auditor Drill Down";
	public static final String AUDITOR_FILTER_DASHBOARD = "Auditor Filter Dashboard";
	public static final String SAVE_AUDIT_DETAILS= "Save Audit Details ";
	public static final String CMC_UNBILLABLE_REASONS = "CMC Unbillable Reasons";
	public static final String GET_CPT_CODES = "GET CPT Codes";
	public static final String INSURANCE_CARRIER= "Insurance Carrier ";
	public static final String AUDITOR_COLLAPSIBLE_SECTION= "Auditor Collapsible Section ";
	public static final String UPDATE_CHART_STATUS= "Update Chart Status ";
	public static final String SAVE_AUDIT_HISTORY= "Save Audit History ";
	public static final String GET_BILL_HISTORY= "Get Bill History ";
	
	public static final String PARSE_CENTER_ALIGNMENT_EXTRACT = "Parse Center Alignment Extract";
	public static final String ESCALATION_DETAILS = "Escalation Details";
	public static final String AUDITOR_REASONS = "Auditor Reasons";
	public static final String VALIDATE_CHART = "Validate Chart";
	public static final String COLLAPSIBLE_FILER_OPTION = "Collapsible Filter Option";
	public static final String COLLAPSIBLE_FILER = "Collapsible Filter";
	public static final String ENCOUNTER_STATUS_REPORT = "Encounter Status Report";
	
	public static final String UPLOAD_CMC_DOCUMENTS = "Upload CMC Documents";
	public static final String IHEAL_PATIENTHSPBALANCEDUESAVE = "Iheal PatientHSPBalanceDueSave";
	
	public static final String RECON_REPORT = "Recon Report";
	public static final String REPORT_FILTER = "Report Filter";
	public static final String MONTHLY_CHARGE_SUMMARY_REPORT = "MOnthly Charge Summary Report";
	public static final String GET_CPT_CODES_REPORT = "Get CPT Codes for Report";
	public static final String DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT = "Drill Down Monthly Charge Summary Report";
	public static final String SUPERBILL_VARIANCE = "Superbill Variance";
	public static final String MISSING_CHART_REPORT = "Missing Chart Report";
	public static final String DRILL_DOWN_MISSING_CHART_REPORT = "Drill Down Missing Chart Report";
	public static final String POST_AUDIT_REPORT = "Post Audit Report";
	public static final String DRILL_DOWN_POST_AUDIT_REPORT = "Drill Down Post Audit Report";
	public static final String GUIDANCE_REPORT = "Encounters Needing Guidance Report";
	public static final String SUPERBILL_VARIANCE_REPORT = "Superbill Variance Report";
	public static final String ENCOUNTER_UNDER_REVIEW_MONTHLY = "Encounter Under Review Monthly";
	public static final String ENCOUNTER_UNDER_REVIEW_COUNT = "Encounter Under Review Count";
	public static final String ENCOUNTER_UNDER_REVIEW = "Encounter Under Review";
	public static final String CHART_WEAKNESS_REPORT = "Chart Weakness Report";
	public static final String CLICK_STREAM = "Click Stream";
	public static final String GET_INSURANCE_DETAILS = "Get Insurance Details";

	public static final String AUDIT_FILTER = "Audit Filter";
	public static final String ALL_INAUDIT_CHARTS = "All In Audit Charts";
	public static final String CHART_BY_STATUS = "Chart By Status";
	public static final String RECON_REPORT_FILTER_OPTIONS = "Recon Report Filter Options";

	public static final String MISSING_CHART_FILTER_OPTIONS = "Missing Chart Filter Options";

	public static final String DEFICIENCY__AGING_REPORT_FILTER_OPTIONS = "Deficiency Aging Report Filter Options";
	public static final String SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS = "Superbill Variance Report Filter Options";
	public static final String ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS = "Encounter Under Review Filter Options";
	public static final String FACILITY_SETTINGS = "Facility Settings";
	public static final String CAMPUS_INDICATOR = "Campus Indicator";
	public static final String SUPERBILL_VARIANCE_FILTERED_DATA = "Superbill Variance Filtered Data";
	public static final String ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS = "Encounter Needing Guience Report Filter Options";
	public static final String ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS = "Encounter Under Review Mthly Report Filter Options";
	
	public static final String NURSE_AUDIT_NOTES_REPORT = "Nurse Audit Notes Report";
	public static final String CODER_PRODUCTIVITY_REPORT = "Coder Productivity Report";
	public static final String CODER_PRODUCTIVITY_REPORT_DRILLDOWN = "Coder Productivity Report Drilldown";
	public static final String CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS = "Coder Productivity Report Filter Options";
	
	public static final String RELOAD_PATIENT_INSURANCE = "Reload Patient Insurance";
	public static final String RELOAD_PATIENT = "Reload Patient and Patient Insurance";
	public static final String LIGHT_SPEED_DATA_IMPORT = "Light Speed Data Import";
	public static final String RELOAD_DEFICIENCY = "Reload Deficiency";
	
	public static final String NURSE_DISPOSITION_LIST = "Nurse Disposition List";
	public static final String AUDITOR_FILTER_DASHBOARD_RELEASE = "Auditor Filter Dashboard Release";
	public static final String RELEASE_BY_FILTER_CHART = "Release By Filter Chart";
	
	public static final String ECW_SENT_REPORT = "ECW Sent Report";
	public static final String UPLOAD_DOCUMENTS = "Upload Documents";
	public static final String GET_SUPERBILL = "Get Superbill";
	
	public static final String ADD_OR_REMOVE_PINNED_FILTER = "Add Or Remove Pinned Filter";
}

