package com.healogics.encode.constants;

public class DAOConstants {
	private DAOConstants() {
	}
	public static final String FAILED = "Failed";
	public static final String SUCCESS = "Success";
	public static final int PAGE_SIZE = 20;
	public static final int NOTE_SIZE = 5;
	public static final int HISTORY_SIZE = 5;
	
	public static final double PAGE_SIZE_DOUBLE = 20.0;
	//public static final double NOTE_SIZE_DOUBLE = 20.0;
	
	//public static final int NOTES_SIZE = 5;
	public static final double NOTES_SIZE_DOUBLE = 5.0;
	
	public static final int HISTORY_TIMELINE_SIZE = 5;
	public static final double HISTORY_TIMELINE_SIZE_DOUBLE = 5.0;
	
	public static final String ERRORCODE = "errorCode";
	public static final String ERRORMESSAGE = "errorMessage";
	
	public static final String ESCALATION_NOTE_SEPARATOR = "app.escalation.note.separator";
	
	
}
