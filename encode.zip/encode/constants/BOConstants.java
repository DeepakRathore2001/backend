package com.healogics.encode.constants;
 
public class BOConstants {
	private BOConstants() {
	}
	public static final String FAILED = "Failed";
	public static final String SUCCESS = "Success";
	public static final String IHEAL_HOST_NAME = "host_name";
	public static final String IHEAL_LOGIN_URL = "iheal.login.url";
	public static final String IHEAL_LOGIN_BY_TOKEN_URL = "iheal.login.by.token.url";
	public static final String IHEAL_LOGOUT_URL = "iheal.logout.url";
	public static final String ERRORCODE = "errorCode";
	public static final String PRIVATE_KEY = "privateKey";
	public static final String ERRORMESSAGE = "errorMessage";
	public static final String IHEAL_PRIVATEKEY = "iheal.privatekey";
	public static final String JWT_EXPIRATION_TIME = "jwt.expirationtime";
	public static final String JWT_REFRESHTOKEN_EXPIRATION_TIME = "jwt.refreshtoken.exp.time";
	public static final String JWT_SECRETKEY = "jwt.secretkey";
	public static final String IHEAL_PROGRESSNOTES_LIST_URL = "iheal.progressnotes.list.url";
	public static final String IHEAL_VISIT_DOCUMENT_LIST_URL = "iheal.visit.document.list.url";
	public static final String IHEAL_WOUND_LIST_URL = "iheal.wound.list.url";
	public static final String IHEAL_WOUND_ASSESSMENT_LIST_URL = "iheal.wound.assessment.list.url";
	public static final String DOCUMENT_BASE_URL = "iheal.doc.base.url";
	public static final String IHEAL_INSTANCE_TOKEN_URL = "iheal.instance.token.url";
	public static final String IHEAL_DEBRIDEMENTS_LIST_URL = "iheal.debridements.list.url";

	public static final String NEW_STATUS = "New";
	public static final String PENDING_STATUS = "Pending";
	public static final String UNBILLABLE_STATUS = "Unbillable";
	public static final String VALIDATED_STATUS = "Ready";
	public static final String AUDIT_STATUS = "In Audit";
	public static final String NURSE_REVIEW = "Nurse Review";
	public static final String COMPLETED_STATUS = "Completed";
	
	public static final String CMC_ROLE = "CMC";
	public static final String CODER_ROLE = "Coder";

	public static final String APP_ENV = "app.env";

	public static final String IHEAL_SUPERBILL_LOAD_URL = "iheal.superbillload.url";
	public static final String IHEAL_PATIENT_LOAD_URL = "iheal.patientload.url";
	public static final String IHEAL_VISIT_LOAD_URL = "iheal.visit.load.url";
	public static final String NETHEALTH_SUPERBILL_SERVICE_MASTERTOKEN = "netHealth.superbill.service.mastertoken";
	public static final String NETHEALTH_SUPERBILL_SERVICE_USERID = "netHealth.superbill.service.userid";
	public static final String NETHEALTH_SUPERBILL_SERVICE_USERNAME = "netHealth.superbill.service.username";
	public static final String NETHEALTH_INTEGRATION_KEY = "netHealth.integration.key";
	public static final String IHEAL_SELECTIION_ADMIN_GET = "iheal.selection.admin.get.url";
	public static final String IHEAL_USERFACILITIES_URL = "iheal.userfacilities.url";
	public static final String ICD_10_SEARCH_API_URL = "icd10.search.api.url";
	public static final String IHEAL_VISIT_LIST_URL = "iheal.visit.list.url";
	
	public static final int HISTORY_SIZE = 5;
	public static final double HISTORY_SIZE_DOUBLE = 5.0;
	
	public static final int ICD_10_COUNT = 25;
	public static final int ICD_10_OFFSET = 0;
	
	public static final String AWS_S3_SOURCE = "AWS S3 bucket";
	public static final String CMC_DOC_SOURCE = "CMC Document Handler";
	
	public static final String PARSE_FACILITY_CSV_API = "parse.facility.csv.api";
	
	public static final int HARD_STOP = 1;
	public static final int SOFT_STOP = 2;
	public static final String IHEAL_PATIENTHSPBALANCEDUESAVE_URL = "iheal.patienthspbalanceduesave.url";
	public static final int SUMMARY_GROUPBY_YEAR = 3;
	public static final int SUMMARY_GROUPBY_QUARTER = 2;
	public static final int SUMMARY_GROUPBY_MONTH = 1;
	
	public static final String NETHEALTH_PROVIDER_INBOX_EMR_SUBJECT = "nethealth.provider.inbox.emr.subject";
	public static final String NETHEALTH_PROVIDER_INBOX_OTPOS_SUBJECT = "nethealth.provider.inbox.otpos.subject";
	public static final String APP_URL = "app.url";
	public static final String IHEAL_APP_URL = "i-heal.app.url";
	public static final String IHEAL_INBOX_MESSAGE_SEND_URL = "iheal.inbox.message.send.url";
	public static final String IHEAL_INBOX_MESSAGE_LIST_GET_URL = "iheal.inbox.message.list.get.url";
	public static final String IHEAL_INBOX_MESSAGE_LOAD_URL = "iheal.inbox.message.load.url";
	public static final String IHEAL_INBOX_MESSAGE_ARCHIVED_SET_URL = "iheal.inbox.message.archived.set.url";
	public static final String IHEAL_PROVIDER_PROFILE_GET_URL = "iheal.provider.profile.get.url";
	
	public static final String FINTHRIVE_API_URL = "finthrive.api.url";
	public static final String FINTHRIVE_HOST_NAME = "finthrive.host.name";
	public static final String FINTHRIVE_SUBSCRIPTION_KEY = "finthrive.subscription.key";
	

}
