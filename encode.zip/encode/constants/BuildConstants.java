package com.healogics.encode.constants;

public class BuildConstants {

	private BuildConstants() {
	}

	public static final String BUILD_PROP_FILE_PATH = "target/classes/build.properties";
	public static final String GIT_PROP_FILE_PATH = "target/classes/git.properties";
	public static final String GIT_PROP_REVISION = "revision";
	public static final String GIT_PROP_USERID = "userid";
	public static final String BUILD_APP_NAME = "app.name";
	public static final String BUILD_APP_PLATFORM = "app.platform";
	public static final String BUILD_APP_COMPONENT = "app.component";
	public static final String BUILD_APP_ENVIRONMENT = "app.environment";
	public static final String BUILD_APP_VERSION = "app.build.version";
	public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ssZ";
	public static final String DYNAMO_TABLE_NAME = "app_build_version";
	public static final String AWS_ACCESSKEY = "aws.dynamodb.accessKey";
	public static final String AWS_SECRETKEY = "aws.dynamodb.secretKey";

}
