package com.healogics.encode.constants;

public class UtilConstants {
	private UtilConstants() {
		
	}
	public static final String TIMESTAMP_FORMAT_WITH_T = "yyyy-MM-dd'T'HH:mm:ssZ";
	public static final String TIMESTAMP = "timestamp";
	public static final String ACTION = "action";
}
