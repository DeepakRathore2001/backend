package com.healogics.encode.exception;

public class EncodeExceptionHandler extends Exception{

	public EncodeExceptionHandler(String message) {
		super(message);
	}
	
	public EncodeExceptionHandler(String message, Throwable cause) {
		super(message,cause);
	}
	
}
