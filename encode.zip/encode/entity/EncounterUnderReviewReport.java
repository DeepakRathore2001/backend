package com.healogics.encode.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "encounter_under_review_report ")
public class EncounterUnderReviewReport {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "patient_id")
	private int patientId;

	@Column(name = "provider_id")
	private int providerId;

	@Column(name = "total")
	private long total;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "deficiency_date")
	private Date deficiencyDate;

	@Column(name = "days_in_review")
	private long daysInReview;

	@Column(name = "date_of_service")
	private Date dateOfService;

	@Column(name = "deficiency_reason")
	private String deficiencyReason;

	@Column(name = "deficient_note")
	private String deficiencyNote;
	
	@Column(name = "child_bluebook_id")
	private String childBluebookId;
	
	@Column(name = "coder_user_id")
	private String coderUserId;
	
	@Column(name = "coder_user_fullname")
	private String coderUserFullname;
	
	

	public String getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}

	public String getCoderUserFullname() {
		return coderUserFullname;
	}

	public void setCoderUserFullname(String coderUserFullname) {
		this.coderUserFullname = coderUserFullname;
	}

	public String getChildBluebookId() {
		return childBluebookId;
	}

	public void setChildBluebookId(String childBluebookId) {
		this.childBluebookId = childBluebookId;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public long getVisitId() {
		return visitId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public Date getDeficiencyDate() {
		return deficiencyDate;
	}

	public void setDeficiencyDate(Date deficiencyDate) {
		this.deficiencyDate = deficiencyDate;
	}

	public long getDaysInReview() {
		return daysInReview;
	}

	public void setDaysInReview(long daysInReview) {
		this.daysInReview = daysInReview;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getDeficiencyNote() {
		return deficiencyNote;
	}

	public void setDeficiencyNote(String deficiencyNote) {
		this.deficiencyNote = deficiencyNote;
	}

	@Override
	public String toString() {
		return "EncounterUnderReviewReport [visitId=" + visitId + ", bluebookId=" + bluebookId + ", patientId="
				+ patientId + ", providerId=" + providerId + ", total=" + total + ", patientName=" + patientName
				+ ", providerName=" + providerName + ", ihealConfig=" + ihealConfig + ", deficiencyDate="
				+ deficiencyDate + ", daysInReview=" + daysInReview + ", dateOfService=" + dateOfService
				+ ", deficiencyReason=" + deficiencyReason + ", deficiencyNote=" + deficiencyNote + ", childBluebookId="
				+ childBluebookId + ", coderUserId=" + coderUserId + ", coderUserFullname=" + coderUserFullname + "]";
	}

}
