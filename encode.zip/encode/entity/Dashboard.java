package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "dashboard")
public class Dashboard {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "patient_name", insertable = false, updatable = false)
	private String patientName;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_alias")
	private String facilityAlias;

	@Column(name = "received_date")
	private Timestamp receivedDate;

	@Column(name = "provider_name", insertable = false, updatable = false)
	private String providerName;

	@Column(name = "date_of_service")
	private Timestamp dateOfService;

	@Column(name = "medical_record_number")
	private String medicalRecordNumber;

	@Column(name = "encounter_type")
	private String encounterType;

	@Column(name = "assignee_username")
	private String assigneeUsername;

	@Column(name = "assignee_user_id")
	private Long assigneeUserId;

	@Column(name = "assignee_user_fullname")
	private String assigneeUserFullname;

	@Column(name = "assignee_role")
	private String assigneeRole;

	@Column(name = "status")
	private String status;

	@Lob
	@Column(name = "cmc_notes")
	private String cmcNotes;

	@Column(name = "account_number")
	private Long accountNumber;

	@Column(name = "message_datetime")
	private Timestamp messageDatetime;

	@Column(name = "event_datetime")
	private Timestamp eventDatetime;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "provider_first_name")
	private String providerFirstName;

	@Column(name = "provider_last_name")
	private String providerLastName;

	@Column(name = "primary_insurance")
	private String primaryInsurance;

	@Column(name = "secondary_insurance")
	private String secondaryInsurance;

	@Column(name = "gender")
	private String gender;

	@Column(name = "iheal_config ")
	private String ihealConfig;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "pend_reason")
	private String pendReason;

	@Column(name = "unbillable_reason")
	private String unbillableReason;

	@Column(name = "last_updated_by_username")
	private String lastUpdatedByUsername;

	@Column(name = "last_updated_by_userid")
	private String lastUpdatedByUserId;

	@Column(name = "last_updated_by_user_fullname")
	private String lastUpdatedByUserFullName;

	@Column(name = "last_updated_by_timestamp")
	private Timestamp lastUpdatedByTimestamp;

	@Column(name = "is_locked")
	private int isLocked;

	@Column(name = "is_prognote_signed")
	private Boolean isProgNoteSigned;

	@Column(name = "is_hbo_signed")
	private Boolean isHBOSigned;

	@Column(name = "last_status_change_role")
	private String lastStatusChangeRole;

	@Column(name = "service_line")
	private String serviceLine;

	@Column(name = "validated_cmc_user")
	private String validatedCMCUser;

	@Column(name = "completed_coder_user")
	private String completedCoderUser;
	
	@Column(name = "completed_coder_user_id")
	private String completedCoderUserId;

	@Column(name = "provider_id")
	private String providerId;

	@Column(name = "coder_user_id")
	private String coderUserId;
	
	@Column(name = "coder_username")
	private String coderUserName;
	
	@Column(name = "coder_user_fullname")
	private String coderUserFullname;

	@Column(name = "coder_first_name")
	private String coderFirstName;

	@Column(name = "coder_last_name")
	private String coderLastName;

	@Column(name = "icd_code")
	private String icdCode;

	@Column(name = "cpt_code")
	private String cptCode;

	@Column(name = "modifier")
	private String modifier;

	@Column(name = "unit")
	private String unit;

	@Column(name = "last_accessed_timestamp ")
	private Timestamp lastAccessedTimestamp;

	@Column(name = "guidance_date")
	private Timestamp guidanceDate;

	@Column(name = "coder_notes")
	private String coderNotes;

	@Column(name = "guidance_notes")
	private String guidanceNotes;

	@Column(name = "review_reason")
	private String reviewReason;

	@Column(name = "facility_type")
	private String facilityType;

	@Column(name = "snf_location_bbc")
	private String snfLocationBBC;

	@Column(name = "snf_location_name")
	private String snfLocationName;

	@Column(name = "is_snf_location")
	private boolean isSNFLocation;

	@Column(name = "in_audit_queue")
	private boolean inAuditQueue;
	
	@Column(name = "is_sb_signed")
	private Boolean isSBSigned;
	
	@Column(name ="team") 
	private String team;
		
	@Column(name = "status_change_timestamp")
	private Timestamp statusChangeTimestamp;
	
	@Column(name = "start_time")
	private Timestamp startTime;
	
	@Column(name = "end_time")
	private Timestamp endTime;
	
	@Column(name = "coder_id")
	private Integer coderId;
	
	@Column(name = "end_date", insertable = false, updatable = false)
	private Date endDate;
	
	@Column(name = "time_in_ms")
	private Long timeInMs;

	public String getCoderUserFullname() {
		return coderUserFullname;
	}

	public void setCoderUserFullname(String coderUserFullname) {
		this.coderUserFullname = coderUserFullname;
	}

	public String getCompletedCoderUserId() {
		return completedCoderUserId;
	}

	public void setCompletedCoderUserId(String completedCoderUserId) {
		this.completedCoderUserId = completedCoderUserId;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public Integer getCoderId() {
		return coderId;
	}

	public void setCoderId(Integer coderId) {
		this.coderId = coderId;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Long getTimeInMs() {
		return timeInMs;
	}

	public void setTimeInMs(Long timeInMs) {
		this.timeInMs = timeInMs;
	}

	public Boolean getIsSBSigned() {
		return isSBSigned;
	}

	public Timestamp getStatusChangeTimestamp() {
		return statusChangeTimestamp;
	}

	public void setStatusChangeTimestamp(Timestamp statusChangeTimestamp) {
		this.statusChangeTimestamp = statusChangeTimestamp;
	}

	public void setIsSBSigned(Boolean isSBSigned) {
		this.isSBSigned = isSBSigned;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public boolean isInAuditQueue() {
		return inAuditQueue;
	}

	public void setInAuditQueue(boolean inAuditQueue) {
		this.inAuditQueue = inAuditQueue;
	}

	public String getSnfLocationBBC() {
		return snfLocationBBC;
	}

	public void setSnfLocationBBC(String snfLocationBBC) {
		this.snfLocationBBC = snfLocationBBC;
	}

	public String getSnfLocationName() {
		return snfLocationName;
	}

	public void setSnfLocationName(String snfLocationName) {
		this.snfLocationName = snfLocationName;
	}

	public boolean isSNFLocation() {
		return isSNFLocation;
	}

	public void setSNFLocation(boolean isSNFLocation) {
		this.isSNFLocation = isSNFLocation;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getGuidanceNotes() {
		return guidanceNotes;
	}

	public void setGuidanceNotes(String guidanceNotes) {
		this.guidanceNotes = guidanceNotes;
	}

	public String getReviewReason() {
		return reviewReason;
	}

	public void setReviewReason(String reviewReason) {
		this.reviewReason = reviewReason;
	}

	public Timestamp getGuidanceDate() {
		return guidanceDate;
	}

	public void setGuidanceDate(Timestamp guidanceDate) {
		this.guidanceDate = guidanceDate;
	}

	public String getCoderNotes() {
		return coderNotes;
	}

	public void setCoderNotes(String coderNotes) {
		this.coderNotes = coderNotes;
	}

	public Timestamp getLastAccessedTimestamp() {
		return lastAccessedTimestamp;
	}

	public void setLastAccessedTimestamp(Timestamp lastAccessedTimestamp) {
		this.lastAccessedTimestamp = lastAccessedTimestamp;
	}

	public String getValidatedCMCUser() {
		return validatedCMCUser;
	}

	public void setValidatedCMCUser(String validatedCMCUser) {
		this.validatedCMCUser = validatedCMCUser;
	}

	public String getCompletedCoderUser() {
		return completedCoderUser;
	}

	public void setCompletedCoderUser(String completedCoderUser) {
		this.completedCoderUser = completedCoderUser;
	}

	public Timestamp getLastUpdatedByTimestamp() {
		return lastUpdatedByTimestamp;
	}

	public void setLastUpdatedByTimestamp(Timestamp lastUpdatedByTimestamp) {
		this.lastUpdatedByTimestamp = lastUpdatedByTimestamp;
	}

	public String getLastStatusChangeRole() {
		return lastStatusChangeRole;
	}

	public void setLastStatusChangeRole(String lastStatusChangeRole) {
		this.lastStatusChangeRole = lastStatusChangeRole;
	}

	public Boolean isProgNoteSigned() {
		return isProgNoteSigned;
	}

	public void setProgNoteSigned(Boolean isProgNoteSigned) {
		this.isProgNoteSigned = isProgNoteSigned;
	}

	public Boolean isHBOSigned() {
		return isHBOSigned;
	}

	public void setHBOSigned(Boolean isHBOSigned) {
		this.isHBOSigned = isHBOSigned;
	}

	public String getPendReason() {
		return pendReason;
	}

	public void setPendReason(String pendReason) {
		this.pendReason = pendReason;
	}

	public String getUnbillableReason() {
		return unbillableReason;
	}

	public void setUnbillableReason(String unbillableReason) {
		this.unbillableReason = unbillableReason;
	}

	public String getLastUpdatedByUsername() {
		return lastUpdatedByUsername;
	}

	public void setLastUpdatedByUsername(String lastUpdatedByUsername) {
		this.lastUpdatedByUsername = lastUpdatedByUsername;
	}

	public String getLastUpdatedByUserId() {
		return lastUpdatedByUserId;
	}

	public void setLastUpdatedByUserId(String lastUpdatedByUserId) {
		this.lastUpdatedByUserId = lastUpdatedByUserId;
	}

	public String getLastUpdatedByUserFullName() {
		return lastUpdatedByUserFullName;
	}

	public void setLastUpdatedByUserFullName(String lastUpdatedByUserFullName) {
		this.lastUpdatedByUserFullName = lastUpdatedByUserFullName;
	}

	public Timestamp getMessageDatetime() {
		return messageDatetime;
	}

	public void setMessageDatetime(Timestamp messageDatetime) {
		this.messageDatetime = messageDatetime;
	}

	public Timestamp getEventDatetime() {
		return eventDatetime;
	}

	public void setEventDatetime(Timestamp eventDatetime) {
		this.eventDatetime = eventDatetime;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public Timestamp getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Timestamp receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getAssigneeUsername() {
		return assigneeUsername;
	}

	public void setAssigneeUsername(String assigneeUsername) {
		this.assigneeUsername = assigneeUsername;
	}

	public Long getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(Long assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserFullname() {
		return assigneeUserFullname;
	}

	public void setAssigneeUserFullname(String assigneeUserFullname) {
		this.assigneeUserFullname = assigneeUserFullname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCmcNotes() {
		return cmcNotes;
	}

	public void setCmcNotes(String cmcNotes) {
		this.cmcNotes = cmcNotes;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}

	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public Boolean getIsProgNoteSigned() {
		return isProgNoteSigned;
	}

	public void setIsProgNoteSigned(Boolean isProgNoteSigned) {
		this.isProgNoteSigned = isProgNoteSigned;
	}

	public Boolean getIsHBOSigned() {
		return isHBOSigned;
	}

	public void setIsHBOSigned(Boolean isHBOSigned) {
		this.isHBOSigned = isHBOSigned;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public String getCoderFirstName() {
		return coderFirstName;
	}

	public void setCoderFirstName(String coderFirstName) {
		this.coderFirstName = coderFirstName;
	}

	public String getCoderLastName() {
		return coderLastName;
	}

	public void setCoderLastName(String coderLastName) {
		this.coderLastName = coderLastName;
	}

	public String getIcdCode() {
		return icdCode;
	}

	public void setIcdCode(String icdCode) {
		this.icdCode = icdCode;
	}

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getAssigneeRole() {
		return assigneeRole;
	}

	public void setAssigneeRole(String assigneeRole) {
		this.assigneeRole = assigneeRole;
	}

	@Override
	public String toString() {
		return "Dashboard [visitId=" + visitId + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId + ", facilityAlias=" + facilityAlias
				+ ", receivedDate=" + receivedDate + ", providerName=" + providerName + ", dateOfService="
				+ dateOfService + ", medicalRecordNumber=" + medicalRecordNumber + ", encounterType=" + encounterType
				+ ", assigneeUsername=" + assigneeUsername + ", assigneeUserId=" + assigneeUserId
				+ ", assigneeUserFullname=" + assigneeUserFullname + ", assigneeRole=" + assigneeRole + ", status="
				+ status + ", cmcNotes=" + cmcNotes + ", accountNumber=" + accountNumber + ", messageDatetime="
				+ messageDatetime + ", eventDatetime=" + eventDatetime + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", providerFirstName=" + providerFirstName
				+ ", providerLastName=" + providerLastName + ", primaryInsurance=" + primaryInsurance
				+ ", secondaryInsurance=" + secondaryInsurance + ", gender=" + gender + ", ihealConfig=" + ihealConfig
				+ ", patientDOB=" + patientDOB + ", pendReason=" + pendReason + ", unbillableReason=" + unbillableReason
				+ ", lastUpdatedByUsername=" + lastUpdatedByUsername + ", lastUpdatedByUserId=" + lastUpdatedByUserId
				+ ", lastUpdatedByUserFullName=" + lastUpdatedByUserFullName + ", lastUpdatedByTimestamp="
				+ lastUpdatedByTimestamp + ", isLocked=" + isLocked + ", isProgNoteSigned=" + isProgNoteSigned
				+ ", isHBOSigned=" + isHBOSigned + ", lastStatusChangeRole=" + lastStatusChangeRole + ", serviceLine="
				+ serviceLine + ", validatedCMCUser=" + validatedCMCUser + ", completedCoderUser=" + completedCoderUser
				+ ", completedCoderUserId=" + completedCoderUserId + ", providerId=" + providerId + ", coderUserId="
				+ coderUserId + ", coderUserName=" + coderUserName + ", coderUserFullname=" + coderUserFullname
				+ ", coderFirstName=" + coderFirstName + ", coderLastName=" + coderLastName + ", icdCode=" + icdCode
				+ ", cptCode=" + cptCode + ", modifier=" + modifier + ", unit=" + unit + ", lastAccessedTimestamp="
				+ lastAccessedTimestamp + ", guidanceDate=" + guidanceDate + ", coderNotes=" + coderNotes
				+ ", guidanceNotes=" + guidanceNotes + ", reviewReason=" + reviewReason + ", facilityType="
				+ facilityType + ", snfLocationBBC=" + snfLocationBBC + ", snfLocationName=" + snfLocationName
				+ ", isSNFLocation=" + isSNFLocation + ", inAuditQueue=" + inAuditQueue + ", isSBSigned=" + isSBSigned
				+ ", team=" + team + ", statusChangeTimestamp=" + statusChangeTimestamp + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", coderId=" + coderId + ", endDate=" + endDate + ", timeInMs=" + timeInMs
				+ "]";
	}

}
