
package com.healogics.encode.entity;

import java.util.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "chart_details")
public class ChartDetails {
	@Id
	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "deficient_provider_user_id")
	private Long deficientProviderUserId;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "deficient_provider_name")
	private String deficientProviderName;

	@Column(name = "deficient_provider_username")
	private String deficientProviderUsername;

	@Column(name = "deficiency_reason")
	private String deficiencyReason;

	@Column(name = "deficient_note ")
	private String deficientNote;

	@Column(name = "was_deficient")
	private int wasDeficient;

	@Column(name = "is_deficient")
	private int isDeficient;
	
	@Column(name = "escalated_user_id")
	private Long escalatedUserId;

	@Column(name = "escalated_username")
	private String escalatedUsername;
	
	@Column(name = "was_escalated")
	private int wasEscalated;

	@Column(name = "is_escalated")
	private int isEscalated;

	@Column(name = "escalation_reason")
	private String escalationReason;

	@Column(name = "escalation_note")
	private String escalationNote;

	@Column(name = "tagged_users", columnDefinition = "json")
	private String taggedUsers;

	@Column(name = "provider_cpt_code")
	private String providerCPTCode;

	@Column(name = "weakness_reason")
	private String weaknessReason;

	@Column(name = "weakness_note")
	private String weaknessNote;

	@Column(name = "coder_cpt_code")
	private String coderCPTCode;

	@Column(name = "coder_username")
	private String coderUserName;

	@Column(name = "coder_user_fullname")
	private String coderUserFullName;

	@Column(name = "coder_user_id")
	private long coderUserId;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "patient_admit_date")
	private Date patientAdmitDate;

	@Column(name = "place_of_service")
	private String placeOfService;

	@Column(name = "accident_or_illness")
	private String accidentOrIllness;

	@Column(name = "icd_codes", columnDefinition = "json")
	private String icdCodes;

	@Column(name = "cpt_codes", columnDefinition = "json")
	private String cptCodes;

	@Column(name = "cpt_object", columnDefinition = "json")
	private String cptObject;

	@Column(name = "accident_illness_date")
	private Date accidentIllnessDate;

	@Column(name = "time_doc_chart")
	private int timeDocChart;

	@Column(name = "time_em_level")
	private int timeEmLevel;

	@Column(name = "accident_category")
	private String accidentCategory;

	@Column(name = "returned_note")
	private String returnedNote;

	@Column(name = "returned_username")
	private String returnedUserName;

	@Column(name = "returned_user_id")
	private Long returnedUserId;

	@Column(name = "returned_user_fullname")
	private String returnedUserFullName;

	@Column(name = "audit_category")
	private String auditCategory;

	@Column(name = "audit_reason")
	private String auditReason;

	@Column(name = "audit_reason_note")
	private String auditReasonNote;

	@Column(name = "auditor_icd_codes", columnDefinition = "json")
	private String auditorICDCodes;

	@Column(name = "auditor_cpt_codes", columnDefinition = "json")
	private String auditorCPTCodes;

	@Column(name = "in_audit")
	private int inAudit;

	@Column(name = "sbill_icd_codes", columnDefinition = "json")
	private String superBillICDCodes;

	@Column(name = "sbill_provider_cpt_codes", columnDefinition = "json")
	private String superBillProviderCPTCodes;

	@Column(name = "sbill_provider_em", columnDefinition = "json")
	private String superBillProviderEM;

	@Column(name = "facility_em", columnDefinition = "json")
	private String superBillfacilityEM;

	@Column(name = "coding_validations", columnDefinition = "json")
	private String codingValidations;

	@Column(name = "nurse_deficiency_reason")
	private String nurseDeficiencyReason;

	@Column(name = "auditor_user_id")
	private Long auditorUserId;

	@Column(name = "auditor_username")
	private String auditorUserName;

	@Column(name = "auditor_userfullname")
	private String auditorUserFullName;

	@Column(name = "message_id")
	private Long messageId;

	@Column(name = "coc_id")
	private String cocId;

	@Column(name = "child_bluebook_id")
	private String childBluebookId;

	@Column(name = "deficiency_start_date ")
	private Timestamp deficiencyStartDate;

	@Column(name = "provider_id")
	private String providerId;

	@Column(name = "provider_firstname")
	private String providerFirstName;

	@Column(name = "provider_lastname")
	private String providerLastName;

	@Column(name = "provider_fullname")
	private String providerFullName;
	
	@Column(name = "pend_provider_id")
	private Long pendProviderId;
	
	@Column(name = "pend_provider_name")
	private String pendProviderName;
	
	public Long getEscalatedUserId() {
		return escalatedUserId;
	}

	public void setEscalatedUserId(Long escalatedUserId) {
		this.escalatedUserId = escalatedUserId;
	}

	public String getEscalatedUsername() {
		return escalatedUsername;
	}

	public void setEscalatedUsername(String escalatedUsername) {
		this.escalatedUsername = escalatedUsername;
	}

	public Long getPendProviderId() {
		return pendProviderId;
	}

	public void setPendProviderId(Long pendProviderId) {
		this.pendProviderId = pendProviderId;
	}

	public String getPendProviderName() {
		return pendProviderName;
	}

	public void setPendProviderName(String pendProviderName) {
		this.pendProviderName = pendProviderName;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public String getProviderFullName() {
		return providerFullName;
	}

	public void setProviderFullName(String providerFullName) {
		this.providerFullName = providerFullName;
	}

	public Timestamp getDeficiencyStartDate() {
		return deficiencyStartDate;
	}

	public void setDeficiencyStartDate(Timestamp deficiencyStartDate) {
		this.deficiencyStartDate = deficiencyStartDate;
	}

	public String getCocId() {
		return cocId;
	}

	public void setCocId(String cocId) {
		this.cocId = cocId;
	}

	public String getChildBluebookId() {
		return childBluebookId;
	}

	public void setChildBluebookId(String childBluebookId) {
		this.childBluebookId = childBluebookId;
	}

	public String getCoderUserFullName() {
		return coderUserFullName;
	}

	public void setCoderUserFullName(String coderUserFullName) {
		this.coderUserFullName = coderUserFullName;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public Long getAuditorUserId() {
		return auditorUserId;
	}

	public void setAuditorUserId(Long auditorUserId) {
		this.auditorUserId = auditorUserId;
	}

	public String getAuditorUserName() {
		return auditorUserName;
	}

	public void setAuditorUserName(String auditorUserName) {
		this.auditorUserName = auditorUserName;
	}

	public String getAuditorUserFullName() {
		return auditorUserFullName;
	}

	public void setAuditorUserFullName(String auditorUserFullName) {
		this.auditorUserFullName = auditorUserFullName;
	}

	public String getCodingValidations() {
		return codingValidations;
	}

	public void setCodingValidations(String codingValidations) {
		this.codingValidations = codingValidations;
	}

	public String getSuperBillICDCodes() {
		return superBillICDCodes;
	}

	public void setSuperBillICDCodes(String superBillICDCodes) {
		this.superBillICDCodes = superBillICDCodes;
	}

	public String getSuperBillProviderCPTCodes() {
		return superBillProviderCPTCodes;
	}

	public void setSuperBillProviderCPTCodes(String superBillProviderCPTCodes) {
		this.superBillProviderCPTCodes = superBillProviderCPTCodes;
	}

	public String getSuperBillProviderEM() {
		return superBillProviderEM;
	}

	public void setSuperBillProviderEM(String superBillProviderEM) {
		this.superBillProviderEM = superBillProviderEM;
	}

	public String getSuperBillfacilityEM() {
		return superBillfacilityEM;
	}

	public void setSuperBillfacilityEM(String superBillfacilityEM) {
		this.superBillfacilityEM = superBillfacilityEM;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getDeficientProviderUserId() {
		return deficientProviderUserId;
	}

	public void setDeficientProviderUserId(Long deficientProviderUserId) {
		this.deficientProviderUserId = deficientProviderUserId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getDeficientProviderName() {
		return deficientProviderName;
	}

	public void setDeficientProviderName(String deficientProviderName) {
		this.deficientProviderName = deficientProviderName;
	}

	public String getDeficientProviderUsername() {
		return deficientProviderUsername;
	}

	public void setDeficientProviderUsername(String deficientProviderUsername) {
		this.deficientProviderUsername = deficientProviderUsername;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getProviderCPTCode() {
		return providerCPTCode;
	}

	public void setProviderCPTCode(String providerCPTCode) {
		this.providerCPTCode = providerCPTCode;
	}

	public String getWeaknessReason() {
		return weaknessReason;
	}

	public void setWeaknessReason(String weaknessReason) {
		this.weaknessReason = weaknessReason;
	}

	public String getCoderCPTCode() {
		return coderCPTCode;
	}

	public void setCoderCPTCode(String coderCPTCode) {
		this.coderCPTCode = coderCPTCode;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public long getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(long coderUserId) {
		this.coderUserId = coderUserId;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public int getWasDeficient() {
		return wasDeficient;
	}

	public void setWasDeficient(int wasDeficient) {
		this.wasDeficient = wasDeficient;
	}

	public int getIsDeficient() {
		return isDeficient;
	}

	public void setIsDeficient(int isDeficient) {
		this.isDeficient = isDeficient;
	}

	public int getWasEscalated() {
		return wasEscalated;
	}

	public void setWasEscalated(int wasEscalated) {
		this.wasEscalated = wasEscalated;
	}

	public int getIsEscalated() {
		return isEscalated;
	}

	public void setIsEscalated(int isEscalated) {
		this.isEscalated = isEscalated;
	}

	public String getEscalationReason() {
		return escalationReason;
	}

	public void setEscalationReason(String escalationReason) {
		this.escalationReason = escalationReason;
	}

	public String getEscalationNote() {
		return escalationNote;
	}

	public void setEscalationNote(String escalationNote) {
		this.escalationNote = escalationNote;
	}

	public String getWeaknessNote() {
		return weaknessNote;
	}

	public void setWeaknessNote(String weaknessNote) {
		this.weaknessNote = weaknessNote;
	}

	public String getTaggedUsers() {
		return taggedUsers;
	}

	public void setTaggedUsers(String taggedUsers) {
		this.taggedUsers = taggedUsers;
	}

	public Date getPatientAdmitDate() {
		return patientAdmitDate;
	}

	public void setPatientAdmitDate(Date patientAdmitDate) {
		this.patientAdmitDate = patientAdmitDate;
	}

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getAccidentOrIllness() {
		return accidentOrIllness;
	}

	public void setAccidentOrIllness(String accidentOrIllness) {
		this.accidentOrIllness = accidentOrIllness;
	}

	public String getIcdCodes() {
		return icdCodes;
	}

	public void setIcdCodes(String icdCodes) {
		this.icdCodes = icdCodes;
	}

	public String getCptObject() {
		return cptObject;
	}

	public void setCptObject(String cptObject) {
		this.cptObject = cptObject;
	}

	public Date getAccidentIllnessDate() {
		return accidentIllnessDate;
	}

	public void setAccidentIllnessDate(Date accidentIllnessDate) {
		this.accidentIllnessDate = accidentIllnessDate;
	}

	public int getTimeDocChart() {
		return timeDocChart;
	}

	public void setTimeDocChart(int timeDocChart) {
		this.timeDocChart = timeDocChart;
	}

	public int getTimeEmLevel() {
		return timeEmLevel;
	}

	public void setTimeEmLevel(int timeEmLevel) {
		this.timeEmLevel = timeEmLevel;
	}

	public String getDeficientNote() {
		return deficientNote;
	}

	public void setDeficientNote(String deficientNote) {
		this.deficientNote = deficientNote;
	}

	public String getAccidentCategory() {
		return accidentCategory;
	}

	public void setAccidentCategory(String accidentCategory) {
		this.accidentCategory = accidentCategory;
	}

	public String getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(String cptCodes) {
		this.cptCodes = cptCodes;
	}

	public String getReturnedNote() {
		return returnedNote;
	}

	public void setReturnedNote(String returnedNote) {
		this.returnedNote = returnedNote;
	}

	public String getReturnedUserName() {
		return returnedUserName;
	}

	public void setReturnedUserName(String returnedUserName) {
		this.returnedUserName = returnedUserName;
	}

	public Long getReturnedUserId() {
		return returnedUserId;
	}

	public void setReturnedUserId(Long returnedUserId) {
		this.returnedUserId = returnedUserId;
	}

	public String getReturnedUserFullName() {
		return returnedUserFullName;
	}

	public void setReturnedUserFullName(String returnedUserFullName) {
		this.returnedUserFullName = returnedUserFullName;
	}

	public String getAuditCategory() {
		return auditCategory;
	}

	public void setAuditCategory(String auditCategory) {
		this.auditCategory = auditCategory;
	}

	public String getAuditReason() {
		return auditReason;
	}

	public void setAuditReason(String auditReason) {
		this.auditReason = auditReason;
	}

	public String getAuditReasonNote() {
		return auditReasonNote;
	}

	public void setAuditReasonNote(String auditReasonNote) {
		this.auditReasonNote = auditReasonNote;
	}

	public String getAuditorICDCodes() {
		return auditorICDCodes;
	}

	public void setAuditorICDCodes(String auditorICDCodes) {
		this.auditorICDCodes = auditorICDCodes;
	}

	public String getAuditorCPTCodes() {
		return auditorCPTCodes;
	}

	public void setAuditorCPTCodes(String auditorCPTCodes) {
		this.auditorCPTCodes = auditorCPTCodes;
	}

	public int getInAudit() {
		return inAudit;
	}

	public void setInAudit(int inAudit) {
		this.inAudit = inAudit;
	}

	public String getNurseDeficiencyReason() {
		return nurseDeficiencyReason;
	}

	public void setNurseDeficiencyReason(String nurseDeficiencyReason) {
		this.nurseDeficiencyReason = nurseDeficiencyReason;
	}

	@Override
	public String toString() {
		return "ChartDetails [visitId=" + visitId + ", patientId=" + patientId + ", deficientProviderUserId="
				+ deficientProviderUserId + ", providerName=" + providerName + ", deficientProviderName="
				+ deficientProviderName + ", deficientProviderUsername=" + deficientProviderUsername
				+ ", deficiencyReason=" + deficiencyReason + ", deficientNote=" + deficientNote + ", wasDeficient="
				+ wasDeficient + ", isDeficient=" + isDeficient + ", escalatedUserId=" + escalatedUserId
				+ ", escalatedUsername=" + escalatedUsername + ", wasEscalated=" + wasEscalated + ", isEscalated="
				+ isEscalated + ", escalationReason=" + escalationReason + ", escalationNote=" + escalationNote
				+ ", taggedUsers=" + taggedUsers + ", providerCPTCode=" + providerCPTCode + ", weaknessReason="
				+ weaknessReason + ", weaknessNote=" + weaknessNote + ", coderCPTCode=" + coderCPTCode
				+ ", coderUserName=" + coderUserName + ", coderUserFullName=" + coderUserFullName + ", coderUserId="
				+ coderUserId + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", patientAdmitDate="
				+ patientAdmitDate + ", placeOfService=" + placeOfService + ", accidentOrIllness=" + accidentOrIllness
				+ ", icdCodes=" + icdCodes + ", cptCodes=" + cptCodes + ", cptObject=" + cptObject
				+ ", accidentIllnessDate=" + accidentIllnessDate + ", timeDocChart=" + timeDocChart + ", timeEmLevel="
				+ timeEmLevel + ", accidentCategory=" + accidentCategory + ", returnedNote=" + returnedNote
				+ ", returnedUserName=" + returnedUserName + ", returnedUserId=" + returnedUserId
				+ ", returnedUserFullName=" + returnedUserFullName + ", auditCategory=" + auditCategory
				+ ", auditReason=" + auditReason + ", auditReasonNote=" + auditReasonNote + ", auditorICDCodes="
				+ auditorICDCodes + ", auditorCPTCodes=" + auditorCPTCodes + ", inAudit=" + inAudit
				+ ", superBillICDCodes=" + superBillICDCodes + ", superBillProviderCPTCodes="
				+ superBillProviderCPTCodes + ", superBillProviderEM=" + superBillProviderEM + ", superBillfacilityEM="
				+ superBillfacilityEM + ", codingValidations=" + codingValidations + ", nurseDeficiencyReason="
				+ nurseDeficiencyReason + ", auditorUserId=" + auditorUserId + ", auditorUserName=" + auditorUserName
				+ ", auditorUserFullName=" + auditorUserFullName + ", messageId=" + messageId + ", cocId=" + cocId
				+ ", childBluebookId=" + childBluebookId + ", deficiencyStartDate=" + deficiencyStartDate
				+ ", providerId=" + providerId + ", providerFirstName=" + providerFirstName + ", providerLastName="
				+ providerLastName + ", providerFullName=" + providerFullName + ", pendProviderId=" + pendProviderId
				+ ", pendProviderName=" + pendProviderName + "]";
	}
}
