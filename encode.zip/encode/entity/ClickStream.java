package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "clickstream")
public class ClickStream {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "patient_id ")
	private int patientId;

	@Column(name = "visit_id ")
	private Long visitId;

	@Column(name = "facility_id ")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "module_name")
	private String moduleName;

	@Column(name = "module_description")
	private String moduleDescription;

	@Column(name = "role")
	private String role;

	@Column(name = "created_timestamp ")
	private Timestamp createdTimestamp;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModuleDescription() {
		return moduleDescription;
	}

	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	@Override
	public String toString() {
		return "ClickStream [id=" + id + ", userId=" + userId + ", patientId=" + patientId + ", visitId=" + visitId
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId + ", moduleName=" + moduleName
				+ ", moduleDescription=" + moduleDescription + ", role=" + role + ", createdTimestamp="
				+ createdTimestamp + "]";
	}

}
