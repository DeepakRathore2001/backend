package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "disparate_facilities")
public class DisparateFacilities {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "bluebook_id")
	private String bbc;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	@Override
	public String toString() {
		return "DisparateFacilities [id=" + id + ", bbc=" + bbc + ", createdTimestamp=" + createdTimestamp + "]";
	}

}
