package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "audit_filters_source")
public class AuditFiltersSource {

	@Id
	@Column(name = "id")
	private long id;

	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "provider_id")
	private long providerId;

	@Column(name = "icd_code")
	private String icdCode;

	@Column(name = "cpt_code")
	private String cptCode;

	@Column(name = "modifier")
	private String modifier;

	@Column(name = "unit")
	private int unit;

	@Column(name = "coder_user_id")
	private long coderUserId;

	@Column(name = "insurance")
	private String insurance;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "record_active")
	private int recordActive;

	@Column(name = "patient_dos")
	private Date patientDOS;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "audit_queue")
	private int auditQueue;

	@Column(name = "status")
	private String status;

	@Column(name = "primary_insruance")
	private String primaryInsurance;

	@Column(name = "secondary_insruance")
	private String secondaryInsurance;

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}

	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}

	public int getAuditQueue() {
		return auditQueue;
	}

	public void setAuditQueue(int auditQueue) {
		this.auditQueue = auditQueue;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Date getPatientDOS() {
		return patientDOS;
	}

	public void setPatientDOS(Date patientDOS) {
		this.patientDOS = patientDOS;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public long getProviderId() {
		return providerId;
	}

	public void setProviderId(long providerId) {
		this.providerId = providerId;
	}

	public String getIcdCode() {
		return icdCode;
	}

	public void setIcdCode(String icdCode) {
		this.icdCode = icdCode;
	}

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public int getUnit() {
		return unit;
	}

	public void setUnit(int unit) {
		this.unit = unit;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public int getRecordActive() {
		return recordActive;
	}

	public void setRecordActive(int recordActive) {
		this.recordActive = recordActive;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(long coderUserId) {
		this.coderUserId = coderUserId;
	}

	@Override
	public String toString() {
		return "AuditFiltersSource [id=" + id + ", visitId=" + visitId + ", bluebookId=" + bluebookId + ", facilityId="
				+ facilityId + ", providerId=" + providerId + ", icdCode=" + icdCode + ", cptCode=" + cptCode
				+ ", modifier=" + modifier + ", unit=" + unit + ", coderUserId=" + coderUserId + ", insurance="
				+ insurance + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", recordActive=" + recordActive
				+ ", patientDOS=" + patientDOS + ", providerName=" + providerName + ", ihealConfig=" + ihealConfig
				+ ", auditQueue=" + auditQueue + ", status=" + status + ", primaryInsurance=" + primaryInsurance
				+ ", secondaryInsurance=" + secondaryInsurance + "]";
	}

}
