package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_preference")
public class UserPreference {

	@Id
	@Column(name = "user_id")
	private Long userId;

	@Column(name = "username")
	private String username;

	@Column(name = "user_full_name")
	private String userFullname;

	@Column(name = "last_updated_timestamp")
	private LocalDateTime lastUpdatedTimestamp;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "clear_notification")
	private Timestamp clearNotificationTimestamp;

	@Column(name = "avatar_color")
	private String avatarColor;

	@Column(name = "filters", columnDefinition = "json")
	private String Filters;
	
	@Column(name = "pinned_filter_ids", columnDefinition = "json")
	private String pinnedFilterIds;

	public String getPinnedFilterIds() {
		return pinnedFilterIds;
	}

	public void setPinnedFilterIds(String pinnedFilterIds) {
		this.pinnedFilterIds = pinnedFilterIds;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public LocalDateTime getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(LocalDateTime lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getClearNotificationTimestamp() {
		return clearNotificationTimestamp;
	}

	public void setClearNotificationTimestamp(Timestamp clearNotificationTimestamp) {
		this.clearNotificationTimestamp = clearNotificationTimestamp;
	}

	public String getAvatarColor() {
		return avatarColor;
	}

	public void setAvatarColor(String avatarColor) {
		this.avatarColor = avatarColor;
	}

	public String getFilters() {
		return Filters;
	}

	public void setFilters(String filters) {
		Filters = filters;
	}

	@Override
	public String toString() {
		return "UserPreference [userId=" + userId + ", username=" + username + ", userFullname=" + userFullname
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", clearNotificationTimestamp=" + clearNotificationTimestamp + ", avatarColor=" + avatarColor
				+ ", Filters=" + Filters + ", pinnedFilterIds=" + pinnedFilterIds + "]";
	}

}
