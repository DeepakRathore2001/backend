package com.healogics.encode.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "chart_history")
public class HistoryTimeline implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "history_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long historyId;
	
	@Column(name = "visit_id")
	private long visitId;
	
	@Column(name = "patient_id")
	private long patientId;
	
	@Column(name = "patient_name")
	private String patientName;
	
	@Column(name = "facility_id")
	private String facilityId;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "date_of_service")
	private Timestamp dateOfService;
	
	@Column(name = "chart_status")
	private String chartStatus;
	
	@Column(name = "chart_notes")
	private String chartNotes;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	
	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;
	
	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;
	
	@Column(name = "last_updated_userid")
	private long lastUpdatedUserid;
	
	@Column(name = "last_updated_user_role")
	private String lastUpdatedUserRole;

	public long getHistoryId() {
		return historyId;
	}

	public void setHistoryId(long historyId) {
		this.historyId = historyId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getChartStatus() {
		return chartStatus;
	}

	public void setChartStatus(String chartStatus) {
		this.chartStatus = chartStatus;
	}

	public String getChartNotes() {
		return chartNotes;
	}

	public void setChartNotes(String chartNotes) {
		this.chartNotes = chartNotes;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public long getLastUpdatedUserid() {
		return lastUpdatedUserid;
	}

	public void setLastUpdatedUserid(long lastUpdatedUserid) {
		this.lastUpdatedUserid = lastUpdatedUserid;
	}

	public String getLastUpdatedUserRole() {
		return lastUpdatedUserRole;
	}

	public void setLastUpdatedUserRole(String lastUpdatedUserRole) {
		this.lastUpdatedUserRole = lastUpdatedUserRole;
	}

	@Override
	public String toString() {
		return "HistoryTimeline [historyId=" + historyId + ", visitId=" + visitId + ", patientId=" + patientId
				+ ", patientName=" + patientName + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", dateOfService=" + dateOfService + ", chartStatus=" + chartStatus + ", chartNotes=" + chartNotes
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + ", lastUpdatedUserid=" + lastUpdatedUserid
				+ ", lastUpdatedUserRole=" + lastUpdatedUserRole + "]";
	}
}
