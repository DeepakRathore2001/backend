package com.healogics.encode.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reasons")
public class Reasons implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "role")
	private String role;

	@Id
	@Column(name = "title")
	private String title;

	@Column(name = "reasons", columnDefinition = "json")
	private String reasons;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getReasons() {
		return reasons;
	}

	public void setReasons(String reasons) {
		this.reasons = reasons;
	}

	@Override
	public String toString() {
		return "Reasons [role=" + role + ", title=" + title + ", reasons=" + reasons + "]";
	}

}
