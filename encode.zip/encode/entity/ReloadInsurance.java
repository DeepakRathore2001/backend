package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reload_insurance")
public class ReloadInsurance {
	
	@Id
	@Column(name = "visit_id")
	private Integer visitId;

	@Column(name = "patient_id")
	private String patientId;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "facility_id")
	private String facilityId;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "error_code")
	private Integer errorCode;
	
	@Column(name = "error_message")
	private String errorMessage;

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "ReloadInsurance [visitId=" + visitId + ", patientId=" + patientId + ", bluebookId=" + bluebookId
				+ ", facilityId=" + facilityId + ", status=" + status + ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + "]";
	}
	
	

}
