package com.healogics.encode.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "audit_history")
public class AuditHistory {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "coder_name")
	private String coderName;

	@Column(name = "team")
	private String billingClientAbbr;

	@Column(name = "account_number")
	private String accountNumber;

	@Column(name = "provider")
	private String provider;

	@Column(name = "sending_facility")
	private String sendingFacility;

	@Column(name = "dos")
	private Timestamp dos;

	@Column(name = "chart_codes")
	private String chartCodes;

	@Column(name = "audit_notes")
	private String auditNotes;

	@Column(name = "coder_username")
	private String coderUserName;

	@Column(name = "coder_user_id")
	private int coderUserId;

	@Column(name = "audit_completed")
	private Boolean auditCompleted;

	@Column(name = "filter_name")
	private String filterName;

	@Column(name = "coding_error")
	private Boolean codingError;
	
	@Column(name = "audit_date")
	private Date auditDate;
	
	public Date getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public boolean isAuditCompleted() {
		return auditCompleted;
	}

	public void setAuditCompleted(boolean auditCompleted) {
		this.auditCompleted = auditCompleted;
	}

	public boolean isCodingError() {
		return codingError;
	}

	public void setCodingError(boolean codingError) {
		this.codingError = codingError;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getCoderName() {
		return coderName;
	}

	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}

	public String getBillingClientAbbr() {
		return billingClientAbbr;
	}

	public void setBillingClientAbbr(String billingClientAbbr) {
		this.billingClientAbbr = billingClientAbbr;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getSendingFacility() {
		return sendingFacility;
	}

	public void setSendingFacility(String sendingFacility) {
		this.sendingFacility = sendingFacility;
	}

	public Timestamp getDos() {
		return dos;
	}

	public void setDos(Timestamp dos) {
		this.dos = dos;
	}

	public String getChartCodes() {
		return chartCodes;
	}

	public void setChartCodes(String chartCodes) {
		this.chartCodes = chartCodes;
	}

	public String getAuditNotes() {
		return auditNotes;
	}

	public void setAuditNotes(String auditNotes) {
		this.auditNotes = auditNotes;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public int getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(int coderUserId) {
		this.coderUserId = coderUserId;
	}

	@Override
	public String toString() {
		return "AuditHistory [visitId=" + visitId + ", coderName=" + coderName + ", billingClientAbbr="
				+ billingClientAbbr + ", accountNumber=" + accountNumber + ", provider=" + provider
				+ ", sendingFacility=" + sendingFacility + ", dos=" + dos + ", chartCodes=" + chartCodes
				+ ", auditNotes=" + auditNotes + ", coderUserName=" + coderUserName + ", coderUserId=" + coderUserId
				+ ", auditCompleted=" + auditCompleted + ", filterName=" + filterName + ", codingError=" + codingError
				+ ", auditDate=" + auditDate + "]";
	}
}
