package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "message_history")
public class MessageHistory {

	@Id
	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "adt_status")
	private Boolean adtStatus;

	@Column(name = "dft_status")
	private Boolean dftStatus;

	@Column(name = "adt_sent_timestamp")
	private Timestamp adtSentTimestamp;

	@Column(name = "dft_sent_timestamp")
	private Timestamp dftSentTimestamp;

	@Column(name = "error_code")
	private Integer errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "status")
	private String status;

	@Column(name = "message_date")
	private Date messageDate;

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Boolean getAdtStatus() {
		return adtStatus;
	}

	public void setAdtStatus(Boolean adtStatus) {
		this.adtStatus = adtStatus;
	}

	public Boolean getDftStatus() {
		return dftStatus;
	}

	public void setDftStatus(Boolean dftStatus) {
		this.dftStatus = dftStatus;
	}

	public Timestamp getAdtSentTimestamp() {
		return adtSentTimestamp;
	}

	public void setAdtSentTimestamp(Timestamp adtSentTimestamp) {
		this.adtSentTimestamp = adtSentTimestamp;
	}

	public Timestamp getDftSentTimestamp() {
		return dftSentTimestamp;
	}

	public void setDftSentTimestamp(Timestamp dftSentTimestamp) {
		this.dftSentTimestamp = dftSentTimestamp;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getMessageDate() {
		return messageDate;
	}

	public void setMessageDate(Date messageDate) {
		this.messageDate = messageDate;
	}

	@Override
	public String toString() {
		return "MessageHistory [visitId=" + visitId + ", adtStatus=" + adtStatus + ", dftStatus=" + dftStatus
				+ ", adtSentTimestamp=" + adtSentTimestamp + ", dftSentTimestamp=" + dftSentTimestamp + ", errorCode="
				+ errorCode + ", errorMessage=" + errorMessage + ", status=" + status + ", messageDate=" + messageDate
				+ "]";
	}

}
