package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "facility_details")
public class FacilityDetails {

	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Lob
	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "facility_id")
	private int facilityId;

	@Lob
	@Column(name = "division")
	private String division;

	@Lob
	@Column(name = "market")
	private String market;

	@Lob
	@Column(name = "territory")
	private String territory;

	@Lob
	@Column(name = "center_address")
	private String centerAddress;

	@Lob
	@Column(name = "center_city")
	private String centerCity;

	@Lob
	@Column(name = "center_state")
	private String centerState;

	@Column(name = "center_zip")
	private String centerZip;

	@Column(name = "center_phone")
	private String centerPhone;

	@Column(name = "center_fax")
	private String centerFax;

	@Column(name = "old_iheal_config")
	private String oldIHealConfig;

	@Column(name = "current_iheal_config")
	private String currentIHealConfig;

	@Column(name = "iheal_config_changed")
	private Integer ihealConfigChanged;

	@Column(name = "active")
	private int active;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	// New columns
	@Column(name = "old_facility_type")
	private String oldFacilityType;

	@Column(name = "current_facility_type")
	private String currentFacilityType;

	@Column(name = "facility_type_changed")
	private Integer facilityTypeChanged;
	
	@Column(name = "place_of_service")
	private String placeOfService;
	

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getOldFacilityType() {
		return oldFacilityType;
	}

	public void setOldFacilityType(String oldFacilityType) {
		this.oldFacilityType = oldFacilityType;
	}

	public String getCurrentFacilityType() {
		return currentFacilityType;
	}

	public void setCurrentFacilityType(String currentFacilityType) {
		this.currentFacilityType = currentFacilityType;
	}

	public Integer getFacilityTypeChanged() {
		return facilityTypeChanged;
	}

	public void setFacilityTypeChanged(Integer facilityTypeChanged) {
		this.facilityTypeChanged = facilityTypeChanged;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getTerritory() {
		return territory;
	}

	public void setTerritory(String territory) {
		this.territory = territory;
	}

	public String getCenterAddress() {
		return centerAddress;
	}

	public void setCenterAddress(String centerAddress) {
		this.centerAddress = centerAddress;
	}

	public String getCenterCity() {
		return centerCity;
	}

	public void setCenterCity(String centerCity) {
		this.centerCity = centerCity;
	}

	public String getCenterState() {
		return centerState;
	}

	public void setCenterState(String centerState) {
		this.centerState = centerState;
	}

	public String getCenterZip() {
		return centerZip;
	}

	public String getCenterPhone() {
		return centerPhone;
	}

	public String getCenterFax() {
		return centerFax;
	}

	public void setCenterZip(String centerZip) {
		this.centerZip = centerZip;
	}

	public void setCenterPhone(String centerPhone) {
		this.centerPhone = centerPhone;
	}

	public void setCenterFax(String centerFax) {
		this.centerFax = centerFax;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getOldIHealConfig() {
		return oldIHealConfig;
	}

	public void setOldIHealConfig(String oldIHealConfig) {
		this.oldIHealConfig = oldIHealConfig;
	}

	public String getCurrentIHealConfig() {
		return currentIHealConfig;
	}

	public void setCurrentIHealConfig(String currentIHealConfig) {
		this.currentIHealConfig = currentIHealConfig;
	}

	public Integer getIhealConfigChanged() {
		return ihealConfigChanged;
	}

	public void setIhealConfigChanged(Integer ihealConfigChanged) {
		this.ihealConfigChanged = ihealConfigChanged;
	}

	@Override
	public String toString() {
		return "FacilityDetails [bluebookId=" + bluebookId + ", id=" + id
				+ ", facilityName=" + facilityName + ", facilityId="
				+ facilityId + ", division=" + division + ", market=" + market
				+ ", territory=" + territory + ", centerAddress="
				+ centerAddress + ", centerCity=" + centerCity
				+ ", centerState=" + centerState + ", centerZip=" + centerZip
				+ ", centerPhone=" + centerPhone + ", centerFax=" + centerFax
				+ ", oldIHealConfig=" + oldIHealConfig + ", currentIHealConfig="
				+ currentIHealConfig + ", ihealConfigChanged="
				+ ihealConfigChanged + ", active=" + active
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", oldFacilityType=" + oldFacilityType
				+ ", currentFacilityType=" + currentFacilityType
				+ ", facilityTypeChanged=" + facilityTypeChanged + "]";
	}

}
