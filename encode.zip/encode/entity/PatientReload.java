package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient_reload")
public class PatientReload {
	
	@Id
	@Column(name = "visit_id")
	private Integer visitId;

	@Column(name = "patient_id")
	private Integer patientId;
	
	@Column(name = "facility_id")
	private Integer facilityId;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "error_code")
	private Integer errorCode;
	
	@Column(name = "error_message")
	private String errorMessage;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "PatientReload [visitId=" + visitId + ", patientId=" + patientId + ", facilityId=" + facilityId
				+ ", status=" + status + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + "]";
	}
	
	

}
