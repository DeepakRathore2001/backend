package com.healogics.encode.entity;

import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.ReconReportFilter;

public class ReconReportFilterOptionsRes extends APIResponse {

	private ReconReportFilter reconReportFilter;

	public ReconReportFilter getReconReportFilter() {
		return reconReportFilter;
	}

	public void setReconReportFilter(ReconReportFilter reconReportFilter) {
		this.reconReportFilter = reconReportFilter;
	}

	@Override
	public String toString() {
		return "ReconReportFilterOptionsRes [reconReportFilter=" + reconReportFilter + "]";
	}

}
