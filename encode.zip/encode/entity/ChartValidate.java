package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "chart_validation")
public class ChartValidate {
	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "cpt_codes")
	private String cptCodes;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(String cptCodes) {
		this.cptCodes = cptCodes;
	}

	@Override
	public String toString() {
		return "ChartValidation [id=" + id + ", cptCodes=" + cptCodes + "]";
	}
}
