package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "encode_users")
public class EncodeUsers {
	@Id
	@Column(name = "user_id")
	private Long userId;

	@Column(name = "username")
	private String username;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "last_logged_in_timestamp")
	private String lastLoggedInTimestamp;

	@Column(name = "user_full_name")
	private String userFullName;

	@Column(name = "encode_role")
	private String encodeRole;

	@Column(name = "iheal_role", columnDefinition = "LONGTEXT")
	private String ihealRole;

	@Column(name = "role_description")
	private String encodeRoleDesc;

	@Column(name = "status")
	private int status;

	@Column(name = "team")
	private String team;

	@Column(name = "user_facilities", columnDefinition = "json")
	private String userFacilities;

	@Column(name = "facility_id_list", columnDefinition = "TEXT")
	private String facilityIdList;

	@Column(name = "bluebook_id_list", columnDefinition = "TEXT")
	private String bluebookIdList;

	public String getFacilityIdList() {
		return facilityIdList;
	}

	public void setFacilityIdList(String facilityIdList) {
		this.facilityIdList = facilityIdList;
	}

	public String getBluebookIdList() {
		return bluebookIdList;
	}

	public void setBluebookIdList(String bluebookIdList) {
		this.bluebookIdList = bluebookIdList;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLastLoggedInTimestamp() {
		return lastLoggedInTimestamp;
	}

	public void setLastLoggedInTimestamp(String lastLoggedInTimestamp) {
		this.lastLoggedInTimestamp = lastLoggedInTimestamp;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(String encodeRole) {
		this.encodeRole = encodeRole;
	}

	public String getIhealRole() {
		return ihealRole;
	}

	public void setIhealRole(String ihealRole) {
		this.ihealRole = ihealRole;
	}

	public String getEncodeRoleDesc() {
		return encodeRoleDesc;
	}

	public void setEncodeRoleDesc(String encodeRoleDesc) {
		this.encodeRoleDesc = encodeRoleDesc;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getUserFacilities() {
		return userFacilities;
	}

	public void setUserFacilities(String userFacilities) {
		this.userFacilities = userFacilities;
	}

	@Override
	public String toString() {
		return "EncodeUsers [userId=" + userId + ", username=" + username
				+ ", emailId=" + emailId + ", lastLoggedInTimestamp="
				+ lastLoggedInTimestamp + ", userFullName=" + userFullName
				+ ", encodeRole=" + encodeRole + ", ihealRole=" + ihealRole
				+ ", encodeRoleDesc=" + encodeRoleDesc + ", status=" + status
				+ ", team=" + team + ", userFacilities=" + userFacilities
				+ ", facilityIdList=" + facilityIdList + ", bluebookIdList="
				+ bluebookIdList + "]";
	}

}
