package com.healogics.encode.entity;
 
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table; 

@Entity
@Table(name = "user_login")
public class UserLogin {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "device_id")
	private String deviceId;

	@Column(name = "device_ip")
	private String deviceIP;

	@Column(name = "device_type")
	private String deviceType;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "employed_by")
	private String employedBy;

	@Column(name = "login_status")
	private String loginStatus;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "user_fullname")
	private String userFullName;

	@Column(name = "username")
	private String username;

	@Column(name = "user_id")
	private String userId;

	@Column(name = "created_timestamp")
	private LocalDateTime createdTimestamp;

	@Column(name = "server_ip")
	private String serverIP;

	@Column(name = "user_role", columnDefinition = "LONGTEXT")
	private String userRole;

	@Column(name = "is_restricted")
	private boolean isRestricted;

	@Column(name = "last_login_timestamp")
	private String lastLoginTimestamp;

	@Column(name = "login_type")
	private String loginType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceIP() {
		return deviceIP;
	}

	public void setDeviceIP(String deviceIP) {
		this.deviceIP = deviceIP;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmployedBy() {
		return employedBy;
	}

	public void setEmployedBy(String employedBy) {
		this.employedBy = employedBy;
	}

	public String getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public LocalDateTime getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(LocalDateTime createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public boolean isRestricted() {
		return isRestricted;
	}

	public void setRestricted(boolean isRestricted) {
		this.isRestricted = isRestricted;
	}

	public String getLastLoginTimestamp() {
		return lastLoginTimestamp;
	}

	public void setLastLoginTimestamp(String lastLoginTimestamp) {
		this.lastLoginTimestamp = lastLoginTimestamp;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	@Override
	public String toString() {
		return "UserLogin [id=" + id + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", deviceId="
				+ deviceId + ", deviceIP=" + deviceIP + ", deviceType=" + deviceType + ", emailId=" + emailId
				+ ", employedBy=" + employedBy + ", loginStatus=" + loginStatus + ", errorMessage=" + errorMessage
				+ ", errorCode=" + errorCode + ", userFullName=" + userFullName + ", username=" + username + ", userId="
				+ userId + ", createdTimestamp=" + createdTimestamp + ", serverIP=" + serverIP + ", userRole="
				+ userRole + ", isRestricted=" + isRestricted + ", lastLoginTimestamp=" + lastLoginTimestamp
				+ ", loginType=" + loginType + "]";
	}

}
