package com.healogics.encode.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
  
@Entity
@Table(name = "audit_compliance_post_audit_report")
public class AuditCompliancePostAuditReport {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "filter_id")
	private Integer filterId;

	@Column(name = "coder_user_id")
	private int coderUserId;

	@Column(name = "coder_username")
	private String coderUserName;

	@Column(name = "coder_name")
	private String coderName;

	@Column(name = "filter_name")
	private String filterName;

	@Column(name = "team")
	private String team;

	@Column(name = "provider")
	private String provider;

	@Column(name = "sending_facility")
	private String sendingFacility;

	@Column(name = "date_of_service")
	private Date dos;

	@Column(name = "chart_codes")
	private String chartCodes;

	@Column(name = "coding_error")
	private Boolean codingError;

	@Column(name = "audit_notes")
	private String auditNotes;

	@Column(name = "audit_date")
	private Date auditDate;

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	

	public Integer getFilterId() {
		return filterId;
	}

	public void setFilterId(Integer filterId) {
		this.filterId = filterId;
	}

	public int getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(int coderUserId) {
		this.coderUserId = coderUserId;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public String getCoderName() {
		return coderName;
	}

	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getSendingFacility() {
		return sendingFacility;
	}

	public void setSendingFacility(String sendingFacility) {
		this.sendingFacility = sendingFacility;
	}

	public Date getDos() {
		return dos;
	}

	public void setDos(Date dos) {
		this.dos = dos;
	}

	public String getChartCodes() {
		return chartCodes;
	}

	public void setChartCodes(String chartCodes) {
		this.chartCodes = chartCodes;
	}

	public Boolean getCodingError() {
		return codingError;
	}

	public void setCodingError(Boolean codingError) {
		this.codingError = codingError;
	}

	public String getAuditNotes() {
		return auditNotes;
	}

	public void setAuditNotes(String auditNotes) {
		this.auditNotes = auditNotes;
	}

	public Date getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	@Override
	public String toString() {
		return "AuditCompliancePostAuditReport [visitId=" + visitId + ", filterId=" + filterId + ", coderUserId="
				+ coderUserId + ", coderUserName=" + coderUserName + ", coderName=" + coderName + ", filterName="
				+ filterName + ", team=" + team + ", provider=" + provider + ", sendingFacility=" + sendingFacility
				+ ", dos=" + dos + ", chartCodes=" + chartCodes + ", codingError=" + codingError + ", auditNotes="
				+ auditNotes + ", auditDate=" + auditDate + "]";
	}

}
