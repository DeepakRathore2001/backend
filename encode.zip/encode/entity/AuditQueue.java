package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "audit_queue")
public class AuditQueue {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "filter_id")
	private int filterId;

	@Column(name = "patient_id")
	private long patientId;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String BBC;

	@Column(name = "facility_alias")
	private String facilityAlias;

	@Column(name = "insurance")
	private String insurance;

	@Column(name = "date_added")
	private Timestamp dateAdded;

	@Column(name = "date_of_service")
	private Timestamp DOS;

	@Column(name = "medical_record_number")
	private String MRN;

	@Column(name = "status")
	private String status;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "iheal_config")
	private String facilityType;

	@Column(name = "last_updated_by_username")
	private String lastUpdatedByUserName;

	@Column(name = "last_updated_by_userid")
	private String lastUpdatedByUserId;

	@Column(name = "last_updated_by_user_fullname")
	private String lastUpdatedByUserFullName;

	@Column(name = "is_locked")
	private int isLocked;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "last_accessed_timestamp ")
	private Timestamp lastAccessedTimestamp;

	@Column(name = "team")
	private String team;

	@Column(name = "audit_complete")
	private int auditComplete;

	@Column(name = "assignee_user_id")
	private Long assigneeUserId;

	@Column(name = "assignee_username")
	private String assigneeUserName;

	@Column(name = "assignee_user_fullname")
	private String assigneeUserFullName;

	@Column(name = "audit_date")
	private Date auditDate;

	@Column(name = "units")
	private String units;

	@Column(name = "provider_id")
	private String providerId;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "resolution")
	private String resolution;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "filter_id", referencedColumnName = "filter_id", insertable = false, updatable = false)
	private Filters filters;

	public Date getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBBC() {
		return BBC;
	}

	public void setBBC(String bBC) {
		BBC = bBC;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public Timestamp getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(Timestamp dateAdded) {
		this.dateAdded = dateAdded;
	}

	public Timestamp getDOS() {
		return DOS;
	}

	public void setDOS(Timestamp dOS) {
		DOS = dOS;
	}

	public String getMRN() {
		return MRN;
	}

	public void setMRN(String mRN) {
		MRN = mRN;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getLastUpdatedByUserName() {
		return lastUpdatedByUserName;
	}

	public void setLastUpdatedByUserName(String lastUpdatedByUserName) {
		this.lastUpdatedByUserName = lastUpdatedByUserName;
	}

	public String getLastUpdatedByUserId() {
		return lastUpdatedByUserId;
	}

	public void setLastUpdatedByUserId(String lastUpdatedByUserId) {
		this.lastUpdatedByUserId = lastUpdatedByUserId;
	}

	public String getLastUpdatedByUserFullName() {
		return lastUpdatedByUserFullName;
	}

	public void setLastUpdatedByUserFullName(String lastUpdatedByUserFullName) {
		this.lastUpdatedByUserFullName = lastUpdatedByUserFullName;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Timestamp getLastAccessedTimestamp() {
		return lastAccessedTimestamp;
	}

	public void setLastAccessedTimestamp(Timestamp lastAccessedTimestamp) {
		this.lastAccessedTimestamp = lastAccessedTimestamp;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public int getAuditComplete() {
		return auditComplete;
	}

	public void setAuditComplete(int auditComplete) {
		this.auditComplete = auditComplete;
	}

	public Long getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(Long assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserName() {
		return assigneeUserName;
	}

	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}

	public String getAssigneeUserFullName() {
		return assigneeUserFullName;
	}

	public void setAssigneeUserFullName(String assigneeUserFullName) {
		this.assigneeUserFullName = assigneeUserFullName;
	}

	public Filters getFilters() {
		return filters;
	}

	public void setFilters(Filters filters) {
		this.filters = filters;
	}

	@Override
	public String toString() {
		return "AuditQueue [visitId=" + visitId + ", filterId=" + filterId + ", patientId=" + patientId
				+ ", patientName=" + patientName + ", facilityId=" + facilityId + ", BBC=" + BBC + ", facilityAlias="
				+ facilityAlias + ", insurance=" + insurance + ", dateAdded=" + dateAdded + ", DOS=" + DOS + ", MRN="
				+ MRN + ", status=" + status + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", facilityType=" + facilityType + ", lastUpdatedByUserName="
				+ lastUpdatedByUserName + ", lastUpdatedByUserId=" + lastUpdatedByUserId
				+ ", lastUpdatedByUserFullName=" + lastUpdatedByUserFullName + ", isLocked=" + isLocked
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", lastAccessedTimestamp=" + lastAccessedTimestamp
				+ ", team=" + team + ", auditComplete=" + auditComplete + ", assigneeUserId=" + assigneeUserId
				+ ", assigneeUserName=" + assigneeUserName + ", assigneeUserFullName=" + assigneeUserFullName
				+ ", auditDate=" + auditDate + ", units=" + units + ", providerId=" + providerId + ", providerName="
				+ providerName + ", resolution=" + resolution + ", filters=" + filters + "]";
	}

}