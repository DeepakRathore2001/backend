package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "icd_codes_master")
public class ICDCodesMaster {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "icd_code")
	private String icdCode;

	@Column(name = "description")
	private String description;

	@Column(name = "active")
	private int active;

	@Column(name = "code_description")
	private String codeDescription;

	@Column(name = "icd_10_formatted")
	private String icd10Formatted;

	public String getIcd10Formatted() {
		return icd10Formatted;
	}

	public void setIcd10Formatted(String icd10Formatted) {
		this.icd10Formatted = icd10Formatted;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIcdCode() {
		return icdCode;
	}

	public void setIcdCode(String icdCode) {
		this.icdCode = icdCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getCodeDescription() {
		return codeDescription;
	}

	public void setCodeDescription(String codeDescription) {
		this.codeDescription = codeDescription;
	}

	@Override
	public String toString() {
		return "ICDCodesMaster [id=" + id + ", icdCode=" + icdCode + ", description=" + description + ", active="
				+ active + ", codeDescription=" + codeDescription + ", icd10Formatted=" + icd10Formatted + "]";
	}

}
