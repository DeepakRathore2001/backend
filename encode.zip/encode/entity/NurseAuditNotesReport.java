package com.healogics.encode.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "nurse_audit_notes_report")
public class NurseAuditNotesReport {

	@Id
	@Column(name = "visit_id")
	private int visitId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "facility_alias")
	private String facilityAlias;

	@Column(name = "audit_date")
	private Date auditDate;

	@Column(name = "dos")
	private Date dateOfService;

	@Column(name = "queued_date")
	private Date queuedDate;

	@Column(name = "units")
	private String units;

	@Column(name = "provider_id")
	private String providerId;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "nurse_comments")
	private String nurseComments;

	@Column(name = "assigned_nurse_id")
	private Long assignedNurseId;

	@Column(name = "assigned_nurse_username")
	private String assignedNurseUserName;

	@Column(name = "assigned_nurse_fullname")
	private String assignedNurseFullName;
	
	@Column(name = "resolution")
	private String resolution;
	
	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "patient_name")
	private String patientName;

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public Date getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public Date getQueuedDate() {
		return queuedDate;
	}

	public void setQueuedDate(Date queuedDate) {
		this.queuedDate = queuedDate;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getNurseComments() {
		return nurseComments;
	}

	public void setNurseComments(String nurseComments) {
		this.nurseComments = nurseComments;
	}

	public Long getAssignedNurseId() {
		return assignedNurseId;
	}

	public void setAssignedNurseId(Long assignedNurseId) {
		this.assignedNurseId = assignedNurseId;
	}

	public String getAssignedNurseUserName() {
		return assignedNurseUserName;
	}

	public void setAssignedNurseUserName(String assignedNurseUserName) {
		this.assignedNurseUserName = assignedNurseUserName;
	}

	public String getAssignedNurseFullName() {
		return assignedNurseFullName;
	}

	public void setAssignedNurseFullName(String assignedNurseFullName) {
		this.assignedNurseFullName = assignedNurseFullName;
	}

	@Override
	public String toString() {
		return "NurseAuditNotesReport [visitId=" + visitId + ", facilityId=" + facilityId + ", facilityAlias="
				+ facilityAlias + ", auditDate=" + auditDate + ", dateOfService=" + dateOfService + ", queuedDate="
				+ queuedDate + ", units=" + units + ", providerId=" + providerId + ", providerName=" + providerName
				+ ", nurseComments=" + nurseComments + ", assignedNurseId=" + assignedNurseId
				+ ", assignedNurseUserName=" + assignedNurseUserName + ", assignedNurseFullName="
				+ assignedNurseFullName + ", resolution=" + resolution + ", patientId=" + patientId + ", patientName="
				+ patientName + "]";
	}

}
