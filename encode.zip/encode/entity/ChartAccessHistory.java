package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "chart_access_history")
public class ChartAccessHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "old_status")
	private String oldStatus;

	@Column(name = "new_status")
	private String newStatus;

	@Column(name = "start_time")
	private Timestamp startTime;

	@Column(name = "end_time")
	private Timestamp endTime;

	@Column(name = "user_first_name")
	private String userFirstName;

	@Column(name = "user_last_name")
	private String userLastName;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "location_bbc")
	private String locationBbc;

	@Column(name = "last_updated_by_timestamp")
	private Timestamp lastUpdatedByTimestamp;

	@Column(name = "team")
	private String team;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(String oldStatus) {
		this.oldStatus = oldStatus;
	}

	public String getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(String newStatus) {
		this.newStatus = newStatus;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getLocationBbc() {
		return locationBbc;
	}

	public void setLocationBbc(String locationBbc) {
		this.locationBbc = locationBbc;
	}

	public Timestamp getLastUpdatedByTimestamp() {
		return lastUpdatedByTimestamp;
	}

	public void setLastUpdatedByTimestamp(Timestamp lastUpdatedByTimestamp) {
		this.lastUpdatedByTimestamp = lastUpdatedByTimestamp;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	@Override
	public String toString() {
		return "ChartAccessHistory [id=" + id + ", userId=" + userId + ", visitId=" + visitId + ", oldStatus="
				+ oldStatus + ", newStatus=" + newStatus + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", userFirstName=" + userFirstName + ", userLastName=" + userLastName + ", bluebookId=" + bluebookId
				+ ", locationBbc=" + locationBbc + ", lastUpdatedByTimestamp=" + lastUpdatedByTimestamp + ", team="
				+ team + "]";
	}

}
