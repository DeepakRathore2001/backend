package com.healogics.encode.entity;

import java.util.Date;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "filter_limit")
public class FilterLimit {

	@Id
	@Column(name = "filter_id")
	private int filterId;

	@Column(name = "date")
	private Date date;

	@Column(name = "actual_count")
	private int actualCount;

	@Column(name = "current_count")
	private int currentCount;

	@Column(name = "exec_flag")
	private Boolean execFlag;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getActualCount() {
		return actualCount;
	}

	public void setActualCount(int actualCount) {
		this.actualCount = actualCount;
	}

	public int getCurrentCount() {
		return currentCount;
	}

	public void setCurrentCount(int currentCount) {
		this.currentCount = currentCount;
	}

	public Boolean getExecFlag() {
		return execFlag;
	}

	public void setExecFlag(Boolean execFlag) {
		this.execFlag = execFlag;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "FilterLimit [filterId=" + filterId + ", date=" + date + ", actualCount=" + actualCount
				+ ", currentCount=" + currentCount + ", execFlag=" + execFlag + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + "]";
	}

}
