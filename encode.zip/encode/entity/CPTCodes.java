package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cpt_codes_master")
public class CPTCodes {
	@Id
	@Column(name = "procedure_id")
	private Long procedureId;

	@Column(name = "cpt4_code")
	private String cptCode;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "active")
	private String active;

	public Long getProcedureId() {
		return procedureId;
	}

	public void setProcedureId(Long procedureId) {
		this.procedureId = procedureId;
	}

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "CPTCodes [procedureId=" + procedureId + ", cptCode=" + cptCode
				+ ", description=" + description
				+ ", active=" + active + "]";
	}
}
