package com.healogics.encode.entity;

import com.healogics.encode.dto.FilterOptions;

public class CollapsibleFilterRes {
	
	private String responseCode;
	private String responseDesc;
	private FilterOptions collapsibleFilter;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	
	public FilterOptions getCollapsibleFilter() {
		return collapsibleFilter;
	}
	public void setCollapsibleFilter(FilterOptions collapsibleFilter) {
		this.collapsibleFilter = collapsibleFilter;
	}
	@Override
	public String toString() {
		return "CollapsibleFilterRes [responseCode=" + responseCode + ", responseDesc=" + responseDesc
				+ ", collapsibleFilter=" + collapsibleFilter + "]";
	}
	
	

}
