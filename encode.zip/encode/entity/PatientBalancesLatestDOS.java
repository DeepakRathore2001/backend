package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient_balances_latest_dos")
public class PatientBalancesLatestDOS {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "cliam_patient")
	private String claimPatient;

	@Column(name = "bluebook_code")
	private String bbc;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "patient_account_no")
	private String patientAccNo;

	@Column(name = "ls_billing_number")
	private String lsBillingNumber;

	@Column(name = "patient_dob")
	private String patientDOB;

	@Column(name = "patient_cell_phone")
	private String patientCellPhone;

	@Column(name = "patient_home_phone")
	private String patientHomePhone;

	@Column(name = "patient_email")
	private String patientEmail;

	@Column(name = "patient_address")
	private String patientAddress;

	@Column(name = "latest_dos")
	private Date latestDOS;

	@Column(name = "balance")
	private String balance;

	@Column(name = "total_balance")
	private String totalBalance;

	@Column(name = "total_balance_1")
	private String totalBalance1;

	@Column(name = "total_balance_2")
	private String totalBalance2;

	@Column(name = "total_balance_3")
	private String totalBalance3;

	@Column(name = "total_percentage")
	private String totalPercentage;

	@Column(name = "received_timestamp")
	private Timestamp receivedTimestamp;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_Message")
	private String errorMessage;

	@Column(name = "sent_timestamp")
	private Timestamp sentTimestamp;

	@Column(name = "sent_to_iheal")
	private int sentToIheal;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getClaimPatient() {
		return claimPatient;
	}

	public void setClaimPatient(String claimPatient) {
		this.claimPatient = claimPatient;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientAccNo() {
		return patientAccNo;
	}

	public void setPatientAccNo(String patientAccNo) {
		this.patientAccNo = patientAccNo;
	}

	public String getLsBillingNumber() {
		return lsBillingNumber;
	}

	public void setLsBillingNumber(String lsBillingNumber) {
		this.lsBillingNumber = lsBillingNumber;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientCellPhone() {
		return patientCellPhone;
	}

	public void setPatientCellPhone(String patientCellPhone) {
		this.patientCellPhone = patientCellPhone;
	}

	public String getPatientHomePhone() {
		return patientHomePhone;
	}

	public void setPatientHomePhone(String patientHomePhone) {
		this.patientHomePhone = patientHomePhone;
	}

	public String getPatientEmail() {
		return patientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}

	public String getPatientAddress() {
		return patientAddress;
	}

	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}

	public Date getLatestDOS() {
		return latestDOS;
	}

	public void setLatestDOS(Date latestDOS) {
		this.latestDOS = latestDOS;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getTotalBalance() {
		return totalBalance;
	}

	public void setTotalBalance(String totalBalance) {
		this.totalBalance = totalBalance;
	}

	public String getTotalBalance1() {
		return totalBalance1;
	}

	public void setTotalBalance1(String totalBalance1) {
		this.totalBalance1 = totalBalance1;
	}

	public String getTotalBalance2() {
		return totalBalance2;
	}

	public void setTotalBalance2(String totalBalance2) {
		this.totalBalance2 = totalBalance2;
	}

	public String getTotalBalance3() {
		return totalBalance3;
	}

	public void setTotalBalance3(String totalBalance3) {
		this.totalBalance3 = totalBalance3;
	}

	public String getTotalPercentage() {
		return totalPercentage;
	}

	public void setTotalPercentage(String totalPercentage) {
		this.totalPercentage = totalPercentage;
	}

	public Timestamp getReceivedTimestamp() {
		return receivedTimestamp;
	}

	public void setReceivedTimestamp(Timestamp receivedTimestamp) {
		this.receivedTimestamp = receivedTimestamp;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Timestamp getSentTimestamp() {
		return sentTimestamp;
	}

	public void setSentTimestamp(Timestamp sentTimestamp) {
		this.sentTimestamp = sentTimestamp;
	}

	public int getSentToIheal() {
		return sentToIheal;
	}

	public void setSentToIheal(int sentToIheal) {
		this.sentToIheal = sentToIheal;
	}

	@Override
	public String toString() {
		return "PatientBalancesLatestDOS [id=" + id + ", facilityName=" + facilityName + ", claimPatient="
				+ claimPatient + ", bbc=" + bbc + ", patientName=" + patientName + ", patientAccNo=" + patientAccNo
				+ ", lsBillingNumber=" + lsBillingNumber + ", patientDOB=" + patientDOB + ", patientCellPhone="
				+ patientCellPhone + ", patientHomePhone=" + patientHomePhone + ", patientEmail=" + patientEmail
				+ ", patientAddress=" + patientAddress + ", latestDOS=" + latestDOS + ", balance=" + balance
				+ ", totalBalance=" + totalBalance + ", totalBalance1=" + totalBalance1 + ", totalBalance2="
				+ totalBalance2 + ", totalBalance3=" + totalBalance3 + ", totalPercentage=" + totalPercentage
				+ ", receivedTimestamp=" + receivedTimestamp + ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + ", sentTimestamp=" + sentTimestamp + ", sentToIheal=" + sentToIheal + "]";
	}

}
