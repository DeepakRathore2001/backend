package com.healogics.encode.entity;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "superbill_history")
public class SuperBillHistory implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "visit_id")
	private Long visitId;
	
	@Id
	@Column(name = "patient_dos")
	private Timestamp patientDOS;
	
	@Column(name = "patient_id")
	private Long patientId;
	
	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "facility_name")
	private String facilityName;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "patient_first_name")
	private String patientFirstName;
	
	@Column(name = "patient_last_name")
	private String patientLastName;
	
	@Column(name = "patient_fullname")
	private String patientFullName;
	
	@Column(name = "patient_dob")
	private Date patientDob;
	
	@Column(name = "patient_mrn")
	private String patientMrn;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	
	@Column(name = "claim_sent_date")
	private Date claimSentDate;
	
	@Column(name = "last_updated_by_user")
	private String lastUpdatedByUser;

	@Column(name = "provider_id")
	private Long providerId;
	
	@Column(name = "provider_first_name")
	private String providerFirstName;
	
	@Column(name = "provider_last_name")
	private String providerLastName;

	public Long getProviderId() {
		return providerId;
	}

	public void setProviderId(Long providerId) {
		this.providerId = providerId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Timestamp getPatientDOS() {
		return patientDOS;
	}

	public void setPatientDOS(Timestamp patientDOS) {
		this.patientDOS = patientDOS;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientFullName() {
		return patientFullName;
	}

	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}

	

	public Date getPatientDob() {
		return patientDob;
	}

	public void setPatientDob(Date patientDob) {
		this.patientDob = patientDob;
	}

	public String getPatientMrn() {
		return patientMrn;
	}

	public void setPatientMrn(String patientMrn) {
		this.patientMrn = patientMrn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Date getClaimSentDate() {
		return claimSentDate;
	}

	public void setClaimSentDate(Date claimSentDate) {
		this.claimSentDate = claimSentDate;
	}

	public String getLastUpdatedByUser() {
		return lastUpdatedByUser;
	}

	public void setLastUpdatedByUser(String lastUpdatedByUser) {
		this.lastUpdatedByUser = lastUpdatedByUser;
	}

	@Override
	public String toString() {
		return "SuperBillHistory [visitId=" + visitId + ", patientDOS=" + patientDOS + ", patientId=" + patientId
				+ ", facilityId=" + facilityId + ", facilityName=" + facilityName + ", bluebookId=" + bluebookId
				+ ", patientFirstName=" + patientFirstName + ", patientLastName=" + patientLastName
				+ ", patientFullName=" + patientFullName + ", patientDob=" + patientDob + ", patientMrn=" + patientMrn
				+ ", status=" + status + ", createdTimestamp=" + createdTimestamp + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", claimSentDate=" + claimSentDate + ", lastUpdatedByUser=" + lastUpdatedByUser
				+ ", providerId=" + providerId + ", providerFirstName=" + providerFirstName + ", providerLastName="
				+ providerLastName + "]";
	}
	
	
}
