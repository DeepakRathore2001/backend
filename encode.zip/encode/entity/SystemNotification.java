package com.healogics.encode.entity;



import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


@Entity
@Table(name = "system_notification")
public class SystemNotification {
	
	@Id
	@Column(name = "notification_id")
	private String notificationId;
	
	@Lob
	@Column(name = "description")
	private String description;

	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "start_timestamp")
	private Timestamp startTimestamp;

	@Column(name = "end_timestamp")
	private Timestamp endTimestamp;

	@Lob
	@Column(name = "hyperlink")
	private String hyperlink;

	@Column(name = "created_username")
	private String createdUsername;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "notification_status")
	private Boolean notificationStatus;

	@Column(name = "title")
	private String title;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;

	@Column(name = "created_user_fullname")
	private String createdUserFullname;

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Timestamp getStartTimestamp() {
		return startTimestamp;
	}

	public void setStartTimestamp(Timestamp startTimestamp) {
		this.startTimestamp = startTimestamp;
	}

	public Timestamp getEndTimestamp() {
		return endTimestamp;
	}

	public void setEndTimestamp(Timestamp endTimestamp) {
		this.endTimestamp = endTimestamp;
	}

	public String getHyperlink() {
		return hyperlink;
	}

	public void setHyperlink(String hyperlink) {
		this.hyperlink = hyperlink;
	}

	public String getCreatedUsername() {
		return createdUsername;
	}

	public void setCreatedUsername(String createdUsername) {
		this.createdUsername = createdUsername;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Boolean getNotificationStatus() {
		return notificationStatus;
	}

	public void setNotificationStatus(Boolean notificationStatus) {
		this.notificationStatus = notificationStatus;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public String getCreatedUserFullname() {
		return createdUserFullname;
	}

	public void setCreatedUserFullname(String createdUserFullname) {
		this.createdUserFullname = createdUserFullname;
	}

	@Override
	public String toString() {
		return "SystemNotification [notificationId=" + notificationId + ", description=" + description + ", endDate="
				+ endDate + ", startDate=" + startDate + ", startTimestamp=" + startTimestamp + ", endTimestamp="
				+ endTimestamp + ", hyperlink=" + hyperlink + ", createdUsername=" + createdUsername
				+ ", createdTimestamp=" + createdTimestamp + ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", notificationStatus=" + notificationStatus
				+ ", title=" + title + ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + ", createdUserFullname="
				+ createdUserFullname + "]";
	}
	
	
}
	
	
	
	