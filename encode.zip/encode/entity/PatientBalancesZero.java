package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient_balances_zero")
public class PatientBalancesZero {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "patient_acct_no")
	private String patientAcctNo;

	@Column(name = "ls_billing_number")
	private String lsBillingNumber;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "bluebook_code")
	private String bbc;

	@Column(name = "previous_balance")
	private String previousBalance;

	@Column(name = "current_balance")
	private String currentBalance;

	@Column(name = "received_timestamp")
	private Timestamp receivedTimestamp;

	@Column(name = "sent_to_iheal")
	private int sentToIheal;

	@Column(name = "sent_timestamp")
	private Timestamp sentTimestamp;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientAcctNo() {
		return patientAcctNo;
	}

	public void setPatientAcctNo(String patientAcctNo) {
		this.patientAcctNo = patientAcctNo;
	}

	public String getLsBillingNumber() {
		return lsBillingNumber;
	}

	public void setLsBillingNumber(String lsBillingNumber) {
		this.lsBillingNumber = lsBillingNumber;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getPreviousBalance() {
		return previousBalance;
	}

	public void setPreviousBalance(String previousBalance) {
		this.previousBalance = previousBalance;
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public Timestamp getReceivedTimestamp() {
		return receivedTimestamp;
	}

	public void setReceivedTimestamp(Timestamp receivedTimestamp) {
		this.receivedTimestamp = receivedTimestamp;
	}

	public int getSentToIheal() {
		return sentToIheal;
	}

	public void setSentToIheal(int sentToIheal) {
		this.sentToIheal = sentToIheal;
	}

	public Timestamp getSentTimestamp() {
		return sentTimestamp;
	}

	public void setSentTimestamp(Timestamp sentTimestamp) {
		this.sentTimestamp = sentTimestamp;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "PatientBalancesZero [id=" + id + ", patientName=" + patientName + ", patientAcctNo=" + patientAcctNo
				+ ", lsBillingNumber=" + lsBillingNumber + ", patientDOB=" + patientDOB + ", bbc=" + bbc
				+ ", previousBalance=" + previousBalance + ", currentBalance=" + currentBalance + ", receivedTimestamp="
				+ receivedTimestamp + ", sentToIheal=" + sentToIheal + ", sentTimestamp=" + sentTimestamp
				+ ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}

}
