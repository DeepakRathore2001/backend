package com.healogics.encode.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reconciliation_report")
public class ReconReport {

	@Id
	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "snf_location_bbc")
	private String snfLocationBBC;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "medical_record_number")
	private String medicalRecordNumber;

	@Column(name = "patient_dos")
	private Date patientDos;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "status")
	private String status;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "service_line")
	private String serviceLine;
	
	@Column(name = "provider_id")
	private String providerId;
	
	@Column(name = "facility_type")
	private String facilityType;

	@Column(name ="team")
	private String team;
	
	@Column(name ="deficiency_reason")
	private String deficiencyReason;
	
	@Column(name ="pending_reason")
	private String pendingReason;
	

	@Column(name = "coder_user_id")
	private String coderUserId;
	
	@Column(name = "coder_user_fullname")
	private String coderUserFullname;
	
	
	public String getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}

	public String getCoderUserFullname() {
		return coderUserFullname;
	}

	public void setCoderUserFullname(String coderUserFullname) {
		this.coderUserFullname = coderUserFullname;
	}

	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		this.pendingReason = pendingReason;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getSnfLocationBBC() {
		return snfLocationBBC;
	}

	public void setSnfLocationBBC(String snfLocationBBC) {
		this.snfLocationBBC = snfLocationBBC;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public Date getPatientDos() {
		return patientDos;
	}

	public void setPatientDos(Date patientDos) {
		this.patientDos = patientDos;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	@Override
	public String toString() {
		return "ReconReport [visitId=" + visitId + ", snfLocationBBC=" + snfLocationBBC + ", ihealConfig=" + ihealConfig
				+ ", facilityId=" + facilityId + ", medicalRecordNumber=" + medicalRecordNumber + ", patientDos="
				+ patientDos + ", patientName=" + patientName + ", status=" + status + ", providerName=" + providerName
				+ ", serviceLine=" + serviceLine + ", providerId=" + providerId + ", facilityType=" + facilityType
				+ ", team=" + team + ", deficiencyReason=" + deficiencyReason + ", pendingReason=" + pendingReason
				+ ", coderUserId=" + coderUserId + ", coderUserFullname=" + coderUserFullname + "]";
	}

}
