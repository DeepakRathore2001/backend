package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reload_metrics")
public class ReloadMetrics {
	@Id
	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "document_id")
	private String documentId;

	@Column(name = "document_type")
	private String documentType;
	
	@Column(name = "superbill_status")
	private Boolean superbillStatus;
	
	@Column(name = "document_status")
	private Boolean documentStatus;
	
	@Column(name = "error_code")
	private String errorCode;
	
	@Column(name = "error_message")
	private String errorMessage;
	
	@Column(name = "document_error_code")
	private String documentErrorCode;
	
	@Column(name = "document_error_message")
	private String documentErrorMessage;

	public String getDocumentErrorCode() {
		return documentErrorCode;
	}

	public void setDocumentErrorCode(String documentErrorCode) {
		this.documentErrorCode = documentErrorCode;
	}

	public String getDocumentErrorMessage() {
		return documentErrorMessage;
	}

	public void setDocumentErrorMessage(String documentErrorMessage) {
		this.documentErrorMessage = documentErrorMessage;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Boolean getSuperbillStatus() {
		return superbillStatus;
	}

	public void setSuperbillStatus(Boolean superbillStatus) {
		this.superbillStatus = superbillStatus;
	}

	public Boolean getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(Boolean documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	@Override
	public String toString() {
		return "ReloadMetrics [visitId=" + visitId + ", facilityId=" + facilityId + ", documentId=" + documentId
				+ ", documentType=" + documentType + ", superbillStatus=" + superbillStatus + ", documentStatus="
				+ documentStatus + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", documentErrorCode=" + documentErrorCode + ", documentErrorMessage=" + documentErrorMessage + "]";
	}
}
