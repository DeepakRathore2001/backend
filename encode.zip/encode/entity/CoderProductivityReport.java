package com.healogics.encode.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "coder_productivity_report")
public class CoderProductivityReport {

	@Id
	@Column(name = "coder_id")
	private Integer coderId;

	@Column(name = "coder")
	private String coder;

	@Column(name = "total")
	private Long total;
	
	@Column(name = "in_review")
	private Long inReview;

	@Column(name = "completed")
	private Long completed;

	@Column(name = "sent")
	private Long sent;

	@Column(name = "deficiency")
	private Long deficiency;

	@Column(name = "unbillable")
	private Long unbillable;

	@Column(name = "other")
	private Long other;
	
	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "avg_time_mins")
	private Long avgTimeMins;
	
	@Column(name = "avg_time_hrs")
	private Long avgTimeHrs;

	public Integer getCoderId() {
		return coderId;
	}

	public void setCoderId(Integer coderId) {
		this.coderId = coderId;
	}

	public String getCoder() {
		return coder;
	}

	public void setCoder(String coder) {
		this.coder = coder;
	}

	public Long getTotal() {
		return total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public Long getInReview() {
		return inReview;
	}

	public void setInReview(Long inReview) {
		this.inReview = inReview;
	}

	public Long getCompleted() {
		return completed;
	}

	public void setCompleted(Long completed) {
		this.completed = completed;
	}

	public Long getSent() {
		return sent;
	}

	public void setSent(Long sent) {
		this.sent = sent;
	}

	public Long getDeficiency() {
		return deficiency;
	}

	public void setDeficiency(Long deficiency) {
		this.deficiency = deficiency;
	}

	public Long getUnbillable() {
		return unbillable;
	}

	public void setUnbillable(Long unbillable) {
		this.unbillable = unbillable;
	}

	public Long getOther() {
		return other;
	}

	public void setOther(Long other) {
		this.other = other;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Long getAvgTimeMins() {
		return avgTimeMins;
	}

	public void setAvgTimeMins(Long avgTimeMins) {
		this.avgTimeMins = avgTimeMins;
	}

	public Long getAvgTimeHrs() {
		return avgTimeHrs;
	}

	public void setAvgTimeHrs(Long avgTimeHrs) {
		this.avgTimeHrs = avgTimeHrs;
	}

	@Override
	public String toString() {
		return "CoderProductivityReport [coderId=" + coderId + ", coder=" + coder + ", total=" + total + ", inReview="
				+ inReview + ", completed=" + completed + ", sent=" + sent + ", deficiency=" + deficiency
				+ ", unbillable=" + unbillable + ", other=" + other + ", endDate=" + endDate + ", avgTimeMins="
				+ avgTimeMins + ", avgTimeHrs=" + avgTimeHrs + "]";
	}

	
}
