package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "patient_medical_records")
public class PatientMedicalRecords {
	@Id
	@Column(name = "patient_id")
	private long patientId;
	
	@Column(name = "visit_id")
	private long visitId;
	
	@Column(name = "document_type")
	private String documentType;
	
	@Column(name = "document_source")
	private String documentSource;
	
	@Column(name = "patient_fullname")
	private String patientFullname;
	
	@Column(name = "document_entity_id")
	private long documentEntityId;
	
	@Column(name = "document_id")
	private String documentId;
	
	@Column(name = "patient_dob")
	private Date patientDob;
	
	@Column(name = "patient_dos")
	private Timestamp patientDos;
	
	@Column(name = "facility_id")
	private int facilityId;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "received_timestamp")
	private Timestamp receivedTimestamp;
	
	@Column(name = "is_document_updated")
	private int isDocumentUpdated;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	
	@Column(name = "event_datetime")
	private Timestamp eventDatetime;
	
	@Lob
	@Column(name = "document_content")
	private String documentContent;
	
	@Column(name = "document_name")
	private String documentName;
	
	@Column(name = "sbill_provider_em", columnDefinition = "json")
	private String sbillProviderEM;
	
	@Column(name = "sbill_icd_codes", columnDefinition = "json")
	private String sbillICDCodes;
	
	@Column(name = "sbill_provider_cpt_codes", columnDefinition = "json")
	private String sbillProviderCPTCodes;
	
	@Column(name = "patient_firstname")
	private String patientFirstName;
	
	@Column(name = "patient_lastname")
	private String patientLastName;
	
	@Column(name = "patient_mrn")
	private String patientMRN;
	
	@Column(name = "sbill_provider_firstname")
	private String sbillProviderFirstName;
	
	@Column(name = "sbill_provider_lastname")
	private String sbillProviderLastName;
	
	@Column(name = "sbill_provider_id")
	private String sbillProviderId;

	public String getSbillProviderEM() {
		return sbillProviderEM;
	}

	public void setSbillProviderEM(String sbillProviderEM) {
		this.sbillProviderEM = sbillProviderEM;
	}

	public String getSbillICDCodes() {
		return sbillICDCodes;
	}

	public void setSbillICDCodes(String sbillICDCodes) {
		this.sbillICDCodes = sbillICDCodes;
	}

	public String getSbillProviderCPTCodes() {
		return sbillProviderCPTCodes;
	}

	public void setSbillProviderCPTCodes(String sbillProviderCPTCodes) {
		this.sbillProviderCPTCodes = sbillProviderCPTCodes;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientMRN() {
		return patientMRN;
	}

	public void setPatientMRN(String patientMRN) {
		this.patientMRN = patientMRN;
	}

	public String getSbillProviderFirstName() {
		return sbillProviderFirstName;
	}

	public void setSbillProviderFirstName(String sbillProviderFirstName) {
		this.sbillProviderFirstName = sbillProviderFirstName;
	}

	public String getSbillProviderLastName() {
		return sbillProviderLastName;
	}

	public void setSbillProviderLastName(String sbillProviderLastName) {
		this.sbillProviderLastName = sbillProviderLastName;
	}

	public String getSbillProviderId() {
		return sbillProviderId;
	}

	public void setSbillProviderId(String sbillProviderId) {
		this.sbillProviderId = sbillProviderId;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentSource() {
		return documentSource;
	}

	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}

	public String getPatientFullname() {
		return patientFullname;
	}

	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}

	public long getDocumentEntityId() {
		return documentEntityId;
	}

	public void setDocumentEntityId(long documentEntityId) {
		this.documentEntityId = documentEntityId;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public Date getPatientDob() {
		return patientDob;
	}

	public void setPatientDob(Date patientDob) {
		this.patientDob = patientDob;
	}

	public Timestamp getPatientDos() {
		return patientDos;
	}

	public void setPatientDos(Timestamp patientDos) {
		this.patientDos = patientDos;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Timestamp getReceivedTimestamp() {
		return receivedTimestamp;
	}

	public void setReceivedTimestamp(Timestamp receivedTimestamp) {
		this.receivedTimestamp = receivedTimestamp;
	}

	public int getIsDocumentUpdated() {
		return isDocumentUpdated;
	}

	public void setIsDocumentUpdated(int isDocumentUpdated) {
		this.isDocumentUpdated = isDocumentUpdated;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Timestamp getEventDatetime() {
		return eventDatetime;
	}

	public void setEventDatetime(Timestamp eventDatetime) {
		this.eventDatetime = eventDatetime;
	}

	public String getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	@Override
	public String toString() {
		return "PatientMedicalRecords [patientId=" + patientId + ", visitId=" + visitId + ", documentType="
				+ documentType + ", documentSource=" + documentSource + ", patientFullname=" + patientFullname
				+ ", documentEntityId=" + documentEntityId + ", documentId=" + documentId + ", patientDob=" + patientDob
				+ ", patientDos=" + patientDos + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", receivedTimestamp=" + receivedTimestamp + ", isDocumentUpdated=" + isDocumentUpdated
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", eventDatetime=" + eventDatetime
				+ ", documentContent=" + documentContent + ", documentName=" + documentName + ", sbillProviderEM="
				+ sbillProviderEM + ", sbillICDCodes=" + sbillICDCodes + ", sbillProviderCPTCodes="
				+ sbillProviderCPTCodes + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", patientMRN=" + patientMRN + ", sbillProviderFirstName=" + sbillProviderFirstName
				+ ", sbillProviderLastName=" + sbillProviderLastName + ", sbillProviderId=" + sbillProviderId + "]";
	}
}
