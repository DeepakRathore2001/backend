package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "email_notification")
public class WeeklyIncompleteReportEmail {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "facility_admin_email")
	private String facilityAdminEmail;

	@Column(name = "facility_admin_fullname")
	private String facilityAdminFullname;

	@Column(name = "email_sent_status")
	private String emailSentStatus;

	@Column(name = "email_sent_status_code")
	private String emailSentStatusCode;

	@Column(name = "email_sent_status_message")
	private String emailSentStatusMessage;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityAdminEmail() {
		return facilityAdminEmail;
	}

	public void setFacilityAdminEmail(String facilityAdminEmail) {
		this.facilityAdminEmail = facilityAdminEmail;
	}

	public String getFacilityAdminFullname() {
		return facilityAdminFullname;
	}

	public void setFacilityAdminFullname(String facilityAdminFullname) {
		this.facilityAdminFullname = facilityAdminFullname;
	}

	public String getEmailSentStatus() {
		return emailSentStatus;
	}

	public void setEmailSentStatus(String emailSentStatus) {
		this.emailSentStatus = emailSentStatus;
	}

	public String getEmailSentStatusCode() {
		return emailSentStatusCode;
	}

	public void setEmailSentStatusCode(String emailSentStatusCode) {
		this.emailSentStatusCode = emailSentStatusCode;
	}

	public String getEmailSentStatusMessage() {
		return emailSentStatusMessage;
	}

	public void setEmailSentStatusMessage(String emailSentStatusMessage) {
		this.emailSentStatusMessage = emailSentStatusMessage;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	@Override
	public String toString() {
		return "WeeklyIncompleteReportEmail [id=" + id + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", facilityName=" + facilityName + ", facilityAdminEmail=" + facilityAdminEmail
				+ ", facilityAdminFullname=" + facilityAdminFullname + ", emailSentStatus=" + emailSentStatus
				+ ", emailSentStatusCode=" + emailSentStatusCode + ", emailSentStatusMessage=" + emailSentStatusMessage
				+ "]";
	}

}
