package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reload_cmc_metrics")
public class ReloadCMCMetrics {
	@Id
	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "document_id")
	private String documentId;

	@Column(name = "document_type")
	private String documentType;
	
	@Column(name = "cmc_status")
	private Boolean cmcStatus;
	
	@Column(name = "error_code")
	private String errorCode;
	
	@Column(name = "error_message")
	private String errorMessage;

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Boolean getCmcStatus() {
		return cmcStatus;
	}

	public void setCmcStatus(Boolean cmcStatus) {
		this.cmcStatus = cmcStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "ReloadCMCMetrics [visitId=" + visitId + ", facilityId=" + facilityId + ", documentId=" + documentId
				+ ", documentType=" + documentType + ", cmcStatus=" + cmcStatus + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + "]";
	}
}
