package com.healogics.encode.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "encode_roles")
public class EncodeRoles {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "encode_role")
	private String encodeRole;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(String encodeRole) {
		this.encodeRole = encodeRole;
	}

	@Override
	public String toString() {
		return "EncodeRoles [id=" + id + ", encodeRole=" + encodeRole + "]";
	}

}
