package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "notification")
public class Notification {

	@Id
	@Column(name = "notification_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long notificationId;

	@Column(name = "username")
	private String username;

	@Column(name = "user_id")
	private String userId;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "patient_dos")
	private Timestamp patientDOS;

	@Column(name = "patient_account_no")
	private Long patientAccountNo;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "document_id")
	private String documentId;

	@Column(name = "event_datetime")
	private Timestamp eventDateTime;
	
	@Column(name = "notification_source")
	private String notificationSource;
	
	@Column(name = "file_name")
	private String fileName;
	
	@Column(name = "file_size")
	private String fileSize;
	
	@Column(name = "file_type")
	private String fileType;
	
	@Column(name = "doc_download_status")
	private String docDownloadStatus;
	
	@Column(name = "aws_bucket_name")
	private String awsBucketName;
	
	@Column(name = "user_fullname")
	private String userFullname;
	
	@Column(name = "notification_timestamp")
	private Timestamp notificationTimestamp;
	
	@Column(name = "download_timestamp")
	private Timestamp downloadTimestamp;
	
	@Column(name = "processing_time_seconds")
	private int processingTimeSeconds;
	
	@Column(name = "provider_inbox_api_status", columnDefinition = "json")
	private String providerInboxAPIStatus;
	
	@Column(name = "message_id")
	private Long messageId;
	
	@Column(name = "coc2_id")
	private String coc2Id;
	
	public String getCoc2Id() {
		return coc2Id;
	}

	public void setCoc2Id(String coc2Id) {
		this.coc2Id = coc2Id;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getProviderInboxAPIStatus() {
		return providerInboxAPIStatus;
	}

	public void setProviderInboxAPIStatus(String providerInboxAPIStatus) {
		this.providerInboxAPIStatus = providerInboxAPIStatus;
	}

	public long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Timestamp getPatientDOS() {
		return patientDOS;
	}

	public void setPatientDOS(Timestamp patientDOS) {
		this.patientDOS = patientDOS;
	}

	public Long getPatientAccountNo() {
		return patientAccountNo;
	}

	public void setPatientAccountNo(Long patientAccountNo) {
		this.patientAccountNo = patientAccountNo;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public Timestamp getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(Timestamp eventDateTime) {
		this.eventDateTime = eventDateTime;
	}
	
	public String getNotificationSource() {
		return notificationSource;
	}

	public void setNotificationSource(String notificationSource) {
		this.notificationSource = notificationSource;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getDocDownloadStatus() {
		return docDownloadStatus;
	}

	public void setDocDownloadStatus(String docDownloadStatus) {
		this.docDownloadStatus = docDownloadStatus;
	}

	public String getAwsBucketName() {
		return awsBucketName;
	}

	public void setAwsBucketName(String awsBucketName) {
		this.awsBucketName = awsBucketName;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public Timestamp getNotificationTimestamp() {
		return notificationTimestamp;
	}

	public void setNotificationTimestamp(Timestamp notificationTimestamp) {
		this.notificationTimestamp = notificationTimestamp;
	}

	public Timestamp getDownloadTimestamp() {
		return downloadTimestamp;
	}

	public void setDownloadTimestamp(Timestamp downloadTimestamp) {
		this.downloadTimestamp = downloadTimestamp;
	}

	public int getProcessingTimeSeconds() {
		return processingTimeSeconds;
	}

	public void setProcessingTimeSeconds(int processingTimeSeconds) {
		this.processingTimeSeconds = processingTimeSeconds;
	}

	@Override
	public String toString() {
		return "Notification [notificationId=" + notificationId + ", username=" + username + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId + ", facilityName=" + facilityName
				+ ", patientId=" + patientId + ", visitId=" + visitId + ", patientDOS=" + patientDOS
				+ ", patientAccountNo=" + patientAccountNo + ", documentType=" + documentType + ", documentId="
				+ documentId + ", eventDateTime=" + eventDateTime + ", notificationSource=" + notificationSource
				+ ", fileName=" + fileName + ", fileSize=" + fileSize + ", fileType=" + fileType
				+ ", docDownloadStatus=" + docDownloadStatus + ", awsBucketName=" + awsBucketName + ", userFullname="
				+ userFullname + ", notificationTimestamp=" + notificationTimestamp + ", downloadTimestamp="
				+ downloadTimestamp + ", processingTimeSeconds=" + processingTimeSeconds + ", providerInboxAPIStatus="
				+ providerInboxAPIStatus + ", messageId=" + messageId + ", coc2Id=" + coc2Id + "]";
	}

}
