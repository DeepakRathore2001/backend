package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "notes")
public class Notes {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "note_id")
	private int noteId;
	
	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "patient_mrn")
	private String patientMRN;

	@Column(name = "patient_fullname")
	private String patientFullName;

	@Column(name = "created_by_role")
	private String userRole;

	@Column(name = "creator_username")
	private String userName;

	@Column(name = "creator_fullname")
	private String userFullName;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "creator_user_id")
	private int creatorUserId;

	@Lob
	@Column(name = "description")
	private String description;

	@Column(name = "patient_acctno")
	private Long patientAccNo;

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public int getNoteId() {
		return noteId;
	}

	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientMRN() {
		return patientMRN;
	}

	public void setPatientMRN(String patientMRN) {
		this.patientMRN = patientMRN;
	}

	public String getPatientFullName() {
		return patientFullName;
	}

	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getPatientAccNo() {
		return patientAccNo;
	}

	public void setPatientAccNo(Long patientAccNo) {
		this.patientAccNo = patientAccNo;
	}
	

	public int getCreatorUserId() {
		return creatorUserId;
	}

	public void setCreatorUserId(int creatorUserId) {
		this.creatorUserId = creatorUserId;
	}

	@Override
	public String toString() {
		return "Notes [visitId=" + visitId + ", noteId=" + noteId + ", patientId=" + patientId + ", patientDOB="
				+ patientDOB + ", patientMRN=" + patientMRN + ", patientFullName=" + patientFullName + ", userRole="
				+ userRole + ", userName=" + userName + ", userFullName=" + userFullName + ", createdTimestamp="
				+ createdTimestamp + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId + ", creatorUserId="
				+ creatorUserId + ", description=" + description + ", patientAccNo=" + patientAccNo + "]";
	}

}
