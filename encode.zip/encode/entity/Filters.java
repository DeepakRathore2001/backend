package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "audit_filters")
public class Filters {
	@Id
	@Column(name = "filter_id")
	private int filterId;

	@Column(name = "filter_name")
	private String filterName;

	@Column(name = "team")
	private String team;

	@Column(name = "coders")
	private String coders;

	@Column(name = "providers")
	private String providers;

	@Column(name = "facilities")
	private String facilities;

	@Column(name = "cpt_codes")
	private String cptCodes;

	@Column(name = "icd_codes")
	private String icdCodes;

	@Column(name = "modifiers")
	private String modifiers;

	@Column(name = "units")
	private String units;

	@Column(name = "insurance")
	private String insurance;

	@Column(name = "downcoded")
	private int downcoded;

	@Column(name = "percentage")
	private int percentage;

	@Column(name = "count")
	private int count;

	@Column(name = "active")
	private int active;

	@Column(name = "created_user")
	private String createdUser;

	@Column(name = "created_username")
	private String createdUsername;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "last_updated_user")
	private String lastUpdatedUser;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "provider_id")
	private String providerId;

	@Column(name = "facility_id")
	private String facilityId;

	@Column(name = "coder_id")
	private String coderId;

	@Column(name = "coder_fullname")
	private String coderFullName;

	@Column(name = "filter_audience")
	private String filterAudience;

	@Column(name = "filter_execution_timestamp")
	private Timestamp filterExecutionTimestamp;

	@Column(name = "cpt_name")
	private String cptName;

	@Column(name = "modifier_name")
	private String modifierName;

	@Column(name = "cpt_object")
	private String cptObject;

	@Column(name = "coding_team")
	private String codingTeam;

	public String getCoderFullName() {
		return coderFullName;
	}

	public void setCoderFullName(String coderFullName) {
		this.coderFullName = coderFullName;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getCptObject() {
		return cptObject;
	}

	public void setCptObject(String cptObject) {
		this.cptObject = cptObject;
	}

	public String getCptName() {
		return cptName;
	}

	public void setCptName(String cptName) {
		this.cptName = cptName;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public String getFilterAudience() {
		return filterAudience;
	}

	public void setFilterAudience(String filterAudience) {
		this.filterAudience = filterAudience;
	}

	public Timestamp getFilterExecutionTimestamp() {
		return filterExecutionTimestamp;
	}

	public void setFilterExecutionTimestamp(Timestamp filterExecutionTimestamp) {
		this.filterExecutionTimestamp = filterExecutionTimestamp;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getCoders() {
		return coders;
	}

	public void setCoders(String coders) {
		this.coders = coders;
	}

	public String getProviders() {
		return providers;
	}

	public void setProviders(String providers) {
		this.providers = providers;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public String getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(String cptCodes) {
		this.cptCodes = cptCodes;
	}

	public String getIcdCodes() {
		return icdCodes;
	}

	public void setIcdCodes(String icdCodes) {
		this.icdCodes = icdCodes;
	}

	public String getModifiers() {
		return modifiers;
	}

	public void setModifiers(String modifiers) {
		this.modifiers = modifiers;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public int getDowncoded() {
		return downcoded;
	}

	public void setDowncoded(int downcoded) {
		this.downcoded = downcoded;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedUsername() {
		return createdUsername;
	}

	public void setCreatedUsername(String createdUsername) {
		this.createdUsername = createdUsername;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getCoderId() {
		return coderId;
	}

	public void setCoderId(String coderId) {
		this.coderId = coderId;
	}

	@Override
	public String toString() {
		return "Filters [filterId=" + filterId + ", filterName=" + filterName + ", team=" + team + ", coders=" + coders
				+ ", providers=" + providers + ", facilities=" + facilities + ", cptCodes=" + cptCodes + ", icdCodes="
				+ icdCodes + ", modifiers=" + modifiers + ", units=" + units + ", insurance=" + insurance
				+ ", downcoded=" + downcoded + ", percentage=" + percentage + ", count=" + count + ", active=" + active
				+ ", createdUser=" + createdUser + ", createdUsername=" + createdUsername + ", createdTimestamp="
				+ createdTimestamp + ", lastUpdatedUser=" + lastUpdatedUser + ", lastUpdatedUsername="
				+ lastUpdatedUsername + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", providerId=" + providerId
				+ ", facilityId=" + facilityId + ", coderId=" + coderId + ", coderFullName=" + coderFullName
				+ ", filterAudience=" + filterAudience + ", filterExecutionTimestamp=" + filterExecutionTimestamp
				+ ", cptName=" + cptName + ", modifierName=" + modifierName + ", cptObject=" + cptObject
				+ ", codingTeam=" + codingTeam + "]";
	}
}
