package com.healogics.encode.entity;

import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

@DynamoDbBean
public class HeadlessBuild {

	private String environment;
	private String appName;
	private String component;
	private String appVersion;
	private String buildVersion;
	private String appPlatform;
	private String lastUpdatedBy;
	private String lastUpdatedTime;
	private String pk;
	private String sk;

	@DynamoDbPartitionKey
	public String getPk() {
		return pk;
	}

	public void setPk(String pk) {
		this.pk = pk;
	}

	@DynamoDbSortKey
	public String getSk() {
		return sk;
	}

	public void setSk(String sk) {
		this.sk = sk;
	}

	@DynamoDbAttribute(value = "environment")
	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	@DynamoDbAttribute(value = "application_name")
	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@DynamoDbAttribute(value = "component")
	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	@DynamoDbAttribute(value = "application_version")
	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	@DynamoDbAttribute(value = "build_version")
	public String getBuildVersion() {
		return buildVersion;
	}

	public void setBuildVersion(String buildVersion) {
		this.buildVersion = buildVersion;
	}

	@DynamoDbAttribute(value = "application_platform")
	public String getAppPlatform() {
		return appPlatform;
	}

	public void setAppPlatform(String appPlatform) {
		this.appPlatform = appPlatform;
	}

	@DynamoDbAttribute(value = "last_updated_user")
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@DynamoDbAttribute(value = "last_updated_timestamp")
	public String getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	@Override
	public String toString() {
		return "HeadlessBuild{" + "environment='" + environment + '\'' + ", appName='" + appName + '\''
				+ ", component='" + component + '\'' + ", appVersion='" + appVersion + '\'' + ", buildVersion='"
				+ buildVersion + '\'' + ", appPlatform='" + appPlatform + '\'' + ", lastUpdatedBy='" + lastUpdatedBy
				+ '\'' + ", lastUpdatedTime='" + lastUpdatedTime + '\'' + ", pk='" + pk + '\'' + ", sk='" + sk + '\''
				+ '}';
	}

}
