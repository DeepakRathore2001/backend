package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient_insurance")
public class PatientInsurance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "patient_id")
	private String patientId;

	@Column(name = "family_name")
	private String familyName;

	@Column(name = "given_name")
	private String givenName;

	@Column(name = "facility_id")
	private String facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "insurance_id")
	private String insuranceId;

	@Column(name = "insurance_name")
	private String insuranceName;

	@Column(name = "street_address")
	private String streetAddress;

	@Column(name = "other_designation")
	private String otherDesignation;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "zip")
	private String zip;

	@Column(name = "insured_family_name")
	private String insuredFamilyName;

	@Column(name = "insured_given_name")
	private String insuredGivenName;

	@Column(name = "insured_relation")
	private String insuredRelation;

	@Column(name = "insured_dob")
	private String insuredDOB;

	@Column(name = "priority")
	private String priority;

	@Column(name = "policy_number")
	private String policyNumber;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "group_number")
	private String groupNumber;

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(String insuranceId) {
		this.insuranceId = insuranceId;
	}

	public String getInsuranceName() {
		return insuranceName;
	}

	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getOtherDesignation() {
		return otherDesignation;
	}

	public void setOtherDesignation(String otherDesignation) {
		this.otherDesignation = otherDesignation;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getInsuredFamilyName() {
		return insuredFamilyName;
	}

	public void setInsuredFamilyName(String insuredFamilyName) {
		this.insuredFamilyName = insuredFamilyName;
	}

	public String getInsuredGivenName() {
		return insuredGivenName;
	}

	public void setInsuredGivenName(String insuredGivenName) {
		this.insuredGivenName = insuredGivenName;
	}

	public String getInsuredRelation() {
		return insuredRelation;
	}

	public void setInsuredRelation(String insuredRelation) {
		this.insuredRelation = insuredRelation;
	}

	public String getInsuredDOB() {
		return insuredDOB;
	}

	public void setInsuredDOB(String insuredDOB) {
		this.insuredDOB = insuredDOB;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	@Override
	public String toString() {
		return "PatientInsurance [id=" + id + ", visitId=" + visitId + ", patientId=" + patientId + ", familyName="
				+ familyName + ", givenName=" + givenName + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", insuranceId=" + insuranceId + ", insuranceName=" + insuranceName + ", streetAddress="
				+ streetAddress + ", otherDesignation=" + otherDesignation + ", city=" + city + ", state=" + state
				+ ", zip=" + zip + ", insuredFamilyName=" + insuredFamilyName + ", insuredGivenName=" + insuredGivenName
				+ ", insuredRelation=" + insuredRelation + ", insuredDOB=" + insuredDOB + ", priority=" + priority
				+ ", policyNumber=" + policyNumber + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", groupNumber="
				+ groupNumber + "]";
	}

}
