package com.healogics.encode.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "monthly_charge_summary_procedure_report")
public class MonthlyChargeSummaryProcedureReport {

	@Id
	@Column(name = "cpt_code")
	private String cptCode;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "date_of_service")
	private Date dateOfService;

	@Column(name = "code_count")
	private int codeCount;

	@Column(name = "percentage")
	private Double percentage;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "iheal_config")
	private String ihealConfig;

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public int getCodeCount() {
		return codeCount;
	}

	public void setCodeCount(int codeCount) {
		this.codeCount = codeCount;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	@Override
	public String toString() {
		return "MonthlyChargeSummaryProcedureReport [cptCode=" + cptCode
				+ ", bluebookId=" + bluebookId + ", visitId=" + visitId
				+ ", facilityId=" + facilityId + ", dateOfService="
				+ dateOfService + ", codeCount=" + codeCount + ", percentage="
				+ percentage + ", providerName=" + providerName
				+ ", ihealConfig=" + ihealConfig + "]";
	}

}
