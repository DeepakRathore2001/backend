package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "superbill_variance")
public class SuperbillVariance {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "provider_id")
	private int providerId;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "date_of_service")
	private Date dateOfService;

	@Column(name = "date_billed")
	private Date dateBilled;

	@Column(name = "potential_cpt_code")
	private String potentialCptCode;

	@Column(name = "actual_cpt_code")
	private String actualCptCode;

	@Column(name = "variance_reason")
	private String varianceReason;

	@Column(name = "comment")
	private String comment;

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public Date getDateBilled() {
		return dateBilled;
	}

	public void setDateBilled(Date dateBilled) {
		this.dateBilled = dateBilled;
	}

	public String getPotentialCptCode() {
		return potentialCptCode;
	}

	public void setPotentialCptCode(String potentialCptCode) {
		this.potentialCptCode = potentialCptCode;
	}

	public String getActualCptCode() {
		return actualCptCode;
	}

	public void setActualCptCode(String actualCptCode) {
		this.actualCptCode = actualCptCode;
	}

	public String getVarianceReason() {
		return varianceReason;
	}

	public void setVarianceReason(String varianceReason) {
		this.varianceReason = varianceReason;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "SuperbillVariance [visitId=" + visitId + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId
				+ ", providerId=" + providerId + ", ihealConfig=" + ihealConfig + ", facilityName=" + facilityName
				+ ", providerName=" + providerName + ", patientName=" + patientName + ", dateOfService=" + dateOfService
				+ ", dateBilled=" + dateBilled + ", potentialCptCode=" + potentialCptCode + ", actualCptCode="
				+ actualCptCode + ", varianceReason=" + varianceReason + ", comment=" + comment + "]";
	}

}
