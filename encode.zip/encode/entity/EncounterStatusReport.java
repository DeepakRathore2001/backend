package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "encounter_status_report")
public class EncounterStatusReport {

	@Id
	@Column(name = "date_of_service")
	private Timestamp dateOfService;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "iheal_config ")
	private String ihealConfig ;

	@Column(name = "provider_id")
	private Long providerId;
	
	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "provider_name", insertable = false, updatable = false)
	private String providerName;

	@Column(name = "ready")
	private int ready;

	@Column(name = "completed")
	private int completed;

	@Column(name = "in_review")
	private int inreview;
	
	@Column(name = "review")
	private int review;

	@Column(name = "received")
	private int received;

	@Column(name = "unbillable")
	private int unbillable;

	@Column(name = "sent")
	private int sent;

	@Column(name = "no_status")
	private int nostatus;

	
	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public int getReview() {
		return review;
	}

	public void setReview(int review) {
		this.review = review;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Long getProviderId() {
		return providerId;
	}

	public void setProviderId(Long providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public int getReady() {
		return ready;
	}

	public void setReady(int ready) {
		this.ready = ready;
	}

	public int getCompleted() {
		return completed;
	}

	public void setCompleted(int completed) {
		this.completed = completed;
	}

	public int getInreview() {
		return inreview;
	}

	public void setInreview(int inreview) {
		this.inreview = inreview;
	}

	public int getReceived() {
		return received;
	}

	public void setReceived(int received) {
		this.received = received;
	}

	public int getUnbillable() {
		return unbillable;
	}

	public void setUnbillable(int unbillable) {
		this.unbillable = unbillable;
	}

	public int getSent() {
		return sent;
	}

	public void setSent(int sent) {
		this.sent = sent;
	}

	public int getNostatus() {
		return nostatus;
	}

	public void setNostatus(int nostatus) {
		this.nostatus = nostatus;
	}

	@Override
	public String toString() {
		return "EncounterStatusReport [dateOfService=" + dateOfService + ", bluebookId=" + bluebookId + ", ihealConfig="
				+ ihealConfig + ", providerId=" + providerId + ", facilityId=" + facilityId + ", providerName="
				+ providerName + ", ready=" + ready + ", completed=" + completed + ", inreview=" + inreview
				+ ", review=" + review + ", received=" + received + ", unbillable=" + unbillable + ", sent=" + sent
				+ ", nostatus=" + nostatus + "]";
	}

}
