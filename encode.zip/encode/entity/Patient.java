package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name = "patient")
public class Patient {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "patient_id")
	private String patientId;

	@Column(name = "given_name")
	private String givenName;

	@Column(name = "family_name")
	private String familyName;

	@Column(name = "patient_gender")
	private String patientGender;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@Column(name = "street_address")
	private String streetAddress;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "zip_code")
	private String zipCode;

	@Column(name = "birth_place")
	private String birthPlace;

	@Column(name = "point_of_care")
	private String pointOfCare;

	@Column(name = "bed")
	private String bed;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "building")
	private String building;

	@Column(name = "floor")
	private String floor;

	@Column(name = "location_description")
	private String locationDescription;

	@Column(name = "attending_doc_id")
	private String attendingDocId;

	@Column(name = "attending_doc_name")
	private String attendingDocName;

	@Column(name = "admitting_doc_id")
	private String admittingDocId;

	@Column(name = "admitting_doc_family_name")
	private String admittingDocFamilyName;

	@Column(name = "admitting_doc_given_name")
	private String admittingDocGivenName;

	@Column(name = "guarantor_family_name")
	private String guarantorFamilyName;

	@Column(name = "guarantor_given_name")
	private String guarantorGivenName;

	@Column(name = "guarantor_street_address")
	private String guarantorStreetAddress;

	@Column(name = "guarantor_city")
	private String guarantorCity;

	@Column(name = "guarantor_state")
	private String guarantorState;

	@Column(name = "guarantor_zip")
	private String guarantorZip;

	@Column(name = "guarantor_relation")
	private String guarantorRelation;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "phone_1")
	private String phone1;

	@Column(name = "phone_2")
	private String phone2;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	public String getPointOfCare() {
		return pointOfCare;
	}

	public void setPointOfCare(String pointOfCare) {
		this.pointOfCare = pointOfCare;
	}

	public String getBed() {
		return bed;
	}

	public void setBed(String bed) {
		this.bed = bed;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getLocationDescription() {
		return locationDescription;
	}

	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

	public String getAttendingDocId() {
		return attendingDocId;
	}

	public void setAttendingDocId(String attendingDocId) {
		this.attendingDocId = attendingDocId;
	}

	public String getAttendingDocName() {
		return attendingDocName;
	}

	public void setAttendingDocName(String attendingDocName) {
		this.attendingDocName = attendingDocName;
	}

	public String getAdmittingDocId() {
		return admittingDocId;
	}

	public void setAdmittingDocId(String admittingDocId) {
		this.admittingDocId = admittingDocId;
	}

	public String getAdmittingDocFamilyName() {
		return admittingDocFamilyName;
	}

	public void setAdmittingDocFamilyName(String admittingDocFamilyName) {
		this.admittingDocFamilyName = admittingDocFamilyName;
	}

	public String getAdmittingDocGivenName() {
		return admittingDocGivenName;
	}

	public void setAdmittingDocGivenName(String admittingDocGivenName) {
		this.admittingDocGivenName = admittingDocGivenName;
	}

	public String getGuarantorFamilyName() {
		return guarantorFamilyName;
	}

	public void setGuarantorFamilyName(String guarantorFamilyName) {
		this.guarantorFamilyName = guarantorFamilyName;
	}

	public String getGuarantorGivenName() {
		return guarantorGivenName;
	}

	public void setGuarantorGivenName(String guarantorGivenName) {
		this.guarantorGivenName = guarantorGivenName;
	}

	public String getGuarantorStreetAddress() {
		return guarantorStreetAddress;
	}

	public void setGuarantorStreetAddress(String guarantorStreetAddress) {
		this.guarantorStreetAddress = guarantorStreetAddress;
	}

	public String getGuarantorCity() {
		return guarantorCity;
	}

	public void setGuarantorCity(String guarantorCity) {
		this.guarantorCity = guarantorCity;
	}

	public String getGuarantorState() {
		return guarantorState;
	}

	public void setGuarantorState(String guarantorState) {
		this.guarantorState = guarantorState;
	}

	public String getGuarantorZip() {
		return guarantorZip;
	}

	public void setGuarantorZip(String guarantorZip) {
		this.guarantorZip = guarantorZip;
	}

	public String getGuarantorRelation() {
		return guarantorRelation;
	}

	public void setGuarantorRelation(String guarantorRelation) {
		this.guarantorRelation = guarantorRelation;
	}

	public String getPatientGender() {
		return patientGender;
	}

	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}

	@Override
	public String toString() {
		return "Patient [visitId=" + visitId + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId
				+ ", patientId=" + patientId + ", givenName=" + givenName + ", familyName=" + familyName
				+ ", patientGender=" + patientGender + ", dateOfBirth=" + dateOfBirth + ", streetAddress="
				+ streetAddress + ", city=" + city + ", state=" + state + ", zipCode=" + zipCode + ", birthPlace="
				+ birthPlace + ", pointOfCare=" + pointOfCare + ", bed=" + bed + ", facilityName=" + facilityName
				+ ", building=" + building + ", floor=" + floor + ", locationDescription=" + locationDescription
				+ ", attendingDocId=" + attendingDocId + ", attendingDocName=" + attendingDocName + ", admittingDocId="
				+ admittingDocId + ", admittingDocFamilyName=" + admittingDocFamilyName + ", admittingDocGivenName="
				+ admittingDocGivenName + ", guarantorFamilyName=" + guarantorFamilyName + ", guarantorGivenName="
				+ guarantorGivenName + ", guarantorStreetAddress=" + guarantorStreetAddress + ", guarantorCity="
				+ guarantorCity + ", guarantorState=" + guarantorState + ", guarantorZip=" + guarantorZip
				+ ", guarantorRelation=" + guarantorRelation + ", emailId=" + emailId + ", phone1=" + phone1
				+ ", phone2=" + phone2 + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + "]";
	}

}
