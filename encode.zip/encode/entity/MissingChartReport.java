package com.healogics.encode.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "missing_chart_report")
public class MissingChartReport {

	@Id
	@Column(name = "date_of_service")
	private Date dateOfService;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "facility")
	private String facilityName;

	@Column(name = "missing_chart")
	private int missingChart;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "iheal_config")
	private String ihealConfig;

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public int getMissingChart() {
		return missingChart;
	}

	public void setMissingChart(int missingChart) {
		this.missingChart = missingChart;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	@Override
	public String toString() {
		return "MissingChartReport [dateOfService=" + dateOfService
				+ ", bluebookId=" + bluebookId + ", facilityId=" + facilityId
				+ ", facilityName=" + facilityName + ", missingChart="
				+ missingChart + ", providerName=" + providerName
				+ ", ihealConfig=" + ihealConfig + "]";
	}

}
