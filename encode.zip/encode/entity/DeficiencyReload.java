package com.healogics.encode.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deficiency_reload")
public class DeficiencyReload {

	@Id
	@Column(name = "visit_id")
	private Integer visitId;

	@Column(name = "deficiency_date")
	private Timestamp deficiencyDate;

	@Column(name = "status")
	private String status;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "last_updated_timestamp")
	private String lastUpdatedTimestamp;

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public Timestamp getDeficiencyDate() {
		return deficiencyDate;
	}

	public void setDeficiencyDate(Timestamp deficiencyDate) {
		this.deficiencyDate = deficiencyDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(String lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "DeficiencyReload [visitId=" + visitId + ", deficiencyDate=" + deficiencyDate + ", status=" + status
				+ ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + "]";
	}

}
