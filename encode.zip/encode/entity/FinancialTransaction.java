package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "financial_transaction")
public class FinancialTransaction {

	@Id
	@Column(name = "visit_id")
	private int visitId;

	@Column(name = "id")
	private int id;

	@Column(name = "transaction_type")
	private String transactionType;

	@Column(name = "transaction_date")
	private String transactionDate;

	@Column(name = "transaction_code")
	private String transactionCode;

	@Column(name = "transaction_quantity")
	private String transactionQuantity;

	@Column(name = "point_of_care")
	private String pointOfCare;

	@Column(name = "diagnosis_code")
	private String diagnosisCode;

	@Column(name = "performed_by_id")
	private String performedById;

	@Column(name = "performed_by_fullname")
	private String performedByFullName;

	@Column(name = "coded_by_family_name")
	private String codedByFamilyName;

	@Column(name = "coded_by_given_name")
	private String codedByGivenName;

	@Column(name = "procedure_code")
	private String procedureCode;

	@Column(name = "modifier")
	private String modifier;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTransactionQuantity() {
		return transactionQuantity;
	}

	public void setTransactionQuantity(String transactionQuantity) {
		this.transactionQuantity = transactionQuantity;
	}

	public String getPointOfCare() {
		return pointOfCare;
	}

	public void setPointOfCare(String pointOfCare) {
		this.pointOfCare = pointOfCare;
	}

	public String getDiagnosisCode() {
		return diagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		this.diagnosisCode = diagnosisCode;
	}

	public String getPerformedById() {
		return performedById;
	}

	public void setPerformedById(String performedById) {
		this.performedById = performedById;
	}

	public String getPerformedByFullName() {
		return performedByFullName;
	}

	public void setPerformedByFullName(String performedByFullName) {
		this.performedByFullName = performedByFullName;
	}

	public String getCodedByFamilyName() {
		return codedByFamilyName;
	}

	public void setCodedByFamilyName(String codedByFamilyName) {
		this.codedByFamilyName = codedByFamilyName;
	}

	public String getCodedByGivenName() {
		return codedByGivenName;
	}

	public void setCodedByGivenName(String codedByGivenName) {
		this.codedByGivenName = codedByGivenName;
	}

	public String getProcedureCode() {
		return procedureCode;
	}

	public void setProcedureCode(String procedureCode) {
		this.procedureCode = procedureCode;
	}

	@Override
	public String toString() {
		return "FinancialTransaction [visitId=" + visitId + ", id=" + id + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", transactionCode=" + transactionCode
				+ ", transactionQuantity=" + transactionQuantity + ", pointOfCare=" + pointOfCare + ", diagnosisCode="
				+ diagnosisCode + ", performedById=" + performedById + ", performedByFullName=" + performedByFullName
				+ ", codedByFamilyName=" + codedByFamilyName + ", codedByGivenName=" + codedByGivenName
				+ ", procedureCode=" + procedureCode + ", modifier=" + modifier + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + "]";
	}

}
