package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "audit_filters")
public class AuditFilters {
	@Id
	@Column(name = "filter_id")
	private int filterId;

	@Column(name = "filter_name")
	private String filterName;

	@Column(name = "billing_client")
	private String billingClient;

	@Column(name = "coders", columnDefinition = "json")
	private String coders;

	@Column(name = "providers", columnDefinition = "json")
	private String providers;

	@Column(name = "facilities", columnDefinition = "json")
	private String facilities;

	@Column(name = "cpt_codes", columnDefinition = "json")
	private String cptCodes;

	@Column(name = "icd_codes", columnDefinition = "json")
	private String icdCodes;

	@Column(name = "modifiers")
	private String modifiers;

	@Column(name = "units")
	private String units;

	@Column(name = "insurance")
	private String insurance;

	@Column(name = "downcoded")
	private int downcoded;

	@Column(name = "percentage")
	private int percentage;

	@Column(name = "count")
	private int count;

	@Column(name = "active")
	private int active;

	@Column(name = "created_user")
	private String createdUser;

	@Column(name = "created_username")
	private String createdUsername;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "last_updated_user")
	private String lastUpdatedUser;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getBillingClient() {
		return billingClient;
	}

	public void setBillingClient(String billingClient) {
		this.billingClient = billingClient;
	}

	public String getCoders() {
		return coders;
	}

	public void setCoders(String coders) {
		this.coders = coders;
	}

	public String getProviders() {
		return providers;
	}

	public void setProviders(String providers) {
		this.providers = providers;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public String getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(String cptCodes) {
		this.cptCodes = cptCodes;
	}

	public String getIcdCodes() {
		return icdCodes;
	}

	public void setIcdCodes(String icdCodes) {
		this.icdCodes = icdCodes;
	}

	public String getModifiers() {
		return modifiers;
	}

	public void setModifiers(String modifiers) {
		this.modifiers = modifiers;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public int getDowncoded() {
		return downcoded;
	}

	public void setDowncoded(int downcoded) {
		this.downcoded = downcoded;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedUsername() {
		return createdUsername;
	}

	public void setCreatedUsername(String createdUsername) {
		this.createdUsername = createdUsername;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "AuditFilters [filterId=" + filterId + ", filterName=" + filterName + ", billingClient=" + billingClient
				+ ", coders=" + coders + ", providers=" + providers + ", facilities=" + facilities + ", cptCodes="
				+ cptCodes + ", icdCodes=" + icdCodes + ", modifiers=" + modifiers + ", units=" + units + ", insurance="
				+ insurance + ", downcoded=" + downcoded + ", percentage=" + percentage + ", count=" + count
				+ ", active=" + active + ", createdUser=" + createdUser + ", createdUsername=" + createdUsername
				+ ", createdTimestamp=" + createdTimestamp + ", lastUpdatedUser=" + lastUpdatedUser
				+ ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ "]";
	}
}
