package com.healogics.encode.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "encounter_needing_guidance_report")
public class EncounterNeedingGuidanceReport {

	@Id
	@Column(name = "visit_id")
	private long visitId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String blueBookId;

	@Column(name = "coder_user_id")
	private String coderUserId;

	@Column(name = "coder_username")
	private String coderUserName;

	@Column(name = "guidance_date")
	private Timestamp guidanceDate;

	@Column(name = "days_in_guidance")
	private int daysInGuidance;

	@Column(name = "date_of_service")
	private Timestamp dateOfService;

	@Column(name = "review_reason")
	private String reviewReason;

	@Column(name = "guidance_notes")
	private String guidanceNotes;

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBlueBookId() {
		return blueBookId;
	}

	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}

	public String getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public Timestamp getGuidanceDate() {
		return guidanceDate;
	}

	public void setGuidanceDate(Timestamp guidanceDate) {
		this.guidanceDate = guidanceDate;
	}

	public int getDaysInGuidance() {
		return daysInGuidance;
	}

	public void setDaysInGuidance(int daysInGuidance) {
		this.daysInGuidance = daysInGuidance;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getReviewReason() {
		return reviewReason;
	}

	public void setReviewReason(String reviewReason) {
		this.reviewReason = reviewReason;
	}

	public String getGuidanceNotes() {
		return guidanceNotes;
	}

	public void setGuidanceNotes(String guidanceNotes) {
		this.guidanceNotes = guidanceNotes;
	}

	@Override
	public String toString() {
		return "EncounterNeedingGuidanceReport [visitId=" + visitId + ", facilityId=" + facilityId + ", blueBookId="
				+ blueBookId + ", coderUserId=" + coderUserId + ", coderUserName=" + coderUserName + ", guidanceDate="
				+ guidanceDate + ", daysInGuidance=" + daysInGuidance + ", dateOfService=" + dateOfService
				+ ", reviewReason=" + reviewReason + ", guidanceNotes=" + guidanceNotes + "]";
	}

}
