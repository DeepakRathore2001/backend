package com.healogics.encode.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotesReq {

	public int getCreatorUserId() {
		return creatorUserId;
	}

	public void setCreatorUserId(int creatorUserId) {
		this.creatorUserId = creatorUserId;
	}

	private Long visitId;
	private Long patientId;
	private Date patientDOB;
	private String patientMRN;
	private String patientFullName;
	private String userRole;
	private String userName;
	private String userFullName;
	private int facilityId;
	private String bluebookId;
	private String description;
	private Long patientAccNo;
	private int creatorUserId;
	private String dashboard;

	private Boolean userTaggedInNotes;
	private List<TaggedUsers> taggedUsers;

	public String getDashboard() {
		return dashboard;
	}

	public void setDashboard(String dashboard) {
		this.dashboard = dashboard;
	}

	public Boolean getUserTaggedInNotes() {
		return userTaggedInNotes;
	}

	public void setUserTaggedInNotes(Boolean userTaggedInNotes) {
		this.userTaggedInNotes = userTaggedInNotes;
	}

	public List<TaggedUsers> getTaggedUsers() {
		return taggedUsers;
	}

	public void setTaggedUsers(List<TaggedUsers> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientMRN() {
		return patientMRN;
	}

	public void setPatientMRN(String patientMRN) {
		this.patientMRN = patientMRN;
	}

	public String getPatientFullName() {
		return patientFullName;
	}

	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getPatientAccNo() {
		return patientAccNo;
	}

	public void setPatientAccNo(Long patientAccNo) {
		this.patientAccNo = patientAccNo;
	}

	@Override
	public String toString() {
		return "NotesReq [visitId=" + visitId + ", patientId=" + patientId + ", patientDOB=" + patientDOB
				+ ", patientMRN=" + patientMRN + ", patientFullName=" + patientFullName + ", userRole=" + userRole
				+ ", userName=" + userName + ", userFullName=" + userFullName + ", facilityId=" + facilityId
				+ ", bluebookId=" + bluebookId + ", description=" + description + ", patientAccNo=" + patientAccNo
				+ ", creatorUserId=" + creatorUserId + ", dashboard=" + dashboard + ", userTaggedInNotes="
				+ userTaggedInNotes + ", taggedUsers=" + taggedUsers + "]";
	}

}
