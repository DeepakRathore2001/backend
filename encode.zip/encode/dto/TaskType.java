package com.healogics.encode.dto;

import java.util.Map;

public class TaskType {

	private Map<String, Object> MY;

	public Map<String, Object> getMY() {
		return MY;
	}

	public void setMY(Map<String, Object> mY) {
		MY = mY;
	}

	@Override
	public String toString() {
		return "TaskType [MY=" + MY + "]";
	}

}
