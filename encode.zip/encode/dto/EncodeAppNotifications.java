package com.healogics.encode.dto;

import java.sql.Timestamp;

public class EncodeAppNotifications {

	private long notificationId;
	private Long userId;
	private String userName;
	private Boolean readFlag;
	private String notificationDescription;
	private String notificationTitle;
	private String hyperlink;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;
	private String userFullname;
	private Long creatorUserId;
	private String creatorUsername;
	private String creatorUserFullname;
	private String userColorCodes;
	private String creatorColorCodes;

	public String getUserColorCodes() {
		return userColorCodes;
	}

	public void setUserColorCodes(String userColorCodes) {
		this.userColorCodes = userColorCodes;
	}

	public String getCreatorColorCodes() {
		return creatorColorCodes;
	}

	public void setCreatorColorCodes(String creatorColorCodes) {
		this.creatorColorCodes = creatorColorCodes;
	}

	public long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Boolean getReadFlag() {
		return readFlag;
	}

	public void setReadFlag(Boolean readFlag) {
		this.readFlag = readFlag;
	}

	public String getNotificationDescription() {
		return notificationDescription;
	}

	public void setNotificationDescription(String notificationDescription) {
		this.notificationDescription = notificationDescription;
	}

	public String getNotificationTitle() {
		return notificationTitle;
	}

	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}

	public String getHyperlink() {
		return hyperlink;
	}

	public void setHyperlink(String hyperlink) {
		this.hyperlink = hyperlink;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public Long getCreatorUserId() {
		return creatorUserId;
	}

	public void setCreatorUserId(Long creatorUserId) {
		this.creatorUserId = creatorUserId;
	}

	public String getCreatorUsername() {
		return creatorUsername;
	}

	public void setCreatorUsername(String creatorUsername) {
		this.creatorUsername = creatorUsername;
	}

	public String getCreatorUserFullname() {
		return creatorUserFullname;
	}

	public void setCreatorUserFullname(String creatorUserFullname) {
		this.creatorUserFullname = creatorUserFullname;
	}

	@Override
	public String toString() {
		return "EncodeAppNotifications [notificationId=" + notificationId
				+ ", userId=" + userId + ", userName=" + userName
				+ ", readFlag=" + readFlag + ", notificationDescription="
				+ notificationDescription + ", notificationTitle="
				+ notificationTitle + ", hyperlink=" + hyperlink
				+ ", createdTimestamp=" + createdTimestamp
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", userFullname=" + userFullname + ", creatorUserId="
				+ creatorUserId + ", creatorUsername=" + creatorUsername
				+ ", creatorUserFullname=" + creatorUserFullname
				+ ", userColorCodes=" + userColorCodes + ", creatorColorCodes="
				+ creatorColorCodes + "]";
	}

}
