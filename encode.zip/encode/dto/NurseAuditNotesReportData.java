package com.healogics.encode.dto;

public class NurseAuditNotesReportData {

	private int visitId;
	private int facilityId;
	private String facilityName;
	private String auditDate;
	private String dateOfService;
	private String queuedDate;
	private String units;
	private String providerId;
	private String providerName;
	private String resolution;
	private String nurseComments;
	private Long assignedNurseId;
	private String assignedNurseUserName;
	private String assignedNurseFullName;
	private Long patientId;
	private String patientName;

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(String auditDate) {
		this.auditDate = auditDate;
	}

	public String getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getQueuedDate() {
		return queuedDate;
	}

	public void setQueuedDate(String queuedDate) {
		this.queuedDate = queuedDate;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public String getNurseComments() {
		return nurseComments;
	}

	public void setNurseComments(String nurseComments) {
		this.nurseComments = nurseComments;
	}

	public Long getAssignedNurseId() {
		return assignedNurseId;
	}

	public void setAssignedNurseId(Long assignedNurseId) {
		this.assignedNurseId = assignedNurseId;
	}

	public String getAssignedNurseUserName() {
		return assignedNurseUserName;
	}

	public void setAssignedNurseUserName(String assignedNurseUserName) {
		this.assignedNurseUserName = assignedNurseUserName;
	}

	public String getAssignedNurseFullName() {
		return assignedNurseFullName;
	}

	public void setAssignedNurseFullName(String assignedNurseFullName) {
		this.assignedNurseFullName = assignedNurseFullName;
	}

	@Override
	public String toString() {
		return "NurseAuditNotesReportData [visitId=" + visitId + ", facilityId=" + facilityId + ", facilityName="
				+ facilityName + ", auditDate=" + auditDate + ", dateOfService=" + dateOfService + ", queuedDate="
				+ queuedDate + ", units=" + units + ", providerId=" + providerId + ", providerName=" + providerName
				+ ", resolution=" + resolution + ", nurseComments=" + nurseComments + ", assignedNurseId="
				+ assignedNurseId + ", assignedNurseUserName=" + assignedNurseUserName + ", assignedNurseFullName="
				+ assignedNurseFullName + ", patientId=" + patientId + ", patientName=" + patientName + "]";
	}

}
