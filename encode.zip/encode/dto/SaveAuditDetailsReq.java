package com.healogics.encode.dto;

import java.util.List;

public class SaveAuditDetailsReq {

	private Long visitId;
	private Long patientId;
	private int filterId;
	private String action;
	private String auditCategory;
	private String auditReason;
	private String auditNotes;
	private int inAudit;
	private String userId;
	private String userName;
	private String userFullName;
	private String userFirstName;
	private String userLastName;
	private String masterToken;
	private List<ICD10Data> icdData;
	private List<CPTChartDetails> cptData;
	private String nurseUserId;
	private String nurseUserName;
	private String nurseUserFullName;
	private String nurseDeficiencyReason;
	private String resolution;
	private List<String> deficiencyReason;
	private Long deficientProviderUserId;
	private String deficientProviderName;
	private String iHealConfig;
	private String patientLastName;
	private String patientFirstName;
	private String deficientNote;
	private String dateOfService;
	private String providerCPTCode;
	private List<String> weaknessReason;
	private String weaknessNote;
	private String coderCPTCode;
	private Boolean userTaggedInNotes;
	private List<TaggedUsers> taggedUsers;
	private String userRole;

	public List<TaggedUsers> getTaggedUsers() {
		return taggedUsers;
	}

	public void setTaggedUsers(List<TaggedUsers> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Boolean getUserTaggedInNotes() {
		return userTaggedInNotes;
	}

	public void setUserTaggedInNotes(Boolean userTaggedInNotes) {
		this.userTaggedInNotes = userTaggedInNotes;
	}

	public String getProviderCPTCode() {
		return providerCPTCode;
	}

	public void setProviderCPTCode(String providerCPTCode) {
		this.providerCPTCode = providerCPTCode;
	}

	public List<String> getWeaknessReason() {
		return weaknessReason;
	}

	public void setWeaknessReason(List<String> weaknessReason) {
		this.weaknessReason = weaknessReason;
	}

	public String getWeaknessNote() {
		return weaknessNote;
	}

	public void setWeaknessNote(String weaknessNote) {
		this.weaknessNote = weaknessNote;
	}

	public String getCoderCPTCode() {
		return coderCPTCode;
	}

	public void setCoderCPTCode(String coderCPTCode) {
		this.coderCPTCode = coderCPTCode;
	}

	public String getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getDeficientNote() {
		return deficientNote;
	}

	public void setDeficientNote(String deficientNote) {
		this.deficientNote = deficientNote;
	}

	public String getiHealConfig() {
		return iHealConfig;
	}

	public void setiHealConfig(String iHealConfig) {
		this.iHealConfig = iHealConfig;
	}

	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public Long getDeficientProviderUserId() {
		return deficientProviderUserId;
	}

	public void setDeficientProviderUserId(Long deficientProviderUserId) {
		this.deficientProviderUserId = deficientProviderUserId;
	}

	public String getDeficientProviderName() {
		return deficientProviderName;
	}

	public void setDeficientProviderName(String deficientProviderName) {
		this.deficientProviderName = deficientProviderName;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public String getNurseDeficiencyReason() {
		return nurseDeficiencyReason;
	}

	public void setNurseDeficiencyReason(String nurseDeficiencyReason) {
		this.nurseDeficiencyReason = nurseDeficiencyReason;
	}

	public String getNurseUserId() {
		return nurseUserId;
	}

	public void setNurseUserId(String nurseUserId) {
		this.nurseUserId = nurseUserId;
	}

	public String getNurseUserName() {
		return nurseUserName;
	}

	public void setNurseUserName(String nurseUserName) {
		this.nurseUserName = nurseUserName;
	}

	public String getNurseUserFullName() {
		return nurseUserFullName;
	}

	public void setNurseUserFullName(String nurseUserFullName) {
		this.nurseUserFullName = nurseUserFullName;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getAuditCategory() {
		return auditCategory;
	}

	public void setAuditCategory(String auditCategory) {
		this.auditCategory = auditCategory;
	}

	public String getAuditReason() {
		return auditReason;
	}

	public void setAuditReason(String auditReason) {
		this.auditReason = auditReason;
	}

	public String getAuditNotes() {
		return auditNotes;
	}

	public void setAuditNotes(String auditNotes) {
		this.auditNotes = auditNotes;
	}

	public int getInAudit() {
		return inAudit;
	}

	public void setInAudit(int inAudit) {
		this.inAudit = inAudit;
	}

	public List<ICD10Data> getIcdData() {
		return icdData;
	}

	public void setIcdData(List<ICD10Data> icdData) {
		this.icdData = icdData;
	}

	public List<CPTChartDetails> getCptData() {
		return cptData;
	}

	public void setCptData(List<CPTChartDetails> cptData) {
		this.cptData = cptData;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "SaveAuditDetailsReq [visitId=" + visitId + ", patientId=" + patientId + ", filterId=" + filterId
				+ ", action=" + action + ", auditCategory=" + auditCategory + ", auditReason=" + auditReason
				+ ", auditNotes=" + auditNotes + ", inAudit=" + inAudit + ", userId=" + userId + ", userName="
				+ userName + ", userFullName=" + userFullName + ", userFirstName=" + userFirstName + ", userLastName="
				+ userLastName + ", masterToken=" + masterToken + ", icdData=" + icdData + ", cptData=" + cptData
				+ ", nurseUserId=" + nurseUserId + ", nurseUserName=" + nurseUserName + ", nurseUserFullName="
				+ nurseUserFullName + ", nurseDeficiencyReason=" + nurseDeficiencyReason + ", resolution=" + resolution
				+ ", deficiencyReason=" + deficiencyReason + ", deficientProviderUserId=" + deficientProviderUserId
				+ ", deficientProviderName=" + deficientProviderName + ", iHealConfig=" + iHealConfig
				+ ", patientLastName=" + patientLastName + ", patientFirstName=" + patientFirstName + ", deficientNote="
				+ deficientNote + ", dateOfService=" + dateOfService + ", providerCPTCode=" + providerCPTCode
				+ ", weaknessReason=" + weaknessReason + ", weaknessNote=" + weaknessNote + ", coderCPTCode="
				+ coderCPTCode + ", userTaggedInNotes=" + userTaggedInNotes + ", taggedUsers=" + taggedUsers
				+ ", userRole=" + userRole + "]";
	}

}
