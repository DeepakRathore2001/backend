package com.healogics.encode.dto;

public class SNSRecords {
	private String eventVersion;
	private String eventSource;
	private String awsRegion;
	private String eventTime;
	private String eventName;
	private String userIdentity;
	private String requestParameters;
	private String responseElements;
	private S3Details s3;

	public String getEventVersion() {
		return eventVersion;
	}

	public void setEventVersion(String eventVersion) {
		this.eventVersion = eventVersion;
	}

	public String getEventSource() {
		return eventSource;
	}

	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}

	public String getAwsRegion() {
		return awsRegion;
	}

	public void setAwsRegion(String awsRegion) {
		this.awsRegion = awsRegion;
	}

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getUserIdentity() {
		return userIdentity;
	}

	public void setUserIdentity(String userIdentity) {
		this.userIdentity = userIdentity;
	}

	public String getRequestParameters() {
		return requestParameters;
	}

	public void setRequestParameters(String requestParameters) {
		this.requestParameters = requestParameters;
	}

	public String getResponseElements() {
		return responseElements;
	}

	public void setResponseElements(String responseElements) {
		this.responseElements = responseElements;
	}

	public S3Details getS3() {
		return s3;
	}

	public void setS3(S3Details s3) {
		this.s3 = s3;
	}

	@Override
	public String toString() {
		return "SNSRecords [eventVersion=" + eventVersion + ", eventSource=" + eventSource + ", awsRegion=" + awsRegion
				+ ", eventTime=" + eventTime + ", eventName=" + eventName + ", userIdentity=" + userIdentity
				+ ", requestParameters=" + requestParameters + ", responseElements=" + responseElements + ", s3=" + s3
				+ "]";
	}
}
