package com.healogics.encode.dto;

import java.util.List;

public class ProviderListRes {
	private String responseCode;
	private String responseMessage;
	private List<ProviderObj> providerList;

	public List<ProviderObj> getProviderList() {
		return providerList;
	}
	public void setProviderList(List<ProviderObj> providerList) {
		this.providerList = providerList;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "ProviderListRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", providerList="
				+ providerList + "]";
	}

}
