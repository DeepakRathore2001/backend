package com.healogics.encode.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class MonthlyChargeSummaryReportRes extends APIResponse {

	private List<MonthlyChargeSummaryObj> codesList;

	private Integer total;

	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}

	public List<MonthlyChargeSummaryObj> getCodesList() {
		return codesList;
	}

	public void setCodesList(List<MonthlyChargeSummaryObj> codesList) {
		this.codesList = codesList;
	}

	@Override
	public String toString() {
		return "MonthlyChargeSummaryReportRes [codesList=" + codesList
				+ ", total=" + total + "]";
	}

}
