package com.healogics.encode.dto;

import java.util.List;

public class Weakness {

	private String coderCPTCode;
	private String providerCPTCode;
	private String weaknessNote;
	private List<String> weaknessReason;

	public String getCoderCPTCode() {
		return coderCPTCode;
	}

	public void setCoderCPTCode(String coderCPTCode) {
		this.coderCPTCode = coderCPTCode;
	}

	public String getProviderCPTCode() {
		return providerCPTCode;
	}

	public void setProviderCPTCode(String providerCPTCode) {
		this.providerCPTCode = providerCPTCode;
	}

	public String getWeaknessNote() {
		return weaknessNote;
	}

	public void setWeaknessNote(String weaknessNote) {
		this.weaknessNote = weaknessNote;
	}

	public List<String> getWeaknessReason() {
		return weaknessReason;
	}

	public void setWeaknessReason(List<String> weaknessReason) {
		this.weaknessReason = weaknessReason;
	}

	@Override
	public String toString() {
		return "Weakness [coderCPTCode=" + coderCPTCode + ", providerCPTCode=" + providerCPTCode + ", weaknessNote="
				+ weaknessNote + ", weaknessReason=" + weaknessReason + "]";
	}

}
