package com.healogics.encode.dto;

public class OAuthReq {
	private String authCode;
	private String encryptedUserId;
	

	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public String getEncryptedUserId() {
		return encryptedUserId;
	}
	public void setEncryptedUserId(String encryptedUserId) {
		this.encryptedUserId = encryptedUserId;
	}
	@Override
	public String toString() {
		return "OAuthReq [authCode=" + authCode + ", encryptedUserId=" + encryptedUserId + "]";
	}
}
