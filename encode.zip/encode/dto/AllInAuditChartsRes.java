package com.healogics.encode.dto;

import java.util.List;

public class AllInAuditChartsRes extends APIResponse {

	private List<AuditorCollapsibleSectionData> inAuditData;

	public List<AuditorCollapsibleSectionData> getInAuditData() {
		return inAuditData;
	}

	public void setInAuditData(List<AuditorCollapsibleSectionData> inAuditData) {
		this.inAuditData = inAuditData;
	}

	@Override
	public String toString() {
		return "AllInAuditChartsRes [inAuditData=" + inAuditData + "]";
	}

}
