package com.healogics.encode.dto;

public class FilterLogicReq {

	private int auditor;
	private int nurse;
	private String codingTeam;

	public int getAuditor() {
		return auditor;
	}

	public void setAuditor(int auditor) {
		this.auditor = auditor;
	}

	public int getNurse() {
		return nurse;
	}

	public void setNurse(int nurse) {
		this.nurse = nurse;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	@Override
	public String toString() {
		return "FilterLogicReq [auditor=" + auditor + ", nurse=" + nurse + ", codingTeam=" + codingTeam + "]";
	}

}
