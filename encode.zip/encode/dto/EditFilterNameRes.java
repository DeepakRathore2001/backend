package com.healogics.encode.dto;

public class EditFilterNameRes extends APIResponse{
	
	

}
