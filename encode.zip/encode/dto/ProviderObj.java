package com.healogics.encode.dto;

public class ProviderObj {

	private String id;
	private String providerName;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	@Override
	public String toString() {
		return "ProviderObj [id=" + id + ", providerName=" + providerName + "]";
	}

}
