package com.healogics.encode.dto;

public class DBDocumentListReq {

	private long patientId;
	private long visitId;
	private String documentType;
	private String documentId;

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	@Override
	public String toString() {
		return "DBDocumentListReq [patientId=" + patientId + ", visitId=" + visitId + ", documentType=" + documentType
				+ ", documentId=" + documentId + "]";
	}

}
