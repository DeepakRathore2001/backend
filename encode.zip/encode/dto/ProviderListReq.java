package com.healogics.encode.dto;

import java.util.List;

public class ProviderListReq {

	private String privateKey;
	private String facilityId;
	private String selectionName;
	private List<String> facilityIds;
	private Boolean isSelectedBbc;
	
	public Boolean getIsSelectedBbc() {
		return isSelectedBbc;
	}
	public void setIsSelectedBbc(Boolean isSelectedBbc) {
		this.isSelectedBbc = isSelectedBbc;
	}
	
	public List<String> getFacilityIds() {
		return facilityIds;
	}
	public void setFacilityIds(List<String> facilityIds) {
		this.facilityIds = facilityIds;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getSelectionName() {
		return selectionName;
	}
	public void setSelectionName(String selectionName) {
		this.selectionName = selectionName;
	}
	@Override
	public String toString() {
		return "ProviderListReq [privateKey=" + privateKey + ", facilityId=" + facilityId + ", selectionName="
				+ selectionName + ", facilityIds=" + facilityIds + ", isSelectedBbc=" + isSelectedBbc + "]";
	}

}
