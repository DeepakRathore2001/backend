package com.healogics.encode.dto;

import java.util.Date;

public class DrillDownMonthlyChargeSummaryObj {

	private int sequence;
	private String bluebookId;
	private Long visitId;
	private Date dateOfService;
	private String cptCode;
	private String providerName;

	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public Long getVisitId() {
		return visitId;
	}
	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}
	public Date getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}
	public String getCptCode() {
		return cptCode;
	}
	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}
	@Override
	public String toString() {
		return "DrillDownMonthlyChargeSummaryObj [sequence=" + sequence + ", bluebookId=" + bluebookId + ", visitId="
				+ visitId + ", dateOfService=" + dateOfService + ", cptCode=" + cptCode + ", providerName="
				+ providerName + "]";
	}

}
