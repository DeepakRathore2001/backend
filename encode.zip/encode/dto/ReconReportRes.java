package com.healogics.encode.dto;

import java.util.List;

public class ReconReportRes extends APIResponse {

	
	private List<ReconReportData> reportData;
	
	private int nextIndex;
	private int currentIndex;
	private Long totalCount;
	private double totalPage;
	private boolean isExhausted;

	
	public List<ReconReportData> getReportData() {
		return reportData;
	}

	public void setReportData(List<ReconReportData> reportData) {
		this.reportData = reportData;
	}

	public int getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}

	public int getCurrentIndex() {
		return currentIndex;
	}

	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public double getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}

	public boolean isExhausted() {
		return isExhausted;
	}

	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}

	
	@Override
	public String toString() {
		return "ReconReportRes [reportData=" + reportData + ", nextIndex=" + nextIndex + ", currentIndex="
				+ currentIndex + ", totalCount=" + totalCount + ", totalPage=" + totalPage + ", isExhausted="
				+ isExhausted + "]";
	}

}
