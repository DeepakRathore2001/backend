package com.healogics.encode.dto;

import java.sql.Date;
import java.sql.Timestamp;

public class CoderDashboardReq {

	private int index;
	private String taskType;
	private String username;
	private int order;
	private String sortBy;
	private String masterToken;
	private String userId;

	// Filter options
	private String filterOptions;
	private String filters;

	private String bbc;
	private String facilityName;
	private String ihealConfig;

	// Search Coder Dashboard
	private boolean isSearch;
	private String patientFirstName;
	private String patientLastName;
	private Timestamp dateOfService;
	private String visitId;
	
	private String status;
	private String medicalRecordNumber;
	private String insurance;
	private String startDOSDate;
	private String endDOSDate;
	private String ageStartDate;
	private String ageEndDate;
	private String visitIds;
	private String location;
	private boolean isfilterapplied;
	private String userFirstName;
	private String userLastName;
	private String chartLocation;
	private Timestamp dateOfBirth;
	private Timestamp interfaceDate;
	private long age;
	private long recordAge;
	private String providerName;
	private String providerId;
	private String encounterType;
	private String serviceLine;
	private String chartNotes;
	private Long patientId;
	private String patientName;
	private String startInterfaceDate;
	private String endInterfaceDate;
	private String excelColumns;
	private Timestamp startTime;
	private Timestamp endTime;
	private Integer coderId;
	private Boolean ifFlag;

	public Boolean getIfFlag() {
		return ifFlag;
	}

	public void setIfFlag(Boolean ifFlag) {
		this.ifFlag = ifFlag;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public Integer getCoderId() {
		return coderId;
	}

	public void setCoderId(Integer coderId) {
		this.coderId = coderId;
	}

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public String getStartInterfaceDate() {
		return startInterfaceDate;
	}

	public void setStartInterfaceDate(String startInterfaceDate) {
		this.startInterfaceDate = startInterfaceDate;
	}

	public String getEndInterfaceDate() {
		return endInterfaceDate;
	}

	public void setEndInterfaceDate(String endInterfaceDate) {
		this.endInterfaceDate = endInterfaceDate;
	}

	public Timestamp getInterfaceDate() {
		return interfaceDate;
	}

	public void setInterfaceDate(Timestamp interfaceDate) {
		this.interfaceDate = interfaceDate;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public long getRecordAge() {
		return recordAge;
	}

	public void setRecordAge(long recordAge) {
		this.recordAge = recordAge;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getChartNotes() {
		return chartNotes;
	}

	public void setChartNotes(String chartNotes) {
		this.chartNotes = chartNotes;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Timestamp getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Timestamp dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getChartLocation() {
		return chartLocation;
	}

	public void setChartLocation(String chartLocation) {
		this.chartLocation = chartLocation;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public boolean isIsfilterapplied() {
		return isfilterapplied;
	}

	public void setIsfilterapplied(boolean isfilterapplied) {
		this.isfilterapplied = isfilterapplied;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getVisitIds() {
		return visitIds;
	}

	public void setVisitIds(String visitIds) {
		this.visitIds = visitIds;
	}

	public String getAgeStartDate() {
		return ageStartDate;
	}

	public void setAgeStartDate(String ageStartDate) {
		this.ageStartDate = ageStartDate;
	}

	public String getAgeEndDate() {
		return ageEndDate;
	}

	public void setAgeEndDate(String ageEndDate) {
		this.ageEndDate = ageEndDate;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public boolean isSearch() {
		return isSearch;
	}

	public void setSearch(boolean isSearch) {
		this.isSearch = isSearch;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}


	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "CoderDashboardReq [index=" + index + ", taskType=" + taskType + ", username=" + username + ", order="
				+ order + ", sortBy=" + sortBy + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", filterOptions=" + filterOptions + ", filters=" + filters + ", bbc=" + bbc + ", facilityName="
				+ facilityName + ", ihealConfig=" + ihealConfig + ", isSearch=" + isSearch + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName + ", dateOfService=" + dateOfService
				+ ", visitId=" + visitId + ", status=" + status + ", medicalRecordNumber=" + medicalRecordNumber
				+ ", insurance=" + insurance + ", startDOSDate=" + startDOSDate + ", endDOSDate=" + endDOSDate
				+ ", ageStartDate=" + ageStartDate + ", ageEndDate=" + ageEndDate + ", visitIds=" + visitIds
				+ ", location=" + location + ", isfilterapplied=" + isfilterapplied + ", userFirstName=" + userFirstName
				+ ", userLastName=" + userLastName + ", chartLocation=" + chartLocation + ", dateOfBirth=" + dateOfBirth
				+ ", interfaceDate=" + interfaceDate + ", age=" + age + ", recordAge=" + recordAge + ", providerName="
				+ providerName + ", providerId=" + providerId + ", encounterType=" + encounterType + ", serviceLine="
				+ serviceLine + ", chartNotes=" + chartNotes + ", patientId=" + patientId + ", patientName="
				+ patientName + ", startInterfaceDate=" + startInterfaceDate + ", endInterfaceDate=" + endInterfaceDate
				+ ", excelColumns=" + excelColumns + ", startTime=" + startTime + ", endTime=" + endTime + ", coderId="
				+ coderId + ", ifFlag=" + ifFlag + "]";
	}
}
