package com.healogics.encode.dto;

public class AuthenticateIntanceByTokenReq {
	
	private int userId;
	private String privateKey;
	private String masterToken;
	private PlainTextObj plainTexts;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public PlainTextObj getPlainTexts() {
		return plainTexts;
	}
	public void setPlainTexts(PlainTextObj plainTexts) {
		this.plainTexts = plainTexts;
	}
	
	

}
