package com.healogics.encode.dto;

import java.util.List;

public class CMCDashboardRes {

	private String responseCode;
	private String responseMessage;
	private List<CMCData> cmcData;
	private int nextIndex;
	private int currentIndex;
	private Long totalCount;
	private double totalPage;
	private boolean isExhausted;
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<CMCData> getCmcData() {
		return cmcData;
	}
	public void setCmcData(List<CMCData> cmcData) {
		this.cmcData = cmcData;
	}
	public int getNextIndex() {
		return nextIndex;
	}
	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}
	public int getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	@Override
	public String toString() {
		return "CMCDashboardRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", cmcData="
				+ cmcData + ", nextIndex=" + nextIndex + ", currentIndex="
				+ currentIndex + ", totalCount=" + totalCount + ", totalPage="
				+ totalPage + ", isExhausted=" + isExhausted + "]";
	}

}
