package com.healogics.encode.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SNSMesage {
	@JsonProperty("Records")
	private List<SNSRecords> records;

	public List<SNSRecords> getRecords() {
		return records;
	}

	public void setRecords(List<SNSRecords> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return "SNSMesage [records=" + records + "]";
	}
}
