package com.healogics.encode.dto;

public class DBDocumentContentRes {

	private long patientId;
	private long visitId;
	private Document document;
	private String responseCode;
	private String responseMessage;

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	@Override
	public String toString() {
		return "DBDocumentContentRes [patientId=" + patientId + ", visitId=" + visitId + ", document=" + document
				+ ", responseCode=" + responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
