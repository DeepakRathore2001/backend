package com.healogics.encode.dto;

import java.sql.Timestamp;

public class DocumentNotificationReq {

	private String username;
	private String userID;
	private String masterToken;
	private String integrationKey;
	private String facilityID;
	private String bluebookID;
	private String facilityName;
	private String patientID;
	private String visitID;
	private Timestamp patientDOS;
	private String patientAccountNumber;
	private String documentType;
	private String documentID;
	private Timestamp eventDateTime;
	private String providerUserId;
	private String providerUsername;
	private String providerName;
	private String facilityType;
	private String dataType;
	private String eventType;
	private String documentEntityId;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getIntegrationKey() {
		return integrationKey;
	}
	public void setIntegrationKey(String integrationKey) {
		this.integrationKey = integrationKey;
	}
	public String getFacilityID() {
		return facilityID;
	}
	public void setFacilityID(String facilityID) {
		this.facilityID = facilityID;
	}
	public String getBluebookID() {
		return bluebookID;
	}
	public void setBluebookID(String bluebookID) {
		this.bluebookID = bluebookID;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getPatientID() {
		return patientID;
	}
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}
	public String getVisitID() {
		return visitID;
	}
	public void setVisitID(String visitID) {
		this.visitID = visitID;
	}
	public Timestamp getPatientDOS() {
		return patientDOS;
	}
	public void setPatientDOS(Timestamp patientDOS) {
		this.patientDOS = patientDOS;
	}
	public String getPatientAccountNumber() {
		return patientAccountNumber;
	}
	public void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentID() {
		return documentID;
	}
	public void setDocumentID(String documentID) {
		this.documentID = documentID;
	}
	public Timestamp getEventDateTime() {
		return eventDateTime;
	}
	public void setEventDateTime(Timestamp eventDateTime) {
		this.eventDateTime = eventDateTime;
	}
	public String getProviderUserId() {
		return providerUserId;
	}
	public void setProviderUserId(String providerUserId) {
		this.providerUserId = providerUserId;
	}
	public String getProviderUsername() {
		return providerUsername;
	}
	public void setProviderUsername(String providerUsername) {
		this.providerUsername = providerUsername;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getFacilityType() {
		return facilityType;
	}
	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(String documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	@Override
	public String toString() {
		return "DocumentNotificationReq [username=" + username + ", userID="
				+ userID + ", masterToken=" + masterToken + ", integrationKey="
				+ integrationKey + ", facilityID=" + facilityID
				+ ", bluebookID=" + bluebookID + ", facilityName="
				+ facilityName + ", patientID=" + patientID + ", visitID="
				+ visitID + ", patientDOS=" + patientDOS
				+ ", patientAccountNumber=" + patientAccountNumber
				+ ", documentType=" + documentType + ", documentID="
				+ documentID + ", eventDateTime=" + eventDateTime
				+ ", providerUserId=" + providerUserId + ", providerUsername="
				+ providerUsername + ", providerName=" + providerName
				+ ", facilityType=" + facilityType + ", dataType=" + dataType
				+ ", eventType=" + eventType + ", documentEntityId="
				+ documentEntityId + "]";
	}

}
