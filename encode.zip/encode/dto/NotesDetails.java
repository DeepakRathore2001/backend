package com.healogics.encode.dto;

import java.sql.Timestamp;

public class NotesDetails {
	private long visitId;
	private Long patientId;
	private String userRole;
	private String userName;
	private String userFullName;
	private String description;
	private Timestamp noteAddedTimestamp;
	private int noteId;
	private int creatorUserId;
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Timestamp getNoteAddedTimestamp() {
		return noteAddedTimestamp;
	}
	public void setNoteAddedTimestamp(Timestamp noteAddedTimestamp) {
		this.noteAddedTimestamp = noteAddedTimestamp;
	}
	
	public int getNoteId() {
		return noteId;
	}
	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}
	
	public int getCreatorUserId() {
		return creatorUserId;
	}
	public void setCreatorUserId(int creatorUserId) {
		this.creatorUserId = creatorUserId;
	}
	@Override
	public String toString() {
		return "CMCRetrieveNotes [visitId=" + visitId + ", patientId=" + patientId + ", userRole=" + userRole
				+ ", userName=" + userName + ", userFullName=" + userFullName + ", description=" + description
				+ ", noteAddedTimestamp=" + noteAddedTimestamp + ", noteId=" + noteId + ", creatorUserId="
				+ creatorUserId + "]";
	}
}
