package com.healogics.encode.dto;

public class IHealUserInboxMessageLoadRes {
	private String errorCode;
	private String errorMessage;
	private IHealInboxMessage message;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public IHealInboxMessage getMessage() {
		return message;
	}

	public void setMessage(IHealInboxMessage message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageLoadRes [errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", message="
				+ message + "]";
	}
}
