package com.healogics.encode.dto;

import java.util.List;

public class WeeklyIncompleteReportRes {

	private String responseCode;
	private String responseMessage;
	private List<WeeklyIncompleteReportData> dataList;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<WeeklyIncompleteReportData> getDataList() {
		return dataList;
	}

	public void setDataList(List<WeeklyIncompleteReportData> dataList) {
		this.dataList = dataList;
	}

	@Override
	public String toString() {
		return "WeeklyIncompleteReportRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", dataList=" + dataList + "]";
	}

}
