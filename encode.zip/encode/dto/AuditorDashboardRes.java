package com.healogics.encode.dto;

import java.util.List;

public class AuditorDashboardRes extends APIResponse {

	private List<Audit> auditorData;
	private int nextIndex;
	private int currentIndex;
	private Long totalCount;
	private double totalPage;
	private boolean isExhausted;

	public List<Audit> getAuditorData() {
		return auditorData;
	}

	public void setAuditorData(List<Audit> auditorData) {
		this.auditorData = auditorData;
	}

	public int getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}

	public int getCurrentIndex() {
		return currentIndex;
	}

	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public double getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}

	public boolean isExhausted() {
		return isExhausted;
	}

	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}

	@Override
	public String toString() {
		return "AuditorDashboardRes [auditorData=" + auditorData + ", nextIndex=" + nextIndex + ", currentIndex="
				+ currentIndex + ", totalCount=" + totalCount + ", totalPage=" + totalPage + ", isExhausted="
				+ isExhausted + "]";
	}

}
