package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class AuditorExcelData {

	private int filterId;
	private String filterName;
	private String codingTeam;
	private long visitId;
	private Long patientId;
	private String patientName;
	private int facilityId;
	private String bluebookId;
	private String facilityAlias;
	private Timestamp dateOfService;
	private String status;
	private String medicalRecordNumber;
	private String patientFirstName;
	private String patientLastName;
	private String insurance;
	private Date dateAdded;
	private Long assigneeUserId;
	private String assigneeUserName;
	private String assigneeUserFullName;

	public Long getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(Long assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserName() {
		return assigneeUserName;
	}

	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}

	public String getAssigneeUserFullName() {
		return assigneeUserFullName;
	}

	public void setAssigneeUserFullName(String assigneeUserFullName) {
		this.assigneeUserFullName = assigneeUserFullName;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public Date getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(Date dateAdded) {
		this.dateAdded = dateAdded;
	}

	@Override
	public String toString() {
		return "AuditorExcelData [filterId=" + filterId + ", filterName=" + filterName + ", codingTeam=" + codingTeam
				+ ", visitId=" + visitId + ", patientId=" + patientId + ", patientName=" + patientName + ", facilityId="
				+ facilityId + ", bluebookId=" + bluebookId + ", facilityAlias=" + facilityAlias + ", dateOfService="
				+ dateOfService + ", status=" + status + ", medicalRecordNumber=" + medicalRecordNumber
				+ ", patientFirstName=" + patientFirstName + ", patientLastName=" + patientLastName + ", insurance="
				+ insurance + ", dateAdded=" + dateAdded + ", assigneeUserId=" + assigneeUserId + ", assigneeUserName="
				+ assigneeUserName + ", assigneeUserFullName=" + assigneeUserFullName + "]";
	}

}
