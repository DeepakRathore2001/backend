package com.healogics.encode.dto;

public class IHealUserInboxMessageListGetReq {
	private String privateKey;
	private String masterToken;
	private Integer userId;
	private Integer messageType;
	private Integer messageList;
	private String startDate;
	private String endDate;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getMessageType() {
		return messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

	public Integer getMessageList() {
		return messageList;
	}

	public void setMessageList(Integer messageList) {
		this.messageList = messageList;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageListGetReq [privateKey=" + privateKey + ", masterToken=" + masterToken
				+ ", userId=" + userId + ", messageType=" + messageType + ", messageList=" + messageList
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
}
