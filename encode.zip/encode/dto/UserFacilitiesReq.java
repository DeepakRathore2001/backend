package com.healogics.encode.dto;

public class UserFacilitiesReq {

	private String masterToken;
	private String userId;

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "UserFacilitiesReq [masterToken=" + masterToken + ", userId=" + userId + "]";
	}

}
