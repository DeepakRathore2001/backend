package com.healogics.encode.dto;

import java.util.List;

public class SearchCoderDashboardRes {

	private String responseCode;
	private String responseMessage;
	private List<SearchCoderDashboardObj> coderData;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<SearchCoderDashboardObj> getCoderData() {
		return coderData;
	}
	public void setCoderData(List<SearchCoderDashboardObj> coderData) {
		this.coderData = coderData;
	}
	@Override
	public String toString() {
		return "SearchCoderDashboardRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", coderData="
				+ coderData + "]";
	}

}
