package com.healogics.encode.dto;

public class LockRecordRes {
	
	private String responseCode;
	private String responseMessage;
	private String userFullName;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	@Override
	public String toString() {
		return "LockRecordRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", userFullName=" + userFullName + "]";
	}
	
	

}
