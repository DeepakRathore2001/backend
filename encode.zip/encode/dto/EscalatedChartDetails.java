package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Lob;

public class EscalatedChartDetails {
	private long visitId;
	private Long patientId;
	private String patientName;
	private String facilityAlias;
	private Timestamp receivedDate;
	private String providerName;
	private String status;
	private Timestamp dateOfService;
	private String medicalRecordNumber;
	private String encounterType;
	private String assigneeUsername;
	private Long assigneeUserId;
	private String assigneeUserFullname;
	private Long accountNumber;
	private String gender;
	private String ihealConfig;
	private int facilityId;
	private String bluebookId;
	private String DashboardName;
	private String insurance;
	private String patientFirstName;
	private String patientLastName;
	private Timestamp patientDOB;
	private boolean recordOverDue;
	private long age;
	private long recordAge;
	private int isLocked;
	private String userFullName;

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public long getRecordAge() {
		return recordAge;
	}

	public void setRecordAge(long recordAge) {
		this.recordAge = recordAge;
	}

	public Timestamp getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Timestamp patientDOB) {
		this.patientDOB = patientDOB;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public boolean isRecordOverDue() {
		return recordOverDue;
	}

	public void setRecordOverDue(boolean recordOverDue) {
		this.recordOverDue = recordOverDue;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public String getDashboardName() {
		return DashboardName;
	}

	public void setDashboardName(String dashboardName) {
		DashboardName = dashboardName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getAssigneeUsername() {
		return assigneeUsername;
	}

	public void setAssigneeUsername(String assigneeUsername) {
		this.assigneeUsername = assigneeUsername;
	}

	public Long getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(Long assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserFullname() {
		return assigneeUserFullname;
	}

	public void setAssigneeUserFullname(String assigneeUserFullname) {
		this.assigneeUserFullname = assigneeUserFullname;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public Timestamp getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Timestamp receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "EscalatedChartDetails [visitId=" + visitId + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", facilityAlias=" + facilityAlias + ", receivedDate=" + receivedDate + ", providerName="
				+ providerName + ", status=" + status + ", dateOfService=" + dateOfService + ", medicalRecordNumber="
				+ medicalRecordNumber + ", encounterType=" + encounterType + ", assigneeUsername=" + assigneeUsername
				+ ", assigneeUserId=" + assigneeUserId + ", assigneeUserFullname=" + assigneeUserFullname
				+ ", accountNumber=" + accountNumber + ", gender=" + gender + ", ihealConfig=" + ihealConfig
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId + ", DashboardName=" + DashboardName
				+ ", insurance=" + insurance + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", patientDOB=" + patientDOB + ", recordOverDue=" + recordOverDue + ", age=" + age
				+ ", recordAge=" + recordAge + ", isLocked=" + isLocked + ", userFullName=" + userFullName + "]";
	}

}
