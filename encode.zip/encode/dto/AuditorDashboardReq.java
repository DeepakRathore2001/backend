package com.healogics.encode.dto;

import java.util.List;

public class AuditorDashboardReq {

	private String codingTeam;
	private List<Integer> filterId;
	private String filters;
	private String filterOptions;
	private int index;
	private int order;
	private String sortBy;
	private String dashboardName;
	private String excelColumns;
	private String filterAudience;
	private List<Integer> filterState;
	private List<String> Roles;

	public List<String> getRoles() {
		return Roles;
	}

	public void setRoles(List<String> roles) {
		Roles = roles;
	}

	public List<Integer> getFilterState() {
		return filterState;
	}

	public void setFilterState(List<Integer> filterState) {
		this.filterState = filterState;
	}

	public String getFilterAudience() {
		return filterAudience;
	}

	public void setFilterAudience(String filterAudience) {
		this.filterAudience = filterAudience;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public List<Integer> getFilterId() {
		return filterId;
	}

	public void setFilterId(List<Integer> filterId) {
		this.filterId = filterId;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getDashboardName() {
		return dashboardName;
	}

	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	@Override
	public String toString() {
		return "AuditorDashboardReq [codingTeam=" + codingTeam + ", filterId=" + filterId + ", filters=" + filters
				+ ", filterOptions=" + filterOptions + ", index=" + index + ", order=" + order + ", sortBy=" + sortBy
				+ ", dashboardName=" + dashboardName + ", excelColumns=" + excelColumns + ", filterAudience="
				+ filterAudience + ", filterState=" + filterState + ", Roles=" + Roles + "]";
	}

}
