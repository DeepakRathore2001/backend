package com.healogics.encode.dto;

import java.util.List;

public class SuperbillVarianceReportRes {

	private String responseCode;
	private String responseMessage;
	private List<SuperbillVarianceReportData> dataList;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<SuperbillVarianceReportData> getDataList() {
		return dataList;
	}
	public void setDataList(List<SuperbillVarianceReportData> dataList) {
		this.dataList = dataList;
	}
	@Override
	public String toString() {
		return "SuperbillVarianceReportRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", dataList=" + dataList + "]";
	}
	
	
}
