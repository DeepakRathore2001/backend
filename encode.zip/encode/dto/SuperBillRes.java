package com.healogics.encode.dto;

public class SuperBillRes extends APIResponse {

	private SuperBillObj superBillData;

	public SuperBillObj getSuperBillData() {
		return superBillData;
	}

	public void setSuperBillData(SuperBillObj superBillData) {
		this.superBillData = superBillData;
	}

	@Override
	public String toString() {
		return "SuperBillRes [superBillData=" + superBillData + "]";
	}

}
