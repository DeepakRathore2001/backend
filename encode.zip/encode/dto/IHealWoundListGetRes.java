package com.healogics.encode.dto;

import java.util.List;

public class IHealWoundListGetRes {

	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	private List<IHealErrorDetails> errors;
	private String requestId;
	private List<IHealWoundMeasurement> woundMeasurements;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}

	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}

	public List<IHealErrorDetails> getErrors() {
		return errors;
	}

	public void setErrors(List<IHealErrorDetails> errors) {
		this.errors = errors;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public List<IHealWoundMeasurement> getWoundMeasurements() {
		return woundMeasurements;
	}

	public void setWoundMeasurements(List<IHealWoundMeasurement> woundMeasurements) {
		this.woundMeasurements = woundMeasurements;
	}

	@Override
	public String toString() {
		return "WoundListRes [errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", warnings=" + warnings
				+ ", errors=" + errors + ", requestId=" + requestId + ", woundMeasurements=" + woundMeasurements + "]";
	}

}
