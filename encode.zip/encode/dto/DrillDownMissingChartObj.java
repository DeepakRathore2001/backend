package com.healogics.encode.dto;

import java.util.Date;

public class DrillDownMissingChartObj {

	private String bluebookId;
	private String facilityName;
	private String providerName;
	private Long visitId;
	private Date dateOfService;
	private String patientName;
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Long getVisitId() {
		return visitId;
	}
	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}
	public Date getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	@Override
	public String toString() {
		return "DrillDownMissingChartObj [bluebookId=" + bluebookId + ", facilityName=" + facilityName
				+ ", providerName=" + providerName + ", visitId=" + visitId + ", dateOfService=" + dateOfService
				+ ", patientName=" + patientName + ", status=" + status + "]";
	}

}
