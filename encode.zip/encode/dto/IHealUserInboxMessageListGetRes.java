package com.healogics.encode.dto;

import java.util.List;

public class IHealUserInboxMessageListGetRes {
	private String errorCode;
	private String errorMessage;
	private List<IHealInboxMessageMini> messages;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<IHealInboxMessageMini> getMessages() {
		return messages;
	}

	public void setMessages(List<IHealInboxMessageMini> messages) {
		this.messages = messages;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageListGetRes [errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", messages=" + messages + "]";
	}
}
