package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

public class IHealPatientLoadRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private IHealPatientLoadObj patient;
	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	public IHealPatientLoadObj getPatient() {
		return patient;
	}
	public void setPatient(IHealPatientLoadObj patient) {
		this.patient = patient;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealPatientLoadRes [patient=" + patient + ", errorCode="
				+ errorCode + ", errorMessage=" + errorMessage + ", warnings="
				+ warnings + "]";
	}

}
