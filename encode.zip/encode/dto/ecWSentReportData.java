package com.healogics.encode.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ecWSentReportData {

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date date;
	private Long totalSent;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Long getTotalSent() {
		return totalSent;
	}

	public void setTotalSent(Long totalSent) {
		this.totalSent = totalSent;
	}

	@Override
	public String toString() {
		return "ecWSentReportRes [date=" + date + ", totalSent=" + totalSent + "]";
	}
}
