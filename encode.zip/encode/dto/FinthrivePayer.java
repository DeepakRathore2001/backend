package com.healogics.encode.dto;

public class FinthrivePayer {
	private String name;
	private int stateAbbr;
	private String contractorId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStateAbbr() {
		return stateAbbr;
	}

	public void setStateAbbr(int stateAbbr) {
		this.stateAbbr = stateAbbr;
	}

	public String getContractorId() {
		return contractorId;
	}

	public void setContractorId(String contractorId) {
		this.contractorId = contractorId;
	}

	@Override
	public String toString() {
		return "FinthrivePayer [name=" + name + ", stateAbbr=" + stateAbbr
				+ ", contractorId=" + contractorId + "]";
	}
}
