package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

public class EncodeUserDetails {
	
	private Long userId;
	private String username;
	private String emailId;
	private String lastLoggedInTimestamp;
	private String userFullName;
	private List<String> encodeRole;
	private String ihealRole;
	private String encodeRoleDesc;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getLastLoggedInTimestamp() {
		return lastLoggedInTimestamp;
	}
	public void setLastLoggedInTimestamp(String lastLoggedInTimestamp) {
		this.lastLoggedInTimestamp = lastLoggedInTimestamp;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	
	public String getIhealRole() {
		return ihealRole;
	}
	public void setIhealRole(String ihealRole) {
		this.ihealRole = ihealRole;
	}
	public String getEncodeRoleDesc() {
		return encodeRoleDesc;
	}
	public void setEncodeRoleDesc(String encodeRoleDesc) {
		this.encodeRoleDesc = encodeRoleDesc;
	}
	
	public List<String> getEncodeRole() {
		return encodeRole;
	}
	public void setEncodeRole(List<String> encodeRole) {
		this.encodeRole = encodeRole;
	}
	@Override
	public String toString() {
		return "EncodeUserDetails [userId=" + userId + ", username=" + username + ", emailId=" + emailId
				+ ", lastLoggedInTimestamp=" + lastLoggedInTimestamp + ", userFullName=" + userFullName
				+ ", encodeRole=" + encodeRole + ", ihealRole=" + ihealRole + ", encodeRoleDesc=" + encodeRoleDesc
				+ "]";
	}
	
	

}
