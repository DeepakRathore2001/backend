package com.healogics.encode.dto;

import java.util.List;

public class FinthriveProcedures {
	private int id;
	private String fromDate;
	private String toDate;
	private String place;
	private String serviceDate;
	private String cpthcpcsCode;
	private List<Integer> diagnosisIds;
	private List<FinthriveModifers> modifiers;
	private int daysOrUnits;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getCpthcpcsCode() {
		return cpthcpcsCode;
	}

	public void setCpthcpcsCode(String cpthcpcsCode) {
		this.cpthcpcsCode = cpthcpcsCode;
	}

	public List<Integer> getDiagnosisIds() {
		return diagnosisIds;
	}

	public void setDiagnosisIds(List<Integer> diagnosisIds) {
		this.diagnosisIds = diagnosisIds;
	}

	public List<FinthriveModifers> getModifiers() {
		return modifiers;
	}

	public void setModifiers(List<FinthriveModifers> modifiers) {
		this.modifiers = modifiers;
	}

	public int getDaysOrUnits() {
		return daysOrUnits;
	}

	public void setDaysOrUnits(int daysOrUnits) {
		this.daysOrUnits = daysOrUnits;
	}

	@Override
	public String toString() {
		return "FinthriveProcedures [id=" + id + ", fromDate=" + fromDate + ", toDate=" + toDate + ", place=" + place
				+ ", serviceDate=" + serviceDate + ", cpthcpcsCode=" + cpthcpcsCode + ", diagnosisIds=" + diagnosisIds
				+ ", modifiers=" + modifiers + ", daysOrUnits=" + daysOrUnits + "]";
	}
}
