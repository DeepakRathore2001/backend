package com.healogics.encode.dto;

public class LoginUser {
 
	private String bluebookId;
	private Integer facilityId;
	private String deviceId;
	private String deviceIp;
	private String deviceType;
	private String emailId;
	private String employedBy;
	private String loginStatus;
	private String errorCode;
	private String errorMessage;
	private String userFullname;
	private String username;
	private String userId;
	private String serverIp;
	private String loginType;
	private String userRole;
	private String lastLoginTimestamp;
	private boolean isRestricted;

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceIp() {
		return deviceIp;
	}

	public void setDeviceIp(String deviceIp) {
		this.deviceIp = deviceIp;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmployedBy() {
		return employedBy;
	}

	public void setEmployedBy(String employedBy) {
		this.employedBy = employedBy;
	}

	public String getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getLastLoginTimestamp() {
		return lastLoginTimestamp;
	}

	public void setLastLoginTimestamp(String lastLoginTimestamp) {
		this.lastLoginTimestamp = lastLoginTimestamp;
	}

	public boolean isRestricted() {
		return isRestricted;
	}

	public void setRestricted(boolean isRestricted) {
		this.isRestricted = isRestricted;
	}

	@Override
	public String toString() {
		return "LoginUser [bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", deviceId=" + deviceId
				+ ", deviceIp=" + deviceIp + ", deviceType=" + deviceType + ", emailId=" + emailId + ", employedBy="
				+ employedBy + ", loginStatus=" + loginStatus + ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + ", userFullname=" + userFullname + ", username=" + username + ", userId=" + userId
				+ ", serverIp=" + serverIp + ", loginType=" + loginType + ", userRole=" + userRole
				+ ", lastLoginTimestamp=" + lastLoginTimestamp + ", isRestricted=" + isRestricted + "]";
	}
 
}
