package com.healogics.encode.dto;

import java.util.List;

public class ReleaseByFilterChartReq {
	
	private List<Integer> filterSelection;
	private List<Integer> chartSelection;
	private String userId;
	private String userName;
	private String userFullName;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public List<Integer> getFilterSelection() {
		return filterSelection;
	}

	public void setFilterSelection(List<Integer> filterSelection) {
		this.filterSelection = filterSelection;
	}

	public List<Integer> getChartSelection() {
		return chartSelection;
	}

	public void setChartSelection(List<Integer> chartSelection) {
		this.chartSelection = chartSelection;
	}

	@Override
	public String toString() {
		return "ReleaseByFilterChartReq [filterSelection=" + filterSelection + ", chartSelection=" + chartSelection
				+ ", userId=" + userId + ", userName=" + userName + ", userFullName=" + userFullName + "]";
	}
	
	

}
