package com.healogics.encode.dto;

import java.util.List;

public class AuthenticateIntanceByTokenRes {
	private String authenticateToken;
	private PlainTextObj cipherTexts;
	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	private List<NHWarningDetails> errors;

	public String getAuthenticateToken() {
		return authenticateToken;
	}

	public void setAuthenticateToken(String authenticateToken) {
		this.authenticateToken = authenticateToken;
	}

	public PlainTextObj getCipherTexts() {
		return cipherTexts;
	}

	public void setCipherTexts(PlainTextObj cipherTexts) {
		this.cipherTexts = cipherTexts;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}

	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}

	public List<NHWarningDetails> getErrors() {
		return errors;
	}

	public void setErrors(List<NHWarningDetails> errors) {
		this.errors = errors;
	}

	@Override
	public String toString() {
		return "AuthenticateIntanceByTokenRes [authenticateToken=" + authenticateToken + ", cipherTexts=" + cipherTexts
				+ ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", warnings=" + warnings + ", errors="
				+ errors + "]";
	}

}
