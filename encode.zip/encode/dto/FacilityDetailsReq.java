package com.healogics.encode.dto;


public class FacilityDetailsReq {

	private int index;
	private int order;
	private String sortBy;
	private String filterOptions;
	private String filters;
	private int campusCode;
	private String facilityBBC;
	private String facilityName;
	private String facilityId;
	
	private String facilityConfig;
	private String facilityType;
	private String placeOfService;
	
	public int getCampusCode() {
		return campusCode;
	}
	public void setCampusCode(int campusCode) {
		this.campusCode = campusCode;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getFilterOptions() {
		return filterOptions;
	}
	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}
	public String getFilters() {
		return filters;
	}
	public void setFilters(String filters) {
		this.filters = filters;
	}
	public String getFacilityConfig() {
		return facilityConfig;
	}
	public void setFacilityConfig(String facilityConfig) {
		this.facilityConfig = facilityConfig;
	}
	public String getFacilityType() {
		return facilityType;
	}
	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	
	public String getPlaceOfService() {
		return placeOfService;
	}
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}
	@Override
	public String toString() {
		return "FacilityDetailsReq [index=" + index + ", order=" + order + ", sortBy=" + sortBy + ", filterOptions="
				+ filterOptions + ", filters=" + filters + ", campusCode=" + campusCode + ", facilityBBC=" + facilityBBC
				+ ", facilityName=" + facilityName + ", facilityId=" + facilityId + ", facilityConfig=" + facilityConfig
				+ ", facilityType=" + facilityType + ", placeOfService=" + placeOfService + "]";
	}
	public String getFacilityBBC() {
		return facilityBBC;
	}
	public void setFacilityBBC(String facilityBBC) {
		this.facilityBBC = facilityBBC;
	}

	

}
