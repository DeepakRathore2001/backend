package com.healogics.encode.dto;

public class NotesDetailsRes extends APIResponse {

	public NotesDetails noteDetail;

	public NotesDetails getNoteDetail() {
		return noteDetail;
	}

	public void setNoteDetail(NotesDetails noteDetail) {
		this.noteDetail = noteDetail;
	}

	@Override
	public String toString() {
		return "NotesDetailsRes [noteDetail=" + noteDetail + "]";
	}
}
