package com.healogics.encode.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Chart {

	private String providerName;
	//private String patientAdmitDate;
	private Date patientAdmitDate;
	private String placeOfService;
	private String accidentOrIllness;
	private String accidentCategory;
	private Date accidentOrIllnessDate;
	private int timeDocInChart;
	private int timeUsedToCodeEMLevel;
	private String unbillableReason;

	private Weakness weakness;
	private Deficiency deficiency;
	private String nurseDeficiencyNote;
	private Escalation escalation;
	private List<ICD10Data> icdData;
	private List<CPTChartDetails> cptData;

	// SuperBill Obj
	private ProcedureProviderEMObj procedureProviderEM;
	private List<ProceduresObj> procedures;
	private List<CodeDiagnosisObj> codeDiagnosis;
	
	private String coc2Id;
	private String blueBookId;
	private boolean isDisparate;
	
	private List<SBVersionObj> sbVersionList;
	
	public List<SBVersionObj> getSbVersionList() {
		return sbVersionList;
	}

	public void setSbVersionList(List<SBVersionObj> sbVersionList) {
		this.sbVersionList = sbVersionList;
	}

	public boolean isDisparate() {
		return isDisparate;
	}

	public void setDisparate(boolean isDisparate) {
		this.isDisparate = isDisparate;
	}

	public String getCoc2Id() {
		return coc2Id;
	}

	public void setCoc2Id(String coc2Id) {
		this.coc2Id = coc2Id;
	}

	public String getBlueBookId() {
		return blueBookId;
	}

	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}

	public String getNurseDeficiencyNote() {
		return nurseDeficiencyNote;
	}

	public void setNurseDeficiencyNote(String nurseDeficiencyNote) {
		this.nurseDeficiencyNote = nurseDeficiencyNote;
	}

	public ProcedureProviderEMObj getProcedureProviderEM() {
		return procedureProviderEM;
	}

	public void setProcedureProviderEM(ProcedureProviderEMObj procedureProviderEM) {
		this.procedureProviderEM = procedureProviderEM;
	}

	public List<ProceduresObj> getProcedures() {
		return procedures;
	}

	public void setProcedures(List<ProceduresObj> procedures) {
		this.procedures = procedures;
	}

	public List<CodeDiagnosisObj> getCodeDiagnosis() {
		return codeDiagnosis;
	}

	public void setCodeDiagnosis(List<CodeDiagnosisObj> codeDiagnosis) {
		this.codeDiagnosis = codeDiagnosis;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	
	public Date getPatientAdmitDate() {
		return patientAdmitDate;
	}

	public void setPatientAdmitDate(Date patientAdmitDate) {
		this.patientAdmitDate = patientAdmitDate;
	}

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getAccidentOrIllness() {
		return accidentOrIllness;
	}

	public void setAccidentOrIllness(String accidentOrIllness) {
		this.accidentOrIllness = accidentOrIllness;
	}

	public String getAccidentCategory() {
		return accidentCategory;
	}

	public void setAccidentCategory(String accidentCategory) {
		this.accidentCategory = accidentCategory;
	}

	public int getTimeDocInChart() {
		return timeDocInChart;
	}

	public void setTimeDocInChart(int timeDocInChart) {
		this.timeDocInChart = timeDocInChart;
	}

	public int getTimeUsedToCodeEMLevel() {
		return timeUsedToCodeEMLevel;
	}

	public void setTimeUsedToCodeEMLevel(int timeUsedToCodeEMLevel) {
		this.timeUsedToCodeEMLevel = timeUsedToCodeEMLevel;
	}

	public String getUnbillableReason() {
		return unbillableReason;
	}

	public void setUnbillableReason(String unbillableReason) {
		this.unbillableReason = unbillableReason;
	}

	public List<ICD10Data> getIcdData() {
		return icdData;
	}

	public void setIcdData(List<ICD10Data> icdData) {
		this.icdData = icdData;
	}

	public List<CPTChartDetails> getCptData() {
		return cptData;
	}

	public void setCptData(List<CPTChartDetails> cptData) {
		this.cptData = cptData;
	}

	public Weakness getWeakness() {
		return weakness;
	}

	public void setWeakness(Weakness weakness) {
		this.weakness = weakness;
	}

	public Deficiency getDeficiency() {
		return deficiency;
	}

	public void setDeficiency(Deficiency deficiency) {
		this.deficiency = deficiency;
	}

	public Escalation getEscalation() {
		return escalation;
	}

	public void setEscalation(Escalation escalation) {
		this.escalation = escalation;
	}

	public Date getAccidentOrIllnessDate() {
		return accidentOrIllnessDate;
	}

	public void setAccidentOrIllnessDate(Date accidentOrIllnessDate) {
		this.accidentOrIllnessDate = accidentOrIllnessDate;
	}

	@Override
	public String toString() {
		return "Chart [providerName=" + providerName + ", patientAdmitDate=" + patientAdmitDate + ", placeOfService="
				+ placeOfService + ", accidentOrIllness=" + accidentOrIllness + ", accidentCategory=" + accidentCategory
				+ ", accidentOrIllnessDate=" + accidentOrIllnessDate + ", timeDocInChart=" + timeDocInChart
				+ ", timeUsedToCodeEMLevel=" + timeUsedToCodeEMLevel + ", unbillableReason=" + unbillableReason
				+ ", weakness=" + weakness + ", deficiency=" + deficiency + ", nurseDeficiencyNote="
				+ nurseDeficiencyNote + ", escalation=" + escalation + ", icdData=" + icdData + ", cptData=" + cptData
				+ ", procedureProviderEM=" + procedureProviderEM + ", procedures=" + procedures + ", codeDiagnosis="
				+ codeDiagnosis + ", coc2Id=" + coc2Id + ", blueBookId=" + blueBookId + ", isDisparate=" + isDisparate
				+ ", sbVersionList=" + sbVersionList + "]";
	}

}
