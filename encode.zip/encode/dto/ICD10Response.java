package com.healogics.encode.dto;

import java.util.List;

public class ICD10Response extends APIResponse {
	private List<ICD10Data> icd10Codes;
	private int totalCount;
	private boolean isExhausted;
	
	public boolean isExhausted() {
		return isExhausted;
	}

	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}

	public List<ICD10Data> getIcd10Codes() {
		return icd10Codes;
	}

	public void setIcd10Codes(List<ICD10Data> icd10Codes) {
		this.icd10Codes = icd10Codes;
	}
	
	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	@Override
	public String toString() {
		return "ICD10Response [icd10Codes=" + icd10Codes + ", totalCount=" + totalCount + ", isExhausted=" + isExhausted
				+ "]";
	}
}
