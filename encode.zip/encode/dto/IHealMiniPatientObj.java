package com.healogics.encode.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealMiniPatientObj implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("patientId")
	private int patientId;

	@JsonProperty("patientFirstName")
	private String patientFirstName;

	@JsonProperty("patientLastName")
	private String patientLastName;

	@JsonProperty("patientMiddleName")
	private String patientMiddleName;

	@JsonProperty("patientNumber")
	private String patientNumber;

	@JsonProperty("patientDOB")
	private String patientDOB;

	@JsonProperty("patientSex")
	private String patientSex;

	@JsonProperty("weeksInTreatment")
	private int weeksInTreatment;

	@JsonProperty("admissionDate")
	private String admissionDate;

	@JsonProperty("preregistrationDate")
	private String preRegistrationDate;

	@JsonProperty("locationId")
	private int locationId;

	@JsonProperty("locationDescription")
	private String locationDescription;

	@JsonProperty("serviceLineId")
	private int serviceLineId;

	@JsonProperty("serviceLineDescription")
	private String serviceLineDescription;

	@JsonProperty("dischargeDate")
	private String dischargeDate;

	@JsonProperty("dischargeStatusCode")
	private int dischargeStatusCode;

	@JsonProperty("dischargeStatusDescription")
	private String dischargeStatusDescription;

	public String getPatientMiddleName() {
		return patientMiddleName;
	}

	public void setPatientMiddleName(String patientMiddleName) {
		this.patientMiddleName = patientMiddleName;
	}

	public String getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getPreRegistrationDate() {
		return preRegistrationDate;
	}

	public void setPreRegistrationDate(String preRegistrationDate) {
		this.preRegistrationDate = preRegistrationDate;
	}

	public String getLocationDescription() {
		return locationDescription;
	}

	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

	public String getServiceLineDescription() {
		return serviceLineDescription;
	}

	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}

	public String getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public String getDischargeStatusDescription() {
		return dischargeStatusDescription;
	}

	public void setDischargeStatusDescription(
			String dischargeStatusDescription) {
		this.dischargeStatusDescription = dischargeStatusDescription;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientNumber() {
		return patientNumber;
	}

	public void setPatientNumber(String patientNumber) {
		this.patientNumber = patientNumber;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientSex() {
		return patientSex;
	}

	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public int getWeeksInTreatment() {
		return weeksInTreatment;
	}

	public void setWeeksInTreatment(int weeksInTreatment) {
		this.weeksInTreatment = weeksInTreatment;
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public int getServiceLineId() {
		return serviceLineId;
	}

	public void setServiceLineId(int serviceLineId) {
		this.serviceLineId = serviceLineId;
	}

	public int getDischargeStatusCode() {
		return dischargeStatusCode;
	}

	public void setDischargeStatusCode(int dischargeStatusCode) {
		this.dischargeStatusCode = dischargeStatusCode;
	}

	@Override
	public String toString() {
		return "IHealMiniPatientObj [patientId=" + patientId
				+ ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName
				+ ", patientMiddleName=" + patientMiddleName
				+ ", patientNumber=" + patientNumber + ", patientDOB="
				+ patientDOB + ", patientSex=" + patientSex
				+ ", weeksInTreatment=" + weeksInTreatment + ", admissionDate="
				+ admissionDate + ", preRegistrationDate=" + preRegistrationDate
				+ ", locationId=" + locationId + ", locationDescription="
				+ locationDescription + ", serviceLineId=" + serviceLineId
				+ ", serviceLineDescription=" + serviceLineDescription
				+ ", dischargeDate=" + dischargeDate + ", dischargeStatusCode="
				+ dischargeStatusCode + ", dischargeStatusDescription="
				+ dischargeStatusDescription + "]";
	}

}
