package com.healogics.encode.dto;

import java.sql.Timestamp;

public class IHealInboxMessageStatus {
	private Long messageId;
	private String inboxLoadAPIStatus;
	private String inboxLoadAPIErrorCode;
	private String inboxLoadAPIErrorMessage;
	private Timestamp inboxLoadAPIReqSentTimestamp;
	private Timestamp inboxLoadAPIResReceivedTimestamp;

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getInboxLoadAPIStatus() {
		return inboxLoadAPIStatus;
	}

	public void setInboxLoadAPIStatus(String inboxLoadAPIStatus) {
		this.inboxLoadAPIStatus = inboxLoadAPIStatus;
	}

	public String getInboxLoadAPIErrorCode() {
		return inboxLoadAPIErrorCode;
	}

	public void setInboxLoadAPIErrorCode(String inboxLoadAPIErrorCode) {
		this.inboxLoadAPIErrorCode = inboxLoadAPIErrorCode;
	}

	public String getInboxLoadAPIErrorMessage() {
		return inboxLoadAPIErrorMessage;
	}

	public void setInboxLoadAPIErrorMessage(String inboxLoadAPIErrorMessage) {
		this.inboxLoadAPIErrorMessage = inboxLoadAPIErrorMessage;
	}

	public Timestamp getInboxLoadAPIReqSentTimestamp() {
		return inboxLoadAPIReqSentTimestamp;
	}

	public void setInboxLoadAPIReqSentTimestamp(Timestamp inboxLoadAPIReqSentTimestamp) {
		this.inboxLoadAPIReqSentTimestamp = inboxLoadAPIReqSentTimestamp;
	}

	public Timestamp getInboxLoadAPIResReceivedTimestamp() {
		return inboxLoadAPIResReceivedTimestamp;
	}

	public void setInboxLoadAPIResReceivedTimestamp(Timestamp inboxLoadAPIResReceivedTimestamp) {
		this.inboxLoadAPIResReceivedTimestamp = inboxLoadAPIResReceivedTimestamp;
	}

	@Override
	public String toString() {
		return "IHealInboxMessageStatus [messageId=" + messageId + ", inboxLoadAPIStatus=" + inboxLoadAPIStatus
				+ ", inboxLoadAPIErrorCode=" + inboxLoadAPIErrorCode + ", inboxLoadAPIErrorMessage="
				+ inboxLoadAPIErrorMessage + ", inboxLoadAPIReqSentTimestamp=" + inboxLoadAPIReqSentTimestamp
				+ ", inboxLoadAPIResReceivedTimestamp=" + inboxLoadAPIResReceivedTimestamp + "]";
	}
}
