package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcedureFacilityEMObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("code")
	private String code;

	@JsonProperty("description")
	private String description;

	@JsonProperty("codeSystem")
	private String codeSystem;

	@JsonProperty("procedureFacility")
	private Boolean procedureFacility;

	@JsonProperty("codeFacility")
	private String codeFacility;

	@JsonProperty("descriptionFacility")
	private String descriptionFacility;

	@JsonProperty("feeFacility")
	private Integer feeFacility;

	@JsonProperty("procedureProvider")
	private Boolean procedureProvider;

	@JsonProperty("codeProvider")
	private String codeProvider;

	@JsonProperty("descriptionProvider")
	private String descriptionProvider;

	@JsonProperty("feeProvider")
	private Integer feeProvider;

	@JsonProperty("feeManagement")
	private Integer feeManagement;

	@JsonProperty("codeDiagnosis")
	private List<CodeDiagnosisObj> codeDiagnosis;

	@JsonProperty("quantity")
	private Integer quantity;

	@JsonProperty("productSize")
	private Integer productSize;

	@JsonProperty("productWaste")
	private Integer productWaste;

	@JsonProperty("sort")
	private Integer sort;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCodeSystem() {
		return codeSystem;
	}

	public void setCodeSystem(String codeSystem) {
		this.codeSystem = codeSystem;
	}

	public Boolean getProcedureFacility() {
		return procedureFacility;
	}

	public void setProcedureFacility(Boolean procedureFacility) {
		this.procedureFacility = procedureFacility;
	}

	public String getCodeFacility() {
		return codeFacility;
	}

	public void setCodeFacility(String codeFacility) {
		this.codeFacility = codeFacility;
	}

	public String getDescriptionFacility() {
		return descriptionFacility;
	}

	public void setDescriptionFacility(String descriptionFacility) {
		this.descriptionFacility = descriptionFacility;
	}

	public Integer getFeeFacility() {
		return feeFacility;
	}

	public void setFeeFacility(Integer feeFacility) {
		this.feeFacility = feeFacility;
	}

	public Boolean getProcedureProvider() {
		return procedureProvider;
	}

	public void setProcedureProvider(Boolean procedureProvider) {
		this.procedureProvider = procedureProvider;
	}

	public String getCodeProvider() {
		return codeProvider;
	}

	public void setCodeProvider(String codeProvider) {
		this.codeProvider = codeProvider;
	}

	public String getDescriptionProvider() {
		return descriptionProvider;
	}

	public void setDescriptionProvider(String descriptionProvider) {
		this.descriptionProvider = descriptionProvider;
	}

	public Integer getFeeProvider() {
		return feeProvider;
	}

	public void setFeeProvider(Integer feeProvider) {
		this.feeProvider = feeProvider;
	}

	public Integer getFeeManagement() {
		return feeManagement;
	}

	public void setFeeManagement(Integer feeManagement) {
		this.feeManagement = feeManagement;
	}

	public List<CodeDiagnosisObj> getCodeDiagnosis() {
		return codeDiagnosis;
	}

	public void setCodeDiagnosis(List<CodeDiagnosisObj> codeDiagnosis) {
		this.codeDiagnosis = codeDiagnosis;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getProductSize() {
		return productSize;
	}

	public void setProductSize(Integer productSize) {
		this.productSize = productSize;
	}

	public Integer getProductWaste() {
		return productWaste;
	}

	public void setProductWaste(Integer productWaste) {
		this.productWaste = productWaste;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	@Override
	public String toString() {
		return "ProceduresObj [code=" + code + ", description=" + description
				+ ", codeSystem=" + codeSystem + ", procedureFacility="
				+ procedureFacility + ", codeFacility=" + codeFacility
				+ ", descriptionFacility=" + descriptionFacility
				+ ", feeFacility=" + feeFacility + ", procedureProvider="
				+ procedureProvider + ", codeProvider=" + codeProvider
				+ ", descriptionProvider=" + descriptionProvider
				+ ", feeProvider=" + feeProvider + ", feeManagement="
				+ feeManagement + ", codeDiagnosis=" + codeDiagnosis
				+ ", quantity=" + quantity + ", productSize=" + productSize
				+ ", productWaste=" + productWaste + ", sort=" + sort + "]";
	}

}
