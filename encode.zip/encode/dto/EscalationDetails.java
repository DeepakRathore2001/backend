package com.healogics.encode.dto;

import java.sql.Timestamp;

public class EscalationDetails {
	private String createdUserName;
	private String createdUserFullName;
	private String description;
	private Timestamp addedTimestamp;
	private int createdUserId;
	private int escalationType;
	
	public int getEscalationType() {
		return escalationType;
	}
	public void setEscalationType(int escalationType) {
		this.escalationType = escalationType;
	}
	public String getCreatedUserName() {
		return createdUserName;
	}
	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}
	public String getCreatedUserFullName() {
		return createdUserFullName;
	}
	public void setCreatedUserFullName(String createdUserFullName) {
		this.createdUserFullName = createdUserFullName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Timestamp getAddedTimestamp() {
		return addedTimestamp;
	}
	public void setAddedTimestamp(Timestamp addedTimestamp) {
		this.addedTimestamp = addedTimestamp;
	}
	public int getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(int createdUserId) {
		this.createdUserId = createdUserId;
	}

	@Override
	public String toString() {
		return "EscalationDetails [createdUserName=" + createdUserName + ", createdUserFullName=" + createdUserFullName
				+ ", description=" + description + ", addedTimestamp=" + addedTimestamp + ", createdUserId="
				+ createdUserId + ", escalationType=" + escalationType + "]";
	}
}
