package com.healogics.encode.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DashboardReq {

	private int index;
	private String taskType;
	private String username;
	private int order;
	private String sortBy;
	private String masterToken;
	private String userId;

	// Filter options
	private String filterOptions;
	private String filters;

	private String startDOSDate;
	private String endDOSDate;
	private String startInterfaceDate;
	private String endInterfaceDate;
	private String ageStartDate;
	private String ageEndDate;

	private String bbc;
	private String patientName;
	private String facilityName;
	private String providerName;
	//private String facilityType;
	private String ihealConfig;
	private String medicalRecordNumber;
	private String encounterType;
	private String assignedTo;
	private String status;
	private String cmcNotes;
	private String serviceLine;

	private String dashboardName;
	private String excelColumns;

	private String lastUpdatedByUsername;
	private String lastUpdatedByUserId;
	private String lastUpdatedByUserFullName;
	private long visitId;
	private String visitIds;
	private int isLocked;
	private Long patientId;
	private Boolean isFromAuditor;
	
	// role assignments
	private String assigneeFullname;
	private String encodeRole;
	private String businessRole;
	private String email;
	private String assigneeUsername;
	
	private String patientFirstName;
	private String patientLastName;
	private String insurance;
	
	private Timestamp dateOfService;
	private String location;
	private boolean isfilterapplied;
	private String userFirstName;
	private String userLastName;
	private String chartLocation;
	private Timestamp dateOfBirth;
	private Timestamp interfaceDate;
	private long age;
	private long recordAge;
	private String providerId;
	private String chartNotes;
	
	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public boolean isIsfilterapplied() {
		return isfilterapplied;
	}

	public void setIsfilterapplied(boolean isfilterapplied) {
		this.isfilterapplied = isfilterapplied;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getChartLocation() {
		return chartLocation;
	}

	public void setChartLocation(String chartLocation) {
		this.chartLocation = chartLocation;
	}

	public Timestamp getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Timestamp dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Timestamp getInterfaceDate() {
		return interfaceDate;
	}

	public void setInterfaceDate(Timestamp interfaceDate) {
		this.interfaceDate = interfaceDate;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public long getRecordAge() {
		return recordAge;
	}

	public void setRecordAge(long recordAge) {
		this.recordAge = recordAge;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getChartNotes() {
		return chartNotes;
	}

	public void setChartNotes(String chartNotes) {
		this.chartNotes = chartNotes;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public Boolean getIsFromAuditor() {
		return isFromAuditor;
	}

	public void setIsFromAuditor(Boolean isFromAuditor) {
		this.isFromAuditor = isFromAuditor;
	}

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public String getDashboardName() {
		return dashboardName;
	}

	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	public String getStartInterfaceDate() {
		return startInterfaceDate;
	}

	public void setStartInterfaceDate(String startInterfaceDate) {
		this.startInterfaceDate = startInterfaceDate;
	}

	public String getEndInterfaceDate() {
		return endInterfaceDate;
	}

	public void setEndInterfaceDate(String endInterfaceDate) {
		this.endInterfaceDate = endInterfaceDate;
	}

	public String getAgeStartDate() {
		return ageStartDate;
	}

	public void setAgeStartDate(String ageStartDate) {
		this.ageStartDate = ageStartDate;
	}

	public String getAgeEndDate() {
		return ageEndDate;
	}

	public void setAgeEndDate(String ageEndDate) {
		this.ageEndDate = ageEndDate;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCmcNotes() {
		return cmcNotes;
	}

	public void setCmcNotes(String cmcNotes) {
		this.cmcNotes = cmcNotes;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getLastUpdatedByUsername() {
		return lastUpdatedByUsername;
	}

	public void setLastUpdatedByUsername(String lastUpdatedByUsername) {
		this.lastUpdatedByUsername = lastUpdatedByUsername;
	}

	public String getLastUpdatedByUserId() {
		return lastUpdatedByUserId;
	}

	public void setLastUpdatedByUserId(String lastUpdatedByUserId) {
		this.lastUpdatedByUserId = lastUpdatedByUserId;
	}

	public String getLastUpdatedByUserFullName() {
		return lastUpdatedByUserFullName;
	}

	public void setLastUpdatedByUserFullName(String lastUpdatedByUserFullName) {
		this.lastUpdatedByUserFullName = lastUpdatedByUserFullName;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	


	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	

	public String getVisitIds() {
		return visitIds;
	}

	public void setVisitIds(String visitIds) {
		this.visitIds = visitIds;
	}

	
	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	
	

	public String getAssigneeFullname() {
		return assigneeFullname;
	}

	public void setAssigneeFullname(String assigneeFullname) {
		this.assigneeFullname = assigneeFullname;
	}

	

	public String getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(String encodeRole) {
		this.encodeRole = encodeRole;
	}

	public String getBusinessRole() {
		return businessRole;
	}

	public void setBusinessRole(String businessRole) {
		this.businessRole = businessRole;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAssigneeUsername() {
		return assigneeUsername;
	}

	public void setAssigneeUsername(String assigneeUsername) {
		this.assigneeUsername = assigneeUsername;
	}
	

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "DashboardReq [index=" + index + ", taskType=" + taskType + ", username=" + username + ", order=" + order
				+ ", sortBy=" + sortBy + ", masterToken=" + masterToken + ", userId=" + userId + ", filterOptions="
				+ filterOptions + ", filters=" + filters + ", startDOSDate=" + startDOSDate + ", endDOSDate="
				+ endDOSDate + ", startInterfaceDate=" + startInterfaceDate + ", endInterfaceDate=" + endInterfaceDate
				+ ", ageStartDate=" + ageStartDate + ", ageEndDate=" + ageEndDate + ", bbc=" + bbc + ", patientName="
				+ patientName + ", facilityName=" + facilityName + ", providerName=" + providerName + ", ihealConfig="
				+ ihealConfig + ", medicalRecordNumber=" + medicalRecordNumber + ", encounterType=" + encounterType
				+ ", assignedTo=" + assignedTo + ", status=" + status + ", cmcNotes=" + cmcNotes + ", serviceLine="
				+ serviceLine + ", dashboardName=" + dashboardName + ", excelColumns=" + excelColumns
				+ ", lastUpdatedByUsername=" + lastUpdatedByUsername + ", lastUpdatedByUserId=" + lastUpdatedByUserId
				+ ", lastUpdatedByUserFullName=" + lastUpdatedByUserFullName + ", visitId=" + visitId + ", visitIds="
				+ visitIds + ", isLocked=" + isLocked + ", patientId=" + patientId + ", isFromAuditor=" + isFromAuditor
				+ ", assigneeFullname=" + assigneeFullname + ", encodeRole=" + encodeRole + ", businessRole="
				+ businessRole + ", email=" + email + ", assigneeUsername=" + assigneeUsername + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName + ", insurance=" + insurance
				+ ", dateOfService=" + dateOfService + ", location=" + location + ", isfilterapplied=" + isfilterapplied
				+ ", userFirstName=" + userFirstName + ", userLastName=" + userLastName + ", chartLocation="
				+ chartLocation + ", dateOfBirth=" + dateOfBirth + ", interfaceDate=" + interfaceDate + ", age=" + age
				+ ", recordAge=" + recordAge + ", providerId=" + providerId + ", chartNotes=" + chartNotes + "]";
	}

}
