package com.healogics.encode.dto;

public class SuperBillReq {

	private String visitId;
	private String patientId;
	private String versionId;

	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	@Override
	public String toString() {
		return "SuperBillReq [visitId=" + visitId + ", patientId=" + patientId + ", versionId=" + versionId + "]";
	}

}
