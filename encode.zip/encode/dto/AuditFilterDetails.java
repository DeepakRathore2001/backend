package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuditFilterDetails {
	private int filterId;
	private String filterName;
	private List<String> codingTeam;
	private String coders;
	private String codersFullName;
	private String codersId;
	private String providersId;
	private String providers;
	private String facilities;
	private String facilitiesId;
	private String cptCodes;
	private String icdCodes;
	private String modifiers;
	private String units;
	private String insurance;
	private int downcoded;
	private int percentage;
	private int count;
	private int active;
	private String userFullName;
	private String username;
	private String createdUserFullName;
	private String createdUserName;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;
	private String lastUpdatedUser;
	private String lastUpdatedUsername;
	private int nurseFilter;
	private String filterAudience;
	private String cptName;
	private String modifierName;
	private List<CPTObj> cptData;
	private int isFilterNameChanged;

	public int getIsFilterNameChanged() {
		return isFilterNameChanged;
	}

	public void setIsFilterNameChanged(int isFilterNameChanged) {
		this.isFilterNameChanged = isFilterNameChanged;
	}

	public List<CPTObj> getCptData() {
		return cptData;
	}

	public void setCptData(List<CPTObj> cptData) {
		this.cptData = cptData;
	}

	public String getCptName() {
		return cptName;
	}

	public void setCptName(String cptName) {
		this.cptName = cptName;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public String getFilterAudience() {
		return filterAudience;
	}

	public void setFilterAudience(String filterAudience) {
		this.filterAudience = filterAudience;
	}

	public int getNurseFilter() {
		return nurseFilter;
	}

	public void setNurseFilter(int nurseFilter) {
		this.nurseFilter = nurseFilter;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getCreatedUserFullName() {
		return createdUserFullName;
	}

	public void setCreatedUserFullName(String createdUserFullName) {
		this.createdUserFullName = createdUserFullName;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public List<String> getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(List<String> codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getCoders() {
		return coders;
	}

	public void setCoders(String coders) {
		this.coders = coders;
	}

	public String getProviders() {
		return providers;
	}

	public void setProviders(String providers) {
		this.providers = providers;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public String getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(String cptCodes) {
		this.cptCodes = cptCodes;
	}

	public String getIcdCodes() {
		return icdCodes;
	}

	public void setIcdCodes(String icdCodes) {
		this.icdCodes = icdCodes;
	}

	public String getModifiers() {
		return modifiers;
	}

	public void setModifiers(String modifiers) {
		this.modifiers = modifiers;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public int getDowncoded() {
		return downcoded;
	}

	public void setDowncoded(int downcoded) {
		this.downcoded = downcoded;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCodersId() {
		return codersId;
	}

	public void setCodersId(String codersId) {
		this.codersId = codersId;
	}

	public String getProvidersId() {
		return providersId;
	}

	public void setProvidersId(String providersId) {
		this.providersId = providersId;
	}

	public String getFacilitiesId() {
		return facilitiesId;
	}

	public void setFacilitiesId(String facilitiesId) {
		this.facilitiesId = facilitiesId;
	}

	public String getCodersFullName() {
		return codersFullName;
	}

	public void setCodersFullName(String codersFullName) {
		this.codersFullName = codersFullName;
	}

	@Override
	public String toString() {
		return "AuditFilterDetails [filterId=" + filterId + ", filterName=" + filterName + ", codingTeam=" + codingTeam
				+ ", coders=" + coders + ", codersFullName=" + codersFullName + ", codersId=" + codersId
				+ ", providersId=" + providersId + ", providers=" + providers + ", facilities=" + facilities
				+ ", facilitiesId=" + facilitiesId + ", cptCodes=" + cptCodes + ", icdCodes=" + icdCodes
				+ ", modifiers=" + modifiers + ", units=" + units + ", insurance=" + insurance + ", downcoded="
				+ downcoded + ", percentage=" + percentage + ", count=" + count + ", active=" + active
				+ ", userFullName=" + userFullName + ", username=" + username + ", createdUserFullName="
				+ createdUserFullName + ", createdUserName=" + createdUserName + ", createdTimestamp="
				+ createdTimestamp + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", lastUpdatedUser="
				+ lastUpdatedUser + ", lastUpdatedUsername=" + lastUpdatedUsername + ", nurseFilter=" + nurseFilter
				+ ", filterAudience=" + filterAudience + ", cptName=" + cptName + ", modifierName=" + modifierName
				+ ", cptData=" + cptData + ", isFilterNameChanged=" + isFilterNameChanged + "]";
	}
}
