package com.healogics.encode.dto;

public class IHealMeasurement {
	
	private double length;
	private double width;
	private double depth;
	private double area;
	private double volume;
	private IHealDocumentObj document;
	private boolean useCentimeters;
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getDepth() {
		return depth;
	}
	public void setDepth(double depth) {
		this.depth = depth;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	public double getVolume() {
		return volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}
	public IHealDocumentObj getDocument() {
		return document;
	}
	public void setDocument(IHealDocumentObj document) {
		this.document = document;
	}
	public boolean isUseCentimeters() {
		return useCentimeters;
	}
	public void setUseCentimeters(boolean useCentimeters) {
		this.useCentimeters = useCentimeters;
	}
	@Override
	public String toString() {
		return "IHealMeasurement [length=" + length + ", width=" + width
				+ ", depth=" + depth + ", area=" + area + ", volume=" + volume
				+ ", document=" + document + ", useCentimeters="
				+ useCentimeters + "]";
	}


}
