package com.healogics.encode.dto;

import java.util.List;

public class LoginRes {
	private static final long serialVersionUID = 0L;
	private String accessToken;
	private String refreshToken;
	private String responseCode;
	private String responseMessage;
	private IHealUserdetails ihealUserdetails;
	private List<String> encodeRole;
	private String colorCode;
	private String encodeRoleDesc;
	private List<UserFacilities> facilities;
	private String codingTeam;

	public List<UserFacilities> getFacilities() {
		return facilities;
	}

	public void setFacilities(List<UserFacilities> facilities) {
		this.facilities = facilities;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public IHealUserdetails getIhealUserdetails() {
		return ihealUserdetails;
	}

	public void setIhealUserDetails(IHealUserdetails ihealUserdetails) {
		this.ihealUserdetails = ihealUserdetails;
	}

	public String getEncodeRoleDesc() {
		return encodeRoleDesc;
	}

	public void setEncodeRoleDesc(String encodeRoleDesc) {
		this.encodeRoleDesc = encodeRoleDesc;
	}

	public List<String> getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(List<String> encodeRole) {
		this.encodeRole = encodeRole;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	@Override
	public String toString() {
		return "LoginRes [accessToken=" + accessToken + ", refreshToken=" + refreshToken + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + ", ihealUserdetails=" + ihealUserdetails
				+ ", encodeRole=" + encodeRole + ", colorCode=" + colorCode + ", encodeRoleDesc=" + encodeRoleDesc
				+ ", facilities=" + facilities + ", codingTeam=" + codingTeam + "]";
	}

}
