package com.healogics.encode.dto;

import java.util.List;

public class CodersRes extends APIResponse {

	private List<Coder> coders;

	public List<Coder> getCoders() {
		return coders;
	}

	public void setCoders(List<Coder> coders) {
		this.coders = coders;
	}

	@Override
	public String toString() {
		return "Coders [coders=" + coders + "]";
	}

}
