package com.healogics.encode.dto;

public class ProviderDetails {
	private String providerUserId;
	private String providerUserName;
	private String providerUserFullName;

	public String getProviderUserId() {
		return providerUserId;
	}
	public void setProviderUserId(String providerUserId) {
		this.providerUserId = providerUserId;
	}
	public String getProviderUserName() {
		return providerUserName;
	}
	public void setProviderUserName(String providerUserName) {
		this.providerUserName = providerUserName;
	}
	public String getProviderUserFullName() {
		return providerUserFullName;
	}
	public void setProviderUserFullName(String providerUserFullName) {
		this.providerUserFullName = providerUserFullName;
	}
	@Override
	public String toString() {
		return "ProviderDetails [providerUserId=" + providerUserId + ", providerUserName=" + providerUserName
				+ ", providerUserFullName=" + providerUserFullName + "]";
	}
}
