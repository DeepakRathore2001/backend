package com.healogics.encode.dto;

import java.util.List;

public class IHealVisitDocumentRes extends APIResponse {

	private List<DocumentObj> documentList;

	public List<DocumentObj> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<DocumentObj> documentList) {
		this.documentList = documentList;
	}

	@Override
	public String toString() {
		return "IHealVisitDocumentRes [documentList=" + documentList + "]";
	}

}
