package com.healogics.encode.dto;

public class ICDCPTRequest {
	private String searchText;
	private int searchType;
	private int count;
	private int offset;
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getSearchType() {
		return searchType;
	}

	public void setSearchType(int searchType) {
		this.searchType = searchType;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	@Override
	public String toString() {
		return "ICDCPTRequest [searchText=" + searchText + ", searchType=" + searchType + "]";
	}
}
