package com.healogics.encode.dto;

import java.util.List;

public class ChartByStatusReq {

	private List<String> status;

	public List<String> getStatus() {
		return status;
	}

	public void setStatus(List<String> status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ChartByStatusReq [status=" + status + "]";
	}

}
