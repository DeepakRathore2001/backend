package com.healogics.encode.dto;

import java.util.Date;

public class PatientMedicalRecordsDTO {

	private String documentId;
	private Long patientId;
	private Long visitId;
	private String documentType;
	private String sbillProviderFirstName;
	private String sbillProviderLastName;
	private String sbillProviderId;
	private Date eventDatetime;

	public PatientMedicalRecordsDTO(String documentId, Long patientId, Long visitId, String documentType,
			String sbillProviderFirstName, String sbillProviderLastName, String sbillProviderId, Date eventDatetime) {
		this.documentId = documentId;
		this.patientId = patientId;
		this.visitId = visitId;
		this.documentType = documentType;
		this.sbillProviderFirstName = sbillProviderFirstName;
		this.sbillProviderLastName = sbillProviderLastName;
		this.sbillProviderId = sbillProviderId;
		this.eventDatetime = eventDatetime;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getSbillProviderFirstName() {
		return sbillProviderFirstName;
	}

	public void setSbillProviderFirstName(String sbillProviderFirstName) {
		this.sbillProviderFirstName = sbillProviderFirstName;
	}

	public String getSbillProviderLastName() {
		return sbillProviderLastName;
	}

	public void setSbillProviderLastName(String sbillProviderLastName) {
		this.sbillProviderLastName = sbillProviderLastName;
	}

	public String getSbillProviderId() {
		return sbillProviderId;
	}

	public void setSbillProviderId(String sbillProviderId) {
		this.sbillProviderId = sbillProviderId;
	}

	public Date getEventDatetime() {
		return eventDatetime;
	}

	public void setEventDatetime(Date eventDatetime) {
		this.eventDatetime = eventDatetime;
	}

	@Override
	public String toString() {
		return "PatientMedicalRecordsDTO [documentId=" + documentId + ", patientId=" + patientId + ", visitId="
				+ visitId + ", documentType=" + documentType + ", sbillProviderFirstName=" + sbillProviderFirstName
				+ ", sbillProviderLastName=" + sbillProviderLastName + ", sbillProviderId=" + sbillProviderId
				+ ", eventDatetime=" + eventDatetime + "]";
	}

}
