package com.healogics.encode.dto;

import java.util.Date;

public class EncounterMonthlyReviewData {
	
	private long visitId;
	private String bluebookId;
	private int patientId;
	private String patientName;
	private String providerName;
	private Date dateOfService;
	private Date deficiencyDate;
	private String deficiencyNote;
	private String deficiencyReason;
	private String coderUserId;
	private String coderFullname;
	
	public String getCoderUserId() {
		return coderUserId;
	}
	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}
	public String getCoderFullname() {
		return coderFullname;
	}
	public void setCoderFullname(String coderFullname) {
		this.coderFullname = coderFullname;
	}
	public String getDeficiencyReason() {
		return deficiencyReason;
	}
	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Date getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}
	public Date getDeficiencyDate() {
		return deficiencyDate;
	}
	public void setDeficiencyDate(Date deficiencyDate) {
		this.deficiencyDate = deficiencyDate;
	}
	public String getDeficiencyNote() {
		return deficiencyNote;
	}
	public void setDeficiencyNote(String deficiencyNote) {
		this.deficiencyNote = deficiencyNote;
	}
	@Override
	public String toString() {
		return "EncounterMonthlyReviewData [visitId=" + visitId + ", bluebookId=" + bluebookId + ", patientId="
				+ patientId + ", patientName=" + patientName + ", providerName=" + providerName + ", dateOfService="
				+ dateOfService + ", deficiencyDate=" + deficiencyDate + ", deficiencyNote=" + deficiencyNote
				+ ", deficiencyReason=" + deficiencyReason + ", coderUserId=" + coderUserId + ", coderFullname="
				+ coderFullname + "]";
	}
	

}
