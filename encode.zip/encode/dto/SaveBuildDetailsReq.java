package com.healogics.encode.dto;

public class SaveBuildDetailsReq {

	private String environment;
	private String applicationName;
	private String component;
	private String applicationVersion;
	private String buildVersion;
	private String applicationPlatform;
	private String lastUpdatedUser;
	private String lastUpdatedTimestamp;
	private String pk;
	private String sk;

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getApplicationVersion() {
		return applicationVersion;
	}

	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}

	public String getBuildVersion() {
		return buildVersion;
	}

	public void setBuildVersion(String buildVersion) {
		this.buildVersion = buildVersion;
	}

	public String getApplicationPlatform() {
		return applicationPlatform;
	}

	public void setApplicationPlatform(String applicationPlatform) {
		this.applicationPlatform = applicationPlatform;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public String getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(String lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getPk() {
		return pk;
	}

	public void setPk(String pk) {
		this.pk = pk;
	}

	public String getSk() {
		return sk;
	}

	public void setSk(String sk) {
		this.sk = sk;
	}

	@Override
	public String toString() {
		return "SaveBuildDetailsReq [environment=" + environment + ", applicationName=" + applicationName
				+ ", component=" + component + ", applicationVersion=" + applicationVersion + ", buildVersion="
				+ buildVersion + ", applicationPlatform=" + applicationPlatform + ", lastUpdatedUser=" + lastUpdatedUser
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", pk=" + pk + ", sk=" + sk + "]";
	}

}
