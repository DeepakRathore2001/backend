package com.healogics.encode.dto;

import java.util.List;

public class ecWSentReportRes extends APIResponse {

	private List<ecWSentReportData> reportData;

	public List<ecWSentReportData> getReportData() {
		return reportData;
	}

	public void setReportData(List<ecWSentReportData> reportData) {
		this.reportData = reportData;
	}

	@Override
	public String toString() {
		return "ecWSentReportRes [reportData=" + reportData + "]";
	}

}
