package com.healogics.encode.dto;

public class InsuranceDetailsObj {
	
	private String insuranceName;
	private int insuranceId;
	private String insCo;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String policyNumber;
	private String relationship;
	private String group;
	private String coverage;
	private String providerUniqueId;
	private String insuranceType;
	
	public String getInsuranceType() {
		return insuranceType;
	}
	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	public int getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}
	public String getInsCo() {
		return insCo;
	}
	public void setInsCo(String insCo) {
		this.insCo = insCo;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getCoverage() {
		return coverage;
	}
	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}
	public String getProviderUniqueId() {
		return providerUniqueId;
	}
	public void setProviderUniqueId(String providerUniqueId) {
		this.providerUniqueId = providerUniqueId;
	}
	@Override
	public String toString() {
		return "InsuranceDetailsObj [insuranceName=" + insuranceName + ", insuranceId=" + insuranceId + ", insCo="
				+ insCo + ", address1=" + address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state
				+ ", policyNumber=" + policyNumber + ", relationship=" + relationship + ", group=" + group
				+ ", coverage=" + coverage + ", providerUniqueId=" + providerUniqueId + ", insuranceType="
				+ insuranceType + "]";
	}
	
	
	

}
