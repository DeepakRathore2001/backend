package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

public class IHealProviderInboxAPIStatus {
	private String inboxListAPIStatus;
	private String inboxListAPIErrorCode;
	private String inboxListAPIErrorMessage;
	private Timestamp inboxListAPIReqSentTimestamp;
	private Timestamp inboxListAPIResReceivedTimestamp;
	
	private List<IHealInboxMessageStatus> messageStatus;
	private List<Integer> readMessageIds;
	
	private String inboxArchivedSetAPIStatus;
	private String inboxArchivedSetAPIErrorCode;
	private String inboxArchivedSetAPIErrorMessage;
	private Timestamp inboxArchivedSetAPIReqSentTimestamp;
	private Timestamp inboxArchivedSetAPIResReceivedTimestamp;
	
	public List<Integer> getReadMessageIds() {
		return readMessageIds;
	}

	public void setReadMessageIds(List<Integer> readMessageIds) {
		this.readMessageIds = readMessageIds;
	}

	public String getInboxArchivedSetAPIStatus() {
		return inboxArchivedSetAPIStatus;
	}

	public void setInboxArchivedSetAPIStatus(String inboxArchivedSetAPIStatus) {
		this.inboxArchivedSetAPIStatus = inboxArchivedSetAPIStatus;
	}

	public String getInboxArchivedSetAPIErrorCode() {
		return inboxArchivedSetAPIErrorCode;
	}

	public void setInboxArchivedSetAPIErrorCode(String inboxArchivedSetAPIErrorCode) {
		this.inboxArchivedSetAPIErrorCode = inboxArchivedSetAPIErrorCode;
	}

	public String getInboxArchivedSetAPIErrorMessage() {
		return inboxArchivedSetAPIErrorMessage;
	}

	public void setInboxArchivedSetAPIErrorMessage(String inboxArchivedSetAPIErrorMessage) {
		this.inboxArchivedSetAPIErrorMessage = inboxArchivedSetAPIErrorMessage;
	}

	public Timestamp getInboxArchivedSetAPIReqSentTimestamp() {
		return inboxArchivedSetAPIReqSentTimestamp;
	}

	public void setInboxArchivedSetAPIReqSentTimestamp(Timestamp inboxArchivedSetAPIReqSentTimestamp) {
		this.inboxArchivedSetAPIReqSentTimestamp = inboxArchivedSetAPIReqSentTimestamp;
	}

	public Timestamp getInboxArchivedSetAPIResReceivedTimestamp() {
		return inboxArchivedSetAPIResReceivedTimestamp;
	}

	public void setInboxArchivedSetAPIResReceivedTimestamp(Timestamp inboxArchivedSetAPIResReceivedTimestamp) {
		this.inboxArchivedSetAPIResReceivedTimestamp = inboxArchivedSetAPIResReceivedTimestamp;
	}

	public String getInboxListAPIStatus() {
		return inboxListAPIStatus;
	}

	public void setInboxListAPIStatus(String inboxListAPIStatus) {
		this.inboxListAPIStatus = inboxListAPIStatus;
	}

	public String getInboxListAPIErrorCode() {
		return inboxListAPIErrorCode;
	}

	public void setInboxListAPIErrorCode(String inboxListAPIErrorCode) {
		this.inboxListAPIErrorCode = inboxListAPIErrorCode;
	}

	public String getInboxListAPIErrorMessage() {
		return inboxListAPIErrorMessage;
	}

	public void setInboxListAPIErrorMessage(String inboxListAPIErrorMessage) {
		this.inboxListAPIErrorMessage = inboxListAPIErrorMessage;
	}

	public Timestamp getInboxListAPIReqSentTimestamp() {
		return inboxListAPIReqSentTimestamp;
	}

	public void setInboxListAPIReqSentTimestamp(Timestamp inboxListAPIReqSentTimestamp) {
		this.inboxListAPIReqSentTimestamp = inboxListAPIReqSentTimestamp;
	}

	public Timestamp getInboxListAPIResReceivedTimestamp() {
		return inboxListAPIResReceivedTimestamp;
	}

	public void setInboxListAPIResReceivedTimestamp(Timestamp inboxListAPIResReceivedTimestamp) {
		this.inboxListAPIResReceivedTimestamp = inboxListAPIResReceivedTimestamp;
	}

	public List<IHealInboxMessageStatus> getMessageStatus() {
		return messageStatus;
	}

	public void setMessageStatus(List<IHealInboxMessageStatus> messageStatus) {
		this.messageStatus = messageStatus;
	}

	@Override
	public String toString() {
		return "IHealProviderInboxAPIStatus [inboxListAPIStatus=" + inboxListAPIStatus + ", inboxListAPIErrorCode="
				+ inboxListAPIErrorCode + ", inboxListAPIErrorMessage=" + inboxListAPIErrorMessage
				+ ", inboxListAPIReqSentTimestamp=" + inboxListAPIReqSentTimestamp
				+ ", inboxListAPIResReceivedTimestamp=" + inboxListAPIResReceivedTimestamp + ", messageStatus="
				+ messageStatus + ", readMessageIds=" + readMessageIds + ", inboxArchivedSetAPIStatus="
				+ inboxArchivedSetAPIStatus + ", inboxArchivedSetAPIErrorCode=" + inboxArchivedSetAPIErrorCode
				+ ", inboxArchivedSetAPIErrorMessage=" + inboxArchivedSetAPIErrorMessage
				+ ", inboxArchivedSetAPIReqSentTimestamp=" + inboxArchivedSetAPIReqSentTimestamp
				+ ", inboxArchivedSetAPIResReceivedTimestamp=" + inboxArchivedSetAPIResReceivedTimestamp + "]";
	}
}
