package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class ReconReportReq {
	private Timestamp startDate;
	private Timestamp endDate;
	private List<String> codingTeamList;
	private List<String> bbcList;
	private List<String> locationTypeList;
	private List<String> providerNameList;
	private List<String> patientNameList;
	private List<String> providerIdList;
	private List<String> visitIdList;
	private List<Integer> facilityIdList;
	private List<String> facilityTypeList;
	private List<String> serviceLineList;
	private List<String> status;
	private List<Integer> daysList;
	private List<String> coderFullnameList;
	private String filters;
	private String filterOptions;
	private int index;
	private int order;
	private String sortBy;
	private Date defStartDate;
	private Date defEndDate;
	private List<Long> visitIds;

	private int facilityId;
	private int providerId;
	private String providerName;

	private Boolean authorizedFacilityOnly;
	private String userId;
	private String masterToken;

	private String excelColumns;

	private String viewBy;

	// AdditionalMonthlyChargeSummaryReportFields
	private String cptCodes;
	private Boolean isAll;

	// AdditionalMissing Chart Report
	private Date dateOfService;
	private Boolean allChart;

	// Additional PostAuditReport
	private List<String> filterName;

	// Encounter Under Review

	private List<String> deficiencyReason;
	private List<String> pendingReason;

	private String dateType;
	private boolean isPagination;
	public boolean isPagination() {
		return isPagination;
	}

	public void setPagination(boolean isPagination) {
		this.isPagination = isPagination;
	}

	private boolean isfilterapplied;
	private String bbc;
	private String facilityName;
	private String patientName;
	private String visitId;
	private String startDOSDate;
	private String endDOSDate;
	private String deficiencyStartDate;
	private String deficiencyEndDate;
	private String bluebookId;

	
	public List<String> getCoderFullnameList() {
		return coderFullnameList;
	}

	public void setCoderFullnameList(List<String> coderFullnameList) {
		this.coderFullnameList = coderFullnameList;
	}

	public List<String> getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(List<String> pendingReason) {
		this.pendingReason = pendingReason;
	}

	public Timestamp getStartDate() {
		return startDate;
	}

	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public List<String> getCodingTeamList() {
		return codingTeamList;
	}

	public void setCodingTeamList(List<String> codingTeamList) {
		this.codingTeamList = codingTeamList;
	}

	public List<Long> getVisitIds() {
		return visitIds;
	}

	public void setVisitIds(List<Long> visitIds) {
		this.visitIds = visitIds;
	}

	public String getDeficiencyStartDate() {
		return deficiencyStartDate;
	}

	public void setDeficiencyStartDate(String deficiencyStartDate) {
		this.deficiencyStartDate = deficiencyStartDate;
	}

	public String getDeficiencyEndDate() {
		return deficiencyEndDate;
	}

	public void setDeficiencyEndDate(String deficiencyEndDate) {
		this.deficiencyEndDate = deficiencyEndDate;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Date getDefStartDate() {
		return defStartDate;
	}

	public void setDefStartDate(Date defStartDate) {
		this.defStartDate = defStartDate;
	}

	public Date getDefEndDate() {
		return defEndDate;
	}

	public void setDefEndDate(Date defEndDate) {
		this.defEndDate = defEndDate;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	public boolean isIsfilterapplied() {
		return isfilterapplied;
	}

	public void setIsfilterapplied(boolean isfilterapplied) {
		this.isfilterapplied = isfilterapplied;
	}

	public List<String> getServiceLineList() {
		return serviceLineList;
	}

	public void setServiceLineList(List<String> serviceLineList) {
		this.serviceLineList = serviceLineList;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public List<String> getPatientNameList() {
		return patientNameList;
	}

	public void setPatientNameList(List<String> patientNameList) {
		this.patientNameList = patientNameList;
	}

	public List<String> getVisitIdList() {
		return visitIdList;
	}

	public void setVisitIdList(List<String> visitIdList) {
		this.visitIdList = visitIdList;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public List<String> getFacilityTypeList() {
		return facilityTypeList;
	}

	public void setFacilityTypeList(List<String> facilityTypeList) {
		this.facilityTypeList = facilityTypeList;
	}

	public Boolean getAuthorizedFacilityOnly() {
		return authorizedFacilityOnly;
	}

	public void setAuthorizedFacilityOnly(Boolean authorizedFacilityOnly) {
		this.authorizedFacilityOnly = authorizedFacilityOnly;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getDateType() {
		return dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public List<String> getProviderIdList() {
		return providerIdList;
	}

	public void setProviderIdList(List<String> providerIdList) {
		this.providerIdList = providerIdList;
	}

	public List<Integer> getFacilityIdList() {
		return facilityIdList;
	}

	public void setFacilityIdList(List<Integer> facilityIdList) {
		this.facilityIdList = facilityIdList;
	}

	public List<String> getFilterName() {
		return filterName;
	}

	public void setFilterName(List<String> filterName) {
		this.filterName = filterName;
	}

	public Boolean getAllChart() {
		return allChart;
	}

	public void setAllChart(Boolean allChart) {
		this.allChart = allChart;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getViewBy() {
		return viewBy;
	}

	public void setViewBy(String viewBy) {
		this.viewBy = viewBy;
	}

	public Boolean getIsAll() {
		return isAll;
	}

	public void setIsAll(Boolean isAll) {
		this.isAll = isAll;
	}

	public String getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(String cptCodes) {
		this.cptCodes = cptCodes;
	}

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public List<String> getBbcList() {
		return bbcList;
	}

	public void setBbcList(List<String> bbcList) {
		this.bbcList = bbcList;
	}

	public List<String> getLocationTypeList() {
		return locationTypeList;
	}

	public void setLocationTypeList(List<String> locationTypeList) {
		this.locationTypeList = locationTypeList;
	}

	public List<String> getProviderNameList() {
		return providerNameList;
	}

	public void setProviderNameList(List<String> providerNameList) {
		this.providerNameList = providerNameList;
	}

	public List<String> getStatus() {
		return status;
	}

	public void setStatus(List<String> status) {
		this.status = status;
	}

	public List<Integer> getDaysList() {
		return daysList;
	}

	public void setDaysList(List<Integer> daysList) {
		this.daysList = daysList;
	}

	@Override
	public String toString() {
		return "ReconReportReq [startDate=" + startDate + ", endDate=" + endDate + ", codingTeamList=" + codingTeamList
				+ ", bbcList=" + bbcList + ", locationTypeList=" + locationTypeList + ", providerNameList="
				+ providerNameList + ", patientNameList=" + patientNameList + ", providerIdList=" + providerIdList
				+ ", visitIdList=" + visitIdList + ", facilityIdList=" + facilityIdList + ", facilityTypeList="
				+ facilityTypeList + ", serviceLineList=" + serviceLineList + ", status=" + status + ", daysList="
				+ daysList + ", coderFullnameList=" + coderFullnameList + ", filters=" + filters + ", filterOptions="
				+ filterOptions + ", index=" + index + ", order=" + order + ", sortBy=" + sortBy + ", defStartDate="
				+ defStartDate + ", defEndDate=" + defEndDate + ", visitIds=" + visitIds + ", facilityId=" + facilityId
				+ ", providerId=" + providerId + ", providerName=" + providerName + ", authorizedFacilityOnly="
				+ authorizedFacilityOnly + ", userId=" + userId + ", masterToken=" + masterToken + ", excelColumns="
				+ excelColumns + ", viewBy=" + viewBy + ", cptCodes=" + cptCodes + ", isAll=" + isAll
				+ ", dateOfService=" + dateOfService + ", allChart=" + allChart + ", filterName=" + filterName
				+ ", deficiencyReason=" + deficiencyReason + ", pendingReason=" + pendingReason + ", dateType="
				+ dateType + ", isPagination=" + isPagination + ", isfilterapplied=" + isfilterapplied + ", bbc=" + bbc
				+ ", facilityName=" + facilityName + ", patientName=" + patientName + ", visitId=" + visitId
				+ ", startDOSDate=" + startDOSDate + ", endDOSDate=" + endDOSDate + ", deficiencyStartDate="
				+ deficiencyStartDate + ", deficiencyEndDate=" + deficiencyEndDate + ", bluebookId=" + bluebookId + "]";
	}

}
