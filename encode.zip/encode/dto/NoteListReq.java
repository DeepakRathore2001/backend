package com.healogics.encode.dto;

import java.util.List;

public class NoteListReq {
	private int index;
	// private String taskType;
	private int order;
	private String sortBy;
	private String userRole;
	private List<String> userRoles;
	private Long visitId;

	private int noteId;

	public List<String> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<String> userRoles) {
		this.userRoles = userRoles;
	}

	public int getNoteId() {
		return noteId;
	}

	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	@Override
	public String toString() {
		return "NoteListReq [index=" + index + ", order=" + order + ", sortBy=" + sortBy + ", userRole=" + userRole
				+ ", userRoles=" + userRoles + ", visitId=" + visitId + ", noteId=" + noteId + "]";
	}

}
