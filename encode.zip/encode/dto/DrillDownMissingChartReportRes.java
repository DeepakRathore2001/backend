package com.healogics.encode.dto;

import java.util.List;

public class DrillDownMissingChartReportRes extends APIResponse {

	private List<DrillDownMissingChartObj> charts;

	public List<DrillDownMissingChartObj> getCharts() {
		return charts;
	}

	public void setCharts(List<DrillDownMissingChartObj> charts) {
		this.charts = charts;
	}

	@Override
	public String toString() {
		return "DrillDownMissingChartReport [charts=" + charts + "]";
	}

}
