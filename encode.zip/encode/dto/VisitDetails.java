package com.healogics.encode.dto;

import java.sql.Timestamp;

public class VisitDetails extends APIResponse {

	private long visitId;
	private String bluebookId;
	private Timestamp DOS;
	private String status;
	private String medicalRecordNumber;
	private String patientFirstName;
	private String patientLastName;
	private String primaryInsurance;
	private String secondaryInsurance;
	private int filterId;
	private String codingTeam;
	private long patientId;
	private String patientName;
	private int facilityId;
	private String facilityAlias;
	private String facilityType;

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Timestamp getDOS() {
		return DOS;
	}

	public void setDOS(Timestamp dOS) {
		DOS = dOS;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}

	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	@Override
	public String toString() {
		return "VisitDetails [visitId=" + visitId + ", bluebookId=" + bluebookId + ", DOS=" + DOS + ", status=" + status
				+ ", medicalRecordNumber=" + medicalRecordNumber + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", primaryInsurance=" + primaryInsurance
				+ ", secondaryInsurance=" + secondaryInsurance + ", filterId=" + filterId + ", codingTeam=" + codingTeam
				+ ", patientId=" + patientId + ", patientName=" + patientName + ", facilityId=" + facilityId
				+ ", facilityAlias=" + facilityAlias + ", facilityType=" + facilityType + "]";
	}

}
