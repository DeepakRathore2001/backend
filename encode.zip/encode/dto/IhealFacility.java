package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IhealFacility implements Serializable {
	private static final long serialVersionUID = 2915579310894440018L;

	private String facilityId;
	private String facilityName;
	private String facilityBluebookId;
	private String configuration;
	private String timeZone;
	private String createdOn;
	private String createdBy;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private String zone;
	private String fax;
	private String email;
	private String lastUpdatedBy;
	private String lastUpdatedDateTime;
	private List<String> authorizedApps;
	private List<ExternalSystems> externalSystems;
	private IhealSettings settings;
	@JsonProperty("SettingsV2")
	private IHealSettingsV2 settingsV2;
	private Boolean activeFacility;

	private IhealFacilityAdmin administrator;

	public List<ExternalSystems> getExternalSystems() {
		return externalSystems;
	}
	public void setExternalSystems(List<ExternalSystems> externalSystems) {
		this.externalSystems = externalSystems;
	}
	public IhealSettings getSettings() {
		return settings;
	}
	public void setSettings(IhealSettings settings) {
		this.settings = settings;
	}
	public IHealSettingsV2 getSettingsV2() {
		return settingsV2;
	}
	public void setSettingsV2(IHealSettingsV2 settingsV2) {
		this.settingsV2 = settingsV2;
	}

	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getFacilityBluebookId() {
		return facilityBluebookId;
	}
	public void setFacilityBluebookId(String facilityBluebookId) {
		this.facilityBluebookId = facilityBluebookId;
	}
	public String getConfiguration() {
		return configuration;
	}
	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}
	public void setLastUpdatedDateTime(String lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}
	public List<String> getAuthorizedApps() {
		return authorizedApps;
	}
	public void setAuthorizedApps(List<String> authorizedApps) {
		this.authorizedApps = authorizedApps;
	}
	public Boolean getActiveFacility() {
		return activeFacility;
	}
	public void setActiveFacility(Boolean activeFacility) {
		this.activeFacility = activeFacility;
	}
	public IhealFacilityAdmin getAdministrator() {
		return administrator;
	}
	public void setAdministrator(IhealFacilityAdmin administrator) {
		this.administrator = administrator;
	}
	@Override
	public String toString() {
		return "IhealFacility [facilityId=" + facilityId + ", facilityName="
				+ facilityName + ", facilityBluebookId=" + facilityBluebookId
				+ ", configuration=" + configuration + ", timeZone=" + timeZone
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", address1=" + address1 + ", address2=" + address2
				+ ", city=" + city + ", state=" + state + ", zip=" + zip
				+ ", phone=" + phone + ", zone=" + zone + ", fax=" + fax
				+ ", email=" + email + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedDateTime=" + lastUpdatedDateTime
				+ ", authorizedApps=" + authorizedApps + ", externalSystems="
				+ externalSystems + ", settings=" + settings + ", settingsV2="
				+ settingsV2 + ", activeFacility=" + activeFacility
				+ ", administrator=" + administrator + "]";
	}

}
