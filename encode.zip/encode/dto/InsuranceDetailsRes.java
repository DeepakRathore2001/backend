package com.healogics.encode.dto;

import java.util.List;

public class InsuranceDetailsRes {
	
	private String responseCode;
	private String responseMessage;
	private List<InsuranceDetailsObj> insuranceDetailsList;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<InsuranceDetailsObj> getInsuranceDetailsList() {
		return insuranceDetailsList;
	}
	public void setInsuranceDetailsList(List<InsuranceDetailsObj> insuranceDetailsList) {
		this.insuranceDetailsList = insuranceDetailsList;
	}
	@Override
	public String toString() {
		return "InsuranceDetailsRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", insuranceDetailsList=" + insuranceDetailsList + "]";
	}
	
	


}
