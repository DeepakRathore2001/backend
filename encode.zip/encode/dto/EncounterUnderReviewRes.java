package com.healogics.encode.dto;

import java.util.List;

public class EncounterUnderReviewRes {
	
	private String responseCode;
	private String responseMessage;
	private List<EncounterUnderReviewData> data;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<EncounterUnderReviewData> getData() {
		return data;
	}
	public void setData(List<EncounterUnderReviewData> data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "EncounterUnderReviewRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", data=" + data + "]";
	}
	
	

}
