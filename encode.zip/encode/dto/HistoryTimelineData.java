package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

public class HistoryTimelineData {
	private long visitId;
	private long patientId;
	private String patientName;
	private String bluebookId;
	private int facilityId;
	private Timestamp dateOfService;
	private String chartStatus;
	private String chartDescription;
	private String userName;
	private long userId;
	private String userFullName;
	private String userRole;

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getChartStatus() {
		return chartStatus;
	}

	public void setChartStatus(String chartStatus) {
		this.chartStatus = chartStatus;
	}

	public String getChartDescription() {
		return chartDescription;
	}

	public void setChartDescription(String chartDescription) {
		this.chartDescription = chartDescription;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	@Override
	public String toString() {
		return "HistoryTimelineData [visitId=" + visitId + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", dateOfService=" + dateOfService
				+ ", chartStatus=" + chartStatus + ", chartDescription=" + chartDescription + ", userName=" + userName
				+ ", userId=" + userId + ", userFullName=" + userFullName + ", userRole=" + userRole + "]";
	}
}
