package com.healogics.encode.dto;

import java.util.List;

public class EncodeRolesRes extends APIResponse {

	private List<String> encodeRoles;

	public List<String> getEncodeRoles() {
		return encodeRoles;
	}

	public void setEncodeRoles(List<String> encodeRoles) {
		this.encodeRoles = encodeRoles;
	}

	@Override
	public String toString() {
		return "EncodeRolesRes [encodeRoles=" + encodeRoles + "]";
	}

}
