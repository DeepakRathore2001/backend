package com.healogics.encode.dto;

public class ReportRes {
	
	private String responseCode;
	private String responseMessage;
	private ReportData data;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public ReportData getData() {
		return data;
	}
	public void setData(ReportData data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "ReportRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage + ", data=" + data
				+ "]";
	}
	
	

}
