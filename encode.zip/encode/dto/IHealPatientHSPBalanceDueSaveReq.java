package com.healogics.encode.dto;

public class IHealPatientHSPBalanceDueSaveReq {

	private String privateKey;
	private String masterToken;
	private String userId;
	private String facilityId;
	private String patientId;
	private String eventDateTime;
	private String hspBalanceDue;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getHspBalanceDue() {
		return hspBalanceDue;
	}

	public void setHspBalanceDue(String hspBalanceDue) {
		this.hspBalanceDue = hspBalanceDue;
	}

	@Override
	public String toString() {
		return "IHealPatientHSPBalanceDueSaveReq [privateKey=" + privateKey + ", masterToken=" + masterToken
				+ ", userId=" + userId + ", facilityId=" + facilityId + ", patientId=" + patientId + ", eventDateTime="
				+ eventDateTime + ", hspBalanceDue=" + hspBalanceDue + "]";
	}

}
