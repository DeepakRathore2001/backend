package com.healogics.encode.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InsuranceObj {

	private int insuranceId;
	private String insuranceName;
	private int sequence;
	public int getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	@Override
	public String toString() {
		return "InsuranceObj [insuranceId=" + insuranceId + ", insuranceName="
				+ insuranceName + ", sequence=" + sequence + "]";
	}

}
