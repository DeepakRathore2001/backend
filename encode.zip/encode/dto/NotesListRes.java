package com.healogics.encode.dto;

import java.util.List;

public class NotesListRes {
	private String responseCode;
	private String responseMessage;
	private List<NotesDetails> cmcRetrieveNotes;
	private int nextIndex;
	private int currentIndex;

	private Long totalCount;
	private double totalPage;
	private boolean isExhausted;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<NotesDetails> getCmcRetrieveNotes() {
		return cmcRetrieveNotes;
	}
	public void setCmcRetrieveNotes(List<NotesDetails> cmcRetrieveNotes) {
		this.cmcRetrieveNotes = cmcRetrieveNotes;
	}
	public int getNextIndex() {
		return nextIndex;
	}
	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}
	public int getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	@Override
	public String toString() {
		return "CMCRetrieveNoteRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", cmcRetrieveNotes=" + cmcRetrieveNotes + ", nextIndex=" + nextIndex + ", currentIndex="
				+ currentIndex + ", totalCount=" + totalCount + ", totalPage=" + totalPage + ", isExhausted="
				+ isExhausted + "]";
	}
	

}
