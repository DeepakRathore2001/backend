package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class AuditorCollapsibleSectionData {

	private int filterId;
	private long visitId;
	private Long patientId;
	private String patientName;
	private int facilityId;
	private String bbc;
	private String facilityAlias;
	private Timestamp dateOfService;
	private Timestamp dateQueued;
	private String status;
	private String medicalRecordNumber;
	private String patientFirstName;
	private String patientLastName;
	private String insurance;
	private int isLocked;
	private String userFullName;
	private Long assigneeUserId;
	private String assigneeUserName;
	private String assigneeUserFullName;

	public Long getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(Long assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserName() {
		return assigneeUserName;
	}

	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}

	public String getAssigneeUserFullName() {
		return assigneeUserFullName;
	}

	public void setAssigneeUserFullName(String assigneeUserFullName) {
		this.assigneeUserFullName = assigneeUserFullName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public Timestamp getDateQueued() {
		return dateQueued;
	}

	public void setDateQueued(Timestamp dateQueued) {
		this.dateQueued = dateQueued;
	}

	@Override
	public String toString() {
		return "AuditorCollapsibleSectionData [filterId=" + filterId + ", visitId=" + visitId + ", patientId="
				+ patientId + ", patientName=" + patientName + ", facilityId=" + facilityId + ", bbc=" + bbc
				+ ", facilityAlias=" + facilityAlias + ", dateOfService=" + dateOfService + ", dateQueued=" + dateQueued
				+ ", status=" + status + ", medicalRecordNumber=" + medicalRecordNumber + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName + ", insurance=" + insurance + ", isLocked="
				+ isLocked + ", userFullName=" + userFullName + ", assigneeUserId=" + assigneeUserId
				+ ", assigneeUserName=" + assigneeUserName + ", assigneeUserFullName=" + assigneeUserFullName + "]";
	}

}
