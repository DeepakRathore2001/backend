package com.healogics.encode.dto;

public class SuperBillLoadRes {

	private String responseCode;
	private String responseDesc;
	private SuperBillLoadObj superbill;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public SuperBillLoadObj getSuperbill() {
		return superbill;
	}
	public void setSuperbill(SuperBillLoadObj superbill) {
		this.superbill = superbill;
	}
	@Override
	public String toString() {
		return "SuperBillLoadRes [responseCode=" + responseCode
				+ ", responseDesc=" + responseDesc + ", superbill=" + superbill
				+ "]";
	}

}
