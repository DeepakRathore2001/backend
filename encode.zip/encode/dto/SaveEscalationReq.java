package com.healogics.encode.dto;

import java.sql.Timestamp;

public class SaveEscalationReq {

	private Long visitId;
	private Long patientId;
	private int wasEscalated;
	private int isEscalated;
	private String escalationReason;
	private String coderUserName;
	private long coderUserId;
	private Timestamp lastUpdatedTimestamp;

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public int getWasEscalated() {
		return wasEscalated;
	}

	public void setWasEscalated(int wasEscalated) {
		this.wasEscalated = wasEscalated;
	}

	public int getIsEscalated() {
		return isEscalated;
	}

	public void setIsEscalated(int isEscalated) {
		this.isEscalated = isEscalated;
	}

	public String getEscalationReason() {
		return escalationReason;
	}

	public void setEscalationReason(String escalationReason) {
		this.escalationReason = escalationReason;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public long getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(long coderUserId) {
		this.coderUserId = coderUserId;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "SaveEscalateNotesReq [visitId=" + visitId + ", patientId=" + patientId + ", wasEscalated="
				+ wasEscalated + ", isEscalated=" + isEscalated + ", escalationReason=" + escalationReason
				+ ", coderUserName=" + coderUserName + ", coderUserId=" + coderUserId + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + "]";
	}

}
