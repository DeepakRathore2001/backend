package com.healogics.encode.dto;

import java.util.List;

public class DocumentDeleteReq {
	
	private List<String> documentId;
	private long visitId;
	private List<String> documentName;
	private String userId;
	private String userName;
	private String userFullName;
	private long patientId;
	private List<String> documentType;

	public List<String> getDocumentType() {
		return documentType;
	}

	public void setDocumentType(List<String> documentType) {
		this.documentType = documentType;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public List<String> getDocumentName() {
		return documentName;
	}

	public void setDocumentName(List<String> documentName) {
		this.documentName = documentName;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public List<String> getDocumentId() {
		return documentId;
	}

	public void setDocumentId(List<String> documentId) {
		this.documentId = documentId;
	}

	@Override
	public String toString() {
		return "DocumentDeleteReq [documentId=" + documentId + ", visitId=" + visitId + ", documentName=" + documentName
				+ ", userId=" + userId + ", userName=" + userName + ", userFullName=" + userFullName + ", patientId="
				+ patientId + ", documentType=" + documentType + "]";
	}
	
	

}
