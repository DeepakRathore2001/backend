package com.healogics.encode.dto;

public class ReloadRequest {
	private int reloadCount;

	public int getReloadCount() {
		return reloadCount;
	}

	public void setReloadCount(int reloadCount) {
		this.reloadCount = reloadCount;
	}

	@Override
	public String toString() {
		return "ReloadRequest [reloadCount=" + reloadCount + "]";
	}
}
