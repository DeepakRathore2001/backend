package com.healogics.encode.dto;

public class ICD10Data {
	private String code;
	private String name;
	private String icd10Formatted;

	public String getIcd10Formatted() {
		return icd10Formatted;
	}

	public void setIcd10Formatted(String icd10Formatted) {
		this.icd10Formatted = icd10Formatted;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
  
	@Override
	public String toString() {
		return "ICD10Data [code=" + code + ", name=" + name + ", icd10Formatted=" + icd10Formatted + "]";
	}
}
