package com.healogics.encode.dto;

import java.util.List;

public class CollapsibleSectionRes {

	private String responseCode;
	private String responseMessage;
	private List<CollapsibleSection> collapsibleSection;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<CollapsibleSection> getCollapsibleSection() {
		return collapsibleSection;
	}

	public void setCollapsibleSection(List<CollapsibleSection> collapsibleSection) {
		this.collapsibleSection = collapsibleSection;
	}

	@Override
	public String toString() {
		return "CollapsibleSectionRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", collapsibleSection=" + collapsibleSection + "]";
	}

}
