package com.healogics.encode.dto;

import java.util.List;

public class EscalationDetailsRes {
	private String responseCode;
	private String responseMessage;
	private List<EscalationDetails> escalationDetails;

	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<EscalationDetails> getEscalationDetails() {
		return escalationDetails;
	}
	public void setEscalationDetails(List<EscalationDetails> escalationDetails) {
		this.escalationDetails = escalationDetails;
	}
	@Override
	public String toString() {
		return "EscalationDetailsList [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage
				+ ", escalationDetails=" + escalationDetails + "]";
	}
}
