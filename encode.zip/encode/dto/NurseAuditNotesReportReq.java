package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class NurseAuditNotesReportReq {
 
	private String excelColumns;
	private Date startAuditDate;
	private Date endAuditDate;
	private String visitId;
	private String Facility;
	private Date startDOS;
	private Date endDOS;
	private Date startQueuedDate;
	private Date endQueuedDate;
    private String units;
	private String  provider;
	private String resolution;
	private  String nurseComments;
	private String  AssignedNurse;
	private Long patientId;
	private String patientName;
	private int order;
	private String sortBy;
	private String filters;
	private String filterOption;
	
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getExcelColumns() {
		return excelColumns;
	}
	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}
	public Date getStartAuditDate() {
		return startAuditDate;
	}
	public void setStartAuditDate(Date startAuditDate) {
		this.startAuditDate = startAuditDate;
	}
	public Date getEndAuditDate() {
		return endAuditDate;
	}
	public void setEndAuditDate(Date endAuditDate) {
		this.endAuditDate = endAuditDate;
	}
	public String getVisitId() {
		return visitId;
	}
	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}
	public String getFacility() {
		return Facility;
	}
	public void setFacility(String facility) {
		Facility = facility;
	}
	public Date getStartDOS() {
		return startDOS;
	}
	public void setStartDOS(Date startDOS) {
		this.startDOS = startDOS;
	}
	public Date getEndDOS() {
		return endDOS;
	}
	public void setEndDOS(Date endDOS) {
		this.endDOS = endDOS;
	}
	public Date getStartQueuedDate() {
		return startQueuedDate;
	}
	public void setStartQueuedDate(Date startQueuedDate) {
		this.startQueuedDate = startQueuedDate;
	}
	public Date getEndQueuedDate() {
		return endQueuedDate;
	}
	public void setEndQueuedDate(Date endQueuedDate) {
		this.endQueuedDate = endQueuedDate;
	}

	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	public String getNurseComments() {
		return nurseComments;
	}
	public void setNurseComments(String nurseComments) {
		this.nurseComments = nurseComments;
	}
	public String getAssignedNurse() {
		return AssignedNurse;
	}
	public void setAssignedNurse(String assignedNurse) {
		AssignedNurse = assignedNurse;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getFilters() {
		return filters;
	}
	public void setFilters(String filters) {
		this.filters = filters;
	}
	public String getFilterOption() {
		return filterOption;
	}
	public void setFilterOption(String filterOption) {
		this.filterOption = filterOption;
	}
	@Override
	public String toString() {
		return "NurseAuditNotesReportReq [excelColumns=" + excelColumns + ", startAuditDate=" + startAuditDate
				+ ", endAuditDate=" + endAuditDate + ", visitId=" + visitId + ", Facility=" + Facility + ", startDOS="
				+ startDOS + ", endDOS=" + endDOS + ", startQueuedDate=" + startQueuedDate + ", endQueuedDate="
				+ endQueuedDate + ", units=" + units + ", provider=" + provider + ", resolution=" + resolution
				+ ", nurseComments=" + nurseComments + ", AssignedNurse=" + AssignedNurse + ", patientId=" + patientId
				+ ", patientName=" + patientName + ", order=" + order + ", sortBy=" + sortBy + ", filters=" + filters
				+ ", filterOption=" + filterOption + "]";
	}
	
}

	