package com.healogics.encode.dto;

public class TaggedUsers {
	private String taggedUserName;
	private Long taggedUserId;
	private String taggedUserFullName;
	private String taggedEmailId;
	public String getTaggedUserName() {
		return taggedUserName;
	}
	public void setTaggedUserName(String taggedUserName) {
		this.taggedUserName = taggedUserName;
	}
	public Long getTaggedUserId() {
		return taggedUserId;
	}
	public void setTaggedUserId(Long taggedUserId) {
		this.taggedUserId = taggedUserId;
	}
	public String getTaggedUserFullName() {
		return taggedUserFullName;
	}
	public void setTaggedUserFullName(String taggedUserFullName) {
		this.taggedUserFullName = taggedUserFullName;
	}
	public String getTaggedEmailId() {
		return taggedEmailId;
	}
	public void setTaggedEmailId(String taggedEmailId) {
		this.taggedEmailId = taggedEmailId;
	}
	@Override
	public String toString() {
		return "TaggedUsers [taggedUserName=" + taggedUserName
				+ ", taggedUserId=" + taggedUserId + ", taggedUserFullName="
				+ taggedUserFullName + ", taggedEmailId=" + taggedEmailId + "]";
	}

}
