package com.healogics.encode.dto;

import java.util.List;

public class SuperBillObj {

	private String VisitId;
	private String VersionId;
	private String DocumentEntityId;
	private String BBC;
	private String PatientFirstName;
	private String PatientLastName;
	private String PatientId;
	private String MRN;
	private String ProviderFirstName;
	private String ProviderLastName;
	private String ProviderId;
	private String DOS;
	private ProcedureProviderEMObj ProcedureProviderEM;
	private List<ProceduresObj> Procedures;
	private List<CodeDiagnosisObj> CodeDiagnosis;

	public String getVisitId() {
		return VisitId;
	}

	public void setVisitId(String visitId) {
		VisitId = visitId;
	}

	public String getVersionId() {
		return VersionId;
	}

	public void setVersionId(String versionId) {
		VersionId = versionId;
	}

	public String getDocumentEntityId() {
		return DocumentEntityId;
	}

	public void setDocumentEntityId(String documentEntityId) {
		DocumentEntityId = documentEntityId;
	}

	public String getBBC() {
		return BBC;
	}

	public void setBBC(String bBC) {
		BBC = bBC;
	}

	public String getPatientFirstName() {
		return PatientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		PatientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return PatientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		PatientLastName = patientLastName;
	}

	public String getPatientId() {
		return PatientId;
	}

	public void setPatientId(String patientId) {
		PatientId = patientId;
	}

	public String getMRN() {
		return MRN;
	}

	public void setMRN(String mRN) {
		MRN = mRN;
	}

	public String getProviderFirstName() {
		return ProviderFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		ProviderFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return ProviderLastName;
	}

	public void setProviderLastName(String providerLastName) {
		ProviderLastName = providerLastName;
	}

	public String getProviderId() {
		return ProviderId;
	}

	public void setProviderId(String providerId) {
		ProviderId = providerId;
	}

	public String getDOS() {
		return DOS;
	}

	public void setDOS(String dOS) {
		DOS = dOS;
	}

	public ProcedureProviderEMObj getProcedureProviderEM() {
		return ProcedureProviderEM;
	}

	public void setProcedureProviderEM(ProcedureProviderEMObj procedureProviderEM) {
		ProcedureProviderEM = procedureProviderEM;
	}

	public List<ProceduresObj> getProcedures() {
		return Procedures;
	}

	public void setProcedures(List<ProceduresObj> procedures) {
		Procedures = procedures;
	}

	public List<CodeDiagnosisObj> getCodeDiagnosis() {
		return CodeDiagnosis;
	}

	public void setCodeDiagnosis(List<CodeDiagnosisObj> codeDiagnosis) {
		CodeDiagnosis = codeDiagnosis;
	}

	@Override
	public String toString() {
		return "SuperBillObj [VisitId=" + VisitId + ", VersionId=" + VersionId + ", DocumentEntityId="
				+ DocumentEntityId + ", BBC=" + BBC + ", PatientFirstName=" + PatientFirstName + ", PatientLastName="
				+ PatientLastName + ", PatientId=" + PatientId + ", MRN=" + MRN + ", ProviderFirstName="
				+ ProviderFirstName + ", ProviderLastName=" + ProviderLastName + ", ProviderId=" + ProviderId + ", DOS="
				+ DOS + ", ProcedureProviderEM=" + ProcedureProviderEM + ", Procedures=" + Procedures
				+ ", CodeDiagnosis=" + CodeDiagnosis + "]";
	}

}
