package com.healogics.encode.dto;

public class FilterOptionsRes {
	
	private String responseCode;
	private String responseDesc;
	private FilterOptions filterOptions;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}

	public FilterOptions getFilterOptions() {
		return filterOptions;
	}
	public void setFilterOptions(FilterOptions filterOptions) {
		this.filterOptions = filterOptions;
	}
	@Override
	public String toString() {
		return "FilterOptionsRes [responseCode=" + responseCode
				+ ", responseDesc=" + responseDesc + ", filterOptions="
				+ filterOptions + "]";
	}

}
