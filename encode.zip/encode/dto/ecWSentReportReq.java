package com.healogics.encode.dto;

import java.util.Date;

public class ecWSentReportReq {

	private Date startDate;
	private Date endDate;
	private String excelColumns;

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "ecWSentReportReq [startDate=" + startDate + ", endDate=" + endDate + ", excelColumns=" + excelColumns
				+ "]";
	}

}
