package com.healogics.encode.dto;

public class IHealPatientLoadReq {

	private String privateKey;
	private String masterToken;
	private String userId;
	private String facilityId;
	private String patientId;
	private long visitId;
	
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	@Override
	public String toString() {
		return "IHealPatientLoadReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId + ", visitId=" + visitId + "]";
	}

}
