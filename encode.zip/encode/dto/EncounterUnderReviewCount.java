package com.healogics.encode.dto;

public class EncounterUnderReviewCount {
	
	private long patientId;
	private String patientName;
	private String providerName;
	private Long total;
	

	public long getPatientId() {
		return patientId;
	}
	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}
	public Long getTotal() {
		return total;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	@Override
	public String toString() {
		return "EncounterUnderReviewCount [patientId=" + patientId + ", patientName=" + patientName + ", providerName="
				+ providerName + ", total=" + total + "]";
	}
	
	

}
