package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealVisitLoadRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private IHealVisitObject visit;
	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	public IHealVisitObject getVisit() {
		return visit;
	}
	public void setVisit(IHealVisitObject visit) {
		this.visit = visit;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealVisitListGetRes [visit=" + visit + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", warnings=" + warnings + "]";
	}

}
