package com.healogics.encode.dto;

import java.util.List;

public class Escalation {
	private Long escalatedUserId;
	private String escalatedUsername;
	private String escalationReason;
	private String escalationNote;
	private List<TaggedUsers> taggedUsers;

	public Long getEscalatedUserId() {
		return escalatedUserId;
	}

	public void setEscalatedUserId(Long escalatedUserId) {
		this.escalatedUserId = escalatedUserId;
	}

	public String getEscalatedUsername() {
		return escalatedUsername;
	}

	public void setEscalatedUsername(String escalatedUsername) {
		this.escalatedUsername = escalatedUsername;
	}

	public String getEscalationReason() {
		return escalationReason;
	}

	public void setEscalationReason(String escalationReason) {
		this.escalationReason = escalationReason;
	}

	public String getEscalationNote() {
		return escalationNote;
	}

	public void setEscalationNote(String escalationNote) {
		this.escalationNote = escalationNote;
	}

	public List<TaggedUsers> getTaggedUsers() {
		return taggedUsers;
	}

	public void setTaggedUsers(List<TaggedUsers> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}

	@Override
	public String toString() {
		return "Escalation [escalatedUserId=" + escalatedUserId + ", escalatedUsername=" + escalatedUsername
				+ ", escalationReason=" + escalationReason + ", escalationNote=" + escalationNote + ", taggedUsers="
				+ taggedUsers + "]";
	}

}
