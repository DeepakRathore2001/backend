package com.healogics.encode.dto;

import java.util.List;

public class PostAuditFiltersRes extends APIResponse {

	private List<String> filterName;

	public List<String> getFilterName() {
		return filterName;
	}

	public void setFilterName(List<String> filterName) {
		this.filterName = filterName;
	}

	@Override
	public String toString() {
		return "PostAuditFiltersRes [filterName=" + filterName + "]";
	}

}
