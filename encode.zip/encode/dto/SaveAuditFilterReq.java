package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

public class SaveAuditFilterReq {
	private Long filterId;
	private String filterName;
	private String billingClient;
	private List<CoderDetails> coders;
	private List<ProviderDetails> providers;
	private List<FacilityDetails> facilities;
	private List<CPTCodeDetails> cptCodes;
	private List<ICD10Data> icdCodes;
	private String modifiers;
	private String units;
	private String insurance;
	private int downcoded;
	private int percentage;
	private int count;
	private int active;
	private String userFullName;
	private String username;
	private String createdUserFullName;
	private String createdUserName;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;
	private String lastUpdatedUser;
	private String lastUpdatedUsername;
	private int isFilterNameChanged;

	public int getIsFilterNameChanged() {
		return isFilterNameChanged;
	}

	public void setIsFilterNameChanged(int isFilterNameChanged) {
		this.isFilterNameChanged = isFilterNameChanged;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Long getFilterId() {
		return filterId;
	}

	public void setFilterId(Long filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getBillingClient() {
		return billingClient;
	}

	public void setBillingClient(String billingClient) {
		this.billingClient = billingClient;
	}

	public List<CoderDetails> getCoders() {
		return coders;
	}

	public void setCoders(List<CoderDetails> coders) {
		this.coders = coders;
	}

	public List<ProviderDetails> getProviders() {
		return providers;
	}

	public void setProviders(List<ProviderDetails> providers) {
		this.providers = providers;
	}

	public List<FacilityDetails> getFacilities() {
		return facilities;
	}

	public void setFacilities(List<FacilityDetails> facilities) {
		this.facilities = facilities;
	}

	public List<CPTCodeDetails> getCptCodes() {
		return cptCodes;
	}

	public void setCptCodes(List<CPTCodeDetails> cptCodes) {
		this.cptCodes = cptCodes;
	}

	public List<ICD10Data> getIcdCodes() {
		return icdCodes;
	}

	public void setIcdCodes(List<ICD10Data> icdCodes) {
		this.icdCodes = icdCodes;
	}

	public String getModifiers() {
		return modifiers;
	}

	public void setModifiers(String modifiers) {
		this.modifiers = modifiers;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public int getDowncoded() {
		return downcoded;
	}

	public void setDowncoded(int downcoded) {
		this.downcoded = downcoded;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCreatedUserFullName() {
		return createdUserFullName;
	}

	public void setCreatedUserFullName(String createdUserFullName) {
		this.createdUserFullName = createdUserFullName;
	}

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	@Override
	public String toString() {
		return "SaveAuditFilterReq [filterId=" + filterId + ", filterName=" + filterName + ", billingClient="
				+ billingClient + ", coders=" + coders + ", providers=" + providers + ", facilities=" + facilities
				+ ", cptCodes=" + cptCodes + ", icdCodes=" + icdCodes + ", modifiers=" + modifiers + ", units=" + units
				+ ", insurance=" + insurance + ", downcoded=" + downcoded + ", percentage=" + percentage + ", count="
				+ count + ", active=" + active + ", userFullName=" + userFullName + ", username=" + username
				+ ", createdUserFullName=" + createdUserFullName + ", createdUserName=" + createdUserName
				+ ", createdTimestamp=" + createdTimestamp + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", lastUpdatedUser=" + lastUpdatedUser + ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", isFilterNameChanged=" + isFilterNameChanged + "]";
	}
}
