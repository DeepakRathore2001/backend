package com.healogics.encode.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AuditorReasonRes {
	
	private String responseCode;
	private String responseMessage;
	private String role;
	private List<Map<String, Object>> listOfReasons;
	
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
	public List<Map<String, Object>> getListOfReasons() {
		return listOfReasons;
	}
	public void setListOfReasons(List<Map<String, Object>> listOfReasons) {
		this.listOfReasons = listOfReasons;
	}
	@Override
	public String toString() {
		return "AuditorReasonRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage + ", role="
				+ role + ", listOfReasons=" + listOfReasons + "]";
	}
	

}
