package com.healogics.encode.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealInsuredObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("Id")
	private int Id;

	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("middleName")
	private String middleName;

	@JsonProperty("relationship")
	private String relationship;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	@Override
	public String toString() {
		return "IHealInsuredObj [Id=" + Id + ", firstName=" + firstName + ", lastName=" + lastName + ", middleName="
				+ middleName + ", relationship=" + relationship + "]";
	}

}
