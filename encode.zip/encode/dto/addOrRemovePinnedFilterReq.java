package com.healogics.encode.dto;

public class addOrRemovePinnedFilterReq {

	private int pinFilter;
	private int unpinFilter;
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getPinFilter() {
		return pinFilter;
	}

	public void setPinFilter(int pinFilter) {
		this.pinFilter = pinFilter;
	}

	public int getUnpinFilter() {
		return unpinFilter;
	}

	public void setUnpinFilter(int unpinFilter) {
		this.unpinFilter = unpinFilter;
	}

	@Override
	public String toString() {
		return "addOrRemovePinnedFilterReq [pinFilter=" + pinFilter + ", unpinFilter=" + unpinFilter + ", userId="
				+ userId + "]";
	}

}
