package com.healogics.encode.dto;

import java.util.List;

public class SaveRecordReq {
	private Long visitId;
	private String existingStatus;
	private String action;
	private String pendReason;
	private String unbillableReason;
	private String userId;
	private String userName;
	private String userFullName;
	private String masterToken;
	private Long patientId;
	private String userRole;
	private List<String> filterBbc;
	private List<String> filterFacilityId;
	
	private String userFirstName;
	private String userLastName;
	private Long pendProviderId;
	private String pendProviderName;
	private String patientFirstName;
	private String patientLastName;
	private String dateOfService;

	public String getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public Long getPendProviderId() {
		return pendProviderId;
	}

	public void setPendProviderId(Long pendProviderId) {
		this.pendProviderId = pendProviderId;
	}

	public String getPendProviderName() {
		return pendProviderName;
	}

	public void setPendProviderName(String pendProviderName) {
		this.pendProviderName = pendProviderName;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public List<String> getFilterFacilityId() {
		return filterFacilityId;
	}

	public void setFilterFacilityId(List<String> filterFacilityId) {
		this.filterFacilityId = filterFacilityId;
	}

	public List<String> getFilterBbc() {
		return filterBbc;
	}

	public void setFilterBbc(List<String> filterBbc) {
		this.filterBbc = filterBbc;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getExistingStatus() {
		return existingStatus;
	}

	public void setExistingStatus(String existingStatus) {
		this.existingStatus = existingStatus;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getPendReason() {
		return pendReason;
	}

	public void setPendReason(String pendReason) {
		this.pendReason = pendReason;
	}

	public String getUnbillableReason() {
		return unbillableReason;
	}

	public void setUnbillableReason(String unbillableReason) {
		this.unbillableReason = unbillableReason;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	@Override
	public String toString() {
		return "SaveRecordReq [visitId=" + visitId + ", existingStatus=" + existingStatus + ", action=" + action
				+ ", pendReason=" + pendReason + ", unbillableReason=" + unbillableReason + ", userId=" + userId
				+ ", userName=" + userName + ", userFullName=" + userFullName + ", masterToken=" + masterToken
				+ ", patientId=" + patientId + ", userRole=" + userRole + ", filterBbc=" + filterBbc
				+ ", filterFacilityId=" + filterFacilityId + ", userFirstName=" + userFirstName + ", userLastName="
				+ userLastName + ", pendProviderId=" + pendProviderId + ", pendProviderName=" + pendProviderName
				+ ", patientFirstName=" + patientFirstName + ", patientLastName=" + patientLastName + ", dateOfService="
				+ dateOfService + "]";
	}
}
