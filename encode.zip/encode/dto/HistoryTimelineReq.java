package com.healogics.encode.dto;

public class HistoryTimelineReq {
	private long visitId;
	private int index;

	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	@Override
	public String toString() {
		return "HistoryTimelineReq [visitId=" + visitId + ", index=" + index + "]";
	}
}
