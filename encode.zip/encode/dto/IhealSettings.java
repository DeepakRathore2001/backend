package com.healogics.encode.dto;

import java.io.Serializable;

public class IhealSettings implements Serializable{

	 private static final long serialVersionUID = 1L;
	    private String location;
	    private String serviceLine;

	    public String getLocation() {
	        return location;
	    }
	    public void setLocation(String location) {
	        this.location = location;
	    }
	    public String getServiceLine() {
	        return serviceLine;
	    }
	    public void setServiceLine(String serviceLine) {
	        this.serviceLine = serviceLine;
	    }

	    @Override
	    public String toString() {
	        return "{ location:" + location + ", serviceLine:" + serviceLine + "}";
	    }
	
}
