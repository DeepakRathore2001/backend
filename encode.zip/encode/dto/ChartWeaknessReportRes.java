package com.healogics.encode.dto;

import java.util.List;

public class ChartWeaknessReportRes extends APIResponse{
	private int nextIndex;
	private int currentIndex;
	private Long totalCount;
	private double totalPage;
	private boolean isExhausted;
	private List<ChartWeaknessReportData> data;

	public int getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}

	public int getCurrentIndex() {
		return currentIndex;
	}

	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public double getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}

	public boolean isExhausted() {
		return isExhausted;
	}

	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}

	public List<ChartWeaknessReportData> getData() {
		return data;
	}

	public void setData(List<ChartWeaknessReportData> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "ChartWeaknessReportRes [nextIndex=" + nextIndex + ", currentIndex=" + currentIndex + ", totalCount="
				+ totalCount + ", totalPage=" + totalPage + ", isExhausted=" + isExhausted + ", data=" + data + "]";
	}
	
	
	
	

}
