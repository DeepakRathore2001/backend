package com.healogics.encode.dto;

import java.util.List;

public class FinthriveClaimLookup {
	private int id;
	private int type;
	private int stateAbbr;
	private String claimNumber;
	private List<FinthriveProcedures> procedures;
	private FinthrivePatient patient;
	private List<FinthriveDiagnosis> diagnoses;
	private FinthrivePayer payer;
	private FinthriveProvider provider;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getStateAbbr() {
		return stateAbbr;
	}

	public void setStateAbbr(int stateAbbr) {
		this.stateAbbr = stateAbbr;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public List<FinthriveProcedures> getProcedures() {
		return procedures;
	}

	public void setProcedures(List<FinthriveProcedures> procedures) {
		this.procedures = procedures;
	}

	public FinthrivePatient getPatient() {
		return patient;
	}

	public void setPatient(FinthrivePatient patient) {
		this.patient = patient;
	}

	public List<FinthriveDiagnosis> getDiagnoses() {
		return diagnoses;
	}

	public void setDiagnoses(List<FinthriveDiagnosis> diagnoses) {
		this.diagnoses = diagnoses;
	}

	public FinthrivePayer getPayer() {
		return payer;
	}

	public void setPayer(FinthrivePayer payer) {
		this.payer = payer;
	}

	public FinthriveProvider getProvider() {
		return provider;
	}

	public void setProvider(FinthriveProvider provider) {
		this.provider = provider;
	}

	@Override
	public String toString() {
		return "FinthriveClaimLookup [id=" + id + ", type=" + type + ", stateAbbr=" + stateAbbr + ", claimNumber="
				+ claimNumber + ", procedures=" + procedures + ", patient=" + patient + ", diagnoses=" + diagnoses
				+ ", payer=" + payer + ", provider=" + provider + "]";
	}
}
