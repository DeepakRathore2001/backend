package com.healogics.encode.dto;

public class IHealUserInboxMessageLoadReq {
	private String privateKey;
	private String masterToken;
	private Integer userId;
	private Integer messageId;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageLoadReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId="
				+ userId + ", messageId=" + messageId + "]";
	}
}
