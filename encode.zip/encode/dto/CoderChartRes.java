package com.healogics.encode.dto;

public class CoderChartRes extends APIResponse {
	private CoderChartDetails coderRecord;

	private Chart chartDetails;
	
	public CoderChartDetails getCoderRecord() {
		return coderRecord;
	}

	public void setCoderRecord(CoderChartDetails coderRecord) {
		this.coderRecord = coderRecord;
	}

	public Chart getChartDetails() {
		return chartDetails;
	}

	public void setChartDetails(Chart chartDetails) {
		this.chartDetails = chartDetails;
	}

	@Override
	public String toString() {
		return "CoderChartRes [coderRecord=" + coderRecord + ", chartDetails=" + chartDetails + "]";
	}
}
