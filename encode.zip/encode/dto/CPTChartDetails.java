package com.healogics.encode.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CPTChartDetails {
	private String cptCode;
	private String cptName;
	private List<String> modifier;
	private int unit;
	private String auditCategory;
	private String auditReason;
	private String auditReasonNote;
	private String saveAuditNote;
	private String oldCptCode;
	private String newCptCode;
	private List<ICD10Data> selectedICDs;

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public String getCptName() {
		return cptName;
	}

	public void setCptName(String cptName) {
		this.cptName = cptName;
	}

	public List<String> getModifier() {
		return modifier;
	}

	public void setModifier(List<String> modifier) {
		this.modifier = modifier;
	}

	public int getUnit() {
		return unit;
	}

	public void setUnit(int unit) {
		this.unit = unit;
	}

	public List<ICD10Data> getSelectedICDs() {
		return selectedICDs;
	}

	public void setSelectedICDs(List<ICD10Data> selectedICDs) {
		this.selectedICDs = selectedICDs;
	}

	public String getAuditCategory() {
		return auditCategory;
	}

	public void setAuditCategory(String auditCategory) {
		this.auditCategory = auditCategory;
	}

	public String getAuditReason() {
		return auditReason;
	}

	public void setAuditReason(String auditReason) {
		this.auditReason = auditReason;
	}

	public String getAuditReasonNote() {
		return auditReasonNote;
	}

	public void setAuditReasonNote(String auditReasonNote) {
		this.auditReasonNote = auditReasonNote;
	}

	public String getOldCptCode() {
		return oldCptCode;
	}

	public void setOldCptCode(String oldCptCode) {
		this.oldCptCode = oldCptCode;
	}

	public String getNewCptCode() {
		return newCptCode;
	}

	public void setNewCptCode(String newCptCode) {
		this.newCptCode = newCptCode;
	}

	public String getSaveAuditNote() {
		return saveAuditNote;
	}

	public void setSaveAuditNote(String saveAuditNote) {
		this.saveAuditNote = saveAuditNote;
	}

	@Override
	public String toString() {
		return "CPTChartDetails [cptCode=" + cptCode + ", cptName=" + cptName + ", modifier=" + modifier + ", unit="
				+ unit + ", auditCategory=" + auditCategory + ", auditReason=" + auditReason + ", auditReasonNote="
				+ auditReasonNote + ", saveAuditNote=" + saveAuditNote + ", oldCptCode=" + oldCptCode + ", newCptCode="
				+ newCptCode + ", selectedICDs=" + selectedICDs + "]";
	}
}
