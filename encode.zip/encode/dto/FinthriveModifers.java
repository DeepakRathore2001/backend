package com.healogics.encode.dto;

public class FinthriveModifers {
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "FinthriveModifers [code=" + code + "]";
	}
}
