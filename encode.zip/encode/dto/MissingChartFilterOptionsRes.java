package com.healogics.encode.dto;

public class MissingChartFilterOptionsRes extends APIResponse{
	
	private MissingChartFilter missingChartFilter;

	public MissingChartFilter getMissingChartFilter() {
		return missingChartFilter;
	}

	public void setMissingChartFilter(MissingChartFilter missingChartFilter) {
		this.missingChartFilter = missingChartFilter;
	}

	@Override
	public String toString() {
		return "MissingChartFilterOptionsRes [missingChartFilter=" + missingChartFilter + "]";
	}
	
	
	
	

}
