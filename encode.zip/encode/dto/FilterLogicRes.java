package com.healogics.encode.dto;

import java.util.List;
import java.util.Map;

public class FilterLogicRes extends APIResponse {

	private Map<Integer, List<VisitDetails>> filteredData;

	public Map<Integer, List<VisitDetails>> getFilteredData() {
		return filteredData;
	}

	public void setFilteredData(Map<Integer, List<VisitDetails>> filteredData) {
		this.filteredData = filteredData;
	}

	@Override
	public String toString() {
		return "FilterLogicRes [filteredData=" + filteredData + "]";
	}

}
