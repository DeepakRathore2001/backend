package com.healogics.encode.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SaveRecordRes extends APIResponse {
	private Long nextRecordVisitId;
	private String userName;
	private String userFullName;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public Long getNextRecordVisitId() {
		return nextRecordVisitId;
	}

	public void setNextRecordVisitId(Long nextRecordVisitId) {
		this.nextRecordVisitId = nextRecordVisitId;
	}

	@Override
	public String toString() {
		return "SaveRecordRes [nextRecordVisitId=" + nextRecordVisitId + ", userName=" + userName + ", userFullName="
				+ userFullName + "]";
	}
}
