package com.healogics.encode.dto;

public class MonthlyChargeSummaryObj {

	private String cptCode;
	private Integer codeCount;
	private Double percentage;

	public String getCptCode() {
		return cptCode;
	}
	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public Integer getCodeCount() {
		return codeCount;
	}
	public void setCodeCount(Integer codeCount) {
		this.codeCount = codeCount;
	}
	public Double getPercentage() {
		return percentage;
	}
	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
	@Override
	public String toString() {
		return "MonthlyChargeSummaryObj [cptCode=" + cptCode + ", codeCount="
				+ codeCount + ", percentage=" + percentage + "]";
	}
}
