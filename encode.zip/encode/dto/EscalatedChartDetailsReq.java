package com.healogics.encode.dto;

public class EscalatedChartDetailsReq {
	private int index;
	private String taskType;
	private String username;
	private int order;
	private String sortBy;
	private String masterToken;
	private String userId;
	private String status;
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "EscalatedChartDetailsReq [index=" + index + ", taskType=" + taskType + ", username=" + username
				+ ", order=" + order + ", sortBy=" + sortBy + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", status=" + status + "]";
	}
	

}
