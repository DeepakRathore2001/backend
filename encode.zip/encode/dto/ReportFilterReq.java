package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class ReportFilterReq {

	private String coderName;
	private String codingTeam;
	private String visitId;
	private String providerName;
	private String bbc;
	private Timestamp dateOfService;
	private boolean codingError;
	private String filterOptions;
	private String filters;
	private String startDOSDate;
	private String endDOSDate;
	private String sortBy;
	private String codingErrors;
	private int order;
	private int index;
	private String auditNote;
	private String chartCodes;
	private String facilityName;
	private String patientName;
	private String primaryProvider;
	private Timestamp dateBilled;
	private Date endDate;
	private Date startDate;
	
	private String coder;
	private Timestamp guidanceDate;
	private String nosOfDays;
	private String facility;
	private List<Integer> coderId;
	private String startGuidanceDate;
	private String endGuidanceDate;
	private List<String> bbcList;
	private List<String> locationTypeList;
	private List<String> providerNameList;
	private String startDateBilled;
	private String endDateBilled;
	private Timestamp dos;
	private int facilityId;
	private int providerId;
	private String bluebookId;
	private String daysInGuidance;
	private String coderFullName;
	private String blueBookId;
	private List<Integer> facilityIdList;
	private List<String> providerIdList;
	private Long elapsedTime;
	private String mrn;
	private List<String> statusList;
	private String status;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<String> statusList) {
		this.statusList = statusList;
	}

	public String getMrn() {
		return mrn;
	}

	public void setMrn(String mrn) {
		this.mrn = mrn;
	}

	public Long getElapsedTime() {
		return elapsedTime;
	}

	public void setElapsedTime(Long elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	public List<String> getProviderIdList() {
		return providerIdList;
	}

	public void setProviderIdList(List<String> providerIdList) {
		this.providerIdList = providerIdList;
	}

	public List<Integer> getFacilityIdList() {
		return facilityIdList;
	}

	public void setFacilityIdList(List<Integer> facilityIdList) {
		this.facilityIdList = facilityIdList;
	}

	public String getBlueBookId() {
		return blueBookId;
	}

	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}

	// Additional PostAuditReport
	private List<String> filterName;
	
	public String getCoderFullName() {
		return coderFullName;
	}

	public void setCoderFullName(String coderFullName) {
		this.coderFullName = coderFullName;
	}

	public String getDaysInGuidance() {
		return daysInGuidance;
	}

	public void setDaysInGuidance(String daysInGuidance) {
		this.daysInGuidance = daysInGuidance;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public List<String> getFilterName() {
		return filterName;
	}

	public void setFilterName(List<String> filterName) {
		this.filterName = filterName;
	}

	public Timestamp getDos() {
		return dos;
	}

	public void setDos(Timestamp dos) {
		this.dos = dos;
	}

	public String getStartDateBilled() {
		return startDateBilled;
	}

	public void setStartDateBilled(String startDateBilled) {
		this.startDateBilled = startDateBilled;
	}

	public String getEndDateBilled() {
		return endDateBilled;
	}

	public void setEndDateBilled(String endDateBilled) {
		this.endDateBilled = endDateBilled;
	}

	public List<String> getBbcList() {
		return bbcList;
	}

	public void setBbcList(List<String> bbcList) {
		this.bbcList = bbcList;
	}

	public List<String> getLocationTypeList() {
		return locationTypeList;
	}

	public void setLocationTypeList(List<String> locationTypeList) {
		this.locationTypeList = locationTypeList;
	}

	public List<String> getProviderNameList() {
		return providerNameList;
	}

	public void setProviderNameList(List<String> providerNameList) {
		this.providerNameList = providerNameList;
	}

	public String getStartGuidanceDate() {
		return startGuidanceDate;
	}

	public void setStartGuidanceDate(String startGuidanceDate) {
		this.startGuidanceDate = startGuidanceDate;
	}

	public String getEndGuidanceDate() {
		return endGuidanceDate;
	}

	public void setEndGuidanceDate(String endGuidanceDate) {
		this.endGuidanceDate = endGuidanceDate;
	}

	public List<Integer> getCoderId() {
		return coderId;
	}

	public void setCoderId(List<Integer> coderId) {
		this.coderId = coderId;
	}

	public String getCoder() {
		return coder;
	}

	public void setCoder(String coder) {
		this.coder = coder;
	}

	public Timestamp getGuidanceDate() {
		return guidanceDate;
	}

	public void setGuidanceDate(Timestamp guidanceDate) {
		this.guidanceDate = guidanceDate;
	}

	public String getNosOfDays() {
		return nosOfDays;
	}

	public void setNosOfDays(String nosOfDays) {
		this.nosOfDays = nosOfDays;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Timestamp getDateBilled() {
		return dateBilled;
	}

	public void setDateBilled(Timestamp dateBilled) {
		this.dateBilled = dateBilled;
	}

	public String getPrimaryProvider() {
		return primaryProvider;
	}

	public void setPrimaryProvider(String primaryProvider) {
		this.primaryProvider = primaryProvider;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getAuditNote() {
		return auditNote;
	}

	public void setAuditNote(String auditNote) {
		this.auditNote = auditNote;
	}

	public String getChartCodes() {
		return chartCodes;
	}

	public void setChartCodes(String chartCodes) {
		this.chartCodes = chartCodes;
	}

	public String getCodingErrors() {
		return codingErrors;
	}

	public void setCodingErrors(String codingErrors) {
		this.codingErrors = codingErrors;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getCoderName() {
		return coderName;
	}

	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public boolean getCodingError() {
		return codingError;
	}

	public void setCodingError(boolean codingError) {
		this.codingError = codingError;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	@Override
	public String toString() {
		return "ReportFilterReq [coderName=" + coderName + ", codingTeam=" + codingTeam + ", visitId=" + visitId
				+ ", providerName=" + providerName + ", bbc=" + bbc + ", dateOfService=" + dateOfService
				+ ", codingError=" + codingError + ", filterOptions=" + filterOptions + ", filters=" + filters
				+ ", startDOSDate=" + startDOSDate + ", endDOSDate=" + endDOSDate + ", sortBy=" + sortBy
				+ ", codingErrors=" + codingErrors + ", order=" + order + ", index=" + index + ", auditNote="
				+ auditNote + ", chartCodes=" + chartCodes + ", facilityName=" + facilityName + ", patientName="
				+ patientName + ", primaryProvider=" + primaryProvider + ", dateBilled=" + dateBilled + ", endDate="
				+ endDate + ", startDate=" + startDate + ", coder=" + coder + ", guidanceDate=" + guidanceDate
				+ ", nosOfDays=" + nosOfDays + ", facility=" + facility + ", coderId=" + coderId
				+ ", startGuidanceDate=" + startGuidanceDate + ", endGuidanceDate=" + endGuidanceDate + ", bbcList="
				+ bbcList + ", locationTypeList=" + locationTypeList + ", providerNameList=" + providerNameList
				+ ", startDateBilled=" + startDateBilled + ", endDateBilled=" + endDateBilled + ", dos=" + dos
				+ ", facilityId=" + facilityId + ", providerId=" + providerId + ", bluebookId=" + bluebookId
				+ ", daysInGuidance=" + daysInGuidance + ", coderFullName=" + coderFullName + ", blueBookId="
				+ blueBookId + ", facilityIdList=" + facilityIdList + ", providerIdList=" + providerIdList
				+ ", elapsedTime=" + elapsedTime + ", mrn=" + mrn + ", statusList=" + statusList + ", status=" + status
				+ ", filterName=" + filterName + "]";
	}

}
