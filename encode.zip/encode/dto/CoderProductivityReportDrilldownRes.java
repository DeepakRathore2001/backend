package com.healogics.encode.dto;

import java.util.List;

public class CoderProductivityReportDrilldownRes {
	
	private String responseCode;
	private String responseMessage;
	private List<CoderProductivityReportDrilldownData> dataList;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<CoderProductivityReportDrilldownData> getDataList() {
		return dataList;
	}
	public void setDataList(List<CoderProductivityReportDrilldownData> dataList) {
		this.dataList = dataList;
	}
	@Override
	public String toString() {
		return "CoderProductivityReportDrilldownRes [responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + ", dataList=" + dataList + "]";
	}

}
