package com.healogics.encode.dto;

import java.util.Date;
import java.util.List;

public class SuperbillVarianceReportData {

	private String bluebookId;
	private long visitId;
	private int facilityId;
	private int providerId;
	private String facilityName;
	private String providerName;
	private Date DOS;
	private String patientName;
	private Date dateBilled;
	private String potentialCptCode;
	private String actualCptCode;
	private List<String> varianceReason;
	private String comment;
	
	public Date getDOS() {
		return DOS;
	}

	public void setDOS(Date dOS) {
		DOS = dOS;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getDateBilled() {
		return dateBilled;
	}

	public void setDateBilled(Date dateBilled) {
		this.dateBilled = dateBilled;
	}

	public String getPotentialCptCode() {
		return potentialCptCode;
	}

	public void setPotentialCptCode(String potentialCptCode) {
		this.potentialCptCode = potentialCptCode;
	}

	public String getActualCptCode() {
		return actualCptCode;
	}

	public void setActualCptCode(String actualCptCode) {
		this.actualCptCode = actualCptCode;
	}

	
	public List<String> getVarianceReason() {
		return varianceReason;
	}

	public void setVarianceReason(List<String> varianceReason) {
		this.varianceReason = varianceReason;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	@Override
	public String toString() {
		return "SuperbillVarianceReportData [bluebookId=" + bluebookId + ", visitId=" + visitId + ", facilityId="
				+ facilityId + ", providerId=" + providerId + ", facilityName=" + facilityName + ", providerName="
				+ providerName + ", DOS=" + DOS + ", patientName=" + patientName + ", dateBilled=" + dateBilled
				+ ", potentialCptCode=" + potentialCptCode + ", actualCptCode=" + actualCptCode + ", varianceReason="
				+ varianceReason + ", comment=" + comment + "]";
	}

}
