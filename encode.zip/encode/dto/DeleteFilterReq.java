package com.healogics.encode.dto;

import java.util.List;

public class DeleteFilterReq {

	private List<Integer> filterId;

	public List<Integer> getFilterId() {
		return filterId;
	}

	public void setFilterId(List<Integer> filterId) {
		this.filterId = filterId;
	}

	@Override
	public String toString() {
		return "DeleteFilterReq [filterId=" + filterId + "]";
	}

}
