package com.healogics.encode.dto;

import java.sql.Timestamp;

public class InsuranceCarrierList {

	private int id;
	private String insuranceDescription;
	private Boolean deleteFlag;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInsuranceDescription() {
		return insuranceDescription;
	}

	public void setInsuranceDescription(String insuranceDescription) {
		this.insuranceDescription = insuranceDescription;
	}

	public Boolean getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "InsuranceCarrierList [id=" + id + ", insuranceDescription=" + insuranceDescription + ", deleteFlag="
				+ deleteFlag + ", createdTimestamp=" + createdTimestamp + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + "]";
	}

}
