package com.healogics.encode.dto;

public class FacilityObj {

	private Integer facilityId;
	private String facilityName;
	private String bluebookId;
	private String location;
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Integer getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	@Override
	public String toString() {
		return "FacilityObj [facilityId=" + facilityId + ", facilityName=" + facilityName + ", bluebookId=" + bluebookId
				+ ", location=" + location + "]";
	}

}
