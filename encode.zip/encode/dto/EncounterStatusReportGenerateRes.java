package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

public class EncounterStatusReportGenerateRes {

	private String responseCode;
	private String responseMessage;
	private long totalCounts;
	private List<Data> dataList;
	private GrandTotal grandTotal;

	public static class Data {

		private LocalDate dateOfService;
		private String bluebookId;
		private int total;
		int PatientsOnSchedule;
		private int received;
		private int ready;
		private int deficiency;
		private int inReview;
		private int completed;
		private int sent;
		private int unbillable;
		private int returned;
		private int pending;
		private int pendingSuperbill;
		
		public int getPendingSuperbill() {
			return pendingSuperbill;
		}

		public void setPendingSuperbill(int pendingSuperbill) {
			this.pendingSuperbill = pendingSuperbill;
		}

		public int getPending() {
			return pending;
		}

		public void setPending(int pending) {
			this.pending = pending;
		}

		public int getReturned() {
			return returned;
		}

		public void setReturned(int returned) {
			this.returned = returned;
		}

		public String getBluebookId() {
			return bluebookId;
		}

		public void setBluebookId(String bluebookId) {
			this.bluebookId = bluebookId;
		}

		public int getDeficiency() {
			return deficiency;
		}

		public void setDeficiency(int deficiency) {
			this.deficiency = deficiency;
		}

		public int getPatientsOnSchedule() {
			return PatientsOnSchedule;
		}

		public void setPatientsOnSchedule(int patientsOnSchedule) {
			PatientsOnSchedule = patientsOnSchedule;
		}

		public int getTotal() {
			return total;
		}

		public void setTotal(int total) {
			this.total = total;
		}

		public int getInReview() {
			return inReview;
		}

		public void setInReview(int inReview) {
			this.inReview = inReview;
		}

		public LocalDate getDateOfService() {
			return dateOfService;
		}

		public void setDateOfService(LocalDate dateOfService) {
			this.dateOfService = dateOfService;
		}

		public int getReceived() {
			return received;
		}

		public void setReceived(int received) {
			this.received = received;
		}

		public int getReady() {
			return ready;
		}

		public void setReady(int ready) {
			this.ready = ready;
		}

		public int getCompleted() {
			return completed;
		}

		public void setCompleted(int completed) {
			this.completed = completed;
		}

		public int getSent() {
			return sent;
		}

		public void setSent(int sent) {
			this.sent = sent;
		}

		public int getUnbillable() {
			return unbillable;
		}

		public void setUnbillable(int unbillable) {
			this.unbillable = unbillable;
		}

		@Override
		public String toString() {
			return "Data [dateOfService=" + dateOfService + ", bluebookId=" + bluebookId + ", total=" + total
					+ ", PatientsOnSchedule=" + PatientsOnSchedule + ", received=" + received + ", ready=" + ready
					+ ", deficiency=" + deficiency + ", inReview=" + inReview + ", completed=" + completed + ", sent="
					+ sent + ", unbillable=" + unbillable + ", returned=" + returned + ", pending=" + pending
					+ ", pendingSuperbill=" + pendingSuperbill + "]";
		}

	}

	public static class GrandTotal {
		private int overallTotal;
		int totalPatientsOnSchedule;
		private int totalReceived;
		private int totalReady;
		private int totalDeficiency;
		private int totalInReview;
		private int totalCompleted;
		private int totalSent;
		private int totalUnbillable;
		private int totalReturned;
		private int totalPending;
		private int totalPendingSuberbill;
		
		public int getTotalPendingSuberbill() {
			return totalPendingSuberbill;
		}

		public void setTotalPendingSuberbill(int totalPendingSuberbill) {
			this.totalPendingSuberbill = totalPendingSuberbill;
		}

		public int getTotalPending() {
			return totalPending;
		}

		public void setTotalPending(int totalPending) {
			this.totalPending = totalPending;
		}

		public int getTotalReturned() {
			return totalReturned;
		}

		public void setTotalReturned(int totalReturned) {
			this.totalReturned = totalReturned;
		}

		public int getOverallTotal() {
			return overallTotal;
		}

		public void setOverallTotal(int overallTotal) {
			this.overallTotal = overallTotal;
		}

		public int getTotalPatientsOnSchedule() {
			return totalPatientsOnSchedule;
		}

		public void setTotalPatientsOnSchedule(int totalPatientsOnSchedule) {
			this.totalPatientsOnSchedule = totalPatientsOnSchedule;
		}

		public int getTotalReceived() {
			return totalReceived;
		}

		public void setTotalReceived(int totalReceived) {
			this.totalReceived = totalReceived;
		}

		public int getTotalReady() {
			return totalReady;
		}

		public void setTotalReady(int totalReady) {
			this.totalReady = totalReady;
		}

		public int getTotalDeficiency() {
			return totalDeficiency;
		}

		public void setTotalDeficiency(int totalDeficiency) {
			this.totalDeficiency = totalDeficiency;
		}

		public int getTotalInReview() {
			return totalInReview;
		}

		public void setTotalInReview(int totalInReview) {
			this.totalInReview = totalInReview;
		}

		public int getTotalCompleted() {
			return totalCompleted;
		}

		public void setTotalCompleted(int totalCompleted) {
			this.totalCompleted = totalCompleted;
		}

		public int getTotalSent() {
			return totalSent;
		}

		public void setTotalSent(int totalSent) {
			this.totalSent = totalSent;
		}

		public int getTotalUnbillable() {
			return totalUnbillable;
		}

		public void setTotalUnbillable(int totalUnbillable) {
			this.totalUnbillable = totalUnbillable;
		}

		@Override
		public String toString() {
			return "GrandTotal [overallTotal=" + overallTotal + ", totalPatientsOnSchedule=" + totalPatientsOnSchedule
					+ ", totalReceived=" + totalReceived + ", totalReady=" + totalReady + ", totalDeficiency="
					+ totalDeficiency + ", totalInReview=" + totalInReview + ", totalCompleted=" + totalCompleted
					+ ", totalSent=" + totalSent + ", totalUnbillable=" + totalUnbillable + ", totalReturned="
					+ totalReturned + ", totalPending=" + totalPending + ", totalPendingSuberbill="
					+ totalPendingSuberbill + "]";
		}

	}

	public GrandTotal getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(GrandTotal grandTotal) {
		this.grandTotal = grandTotal;
	}

	public long getTotalCounts() {
		return totalCounts;
	}

	public void setTotalCounts(long totalCounts) {
		this.totalCounts = totalCounts;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<Data> getDataList() {
		return dataList;
	}

	public void setDataList(List<Data> dataList) {
		this.dataList = dataList;
	}

	@Override
	public String toString() {
		return "EncounterStatusReportGenerateRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", totalCounts=" + totalCounts + ", dataList=" + dataList + ", grandTotal=" + grandTotal + "]";
	}

}
