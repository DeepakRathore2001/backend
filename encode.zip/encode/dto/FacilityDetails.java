package com.healogics.encode.dto;

import java.util.Objects;

public class FacilityDetails {
	private String facilityId;
	private String facilityBluebookId;
	private String facilityName;
	private String ihealConfig;

	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityBluebookId() {
		return facilityBluebookId;
	}
	public void setFacilityBluebookId(String facilityBluebookId) {
		this.facilityBluebookId = facilityBluebookId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	
	public String getIhealConfig() {
		return ihealConfig;
	}
	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FacilityDetails that = (FacilityDetails) o;
        return Objects.equals(facilityId, that.facilityId);
    }
 
    @Override
    public int hashCode() {
        return Objects.hash(facilityId);
    }

	@Override
	public String toString() {
		return "FacilityDetails [facilityId=" + facilityId + ", facilityBluebookId=" + facilityBluebookId
				+ ", facilityName=" + facilityName + ", ihealConfig=" + ihealConfig + "]";
	}
}

