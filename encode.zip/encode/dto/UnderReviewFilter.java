package com.healogics.encode.dto;

import java.util.List;

public class UnderReviewFilter {

	private List<String> options;

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}

	@Override
	public String toString() {
		return "UnderReviewFilter [options=" + options + "]";
	}

}
