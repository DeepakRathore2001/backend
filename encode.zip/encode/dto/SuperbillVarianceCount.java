package com.healogics.encode.dto;

public class SuperbillVarianceCount {

	private String bluebookId;
	private String facilityName;
	private int facilityId;
	private int providerId;
	private String providerName;

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	private int totalVariance;

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public int getTotalVariance() {
		return totalVariance;
	}

	public void setTotalVariance(int totalVariance) {
		this.totalVariance = totalVariance;
	}

	@Override
	public String toString() {
		return "SuperbillVarianceCount [bluebookId=" + bluebookId + ", facilityName=" + facilityName + ", facilityId="
				+ facilityId + ", providerId=" + providerId + ", providerName=" + providerName + ", totalVariance="
				+ totalVariance + "]";
	}

}
