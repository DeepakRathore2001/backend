package com.healogics.encode.dto;

import java.util.List;

public class DrillDownMonthlyChargeSummaryRes extends APIResponse {

	private List<DrillDownMonthlyChargeSummaryObj> report;

	public List<DrillDownMonthlyChargeSummaryObj> getReport() {
		return report;
	}

	public void setReport(List<DrillDownMonthlyChargeSummaryObj> report) {
		this.report = report;
	}

	@Override
	public String toString() {
		return "DrillDownMonthlyChargeSummaryRes [report=" + report + "]";
	}

}
