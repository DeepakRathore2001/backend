package com.healogics.encode.dto;

import java.util.List;

public class ChartValidationRes extends APIResponse {
	private List<ChartValidation> validations;
	private String finthriveAPIError;
	
	public String getFinthriveAPIError() {
		return finthriveAPIError;
	}

	public void setFinthriveAPIError(String finthriveAPIError) {
		this.finthriveAPIError = finthriveAPIError;
	}

	public List<ChartValidation> getValidations() {
		return validations;
	}

	public void setValidations(List<ChartValidation> validations) {
		this.validations = validations;
	}

	@Override
	public String toString() {
		return "ChartValidationRes [validations=" + validations
				+ ", finthriveAPIError=" + finthriveAPIError + "]";
	}
}
