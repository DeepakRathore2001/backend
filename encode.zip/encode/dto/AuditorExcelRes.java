package com.healogics.encode.dto;

import java.util.List;

public class AuditorExcelRes extends APIResponse {

	private String responseCode;
	private String responseMessage;
	private List<AuditorExcelData> collapsibleSection;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<AuditorExcelData> getCollapsibleSection() {
		return collapsibleSection;
	}

	public void setCollapsibleSection(List<AuditorExcelData> collapsibleSection) {
		this.collapsibleSection = collapsibleSection;
	}

	@Override
	public String toString() {
		return "AuditorExcelRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", collapsibleSection=" + collapsibleSection + "]";
	}

}
