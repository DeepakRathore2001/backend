package com.healogics.encode.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealWound {

	private String woundNumber;
	private String alternateWoundNumber;
	private int statusCode;
	private String statusDescription;
	private int LocationCode;
	private String locationDescription;
	private int primaryEtiologyCode;
	private String primaryEtiologyDescription;
	private int secondaryEtiologyCode;
	private String secondaryEtiologyDescriptions;
	private boolean activeWound;
	private String firstAssessmentDate;
	private String lastAssessmentDate;
	private IHealDocumentObj document;

	private String leftRight;
	@JsonProperty("Circumferential")
	private boolean circumferential;
	private String dorsalPlantar;
	private String medialLateral;
	private String anteriorPosterior;
	private String proximalDistal;
	private String inferiorSuperior;

	public boolean isCircumferential() {
		return circumferential;
	}

	public void setCircumferential(boolean circumferential) {
		this.circumferential = circumferential;
	}

	public String getDorsalPlantar() {
		return dorsalPlantar;
	}

	public void setDorsalPlantar(String dorsalPlantar) {
		this.dorsalPlantar = dorsalPlantar;
	}

	public String getMedialLateral() {
		return medialLateral;
	}

	public void setMedialLateral(String medialLateral) {
		this.medialLateral = medialLateral;
	}

	public String getAnteriorPosterior() {
		return anteriorPosterior;
	}

	public void setAnteriorPosterior(String anteriorPosterior) {
		this.anteriorPosterior = anteriorPosterior;
	}

	public String getProximalDistal() {
		return proximalDistal;
	}

	public void setProximalDistal(String proximalDistal) {
		this.proximalDistal = proximalDistal;
	}

	public String getInferiorSuperior() {
		return inferiorSuperior;
	}

	public void setInferiorSuperior(String inferiorSuperior) {
		this.inferiorSuperior = inferiorSuperior;
	}

	public String getLeftRight() {
		return leftRight;
	}

	public void setLeftRight(String leftRight) {
		this.leftRight = leftRight;
	}

	public String getWoundNumber() {
		return woundNumber;
	}

	public void setWoundNumber(String woundNumber) {
		this.woundNumber = woundNumber;
	}

	public String getAlternateWoundNumber() {
		return alternateWoundNumber;
	}

	public void setAlternateWoundNumber(String alternateWoundNumber) {
		this.alternateWoundNumber = alternateWoundNumber;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public int getLocationCode() {
		return LocationCode;
	}

	public void setLocationCode(int locationCode) {
		LocationCode = locationCode;
	}

	public String getLocationDescription() {
		return locationDescription;
	}

	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

	public int getPrimaryEtiologyCode() {
		return primaryEtiologyCode;
	}

	public void setPrimaryEtiologyCode(int primaryEtiologyCode) {
		this.primaryEtiologyCode = primaryEtiologyCode;
	}

	public String getPrimaryEtiologyDescription() {
		return primaryEtiologyDescription;
	}

	public void setPrimaryEtiologyDescription(String primaryEtiologyDescription) {
		this.primaryEtiologyDescription = primaryEtiologyDescription;
	}

	public int getSecondaryEtiologyCode() {
		return secondaryEtiologyCode;
	}

	public void setSecondaryEtiologyCode(int secondaryEtiologyCode) {
		this.secondaryEtiologyCode = secondaryEtiologyCode;
	}

	public String getSecondaryEtiologyDescriptions() {
		return secondaryEtiologyDescriptions;
	}

	public void setSecondaryEtiologyDescriptions(String secondaryEtiologyDescriptions) {
		this.secondaryEtiologyDescriptions = secondaryEtiologyDescriptions;
	}

	public boolean isActiveWound() {
		return activeWound;
	}

	public void setActiveWound(boolean activeWound) {
		this.activeWound = activeWound;
	}

	public String getFirstAssessmentDate() {
		return firstAssessmentDate;
	}

	public void setFirstAssessmentDate(String firstAssessmentDate) {
		this.firstAssessmentDate = firstAssessmentDate;
	}

	public String getLastAssessmentDate() {
		return lastAssessmentDate;
	}

	public void setLastAssessmentDate(String lastAssessmentDate) {
		this.lastAssessmentDate = lastAssessmentDate;
	}

	public IHealDocumentObj getDocument() {
		return document;
	}

	public void setDocument(IHealDocumentObj document) {
		this.document = document;
	}

	@Override
	public String toString() {
		return "IHealWound [woundNumber=" + woundNumber + ", alternateWoundNumber=" + alternateWoundNumber
				+ ", statusCode=" + statusCode + ", statusDescription=" + statusDescription + ", LocationCode="
				+ LocationCode + ", locationDescription=" + locationDescription + ", primaryEtiologyCode="
				+ primaryEtiologyCode + ", primaryEtiologyDescription=" + primaryEtiologyDescription
				+ ", secondaryEtiologyCode=" + secondaryEtiologyCode + ", secondaryEtiologyDescriptions="
				+ secondaryEtiologyDescriptions + ", activeWound=" + activeWound + ", firstAssessmentDate="
				+ firstAssessmentDate + ", lastAssessmentDate=" + lastAssessmentDate + ", document=" + document
				+ ", leftRight=" + leftRight + ", circumferential=" + circumferential + ", dorsalPlantar="
				+ dorsalPlantar + ", medialLateral=" + medialLateral + ", anteriorPosterior=" + anteriorPosterior
				+ ", proximalDistal=" + proximalDistal + ", inferiorSuperior=" + inferiorSuperior + "]";
	}

}
