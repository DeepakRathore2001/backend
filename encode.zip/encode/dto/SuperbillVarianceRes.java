package com.healogics.encode.dto;

import java.util.List;

public class SuperbillVarianceRes {

	private String responseCode;
	private String responseMessage;
	private List<SuperbillVarianceCount> dataList;
	private int total;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<SuperbillVarianceCount> getDataList() {
		return dataList;
	}

	public void setDataList(List<SuperbillVarianceCount> dataList) {
		this.dataList = dataList;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "SuperbillVarianceRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", dataList=" + dataList + ", total=" + total + "]";
	}

}
