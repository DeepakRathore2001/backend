package com.healogics.encode.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CPTObj {
	private String cptCode;
	private String cptName;
	private List<String> modifier;
	private int unit;
	private List<ICD10Data> selectedICDs;

	public String getCptCode() {
		return cptCode;
	}

	public void setCptCode(String cptCode) {
		this.cptCode = cptCode;
	}

	public String getCptName() {
		return cptName;
	}

	public void setCptName(String cptName) {
		this.cptName = cptName;
	}

	public List<String> getModifier() {
		return modifier;
	}

	public void setModifier(List<String> modifier) {
		this.modifier = modifier;
	}

	public int getUnit() {
		return unit;
	}

	public void setUnit(int unit) {
		this.unit = unit;
	}

	public List<ICD10Data> getSelectedICDs() {
		return selectedICDs;
	}

	public void setSelectedICDs(List<ICD10Data> selectedICDs) {
		this.selectedICDs = selectedICDs;
	}

	@Override
	public String toString() {
		return "CPTObj [cptCode=" + cptCode + ", cptName=" + cptName + ", modifier=" + modifier + ", unit=" + unit
				+ ", selectedICDs=" + selectedICDs + "]";
	}

}
