package com.healogics.encode.dto;

public class DocumentURLReq {

	private int userId;
	private String masterToken;
	private String documentId;
	private String facilityId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	@Override
	public String toString() {
		return "DocumentURLReq [userId=" + userId + ", masterToken=" + masterToken + ", documentId=" + documentId
				+ ", facilityId=" + facilityId + "]";
	}

}
