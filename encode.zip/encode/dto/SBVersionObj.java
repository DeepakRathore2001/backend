package com.healogics.encode.dto;

public class SBVersionObj {

	private String versionId;
	private String sbProviderFirstName;
	private String sbProviderLastName;
	private String sbEventDateTime;
	private String providerId;
	
	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public String getSbProviderFirstName() {
		return sbProviderFirstName;
	}

	public void setSbProviderFirstName(String sbProviderFirstName) {
		this.sbProviderFirstName = sbProviderFirstName;
	}

	public String getSbProviderLastName() {
		return sbProviderLastName;
	}

	public void setSbProviderLastName(String sbProviderLastName) {
		this.sbProviderLastName = sbProviderLastName;
	}

	public String getSbEventDateTime() {
		return sbEventDateTime;
	}

	public void setSbEventDateTime(String sbEventDateTime) {
		this.sbEventDateTime = sbEventDateTime;
	}

	@Override
	public String toString() {
		return "SBVersionObj [versionId=" + versionId + ", sbProviderFirstName=" + sbProviderFirstName
				+ ", sbProviderLastName=" + sbProviderLastName + ", sbEventDateTime=" + sbEventDateTime
				+ ", providerId=" + providerId + "]";
	}

}
