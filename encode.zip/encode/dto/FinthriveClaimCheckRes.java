package com.healogics.encode.dto;

import java.util.List;

public class FinthriveClaimCheckRes {
	private int id;
	private List<FinthriveProcedureRes> procedures;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<FinthriveProcedureRes> getProcedures() {
		return procedures;
	}

	public void setProcedures(List<FinthriveProcedureRes> procedures) {
		this.procedures = procedures;
	}

	@Override
	public String toString() {
		return "FinthriveClaimCheckRes [id=" + id + ", procedures=" + procedures + "]";
	}

}
