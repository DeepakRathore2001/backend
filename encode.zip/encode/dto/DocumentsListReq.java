package com.healogics.encode.dto;

public class DocumentsListReq {

	private String masterToken;
	private String privateKey;
	private String userId;
	private String facilityId;
	private String patientId;
	private String startDate;
	private String endDate;
	private String woundDocumentEntityId;
	private boolean activeOnly;

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getWoundDocumentEntityId() {
		return woundDocumentEntityId;
	}

	public void setWoundDocumentEntityId(String woundDocumentEntityId) {
		this.woundDocumentEntityId = woundDocumentEntityId;
	}

	public boolean isActiveOnly() {
		return activeOnly;
	}

	public void setActiveOnly(boolean activeOnly) {
		this.activeOnly = activeOnly;
	}

	@Override
	public String toString() {
		return "DocumentsListReq [masterToken=" + masterToken + ", privateKey=" + privateKey + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId + ", startDate=" + startDate + ", endDate="
				+ endDate + ", woundDocumentEntityId=" + woundDocumentEntityId + ", activeOnly=" + activeOnly + "]";
	}

}
