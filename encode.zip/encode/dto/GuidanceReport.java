package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class GuidanceReport {

	private int coderId;
	private String coderFullName;
	private Timestamp guidanceDate;
	private int daysInGuidance;
	private int facilityId;
	private String blueBookId;
	private Date dateOfService;
	private long visitId;
	private String reviewReason;
	private String notes;

	public int getCoderId() {
		return coderId;
	}

	public void setCoderId(int coderId) {
		this.coderId = coderId;
	}

	public String getCoderFullName() {
		return coderFullName;
	}

	public void setCoderFullName(String coderFullName) {
		this.coderFullName = coderFullName;
	}

	public Timestamp getGuidanceDate() {
		return guidanceDate;
	}

	public void setGuidanceDate(Timestamp guidanceDate) {
		this.guidanceDate = guidanceDate;
	}

	public int getDaysInGuidance() {
		return daysInGuidance;
	}

	public void setDaysInGuidance(int daysInGuidance) {
		this.daysInGuidance = daysInGuidance;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBlueBookId() {
		return blueBookId;
	}

	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getReviewReason() {
		return reviewReason;
	}

	public void setReviewReason(String reviewReason) {
		this.reviewReason = reviewReason;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	@Override
	public String toString() {
		return "GuidanceReport [coderId=" + coderId + ", coderFullName=" + coderFullName + ", guidanceDate="
				+ guidanceDate + ", daysInGuidance=" + daysInGuidance + ", facilityId=" + facilityId + ", blueBookId="
				+ blueBookId + ", dateOfService=" + dateOfService + ", visitId=" + visitId + ", reviewReason="
				+ reviewReason + ", notes=" + notes + "]";
	}

}
