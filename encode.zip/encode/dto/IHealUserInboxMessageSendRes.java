package com.healogics.encode.dto;

import java.util.List;

public class IHealUserInboxMessageSendRes {
	private String errorCode;
	private String errorMessage;
	private List<IHealInboxMessageMini> inboxMessages;
	private List<Integer> recipientsUndelivered;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<IHealInboxMessageMini> getInboxMessages() {
		return inboxMessages;
	}

	public void setInboxMessages(List<IHealInboxMessageMini> inboxMessages) {
		this.inboxMessages = inboxMessages;
	}

	public List<Integer> getRecipientsUndelivered() {
		return recipientsUndelivered;
	}

	public void setRecipientsUndelivered(List<Integer> recipientsUndelivered) {
		this.recipientsUndelivered = recipientsUndelivered;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageSendRes [errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", inboxMessages=" + inboxMessages + ", recipientsUndelivered=" + recipientsUndelivered + "]";
	}
}
