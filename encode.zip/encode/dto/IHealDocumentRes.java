package com.healogics.encode.dto;

import java.util.Map;

public class IHealDocumentRes {
	
	private Map<String, Object> document;

	private String responseCode;
	private String responseMessage;

	public Map<String, Object> getDocument() {
		return document;
	}
	public void setDocument(
			Map<String, Object> document) {
		this.document = document;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "IHealDocumentRes [document=" + document + ", responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + "]";
	}


}
