package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class GuidanceReportReq {
	
	
	private String coderName;
	private String codingTeam;
	private String visitId;
	private String providerName;
	private String bbc;
	private Timestamp dateOfService;
	private boolean codingError;
	private String filterOptions;
	private String filters;
	private String startDOSDate;
	private String endDOSDate;
	private String sortBy;
	private String codingErrors;
	private int order;
	private int index;
	private String auditNote;
	private String chartCodes;
	private String facilityName;
	private String patientName;
	private String primaryProvider;
	private Timestamp dateBilled;
	private Date endDate;
	private Date startDate;
	
	private String coder;
	private Timestamp gudianceDate;
	private String nosOfDays;
	private String facility;
	private List<Integer> coderId;
	private String startGuidanceDate;
	private String endGuidanceDate;
	private String daysInGuidance;
	private String blueBookId;
	private Date startDateOfService;
	private Date endDateOfService;
	private String coderFullName;

	public String getCoderFullName() {
		return coderFullName;
	}

	public void setCoderFullName(String coderFullName) {
		this.coderFullName = coderFullName;
	}

	public String getCoderName() {
		return coderName;
	}

	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public boolean isCodingError() {
		return codingError;
	}

	public void setCodingError(boolean codingError) {
		this.codingError = codingError;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getCodingErrors() {
		return codingErrors;
	}

	public void setCodingErrors(String codingErrors) {
		this.codingErrors = codingErrors;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getAuditNote() {
		return auditNote;
	}

	public void setAuditNote(String auditNote) {
		this.auditNote = auditNote;
	}

	public String getChartCodes() {
		return chartCodes;
	}

	public void setChartCodes(String chartCodes) {
		this.chartCodes = chartCodes;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPrimaryProvider() {
		return primaryProvider;
	}

	public void setPrimaryProvider(String primaryProvider) {
		this.primaryProvider = primaryProvider;
	}

	public Timestamp getDateBilled() {
		return dateBilled;
	}

	public void setDateBilled(Timestamp dateBilled) {
		this.dateBilled = dateBilled;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getCoder() {
		return coder;
	}

	public void setCoder(String coder) {
		this.coder = coder;
	}

	public Timestamp getGudianceDate() {
		return gudianceDate;
	}

	public void setGudianceDate(Timestamp gudianceDate) {
		this.gudianceDate = gudianceDate;
	}

	public String getNosOfDays() {
		return nosOfDays;
	}

	public void setNosOfDays(String nosOfDays) {
		this.nosOfDays = nosOfDays;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public String getStartGuidanceDate() {
		return startGuidanceDate;
	}

	public void setStartGuidanceDate(String startGuidanceDate) {
		this.startGuidanceDate = startGuidanceDate;
	}

	public String getEndGuidanceDate() {
		return endGuidanceDate;
	}

	public void setEndGuidanceDate(String endGuidanceDate) {
		this.endGuidanceDate = endGuidanceDate;
	}

	public List<Integer> getCoderId() {
		return coderId;
	}

	public void setCoderId(List<Integer> coderId) {
		this.coderId = coderId;
	}
 
	

	

	public String getDaysInGuidance() {
		return daysInGuidance;
	}

	public void setDaysInGuidance(String daysInGuidance) {
		this.daysInGuidance = daysInGuidance;
	}

	public String getBlueBookId() {
		return blueBookId;
	}

	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}

	public Date getStartDateOfService() {
		return startDateOfService;
	}

	public void setStartDateOfService(Date startDateOfService) {
		this.startDateOfService = startDateOfService;
	}

	public Date getEndDateOfService() {
		return endDateOfService;
	}

	public void setEndDateOfService(Date endDateOfService) {
		this.endDateOfService = endDateOfService;
	}

	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	@Override
	public String toString() {
		return "GuidanceReportReq [coderName=" + coderName + ", codingTeam=" + codingTeam + ", visitId=" + visitId
				+ ", providerName=" + providerName + ", bbc=" + bbc + ", dateOfService=" + dateOfService
				+ ", codingError=" + codingError + ", filterOptions=" + filterOptions + ", filters=" + filters
				+ ", startDOSDate=" + startDOSDate + ", endDOSDate=" + endDOSDate + ", sortBy=" + sortBy
				+ ", codingErrors=" + codingErrors + ", order=" + order + ", index=" + index + ", auditNote="
				+ auditNote + ", chartCodes=" + chartCodes + ", facilityName=" + facilityName + ", patientName="
				+ patientName + ", primaryProvider=" + primaryProvider + ", dateBilled=" + dateBilled + ", endDate="
				+ endDate + ", startDate=" + startDate + ", coder=" + coder + ", gudianceDate=" + gudianceDate
				+ ", nosOfDays=" + nosOfDays + ", facility=" + facility + ", coderId=" + coderId
				+ ", startGuidanceDate=" + startGuidanceDate + ", endGuidanceDate=" + endGuidanceDate
				+ ", daysInGuidance=" + daysInGuidance + ", blueBookId=" + blueBookId + ", startDateOfService="
				+ startDateOfService + ", endDateOfService=" + endDateOfService + ", coderFullName=" + coderFullName
				+ "]";
	}

}
