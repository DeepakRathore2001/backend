package com.healogics.encode.dto;

import java.util.List;

public class IHealUserInboxMessageArchivedSetReq {
	private String privateKey;
	private String masterToken;
	private Integer userId;
	private List<Integer> messages;
	private Boolean statusArchived;
	private Boolean statusRead;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public List<Integer> getMessages() {
		return messages;
	}

	public void setMessages(List<Integer> messages) {
		this.messages = messages;
	}

	public Boolean getStatusArchived() {
		return statusArchived;
	}

	public void setStatusArchived(Boolean statusArchived) {
		this.statusArchived = statusArchived;
	}

	public Boolean getStatusRead() {
		return statusRead;
	}

	public void setStatusRead(Boolean statusRead) {
		this.statusRead = statusRead;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageArchivedSetReq [privateKey=" + privateKey
				+ ", masterToken=" + masterToken
				+ ", userId=" + userId
				+ ", messages=" + messages
				+ ", statusArchived=" + statusArchived
				+ ", statusRead=" + statusRead + "]";
	}
}
