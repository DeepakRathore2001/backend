package com.healogics.encode.dto;

public class IHealProviderListReq {

	private String privateKey;
	private String facilityId;
	private String selectionName;
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getSelectionName() {
		return selectionName;
	}
	public void setSelectionName(String selectionName) {
		this.selectionName = selectionName;
	}
	@Override
	public String toString() {
		return "IHealProviderListReq [privateKey=" + privateKey
				+ ", facilityId=" + facilityId + ", selectionName="
				+ selectionName + "]";
	}

}
