package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class AuditorCollapsibleSectionReq {

	private int filterId;
	private String visitId;
	private String bbc;
	private Timestamp dateOfService;
	private String status;
	private String mrn;
	private String patientFirstName;
	private String patientLastName;
	private String insurance;
	private Date dateQueued;
	private String startDOSDate;
	private String endDOSDate;
	private String startDateQueued;
	private String endDateQueued;
	private String assigneeUserName;
	private String assignedNurse;

	private String filterOptions;
	private String filters;
	private List<String> roles;
	
	private int index;
	private int order;
	private String sortBy;
	
	private String userId;
	private String username;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public String getAssignedNurse() {
		return assignedNurse;
	}

	public void setAssignedNurse(String assignedNurse) {
		this.assignedNurse = assignedNurse;
	}

	public String getAssigneeUserName() {
		return assigneeUserName;
	}

	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getStartDateQueued() {
		return startDateQueued;
	}

	public void setStartDateQueued(String startDateQueued) {
		this.startDateQueued = startDateQueued;
	}

	public String getEndDateQueued() {
		return endDateQueued;
	}

	public void setEndDateQueued(String endDateQueued) {
		this.endDateQueued = endDateQueued;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMrn() {
		return mrn;
	}

	public void setMrn(String mrn) {
		this.mrn = mrn;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public Date getDateQueued() {
		return dateQueued;
	}

	public void setDateQueued(Date dateQueued) {
		this.dateQueued = dateQueued;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	@Override
	public String toString() {
		return "AuditorCollapsibleSectionReq [filterId=" + filterId + ", visitId=" + visitId + ", bbc=" + bbc
				+ ", dateOfService=" + dateOfService + ", status=" + status + ", mrn=" + mrn + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName + ", insurance=" + insurance
				+ ", dateQueued=" + dateQueued + ", startDOSDate=" + startDOSDate + ", endDOSDate=" + endDOSDate
				+ ", startDateQueued=" + startDateQueued + ", endDateQueued=" + endDateQueued + ", assigneeUserName="
				+ assigneeUserName + ", assignedNurse=" + assignedNurse + ", filterOptions=" + filterOptions
				+ ", filters=" + filters + ", roles=" + roles + ", index=" + index + ", order=" + order + ", sortBy="
				+ sortBy + ", userId=" + userId + ", username=" + username + "]";
	}

}
