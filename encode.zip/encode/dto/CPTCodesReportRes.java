package com.healogics.encode.dto;

import java.util.List;

public class CPTCodesReportRes extends APIResponse {
	private List<String> codes;

	public List<String> getCodes() {
		return codes;
	}

	public void setCodes(List<String> codes) {
		this.codes = codes;
	}

	@Override
	public String toString() {
		return "CPTCodesReportRes [codes=" + codes + "]";
	}
}
