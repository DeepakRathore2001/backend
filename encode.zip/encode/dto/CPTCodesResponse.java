package com.healogics.encode.dto;

import java.util.List;

public class CPTCodesResponse extends APIResponse {
	private List<CPTCodeDetails> cptCodes;
	private int totalCount;

	public List<CPTCodeDetails> getCptCodes() {
		return cptCodes;
	}
	public void setCptCodes(List<CPTCodeDetails> cptCodes) {
		this.cptCodes = cptCodes;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	@Override
	public String toString() {
		return "CPTCodesResponse [cptCodes=" + cptCodes + ", totalCount="
				+ totalCount + "]";
	}
}
