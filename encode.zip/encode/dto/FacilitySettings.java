package com.healogics.encode.dto;

public class FacilitySettings {
	private int facilityId;
	private String facilityName;
	private String facilityBBC;
	private String facilityType;
	private String facilityConfig;
	private String placeOfService;
	private int campusCode;
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityBBC() {
		return facilityBBC;
	}

	public void setFacilityBBC(String facilityBBC) {
		this.facilityBBC = facilityBBC;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getFacilityConfig() {
		return facilityConfig;
	}

	public void setFacilityConfig(String facilityConfig) {
		this.facilityConfig = facilityConfig;
	}

	public int getCampusCode() {
		return campusCode;
	}

	public void setCampusCode(int campusCode) {
		this.campusCode = campusCode;
	}

	@Override
	public String toString() {
		return "FacilitySettings [facilityId=" + facilityId + ", facilityName=" + facilityName + ", facilityBBC="
				+ facilityBBC + ", facilityType=" + facilityType + ", facilityConfig=" + facilityConfig
				+ ", placeOfService=" + placeOfService + ", campusCode=" + campusCode + ", id=" + id + "]";
	}
}
