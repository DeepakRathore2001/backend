package com.healogics.encode.dto;

import java.util.List;

public class UserNotificationReq {
	private String userId;
	private String lastUpdatedUserFullName;
	private List<String> notificationId;
	private String facilityId;
	private String lastUpdatedUserName;
	private String bluebookCode;

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}
	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}
	public List<String> getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(List<String> notificationId) {
		this.notificationId = notificationId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}
	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}
	public String getBluebookCode() {
		return bluebookCode;
	}
	public void setBluebookCode(String bluebookCode) {
		this.bluebookCode = bluebookCode;
	}
	@Override
	public String toString() {
		return "UserNotificationReq [userId=" + userId + ", lastUpdatedUserFullName=" + lastUpdatedUserFullName
				+ ", notificationId=" + notificationId + ", facilityId=" + facilityId + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", bluebookCode=" + bluebookCode + "]";
	}
}
