package com.healogics.encode.dto;

public class DocumentDeleteRes extends APIResponse {

}
