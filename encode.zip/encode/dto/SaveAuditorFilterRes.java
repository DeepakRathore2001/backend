package com.healogics.encode.dto;

public class SaveAuditorFilterRes extends APIResponse {
}
