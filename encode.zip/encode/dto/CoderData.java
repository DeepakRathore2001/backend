package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class CoderData {

	private String bbc;
	private int facilityId;
	private String facilityName;
	//private Long eCount;
	//private Long count;
	//private Date overDueDate;
	//private Boolean overDueFlag;
	private String ihealConfig;

	private String parentBBC;
	private boolean isSNFLocation;
	private String parentFacilityName;
	
	private Timestamp interfaceDate;
	private long age;
	private long recordAge;
	private String providerName;
	private String providerId;
	private String encounterType;
	private String serviceLine;
	private String chartNotes;
	private Long patientId;
	private String patientName;
	private long visitId;
	private Timestamp dateOfService;
	private String medicalRecordNumber;
	private String status;
	private int isLocked;
	private String userFullName;
	
	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public Timestamp getInterfaceDate() {
		return interfaceDate;
	}

	public void setInterfaceDate(Timestamp interfaceDate) {
		this.interfaceDate = interfaceDate;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public long getRecordAge() {
		return recordAge;
	}

	public void setRecordAge(long recordAge) {
		this.recordAge = recordAge;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getChartNotes() {
		return chartNotes;
	}

	public void setChartNotes(String chartNotes) {
		this.chartNotes = chartNotes;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getParentBBC() {
		return parentBBC;
	}

	public void setParentBBC(String parentBBC) {
		this.parentBBC = parentBBC;
	}

	public boolean isSNFLocation() {
		return isSNFLocation;
	}

	public void setSNFLocation(boolean isSNFLocation) {
		this.isSNFLocation = isSNFLocation;
	}

	public String getParentFacilityName() {
		return parentFacilityName;
	}

	public void setParentFacilityName(String parentFacilityName) {
		this.parentFacilityName = parentFacilityName;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	@Override
	public String toString() {
		return "CoderData [bbc=" + bbc + ", facilityId=" + facilityId + ", facilityName=" + facilityName
				+ ", ihealConfig=" + ihealConfig + ", parentBBC=" + parentBBC + ", isSNFLocation=" + isSNFLocation
				+ ", parentFacilityName=" + parentFacilityName + ", interfaceDate=" + interfaceDate + ", age=" + age
				+ ", recordAge=" + recordAge + ", providerName=" + providerName + ", providerId=" + providerId
				+ ", encounterType=" + encounterType + ", serviceLine=" + serviceLine + ", chartNotes=" + chartNotes
				+ ", patientId=" + patientId + ", patientName=" + patientName + ", visitId=" + visitId
				+ ", dateOfService=" + dateOfService + ", medicalRecordNumber=" + medicalRecordNumber + ", status="
				+ status + ", isLocked=" + isLocked + ", userFullName=" + userFullName + "]";
	}

}
