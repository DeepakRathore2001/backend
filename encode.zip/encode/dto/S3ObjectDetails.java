package com.healogics.encode.dto;

public class S3ObjectDetails {
	private String key;
	private String size;
	private String eTag;
	private String sequencer;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String geteTag() {
		return eTag;
	}

	public void seteTag(String eTag) {
		this.eTag = eTag;
	}

	public String getSequencer() {
		return sequencer;
	}

	public void setSequencer(String sequencer) {
		this.sequencer = sequencer;
	}

	@Override
	public String toString() {
		return "S3ObjectDetails [key=" + key + ", size=" + size + ", eTag=" + eTag + ", sequencer=" + sequencer + "]";
	}
}
