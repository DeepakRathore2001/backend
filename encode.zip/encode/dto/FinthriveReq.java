package com.healogics.encode.dto;

import java.util.List;

public class FinthriveReq {
	private List<FinthriveClaimLookup> claimCheckLookups;

	public List<FinthriveClaimLookup> getClaimCheckLookups() {
		return claimCheckLookups;
	}

	public void setClaimCheckLookups(List<FinthriveClaimLookup> claimCheckLookups) {
		this.claimCheckLookups = claimCheckLookups;
	}

	@Override
	public String toString() {
		return "FinthriveReq [claimCheckLookups=" + claimCheckLookups + "]";
	}
}
