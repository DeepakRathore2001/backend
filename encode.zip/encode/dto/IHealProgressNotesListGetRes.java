package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

public class IHealProgressNotesListGetRes implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private List<IHealDocumentObj> progressnote;
	private String errorCode;
	private String errorMessage;
	private List<IHealErrorDetails> errors;
	private List<IHealErrorDetails> warnings;

	public List<IHealDocumentObj> getProgressnote() {
		return progressnote;
	}
	public void setProgressnote(List<IHealDocumentObj> progressnote) {
		this.progressnote = progressnote;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<IHealErrorDetails> getErrors() {
		return errors;
	}
	public void setErrors(List<IHealErrorDetails> errors) {
		this.errors = errors;
	}
	public List<IHealErrorDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<IHealErrorDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealProgressNotesListGetRes [progressnote=" + progressnote
				+ ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", errors=" + errors + ", warnings=" + warnings + "]";
	}


}
