package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class EncounterUnderReviewData {
	
	private String bluebookId;
	private long visitId;
	private long patientId;
	private String patientName;
	private Long providerId;
	private String providerName;
	private Date deficiencyDate;
	private int daysInReview;
	private Timestamp dateOfService;
	private List<String> deficiencyReason;
	private String deficientNote;
	private String coderFullname;
	private String coderUserId;
	
	
	public String getCoderFullname() {
		return coderFullname;
	}
	public void setCoderFullname(String coderFullname) {
		this.coderFullname = coderFullname;
	}
	public String getCoderUserId() {
		return coderUserId;
	}
	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Date getDeficiencyDate() {
		return deficiencyDate;
	}
	public void setDeficiencyDate(Date deficiencyDate) {
		this.deficiencyDate = deficiencyDate;
	}
	
	public int getDaysInReview() {
		return daysInReview;
	}
	public void setDaysInReview(int daysInReview) {
		this.daysInReview = daysInReview;
	}
	public long getPatientId() {
		return patientId;
	}
	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}
	public Long getProviderId() {
		return providerId;
	}
	public void setProviderId(Long providerId) {
		this.providerId = providerId;
	}
	public Timestamp getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}
	
	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}
	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}
	public String getDeficientNote() {
		return deficientNote;
	}
	public void setDeficientNote(String deficientNote) {
		this.deficientNote = deficientNote;
	}
	@Override
	public String toString() {
		return "EncounterUnderReviewData [bluebookId=" + bluebookId + ", visitId=" + visitId + ", patientId="
				+ patientId + ", patientName=" + patientName + ", providerId=" + providerId + ", providerName="
				+ providerName + ", deficiencyDate=" + deficiencyDate + ", daysInReview=" + daysInReview
				+ ", dateOfService=" + dateOfService + ", deficiencyReason=" + deficiencyReason + ", deficientNote="
				+ deficientNote + ", coderFullname=" + coderFullname + ", coderUserId=" + coderUserId + "]";
	}
	
	

}
