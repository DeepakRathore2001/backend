package com.healogics.encode.dto;

import java.util.List;

public class GuidanceReportRes extends APIResponse {

	private List<GuidanceReport> reportData;

	public List<GuidanceReport> getReportData() {
		return reportData;
	}

	public void setReportData(List<GuidanceReport> reportData) {
		this.reportData = reportData;
	}

	@Override
	public String toString() {
		return "GuidanceReportRes [reportData=" + reportData + "]";
	}

}
