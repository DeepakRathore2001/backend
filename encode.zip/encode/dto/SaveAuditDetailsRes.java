package com.healogics.encode.dto;

public class SaveAuditDetailsRes extends APIResponse {

	private long nextRecordVisitId;

	public long getNextRecordVisitId() {
		return nextRecordVisitId;
	}

	public void setNextRecordVisitId(long nextRecordVisitId) {
		this.nextRecordVisitId = nextRecordVisitId;
	}

	@Override
	public String toString() {
		return "SaveAuditDetailsRes [nextRecordVisitId=" + nextRecordVisitId + "]";
	}

}
