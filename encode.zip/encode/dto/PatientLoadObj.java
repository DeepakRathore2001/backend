package com.healogics.encode.dto;

import java.util.List;

public class PatientLoadObj {
	private String patientId;
	private String patientFirstName;
	private String patientLastName;
	private String patientMiddleName;
	private String patientNumber;
	private String patientDOB;
	private List<InsuranceObj> insurance;
	private String patientSex;
	private String weeksInTreatment;
	private String admissionDate;
	private String preRegistrationDate;
	private String locationId;
	private String locationDescription;
	private String serviceLineId;
	private String serviceLineDescription;
	private String dischargeDate;
	private String dischargeStatusCode;
	private String dischargeStatusDescription;
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getPatientMiddleName() {
		return patientMiddleName;
	}
	public void setPatientMiddleName(String patientMiddleName) {
		this.patientMiddleName = patientMiddleName;
	}
	public String getPatientNumber() {
		return patientNumber;
	}
	public void setPatientNumber(String patientNumber) {
		this.patientNumber = patientNumber;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	public List<InsuranceObj> getInsurance() {
		return insurance;
	}
	public void setInsurance(List<InsuranceObj> insurance) {
		this.insurance = insurance;
	}
	public String getPatientSex() {
		return patientSex;
	}
	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}
	public String getWeeksInTreatment() {
		return weeksInTreatment;
	}
	public void setWeeksInTreatment(String weeksInTreatment) {
		this.weeksInTreatment = weeksInTreatment;
	}
	public String getAdmissionDate() {
		return admissionDate;
	}
	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}
	public String getPreRegistrationDate() {
		return preRegistrationDate;
	}
	public void setPreRegistrationDate(String preRegistrationDate) {
		this.preRegistrationDate = preRegistrationDate;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getLocationDescription() {
		return locationDescription;
	}
	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}
	public String getServiceLineId() {
		return serviceLineId;
	}
	public void setServiceLineId(String serviceLineId) {
		this.serviceLineId = serviceLineId;
	}
	public String getServiceLineDescription() {
		return serviceLineDescription;
	}
	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}
	public String getDischargeDate() {
		return dischargeDate;
	}
	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}
	public String getDischargeStatusCode() {
		return dischargeStatusCode;
	}
	public void setDischargeStatusCode(String dischargeStatusCode) {
		this.dischargeStatusCode = dischargeStatusCode;
	}
	public String getDischargeStatusDescription() {
		return dischargeStatusDescription;
	}
	public void setDischargeStatusDescription(
			String dischargeStatusDescription) {
		this.dischargeStatusDescription = dischargeStatusDescription;
	}
	@Override
	public String toString() {
		return "PatientLoadObj [patientId=" + patientId + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName
				+ ", patientMiddleName=" + patientMiddleName
				+ ", patientNumber=" + patientNumber + ", patientDOB="
				+ patientDOB + ", insurance=" + insurance + ", patientSex="
				+ patientSex + ", weeksInTreatment=" + weeksInTreatment
				+ ", admissionDate=" + admissionDate + ", preRegistrationDate="
				+ preRegistrationDate + ", locationId=" + locationId
				+ ", locationDescription=" + locationDescription
				+ ", serviceLineId=" + serviceLineId
				+ ", serviceLineDescription=" + serviceLineDescription
				+ ", dischargeDate=" + dischargeDate + ", dischargeStatusCode="
				+ dischargeStatusCode + ", dischargeStatusDescription="
				+ dischargeStatusDescription + "]";
	}

}
