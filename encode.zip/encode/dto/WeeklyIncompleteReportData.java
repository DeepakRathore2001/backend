package com.healogics.encode.dto;

import java.sql.Timestamp;

public class WeeklyIncompleteReportData {

	private String bluebookId;
	private int facilityId;
	private String facilityAlias;
	private String providerName;
	private long visitId;
	private String patientName;
	private Timestamp dateOfService;

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityAlias() {
		return facilityAlias;
	}

	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	@Override
	public String toString() {
		return "WeeklyIncompleteReportData [bluebookId=" + bluebookId + ", facilityId=" + facilityId
				+ ", facilityAlias=" + facilityAlias + ", providerName=" + providerName + ", visitId=" + visitId
				+ ", patientName=" + patientName + ", dateOfService=" + dateOfService + "]";
	}

}
