package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class FilterOptions {

	private Date minReceivedDate;
	private Date maxReceivedDate;
	private Timestamp minDOS;
	private Timestamp maxDOS;
	private Timestamp minGuidanceDate;
	private Timestamp maxGuidanceDate;
	private Date minDOB;
	private Date maxDOB;
	private Timestamp minAuditDate;
	private Timestamp maxAuditDate;
	private Timestamp minQueuedDate;
	private Timestamp maxQueuedDate;
	
	public Timestamp getMaxAuditDate() {
		return maxAuditDate;
	}

	public Timestamp getMinQueuedDate() {
		return minQueuedDate;
	}

	public Timestamp getMaxQueuedDate() {
		return maxQueuedDate;
	}

	public void setMinAuditDate(Timestamp minAuditDate) {
		this.minAuditDate = minAuditDate;
	}

	public void setMaxAuditDate(Timestamp maxAuditDate) {
		this.maxAuditDate = maxAuditDate;
	}

	public void setMinQueuedDate(Timestamp minQueuedDate) {
		this.minQueuedDate = minQueuedDate;
	}

	public void setMaxQueuedDate(Timestamp maxQueuedDate) {
		this.maxQueuedDate = maxQueuedDate;
	}

	public Date getMinAuditDate() {
		return minAuditDate;
	}

	
	public Timestamp getMinGuidanceDate() {
		return minGuidanceDate;
	}

	public void setMinGuidanceDate(Timestamp minGuidanceDate) {
		this.minGuidanceDate = minGuidanceDate;
	}

	public Timestamp getMaxGuidanceDate() {
		return maxGuidanceDate;
	}

	public void setMaxGuidanceDate(Timestamp maxGuidanceDate) {
		this.maxGuidanceDate = maxGuidanceDate;
	}

	public Date getMinDOB() {
		return minDOB;
	}

	public void setMinDOB(Date minDOB) {
		this.minDOB = minDOB;
	}

	public Date getMaxDOB() {
		return maxDOB;
	}

	public void setMaxDOB(Date maxDOB) {
		this.maxDOB = maxDOB;
	}

	public void setMaxDOB(Timestamp maxDOB) {
		this.maxDOB = maxDOB;
	}

	public Timestamp getMinDOS() {
		return minDOS;
	}

	public void setMinDOS(Timestamp minDOS) {
		this.minDOS = minDOS;
	}

	public Timestamp getMaxDOS() {
		return maxDOS;
	}

	public void setMaxDOS(Timestamp maxDOS) {
		this.maxDOS = maxDOS;
	}

	public Date getMinReceivedDate() {
		return minReceivedDate;
	}

	public void setMinReceivedDate(Date minReceivedDate) {
		this.minReceivedDate = minReceivedDate;
	}

	public Date getMaxReceivedDate() {
		return maxReceivedDate;
	}

	public void setMaxReceivedDate(Date maxReceivedDate) {
		this.maxReceivedDate = maxReceivedDate;
	}

	private List<String> options;

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}

	@Override
	public String toString() {
		return "FilterOptions [minReceivedDate=" + minReceivedDate + ", maxReceivedDate=" + maxReceivedDate
				+ ", minDOS=" + minDOS + ", maxDOS=" + maxDOS + ", minGuidanceDate=" + minGuidanceDate
				+ ", maxGuidanceDate=" + maxGuidanceDate + ", minDOB=" + minDOB + ", maxDOB=" + maxDOB
				+ ", minAuditDate=" + minAuditDate + ", maxAuditDate=" + maxAuditDate + ", minQueuedDate="
				+ minQueuedDate + ", maxQueuedDate=" + maxQueuedDate + ", options=" + options + "]";
	}

}
