package com.healogics.encode.dto;

import java.util.List;

public class AppNotificationsReq {

	private String userId;
	private Boolean readFlag;
	private Boolean clearedFlag;
	private List<String> notificationId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Boolean getReadFlag() {
		return readFlag;
	}

	public void setReadFlag(Boolean readFlag) {
		this.readFlag = readFlag;
	}

	public Boolean getClearedFlag() {
		return clearedFlag;
	}

	public void setClearedFlag(Boolean clearedFlag) {
		this.clearedFlag = clearedFlag;
	}

	public List<String> getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(List<String> notificationId) {
		this.notificationId = notificationId;
	}

	@Override
	public String toString() {
		return "AppNotificationsReq [userId=" + userId + ", readFlag=" + readFlag + ", clearedFlag=" + clearedFlag
				+ ", notificationId=" + notificationId + "]";
	}

}
