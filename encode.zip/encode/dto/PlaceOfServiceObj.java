package com.healogics.encode.dto;

public class PlaceOfServiceObj {
	private String id;
	private String placeOfService;
	private String posDescription;
	private String facilityType;

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getPosDescription() {
		return posDescription;
	}

	public void setPosDescription(String posDescription) {
		this.posDescription = posDescription;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	@Override
	public String toString() {
		return "PlaceOfServiceObj [id=" + id + ", placeOfService=" + placeOfService + ", posDescription="
				+ posDescription + ", facilityType=" + facilityType + "]";
	}

}
