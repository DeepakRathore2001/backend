package com.healogics.encode.dto;

import java.util.List;

public class VisitsListRes {
	
	private String responseCode;
	private String responseMessage;
	private List<VisitObj> visitList;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<VisitObj> getVisitList() {
		return visitList;
	}
	public void setVisitList(List<VisitObj> visitList) {
		this.visitList = visitList;
	}
	@Override
	public String toString() {
		return "VisitsListRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage + ", visitList="
				+ visitList + "]";
	}
	
	

	
}
