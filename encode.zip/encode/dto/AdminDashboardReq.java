package com.healogics.encode.dto;

import java.util.List;

public class AdminDashboardReq {

	private int index;
	private int order;
	private String sortBy;
	private String filterOptions;
	private String filters;
	private String userFullName;
	private String userName;
	private String ihealRole;
	private String encodeRole;
	private String codingTeam;
	private List<Integer> status;

	private List<RoleAssignmentReq> userRoles;

	private String dashboardName;
	private String excelColumns;

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public String getDashboardName() {
		return dashboardName;
	}

	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}

	public List<RoleAssignmentReq> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<RoleAssignmentReq> userRoles) {
		this.userRoles = userRoles;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIhealRole() {
		return ihealRole;
	}

	public void setIhealRole(String ihealRole) {
		this.ihealRole = ihealRole;
	}

	public String getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(String encodeRole) {
		this.encodeRole = encodeRole;
	}

	public List<Integer> getStatus() {
		return status;
	}

	public void setStatus(List<Integer> status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AdminDashboardReq [index=" + index + ", order=" + order + ", sortBy=" + sortBy + ", filterOptions="
				+ filterOptions + ", filters=" + filters + ", userFullName=" + userFullName + ", userName=" + userName
				+ ", ihealRole=" + ihealRole + ", encodeRole=" + encodeRole + ", codingTeam=" + codingTeam + ", status="
				+ status + ", userRoles=" + userRoles + ", dashboardName=" + dashboardName + ", excelColumns="
				+ excelColumns + "]";
	}

}
