package com.healogics.encode.dto;

import java.util.List;

public class CoderProductivityReportRes extends APIResponse{
	
	private List<CoderProductivityReportData> reportData;

	public List<CoderProductivityReportData> getReportData() {
		return reportData;
	}

	public void setReportData(List<CoderProductivityReportData> reportData) {
		this.reportData = reportData;
	}

	@Override
	public String toString() {
		return "CoderProductivityReportRes [reportData=" + reportData + "]";
	}

}
