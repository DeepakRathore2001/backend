package com.healogics.encode.dto;

import java.util.List;

public class IHealUserInboxMessageArchivedSetRes {
	private String errorCode;
	private String errorMessage;
	private List<IHealInboxMessageMini> messagesUpdated;
	private List<Integer> messagesUnchanged;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<IHealInboxMessageMini> getMessagesUpdated() {
		return messagesUpdated;
	}

	public void setMessagesUpdated(List<IHealInboxMessageMini> messagesUpdated) {
		this.messagesUpdated = messagesUpdated;
	}

	public List<Integer> getMessagesUnchanged() {
		return messagesUnchanged;
	}

	public void setMessagesUnchanged(List<Integer> messagesUnchanged) {
		this.messagesUnchanged = messagesUnchanged;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageArchivedSetRes [errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ ", messagesUpdated=" + messagesUpdated + ", messagesUnchanged=" + messagesUnchanged + "]";
	}
}
