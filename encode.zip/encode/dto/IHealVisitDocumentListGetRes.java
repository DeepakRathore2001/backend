package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

public class IHealVisitDocumentListGetRes implements Serializable{

	private static final long serialVersionUID = 1L;
	private List<IHealDocumentObj> documents;
	private String errorCode;
	private String errorMessage;
	private List<IHealErrorDetails> errors;
	private List<IHealErrorDetails> warnings;
	
	public List<IHealDocumentObj> getDocuments() {
		return documents;
	}
	public void setDocuments(List<IHealDocumentObj> documents) {
		this.documents = documents;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<IHealErrorDetails> getErrors() {
		return errors;
	}
	public void setErrors(List<IHealErrorDetails> errors) {
		this.errors = errors;
	}
	public List<IHealErrorDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<IHealErrorDetails> warnings) {
		this.warnings = warnings;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "IHealVisitDocumentListGetRes [documents=" + documents + ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + ", errors=" + errors + ", warnings=" + warnings + "]";
	}
	
	
}
