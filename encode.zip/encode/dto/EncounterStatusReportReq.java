package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class EncounterStatusReportReq {
	
	private Date startDate;
	private Date endDate;
	private List<String> bbcList;
	private List<String> locationTypeList;
	private List<String> providerNameList;
	private List<String> providerIdList;
	private List<Integer> facilityIdList;
	private List<String> facilityTypeList;
	private List<String> codingTeamList;
	
	private String sortBy;
	private int groupBy;
	private Integer pageNumber;
	private Integer pageSize;
	private int index;
	
	public List<String> getCodingTeamList() {
		return codingTeamList;
	}
	public void setCodingTeamList(List<String> codingTeamList) {
		this.codingTeamList = codingTeamList;
	}
	public List<String> getFacilityTypeList() {
		return facilityTypeList;
	}
	public void setFacilityTypeList(List<String> facilityTypeList) {
		this.facilityTypeList = facilityTypeList;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public Integer getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	
	public List<String> getProviderIdList() {
		return providerIdList;
	}
	public void setProviderIdList(List<String> providerIdList) {
		this.providerIdList = providerIdList;
	}
	public List<Integer> getFacilityIdList() {
		return facilityIdList;
	}
	public void setFacilityIdList(List<Integer> facilityIdList) {
		this.facilityIdList = facilityIdList;
	}
	public int getGroupBy() {
		return groupBy;
	}
	public void setGroupBy(int groupBy) {
		this.groupBy = groupBy;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public List<String> getBbcList() {
		return bbcList;
	}
	public void setBbcList(List<String> bbcList) {
		this.bbcList = bbcList;
	}
	public List<String> getLocationTypeList() {
		return locationTypeList;
	}
	public void setLocationTypeList(List<String> locationTypeList) {
		this.locationTypeList = locationTypeList;
	}
	public List<String> getProviderNameList() {
		return providerNameList;
	}
	public void setProviderNameList(List<String> providerNameList) {
		this.providerNameList = providerNameList;
	}
	@Override
	public String toString() {
		return "EncounterStatusReportReq [startDate=" + startDate + ", endDate=" + endDate + ", bbcList=" + bbcList
				+ ", locationTypeList=" + locationTypeList + ", providerNameList=" + providerNameList
				+ ", providerIdList=" + providerIdList + ", facilityIdList=" + facilityIdList + ", facilityTypeList="
				+ facilityTypeList + ", codingTeamList=" + codingTeamList + ", sortBy=" + sortBy + ", groupBy="
				+ groupBy + ", pageNumber=" + pageNumber + ", pageSize=" + pageSize + ", index=" + index + "]";
	}
	
	
	

}
