package com.healogics.encode.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CodeDiagnosisObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("modifier")
	private String modifier;

	@JsonProperty("code")
	private String code;

	@JsonProperty("description")
	private String description;

	@JsonProperty("codeSystem")
	private String codeSystem;

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCodeSystem() {
		return codeSystem;
	}

	public void setCodeSystem(String codeSystem) {
		this.codeSystem = codeSystem;
	}

	@Override
	public String toString() {
		return "CodeDiagnosisObj [modifier=" + modifier + ", code=" + code
				+ ", description=" + description + ", codeSystem=" + codeSystem
				+ "]";
	}

}
