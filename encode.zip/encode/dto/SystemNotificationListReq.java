package com.healogics.encode.dto;

public class SystemNotificationListReq {
	
	private String userId;
	private String notificationId;
	
	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "SystemNotificationListReq [userId=" + userId + ", notificationId=" + notificationId + "]";
	}
}
