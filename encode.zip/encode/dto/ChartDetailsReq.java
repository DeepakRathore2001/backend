package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChartDetailsReq {
	private Long patientId;
	private Long visitId;
	private String action;
	private List<String> deficiencyReason;
	private Long deficientProviderUserId;
	private String deficientProviderName;
	private String escalationReason;
	private String escalationNote;
	private String providerCPTCode;
	private List<String> weaknessReason;
	private String weaknessNote;
	private String coderCPTCode;
	private Long userId;
	private String userName;
	private String userFirstname;
	private String userLastname;
	private String userFullname;
	private String codingTeam;
	private String encounterType;
	private String serviceLine;
	private String chartNotes;
	private String patientName;
	private String startInterfaceDate;
	private String endInterfaceDate;
	

	private String userRole;
	private String deficientNote;
	private Boolean userTaggedInNotes;
	private List<TaggedUsers> taggedUsers;
	private String masterToken;

	private String providerName;
	private String providerId;
	private String providerFirstName;
	private String providerLastName;
	private String patientAdmitDate;
	private String placeOfService;
	private String accidentOrIllness;
	private String accidentCategory;
	private String accidentOrIllnessDate;
	private int timeDocInChart;
	private int timeUsedToCodeEMLevel;

	private List<ICD10Data> icdData;
	private List<CPTChartDetails> cptData;
	private String unbillableReason;
	private String unbillableNote;
	private String returnedNote;
	
	private int patientAge;
	private String primaryInsurance;
	private String dateOfService;
	private int facilityId;
	private String cptValidations;
	
	//provider inbox
	private String iHealConfig;
	private String patientLastName;
	private String patientFirstName;
	
	private String gender;
	private String patientDOB;
	private String filters;

	private String facilityIds;
	private String facilityName;
	private String ihealConfig;
	private String bbc;
	private String status;
	private String medicalRecordNumber;
	private String startDOSDate;
	private String endDOSDate;
	private String ageStartDate;
	private String ageEndDate;
	private String visitIds;
	
	private Timestamp startTime;
	private Timestamp endTime;
	private Integer coderId;
	private String oldStatus;
	
	public String getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(String oldStatus) {
		this.oldStatus = oldStatus;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public Integer getCoderId() {
		return coderId;
	}

	public void setCoderId(Integer coderId) {
		this.coderId = coderId;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getStartDOSDate() {
		return startDOSDate;
	}

	public void setStartDOSDate(String startDOSDate) {
		this.startDOSDate = startDOSDate;
	}

	public String getEndDOSDate() {
		return endDOSDate;
	}

	public void setEndDOSDate(String endDOSDate) {
		this.endDOSDate = endDOSDate;
	}

	public String getAgeStartDate() {
		return ageStartDate;
	}

	public void setAgeStartDate(String ageStartDate) {
		this.ageStartDate = ageStartDate;
	}

	public String getAgeEndDate() {
		return ageEndDate;
	}

	public void setAgeEndDate(String ageEndDate) {
		this.ageEndDate = ageEndDate;
	}

	public String getVisitIds() {
		return visitIds;
	}

	public void setVisitIds(String visitIds) {
		this.visitIds = visitIds;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getChartNotes() {
		return chartNotes;
	}

	public void setChartNotes(String chartNotes) {
		this.chartNotes = chartNotes;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getStartInterfaceDate() {
		return startInterfaceDate;
	}

	public void setStartInterfaceDate(String startInterfaceDate) {
		this.startInterfaceDate = startInterfaceDate;
	}

	public String getEndInterfaceDate() {
		return endInterfaceDate;
	}

	public void setEndInterfaceDate(String endInterfaceDate) {
		this.endInterfaceDate = endInterfaceDate;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}
	
	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getFacilityIds() {
		return facilityIds;
	}

	public void setFacilityIds(String facilityIds) {
		this.facilityIds = facilityIds;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}
	
	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getiHealConfig() {
		return iHealConfig;
	}

	public void setiHealConfig(String iHealConfig) {
		this.iHealConfig = iHealConfig;
	}

	public String getUnbillableNote() {
		return unbillableNote;
	}

	public void setUnbillableNote(String unbillableNote) {
		this.unbillableNote = unbillableNote;
	}

	public String getCptValidations() {
		return cptValidations;
	}

	public void setCptValidations(String cptValidations) {
		this.cptValidations = cptValidations;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public int getPatientAge() {
		return patientAge;
	}

	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}

	public String getUnbillableReason() {
		return unbillableReason;
	}

	public void setUnbillableReason(String unbillableReason) {
		this.unbillableReason = unbillableReason;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPatientAdmitDate() {
		return patientAdmitDate;
	}

	public void setPatientAdmitDate(String patientAdmitDate) {
		this.patientAdmitDate = patientAdmitDate;
	}

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getAccidentOrIllness() {
		return accidentOrIllness;
	}

	public void setAccidentOrIllness(String accidentOrIllness) {
		this.accidentOrIllness = accidentOrIllness;
	}

	public String getAccidentCategory() {
		return accidentCategory;
	}

	public void setAccidentCategory(String accidentCategory) {
		this.accidentCategory = accidentCategory;
	}

	public String getAccidentOrIllnessDate() {
		return accidentOrIllnessDate;
	}

	public void setAccidentOrIllnessDate(String accidentOrIllnessDate) {
		this.accidentOrIllnessDate = accidentOrIllnessDate;
	}

	public int getTimeDocInChart() {
		return timeDocInChart;
	}

	public void setTimeDocInChart(int timeDocInChart) {
		this.timeDocInChart = timeDocInChart;
	}

	public int getTimeUsedToCodeEMLevel() {
		return timeUsedToCodeEMLevel;
	}

	public void setTimeUsedToCodeEMLevel(int timeUsedToCodeEMLevel) {
		this.timeUsedToCodeEMLevel = timeUsedToCodeEMLevel;
	}

	public List<ICD10Data> getIcdData() {
		return icdData;
	}

	public void setIcdData(List<ICD10Data> icdData) {
		this.icdData = icdData;
	}

	public List<CPTChartDetails> getCptData() {
		return cptData;
	}

	public void setCptData(List<CPTChartDetails> cptData) {
		this.cptData = cptData;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public Boolean getUserTaggedInNotes() {
		return userTaggedInNotes;
	}

	public void setUserTaggedInNotes(Boolean userTaggedInNotes) {
		this.userTaggedInNotes = userTaggedInNotes;
	}

	public List<TaggedUsers> getTaggedUsers() {
		return taggedUsers;
	}

	public void setTaggedUsers(List<TaggedUsers> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getDeficientProviderUserId() {
		return deficientProviderUserId;
	}

	public void setDeficientProviderUserId(Long deficientProviderUserId) {
		this.deficientProviderUserId = deficientProviderUserId;
	}

	public String getDeficientProviderName() {
		return deficientProviderName;
	}

	public void setDeficientProviderName(String deficientProviderName) {
		this.deficientProviderName = deficientProviderName;
	}

	public String getEscalationReason() {
		return escalationReason;
	}

	public void setEscalationReason(String escalationReason) {
		this.escalationReason = escalationReason;
	}

	public String getEscalationNote() {
		return escalationNote;
	}

	public void setEscalationNote(String escalationNote) {
		this.escalationNote = escalationNote;
	}

	public String getProviderCPTCode() {
		return providerCPTCode;
	}

	public void setProviderCPTCode(String providerCPTCode) {
		this.providerCPTCode = providerCPTCode;
	}

	public List<String> getWeaknessReason() {
		return weaknessReason;
	}

	public void setWeaknessReason(List<String> weaknessReason) {
		this.weaknessReason = weaknessReason;
	}

	public String getCoderCPTCode() {
		return coderCPTCode;
	}

	public void setCoderCPTCode(String coderCPTCode) {
		this.coderCPTCode = coderCPTCode;
	}

	public String getWeaknessNote() {
		return weaknessNote;
	}

	public void setWeaknessNote(String weaknessNote) {
		this.weaknessNote = weaknessNote;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getDeficientNote() {
		return deficientNote;
	}

	public void setDeficientNote(String deficientNote) {
		this.deficientNote = deficientNote;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getReturnedNote() {
		return returnedNote;
	}

	public void setReturnedNote(String returnedNote) {
		this.returnedNote = returnedNote;
	}

	public String getUserFirstname() {
		return userFirstname;
	}

	public void setUserFirstname(String userFirstname) {
		this.userFirstname = userFirstname;
	}

	public String getUserLastname() {
		return userLastname;
	}

	public void setUserLastname(String userLastname) {
		this.userLastname = userLastname;
	}

	@Override
	public String toString() {
		return "ChartDetailsReq [patientId=" + patientId + ", visitId=" + visitId + ", action=" + action
				+ ", deficiencyReason=" + deficiencyReason + ", deficientProviderUserId=" + deficientProviderUserId
				+ ", deficientProviderName=" + deficientProviderName + ", escalationReason=" + escalationReason
				+ ", escalationNote=" + escalationNote + ", providerCPTCode=" + providerCPTCode + ", weaknessReason="
				+ weaknessReason + ", weaknessNote=" + weaknessNote + ", coderCPTCode=" + coderCPTCode + ", userId="
				+ userId + ", userName=" + userName + ", userFirstname=" + userFirstname + ", userLastname="
				+ userLastname + ", userFullname=" + userFullname + ", codingTeam=" + codingTeam + ", encounterType="
				+ encounterType + ", serviceLine=" + serviceLine + ", chartNotes=" + chartNotes + ", patientName="
				+ patientName + ", startInterfaceDate=" + startInterfaceDate + ", endInterfaceDate=" + endInterfaceDate
				+ ", userRole=" + userRole + ", deficientNote=" + deficientNote + ", userTaggedInNotes="
				+ userTaggedInNotes + ", taggedUsers=" + taggedUsers + ", masterToken=" + masterToken
				+ ", providerName=" + providerName + ", providerId=" + providerId + ", providerFirstName="
				+ providerFirstName + ", providerLastName=" + providerLastName + ", patientAdmitDate="
				+ patientAdmitDate + ", placeOfService=" + placeOfService + ", accidentOrIllness=" + accidentOrIllness
				+ ", accidentCategory=" + accidentCategory + ", accidentOrIllnessDate=" + accidentOrIllnessDate
				+ ", timeDocInChart=" + timeDocInChart + ", timeUsedToCodeEMLevel=" + timeUsedToCodeEMLevel
				+ ", icdData=" + icdData + ", cptData=" + cptData + ", unbillableReason=" + unbillableReason
				+ ", unbillableNote=" + unbillableNote + ", returnedNote=" + returnedNote + ", patientAge=" + patientAge
				+ ", primaryInsurance=" + primaryInsurance + ", dateOfService=" + dateOfService + ", facilityId="
				+ facilityId + ", cptValidations=" + cptValidations + ", iHealConfig=" + iHealConfig
				+ ", patientLastName=" + patientLastName + ", patientFirstName=" + patientFirstName + ", gender="
				+ gender + ", patientDOB=" + patientDOB + ", filters=" + filters + ", facilityIds=" + facilityIds
				+ ", facilityName=" + facilityName + ", ihealConfig=" + ihealConfig + ", bbc=" + bbc + ", status="
				+ status + ", medicalRecordNumber=" + medicalRecordNumber + ", startDOSDate=" + startDOSDate
				+ ", endDOSDate=" + endDOSDate + ", ageStartDate=" + ageStartDate + ", ageEndDate=" + ageEndDate
				+ ", visitIds=" + visitIds + ", startTime=" + startTime + ", endTime=" + endTime + ", coderId="
				+ coderId + ", oldStatus=" + oldStatus + "]";

	}
}

