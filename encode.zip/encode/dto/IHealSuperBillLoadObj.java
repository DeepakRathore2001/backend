package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealSuperBillLoadObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("newPatientCode")
	private Integer newPatientCode;

	@JsonProperty("newPatientDescription")
	private String newPatientDescription;

	@JsonProperty("medicarePatient")
	private Boolean medicarePatient;

	@JsonProperty("procedureFacilityEM")
	private ProcedureFacilityEMObj procedureFacilityEM;

	@JsonProperty("procedureProviderEM")
	private ProcedureProviderEMObj procedureProviderEM;

	@JsonProperty("mdmCodeProviderEM")
	private Integer mdmCodeProviderEM;

	@JsonProperty("mdmDescriptionProviderEM")
	private String mdmDescriptionProviderEM;

	@JsonProperty("procedures")
	private List<ProceduresObj> procedures;

	@JsonProperty("codeDiagnosis")
	private List<CodeDiagnosisObj> codeDiagnosis;

	@JsonProperty("placeOfServiceCode")
	private Integer placeOfServiceCode;

	@JsonProperty("notes")
	private String notes;

	@JsonProperty("document")
	private IHealDocumentObj document;

	public Integer getNewPatientCode() {
		return newPatientCode;
	}

	public void setNewPatientCode(Integer newPatientCode) {
		this.newPatientCode = newPatientCode;
	}

	public String getNewPatientDescription() {
		return newPatientDescription;
	}

	public void setNewPatientDescription(String newPatientDescription) {
		this.newPatientDescription = newPatientDescription;
	}

	public Boolean getMedicarePatient() {
		return medicarePatient;
	}

	public void setMedicarePatient(Boolean medicarePatient) {
		this.medicarePatient = medicarePatient;
	}

	public ProcedureFacilityEMObj getProcedureFacilityEM() {
		return procedureFacilityEM;
	}

	public void setProcedureFacilityEM(
			ProcedureFacilityEMObj procedureFacilityEM) {
		this.procedureFacilityEM = procedureFacilityEM;
	}

	public ProcedureProviderEMObj getProcedureProviderEM() {
		return procedureProviderEM;
	}

	public void setProcedureProviderEM(
			ProcedureProviderEMObj procedureProviderEM) {
		this.procedureProviderEM = procedureProviderEM;
	}

	public Integer getMdmCodeProviderEM() {
		return mdmCodeProviderEM;
	}

	public void setMdmCodeProviderEM(Integer mdmCodeProviderEM) {
		this.mdmCodeProviderEM = mdmCodeProviderEM;
	}

	public String getMdmDescriptionProviderEM() {
		return mdmDescriptionProviderEM;
	}

	public void setMdmDescriptionProviderEM(String mdmDescriptionProviderEM) {
		this.mdmDescriptionProviderEM = mdmDescriptionProviderEM;
	}

	public List<ProceduresObj> getProcedures() {
		return procedures;
	}

	public void setProcedures(List<ProceduresObj> procedures) {
		this.procedures = procedures;
	}

	public List<CodeDiagnosisObj> getCodeDiagnosis() {
		return codeDiagnosis;
	}

	public void setCodeDiagnosis(List<CodeDiagnosisObj> codeDiagnosis) {
		this.codeDiagnosis = codeDiagnosis;
	}

	public Integer getPlaceOfServiceCode() {
		return placeOfServiceCode;
	}

	public void setPlaceOfServiceCode(Integer placeOfServiceCode) {
		this.placeOfServiceCode = placeOfServiceCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public IHealDocumentObj getDocument() {
		return document;
	}

	public void setDocument(IHealDocumentObj document) {
		this.document = document;
	}

	@Override
	public String toString() {
		return "IHealSuperBillLoadObj [newPatientCode=" + newPatientCode
				+ ", newPatientDescription=" + newPatientDescription
				+ ", medicarePatient=" + medicarePatient
				+ ", procedureFacilityEM=" + procedureFacilityEM
				+ ", procedureProviderEM=" + procedureProviderEM
				+ ", mdmCodeProviderEM=" + mdmCodeProviderEM
				+ ", mdmDescriptionProviderEM=" + mdmDescriptionProviderEM
				+ ", procedures=" + procedures + ", codeDiagnosis="
				+ codeDiagnosis + ", placeOfServiceCode=" + placeOfServiceCode
				+ ", notes=" + notes + ", document=" + document + "]";
	}

}
