package com.healogics.encode.dto;

public class CoderDashboardFilterRes {

	private String responseCode;
	private String responseDesc;
	private CoderDashboardFilter coderDashboardFilter;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDesc() {
		return responseDesc;
	}

	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}

	public CoderDashboardFilter getCoderDashboardFilter() {
		return coderDashboardFilter;
	}

	public void setCoderDashboardFilter(CoderDashboardFilter coderDashboardFilter) {
		this.coderDashboardFilter = coderDashboardFilter;
	}

	@Override
	public String toString() {
		return "CoderDashboardFilterRes [responseCode=" + responseCode + ", responseDesc=" + responseDesc
				+ ", coderDashboardFilter=" + coderDashboardFilter + "]";
	}
}
