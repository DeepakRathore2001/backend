package com.healogics.encode.dto;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ReasonsRes {

	private String responseCode;
	private String responseMessage;
	private String role;
	private String title;
	private Map<String, Map<String, String>> reasons;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Map<String, Map<String, String>> getReasons() {
		return reasons;
	}

	
	public void setReasons(Map<String, Map<String, String>> reasons) {
		this.reasons = reasons;
	}

	@Override
	public String toString() {
		return "ReasonsRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage + ", role=" + role
				+ ", title=" + title + ", reasons=" + reasons + "]";
	}

	

}
