package com.healogics.encode.dto;

public class CampusIndicatorData {

	private Long id;
	//private String bluebookId;
	//private int facilityId;
	//private String placeOfService;
	private int campusCode;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getCampusCode() {
		return campusCode;
	}
	public void setCampusCode(int campusCode) {
		this.campusCode = campusCode;
	}
	@Override
	public String toString() {
		return "CampusIndicatorData [id=" + id + ", campusCode=" + campusCode + "]";
	}
	
}
