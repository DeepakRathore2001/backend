package com.healogics.encode.dto;

public class UnderReviewFilterOptionsRes extends APIResponse {

	private UnderReviewFilter underReviewFilter;

	public UnderReviewFilter getUnderReviewFilter() {
		return underReviewFilter;
	}

	public void setUnderReviewFilter(UnderReviewFilter underReviewFilter) {
		this.underReviewFilter = underReviewFilter;
	}

	@Override
	public String toString() {
		return "UnderReviewFilterOptionsRes [underReviewFilter=" + underReviewFilter + "]";
	}

}
