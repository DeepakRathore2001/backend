package com.healogics.encode.dto;

import java.util.List;

public class HistoryTimeLineListRes extends APIResponse {
	private List<HistoryTimelineDetails> historyList;
	private int nextIndex;
	private boolean isExhausted;
	private int currentIndex;
	private Long totalCount;
	private double totalPage;
	
	public int getCurrentIndex() {
		return currentIndex;
	}

	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public double getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}

	public List<HistoryTimelineDetails> getHistoryList() {
		return historyList;
	}

	public void setHistoryList(List<HistoryTimelineDetails> historyList) {
		this.historyList = historyList;
	}
	
	public int getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}

	public boolean isExhausted() {
		return isExhausted;
	}

	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}

	@Override
	public String toString() {
		return "HistoryTimeLineListRes [historyList=" + historyList
				+ ", nextIndex=" + nextIndex
				+ ", isExhausted=" + isExhausted + "]";
	}
}
