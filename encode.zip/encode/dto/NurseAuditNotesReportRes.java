package com.healogics.encode.dto;

import java.util.List;

public class NurseAuditNotesReportRes extends APIResponse {

	private List<NurseAuditNotesReportData> reportData;

	public List<NurseAuditNotesReportData> getReportData() {
		return reportData;
	}

	public void setReportData(List<NurseAuditNotesReportData> reportData) {
		this.reportData = reportData;
	}

	@Override
	public String toString() {
		return "NurseAuditNotesReportRes [reportData=" + reportData + "]";
	}

}
