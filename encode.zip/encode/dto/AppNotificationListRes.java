package com.healogics.encode.dto;

import java.util.List;

public class AppNotificationListRes {

	private String responseCode;
	private String responseMessage;
	private List<EncodeAppNotifications> appNotifications;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<EncodeAppNotifications> getAppNotifications() {
		return appNotifications;
	}

	public void setAppNotifications(List<EncodeAppNotifications> appNotifications) {
		this.appNotifications = appNotifications;
	}

	@Override
	public String toString() {
		return "AppNotificationListRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", appNotifications=" + appNotifications + "]";
	}

}
