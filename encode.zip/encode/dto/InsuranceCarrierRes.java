package com.healogics.encode.dto;

import java.util.List;

public class InsuranceCarrierRes {

	private String responseCode;
	private String responseMessage;

	private List<InsuranceCarrierList> insuranceCarrierList;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<InsuranceCarrierList> getInsuranceCarrierList() {
		return insuranceCarrierList;
	}

	public void setInsuranceCarrierList(List<InsuranceCarrierList> insuranceCarrierList) {
		this.insuranceCarrierList = insuranceCarrierList;
	}

	@Override
	public String toString() {
		return "InsuranceCarrierRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", insuranceCarrierList=" + insuranceCarrierList + "]";
	}

}
