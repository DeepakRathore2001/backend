package com.healogics.encode.dto;

public class CoderDetails {
	private String coderUserId;
	private String coderUserName;
	private String coderUserFullName;

	public String getCoderUserId() {
		return coderUserId;
	}
	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}
	public String getCoderUserName() {
		return coderUserName;
	}
	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}
	public String getCoderUserFullName() {
		return coderUserFullName;
	}
	public void setCoderUserFullName(String coderUserFullName) {
		this.coderUserFullName = coderUserFullName;
	}

	@Override
	public String toString() {
		return "CoderDetails [coderUserId=" + coderUserId + ", coderUserName=" + coderUserName + ", coderUserFullName="
				+ coderUserFullName + "]";
	}
}
