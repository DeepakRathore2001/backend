package com.healogics.encode.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Document {

	private String documentType;
	private String documentSource;
	private Long documentEntityId;
	private String documentId;
	private Timestamp receivedTimestamp;
	private Integer isDocumentUpdated;
	private Timestamp lastUpdatedTimestamp;
	private String documentContent;
	private String documentName;

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentSource() {
		return documentSource;
	}

	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}

	public Long getDocumentEntityId() {
		return documentEntityId;
	}

	public void setDocumentEntityId(Long documentEntityId) {
		this.documentEntityId = documentEntityId;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public Timestamp getReceivedTimestamp() {
		return receivedTimestamp;
	}

	public void setReceivedTimestamp(Timestamp receivedTimestamp) {
		this.receivedTimestamp = receivedTimestamp;
	}

	public Integer getIsDocumentUpdated() {
		return isDocumentUpdated;
	}

	public void setIsDocumentUpdated(Integer isDocumentUpdated) {
		this.isDocumentUpdated = isDocumentUpdated;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	@Override
	public String toString() {
		return "Document [documentType=" + documentType + ", documentSource=" + documentSource + ", documentEntityId="
				+ documentEntityId + ", documentId=" + documentId + ", receivedTimestamp=" + receivedTimestamp
				+ ", isDocumentUpdated=" + isDocumentUpdated + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", documentContent=" + documentContent + ", documentName=" + documentName + "]";
	}

}
