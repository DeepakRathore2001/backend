package com.healogics.encode.dto;

import java.util.List;

public class AuditorDashboardFilter {

	private List<Object> codingTeamOptions;

public List<Object> getCodingTeamOptions() {
		return codingTeamOptions;
	}

	public void setCodingTeamOptions(List<Object> codingTeamOptions) {
		this.codingTeamOptions = codingTeamOptions;
	}


	@Override
	public String toString() {
		return "AuditorDashboardFilter [codingTeamOptions=" + codingTeamOptions + "]";
	}

}
