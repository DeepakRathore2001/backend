package com.healogics.encode.dto;

import java.sql.Timestamp;

public class ClickStreamReq {
	
	private int id;
	private Long userId;
	private String visitId;
	private int patientId;
	private String bluebookId;
	private int facilityId;
	private String moduleName;
	private String moduleDescription;
	private String role;
	private Timestamp createdTimestamp;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	public String getVisitId() {
		return visitId;
	}
	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getModuleDescription() {
		return moduleDescription;
	}
	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	@Override
	public String toString() {
		return "ClickStreamReq [id=" + id + ", userId=" + userId + ", visitId=" + visitId + ", patientId=" + patientId
				+ ", bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", moduleName=" + moduleName
				+ ", moduleDescription=" + moduleDescription + ", role=" + role + ", createdTimestamp="
				+ createdTimestamp + "]";
	}
	
	

}
