package com.healogics.encode.dto;

import java.util.List;

public class FinthriveRes {
	private String nThriveRequestID;
	private List<FinthriveClaimCheckRes> claimChecksProfessional;
	private String errorCode;
	private String errorMessage;
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getnThriveRequestID() {
		return nThriveRequestID;
	}

	public void setnThriveRequestID(String nThriveRequestID) {
		this.nThriveRequestID = nThriveRequestID;
	}

	public List<FinthriveClaimCheckRes> getClaimChecksProfessional() {
		return claimChecksProfessional;
	}

	public void setClaimChecksProfessional(List<FinthriveClaimCheckRes> claimChecksProfessional) {
		this.claimChecksProfessional = claimChecksProfessional;
	}

	@Override
	public String toString() {
		return "FinthriveRes [nThriveRequestID=" + nThriveRequestID + ", claimChecksProfessional="
				+ claimChecksProfessional + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
}
