package com.healogics.encode.dto;

public class UserFacilities {
	private String facilityId;
	private String facilityBluebookId;
	private String facilityName;
	private String configuration;

	private IhealSettings settings;
	private IHealSettingsV2 settingsV2;
	
	private IhealFacilityAdmin administrator;
	
	public IhealFacilityAdmin getAdministrator() {
		return administrator;
	}
	public void setAdministrator(IhealFacilityAdmin administrator) {
		this.administrator = administrator;
	}
	public IhealSettings getSettings() {
		return settings;
	}
	public void setSettings(IhealSettings settings) {
		this.settings = settings;
	}
	public IHealSettingsV2 getSettingsV2() {
		return settingsV2;
	}
	public void setSettingsV2(IHealSettingsV2 settingsV2) {
		this.settingsV2 = settingsV2;
	}

	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityBluebookId() {
		return facilityBluebookId;
	}
	public void setFacilityBluebookId(String facilityBluebookId) {
		this.facilityBluebookId = facilityBluebookId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getConfiguration() {
		return configuration;
	}
	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}
	@Override
	public String toString() {
		return "UserFacilities [facilityId=" + facilityId
				+ ", facilityBluebookId=" + facilityBluebookId
				+ ", facilityName=" + facilityName + ", configuration="
				+ configuration + ", settings=" + settings + ", settingsV2="
				+ settingsV2 + ", administrator=" + administrator + "]";
	}


}
