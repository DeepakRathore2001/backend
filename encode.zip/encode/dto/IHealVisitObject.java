package com.healogics.encode.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealVisitObject implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("visitId")
	private int visitId;
	@JsonProperty("visitDateTime")
	private String visitDateTime;
	@JsonProperty("visitTypeCode")
	private int visitTypeCode;
	@JsonProperty("visitTypeDescription")
	private String visitTypeDescription;
	@JsonProperty("serviceLineId")
	private int serviceLineId;
	@JsonProperty("serviceLineDescription")
	private String serviceLineDescription;
	@JsonProperty("visitStatus")
	private int visitStatus;
	@JsonProperty("providerId")
	private int providerId;
	@JsonProperty("providerFirstName")
	private String providerFirstName;
	@JsonProperty("providerLastName")
	private String providerLastName;
	@JsonProperty("provider2Id")
	private int provider2Id;
	@JsonProperty("provider2FirstName")
	private String provider2FirstName;
	@JsonProperty("provider2LastName")
	private String provider2LastName;
	@JsonProperty("locationId")
	private int locationId;
	@JsonProperty("locationDescription")
	private String locationDescription;

	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getLocationDescription() {
		return locationDescription;
	}
	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getVisitDateTime() {
		return visitDateTime;
	}
	public void setVisitDateTime(String visitDateTime) {
		this.visitDateTime = visitDateTime;
	}
	public int getVisitTypeCode() {
		return visitTypeCode;
	}
	public void setVisitTypeCode(int visitTypeCode) {
		this.visitTypeCode = visitTypeCode;
	}
	public String getVisitTypeDescription() {
		return visitTypeDescription;
	}
	public void setVisitTypeDescription(String visitTypeDescription) {
		this.visitTypeDescription = visitTypeDescription;
	}
	public int getVisitStatus() {
		return visitStatus;
	}
	public void setVisitStatus(int visitStatus) {
		this.visitStatus = visitStatus;
	}
	public int getProviderId() {
		return providerId;
	}
	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}
	public String getProviderFirstName() {
		return providerFirstName;
	}
	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}
	public String getProviderLastName() {
		return providerLastName;
	}
	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public int getProvider2Id() {
		return provider2Id;
	}
	public void setProvider2Id(int provider2Id) {
		this.provider2Id = provider2Id;
	}
	public String getProvider2FirstName() {
		return provider2FirstName;
	}
	public void setProvider2FirstName(String provider2FirstName) {
		this.provider2FirstName = provider2FirstName;
	}
	public String getProvider2LastName() {
		return provider2LastName;
	}
	public void setProvider2LastName(String provider2LastName) {
		this.provider2LastName = provider2LastName;
	}

	public int getServiceLineId() {
		return serviceLineId;
	}
	public void setServiceLineId(int serviceLineId) {
		this.serviceLineId = serviceLineId;
	}
	public String getServiceLineDescription() {
		return serviceLineDescription;
	}
	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}
	@Override
	public String toString() {
		return "IHealVisitObject [visitId=" + visitId + ", visitDateTime=" + visitDateTime + ", visitTypeCode="
				+ visitTypeCode + ", visitTypeDescription=" + visitTypeDescription + ", serviceLineId=" + serviceLineId
				+ ", serviceLineDescription=" + serviceLineDescription + ", visitStatus=" + visitStatus
				+ ", providerId=" + providerId + ", providerFirstName=" + providerFirstName + ", providerLastName="
				+ providerLastName + ", provider2Id=" + provider2Id + ", provider2FirstName=" + provider2FirstName
				+ ", provider2LastName=" + provider2LastName + ", locationId=" + locationId + ", locationDescription="
				+ locationDescription + "]";
	}

}
