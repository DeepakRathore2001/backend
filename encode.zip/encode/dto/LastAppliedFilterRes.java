package com.healogics.encode.dto;

public class LastAppliedFilterRes extends APIResponse {

	private DashboardList userPreference;

	public DashboardList getUserPreference() {
		return userPreference;
	}

	public void setUserPreference(DashboardList userPreference) {
		this.userPreference = userPreference;
	}

	@Override
	public String toString() {
		return "UserPreference [userPreference=" + userPreference + "]";
	}

}
