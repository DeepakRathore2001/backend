package com.healogics.encode.dto;

import java.util.Date;

public class MissingChartDataObj {

	private Date dateOfService;
	private long missingChart;
	public Date getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}
	
	public long getMissingChart() {
		return missingChart;
	}
	public void setMissingChart(long missingChart) {
		this.missingChart = missingChart;
	}
	@Override
	public String toString() {
		return "MissingChartDataObj [dateOfService=" + dateOfService + ", missingChart=" + missingChart + "]";
	}

}
