package com.healogics.encode.dto;

import java.sql.Timestamp;

public class CoderProductivityReportDrilldownData {
	
	private long visitId;
	private String patientName;
	private String bbc;
	private Timestamp dateOfService;
	private String medicalRecordNumber;
	private String status;
	private String codingTeam;
	private Long timeInMs;
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public Timestamp getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}
	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}
	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCodingTeam() {
		return codingTeam;
	}
	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}
	public Long getTimeInMs() {
		return timeInMs;
	}
	public void setTimeInMs(Long timeInMs) {
		this.timeInMs = timeInMs;
	}
	@Override
	public String toString() {
		return "CoderProductivityReportDrilldownData [visitId=" + visitId + ", patientName=" + patientName + ", bbc="
				+ bbc + ", dateOfService=" + dateOfService + ", medicalRecordNumber=" + medicalRecordNumber
				+ ", status=" + status + ", codingTeam=" + codingTeam + ", timeInMs=" + timeInMs + "]";
	}
	
}
