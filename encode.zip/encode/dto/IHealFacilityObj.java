package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

public class IHealFacilityObj implements Serializable{


	private static final long serialVersionUID = 2915579310894440018L;
	private String facilityId;
	private String facilityName;
	private String facilityBluebookId;
	private String configuration;
	private String timeZone;
	private String createdOn;
	private String createdBy;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private String zone;
	private String fax;
	private String email;
	private String lastUpdatedBy;
	private String lastUpdatedDateTime;
	private List<String> authorizedApps;
	private Boolean activeFacility;
	private List<ExternalSystems> externalSystems;
	private IhealSettings settings;
	@JsonProperty("SettingsV2")
	private IHealSettingsV2 settingsV2;
	private List<IhealCodeValue> locations;
	private List<IhealCodeValue> serviceLines;

	/**
	 * @return the facilityId
	 */
	public String getFacilityId() {
		return facilityId;
	}

	/**
	 * @param facilityId
	 *            the facilityId to set
	 */
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * @param facilityName
	 *            the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	/**
	 * @return the facilityBluebookId
	 */
	public String getFacilityBluebookId() {
		return facilityBluebookId;
	}

	/**
	 * @param facilityBluebookId
	 *            the facilityBluebookId to set
	 */
	public void setFacilityBluebookId(String facilityBluebookId) {
		this.facilityBluebookId = facilityBluebookId;
	}

	/**
	 * @return the configuration
	 */
	public String getConfiguration() {
		return configuration;
	}

	/**
	 * @param configuration
	 *            the configuration to set
	 */
	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone
	 *            the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the externalSystems
	 */
	public List<ExternalSystems> getExternalSystems() {
		return externalSystems;
	}

	/**
	 * @param externalSystems
	 *            the externalSystems to set
	 */
	public void setExternalSystems(List<ExternalSystems> externalSystems) {
		this.externalSystems = externalSystems;
	}

	public Boolean getActiveFacility() {
		return activeFacility;
	}

	public void setActiveFacility(Boolean activeFacility) {
		this.activeFacility = activeFacility;
	}

	public IhealSettings getSettings() {
		return settings;
	}

	public void setSettings(IhealSettings settings) {
		this.settings = settings;
	}

	public List<IhealCodeValue> getLocations() {
		return locations;
	}

	public void setLocations(List<IhealCodeValue> locations) {
		this.locations = locations;
	}

	public List<IhealCodeValue> getServiceLines() {
		return serviceLines;
	}

	public void setServiceLines(List<IhealCodeValue> serviceLines) {
		this.serviceLines = serviceLines;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(String lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public List<String> getAuthorizedApps() {
		return authorizedApps;
	}

	public void setAuthorizedApps(List<String> authorizedApps) {
		this.authorizedApps = authorizedApps;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public IHealSettingsV2 getSettingsV2() {
		return settingsV2;
	}

	@JsonSetter("SettingsV2")
	public void setSettingsV2(IHealSettingsV2 settingsV2) {
		this.settingsV2 = settingsV2;
	}

	@Override
	public String toString() {
		return "IhealFacility [facilityId=" + facilityId + ", facilityName="
				+ facilityName + ", facilityBluebookId=" + facilityBluebookId
				+ ", configuration=" + configuration + ", timeZone=" + timeZone
				+ ", createdOn=" + createdOn + ", createdBy=" + createdBy
				+ ", address1=" + address1 + ", address2=" + address2
				+ ", city=" + city + ", state=" + state + ", zip=" + zip
				+ ", phone=" + phone + ", zone=" + zone + ", fax=" + fax
				+ ", email=" + email + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedDateTime=" + lastUpdatedDateTime
				+ ", authorizedApps=" + authorizedApps + ", activeFacility="
				+ activeFacility + ", externalSystems=" + externalSystems
				+ ", settings=" + settings + ", settingsV2=" + settingsV2
				+ ", locations=" + locations + ", serviceLines=" + serviceLines
				+ "]";
	}


}
