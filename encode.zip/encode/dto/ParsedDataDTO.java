package com.healogics.encode.dto;

public class ParsedDataDTO {

	private String facility;
	private String claimPatient;
	private String facilityCode;
	private String patientName;
	private String patientAcctNo;
	private String lsBillingNumber;
	private String patientDOB;
	private String patientCellPhone;
	private String patientHomePhone;
	private String email;
	private String patientAddress;
	private String latestDateOfService;
	private String balance;
	private String totalBalance;
	private String totalPercentage;
	private String previousBalance;
	private String currentBalance;
	private int facilityId;
	
    public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getPreviousBalance() {
		return previousBalance;
	}

	public void setPreviousBalance(String previousBalance) {
		this.previousBalance = previousBalance;
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getTotalBalance() {
		return totalBalance;
	}

	public void setTotalBalance(String totalBalance) {
		this.totalBalance = totalBalance;
	}

	public String getTotalPercentage() {
		return totalPercentage;
	}

	public void setTotalPercentage(String totalPercentage) {
		this.totalPercentage = totalPercentage;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public String getClaimPatient() {
		return claimPatient;
	}

	public void setClaimPatient(String claimPatient) {
		this.claimPatient = claimPatient;
	}

	public String getFacilityCode() {
		return facilityCode;
	}

	public void setFacilityCode(String facilityCode) {
		this.facilityCode = facilityCode;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientAcctNo() {
		return patientAcctNo;
	}

	public void setPatientAcctNo(String patientAcctNo) {
		this.patientAcctNo = patientAcctNo;
	}

	public String getLsBillingNumber() {
		return lsBillingNumber;
	}

	public void setLsBillingNumber(String lsBillingNumber) {
		this.lsBillingNumber = lsBillingNumber;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientCellPhone() {
		return patientCellPhone;
	}

	public void setPatientCellPhone(String patientCellPhone) {
		this.patientCellPhone = patientCellPhone;
	}

	public String getPatientHomePhone() {
		return patientHomePhone;
	}

	public void setPatientHomePhone(String patientHomePhone) {
		this.patientHomePhone = patientHomePhone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPatientAddress() {
		return patientAddress;
	}

	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}

	public String getLatestDateOfService() {
		return latestDateOfService;
	}

	public void setLatestDateOfService(String latestDateOfService) {
		this.latestDateOfService = latestDateOfService;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}
 
    @Override
	public String toString() {
		return "ParsedDataDTO [facility=" + facility + ", claimPatient=" + claimPatient + ", facilityCode="
				+ facilityCode + ", patientName=" + patientName + ", patientAcctNo=" + patientAcctNo
				+ ", lsBillingNumber=" + lsBillingNumber + ", patientDOB=" + patientDOB + ", patientCellPhone="
				+ patientCellPhone + ", patientHomePhone=" + patientHomePhone + ", email=" + email + ", patientAddress="
				+ patientAddress + ", latestDateOfService=" + latestDateOfService + ", balance=" + balance
				+ ", totalBalance=" + totalBalance + ", totalPercentage=" + totalPercentage + ", previousBalance="
				+ previousBalance + ", currentBalance=" + currentBalance + ", facilityId=" + facilityId + "]";
	}
}
