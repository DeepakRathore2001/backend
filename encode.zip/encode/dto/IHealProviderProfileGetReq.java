package com.healogics.encode.dto;

public class IHealProviderProfileGetReq {
	private String privateKey;
	private Integer facilityId;
	private Integer providerId;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public Integer getProviderId() {
		return providerId;
	}

	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}

	@Override
	public String toString() {
		return "IHealProviderProfileGetReq [privateKey=" + privateKey + ", facilityId=" + facilityId + ", providerId="
				+ providerId + "]";
	}

}
