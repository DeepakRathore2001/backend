package com.healogics.encode.dto;

import java.sql.Timestamp;

public class SearchCoderDashboardReq {

	private String patientFirstName;
	private String patientLastName;
	private String bbc;
	private Timestamp dateOfService;
	private String visitId;

	public String getVisitId() {
		return visitId;
	}
	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public Timestamp getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}
	@Override
	public String toString() {
		return "SearchCoderDashboardReq [patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", bbc=" + bbc
				+ ", dateOfService=" + dateOfService + ", visitId=" + visitId
				+ "]";
	}

}
