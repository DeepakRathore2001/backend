package com.healogics.encode.dto;

public class SNSNotificationResponse extends APIResponse {
	public SNSNotificationResponse() {
		super();
	}
}
