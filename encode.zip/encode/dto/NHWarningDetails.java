package com.healogics.encode.dto;

import java.util.List;

public class NHWarningDetails {
	private static final long serialVersionUID = 1L;
	private String fieldName;
	private List<String> errors;

	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public List<String> getErrors() {
		return errors;
	}
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "NHWarningDetails [fieldName=" + fieldName + ", errors=" + errors + "]";
	}
}
