package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealPatientLoadObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("patientId")
	private String patientId;

	@JsonProperty("patientFirstName")
	private String patientFirstName;

	@JsonProperty("patientLastName")
	private String patientLastName;

	@JsonProperty("patientMiddleName")
	private String patientMiddleName;

	@JsonProperty("patientNumber")
	private String patientNumber;

	@JsonProperty("patientDOB")
	private String patientDOB;

	@JsonProperty("insurance")
	private List<IHealInsuranceObj> insurance;

	@JsonProperty("guarantor")
	private IHealGuarantorObj guarantor;

	@JsonProperty("patientSex")
	private String patientSex;

	@JsonProperty("weeksInTreatment")
	private String weeksInTreatment;

	@JsonProperty("admissionDate")
	private String admissionDate;

	@JsonProperty("preregistrationDate")
	private String preRegistrationDate;

	@JsonProperty("locationId")
	private String locationId;

	@JsonProperty("locationDescription")
	private String locationDescription;

	@JsonProperty("serviceLineId")
	private String serviceLineId;

	@JsonProperty("serviceLineDescription")
	private String serviceLineDescription;

	@JsonProperty("dischargeDate")
	private String dischargeDate;

	@JsonProperty("dischargeStatusCode")
	private String dischargeStatusCode;

	@JsonProperty("dischargeStatusDescription")
	private String dischargeStatusDescription;

	@JsonProperty("address1")
	private String address1;

	@JsonProperty("city")
	private String city;

	@JsonProperty("state")
	private String state;

	@JsonProperty("zip")
	private String zip;
	
	@JsonProperty("phone1")
	private String phone1;
	
	@JsonProperty("phone2")
	private String phone2;
	
	@JsonProperty("email")
	private String email;
	
	public String getPhone2() {
		return phone2;
	}

	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<IHealInsuranceObj> getInsurance() {
		return insurance;
	}

	public void setInsurance(List<IHealInsuranceObj> insurance) {
		this.insurance = insurance;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientNumber() {
		return patientNumber;
	}

	public void setPatientNumber(String patientNumber) {
		this.patientNumber = patientNumber;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientSex() {
		return patientSex;
	}

	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}

	public String getWeeksInTreatment() {
		return weeksInTreatment;
	}

	public void setWeeksInTreatment(String weeksInTreatment) {
		this.weeksInTreatment = weeksInTreatment;
	}

	public String getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getPatientMiddleName() {
		return patientMiddleName;
	}

	public void setPatientMiddleName(String patientMiddleName) {
		this.patientMiddleName = patientMiddleName;
	}

	public String getPreRegistrationDate() {
		return preRegistrationDate;
	}

	public void setPreRegistrationDate(String preRegistrationDate) {
		this.preRegistrationDate = preRegistrationDate;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getLocationDescription() {
		return locationDescription;
	}

	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

	public String getServiceLineId() {
		return serviceLineId;
	}

	public void setServiceLineId(String serviceLineId) {
		this.serviceLineId = serviceLineId;
	}

	public String getServiceLineDescription() {
		return serviceLineDescription;
	}

	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}

	public String getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public String getDischargeStatusCode() {
		return dischargeStatusCode;
	}

	public void setDischargeStatusCode(String dischargeStatusCode) {
		this.dischargeStatusCode = dischargeStatusCode;
	}

	public String getDischargeStatusDescription() {
		return dischargeStatusDescription;
	}

	public void setDischargeStatusDescription(String dischargeStatusDescription) {
		this.dischargeStatusDescription = dischargeStatusDescription;
	}

	public IHealGuarantorObj getGuarantor() {
		return guarantor;
	}

	public void setGuarantor(IHealGuarantorObj guarantor) {
		this.guarantor = guarantor;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "IHealPatientLoadObj [patientId=" + patientId + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientMiddleName=" + patientMiddleName
				+ ", patientNumber=" + patientNumber + ", patientDOB=" + patientDOB + ", insurance=" + insurance
				+ ", guarantor=" + guarantor + ", patientSex=" + patientSex + ", weeksInTreatment=" + weeksInTreatment
				+ ", admissionDate=" + admissionDate + ", preRegistrationDate=" + preRegistrationDate + ", locationId="
				+ locationId + ", locationDescription=" + locationDescription + ", serviceLineId=" + serviceLineId
				+ ", serviceLineDescription=" + serviceLineDescription + ", dischargeDate=" + dischargeDate
				+ ", dischargeStatusCode=" + dischargeStatusCode + ", dischargeStatusDescription="
				+ dischargeStatusDescription + ", address1=" + address1 + ", city=" + city + ", state=" + state
				+ ", zip=" + zip + ", phone1=" + phone1 + ", phone2=" + phone2 + ", email=" + email + "]";
	}

}
