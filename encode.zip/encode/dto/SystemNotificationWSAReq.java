package com.healogics.encode.dto;

import java.util.List;

public class SystemNotificationWSAReq {
	
	private String integrationKey;
	private String userId;
	private String notificationId;
	private String lastUpdatedUsername;
	private String lastUpdatedUserFullname;
	private String hyperlink;
	private String createdUsername;
	private String createdUserFullname;
	private boolean notificationStatus;
	private String endTime;
	private String startTime;
	private String title;
	private String description;
	private String startDate;
	private String endDate;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getIntegrationKey() {
		return integrationKey;
	}
	public void setIntegrationKey(String integrationKey) {
		this.integrationKey = integrationKey;
	}
	public String getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public String getHyperlink() {
		return hyperlink;
	}
	public void setHyperlink(String hyperlink) {
		this.hyperlink = hyperlink;
	}
	public String getCreatedUsername() {
		return createdUsername;
	}
	public void setCreatedUsername(String createdUsername) {
		this.createdUsername = createdUsername;
	}
	public String getCreatedUserFullname() {
		return createdUserFullname;
	}
	public void setCreatedUserFullname(String createdUserFullname) {
		this.createdUserFullname = createdUserFullname;
	}
	public boolean isNotificationStatus() {
		return notificationStatus;
	}
	public void setNotificationStatus(boolean notificationStatus) {
		this.notificationStatus = notificationStatus;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "SystemNotificationWSAReq [integrationKey=" + integrationKey + ", userId=" + userId + ", notificationId="
				+ notificationId + ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", hyperlink=" + hyperlink + ", createdUsername=" + createdUsername
				+ ", createdUserFullname=" + createdUserFullname + ", notificationStatus=" + notificationStatus
				+ ", endTime=" + endTime + ", startTime=" + startTime + ", title=" + title + ", description="
				+ description + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
	

}
