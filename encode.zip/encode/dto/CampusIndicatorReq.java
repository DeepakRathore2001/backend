package com.healogics.encode.dto;

import java.util.List;

public class CampusIndicatorReq {

	private List<CampusIndicatorData> indicator;
	
	public List<CampusIndicatorData> getIndicator() {
		return indicator;
	}



	public void setIndicator(List<CampusIndicatorData> indicator) {
		this.indicator = indicator;
	}

	@Override
	public String toString() {
		return "CampusIndicatorReq [indicator=" + indicator + "]";
	}

}
