package com.healogics.encode.dto;

public class DashboardList {

	private TaskType CMC;

	public TaskType getCMC() {
		return CMC;
	}

	public void setCMC(TaskType cMC) {
		CMC = cMC;
	}

	@Override
	public String toString() {
		return "DashboardList [CMC=" + CMC + "]";
	}

}
