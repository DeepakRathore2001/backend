package com.healogics.encode.dto;

import java.util.List;

public class AuditNotesListRes extends APIResponse {
	private List<NotesDetails> auditNotes;

	public List<NotesDetails> getAuditNotes() {
		return auditNotes;
	}

	public void setAuditNotes(List<NotesDetails> auditNotes) {
		this.auditNotes = auditNotes;
	}

	@Override
	public String toString() {
		return "AuditNotesListRes [auditNotes=" + auditNotes + "]";
	}

}
