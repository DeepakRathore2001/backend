package com.healogics.encode.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExternalSystems implements Serializable{
	 private static final long serialVersionUID = 1L;

	    private String name;

	    private boolean isEnabled;

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }
	    @JsonProperty("isEnabled")
	    public boolean isEnabled() {
	        return isEnabled;
	    }

	    public void setEnabled(boolean isEnabled) {
	        this.isEnabled = isEnabled;
	    }

	    @Override
	    public String toString() {
	        return "{ name:" + name + ", isEnabled:" + isEnabled + "}";

	    }
}
