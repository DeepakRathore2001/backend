package com.healogics.encode.dto;

import java.util.List;

public class Deficiency {

	private List<String> deficiencyReason;
	private String deficientNote;
	private String deficientProviderName;
	private Long deficientProviderUserId;

	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getDeficientNote() {
		return deficientNote;
	}

	public void setDeficientNote(String deficientNote) {
		this.deficientNote = deficientNote;
	}

	public String getDeficientProviderName() {
		return deficientProviderName;
	}

	public void setDeficientProviderName(String deficientProviderName) {
		this.deficientProviderName = deficientProviderName;
	}

	public Long getDeficientProviderUserId() {
		return deficientProviderUserId;
	}

	public void setDeficientProviderUserId(Long deficientProviderUserId) {
		this.deficientProviderUserId = deficientProviderUserId;
	}

	@Override
	public String toString() {
		return "Deficiency [deficiencyReason=" + deficiencyReason + ", deficientNote=" + deficientNote
				+ ", deficientProviderName=" + deficientProviderName + ", deficientProviderUserId="
				+ deficientProviderUserId + "]";
	}

}
