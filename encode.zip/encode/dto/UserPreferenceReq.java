package com.healogics.encode.dto;

public class UserPreferenceReq {

	private Long userId;
	private String username;
	private String userFullname;
	private String lastUpdatedBy;
	private String colorCodes;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserFullname() {
		return userFullname;
	}
	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getColorCodes() {
		return colorCodes;
	}
	public void setColorCodes(String colorCodes) {
		this.colorCodes = colorCodes;
	}
	@Override
	public String toString() {
		return "UserPreferenceReq [userId=" + userId + ", username=" + username
				+ ", userFullname=" + userFullname + ", lastUpdatedBy="
				+ lastUpdatedBy + ", colorCodes=" + colorCodes + "]";
	}

}
