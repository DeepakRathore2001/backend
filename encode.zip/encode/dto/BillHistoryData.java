package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class BillHistoryData {
	
	private Long visitId;
	private Timestamp patientDOS;
	private String patientDOSStr;
	private Long patientId;
	private int facilityId;
	private String facilityName;
	private String bluebookId;
	private String patientFirstName;
	private String patientLastName;
	private String patientFullName;
	private Date patientDob;
	private String patientMrn;
	private String status;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;
	private Date claimSentDate;
	private String lastUpdatedByUser;
	private String providerId;
	private String providerName;
	private boolean iHealVisit;
	
	public boolean isiHealVisit() {
		return iHealVisit;
	}
	public void setiHealVisit(boolean iHealVisit) {
		this.iHealVisit = iHealVisit;
	}
	public String getPatientDOSStr() {
		return patientDOSStr;
	}
	public void setPatientDOSStr(String patientDOSStr) {
		this.patientDOSStr = patientDOSStr;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Long getVisitId() {
		return visitId;
	}
	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}
	public Timestamp getPatientDOS() {
		return patientDOS;
	}
	public void setPatientDOS(Timestamp patientDOS) {
		this.patientDOS = patientDOS;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getPatientFullName() {
		return patientFullName;
	}
	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}
	public Date getPatientDob() {
		return patientDob;
	}
	public void setPatientDob(Date patientDob) {
		this.patientDob = patientDob;
	}
	public String getPatientMrn() {
		return patientMrn;
	}
	public void setPatientMrn(String patientMrn) {
		this.patientMrn = patientMrn;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public Date getClaimSentDate() {
		return claimSentDate;
	}
	public void setClaimSentDate(Date claimSentDate) {
		this.claimSentDate = claimSentDate;
	}
	public String getLastUpdatedByUser() {
		return lastUpdatedByUser;
	}
	public void setLastUpdatedByUser(String lastUpdatedByUser) {
		this.lastUpdatedByUser = lastUpdatedByUser;
	}
	@Override
	public String toString() {
		return "BillHistoryData [visitId=" + visitId + ", patientDOS=" + patientDOS + ", patientDOSStr=" + patientDOSStr
				+ ", patientId=" + patientId + ", facilityId=" + facilityId + ", facilityName=" + facilityName
				+ ", bluebookId=" + bluebookId + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", patientFullName=" + patientFullName + ", patientDob=" + patientDob
				+ ", patientMrn=" + patientMrn + ", status=" + status + ", createdTimestamp=" + createdTimestamp
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", claimSentDate=" + claimSentDate
				+ ", lastUpdatedByUser=" + lastUpdatedByUser + ", providerId=" + providerId + ", providerName="
				+ providerName + ", iHealVisit=" + iHealVisit + "]";
	}

	
}
