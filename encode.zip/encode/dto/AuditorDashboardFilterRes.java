package com.healogics.encode.dto;

public class AuditorDashboardFilterRes extends APIResponse {

	private AuditorDashboardFilter auditorDashboardFilter;

	public AuditorDashboardFilter getAuditorDashboardFilter() {
		return auditorDashboardFilter;
	}

	public void setAuditorDashboardFilter(AuditorDashboardFilter auditorDashboardFilter) {
		this.auditorDashboardFilter = auditorDashboardFilter;
	}

	@Override
	public String toString() {
		return "AuditorDashboardFilterRes [auditorDashboardFilter=" + auditorDashboardFilter + "]";
	}

}
