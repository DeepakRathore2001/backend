package com.healogics.encode.dto;

public class AppNotificationCountRes extends APIResponse {
	private boolean isNotificationExists;

	public boolean isNotificationExists() {
		return isNotificationExists;
	}

	public void setNotificationExists(boolean isNotificationExists) {
		this.isNotificationExists = isNotificationExists;
	}

	@Override
	public String toString() {
		return "InAppNotificationCountRes [isNotificationExists=" + isNotificationExists + "]";
	}
}
