package com.healogics.encode.dto;

public class AttachmentDetails {
	
	private String docName;
	private int visitId;
	private String groupName;
	private String docEntityId;
	private String testDesc;
	private String addedDate;
	private String visitDate;
	private boolean isSigned;
	private int versionId;
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	public String getTestDesc() {
		return testDesc;
	}
	public void setTestDesc(String testDesc) {
		this.testDesc = testDesc;
	}
	public String getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(String addedDate) {
		this.addedDate = addedDate;
	}
	public String getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}
	
	public boolean isSigned() {
		return isSigned;
	}
	public void setSigned(boolean isSigned) {
		this.isSigned = isSigned;
	}

	public int getVersionId() {
		return versionId;
	}
	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}
	
	@Override
	public String toString() {
		return "AttachmentDetails [docName=" + docName + ", visitId=" + visitId + ", groupName=" + groupName
				+ ", docEntityId=" + docEntityId + ", testDesc=" + testDesc + ", addedDate=" + addedDate
				+ ", visitDate=" + visitDate + ", isSigned=" + isSigned + ", versionId=" + versionId + "]";
	}
	
	

}
