package com.healogics.encode.dto;

import java.util.List;

public class PlaceOfServiceRes {

	private String responseCode;
	private String responseDesc;
	private List<PlaceOfServiceObj> placeOfServiceList;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public List<PlaceOfServiceObj> getPlaceOfServiceList() {
		return placeOfServiceList;
	}
	public void setPlaceOfServiceList(
			List<PlaceOfServiceObj> placeOfServiceList) {
		this.placeOfServiceList = placeOfServiceList;
	}
	@Override
	public String toString() {
		return "PlaceOfServiceRes [responseCode=" + responseCode
				+ ", responseDesc=" + responseDesc + ", placeOfServiceList="
				+ placeOfServiceList + "]";
	}

}
