package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IhealFacilityListGetReq implements Serializable {
	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String userId;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "IhealFacilityListGetReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId="
				+ userId + "]";
	}
}
