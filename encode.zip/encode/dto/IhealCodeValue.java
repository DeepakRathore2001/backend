package com.healogics.encode.dto;

import java.io.Serializable;

public class IhealCodeValue implements Serializable{


	 private static final long serialVersionUID = 1L;

	    private int code;
	    private String value;
	    private int sort;

	    public int getCode() {
	        return code;
	    }
	    public void setCode(int code) {
	        this.code = code;
	    }
	    public String getValue() {
	        return value;
	    }
	    public void setValue(String value) {
	        this.value = value;
	    }
	    public int getSort() {
	        return sort;
	    }
	    public void setSort(int sort) {
	        this.sort = sort;
	    }

	    @Override
	    public String toString() {
	        return "{code:" + code + ", value:" + value + ", sort:" + sort + "}";
	    }
	

}
