package com.healogics.encode.dto;

import java.sql.Date;

public class CoderProductivityReportData {
	
	private Integer coderId;
	private String coderName;
	private Long total;
	private Long inReview;
	private Long completed;
	private Long sent;
	private Long deficiency;
	private Long unbillable;
	private Long other;
	private Long avgTimeMins;
	private Long avgTimeHrs;
	private String endDate;
	
	
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Integer getCoderId() {
		return coderId;
	}
	public void setCoderId(Integer coderId) {
		this.coderId = coderId;
	}
	public String getCoderName() {
		return coderName;
	}
	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}
	public Long getTotal() {
		return total;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
	public Long getInReview() {
		return inReview;
	}
	public void setInReview(Long inReview) {
		this.inReview = inReview;
	}
	public Long getCompleted() {
		return completed;
	}
	public void setCompleted(Long completed) {
		this.completed = completed;
	}
	public Long getSent() {
		return sent;
	}
	public void setSent(Long sent) {
		this.sent = sent;
	}
	public Long getDeficiency() {
		return deficiency;
	}
	public void setDeficiency(Long deficiency) {
		this.deficiency = deficiency;
	}
	public Long getUnbillable() {
		return unbillable;
	}
	public void setUnbillable(Long unbillable) {
		this.unbillable = unbillable;
	}
	public Long getOther() {
		return other;
	}
	public void setOther(Long other) {
		this.other = other;
	}
	public Long getAvgTimeMins() {
		return avgTimeMins;
	}
	public void setAvgTimeMins(Long avgTimeMins) {
		this.avgTimeMins = avgTimeMins;
	}
	
	public Long getAvgTimeHrs() {
		return avgTimeHrs;
	}
	public void setAvgTimeHrs(Long avgTimeHrs) {
		this.avgTimeHrs = avgTimeHrs;
	}
	
	@Override
	public String toString() {
		return "CoderProductivityReportData [coderId=" + coderId + ", coderName=" + coderName + ", total=" + total
				+ ", inReview=" + inReview + ", completed=" + completed + ", sent=" + sent + ", deficiency="
				+ deficiency + ", unbillable=" + unbillable + ", other=" + other + ", avgTimeMins=" + avgTimeMins
				+ ", avgTimeHrs=" + avgTimeHrs + ", endDate=" + endDate + "]";
	}
	
	

}
