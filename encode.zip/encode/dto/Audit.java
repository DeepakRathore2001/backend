package com.healogics.encode.dto;

import java.util.List;

public class Audit {

	// private String codingTeam;
	private List<String> codingTeam;
	private int filterId;
	private String filterName;
	private String dateCreated;
	private int auditRecordExists;
	private Long count;

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public int getAuditRecordExists() {
		return auditRecordExists;
	}

	public void setAuditRecordExists(int auditRecordExists) {
		this.auditRecordExists = auditRecordExists;
	}

	public List<String> getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(List<String> codingTeam) {
		this.codingTeam = codingTeam;
	}

	public int getFilterId() {
		return filterId;
	}

	public void setFilterId(int filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "Audit [codingTeam=" + codingTeam + ", filterId=" + filterId + ", filterName=" + filterName
				+ ", dateCreated=" + dateCreated + ", auditRecordExists=" + auditRecordExists + ", count=" + count
				+ "]";
	}

}
