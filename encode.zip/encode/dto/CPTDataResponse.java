package com.healogics.encode.dto;

import java.util.List;

public class CPTDataResponse {
	private List<CPTChartDetails> cptCodes;
	private String responseCode;
	private String responseMessage;
	public List<CPTChartDetails> getCptCodes() {
		return cptCodes;
	}
	public void setCptCodes(List<CPTChartDetails> cptCodes) {
		this.cptCodes = cptCodes;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "CPTDataResponse [cptCodes=" + cptCodes + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
