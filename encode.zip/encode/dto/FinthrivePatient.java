package com.healogics.encode.dto;

public class FinthrivePatient {
	private int sex;
	private String birthDate;

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	@Override
	public String toString() {
		return "FinthrivePatient [sex=" + sex + ", birthDate=" + birthDate + "]";
	}
}
