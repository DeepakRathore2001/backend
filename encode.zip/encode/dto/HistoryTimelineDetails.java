package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

public class HistoryTimelineDetails {
	private long historyId;
	private Timestamp addedTimestamp;
	private Timestamp dateOfService;
	private String description;
	private String creatorUserFullName;
	private String creatorUserName;
	private long creatorUserId;
	private String createdUserRole;
	private String status;
	private long visitId;
	private long patientId;
	private String patientName;
	private String facilityId;
	private String bluebookId;
	private String userFirstName;
	private String userLastName;

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public long getHistoryId() {
		return historyId;
	}

	public void setHistoryId(long historyId) {
		this.historyId = historyId;
	}

	public Timestamp getAddedTimestamp() {
		return addedTimestamp;
	}

	public void setAddedTimestamp(Timestamp addedTimestamp) {
		this.addedTimestamp = addedTimestamp;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreatorUserFullName() {
		return creatorUserFullName;
	}

	public void setCreatorUserFullName(String creatorUserFullName) {
		this.creatorUserFullName = creatorUserFullName;
	}

	public String getCreatorUserName() {
		return creatorUserName;
	}

	public void setCreatorUserName(String creatorUserName) {
		this.creatorUserName = creatorUserName;
	}

	public long getCreatorUserId() {
		return creatorUserId;
	}

	public void setCreatorUserId(long creatorUserId) {
		this.creatorUserId = creatorUserId;
	}

	public String getCreatedUserRole() {
		return createdUserRole;
	}

	public void setCreatedUserRole(String createdUserRole) {
		this.createdUserRole = createdUserRole;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	@Override
	public String toString() {
		return "HistoryTimelineDetails [historyId=" + historyId + ", addedTimestamp=" + addedTimestamp
				+ ", dateOfService=" + dateOfService + ", description=" + description + ", creatorUserFullName="
				+ creatorUserFullName + ", creatorUserName=" + creatorUserName + ", creatorUserId=" + creatorUserId
				+ ", createdUserRole=" + createdUserRole + ", status=" + status + ", visitId=" + visitId
				+ ", patientId=" + patientId + ", patientName=" + patientName + ", facilityId=" + facilityId
				+ ", bluebookId=" + bluebookId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ "]";
	}
}
