package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class SearchCoderDashboardObj {

	private String bbc;
	private int facilityId;
	private String facilityName;
	private Date overDueDate;
	private boolean overDueFlag;
	private Timestamp dateOfService;
	private String status;
	private long visitId;
	private String medicalRecordNumber;
	private String firstName;
	private String lastName;
	private String insurance;
	private Date receivedDate;
	private String gender;
	private Date patientDOB;
	private long age;
	private Long patientId;
	private int isLocked;
	private String dashboardName;
	private String userFullName;
	private String chartLocation;
	

	public String getChartLocation() {
		return chartLocation;
	}

	public void setChartLocation(String chartLocation) {
		this.chartLocation = chartLocation;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getDashboardName() {
		return dashboardName;
	}

	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Date getOverDueDate() {
		return overDueDate;
	}

	public void setOverDueDate(Date overDueDate) {
		this.overDueDate = overDueDate;
	}

	public boolean isOverDueFlag() {
		return overDueFlag;
	}

	public void setOverDueFlag(boolean overDueFlag) {
		this.overDueFlag = overDueFlag;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	@Override
	public String toString() {
		return "SearchCoderDashboardObj [bbc=" + bbc + ", facilityId=" + facilityId + ", facilityName=" + facilityName
				+ ", overDueDate=" + overDueDate + ", overDueFlag=" + overDueFlag + ", dateOfService=" + dateOfService
				+ ", status=" + status + ", visitId=" + visitId + ", medicalRecordNumber=" + medicalRecordNumber
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", insurance=" + insurance + ", receivedDate="
				+ receivedDate + ", gender=" + gender + ", patientDOB=" + patientDOB + ", age=" + age + ", patientId="
				+ patientId + ", isLocked=" + isLocked + ", dashboardName=" + dashboardName + ", userFullName="
				+ userFullName + ", chartLocation=" + chartLocation + "]";
	}

}
