package com.healogics.encode.dto;

import java.util.List;

public class DBDocumentListRes {

	private long patientId;
	private long visitId;
	private List<Document> documents;
	private String responseCode;
	private String responseMessage;

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	@Override
	public String toString() {
		return "DBDocumentListRes [patientId=" + patientId + ", visitId=" + visitId + ", documents=" + documents
				+ ", responseCode=" + responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
