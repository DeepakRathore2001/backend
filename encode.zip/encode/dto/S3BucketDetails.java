package com.healogics.encode.dto;

public class S3BucketDetails {
	private String name;
	private String ownerIdentity;
	private String arn;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwnerIdentity() {
		return ownerIdentity;
	}

	public void setOwnerIdentity(String ownerIdentity) {
		this.ownerIdentity = ownerIdentity;
	}

	public String getArn() {
		return arn;
	}

	public void setArn(String arn) {
		this.arn = arn;
	}

	@Override
	public String toString() {
		return "S3BucketDetails [name=" + name + ", ownerIdentity=" + ownerIdentity
				+ ", arn=" + arn + "]";
	}
}
