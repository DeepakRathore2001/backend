package com.healogics.encode.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealInsuranceObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("insuranceId")
	private int insuranceId;

	@JsonProperty("insuranceName")
	private String insuranceName;

	@JsonProperty("Sequence")
	private int sequence;

	@JsonProperty("address1")
	private String address1;

	@JsonProperty("address2")
	private String address2;

	@JsonProperty("city")
	private String city;

	@JsonProperty("state")
	private String state;

	@JsonProperty("zip")
	private String zip;

	@JsonProperty("insured")
	private IHealInsuredObj insured;

	@JsonProperty("insuredDOB")
	private String insuredDOB;

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("groupNumber")
	private String groupNumber;

	public String getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public IHealInsuredObj getInsured() {
		return insured;
	}

	public void setInsured(IHealInsuredObj insured) {
		this.insured = insured;
	}

	public String getInsuredDOB() {
		return insuredDOB;
	}

	public void setInsuredDOB(String insuredDOB) {
		this.insuredDOB = insuredDOB;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public int getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}

	public String getInsuranceName() {
		return insuranceName;
	}

	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	@Override
	public String toString() {
		return "IHealInsuranceObj [insuranceId=" + insuranceId + ", insuranceName=" + insuranceName + ", sequence="
				+ sequence + ", address1=" + address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state
				+ ", zip=" + zip + ", insured=" + insured + ", insuredDOB=" + insuredDOB + ", policyNumber="
				+ policyNumber + ", groupNumber=" + groupNumber + "]";
	}

}
