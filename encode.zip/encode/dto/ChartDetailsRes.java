package com.healogics.encode.dto;

public class ChartDetailsRes extends APIResponse {
	

	

}
