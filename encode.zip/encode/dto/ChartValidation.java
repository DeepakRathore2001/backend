package com.healogics.encode.dto;

public class ChartValidation {
	private String validationMessage;
	private int type;

	public String getValidationMessage() {
		return validationMessage;
	}
	public void setValidationMessage(String validationMessage) {
		this.validationMessage = validationMessage;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "ChartValidation [validationMessage=" + validationMessage
				+ ", type=" + type + "]";
	}
}
