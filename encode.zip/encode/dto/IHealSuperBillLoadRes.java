package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

public class IHealSuperBillLoadRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private IHealSuperBillLoadObj superbill;
	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	public IHealSuperBillLoadObj getSuperbill() {
		return superbill;
	}
	public void setSuperbill(IHealSuperBillLoadObj superbill) {
		this.superbill = superbill;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealSuperBillLoadRes [superbill=" + superbill + ", errorCode="
				+ errorCode + ", errorMessage=" + errorMessage + ", warnings="
				+ warnings + "]";
	}

}
