package com.healogics.encode.dto;

import java.util.List;

public class MissingChartDataRes extends APIResponse {

	private List<MissingChartDataObj> chartsData;
	private int total;
	public List<MissingChartDataObj> getChartsData() {
		return chartsData;
	}
	public void setChartsData(List<MissingChartDataObj> chartsData) {
		this.chartsData = chartsData;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "MissingChartDataRes [chartsData=" + chartsData + ", total="
				+ total + "]";
	}

}
