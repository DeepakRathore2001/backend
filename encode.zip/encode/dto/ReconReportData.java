package com.healogics.encode.dto;

import java.util.List;

public class ReconReportData {

	private Long visitId;
	private String bluebookId;
	private String facilityType;
	private Integer facilityId;
	private String medicalRecordNumber;
	private String patientDos;
	private String patientName;
	private String status;
	private String providerName;
	private String providerId;
	private String serviceLine;
	private String codingTeam;
	private String coderFullname;
	private String coderUserId;
	private List<String> deficiencyReason;
	private String pendingReason;

	public String getCoderFullname() {
		return coderFullname;
	}

	public void setCoderFullname(String coderFullname) {
		this.coderFullname = coderFullname;
	}

	public String getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(String coderUserId) {
		this.coderUserId = coderUserId;
	}

	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		this.pendingReason = pendingReason;
	}

	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getPatientDos() {
		return patientDos;
	}

	public void setPatientDos(String patientDos) {
		this.patientDos = patientDos;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	@Override
	public String toString() {
		return "ReconReportData [visitId=" + visitId + ", bluebookId=" + bluebookId + ", facilityType=" + facilityType
				+ ", facilityId=" + facilityId + ", medicalRecordNumber=" + medicalRecordNumber + ", patientDos="
				+ patientDos + ", patientName=" + patientName + ", status=" + status + ", providerName=" + providerName
				+ ", providerId=" + providerId + ", serviceLine=" + serviceLine + ", codingTeam=" + codingTeam
				+ ", coderFullname=" + coderFullname + ", coderUserId=" + coderUserId + ", deficiencyReason="
				+ deficiencyReason + ", pendingReason=" + pendingReason + "]";
	}

}
