package com.healogics.encode.dto;

import java.util.List;

public class FinthriveProcedureRes {
	private List<FinthriveCCIEditRes> cciEdit;

	public List<FinthriveCCIEditRes> getCciEdit() {
		return cciEdit;
	}

	public void setCciEdit(List<FinthriveCCIEditRes> cciEdit) {
		this.cciEdit = cciEdit;
	}

	@Override
	public String toString() {
		return "FinthriveProcedureRes [cciEdit=" + cciEdit + "]";
	}
}
