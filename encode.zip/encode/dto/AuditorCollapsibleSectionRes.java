package com.healogics.encode.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class AuditorCollapsibleSectionRes {

	private String responseCode;
	private String responseMessage;
	private int count;
	private List<AuditorCollapsibleSectionData> collapsibleSection;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<AuditorCollapsibleSectionData> getCollapsibleSection() {
		return collapsibleSection;
	}

	public void setCollapsibleSection(List<AuditorCollapsibleSectionData> collapsibleSection) {
		this.collapsibleSection = collapsibleSection;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "AuditorCollapsibleSectionRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", count=" + count + ", collapsibleSection=" + collapsibleSection + "]";
	}

}
