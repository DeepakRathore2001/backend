package com.healogics.encode.dto;

import java.sql.Timestamp;

public class AuditHistoryData {

	private long visitId;
	private String coderName;
	private String billingClientAbbr;
	private String accountNumber;
	private String provider;
	private String sendingFacility;
	private Timestamp dos;
	private String chartCodes;
	private String auditNotes;
	private String coderUserName;
	private int coderUserId;

	private Boolean auditCompleted;
	private Boolean codingError;
	private String filterName;

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public boolean isAuditCompleted() {
		return auditCompleted;
	}

	public void setAuditCompleted(boolean auditCompleted) {
		this.auditCompleted = auditCompleted;
	}

	public boolean isCodingError() {
		return codingError;
	}

	public void setCodingError(boolean codingError) {
		this.codingError = codingError;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getCoderName() {
		return coderName;
	}

	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}

	public String getBillingClientAbbr() {
		return billingClientAbbr;
	}

	public void setBillingClientAbbr(String billingClientAbbr) {
		this.billingClientAbbr = billingClientAbbr;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getSendingFacility() {
		return sendingFacility;
	}

	public void setSendingFacility(String sendingFacility) {
		this.sendingFacility = sendingFacility;
	}

	public String getChartCodes() {
		return chartCodes;
	}

	public void setChartCodes(String chartCodes) {
		this.chartCodes = chartCodes;
	}

	public String getAuditNotes() {
		return auditNotes;
	}

	public void setAuditNotes(String auditNotes) {
		this.auditNotes = auditNotes;
	}

	public String getCoderUserName() {
		return coderUserName;
	}

	public void setCoderUserName(String coderUserName) {
		this.coderUserName = coderUserName;
	}

	public int getCoderUserId() {
		return coderUserId;
	}

	public void setCoderUserId(int coderUserId) {
		this.coderUserId = coderUserId;
	}

	public Timestamp getDos() {
		return dos;
	}

	public void setDos(Timestamp dos) {
		this.dos = dos;
	}

	@Override
	public String toString() {
		return "AuditHistoryData [visitId=" + visitId + ", coderName="
				+ coderName + ", billingClientAbbr=" + billingClientAbbr
				+ ", accountNumber=" + accountNumber + ", provider=" + provider
				+ ", sendingFacility=" + sendingFacility + ", dos=" + dos
				+ ", chartCodes=" + chartCodes + ", auditNotes=" + auditNotes
				+ ", coderUserName=" + coderUserName + ", coderUserId="
				+ coderUserId + ", auditCompleted=" + auditCompleted
				+ ", codingError=" + codingError + ", filterName=" + filterName
				+ "]";
	}

}
