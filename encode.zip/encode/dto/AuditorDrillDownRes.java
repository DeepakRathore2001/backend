package com.healogics.encode.dto;

import java.util.List;

public class AuditorDrillDownRes extends APIResponse {

	private List<Coder> coder;
	private List<FacilityDetails> facilities;

	public List<Coder> getCoder() {
		return coder;
	}

	public void setCoder(List<Coder> coder) {
		this.coder = coder;
	}

	public List<FacilityDetails> getFacilities() {
		return facilities;
	}

	public void setFacilities(List<FacilityDetails> facilities) {
		this.facilities = facilities;
	}

	@Override
	public String toString() {
		return "AuditorDrillDownRes [coder=" + coder + ", facilities=" + facilities + "]";
	}

}
