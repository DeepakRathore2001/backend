package com.healogics.encode.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportData {

	private List<FacilityObj> bbc;
	private List<String> locationType;
	private List<LocationObj> locations;
	private List<String> facilityType;
	
	public List<String> getFacilityType() {
		return facilityType;
	}
	public void setFacilityType(List<String> facilityType) {
		this.facilityType = facilityType;
	}
	public List<LocationObj> getLocations() {
		return locations;
	}
	public void setLocations(List<LocationObj> locations) {
		this.locations = locations;
	}
	public List<FacilityObj> getBbc() {
		return bbc;
	}
	public void setBbc(List<FacilityObj> bbc) {
		this.bbc = bbc;
	}
	public List<String> getLocationType() {
		return locationType;
	}
	public void setLocationType(List<String> locationType) {
		this.locationType = locationType;
	}
	@Override
	public String toString() {
		return "ReportData [bbc=" + bbc + ", locationType=" + locationType + ", locations=" + locations
				+ ", facilityType=" + facilityType + "]";
	}
	
	
}
