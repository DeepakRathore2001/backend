package com.healogics.encode.dto;


public class ViewAuditorFilterRes extends APIResponse {
	private AuditFilterDetails filterData;

	public AuditFilterDetails getFilterData() {
		return filterData;
	}

	public void setFilterData(AuditFilterDetails filterData) {
		this.filterData = filterData;
	}

	@Override
	public String toString() {
		return "ViewAuditorFilterRes [filterData=" + filterData + "]";
	}
}
