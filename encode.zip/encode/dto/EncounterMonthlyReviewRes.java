package com.healogics.encode.dto;

import java.util.List;

public class EncounterMonthlyReviewRes {

	private String responseCode;
	private String responseMessage;
	private List<EncounterMonthlyReviewData> data;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<EncounterMonthlyReviewData> getData() {
		return data;
	}
	public void setData(List<EncounterMonthlyReviewData> data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "EncounterMonthlyReviewRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", data=" + data + "]";
	}
	
	
}
