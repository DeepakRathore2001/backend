package com.healogics.encode.dto;

public class S3Details {
	private String s3SchemaVersion;
	private String configurationId;
	private S3BucketDetails bucket;
	private S3ObjectDetails object;

	public String getS3SchemaVersion() {
		return s3SchemaVersion;
	}

	public void setS3SchemaVersion(String s3SchemaVersion) {
		this.s3SchemaVersion = s3SchemaVersion;
	}

	public String getConfigurationId() {
		return configurationId;
	}

	public void setConfigurationId(String configurationId) {
		this.configurationId = configurationId;
	}

	public S3BucketDetails getBucket() {
		return bucket;
	}

	public void setBucket(S3BucketDetails bucket) {
		this.bucket = bucket;
	}

	public S3ObjectDetails getObject() {
		return object;
	}

	public void setObject(S3ObjectDetails object) {
		this.object = object;
	}

	@Override
	public String toString() {
		return "S3Details [s3SchemaVersion=" + s3SchemaVersion + ", configurationId=" + configurationId + ", bucket="
				+ bucket + ", object=" + object + "]";
	}
}
