package com.healogics.encode.dto;

import java.sql.Timestamp;

import javax.persistence.Column;

public class CoderDashboardDTO {

	private String facilityName;
	private Integer facilityId;
	private String bluebookId;
	private Timestamp minDateOfService;
	private Long eCount;
	private Boolean isOverDue;
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public Integer getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public Timestamp getMinDateOfService() {
		return minDateOfService;
	}
	public void setMinDateOfService(Timestamp minDateOfService) {
		this.minDateOfService = minDateOfService;
	}
	public Long geteCount() {
		return eCount;
	}
	public void seteCount(Long eCount) {
		this.eCount = eCount;
	}
	public Boolean getIsOverDue() {
		return isOverDue;
	}
	public void setIsOverDue(Boolean isOverDue) {
		this.isOverDue = isOverDue;
	}
	@Override
	public String toString() {
		return "CoderDashboardDTO [facilityName=" + facilityName
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", minDateOfService=" + minDateOfService + ", eCount="
				+ eCount + ", isOverDue=" + isOverDue + "]";
	}

}
