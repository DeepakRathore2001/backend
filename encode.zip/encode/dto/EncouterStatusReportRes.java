package com.healogics.encode.dto;

import java.util.List;

public class EncouterStatusReportRes {
	
	private String responseCode;
	private String responseMessage;
	private EncounterStatusReportData data;
	
	
	public EncounterStatusReportData getData() {
		return data;
	}
	public void setData(EncounterStatusReportData data) {
		this.data = data;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	
	@Override
	public String toString() {
		return "EncouterStatusReportRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", data=" + data + "]";
	}
	
	public static class EncounterStatusReportData {
		
		private List<String> bbc;
		private List<String> locationType;
		private List<String> providerName;
		private List<Long> providerId;
		private List<Integer> facilityId;
		
		public List<Long> getProviderId() {
			return providerId;
		}


		public void setProviderId(List<Long> providerId) {
			this.providerId = providerId;
		}


		public List<Integer> getFacilityId() {
			return facilityId;
		}


		public void setFacilityId(List<Integer> facilityId) {
			this.facilityId = facilityId;
		}


		public List<String> getBbc() {
			return bbc;
		}


		public void setBbc(List<String> bbc) {
			this.bbc = bbc;
		}

		public List<String> getLocationType() {
			return locationType;
		}


		public void setLocationType(List<String> locationType) {
			this.locationType = locationType;
		}


		public List<String> getProviderName() {
			return providerName;
		}


		public void setProviderName(List<String> providerName) {
			this.providerName = providerName;
		}


		@Override
		public String toString() {
			return "EncounterStatusReportData [bbc=" + bbc + ", locationType=" + locationType + ", providerName="
					+ providerName + ", providerId=" + providerId + ", facilityId=" + facilityId + "]";
		}
		
		

	}
	
	

}
