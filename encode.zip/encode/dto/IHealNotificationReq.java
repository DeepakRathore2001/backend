package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealNotificationReq {
	private String userID;
	private String masterToken;
	
	private String integrationKey;
	private String facilityID;
	private String patientID;
	private String visitID;
	private Timestamp eventDateTime;
	private String dataType;
	private String eventType;
	private String documentEntityId;
	
	private String facilityType;
	//private String bluebookID;
	private String facilityName;
	
	private Date claimSentDate;
	
	private String messageID;
	
	@JsonProperty
	private String coc2Id;
	@JsonProperty
	private String blueBookId;
	
	public String getCoc2Id() {
		return coc2Id;
	}
	public void setCoc2Id(String coc2Id) {
		this.coc2Id = coc2Id;
	}
	public String getBlueBookId() {
		return blueBookId;
	}
	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}
	public String getMessageID() {
		return messageID;
	}
	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}
	public Date getClaimSentDate() {
		return claimSentDate;
	}
	public void setClaimSentDate(Date claimSentDate) {
		this.claimSentDate = claimSentDate;
	}
	public String getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(String documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getFacilityType() {
		return facilityType;
	}
	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getFacilityID() {
		return facilityID;
	}
	public void setFacilityID(String facilityID) {
		this.facilityID = facilityID;
	}
/*	public String getBluebookID() {
		return bluebookID;
	}
	public void setBluebookID(String bluebookID) {
		this.bluebookID = bluebookID;
	}*/
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getPatientID() {
		return patientID;
	}
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}
	public String getVisitID() {
		return visitID;
	}
	public void setVisitID(String visitID) {
		this.visitID = visitID;
	}
	public Timestamp getEventDateTime() {
		return eventDateTime;
	}
	public void setEventDateTime(Timestamp eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getIntegrationKey() {
		return integrationKey;
	}
	public void setIntegrationKey(String integrationKey) {
		this.integrationKey = integrationKey;
	}
	@Override
	public String toString() {
		return "IHealNotificationReq [userID=" + userID + ", masterToken=" + masterToken + ", integrationKey="
				+ integrationKey + ", facilityID=" + facilityID + ", patientID=" + patientID + ", visitID=" + visitID
				+ ", eventDateTime=" + eventDateTime + ", dataType=" + dataType + ", eventType=" + eventType
				+ ", documentEntityId=" + documentEntityId + ", facilityType=" + facilityType
				//+ ", bluebookID=" + bluebookID
				+ ", facilityName=" + facilityName + ", claimSentDate=" + claimSentDate + ", messageID="
				+ messageID + ", coc2Id=" + coc2Id + ", blueBookId=" + blueBookId + "]";
	}

}
