package com.healogics.encode.dto;

import java.util.List;


public class AdministrationEncodeUsersRes {
	
	private String responseCode;
	private String responseMessage;
	private List<EncodeUserDetails> encodeUsers;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<EncodeUserDetails> getEncodeUsers() {
		return encodeUsers;
	}
	public void setEncodeUsers(List<EncodeUserDetails> encodeUsers) {
		this.encodeUsers = encodeUsers;
	}
	@Override
	public String toString() {
		return "AdministrationEncodeUsersRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", encodeUsers=" + encodeUsers + "]";
	}
	
	

}
