package com.healogics.encode.dto;

public class IHealProviderProfileGetRes {
	private String errorCode;
	private String errorMessage;
	private IHealProviderProfile providerProfile;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public IHealProviderProfile getProviderProfile() {
		return providerProfile;
	}

	public void setProviderProfile(IHealProviderProfile providerProfile) {
		this.providerProfile = providerProfile;
	}

	@Override
	public String toString() {
		return "IHealProviderProfileGetRes [errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage
				+ ", providerProfile=" + providerProfile + "]";
	}
}
