package com.healogics.encode.dto;

import java.util.List;



public class SystemNotificationListRes {
	
	private String responseCode;
	private String responseDesc;
	private List<SystemNotificationDetails> systemNotification;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public List<SystemNotificationDetails> getSystemNotification() {
		return systemNotification;
	}
	public void setSystemNotification(List<SystemNotificationDetails> systemNotification) {
		this.systemNotification = systemNotification;
	}
	@Override
	public String toString() {
		return "SystemNotificationListRes [responseCode=" + responseCode + ", responseDesc=" + responseDesc
				+ ", systemNotification=" + systemNotification + "]";
	}
	
	
	

}
