package com.healogics.encode.dto;

public class IHealProviderProfile {
	private Integer providerId;
	private String firstName;
	private String lastName;
	private Integer providerUserId;

	public Integer getProviderId() {
		return providerId;
	}

	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getProviderUserId() {
		return providerUserId;
	}

	public void setProviderUserId(Integer providerUserId) {
		this.providerUserId = providerUserId;
	}

	@Override
	public String toString() {
		return "IHealProviderProfile [providerId=" + providerId
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", providerUserId=" + providerUserId + "]";
	}
}
