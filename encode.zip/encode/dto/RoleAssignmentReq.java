package com.healogics.encode.dto;

import java.util.List;

public class RoleAssignmentReq {

	private Long userId;
	private String username;
	private List<String> encodeRole;
	private List<String> codingTeam;
	private int status;
	
	public List<String> getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(List<String> codingTeam) {
		this.codingTeam = codingTeam;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<String> getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(List<String> encodeRole) {
		this.encodeRole = encodeRole;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "RoleAssignmentReq [userId=" + userId + ", username=" + username + ", encodeRole=" + encodeRole
				+ ", codingTeam=" + codingTeam + ", status=" + status + "]";
	}

}
