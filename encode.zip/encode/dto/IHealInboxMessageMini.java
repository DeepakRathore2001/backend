package com.healogics.encode.dto;

import java.util.List;

public class IHealInboxMessageMini {
	private int messageId;
	private int messageType;
	private IHealPerson sendingUser;
	private IHealPerson recipientUser;
	private String dateReceived;
	private String messageSubject;
	private List<String> attachement;
	private Boolean statusArchived;
	private Boolean statusAssigned;
	private Boolean statusCompleted;
	private Boolean statusRead;
	private int facilityId;
	private int patientId;
	private int visitId;
	
	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public int getMessageType() {
		return messageType;
	}

	public void setMessageType(int messageType) {
		this.messageType = messageType;
	}

	public IHealPerson getSendingUser() {
		return sendingUser;
	}

	public void setSendingUser(IHealPerson sendingUser) {
		this.sendingUser = sendingUser;
	}

	public IHealPerson getRecipientUser() {
		return recipientUser;
	}

	public void setRecipientUser(IHealPerson recipientUser) {
		this.recipientUser = recipientUser;
	}

	public String getDateReceived() {
		return dateReceived;
	}

	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}

	public String getMessageSubject() {
		return messageSubject;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public List<String> getAttachement() {
		return attachement;
	}

	public void setAttachement(List<String> attachement) {
		this.attachement = attachement;
	}

	public Boolean getStatusArchived() {
		return statusArchived;
	}

	public void setStatusArchived(Boolean statusArchived) {
		this.statusArchived = statusArchived;
	}

	public Boolean getStatusAssigned() {
		return statusAssigned;
	}

	public void setStatusAssigned(Boolean statusAssigned) {
		this.statusAssigned = statusAssigned;
	}

	public Boolean getStatusCompleted() {
		return statusCompleted;
	}

	public void setStatusCompleted(Boolean statusCompleted) {
		this.statusCompleted = statusCompleted;
	}

	public Boolean getStatusRead() {
		return statusRead;
	}

	public void setStatusRead(Boolean statusRead) {
		this.statusRead = statusRead;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "IHealInboxMessageMini [messageId=" + messageId + ", messageType=" + messageType + ", sendingUser="
				+ sendingUser + ", recipientUser=" + recipientUser + ", dateReceived=" + dateReceived
				+ ", messageSubject=" + messageSubject + ", attachement=" + attachement + ", statusArchived="
				+ statusArchived + ", statusAssigned=" + statusAssigned + ", statusCompleted=" + statusCompleted
				+ ", statusRead=" + statusRead + ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", visitId=" + visitId + "]";
	}
}
