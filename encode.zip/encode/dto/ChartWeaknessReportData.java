package com.healogics.encode.dto;

import java.util.Date;
import java.util.List;

public class ChartWeaknessReportData {
	private long visitId;
	private String bluebookId;
	private int facilityId;
	private String facilityAlias;
	private Long patientId;
	private String patientName;
	private String ihealConfig;
	private String providerId;
	private String providerName;
	private String medicalRecordNumber;
	private String lastModified;
	private String deficiencyDate;
	private String dateOfService;
	private List<String> deficiencyReason;
	private long agingDays;
	
	public long getAgingDays() {
		return agingDays;
	}
	public void setAgingDays(long agingDays) {
		this.agingDays = agingDays;
	}
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityAlias() {
		return facilityAlias;
	}
	public void setFacilityAlias(String facilityAlias) {
		this.facilityAlias = facilityAlias;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getIhealConfig() {
		return ihealConfig;
	}
	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}
	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}
	
	public String getLastModified() {
		return lastModified;
	}
	public void setLastModified(String lastModified) {
		this.lastModified = lastModified;
	}
	public String getDeficiencyDate() {
		return deficiencyDate;
	}
	public void setDeficiencyDate(String deficiencyDate) {
		this.deficiencyDate = deficiencyDate;
	}
	public String getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}
	public List<String> getDeficiencyReason() {
		return deficiencyReason;
	}
	public void setDeficiencyReason(List<String> deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}
	@Override
	public String toString() {
		return "ChartWeaknessReportData [visitId=" + visitId + ", bluebookId=" + bluebookId + ", facilityId="
				+ facilityId + ", facilityAlias=" + facilityAlias + ", patientId=" + patientId + ", patientName="
				+ patientName + ", ihealConfig=" + ihealConfig + ", providerId=" + providerId + ", providerName="
				+ providerName + ", medicalRecordNumber=" + medicalRecordNumber + ", lastModified=" + lastModified
				+ ", deficiencyDate=" + deficiencyDate + ", dateOfService=" + dateOfService + ", deficiencyReason="
				+ deficiencyReason + ", agingDays=" + agingDays + "]";
	}
	
	

}
