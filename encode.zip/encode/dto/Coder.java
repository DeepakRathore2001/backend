package com.healogics.encode.dto;

public class Coder {

	private Long userId;
	private String username;
	private String userFullName;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	@Override
	public String toString() {
		return "Coder [userId=" + userId + ", username=" + username + ", userFullName=" + userFullName + "]";
	}

}
