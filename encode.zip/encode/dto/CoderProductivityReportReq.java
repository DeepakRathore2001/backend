package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.List;

public class CoderProductivityReportReq {
	
	private Timestamp startDate;
	private Timestamp endDate;
	private List<Integer> coderId;
	private List<String> codeName;
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}
	public Timestamp getEndDate() {
		return endDate;
	}
	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}
	public List<Integer> getCoderId() {
		return coderId;
	}
	public void setCoderId(List<Integer> coderId) {
		this.coderId = coderId;
	}
	public List<String> getCodeName() {
		return codeName;
	}
	public void setCodeName(List<String> codeName) {
		this.codeName = codeName;
	}
	@Override
	public String toString() {
		return "CoderProductivityReportReq [startDate=" + startDate + ", endDate=" + endDate + ", coderId=" + coderId
				+ ", codeName=" + codeName + "]";
	}
	

}
