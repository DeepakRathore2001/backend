package com.healogics.encode.dto;

import java.util.List;

public class UpdateChartstatusReq {

	private List<Long> visitId;
	private long patientId;
	private String action;
	private String userId;
	private String userName;
	private String userFullName;
	private String userRole;
	private String masterToken;
	private String oldStatus;
	private String newStatus;
	private String unbillableReason;
	private String unbillableNote;

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUnbillableReason() {
		return unbillableReason;
	}

	public void setUnbillableReason(String unbillableReason) {
		this.unbillableReason = unbillableReason;
	}

	public String getUnbillableNote() {
		return unbillableNote;
	}

	public void setUnbillableNote(String unbillableNote) {
		this.unbillableNote = unbillableNote;
	}

	public String getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(String oldStatus) {
		this.oldStatus = oldStatus;
	}

	public String getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(String newStatus) {
		this.newStatus = newStatus;
	}

	public List<Long> getVisitId() {
		return visitId;
	}

	public void setVisitId(List<Long> visitId) {
		this.visitId = visitId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	@Override
	public String toString() {
		return "UpdateChartstatusReq [visitId=" + visitId + ", patientId=" + patientId + ", action=" + action
				+ ", userId=" + userId + ", userName=" + userName + ", userFullName=" + userFullName + ", userRole="
				+ userRole + ", masterToken=" + masterToken + ", oldStatus=" + oldStatus + ", newStatus=" + newStatus
				+ ", unbillableReason=" + unbillableReason + ", unbillableNote=" + unbillableNote + "]";
	}

}
