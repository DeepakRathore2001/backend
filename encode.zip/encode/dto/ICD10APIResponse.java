package com.healogics.encode.dto;

import java.util.Arrays;

public class ICD10APIResponse {
	private Object[] icd10Data;
	private String errorCode;
	private String errorMessage;
	
	public Object[] getIcd10Data() {
		return icd10Data;
	}
	public void setIcd10Data(Object[] icd10Data) {
		this.icd10Data = icd10Data;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "ICD10APIResponse [icd10Data=" + Arrays.toString(icd10Data) + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + "]";
	}
}
