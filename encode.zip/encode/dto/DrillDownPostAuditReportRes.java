package com.healogics.encode.dto;

import java.util.List;

public class DrillDownPostAuditReportRes extends APIResponse {

	private List<PostAuditObj> audits;

	public List<PostAuditObj> getAudits() {
		return audits;
	}

	public void setAudits(List<PostAuditObj> audits) {
		this.audits = audits;
	}

	@Override
	public String toString() {
		return "DrillDownPostAuditReportRes [audits=" + audits + "]";
	}

}
