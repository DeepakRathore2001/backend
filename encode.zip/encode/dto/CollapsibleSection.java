package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

public class CollapsibleSection {
	private Timestamp dateOfService;
	private String status;
	private long visitId;
	private String medicalRecordNumber;
	private String firstName;
	private String lastName;
	private String primaryInsurance;
	private String secondaryInsurance;
	private String insurance;
	private String insuranceType;
	private Date receivedDate;
	private boolean recordOverDue;
	private String bbc;
	private String facilityName;
	private String gender;
	private Date patientDOB;
	private long age;
	private long recordAge;
	private Long patientId;
	private int facilityId;
	private int isLocked;
	private Boolean isProgressNoteSigned;
	private Boolean isHBOSigned;
	private String dashboardName;
	private String ihealConfig;
	private String userFullName;

	
	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}

	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public Boolean getIsProgressNoteSigned() {
		return isProgressNoteSigned;
	}

	public void setIsProgressNoteSigned(Boolean isProgressNoteSigned) {
		this.isProgressNoteSigned = isProgressNoteSigned;
	}

	public Boolean getIsHBOSigned() {
		return isHBOSigned;
	}

	public void setIsHBOSigned(Boolean isHBOSigned) {
		this.isHBOSigned = isHBOSigned;
	}

	public long getRecordAge() {
		return recordAge;
	}

	public void setRecordAge(long recordAge) {
		this.recordAge = recordAge;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public long getAge() {
		return age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public long getVisitId() {
		return visitId;
	}

	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public boolean isRecordOverDue() {
		return recordOverDue;
	}

	public void setRecordOverDue(boolean recordOverDue) {
		this.recordOverDue = recordOverDue;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public String getDashboardName() {
		return dashboardName;
	}

	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}


	@Override
	public String toString() {
		return "CollapsibleSection [dateOfService=" + dateOfService + ", status=" + status + ", visitId=" + visitId
				+ ", medicalRecordNumber=" + medicalRecordNumber + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", primaryInsurance=" + primaryInsurance + ", secondaryInsurance=" + secondaryInsurance
				+ ", insurance=" + insurance + ", insuranceType=" + insuranceType + ", receivedDate=" + receivedDate
				+ ", recordOverDue=" + recordOverDue + ", bbc=" + bbc + ", facilityName=" + facilityName + ", gender="
				+ gender + ", patientDOB=" + patientDOB + ", age=" + age + ", recordAge=" + recordAge + ", patientId="
				+ patientId + ", facilityId=" + facilityId + ", isLocked=" + isLocked + ", isProgressNoteSigned="
				+ isProgressNoteSigned + ", isHBOSigned=" + isHBOSigned + ", dashboardName=" + dashboardName
				+ ", ihealConfig=" + ihealConfig + ", userFullName=" + userFullName + "]";
	}

}
