package com.healogics.encode.dto;

import java.util.List;

public class ChartByStatusRes extends APIResponse {

	private List<AuditorCollapsibleSectionData> chartData;

	public List<AuditorCollapsibleSectionData> getChartData() {
		return chartData;
	}

	public void setChartData(List<AuditorCollapsibleSectionData> chartData) {
		this.chartData = chartData;
	}

	@Override
	public String toString() {
		return "ChartByStatusRes [chartData=" + chartData + "]";
	}

}
