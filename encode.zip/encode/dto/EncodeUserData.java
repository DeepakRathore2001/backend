package com.healogics.encode.dto;

import java.util.List;

public class EncodeUserData {

	private Long userId;
	private String userFullName;
	private String userName;
	private List<String> ihealRole;
	private List<String> encodeRole;
	private List<String> codingTeam;
	private int status;

	public List<String> getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(List<String> codingTeam) {
		this.codingTeam = codingTeam;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<String> getIhealRole() {
		return ihealRole;
	}

	public void setIhealRole(List<String> ihealRole) {
		this.ihealRole = ihealRole;
	}

	public List<String> getEncodeRole() {
		return encodeRole;
	}

	public void setEncodeRole(List<String> encodeRole) {
		this.encodeRole = encodeRole;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "EncodeUserData [userId=" + userId + ", userFullName=" + userFullName + ", userName=" + userName
				+ ", ihealRole=" + ihealRole + ", encodeRole=" + encodeRole + ", codingTeam=" + codingTeam + ", status="
				+ status + "]";
	}

}
