package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CoderChartDetails {
	private Long visitId;
	private Long patientId;
	private Integer facilityId;
	private String bbc;
	private String facilityName;
	private Date receivedDate;
	private Date interfaceDate;
	private String providerName;
	private Timestamp dateOfService;
	private String medicalRecordNumber;
	private String encounterType;
	private String assigneeUsername;
	private Long assigneeUserId;
	private String assigneeUserFullname;
	private String status;
	private Long accountNumber;
	private Long age;
	// private String insurance;
	private String primaryInsurance;
	private String secondaryInsurance;
	private String gender;
	private String ihealConfig;
	private Date patientDOB;
	private String patientName;
	private String patientFirstName;
	private String patientLastName;
	private String DashboardName;
	private String userId;
	private String userName;
	private String userFullName;
	private String serviceLine;
	private String validatedCMCUser;
	private String validatedUserFirstName;
	private String validatedUserLastName;
	private String completedCoderUser;
	private int isLocked;
	private String facilityType;
	private String lockedByUserId;

	private String coc2Id;
	private String blueBookId;

	private boolean progNoteSigned;
	private boolean hboSigned;

	private boolean isIHealDocEmpty;
	private boolean isCoderDocEmpty;

	private Timestamp startTime;
	private Timestamp endTime;

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public Date getInterfaceDate() {
		return interfaceDate;
	}

	public void setInterfaceDate(Date interfaceDate) {
		this.interfaceDate = interfaceDate;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Timestamp getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Timestamp dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getEncounterType() {
		return encounterType;
	}

	public void setEncounterType(String encounterType) {
		this.encounterType = encounterType;
	}

	public String getAssigneeUsername() {
		return assigneeUsername;
	}

	public void setAssigneeUsername(String assigneeUsername) {
		this.assigneeUsername = assigneeUsername;
	}

	public Long getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(Long assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserFullname() {
		return assigneeUserFullname;
	}

	public void setAssigneeUserFullname(String assigneeUserFullname) {
		this.assigneeUserFullname = assigneeUserFullname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getAge() {
		return age;
	}

	public void setAge(Long age) {
		this.age = age;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}

	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getDashboardName() {
		return DashboardName;
	}

	public void setDashboardName(String dashboardName) {
		DashboardName = dashboardName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getValidatedCMCUser() {
		return validatedCMCUser;
	}

	public void setValidatedCMCUser(String validatedCMCUser) {
		this.validatedCMCUser = validatedCMCUser;
	}

	public String getValidatedUserFirstName() {
		return validatedUserFirstName;
	}

	public void setValidatedUserFirstName(String validatedUserFirstName) {
		this.validatedUserFirstName = validatedUserFirstName;
	}

	public String getValidatedUserLastName() {
		return validatedUserLastName;
	}

	public void setValidatedUserLastName(String validatedUserLastName) {
		this.validatedUserLastName = validatedUserLastName;
	}

	public String getCompletedCoderUser() {
		return completedCoderUser;
	}

	public void setCompletedCoderUser(String completedCoderUser) {
		this.completedCoderUser = completedCoderUser;
	}

	public int getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(int isLocked) {
		this.isLocked = isLocked;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getLockedByUserId() {
		return lockedByUserId;
	}

	public void setLockedByUserId(String lockedByUserId) {
		this.lockedByUserId = lockedByUserId;
	}

	public String getCoc2Id() {
		return coc2Id;
	}

	public void setCoc2Id(String coc2Id) {
		this.coc2Id = coc2Id;
	}

	public String getBlueBookId() {
		return blueBookId;
	}

	public void setBlueBookId(String blueBookId) {
		this.blueBookId = blueBookId;
	}

	public boolean isProgNoteSigned() {
		return progNoteSigned;
	}

	public void setProgNoteSigned(boolean progNoteSigned) {
		this.progNoteSigned = progNoteSigned;
	}

	public boolean isHboSigned() {
		return hboSigned;
	}

	public void setHboSigned(boolean hboSigned) {
		this.hboSigned = hboSigned;
	}

	public boolean isIHealDocEmpty() {
		return isIHealDocEmpty;
	}

	public void setIHealDocEmpty(boolean isIHealDocEmpty) {
		this.isIHealDocEmpty = isIHealDocEmpty;
	}

	public boolean isCoderDocEmpty() {
		return isCoderDocEmpty;
	}

	public void setCoderDocEmpty(boolean isCoderDocEmpty) {
		this.isCoderDocEmpty = isCoderDocEmpty;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	@Override
	public String toString() {
		return "CoderChartDetails [visitId=" + visitId + ", patientId=" + patientId + ", facilityId=" + facilityId
				+ ", bbc=" + bbc + ", facilityName=" + facilityName + ", receivedDate=" + receivedDate
				+ ", interfaceDate=" + interfaceDate + ", providerName=" + providerName + ", dateOfService="
				+ dateOfService + ", medicalRecordNumber=" + medicalRecordNumber + ", encounterType=" + encounterType
				+ ", assigneeUsername=" + assigneeUsername + ", assigneeUserId=" + assigneeUserId
				+ ", assigneeUserFullname=" + assigneeUserFullname + ", status=" + status + ", accountNumber="
				+ accountNumber + ", age=" + age + ", primaryInsurance=" + primaryInsurance + ", secondaryInsurance="
				+ secondaryInsurance + ", gender=" + gender + ", ihealConfig=" + ihealConfig + ", patientDOB="
				+ patientDOB + ", patientName=" + patientName + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", DashboardName=" + DashboardName + ", userId=" + userId
				+ ", userName=" + userName + ", userFullName=" + userFullName + ", serviceLine=" + serviceLine
				+ ", validatedCMCUser=" + validatedCMCUser + ", validatedUserFirstName=" + validatedUserFirstName
				+ ", validatedUserLastName=" + validatedUserLastName + ", completedCoderUser=" + completedCoderUser
				+ ", isLocked=" + isLocked + ", facilityType=" + facilityType + ", lockedByUserId=" + lockedByUserId
				+ ", coc2Id=" + coc2Id + ", blueBookId=" + blueBookId + ", progNoteSigned=" + progNoteSigned
				+ ", hboSigned=" + hboSigned + ", isIHealDocEmpty=" + isIHealDocEmpty + ", isCoderDocEmpty="
				+ isCoderDocEmpty + ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}

}
