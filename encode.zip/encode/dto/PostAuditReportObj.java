package com.healogics.encode.dto;

import java.sql.Timestamp;
import java.util.Date;

public class PostAuditReportObj {

	private String coderName;
	private String codingTeam;
	private long visitId;
	private String providerName;
	private String bbc;
	private Date dateOfService;
	//private boolean codingError;
	private String codingError;
	private String auditNote;
	private String chartCodes;
	private Date auditDate;
	private String filterName;
	
	public Date getAuditDate() {
		return auditDate;
	}
	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public Date getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}
	
	public String getAuditNote() {
		return auditNote;
	}
	public void setAuditNote(String auditNote) {
		this.auditNote = auditNote;
	}
	public String getChartCodes() {
		return chartCodes;
	}
	public void setChartCodes(String chartCodes) {
		this.chartCodes = chartCodes;
	}
	public String getCoderName() {
		return coderName;
	}
	public void setCoderName(String coderName) {
		this.coderName = coderName;
	}
	public String getCodingTeam() {
		return codingTeam;
	}
	public void setCodingTeam(String codingTeam) {
		this.codingTeam = codingTeam;
	}
	
	public long getVisitId() {
		return visitId;
	}
	public void setVisitId(long visitId) {
		this.visitId = visitId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	
	public String getCodingError() {
		return codingError;
	}
	public void setCodingError(String codingError) {
		this.codingError = codingError;
	}
	@Override
	public String toString() {
		return "PostAuditReportObj [coderName=" + coderName + ", codingTeam=" + codingTeam + ", visitId=" + visitId
				+ ", providerName=" + providerName + ", bbc=" + bbc + ", dateOfService=" + dateOfService
				+ ", codingError=" + codingError + ", auditNote=" + auditNote + ", chartCodes=" + chartCodes
				+ ", auditDate=" + auditDate + ", filterName=" + filterName + "]";
	}
	
	
}
