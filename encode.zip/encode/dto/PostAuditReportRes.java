package com.healogics.encode.dto;

import java.util.List;

public class PostAuditReportRes {
	private String responseCode;
	private String responseMessage;
	private List<PostAuditReportObj> reportData;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<PostAuditReportObj> getReportData() {
		return reportData;
	}
	public void setReportData(List<PostAuditReportObj> reportData) {
		this.reportData = reportData;
	}
	@Override
	public String toString() {
		return "PostAuditReportRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", reportData=" + reportData + "]";
	}
	
	

}
