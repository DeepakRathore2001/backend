package com.healogics.encode.dto;

import java.util.List;

public class CodingTeamRes extends APIResponse {

	private List<String> codingTeam;

	
	public List<String> getCodingTeam() {
		return codingTeam;
	}


	public void setCodingTeam(List<String> codingTeam) {
		this.codingTeam = codingTeam;
	}


	@Override
	public String toString() {
		return "BillingClientRes [codingTeam=" + codingTeam + "]";
	}

}
