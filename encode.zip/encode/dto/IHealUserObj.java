package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealUserObj implements Serializable {
	private static final long serialVersionUID = 1L;

	private String userName;
	private String firstName;
	private String lastName;
	private String middleName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private String email;
	private List<String> roles;
	private String userId;
	private String lastLogonTime;
	private boolean moreFacilities;
	@JsonProperty("PositionCode")
	private int positionCode;
	@JsonProperty("PositionDescription")
	private String positionDescription;
	@JsonProperty("EmployedByCode")
	private int employedByCode;
	@JsonProperty("EmployedByDescription")
	private String employedByDescription;
	private boolean termsAndConditions;
	private boolean passwordChange;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLastLogonTime() {
		return lastLogonTime;
	}

	public void setLastLogonTime(String lastLogonTime) {
		this.lastLogonTime = lastLogonTime;
	}

	public boolean isMoreFacilities() {
		return moreFacilities;
	}

	public void setMoreFacilities(boolean moreFacilities) {
		this.moreFacilities = moreFacilities;
	}

	public int getPositionCode() {
		return positionCode;
	}

	public void setPositionCode(int positionCode) {
		this.positionCode = positionCode;
	}

	public String getPositionDescription() {
		return positionDescription;
	}

	public void setPositionDescription(String positionDescription) {
		this.positionDescription = positionDescription;
	}

	public int getEmployedByCode() {
		return employedByCode;
	}

	public void setEmployedByCode(int employedByCode) {
		this.employedByCode = employedByCode;
	}

	public String getEmployedByDescription() {
		return employedByDescription;
	}

	public void setEmployedByDescription(String employedByDescription) {
		this.employedByDescription = employedByDescription;
	}

	public boolean isTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(boolean termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public boolean isPasswordChange() {
		return passwordChange;
	}

	public void setPasswordChange(boolean passwordChange) {
		this.passwordChange = passwordChange;
	}

	@Override
	public String toString() {
		return "IHealUserObj [userName=" + userName + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", middleName=" + middleName + ", address1=" + address1 + ", address2=" + address2 + ", city=" + city
				+ ", state=" + state + ", zip=" + zip + ", phone=" + phone + ", email=" + email + ", roles=" + roles
				+ ", userId=" + userId + ", lastLogonTime=" + lastLogonTime + ", moreFacilities=" + moreFacilities
				+ ", positionCode=" + positionCode + ", positionDescription=" + positionDescription
				+ ", employedByCode=" + employedByCode + ", employedByDescription=" + employedByDescription
				+ ", termsAndConditions=" + termsAndConditions + ", passwordChange=" + passwordChange + "]";
	}

}
