package com.healogics.encode.dto;

import java.io.Serializable;

public class IHealUser implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String userId;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId2) {
		this.userId = userId2;
	}

	@Override
	public String toString() {
		return "IHealUser [privateKey=" + privateKey + ", masterToken="
				+ masterToken + ", userId=" + userId + "]";
	}

}

