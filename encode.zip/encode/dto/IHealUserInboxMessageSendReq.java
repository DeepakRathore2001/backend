package com.healogics.encode.dto;

import java.util.List;

public class IHealUserInboxMessageSendReq {
	private String privateKey;
	private String masterToken;
	private Integer userId;
	private Integer messageType;
	private List<Integer> recipients;
	private String messageSubject;
	private String messageBody;
	private Integer facilityId;
	private Integer patientId;
	private Integer visitId;
	private String referenceLinkUrl ;
	private String referenceLinkDescription ;
	
	
	
	public String getReferenceLinkUrl() {
		return referenceLinkUrl;
	}

	public void setReferenceLinkUrl(String referenceLinkUrl) {
		this.referenceLinkUrl = referenceLinkUrl;
	}

	public String getReferenceLinkDescription() {
		return referenceLinkDescription;
	}

	public void setReferenceLinkDescription(String referenceLinkDescription) {
		this.referenceLinkDescription = referenceLinkDescription;
	}

	public Integer getVisitId() {
		return visitId;
	}

	public void setVisitId(Integer visitId) {
		this.visitId = visitId;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getMessageType() {
		return messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

	public List<Integer> getRecipients() {
		return recipients;
	}

	public void setRecipients(List<Integer> recipients) {
		this.recipients = recipients;
	}

	public String getMessageSubject() {
		return messageSubject;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "IHealUserInboxMessageSendReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId="
				+ userId + ", messageType=" + messageType + ", recipients=" + recipients + ", messageSubject="
				+ messageSubject + ", messageBody=" + messageBody + ", facilityId=" + facilityId + ", patientId="
				+ patientId + ", visitId=" + visitId + ", referenceLinkUrl=" + referenceLinkUrl
				+ ", referenceLinkDescription=" + referenceLinkDescription + "]";
	}
}
