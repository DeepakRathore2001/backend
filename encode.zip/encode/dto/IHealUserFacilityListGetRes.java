package com.healogics.encode.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IHealUserFacilityListGetRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<IhealFacility> Facilities = new ArrayList<>();

	@Override
	public String toString() {
		return "UserFacilitiesResponse [Facilities=" + Facilities
		// + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
				+ "]";
	}
    
    private String errorCode = "0";
    private String errorMessage = "Success";
    private String responseCode;
    private String responseMessage;
    
    public List<IhealFacility> getFacilities() {
		return Facilities;
	}
    @JsonSetter("Facilities")
	public void setFacilities(List<IhealFacility> facilities) {
		Facilities = facilities;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
}
    
	