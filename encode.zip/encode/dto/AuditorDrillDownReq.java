package com.healogics.encode.dto;

import java.util.List;

public class AuditorDrillDownReq {

	private String filters;
	private List<String> codingTeam;
	private String coder;

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public List<String> getCodingTeam() {
		return codingTeam;
	}

	public void setCodingTeam(List<String> codingTeam) {
		this.codingTeam = codingTeam;
	}

	public String getCoder() {
		return coder;
	}

	public void setCoder(String coder) {
		this.coder = coder;
	}

	@Override
	public String toString() {
		return "AuditorDrillDownReq [filters=" + filters + ", codingTeam=" + codingTeam + ", coder=" + coder + "]";
	}

}
