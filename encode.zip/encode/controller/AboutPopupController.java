package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SAVE_BUILD_DETAILS;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.BuildDetailsResponse;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.SaveBuildDetailsReq;
import com.healogics.encode.service.AboutPopupBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AboutPopupController {

	private final Logger log = LoggerFactory.getLogger(AboutPopupController.class);

	private final AboutPopupBO aboutPopupBO;

	@Autowired
	public AboutPopupController(AboutPopupBO aboutPopupBO) {
		this.aboutPopupBO = aboutPopupBO;
	}

	@ApiOperation(value = "To get build details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC) })
	@GetMapping(value = "/app/buildversion", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getBuildVersion() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		BuildDetailsResponse buildDetails = null;
		Map<String, Object> messageHeader;
		try {
			buildDetails = aboutPopupBO.getBuildDetails();
			log.info("buildDetails : {}", buildDetails);

			if (buildDetails == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.BUILD_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.BUILD_DETAILS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, buildDetails);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.BUILD_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.BUILD_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.BUILD_DETAILS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, buildDetails);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.BUILD_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.BUILD_DETAILS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.BUILD_DETAILS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, buildDetails);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.BUILD_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To save build details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/savebuilddetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveNotes(
			@ApiParam(name = "SaveBuildDetailsReq", value = "SaveBuildDetailsReq data", required = true) @RequestBody SaveBuildDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NotesRes res = null;
		Map<String, Object> response = null;
		try {

			res = aboutPopupBO.saveBuildDetails(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_BUILD_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_BUILD_DETAILS, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_BUILD_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_BUILD_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_BUILD_DETAILS, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_BUILD_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_BUILD_DETAILS, formattedDate);
			response = CommonUtils.getResponseObject(SAVE_BUILD_DETAILS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_BUILD_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
