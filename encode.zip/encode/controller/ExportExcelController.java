package com.healogics.encode.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.AdminDashboardReq;
import com.healogics.encode.dto.AdminDashboardRes;
import com.healogics.encode.dto.AuditorDashboardReq;
import com.healogics.encode.dto.AuditorExcelRes;
import com.healogics.encode.dto.CMCDashboardRes;
import com.healogics.encode.dto.ChartWeaknessReportRes;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.CoderDashboardRes;
import com.healogics.encode.dto.CoderProductivityReportDrilldownRes;
import com.healogics.encode.dto.CoderProductivityReportReq;
import com.healogics.encode.dto.CoderProductivityReportRes;
import com.healogics.encode.dto.CollapsibleSectionRes;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.DrillDownMissingChartReportRes;
import com.healogics.encode.dto.DrillDownMonthlyChargeSummaryRes;
import com.healogics.encode.dto.DrillDownPostAuditReportRes;
import com.healogics.encode.dto.EncounterMonthlyReviewRes;
import com.healogics.encode.dto.EncounterStatusReportGenerateRes;
import com.healogics.encode.dto.EncounterStatusReportReq;
import com.healogics.encode.dto.EncounterUnderReviewCountRes;
import com.healogics.encode.dto.EncounterUnderReviewRes;
import com.healogics.encode.dto.GuidanceReportReq;
import com.healogics.encode.dto.GuidanceReportRes;
import com.healogics.encode.dto.MissingChartDataRes;
import com.healogics.encode.dto.MonthlyChargeSummaryReportRes;
import com.healogics.encode.dto.NurseAuditNotesReportReq;
import com.healogics.encode.dto.NurseAuditNotesReportRes;
import com.healogics.encode.dto.PostAuditFiltersRes;
import com.healogics.encode.dto.ReconReportReq;
import com.healogics.encode.dto.ReconReportRes;
import com.healogics.encode.dto.ReportFilterReq;
import com.healogics.encode.dto.SuperbillVarianceReportRes;
import com.healogics.encode.dto.SuperbillVarianceRes;
import com.healogics.encode.dto.WeeklyIncompleteReportRes;
import com.healogics.encode.dto.ecWSentReportReq;
import com.healogics.encode.dto.ecWSentReportRes;
import com.healogics.encode.service.AdministrationBO;
import com.healogics.encode.service.AuditorDashboardBO;
import com.healogics.encode.service.CMCDashboardBO;
import com.healogics.encode.service.CoderDashboardBO;
import com.healogics.encode.service.EncounterStatusReportBO;
import com.healogics.encode.service.ReportBO;
import com.healogics.encode.util.CommonUtils;
import com.healogics.encode.util.ExportExcelUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
  
@RestController
public class ExportExcelController {

	private final Logger log = LoggerFactory.getLogger(ExportExcelController.class);

	private final CMCDashboardBO dashboardBO;

	private final CoderDashboardBO coderDashboardBO;

	private final AdministrationBO adminDashboardBO;
	
	private final AuditorDashboardBO auditorDashboardBO;
	
	private final ReportBO reportBO;
	
	private final EncounterStatusReportBO encounterStatusReportBO;

	@Autowired
	public ExportExcelController(CMCDashboardBO dashboardBO, CoderDashboardBO coderDashboardBO,
			AdministrationBO adminDashboardBO, AuditorDashboardBO auditorDashboardBO, ReportBO reportBO,
			 EncounterStatusReportBO encounterStatusReportBO) {
		this.dashboardBO = dashboardBO;
		this.coderDashboardBO = coderDashboardBO;
		this.adminDashboardBO = adminDashboardBO;
		this.auditorDashboardBO = auditorDashboardBO;
		this.reportBO = reportBO;
		this.encounterStatusReportBO = encounterStatusReportBO;
	}

	@ApiOperation(value = "To export excel for encode dashboard")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/dashboardexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityDashboardExcel(
			@ApiParam(name = "Export Encode Dashboard Excel", value = "Export Encode Dashboard Excel", required = true) @RequestBody DashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CMCDashboardRes cmcDashboardRes = new CMCDashboardRes();
		CollapsibleSectionRes coderDashboardRes = new CollapsibleSectionRes();
		CoderDashboardRes res = new CoderDashboardRes();
		String excelStream = "";
		boolean isFilter = false;
		try {
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}

			switch (req.getDashboardName()) {
			case "CMC":
				cmcDashboardRes = dashboardBO.getAllCMCData(isFilter, req, 0, req.getTaskType(), req.getUsername(),
						false);

				log.debug("cmcDashboardRes: {}", cmcDashboardRes);
				excelStream = ExportExcelUtil.generateDashboardExcel(req, cmcDashboardRes.getCmcData());
				break;
			/*case "coder":
				coderDashboardRes = coderDashboardBO.getAllCoderData(isFilter, req, 0, req.getTaskType(),
						req.getUsername());
				log.debug("coderDashboardRes: {}", coderDashboardRes);
				excelStream = ExportExcelUtil.generateCoderDashboardExcel(req,
						coderDashboardRes.getCollapsibleSection());
				break;*/
			default:
				throw new IllegalArgumentException("Invalid dashboard name: " + req.getDashboardName());
			}

			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (IllegalArgumentException e) {
			log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To export admin excel for encode dashboard")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/admindashboardexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAdminDashboardExcel(
			@ApiParam(name = "Export Admin Encode Dashboard Excel", value = "Export Admin Encode Dashboard Excel", required = true) @RequestBody AdminDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AdminDashboardRes adminDashboardRes = new AdminDashboardRes();
		String excelStream = "";
		boolean isFilter = false;
		try {
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}

			adminDashboardRes = adminDashboardBO.getEncodeUsers(isFilter, req, 0, true);

			log.debug("adminDashboardRes: {}", adminDashboardRes);
			excelStream = ExportExcelUtil.generateAdminDashboardExcel(req, adminDashboardRes.getEncodeUsers());

			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (IllegalArgumentException e) {
			log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export auditor excel for encode dashboard")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/auditordashboardexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditorDashboardExcel(
			@ApiParam(name = "Export Auditor Dashboard Excel", value = "Export Auditor Encode Dashboard Excel", required = true) @RequestBody AuditorDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AuditorExcelRes auditorDashboardRes = new AuditorExcelRes();
		String excelStream = "";
		boolean isFilter = false;
		try {
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}

			auditorDashboardRes = auditorDashboardBO.getAllAuditorData(isFilter, req, 0);
			

			log.debug("auditorDashboardRes: {}", auditorDashboardRes);
			
			excelStream = ExportExcelUtil.generateAuditorDashboardExcel(req,
					auditorDashboardRes.getCollapsibleSection());

			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (IllegalArgumentException e) {
			log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export recon report to excel")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/reconreportexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getReconReportExcel(
			@ApiParam(name = "Export Recon Report Excel", value = "Export Recon Report Excel", required = true) 
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		ReconReportRes res = new ReconReportRes();
		String excelStream = "";
		boolean isFilter = false;
		try {

			res = reportBO.reconReports(req);

			excelStream = ExportExcelUtil.generateReconReportExcel(req, res.getReportData());

			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (IllegalArgumentException e) {
			log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export monthly summary to excel")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/monthlysummaryreportexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getMonthlySummaryReportExcel(
			@ApiParam(name = "Export Recon Report Excel", value = "Export Recon Report Excel", required = true) 
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		DrillDownMonthlyChargeSummaryRes res = new DrillDownMonthlyChargeSummaryRes();
		String excelStream = "";
		boolean isFilter = false;
		try {

			res = reportBO.drillDownMonthlyChargeSummaryReport(req.getCptCodes(),req);

			excelStream = ExportExcelUtil.MonthlySummaryReportExcel(req, res.getReport());

			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (IllegalArgumentException e) {
			log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Post Audit")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/postauditexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getPostAuditExcel(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		DrillDownPostAuditReportRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = reportBO.drillDownPostAuditReport(req, isExcel);
			//log.debug("viewReportsRes: " + res);
			excelStream = ExportExcelUtil
					.generatePostAuditExcel(res.getAudits());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Encounter Needing Guidance")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/encounterguidanceexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNeedingGuidanceExcel(
			@ApiParam(name = "GuidanceReportReq", value = "GuidanceReportReq data", required = true)
			@RequestBody GuidanceReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		GuidanceReportRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = reportBO.guidanceReport(req);
			//log.debug("viewReportsRes: " + res);
			excelStream = ExportExcelUtil
					.generateNeedingGuidanceExcel(res.getReportData());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Encounter Review Monthly")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/encounterreviewmonthlyeexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEnccountReviewMonthlyExcel(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		EncounterMonthlyReviewRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = reportBO.getEncounterUnderReviewmonthly(req);
			//log.debug("viewReportsRes: " + res);
			excelStream = ExportExcelUtil
					.generateEncounterReviewMonthlyExcel(res.getData());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Encounter Under Review")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/encounterunderrevieweexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEnccountUnderReviewExcel(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		EncounterUnderReviewRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = reportBO.getEncounterUnderReviewReport(req);
			//log.debug("viewReportsRes: " + res);
			excelStream = ExportExcelUtil
					.generateEncounterUnderReviewExcel(res.getData());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Encounter Under Review")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/encounterreportexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEnccountReportExcel(
			@ApiParam(name = "EncounterStatusReportReq", 
			value = "EncounterStatusReportReq data", required = true) 
			@RequestBody EncounterStatusReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		EncounterStatusReportGenerateRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = encounterStatusReportBO.generateEncounterReport(req);
			//log.debug("viewReportsRes: " + res);

			excelStream = ExportExcelUtil
					.generateEncounterReportDataExcel(res.getDataList(),req);

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Superbill Variance Report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/superbillreportexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSuperBillVarianceExcel(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		SuperbillVarianceReportRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = reportBO.generateSuperbillVarianceReport(req.getFacilityId(), req);
			//log.debug("viewReportsRes: " + res);

			excelStream = ExportExcelUtil
					.generateSuperbillReportExcel(res.getDataList());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//Incomplete Summary
	@ApiOperation(value = "To export excel for Missing Chart")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/missingchartsexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getMissingChartExcel(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		DrillDownMissingChartReportRes res = null;
		String excelStream = "";

		try {
			//boolean isExcel = true;
			res = reportBO.drillDownMissingChartReport(req);
			//log.debug("viewReportsRes: " + res);

			excelStream = ExportExcelUtil
					.generateMissingChartExcel(res.getCharts());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export deficiency aging report to excel")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/deficiencyagingreportexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDeficiencyAgingReportExcel(
			@ApiParam(name = "Export Recon Report Excel", value = "Export Recon Report Excel", required = true) 
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		ChartWeaknessReportRes res = new ChartWeaknessReportRes();
		String excelStream = "";
		boolean isFilter = false;
		try {

			res = reportBO.deficiencyAgingReport(req);
			
			if(res == null || res.getData() == null){
				log.error("Report generated failed, no data returned from reportBO");
				throw new IllegalArgumentException("Report data is null");
				
			}

			excelStream = ExportExcelUtil.generateDeficiencyAgingReportExcel(req, res.getData());

			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (IllegalArgumentException e) {
			log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
		@ApiOperation(value = "To export excel for Encounter Under Review Main Table")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/encounterunderreviewexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> encounterUnderReviewCountExcel(
				@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
				@RequestBody ReconReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			EncounterUnderReviewCountRes res = null;
			String excelStream = "";

			try {
				//boolean isExcel = true;
				res = reportBO.getEncounterUnderReviewCount(req);
				//log.debug("viewReportsRes: " + res);

				excelStream = ExportExcelUtil
						.generateEncounterUnderReviewMainTableExcel(res.getData());

				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To export excel for Missing Chart Main Table")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/missingchartdataexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> missingChartDataExcel(
				@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
				@RequestBody ReconReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			MissingChartDataRes res = null;
			String excelStream = "";

			try {
				//boolean isExcel = true;
				res = reportBO.missingChartDataReport(req);
				//log.debug("viewReportsRes: " + res);

				excelStream = ExportExcelUtil
						.generateMissingChartMainTableExcel(res.getChartsData(),res.getTotal());

				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		
		@ApiOperation(value = "To export excel for SuperBill Variance Main Table")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/superbillvariancedataexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> superbillVarianceDataExcel(
				@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
				@RequestBody ReconReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			SuperbillVarianceRes res = null;
			String excelStream = "";

			try {
				//boolean isExcel = true;
				res = reportBO.superbillVarianceReportData(req);
				//log.debug("viewReportsRes: " + res);

				excelStream = ExportExcelUtil
						.generateSuperBillVarianceMainTableExcel(res.getDataList(),res.getTotal());

				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To generate weekly incomplete report")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/weeklyincompletereportexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> weeklyIncompleteReportExcel(
				@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
				@RequestBody ReconReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			WeeklyIncompleteReportRes res = null;
			String excelStream = "";

			try {
				//boolean isExcel = true;
				res = reportBO.weeklyIncompleteReportExcel(req);
				//log.debug("viewReportsRes: " + res);

				excelStream = ExportExcelUtil
						.generateWeeklyIncompleteReportExcel(res.getDataList());

				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
		
	
		@ApiOperation(value = "To export excel for Monthly Summary Data Main Table")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/monthlysummmaryexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> monthlySummaryDataExcel(
				@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
				@RequestBody ReconReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			MonthlyChargeSummaryReportRes res = null;
			String excelStream = "";

			try {

				res = reportBO.monthlyChargeSummaryReport(req);

				excelStream = ExportExcelUtil
						.generateMonthlySummaryMainTableExcel(res.getCodesList());

				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To export excel for Monthly Summary Data Drill Down Table")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/generatemonthlysummaryexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> monthlySummaryDrillExcel(
				@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
				@RequestBody ReconReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			String statusCode = ControllerConstants.SUCCESS_CODE;
			String errorCode = ControllerConstants.ZERO_ERROR_CODE;
			String statusDesc = ControllerConstants.SUCCESS_DESC;
			DrillDownMonthlyChargeSummaryRes res = null;
			String excelStream = "";

			try {
				
				/*if (StringUtils.isBlank(req.getCptCodes())) {
					
					statusCode = ControllerConstants.INVALID_PARAMETERS;
					errorCode = ControllerConstants.ERROR_CODE_NUMBER;
					statusDesc = ControllerConstants.INVALID_PARAMETERS;
					response = CommonUtils.getResponseObject(
							ControllerConstants.EXPORT_EXCEL, statusCode,
							errorCode, statusDesc);
					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.EXPORT_EXCEL);
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
				}*/

				res = reportBO.drillDownMonthlyChargeSummaryReport(req.getCptCodes(),req);


				excelStream = ExportExcelUtil
						.generateMonthlySummaryDrillDownExcel(res.getReport());

				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To export nurse audit notes report to excel")
		@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
		@PostMapping(value = "/app/nurseauditnotesreportexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> getNurseAuditNotesReportExcel(
				@ApiParam(name = "Export Nurse Audit Notes Report Excel", value = "Export Nurse Audit Notes Report Excel", required = true) 
				@RequestBody NurseAuditNotesReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			NurseAuditNotesReportRes res = new NurseAuditNotesReportRes();
			String excelStream = "";
			try {

				res = reportBO.nurseAuditNotesReport(req);

				excelStream = ExportExcelUtil.generateNurseAuditNotesExcel(req, res.getReportData());

				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (IllegalArgumentException e) {
				log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To export ecw sent report to excel")
		@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
		@PostMapping(value = "/app/ecwsentreportexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> ecWSentReportExcel(
				@ApiParam(name = "Export ecW Sent Report Excel", value = "Export ecW Sent Excel", required = true) 
				@RequestBody ecWSentReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			ecWSentReportRes res = new ecWSentReportRes();
			String excelStream = "";
			try {

				res = reportBO.ecWSentReport(req);

				excelStream = ExportExcelUtil.generateEcWSentReportExcel(req, res.getReportData());

				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (IllegalArgumentException e) {
				log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		@ApiOperation(value = "To export admin excel for encode dashboard")
		@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
		@PostMapping(value = "/app/coderdashboardexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> getCoderDashboardExcel(
				@ApiParam(name = "Export Admin Encode Dashboard Excel", value = "Export Admin Encode Dashboard Excel", required = true) @RequestBody CoderDashboardReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			CoderDashboardRes res = new CoderDashboardRes();
			CollapsibleSectionRes coderDashboardRes = new CollapsibleSectionRes();
			String excelStream = "";
			boolean isFilter = false;
			try {
				if (req.getFilters() != null && !req.getFilters().isEmpty()) {
					isFilter = true;
				}
				log.debug("coderDashboardRes: {}", coderDashboardRes);
				/*res = coderDashboardBO.getCoderDatas(isFilter,
						req,req.getIndex(),
						req.getTaskType(), req.getUsername(),
						req.getMasterToken(),req);*/
				res = coderDashboardBO.getAllCoderDataForExcel(isFilter, req, 0, req.getTaskType(),
						req.getUsername());

				log.debug("coderDashboardRes: {}", res);
				excelStream = ExportExcelUtil.generateCoderDashboardExcel(req, res.getCoderData());

				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (IllegalArgumentException e) {
				log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To export excel for Encounter Needing Guidance")
		@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
		@PostMapping(value = "/app/coderproductivityreportexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> getCoderProductivityReportExcel(
				@ApiParam(name = "CoderProductivityReportReq", value = "CoderProductivityReportReq data", required = true)
				@RequestBody CoderProductivityReportReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			CoderProductivityReportRes res = null;
			String excelStream = "";

			try {
				boolean isExcel = true;
				res = reportBO.coderProductivityReport(req);
				//log.debug("viewReportsRes: " + res);
				// Handle the case where no data is found for the given coderId
		        if (res == null || res.getReportData() == null || res.getReportData().isEmpty()) {
		            log.warn("No data found for coderId: {}", req.getCoderId());

		            // Generate an Excel file with blank fields & "No data found" message
		            excelStream = ExportExcelUtil.generateEmptyCoderProductivityReportExcel(req.getCoderId());

		            response = CommonUtils.getResponseObject(
		                    ControllerConstants.EXPORT_EXCEL, "200", "0",
		                    "No data found");
		        } else {
		            // Generate Excel with actual data
		            excelStream = ExportExcelUtil.generateCoderProductivityReportExcel(res.getReportData(), req.getCoderId());

		            response = CommonUtils.getResponseObject(
		                    ControllerConstants.EXPORT_EXCEL, "200", "0",
		                    ControllerConstants.SUCCESS_DESC);
		        }

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				e.printStackTrace();
				response = CommonUtils.getResponseObject(
						ControllerConstants.EXPORT_EXCEL, "501", "501",
						e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		@ApiOperation(value = "To export recon report to excel")
		@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
		@PostMapping(value = "/app/coderproductivityreportdrilldownexcel", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> getcoderproductivityreportdrilldownexcel(
				@ApiParam(name = "CoderProductivityReportReq", value = "CoderProductivityReportReq data", required = true)
				@RequestBody ReportFilterReq req) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> response;
			CoderProductivityReportDrilldownRes res = new CoderProductivityReportDrilldownRes();
			String excelStream = "";
			boolean isFilter = false;
			try {

				res= reportBO.getCoderProductivityReportDrilldown(req);

				excelStream = ExportExcelUtil.generateCoderProductivityReportDrillDownExcel(res.getDataList(), req.getCoderId());

				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "200", "0",
						ControllerConstants.SUCCESS_DESC);

				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);

				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} catch (IllegalArgumentException e) {
				log.error("INVALID DASHBOARD NAME: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "400", "400", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				log.error("EXCEPTION OCCURRED: {}", e.getMessage());
				response = CommonUtils.getResponseObject(ControllerConstants.EXPORT_EXCEL, "501", "501", e.getMessage());
				Map<String, Object> excelDetails = new LinkedHashMap<>();
				excelDetails.put("messageheader", response);
				excelDetails.put("excelstream", excelStream);
				Map<String, Object> json = new HashMap<>();
				json.put("exceldownload", excelDetails);

				HttpHeaders headers = new HttpHeaders();
				headers.add("timestamp", formattedDate);
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
}
