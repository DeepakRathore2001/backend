package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.LIGHT_SPEED_DATA_IMPORT;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.ReloadPatientInsuranceReq;
import com.healogics.encode.service.LightSpeedImportBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class LightSpeedImportController {
	
	private final Logger log = LoggerFactory
			.getLogger(IHealNotificationController.class);
	
	private final Environment env;
	private final LightSpeedImportBO lightSpeedImportBO;

	@Autowired
	public LightSpeedImportController(LightSpeedImportBO lightSpeedImportBO, Environment env) {
		this.lightSpeedImportBO = lightSpeedImportBO;
		this.env = env;
	} 

	@ApiOperation(value = "Light Speed Data Import")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/user/lightspeeddataimport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> lightSpeedDataImport(
			@ApiParam(name = "Light Speed Data Import Request", value = "Light Speed Data Import", required = true) @RequestBody ReloadPatientInsuranceReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response;
		try {
			res = lightSpeedImportBO.lightSpeedDataImport(req);

			if (res != null && res.getResponseCode() != null) {
				if (res.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(LIGHT_SPEED_DATA_IMPORT, formattedDate);
					response = CommonUtils.getResponseObject(LIGHT_SPEED_DATA_IMPORT, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.LIGHT_SPEED_DATA_IMPORT);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(LIGHT_SPEED_DATA_IMPORT, formattedDate);
					response = CommonUtils.getResponseObject(LIGHT_SPEED_DATA_IMPORT, "500", res.getResponseCode(),
							res.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.LIGHT_SPEED_DATA_IMPORT);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(LIGHT_SPEED_DATA_IMPORT, formattedDate);
				response = CommonUtils.getResponseObject(LIGHT_SPEED_DATA_IMPORT, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LIGHT_SPEED_DATA_IMPORT);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(LIGHT_SPEED_DATA_IMPORT, formattedDate);
			response = CommonUtils.getResponseObject(LIGHT_SPEED_DATA_IMPORT, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.LIGHT_SPEED_DATA_IMPORT);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


}
