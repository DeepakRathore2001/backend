package com.healogics.encode.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.service.LoginBO;
import com.healogics.encode.service.UserPreferenceBO;
import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.IHealUser;
import com.healogics.encode.dto.IHealUserdetails;
import com.healogics.encode.dto.LoginReq;
import com.healogics.encode.dto.LoginRes;
import com.healogics.encode.dto.OAuthReq;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.dto.UserPreferenceReq;
import com.healogics.encode.dto.UserPreferenceRes;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import static com.healogics.encode.constants.ControllerConstants.LOGIN;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.UPDATE_COLOR_CODES;

@RestController
public class LoginController {
	private final Logger log = LoggerFactory.getLogger(LoginController.class);

	private final LoginBO loginBO;
	private final UserPreferenceBO userPreferenceBO;

	@Autowired
	public LoginController(LoginBO loginBO, UserPreferenceBO userPreferenceBO) {
		this.loginBO = loginBO;
		this.userPreferenceBO = userPreferenceBO;
	}

	@ApiOperation(value = "Authenticates user ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/user/login", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getLoginUserDetails(
			@ApiParam(name = "UserLogin", value = "user credentials", required = true)
			@RequestBody LoginReq loginReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		LoginRes loginRes = null;
		Map<String, Object> response;

		try {
			loginRes = loginBO.login(loginReq);

			if (loginRes == null || loginRes.getResponseCode() == null) {
				messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

			if (loginRes.getResponseCode().equalsIgnoreCase("0")) {
				
				if (loginRes.getIhealUserdetails().getUser() != null
						&& loginRes.getIhealUserdetails().getUser().isPasswordChange()) {
					// Password expired
					messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "402", loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					LoginRes loginResDetails = new LoginRes();
					loginResDetails.setResponseCode("11");
					loginResDetails.setResponseMessage("Password expired");
					json.put(ControllerConstants.LOGIN, loginResDetails);

					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.PAYMENT_REQUIRED);

				} else if (loginRes.getIhealUserdetails().getUser() != null
						&& loginRes.getIhealUserdetails().getUser().isTermsAndConditions()) {
					// Accept Terms required
					messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "409", loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					LoginRes loginResDetails = new LoginRes();
					loginResDetails.setResponseCode("16");
					loginResDetails.setResponseMessage("Accept Terms required");
					loginResDetails.setAccessToken(loginRes.getAccessToken());
					loginResDetails.setRefreshToken(loginRes.getRefreshToken());
					json.put(ControllerConstants.LOGIN, loginResDetails);

					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

				} else {
					// Success
					messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.LOGIN, loginRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				}

			} else if (loginRes.getResponseCode().equalsIgnoreCase("1")) {
				// Login failed
				messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "410", loginRes.getResponseCode(),
						loginRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.GONE);

			} else if (loginRes.getResponseCode().equalsIgnoreCase("2")) {
				// Invalid PrivateKey
				messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "405", loginRes.getResponseCode(),
						loginRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.METHOD_NOT_ALLOWED);

			} else if (loginRes.getResponseCode().equalsIgnoreCase("10")) {
				// Account locked out
				messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "406", loginRes.getResponseCode(),
						loginRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.NOT_ACCEPTABLE);

			} else if (loginRes.getResponseCode().equalsIgnoreCase("15")) {
				// Unknown error
				messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "408", loginRes.getResponseCode(),
						loginRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.REQUEST_TIMEOUT);

			} else {
				// All other error codes
				messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "500", loginRes.getResponseCode(),
						loginRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (BadCredentialsException bexcp) {
			log.error(ControllerConstants.INVALID_CREDENTIALS, bexcp);
			messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
			response = CommonUtils.getResponseObject(LOGIN, "401", "401", bexcp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.LOGIN, loginRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
			response = CommonUtils.getResponseObject(LOGIN, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.LOGIN, loginRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Update Color Codes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/updatecolorcodes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateColorCodes(
			@RequestBody UserPreferenceReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		UserPreferenceRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (req.getUserId() == null) {

				messageHeader = CommonUtils.getMessageHeader(UPDATE_COLOR_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_COLOR_CODES,
						"401", "404", "INVALID PARAMETERS");

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, UPDATE_COLOR_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(headers, HttpStatus.BAD_REQUEST);

			}
			res = userPreferenceBO.updateColorCodes(req);
			messageHeader = CommonUtils.getMessageHeader(UPDATE_COLOR_CODES,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_COLOR_CODES,
					ControllerConstants.SUCCESS_CODE, "0",
					ControllerConstants.SUCCESS_DESC);
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, UPDATE_COLOR_CODES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			log.info("Update Color Codes:  ", res);
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured: ", e);
			messageHeader = CommonUtils.getMessageHeader(UPDATE_COLOR_CODES,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_COLOR_CODES, "500",
					"505", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, UPDATE_COLOR_CODES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	@ApiOperation(value = "Authenticates user ")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/user/userinfo", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> loginbyOAuth(
			@ApiParam(name = "UserLogin", value = "user credentials", required = true)
			@RequestBody OAuthReq oauthReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		LoginRes loginRes = null;
		Map<String, Object> response;
		try {

			loginRes = loginBO.loginByOAuth(oauthReq);
			if (loginRes != null && loginRes.getResponseCode() != null) {
				if (loginRes.getResponseCode().equalsIgnoreCase("0")) {

					if (loginRes.getIhealUserdetails().getUser() != null
							&& loginRes.getIhealUserdetails().getUser()
									.isPasswordChange()) {
						// Password expired
						messageHeader = CommonUtils.getMessageHeader(LOGIN,
								formattedDate);
						response = CommonUtils.getResponseObject(LOGIN, "402",
								loginRes.getResponseCode(),
								loginRes.getResponseMessage());

						Map<String, Object> json = new HashMap<>();
						LoginRes loginResDetails = new LoginRes();
						loginResDetails.setResponseCode("11");
						loginResDetails.setResponseMessage("Password expired");
						json.put(ControllerConstants.LOGIN, loginResDetails);

						HttpHeaders headers = new HttpHeaders();
						headers.add(ControllerConstants.TIMESTAMP,
								formattedDate);
						headers.add(ControllerConstants.ACTION,
								ControllerConstants.LOGIN);
						headers.add(ControllerConstants.MSG_HEADER,
								String.valueOf(messageHeader));
						headers.add(ControllerConstants.RESPONSE,
								String.valueOf(response));
						return new ResponseEntity<>(json, headers,
								HttpStatus.PAYMENT_REQUIRED);

					} else if (loginRes.getIhealUserdetails().getUser() != null
							&& loginRes.getIhealUserdetails().getUser()
									.isTermsAndConditions()) {
						// Accept Terms required
						messageHeader = CommonUtils.getMessageHeader(LOGIN,
								formattedDate);
						response = CommonUtils.getResponseObject(LOGIN, "409",
								loginRes.getResponseCode(),
								loginRes.getResponseMessage());

						Map<String, Object> json = new HashMap<>();
						LoginRes loginResDetails = new LoginRes();
						loginResDetails.setResponseCode("16");
						loginResDetails
								.setResponseMessage("Accept Terms required");
						loginResDetails
								.setAccessToken(loginRes.getAccessToken());
						loginResDetails
								.setRefreshToken(loginRes.getRefreshToken());
						json.put(ControllerConstants.LOGIN, loginResDetails);

						HttpHeaders headers = new HttpHeaders();
						headers.add(ControllerConstants.TIMESTAMP,
								formattedDate);
						headers.add(ControllerConstants.ACTION,
								ControllerConstants.LOGIN);
						headers.add(ControllerConstants.MSG_HEADER,
								String.valueOf(messageHeader));
						headers.add(ControllerConstants.RESPONSE,
								String.valueOf(response));
						return new ResponseEntity<>(json, headers,
								HttpStatus.CONFLICT);

					} else {
						// Success
						messageHeader = CommonUtils.getMessageHeader(LOGIN,
								formattedDate);
						response = CommonUtils.getResponseObject(LOGIN, "200",
								"0", SUCCESS_DESC);

						Map<String, Object> json = new HashMap<>();
						json.put(ControllerConstants.LOGIN, loginRes);
						HttpHeaders headers = new HttpHeaders();
						headers.add(ControllerConstants.TIMESTAMP,
								formattedDate);
						headers.add(ControllerConstants.ACTION,
								ControllerConstants.LOGIN);
						headers.add(ControllerConstants.MSG_HEADER,
								String.valueOf(messageHeader));
						headers.add(ControllerConstants.RESPONSE,
								String.valueOf(response));
						return new ResponseEntity<>(json, headers,
								HttpStatus.OK);
					}

				} else if (loginRes.getResponseCode().equalsIgnoreCase("1")) {
					// Login failed
					messageHeader = CommonUtils.getMessageHeader(LOGIN,
							formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "410",
							loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.LOGIN, loginRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.GONE);

				} else if (loginRes.getResponseCode().equalsIgnoreCase("2")) {
					// Invalid PrivateKey
					messageHeader = CommonUtils.getMessageHeader(LOGIN,
							formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "405",
							loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.LOGIN, loginRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.METHOD_NOT_ALLOWED);

				} else if (loginRes.getResponseCode().equalsIgnoreCase("10")) {
					// Account locked out
					messageHeader = CommonUtils.getMessageHeader(LOGIN,
							formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "406",
							loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.LOGIN, loginRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.NOT_ACCEPTABLE);

				} else if (loginRes.getResponseCode().equalsIgnoreCase("15")) {
					// Unknown error
					messageHeader = CommonUtils.getMessageHeader(LOGIN,
							formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "408",
							loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.LOGIN, loginRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.REQUEST_TIMEOUT);

				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(LOGIN,
							formattedDate);
					response = CommonUtils.getResponseObject(LOGIN, "500",
							loginRes.getResponseCode(),
							loginRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.LOGIN, loginRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.LOGIN);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(LOGIN,
						formattedDate);
				response = CommonUtils.getResponseObject(LOGIN, "500", "556",
						"Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.LOGIN, loginRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.LOGIN);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (BadCredentialsException bexcp) {
			log.error(ControllerConstants.INVALID_CREDENTIALS, bexcp);
			messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
			response = CommonUtils.getResponseObject(LOGIN, "401", "401",
					bexcp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.LOGIN, loginRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(LOGIN, formattedDate);
			response = CommonUtils.getResponseObject(LOGIN, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.LOGIN, loginRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.LOGIN);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Close functionality in iheal2")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/user/logout", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> closeIheal2(
			@ApiParam(name = "closeIheal2", value = "closeIheal2 Details", required = true) @RequestBody IHealUser user) {
		Map<String, Object> json = new HashMap<>();
		IHealUserdetails ihealUserdetails = loginBO.logout(user);
		json.put(ControllerConstants.API_RESPONSE, ihealUserdetails);
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<>(json, headers, HttpStatus.OK);
	}
	
	
}
