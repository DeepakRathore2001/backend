package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.PATIENT_LOAD;
import static com.healogics.encode.constants.ControllerConstants.PLACE_OF_SERVICE_LIST_GET;
import static com.healogics.encode.constants.ControllerConstants.VISIT_LOAD;
import static com.healogics.encode.constants.ControllerConstants.RELOAD_PATIENT_INSURANCE;
import static com.healogics.encode.constants.ControllerConstants.RELOAD_PATIENT;
import static com.healogics.encode.constants.ControllerConstants.RELOAD_DEFICIENCY;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.constants.IntegrationConstants;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.IHealGetVisitsReq;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.IHealSuperBillLoadReq;
import com.healogics.encode.dto.IHealVisitLoadRes;
import com.healogics.encode.dto.PatientLoadRes;
import com.healogics.encode.dto.PlaceOfServiceObj;
import com.healogics.encode.dto.PlaceOfServiceRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ProviderListRes;
import com.healogics.encode.dto.ReloadPatientInsuranceReq;
import com.healogics.encode.dto.ReloadRequest;
import com.healogics.encode.dto.SuperBillLoadRes;
import com.healogics.encode.dto.IHealNotificationReq;
import com.healogics.encode.service.IHealNotificationBO;
import com.healogics.encode.util.CommonUtils;
import com.healogics.encode.util.XMLServiceResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class IHealNotificationController {

	private final Logger log = LoggerFactory
			.getLogger(IHealNotificationController.class);

	private final Environment env;
	private final IHealNotificationBO notificationBO;

	@Autowired
	public IHealNotificationController(IHealNotificationBO notificationBO, Environment env) {
		this.notificationBO = notificationBO;
		this.env = env;
	} 

	@RequestMapping(value = "/notificationtest", method = RequestMethod.GET)
	@ApiOperation(value = "Notification web service test", nickname = "notification")
	public String test() {
		log.info("NOTIFICATION SERVICES WORKING:: ");
		return "NOTIFICATION SERVICES WORKING";
	}

	@ApiOperation(value = "Notification details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorised"),
			@ApiResponse(code = 501, message = "Invalid parameters"),
			@ApiResponse(code = 404, message = "Service not found"),
			@ApiResponse(code = 500, message = "Server error"),
			@ApiResponse(code = 403, message = "Authorised token expire"),})
	@RequestMapping(value = "/user/GetDocumentNotification", method = RequestMethod.POST,
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<XMLServiceResponse> consumeSuperbillNotificationXML(
			@RequestBody IHealNotificationReq iHealNotificationReq) {
		log.debug("Document Notification Request Received: "
				+ iHealNotificationReq);

		XMLServiceResponse xmlServiceResponse = new XMLServiceResponse();
		xmlServiceResponse.setRequestId(UUID.randomUUID().toString());

		if (!iHealNotificationReq.getIntegrationKey()
				.equalsIgnoreCase(env.getProperty(BOConstants.NETHEALTH_INTEGRATION_KEY))) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg(
					"Invalid Request - integrationKey is not valid");
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.BAD_REQUEST);
		}
		
		String validStatus = notificationBO
				.validateNotificationReq(iHealNotificationReq);

		if (!validStatus.equalsIgnoreCase("valid")) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg(validStatus);
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.BAD_REQUEST);
		}
		
		Instant serviceStart = Instant.now();
		if (notificationBO.consumeNotificationData(iHealNotificationReq,
				serviceStart)) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_SUCCESS);
			xmlServiceResponse.setErrorMsg("Request Completed Successfully");
			return new ResponseEntity<>(xmlServiceResponse, HttpStatus.OK);
		} else {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg("Internal Server Error"); // Set
																		// proper
																		// error
																		// message
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Patient Load")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/patientload", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getPatientLoad(
			@ApiParam(name = "Patient Load Request", value = "Patient Load details", required = true) @RequestBody IHealPatientLoadReq patientSearchReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		PatientLoadRes patientLoadRes = null;
		Map<String, Object> response;
		try {
			patientLoadRes = notificationBO.getPatientFromIHeal(patientSearchReq);

			if (patientLoadRes != null
					&& patientLoadRes.getResponseCode() != null) {
				if (patientLoadRes.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
							formattedDate);
					response = CommonUtils.getResponseObject(PATIENT_LOAD,
							"200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, patientLoadRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.PATIENT_LOAD);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
							formattedDate);
					response = CommonUtils.getResponseObject(PATIENT_LOAD,
							"500", patientLoadRes.getResponseCode(),
							patientLoadRes.getResponseDesc());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, patientLoadRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.PATIENT_LOAD);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
						formattedDate);
				response = CommonUtils.getResponseObject(PATIENT_LOAD, "500",
						"556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, patientLoadRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.PATIENT_LOAD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
					formattedDate);
			response = CommonUtils.getResponseObject(PATIENT_LOAD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, patientLoadRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.PATIENT_LOAD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Get Visit from Iheal")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getvisits", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getVisitsFromIHeal(
			@ApiParam(name = "Get Visits Request", value = "Get Visits details", required = true) @RequestBody IHealGetVisitsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		IHealVisitLoadRes res = null;
		Map<String, Object> response;
		try {
			res = notificationBO.getVisits(req);

			if (res != null && res.getErrorCode() != null) {
				if (res.getErrorCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(VISIT_LOAD,
							formattedDate);
					response = CommonUtils.getResponseObject(VISIT_LOAD, "200",
							"0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.VISIT_LOAD);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(VISIT_LOAD,
							formattedDate);
					response = CommonUtils.getResponseObject(VISIT_LOAD, "500",
							res.getErrorCode(), res.getErrorMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.VISIT_LOAD);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(VISIT_LOAD,
						formattedDate);
				response = CommonUtils.getResponseObject(VISIT_LOAD, "500",
						"556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VISIT_LOAD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(VISIT_LOAD,
					formattedDate);
			response = CommonUtils.getResponseObject(VISIT_LOAD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.VISIT_LOAD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "SuperBill Load")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/superbillLoad", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSuperbillLoad(
			@ApiParam(name = "SuperBill Load Request", value = "SuperBill Load details", required = true) @RequestBody IHealSuperBillLoadReq superBillLoadReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SuperBillLoadRes superBillLoadRes = null;
		Map<String, Object> response;
		try {
			superBillLoadRes = notificationBO.getSuperBillLoad(superBillLoadReq);

			if (superBillLoadRes != null
					&& superBillLoadRes.getResponseCode() != null) {
				if (superBillLoadRes.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
							formattedDate);
					response = CommonUtils.getResponseObject(PATIENT_LOAD,
							"200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, superBillLoadRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.PATIENT_LOAD);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
							formattedDate);
					response = CommonUtils.getResponseObject(PATIENT_LOAD,
							"500", superBillLoadRes.getResponseCode(),
							superBillLoadRes.getResponseDesc());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, superBillLoadRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.PATIENT_LOAD);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
						formattedDate);
				response = CommonUtils.getResponseObject(PATIENT_LOAD, "500",
						"556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, superBillLoadRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.PATIENT_LOAD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PATIENT_LOAD,
					formattedDate);
			response = CommonUtils.getResponseObject(PATIENT_LOAD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, superBillLoadRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.PATIENT_LOAD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Place of Service List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getplaceofservice", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> searchPatient(
			@ApiParam(name = "Place Of Service List Request", value = "Place of Service List ", required = true) @RequestBody ProviderListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		PlaceOfServiceRes res = null;
		Map<String, Object> response;
		try {
			res = notificationBO.getPlaceOfServices(req);

			if (res != null && res.getResponseCode() != null) {
				if (res.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PLACE_OF_SERVICE_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PLACE_OF_SERVICE_LIST_GET, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PLACE_OF_SERVICE_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PLACE_OF_SERVICE_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PLACE_OF_SERVICE_LIST_GET, "500", res.getResponseCode(),
							res.getResponseDesc());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PLACE_OF_SERVICE_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PLACE_OF_SERVICE_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(PLACE_OF_SERVICE_LIST_GET, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.PLACE_OF_SERVICE_LIST_GET);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PLACE_OF_SERVICE_LIST_GET, formattedDate);
			response = CommonUtils.getResponseObject(PLACE_OF_SERVICE_LIST_GET, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.PLACE_OF_SERVICE_LIST_GET);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Reload SuperBill")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorised"),
			@ApiResponse(code = 501, message = "Invalid parameters"),
			@ApiResponse(code = 404, message = "Service not found"),
			@ApiResponse(code = 500, message = "Server error"),
			@ApiResponse(code = 403, message = "Authorised token expire"),})
	@RequestMapping(value = "/user/reloadsuperbill", method = RequestMethod.POST,
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<XMLServiceResponse> reloadSuperBill(
			@RequestBody ReloadRequest reloadRequest) {
		
		log.debug("SuperBill Reload Request Received: "
				+ reloadRequest);

		XMLServiceResponse xmlServiceResponse = new XMLServiceResponse();
		xmlServiceResponse.setRequestId(UUID.randomUUID().toString());
		
		try {
			boolean status = notificationBO.reloadSuperBillNotification(reloadRequest);
			
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_SUCCESS);
			xmlServiceResponse.setErrorMsg("SuperBill Reload Request Completed Successfully");
			return new ResponseEntity<>(xmlServiceResponse, HttpStatus.OK);
			
		} catch (Exception e) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg("Internal Server Error");
			
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Reload Document")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorised"),
			@ApiResponse(code = 501, message = "Invalid parameters"),
			@ApiResponse(code = 404, message = "Service not found"),
			@ApiResponse(code = 500, message = "Server error"),
			@ApiResponse(code = 403, message = "Authorised token expire"),})
	@RequestMapping(value = "/user/reloaddocument", method = RequestMethod.POST,
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<XMLServiceResponse> reloadDocument(
			@RequestBody ReloadRequest reloadRequest) {
		
		log.debug("Document Reload Request Received: "
				+ reloadRequest);

		XMLServiceResponse xmlServiceResponse = new XMLServiceResponse();
		xmlServiceResponse.setRequestId(UUID.randomUUID().toString());
		
		try {
			boolean status = notificationBO.reloadDocumentNotification(reloadRequest);
			
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_SUCCESS);
			xmlServiceResponse.setErrorMsg("Document Reload Request Completed Successfully");
			return new ResponseEntity<>(xmlServiceResponse, HttpStatus.OK);
			
		} catch (Exception e) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg("Internal Server Error");
			
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Reload Coder Chart")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorised"),
			@ApiResponse(code = 501, message = "Invalid parameters"),
			@ApiResponse(code = 404, message = "Service not found"),
			@ApiResponse(code = 500, message = "Server error"),
			@ApiResponse(code = 403, message = "Authorised token expire"),})
	@RequestMapping(value = "/user/reloadcoderchart", method = RequestMethod.POST,
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<XMLServiceResponse> reloadCoderChart(
			@RequestBody ReloadRequest reloadRequest) {
		
		log.debug("Coder Chart Reload Request Received: "
				+ reloadRequest);

		XMLServiceResponse xmlServiceResponse = new XMLServiceResponse();
		xmlServiceResponse.setRequestId(UUID.randomUUID().toString());
		
		try {
			boolean status = notificationBO.reloadCoder(reloadRequest);
			
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_SUCCESS);
			xmlServiceResponse.setErrorMsg("Coder Chart Reload Request Completed Successfully");
			return new ResponseEntity<>(xmlServiceResponse, HttpStatus.OK);
			
		} catch (Exception e) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg("Internal Server Error");
			
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Reload Coder Chart")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 401, message = "Unauthorised"),
			@ApiResponse(code = 501, message = "Invalid parameters"),
			@ApiResponse(code = 404, message = "Service not found"),
			@ApiResponse(code = 500, message = "Server error"),
			@ApiResponse(code = 403, message = "Authorised token expire"),})
	@RequestMapping(value = "/user/reloadcmcchart", method = RequestMethod.POST,
			consumes = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<XMLServiceResponse> reloadCmcChart(
			@RequestBody ReloadRequest reloadRequest) {
		
		log.debug("CMC Chart Reload Request Received: "
				+ reloadRequest);

		XMLServiceResponse xmlServiceResponse = new XMLServiceResponse();
		xmlServiceResponse.setRequestId(UUID.randomUUID().toString());
		
		try {
			boolean status = notificationBO.reloadCmc(reloadRequest);
			
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_SUCCESS);
			xmlServiceResponse.setErrorMsg("CMC Chart Reload Request Completed Successfully");
			return new ResponseEntity<>(xmlServiceResponse, HttpStatus.OK);
			
		} catch (Exception e) {
			xmlServiceResponse.setStatus(IntegrationConstants.STATUS_ERROR);
			xmlServiceResponse.setErrorMsg("Internal Server Error");
			
			return new ResponseEntity<>(xmlServiceResponse,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Reload Patient Insurance")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/user/reloadPatientInsurance", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> reloadPatientInsurance(
			@ApiParam(name = "Reload Patient Insurance Request", value = "Reload Patient Insurance", required = true) @RequestBody ReloadPatientInsuranceReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response;
		try {
			res = notificationBO.reloadPatientInsurance(req);

			if (res != null && res.getResponseCode() != null) {
				if (res.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT_INSURANCE, formattedDate);
					response = CommonUtils.getResponseObject(RELOAD_PATIENT_INSURANCE, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT_INSURANCE);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT_INSURANCE, formattedDate);
					response = CommonUtils.getResponseObject(RELOAD_PATIENT_INSURANCE, "500", res.getResponseCode(),
							res.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT_INSURANCE);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT_INSURANCE, formattedDate);
				response = CommonUtils.getResponseObject(RELOAD_PATIENT_INSURANCE, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT_INSURANCE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT_INSURANCE, formattedDate);
			response = CommonUtils.getResponseObject(RELOAD_PATIENT_INSURANCE, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT_INSURANCE);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Reload Patient and Patient Insurance")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/user/reloadPatient", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> reloadPatient(
			@ApiParam(name = "Reload Patient and Patient Insurance Request", value = "Reload Patient and Patient Insurance", required = true) @RequestBody ReloadPatientInsuranceReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response;
		try {
			res = notificationBO.reloadPatient(req);

			if (res != null && res.getResponseCode() != null) {
				if (res.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT, formattedDate);
					response = CommonUtils.getResponseObject(RELOAD_PATIENT, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT, formattedDate);
					response = CommonUtils.getResponseObject(RELOAD_PATIENT, "500", res.getResponseCode(),
							res.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT, formattedDate);
				response = CommonUtils.getResponseObject(RELOAD_PATIENT, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT, formattedDate);
			response = CommonUtils.getResponseObject(RELOAD_PATIENT, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Reload Deficiency")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/user/reloadDeficiency", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> reloadDeficiency(
			@ApiParam(name = "Reload Deficiency Request", value = "Reload Deficiency", required = true) @RequestBody ReloadPatientInsuranceReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response;
		try {
			res = notificationBO.reloadDeficiency(req);

			if (res != null && res.getResponseCode() != null) {
				if (res.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(RELOAD_DEFICIENCY, formattedDate);
					response = CommonUtils.getResponseObject(RELOAD_DEFICIENCY, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_DEFICIENCY);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(RELOAD_DEFICIENCY, formattedDate);
					response = CommonUtils.getResponseObject(RELOAD_DEFICIENCY, "500", res.getResponseCode(),
							res.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_DEFICIENCY);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(RELOAD_DEFICIENCY, formattedDate);
				response = CommonUtils.getResponseObject(RELOAD_DEFICIENCY, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_DEFICIENCY);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(RELOAD_PATIENT, formattedDate);
			response = CommonUtils.getResponseObject(RELOAD_PATIENT, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.RELOAD_PATIENT);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
