package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.GET_NOTIFICATION;
import static com.healogics.encode.constants.ControllerConstants.PARSE_CENTER_ALIGNMENT_EXTRACT;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.SNSNotificationDetails;
import com.healogics.encode.dto.SNSNotificationResponse;
import com.healogics.encode.service.SNSNotificationBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class SNSNotificationController {
	private final Logger log = LoggerFactory
			.getLogger(SNSNotificationController.class);

	@Value("${parse.facility.csv.api}")
	private String parseFacilityCSVApi;
	
	private final SNSNotificationBO snsNotificationBO;
	private final RestTemplate restTemplate;

	@Autowired
	public SNSNotificationController(SNSNotificationBO snsNotificationBO, RestTemplate restTemplate) {
		this.snsNotificationBO = snsNotificationBO;
		this.restTemplate = restTemplate;
	}
	
	@ApiOperation(value = "Get SNS Notification")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/user/gets3notification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveFilter(			
			@ApiParam(name = "SNSNotificationDetails",
				value = "SNSNotificationDetails data", required = true)
			@RequestBody SNSNotificationDetails req) {
		log.info("req : " +req);
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response = null;
		SNSNotificationResponse res = null;
		try {
			res = snsNotificationBO.processSNSNotifcation(req);

			messageHeader = CommonUtils
					.getMessageHeader(GET_NOTIFICATION, formattedDate);
			response = CommonUtils.getResponseObject(GET_NOTIFICATION,
					"200", "0", SUCCESS_DESC);
			
			Map<String, Object> json = new HashMap<String, Object>();
			json.put(ControllerConstants.API_RESPONSE, res);

			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_NOTIFICATION);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE,
					String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_NOTIFICATION,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_NOTIFICATION,
					"556", "556", excp.getMessage());
			
			Map<String, Object> json = new HashMap<String, Object>();
			json.put(ControllerConstants.API_RESPONSE, res);

			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_NOTIFICATION);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = PARSE_CENTER_ALIGNMENT_EXTRACT)
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@GetMapping(value = "/user/parsefacilitycsv", headers = "Accept=application/json")
	public SNSNotificationResponse facilityExtract() {
	
		SNSNotificationResponse res = null;
		try {
			res = snsNotificationBO.processCenterAlignmentCSV();
			return res;
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			return res;
		}
	}
	
	@Scheduled(cron = "${centeralignment.run.interval}")
	public void callFacilityExtractAPI() {
		try {
			log.debug("Starting Center Alignment Scheduler: "+Instant.now());
			SNSNotificationResponse response =  restTemplate.getForObject(parseFacilityCSVApi, SNSNotificationResponse.class);
			log.debug("Extract Facility CSV Completed: "+ response);
		} catch (Exception e) {
			log.error(String.format("Exception occured during Facility Extract Scheduled Job: %s", e));
		}
	}
	
}
