package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SAVE_FILTER;
import static com.healogics.encode.constants.ControllerConstants.DELETE_FILTER;
import static com.healogics.encode.constants.ControllerConstants.UPDATE_FILTER;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.VIEW_FILTER;
import static com.healogics.encode.constants.ControllerConstants.AUDIT_FILTER;
import static com.healogics.encode.constants.ControllerConstants.EDIT_FILTER;
import static com.healogics.encode.constants.ControllerConstants.PROVIDER_LIST_GET;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_SEARCH_CODING_TEAM;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_SEARCH_FACILITIES;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_SEARCH_CODERS;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_DRILLDOWN;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.AuditFilterDetails;
import com.healogics.encode.dto.AuditorCollapsibleSectionReq;
import com.healogics.encode.dto.AuditorDrillDownReq;
import com.healogics.encode.dto.AuditorDrillDownRes;
import com.healogics.encode.dto.CodingTeamRes;
import com.healogics.encode.dto.DeleteFilterReq;
import com.healogics.encode.dto.CodersRes;
import com.healogics.encode.dto.EditFilterNameRes;
import com.healogics.encode.dto.FilterLogicReq;
import com.healogics.encode.dto.FilterLogicRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ProviderListRes;
import com.healogics.encode.dto.ProviderObj;
import com.healogics.encode.dto.SaveAuditFilterReq;
import com.healogics.encode.dto.SaveAuditorFilterRes;
import com.healogics.encode.dto.UserFacilitiesReq;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.dto.ViewAuditorFilterRes;
import com.healogics.encode.service.AuditorFilterBO;
import com.healogics.encode.service.CMCDashboardBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AuditorFilterController {
	private final Logger log = LoggerFactory.getLogger(AuditorFilterController.class);

	private final AuditorFilterBO auditorFilterBO;

	private final CMCDashboardBO cmcDashboardBO;

	@Autowired
	public AuditorFilterController(AuditorFilterBO auditorFilterBO, CMCDashboardBO cmcDashboardBO) {
		this.auditorFilterBO = auditorFilterBO;
		this.cmcDashboardBO = cmcDashboardBO;
	}

	@ApiOperation(value = "Save Audiot Filter Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/savefilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveFilter(
			@ApiParam(name = "AuditFilterDetails", value = "AuditFilterDetails data", required = true)
			@RequestBody AuditFilterDetails filterReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveAuditorFilterRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorFilterBO.saveAuditorFilter(filterReq);

			if (res != null && res.getResponseCode() != null
					&& (res.getResponseCode().equalsIgnoreCase("0")
							|| res.getResponseCode().equalsIgnoreCase("2"))) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(SAVE_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Save Audiot Filter Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/saveauditfilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveAuditFilter(
			@ApiParam(name = "SaveAuditFilterReq", value = "SaveAuditFilterReq data", required = true)
			@RequestBody SaveAuditFilterReq filterReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveAuditorFilterRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorFilterBO.saveFilter(filterReq);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(SAVE_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "View Audiot Filters Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/viewfilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> viewFilters(@ApiParam(name = "AuditorCollapsibleSectionData", value = "AuditorCollapsibleSectionData data", required = true)
	@RequestBody AuditorCollapsibleSectionReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ViewAuditorFilterRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorFilterBO.getAuditorFilters(req.getFilterId());

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(VIEW_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(VIEW_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.VIEW_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(VIEW_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(VIEW_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.VIEW_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(VIEW_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(VIEW_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.VIEW_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get billing client values")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getbillingclients", headers = "Accept=application/json")
	public ResponseEntity<CodingTeamRes> getBillingClient() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		CodingTeamRes json = new CodingTeamRes();
		CodingTeamRes res = null;
		try {

			res = auditorFilterBO.getCodingTeam();
			if (res.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_CODING_TEAM, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_SEARCH_CODING_TEAM, "200", "0", SUCCESS_DESC);

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_CODING_TEAM);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_CODING_TEAM, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_SEARCH_CODING_TEAM, "500", "556",
						"Invalid response");

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_CODING_TEAM);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_CODING_TEAM, formattedDate);
			response = CommonUtils.getResponseObject(AUDITOR_SEARCH_CODING_TEAM, "556", "556", e.getMessage());

			json = res;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_CODING_TEAM);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get coder values")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getcoders", headers = "Accept=application/json")
	public ResponseEntity<CodersRes> getCoders() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		CodersRes json = new CodersRes();
		CodersRes res = null;

		try {

			res = auditorFilterBO.getCoders();
			if (res.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_CODERS, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_SEARCH_CODERS, "200", "0", SUCCESS_DESC);

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_CODERS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_CODERS, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_SEARCH_CODERS, "500", "556", "Invalid response");

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_CODERS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_CODERS, formattedDate);
			response = CommonUtils.getResponseObject(AUDITOR_SEARCH_CODERS, "556", "556", e.getMessage());

			json = res;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_CODERS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get facilities search values")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getfacilities", headers = "Accept=application/json")
	public ResponseEntity<UserFacilityRes> getFacilities(
			@ApiParam(name = "Facilities", value = "Facilities data", required = true) @RequestBody UserFacilitiesReq facilitiesReq) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		UserFacilityRes json = new UserFacilityRes();
		UserFacilityRes res = null;

		try {

			res = cmcDashboardBO.getUserFacilities(facilitiesReq.getUserId(), facilitiesReq.getMasterToken());

			if (res.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_FACILITIES, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_SEARCH_FACILITIES, "200", "0", SUCCESS_DESC);

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_FACILITIES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_FACILITIES, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_SEARCH_FACILITIES, "500", "556", "Invalid response");

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_FACILITIES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(AUDITOR_SEARCH_FACILITIES, formattedDate);
			response = CommonUtils.getResponseObject(AUDITOR_SEARCH_FACILITIES, "556", "556", e.getMessage());

			json = res;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, AUDITOR_SEARCH_FACILITIES);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Save Audiot Filter Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/updatefiltername", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateFilterName(
			@ApiParam(name = "AuditFilterDetails", value = "AuditFilterDetails data", required = true) @RequestBody SaveAuditFilterReq filterReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EditFilterNameRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorFilterBO.updateFilters(filterReq);

			if (res != null && res.getResponseCode() != null
					&& (res.getResponseCode().equalsIgnoreCase("0")
							|| res.getResponseCode().equalsIgnoreCase("2"))) {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.UPDATE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.UPDATE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.UPDATE_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Edit Audit Filter Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/editfilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> editFilter(
			@ApiParam(name = "AuditFilterDetails", value = "AuditFilterDetails data", required = true) @RequestBody AuditFilterDetails filterReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EditFilterNameRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorFilterBO.editFilter(filterReq);

			if (res != null && res.getResponseCode() != null
					&& (res.getResponseCode().equalsIgnoreCase("0")
							|| res.getResponseCode().equalsIgnoreCase("2"))) {
				messageHeader = CommonUtils.getMessageHeader(EDIT_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(EDIT_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.EDIT_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(EDIT_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(EDIT_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.EDIT_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(EDIT_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(EDIT_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.EDIT_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Filtered Auditor Drill Down Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/auditordrilldown", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditorDrillDownData(
			@ApiParam(name = "AuditorDrillDownReq", value = "AuditorDrillDownReq data", required = true) @RequestBody AuditorDrillDownReq auditorDrillDownReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AuditorDrillDownRes res = null;
		Map<String, Object> response = null;
		try {
			
			res = auditorFilterBO.getDrillDownData(auditorDrillDownReq);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_DRILLDOWN, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_DRILLDOWN, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_DRILLDOWN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_DRILLDOWN, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_DRILLDOWN, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_DRILLDOWN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(AUDITOR_DRILLDOWN, formattedDate);
			response = CommonUtils.getResponseObject(AUDITOR_DRILLDOWN, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_DRILLDOWN);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Apply Filter Logic")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/auditfilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> applyAuditFilter(
			@ApiParam(name = "FilterLogicReq", value = "FilterLogicReq data", required = true) @RequestBody FilterLogicReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		FilterLogicRes res = null;
		Map<String, Object> response = null;
		try {
			log.debug("Auditor : {} ", req.getAuditor());
			log.debug("Nurse : {} ", req.getNurse());
			log.debug("CodingTeam : {} ", req.getCodingTeam());
			res = auditorFilterBO.applyFilterLogic(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(AUDIT_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(AUDIT_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDIT_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDIT_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(AUDIT_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDIT_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(AUDIT_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(AUDIT_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.AUDIT_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Delete Audit Filter")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/deletefilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> deleteFilter(
			@ApiParam(name = "AuditFilterDetails", value = "AuditFilterDetails data", required = true) @RequestBody DeleteFilterReq filterReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EditFilterNameRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorFilterBO.deleteFilter(filterReq);

			if (res != null && res.getResponseCode() != null
					&& (res.getResponseCode().equalsIgnoreCase("0")
							|| res.getResponseCode().equalsIgnoreCase("2"))) {
				messageHeader = CommonUtils.getMessageHeader(DELETE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(DELETE_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.DELETE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DELETE_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(DELETE_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.DELETE_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DELETE_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(DELETE_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.DELETE_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Provider List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getprovidersbyfacilities", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> searchPatient(
			@ApiParam(name = "Provider List Request", value = "Provider List ", required = true) @RequestBody ProviderListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ProviderListRes providerRes = new ProviderListRes();
		List<ProviderObj> allProviders = new ArrayList<>();
		Map<String, Object> response;
		try {
			for (String facilityId : req.getFacilityIds()) {
				req.setFacilityIds(Collections.singletonList(facilityId)); 
				ProviderListRes currentProviderRes = cmcDashboardBO.getProvidersNamesList(req);
				if (currentProviderRes != null && "0".equals(currentProviderRes.getResponseCode())) {
					allProviders.addAll(currentProviderRes.getProviderList()); 
				}
			}
			allProviders.sort((p1, p2) -> {
	            // First compare by case-insensitive order
	            int result = String.CASE_INSENSITIVE_ORDER.compare(p1.getProviderName(), p2.getProviderName());
	            if (result == 0) {
	                // If they are the same ignoring case, compare by natural order (case-sensitive)
	                result = p1.getProviderName().compareTo(p2.getProviderName());
	            }
	            return result;
	        });
			if (!allProviders.isEmpty()) {
				providerRes.setProviderList(allProviders);
				providerRes.setResponseCode("0");
				providerRes.setResponseMessage(BOConstants.SUCCESS);
			}

			if (providerRes != null && providerRes.getResponseCode() != null) {
				if (providerRes.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, providerRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "500", providerRes.getResponseCode(),
							providerRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, providerRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, providerRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
			response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, providerRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
