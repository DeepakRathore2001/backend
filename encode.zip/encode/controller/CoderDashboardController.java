package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.COLLAPSIBLE_SECTION;
import static com.healogics.encode.constants.ControllerConstants.CODER_FILTER_DASHBOARD;
import static com.healogics.encode.constants.ControllerConstants.CODER_UNBILLABLE_REASONS;
import static com.healogics.encode.constants.ControllerConstants.SAVE_LOCK_STATUS;
import static com.healogics.encode.constants.ControllerConstants.SEARCH_CODER_DASHBOARD;
import static com.healogics.encode.constants.ControllerConstants.CODER_RECORD;
import static com.healogics.encode.constants.ControllerConstants.CODER_PLACE_OF_SERVICES;
import static com.healogics.encode.constants.ControllerConstants.PLACE_OF_SERVICES;
import static com.healogics.encode.constants.ControllerConstants.GET_SUPERBILL;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.CoderChartRes;
import com.healogics.encode.dto.CoderDashboardFilterRes;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.CoderDashboardRes;
import com.healogics.encode.dto.CollapsibleSectionRes;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptionsRes;
import com.healogics.encode.dto.LockRecordRes;
import com.healogics.encode.dto.PlaceOfServiceRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.SearchCoderDashboardRes;
import com.healogics.encode.dto.SuperBillReq;
import com.healogics.encode.dto.SuperBillRes;
import com.healogics.encode.entity.CollapsibleFilterRes;
import com.healogics.encode.service.CoderDashboardBO;
import com.healogics.encode.service.DocumentsBO;
import com.healogics.encode.service.IHealNotificationBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CoderDashboardController {

	private final Logger log = LoggerFactory.getLogger(CoderDashboardController.class);
	private final CoderDashboardBO coderDashboardBO;
	private final IHealNotificationBO notificationBO;

	@Autowired
	public CoderDashboardController(CoderDashboardBO coderDashboardBO, IHealNotificationBO notificationBO) {
		this.coderDashboardBO = coderDashboardBO;
		this.notificationBO = notificationBO;
		
	}
  
	/*@ApiOperation(value = "Fetch Filtered Coder Dashboard Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/coderDashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredData(
			@ApiParam(name = "CoderDashboardReq", value = "Coder DashboardReq data", required = true)
			@RequestBody CoderDashboardReq coderDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CoderDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (coderDashboardReq.getFilters() != null
					&& !coderDashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}

			res = coderDashboardBO.getCoderData(isFilter,
					coderDashboardReq,coderDashboardReq.getIndex(),
					coderDashboardReq.getTaskType(), coderDashboardReq.getUsername(),
					coderDashboardReq.getMasterToken(),coderDashboardReq);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(CODER_FILTER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_FILTER_DASHBOARD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_FILTER_DASHBOARD, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_FILTER_DASHBOARD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CODER_FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}*/

	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getcoderrecordbybbc", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCollapsibleSectionData(
			@ApiParam(name = "CollapsibleSectionData", value = "CollapsibleSection data", required = true)
			@RequestBody DashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CollapsibleSectionRes res = null;
		Map<String, Object> response = null;
		try {
			if(req.getFilters() ==null || req.getFilters().isEmpty()){
				res = coderDashboardBO.getCollapsibleSectionDetails(req.getBbc(),
						req.getUsername(), req.getTaskType(),req);
				
			}else{
				res = coderDashboardBO.getCollapsibleFilteredData(true, req, req.getIndex(),
						req.getTaskType(),
						req.getUsername(), req.getMasterToken(), true, req.getBbc());
				
			}
			

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						COLLAPSIBLE_SECTION, formattedDate);
				response = CommonUtils.getResponseObject(
						COLLAPSIBLE_SECTION, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, COLLAPSIBLE_SECTION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						COLLAPSIBLE_SECTION, formattedDate);
				response = CommonUtils.getResponseObject(
						COLLAPSIBLE_SECTION, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						COLLAPSIBLE_SECTION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					COLLAPSIBLE_SECTION, formattedDate);
			response = CommonUtils.getResponseObject(
					COLLAPSIBLE_SECTION, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, COLLAPSIBLE_SECTION);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

	@ApiOperation(value = "To get coder unbillable reasons")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getunbillablereasons", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getUnbillableReasons() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes UnbillableReasonsRes = null;

		try {

			UnbillableReasonsRes = coderDashboardBO.getUnbillableReasons();
			if (UnbillableReasonsRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						CODER_UNBILLABLE_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_UNBILLABLE_REASONS, "200", "0", SUCCESS_DESC);

				json = UnbillableReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_UNBILLABLE_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(CODER_UNBILLABLE_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CODER_UNBILLABLE_REASONS, "500", "556", "Invalid response");

				json = UnbillableReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_UNBILLABLE_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_UNBILLABLE_REASONS, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_UNBILLABLE_REASONS, "556", "556", e.getMessage());

			json = UnbillableReasonsRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_UNBILLABLE_REASONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*@ApiOperation(value = "To get CoderDashboard columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/searchcoderfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCoderDashboardFilterOption(
			@ApiParam(name = "Search CoderDashboard Filter Options",
				value = "Search CoderDashboard Filter Options", required = true)
			@RequestBody CoderDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CoderDashboardFilterRes coderDashboardFilter = null;
		Map<String, Object> messageHeader;
		try {

			coderDashboardFilter = coderDashboardBO.getCoderDashboardFilterOptions(req);

			if (coderDashboardFilter == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, coderDashboardFilter);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, coderDashboardFilter);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, coderDashboardFilter);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, 
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}*/
	
	@ApiOperation(value = "To get coder place of services")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getplaceofservice", headers = "Accept=application/json")
	public ResponseEntity<PlaceOfServiceRes> getplaceOfService() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		PlaceOfServiceRes json = new PlaceOfServiceRes();
		PlaceOfServiceRes placeOfServiceRes = null;

		try {

			placeOfServiceRes = coderDashboardBO.getplaceOfServices();
			if (placeOfServiceRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						CODER_PLACE_OF_SERVICES, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_PLACE_OF_SERVICES, "200", "0", SUCCESS_DESC);

				json = placeOfServiceRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_PLACE_OF_SERVICES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(CODER_PLACE_OF_SERVICES, formattedDate);
				response = CommonUtils.getResponseObject(CODER_PLACE_OF_SERVICES, "500", "556", "Invalid response");

				json = placeOfServiceRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_PLACE_OF_SERVICES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_PLACE_OF_SERVICES, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_PLACE_OF_SERVICES, "556", "556", e.getMessage());

			json = placeOfServiceRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_PLACE_OF_SERVICES);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To lock a record")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PutMapping(value = "/app/lockrecord", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> lockRecord(
			@ApiParam(name = "DashboardReq", value = "DashboardReq data", required = true)
			@RequestBody DashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		LockRecordRes res = null;
		Map<String, Object> response = null;
		try {
			
			  int isLocked = req.getIsLocked();
		        if (isLocked != 0 && isLocked != 1) {
		            messageHeader = CommonUtils.getMessageHeader(SAVE_LOCK_STATUS, formattedDate);
		            response = CommonUtils.getResponseObject(SAVE_LOCK_STATUS, "400", "400", "isLocked field should be either 0 or 1");
		            Map<String, Object> json = new HashMap<>();
		            json.put(ControllerConstants.API_RESPONSE, res);
		            HttpHeaders headers = new HttpHeaders();
		            headers.add(ControllerConstants.TIMESTAMP, formattedDate);
		            headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_LOCK_STATUS);
		            headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
		            headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
		            return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		        }
		 
		        // Check if all fields are filled with correct data type (you can add more validations as needed)
		        if (req.getVisitId() == 0L || req.getLastUpdatedByUserId() == null ||
		                req.getLastUpdatedByUsername() == null || req.getLastUpdatedByUserFullName() == null) {
		            messageHeader = CommonUtils.getMessageHeader(SAVE_LOCK_STATUS, formattedDate);
		            response = CommonUtils.getResponseObject(SAVE_LOCK_STATUS, "400", "400", "All fields must be filled");
		            Map<String, Object> json = new HashMap<>();
		            json.put(ControllerConstants.API_RESPONSE, res);
		            HttpHeaders headers = new HttpHeaders();
		            headers.add(ControllerConstants.TIMESTAMP, formattedDate);
		            headers.add(ControllerConstants.ACTION, ControllerConstants.SAVE_LOCK_STATUS);
		            headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
		            headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
		            return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
		        }

			res = coderDashboardBO.saveLockStatus(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_LOCK_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_LOCK_STATUS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_LOCK_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_LOCK_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_LOCK_STATUS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_LOCK_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_LOCK_STATUS,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_LOCK_STATUS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_LOCK_STATUS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	} 
	
	@ApiOperation(value = "Fetch Filtered Coder Dashboard Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/advancedsearch", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSearchCoderDashboard(
			@ApiParam(name = "CoderDashboardReq", value = "Coder DashboardReq Data", required = true)
			@RequestBody CoderDashboardReq coderDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SearchCoderDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			if(coderDashboardReq.isIsfilterapplied() == true){
				res = coderDashboardBO.searchCoderfilterData(coderDashboardReq);
				
			}else{
				res = coderDashboardBO.searchCoderData(coderDashboardReq);

				
			}
			//res = coderDashboardBO.searchCoderData(coderDashboardReq);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						SEARCH_CODER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_CODER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SEARCH_CODER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						SEARCH_CODER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(
						SEARCH_CODER_DASHBOARD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SEARCH_CODER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					SEARCH_CODER_DASHBOARD, formattedDate);
			response = CommonUtils.getResponseObject(
					SEARCH_CODER_DASHBOARD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SEARCH_CODER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/coderrecordbyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCoderRecordById(
			@ApiParam(name = "Coder Record Id", value = "Coder Record Id", required = true)
			@RequestBody CoderDashboardReq coderDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CoderChartRes res = null;
		Map<String, Object> response = null;
		try {
			log.info("Request::::: {}", coderDashboardReq);

			res = coderDashboardBO.getCoderRecordById(Long.parseLong(coderDashboardReq.getVisitId()), coderDashboardReq);


			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						COLLAPSIBLE_SECTION, formattedDate);
				response = CommonUtils.getResponseObject(
						COLLAPSIBLE_SECTION, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_RECORD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				log.info("Response:::::::::::::: {}", json);
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_RECORD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						CODER_RECORD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				log.info("Response::::::::: {}", json);

				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_RECORD, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_RECORD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_RECORD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	@ApiOperation(value = "To get collapsbile columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/coderfilteroptionsbybbc", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCollapsibleFilterOption(
			@ApiParam(name = "Search collapsible Filter Options",
				value = "Search Ccollapsible Filter Options", required = true)
			@RequestBody DashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CollapsibleFilterRes collapsibleFilterRes = null;
		Map<String, Object> messageHeader;
		try {

			collapsibleFilterRes = coderDashboardBO.getCollapsibleFilterOption(req, req.getBbc());

			if (collapsibleFilterRes == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.COLLAPSIBLE_FILER_OPTION,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.COLLAPSIBLE_FILER_OPTION, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, collapsibleFilterRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.COLLAPSIBLE_FILER_OPTION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.COLLAPSIBLE_FILER_OPTION,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.COLLAPSIBLE_FILER_OPTION, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, collapsibleFilterRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.COLLAPSIBLE_FILER_OPTION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.COLLAPSIBLE_FILER_OPTION,
					formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.COLLAPSIBLE_FILER_OPTION, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, collapsibleFilterRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, 
					ControllerConstants.COLLAPSIBLE_FILER_OPTION);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/placeofservicebyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getPlaceOfServicedById(
			@ApiParam(name = "placeOfService", value = "placeOfService", required = true)
			@RequestBody ProviderListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		PlaceOfServiceRes res = null;
		Map<String, Object> response = null;
		try {
			res = notificationBO.getPlaceOfServices(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						PLACE_OF_SERVICES, formattedDate);
				response = CommonUtils.getResponseObject(
						PLACE_OF_SERVICES, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, PLACE_OF_SERVICES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						PLACE_OF_SERVICES, formattedDate);
				response = CommonUtils.getResponseObject(
						PLACE_OF_SERVICES, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						PLACE_OF_SERVICES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					PLACE_OF_SERVICES, formattedDate);
			response = CommonUtils.getResponseObject(
					PLACE_OF_SERVICES, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_RECORD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	@ApiOperation(value = "To get CoderDashboard columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/advancesearchfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> advanceSearchFilterOption(
			@ApiParam(name = "Search CoderDashboard Filter Options",
				value = "Search CoderDashboard Filter Options", required = true)
			@RequestBody CoderDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CollapsibleFilterRes res = null;
		Map<String, Object> messageHeader;
		try {

			res = coderDashboardBO.advanceSearchFilterOption(req);

			if (res == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, 
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "Fetch Filtered Coder Dashboard Data")
 	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
 			@ApiResponse(code = 401, message = "Unauthorised") })
 	@PostMapping(value = "/app/advancesearchchart", headers = "Accept=application/json")
 	public ResponseEntity<Map<String, Object>> getSearchCoderDashboards(
 			@ApiParam(name = "CoderDashboardReq", value = "Coder DashboardReq Data", required = true)
 			@RequestBody CoderDashboardReq coderDashboardReq) {
 		String formattedDate = CommonUtils.getformattedDate();
 		Map<String, Object> messageHeader;
 		SearchCoderDashboardRes res = null;
 		Map<String, Object> response = null;
 		try {
 			if(coderDashboardReq.isIsfilterapplied() == true){
 				res = coderDashboardBO.searchCoderfilterData(coderDashboardReq);
 				
 			}else{
 				res = coderDashboardBO.searchCoderData(coderDashboardReq);
 
 				
 			}
 
 			if (res != null && res.getResponseCode() != null
 					&& res.getResponseCode().equalsIgnoreCase("0")) {
 				messageHeader = CommonUtils.getMessageHeader(
 						SEARCH_CODER_DASHBOARD, formattedDate);
 				response = CommonUtils.getResponseObject(SEARCH_CODER_DASHBOARD,
 						"200", "0", SUCCESS_DESC);
 
 				Map<String, Object> json = new HashMap<>();
 				json.put(ControllerConstants.API_RESPONSE, res);
 				HttpHeaders headers = new HttpHeaders();
 				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
 				headers.add(ControllerConstants.ACTION,
 						ControllerConstants.SEARCH_CODER_DASHBOARD);
 				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
 				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
 				return new ResponseEntity<>(json, headers, HttpStatus.OK);
 
 			} else {
 				messageHeader = CommonUtils.getMessageHeader(
 						SEARCH_CODER_DASHBOARD, formattedDate);
 				response = CommonUtils.getResponseObject(
 						SEARCH_CODER_DASHBOARD, "500", "556", "Service Exception");
 
 				Map<String, Object> json = new HashMap<>();
 				json.put(ControllerConstants.API_RESPONSE, res);
 				HttpHeaders headers = new HttpHeaders();
 				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
 				headers.add(ControllerConstants.ACTION,
 						ControllerConstants.SEARCH_CODER_DASHBOARD);
 				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
 				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
 				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
 			}
 
 		} catch (Exception excp) {
 			log.error(String.format("Exception occured: %s", excp));
 			messageHeader = CommonUtils.getMessageHeader(
 					SEARCH_CODER_DASHBOARD, formattedDate);
 			response = CommonUtils.getResponseObject(
 					SEARCH_CODER_DASHBOARD, "556", "556", excp.getMessage());
 
 			Map<String, Object> json = new HashMap<>();
 			json.put(ControllerConstants.API_RESPONSE, res);
 			HttpHeaders headers = new HttpHeaders();
 			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
 			headers.add(ControllerConstants.ACTION,
 					ControllerConstants.SEARCH_CODER_DASHBOARD);
 			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
 			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
 			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
 		}
 	}
	@ApiOperation(value = "Fetch Filtered Coder Dashboard Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/coderDashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredDatas(
			@ApiParam(name = "CoderDashboardReq", value = "Coder DashboardReq data", required = true)
			@RequestBody CoderDashboardReq coderDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CoderDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (coderDashboardReq.getFilters() != null
					&& !coderDashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}

			res = coderDashboardBO.getCoderDatas(isFilter,
					coderDashboardReq,coderDashboardReq.getIndex(),
					coderDashboardReq.getTaskType(), coderDashboardReq.getUsername(),
					coderDashboardReq.getMasterToken(),coderDashboardReq);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(CODER_FILTER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_FILTER_DASHBOARD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_FILTER_DASHBOARD, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_FILTER_DASHBOARD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CODER_FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get CoderDashboard columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/searchcoderfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCoderDashboardFilterOptions(
			@ApiParam(name = "Search CoderDashboard Filter Options",
				value = "Search CoderDashboard Filter Options", required = true)
			@RequestBody CoderDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptionsRes = null;
		Map<String, Object> messageHeader;
		try {

			filterOptionsRes = coderDashboardBO.getCoderDashboardFilterOption(req);

			if (filterOptionsRes == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptionsRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptionsRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptionsRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, 
					ControllerConstants.CODERDASHBOARD_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getSuperBill", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSuperBill(
			@ApiParam(name = "superbill", value = "superbill", required = true)
			@RequestBody SuperBillReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SuperBillRes res = null;
		Map<String, Object> response = null;
		try {
			res = coderDashboardBO.getSuperBillByVersion(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						GET_SUPERBILL, formattedDate);
				response = CommonUtils.getResponseObject(
						GET_SUPERBILL, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_SUPERBILL);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						GET_SUPERBILL, formattedDate);
				response = CommonUtils.getResponseObject(
						GET_SUPERBILL, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						GET_SUPERBILL);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					GET_SUPERBILL, formattedDate);
			response = CommonUtils.getResponseObject(
					GET_SUPERBILL, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, GET_SUPERBILL);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
}
