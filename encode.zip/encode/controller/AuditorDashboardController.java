package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SAVE_AUDIT_DETAILS;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_REASONS;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_FILTER_DASHBOARD;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_FILTER_DASHBOARD_RELEASE;
import static com.healogics.encode.constants.ControllerConstants.AUDITOR_COLLAPSIBLE_SECTION;
import static com.healogics.encode.constants.ControllerConstants.RELEASE_BY_FILTER_CHART;
import static com.healogics.encode.constants.ControllerConstants.UPDATE_CHART_STATUS;
import static com.healogics.encode.constants.ControllerConstants.INSURANCE_CARRIER;
import static com.healogics.encode.constants.ControllerConstants.NURSE_DISPOSITION_LIST;
import static com.healogics.encode.constants.ControllerConstants.RETRIEVE_NOTES;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.CHART_BY_STATUS;
import static com.healogics.encode.constants.ControllerConstants.ADD_OR_REMOVE_PINNED_FILTER;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AllInAuditChartsRes;
import com.healogics.encode.dto.AuditNotesListRes;
import com.healogics.encode.dto.AuditorCollapsibleSectionReq;
import com.healogics.encode.dto.AuditorCollapsibleSectionRes;
import com.healogics.encode.dto.AuditorDashboardFilterRes;
import com.healogics.encode.dto.AuditorDashboardReq;
import com.healogics.encode.dto.AuditorDashboardRes;
import com.healogics.encode.dto.AuditorReasonRes;
import com.healogics.encode.dto.ChartByStatusReq;
import com.healogics.encode.dto.ChartByStatusRes;
import com.healogics.encode.dto.InsuranceCarrierRes;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.ReleaseByFilterChartReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.dto.SaveAuditDetailsRes;
import com.healogics.encode.dto.UpdateChartstatusReq;
import com.healogics.encode.dto.UpdateChartstatusRes;
import com.healogics.encode.dto.addOrRemovePinnedFilterReq;
import com.healogics.encode.entity.CollapsibleFilterRes;
import com.healogics.encode.service.AuditorDashboardBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AuditorDashboardController {

	private static final String ALL_INAUDIT_CHARTS = null;

	private final Logger log = LoggerFactory.getLogger(AuditorFilterController.class);

	private final AuditorDashboardBO auditorDashboardBO;

	@Autowired
	public AuditorDashboardController(AuditorDashboardBO auditorDashboardBO) {
		this.auditorDashboardBO = auditorDashboardBO;

	}  
     
	@ApiOperation(value = "Save Insurance Carrier Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@GetMapping(value = "/app/getinsurancecarrier", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getInsuranceCarrier() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		InsuranceCarrierRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorDashboardBO.getInsuranceCarrier();

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(INSURANCE_CARRIER, formattedDate);
				response = CommonUtils.getResponseObject(INSURANCE_CARRIER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.INSURANCE_CARRIER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(INSURANCE_CARRIER, formattedDate);
				response = CommonUtils.getResponseObject(INSURANCE_CARRIER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.INSURANCE_CARRIER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(INSURANCE_CARRIER, formattedDate);
			response = CommonUtils.getResponseObject(INSURANCE_CARRIER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.INSURANCE_CARRIER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get auditor reasons")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getauditorreasons", headers = "Accept=application/json")
	public ResponseEntity<AuditorReasonRes> getAuditorReasons() {
 
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		AuditorReasonRes json = new AuditorReasonRes();
		AuditorReasonRes AuditorReasonsRes = null;
 
		try {
 
			AuditorReasonsRes = auditorDashboardBO.getAuditorReasons();
			if (AuditorReasonsRes.getResponseCode().equals("0")) {
 
				messageHeader = CommonUtils.getMessageHeader(
						AUDITOR_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(
						AUDITOR_REASONS, "200", "0", SUCCESS_DESC);
 
				json = AuditorReasonsRes;
 
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
 
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_REASONS, "500", "556", "Invalid response");
 
				json = AuditorReasonsRes;
 
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, AUDITOR_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			} 
 
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					AUDITOR_REASONS, formattedDate);
			response = CommonUtils.getResponseObject(
		 			AUDITOR_REASONS, "556", "556", e.getMessage());
 
			json = AuditorReasonsRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, AUDITOR_REASONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());
 
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}	

	   
	@ApiOperation(value = "To save Audit ChartDetails")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/saveauditdetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveAuditDetails(
			@ApiParam(name = "SaveAuditDetailsReq", value = "SaveAuditDetailsReq data", required = true)
			@RequestBody SaveAuditDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveAuditDetailsRes res = null;
		Map<String, Object> response = null;
		try {

			res = auditorDashboardBO.saveAuditDetails(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0") || res.getResponseCode().equalsIgnoreCase("2")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_AUDIT_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_AUDIT_DETAILS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_AUDIT_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_AUDIT_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_AUDIT_DETAILS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_AUDIT_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_AUDIT_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_AUDIT_DETAILS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_AUDIT_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Filtered Auditor Dashboard Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/auditordashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditorFilteredData(
			@ApiParam(name = "AuditorDashboardReq", value = "Auditor DashboardReq data", required = true) @RequestBody AuditorDashboardReq auditorDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AuditorDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (auditorDashboardReq.getFilters() != null && !auditorDashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}

			res = auditorDashboardBO.getAuditorData(isFilter, auditorDashboardReq, auditorDashboardReq.getIndex());

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_FILTER_DASHBOARD, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_FILTER_DASHBOARD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(AUDITOR_FILTER_DASHBOARD, formattedDate);
			response = CommonUtils.getResponseObject(AUDITOR_FILTER_DASHBOARD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
			@PostMapping(value = "/app/getauditorcollapsible", headers = "Accept=application/json")
			public ResponseEntity<Map<String, Object>> getCollapsibleSectionDetails(
					@ApiParam(name = "AuditorCollapsibleSectionData", value = "AuditorCollapsibleSectionData data", required = true)
					@RequestBody AuditorCollapsibleSectionReq req) {
				String formattedDate = CommonUtils.getformattedDate();
				Map<String, Object> messageHeader;
				AuditorCollapsibleSectionRes res = null;
				Map<String, Object> response = null;
				try {
					
					if(req.getFilters() ==null || req.getFilters().isEmpty()){
						res = auditorDashboardBO.getCollapsibleSectionDetails(req.getFilterId(), req);
						
					}else{

					res = auditorDashboardBO.getCollapsibleFilteredData(req.getFilterId(), req, true, req.getIndex(),true);
					}
					if (res != null && res.getResponseCode() != null
							&& res.getResponseCode().equalsIgnoreCase("0")) {
						messageHeader = CommonUtils.getMessageHeader(
								AUDITOR_COLLAPSIBLE_SECTION, formattedDate);
						response = CommonUtils.getResponseObject(
								AUDITOR_COLLAPSIBLE_SECTION, "200", "0", SUCCESS_DESC);

						Map<String, Object> json = new HashMap<>();
						json.put(ControllerConstants.API_RESPONSE, res);
						HttpHeaders headers = new HttpHeaders();
						headers.add(ControllerConstants.TIMESTAMP, formattedDate);
						headers.add(ControllerConstants.ACTION, AUDITOR_COLLAPSIBLE_SECTION);
						headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
						headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
						return new ResponseEntity<>(json, headers, HttpStatus.OK);

					} else {
						messageHeader = CommonUtils.getMessageHeader(
								AUDITOR_COLLAPSIBLE_SECTION, formattedDate);
						response = CommonUtils.getResponseObject(
								AUDITOR_COLLAPSIBLE_SECTION, "500", "556", "Service Exception");

						Map<String, Object> json = new HashMap<>();
						json.put(ControllerConstants.API_RESPONSE, res);
						HttpHeaders headers = new HttpHeaders();
						headers.add(ControllerConstants.TIMESTAMP, formattedDate);
						headers.add(ControllerConstants.ACTION, 
								AUDITOR_COLLAPSIBLE_SECTION);
						headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
						headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
						return new ResponseEntity<>(json, headers,
								HttpStatus.INTERNAL_SERVER_ERROR);
					}

				} catch (Exception excp) {
					log.error(String.format("Exception occured: %s ", excp));
					messageHeader = CommonUtils.getMessageHeader(
							AUDITOR_COLLAPSIBLE_SECTION, formattedDate);
					response = CommonUtils.getResponseObject(
							AUDITOR_COLLAPSIBLE_SECTION, "556", "556", excp.getMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, AUDITOR_COLLAPSIBLE_SECTION);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

				}
			}
  
	@ApiOperation(value = "To get Auditor Dashboard columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/searchauditorfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditorFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody AuditorDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AuditorDashboardFilterRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = auditorDashboardBO.getAuditorFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To update auditor chart status")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/updatechartstatus", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateChartStatus(
			@ApiParam(name = "UpdateChartstatusReq", value = "UpdateChartstatusReq data", required = true)
			@RequestBody UpdateChartstatusReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UpdateChartstatusRes res = null;
		Map<String, Object> response = null;
		try {

			res = auditorDashboardBO.updateChartStatus(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_CHART_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_CHART_STATUS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_CHART_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_CHART_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_CHART_STATUS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_CHART_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_CHART_STATUS,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_CHART_STATUS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_CHART_STATUS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getauditnotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditNotes(
			@ApiParam(name = "AuditorNotes", value = "AuditorNotes data", required = true)
			@RequestBody NoteListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AuditNotesListRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorDashboardBO.getAuditNotes(req, req.getUserRole());
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						RETRIEVE_NOTES, formattedDate);
				response = CommonUtils.getResponseObject(
						RETRIEVE_NOTES, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, RETRIEVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						RETRIEVE_NOTES, formattedDate);
				response = CommonUtils.getResponseObject(
						RETRIEVE_NOTES, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						RETRIEVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					RETRIEVE_NOTES, formattedDate);
			response = CommonUtils.getResponseObject(
					RETRIEVE_NOTES, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, RETRIEVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

	@ApiOperation(value = "To get collapsbile columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/auditorfilteroptionsbyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCollapsibleFilterOption(
			@ApiParam(name = "Search collapsible Filter Options", value = "Search Ccollapsible Filter Options", required = true) 
						@RequestBody AuditorCollapsibleSectionReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CollapsibleFilterRes collapsibleFilterRes = null;
		Map<String, Object> messageHeader;
		try {

			collapsibleFilterRes = auditorDashboardBO.getCollapsibleFilterOption(req, req.getFilterId());

			if (collapsibleFilterRes == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.COLLAPSIBLE_FILER_OPTION,
						formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.COLLAPSIBLE_FILER_OPTION, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, collapsibleFilterRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.COLLAPSIBLE_FILER_OPTION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.COLLAPSIBLE_FILER_OPTION,
						formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.COLLAPSIBLE_FILER_OPTION, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, collapsibleFilterRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.COLLAPSIBLE_FILER_OPTION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.COLLAPSIBLE_FILER_OPTION, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.COLLAPSIBLE_FILER_OPTION, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, collapsibleFilterRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.COLLAPSIBLE_FILER_OPTION);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Get All In Audit Charts")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@GetMapping(value = "/app/getinauditcharts", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAllInAuditCharts() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AllInAuditChartsRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorDashboardBO.getAllInAuditCharts();

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ALL_INAUDIT_CHARTS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ALL_INAUDIT_CHARTS, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ALL_INAUDIT_CHARTS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ALL_INAUDIT_CHARTS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ALL_INAUDIT_CHARTS, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ALL_INAUDIT_CHARTS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ALL_INAUDIT_CHARTS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.ALL_INAUDIT_CHARTS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ALL_INAUDIT_CHARTS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Get Charts by Status")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getchartbystatus", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getChartByStatus(
			@ApiParam(name = "Status", value = "Status list", required = true)
			@RequestBody ChartByStatusReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ChartByStatusRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditorDashboardBO.getChartByStatus(req);
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						CHART_BY_STATUS, formattedDate);
				response = CommonUtils.getResponseObject(
						CHART_BY_STATUS, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CHART_BY_STATUS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						CHART_BY_STATUS, formattedDate);
				response = CommonUtils.getResponseObject(
						CHART_BY_STATUS, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						CHART_BY_STATUS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					CHART_BY_STATUS, formattedDate);
			response = CommonUtils.getResponseObject(
					CHART_BY_STATUS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CHART_BY_STATUS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	
	@ApiOperation(value = "To get nurse disposition list")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getnursedispositionlist", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getNurseDispositionList() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes NurseDispositionRes = null;

		try {

			NurseDispositionRes = auditorDashboardBO.getNurseDispositionList();
			if (NurseDispositionRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						NURSE_DISPOSITION_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						NURSE_DISPOSITION_LIST, "200", "0", SUCCESS_DESC);

				json = NurseDispositionRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NURSE_DISPOSITION_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(NURSE_DISPOSITION_LIST, formattedDate);
				response = CommonUtils.getResponseObject(NURSE_DISPOSITION_LIST, "500", "556", "Invalid response");

				json = NurseDispositionRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NURSE_DISPOSITION_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					NURSE_DISPOSITION_LIST, formattedDate);
			response = CommonUtils.getResponseObject(
					NURSE_DISPOSITION_LIST, "556", "556", e.getMessage());

			json = NurseDispositionRes ;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, NURSE_DISPOSITION_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Filtered Auditor Dashboard Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/auditordashboardrelease", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditorFilteredReleaseData(
			@ApiParam(name = "AuditorDashboardReq", value = "Auditor DashboardReq data", required = true) @RequestBody AuditorDashboardReq auditorDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AuditorDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (auditorDashboardReq.getFilters() != null && !auditorDashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}

			res = auditorDashboardBO.getAuditorReleaseData(isFilter, auditorDashboardReq, auditorDashboardReq.getIndex());

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_FILTER_DASHBOARD_RELEASE, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_FILTER_DASHBOARD_RELEASE, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_FILTER_DASHBOARD_RELEASE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(AUDITOR_FILTER_DASHBOARD_RELEASE, formattedDate);
				response = CommonUtils.getResponseObject(AUDITOR_FILTER_DASHBOARD_RELEASE, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_FILTER_DASHBOARD_RELEASE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(AUDITOR_FILTER_DASHBOARD_RELEASE, formattedDate);
			response = CommonUtils.getResponseObject(AUDITOR_FILTER_DASHBOARD_RELEASE, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.AUDITOR_FILTER_DASHBOARD_RELEASE);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Release By Filter Chart Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/releasebyfilterchart", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> releaseByFilterChart(
			@ApiParam(name = "ReleaseByFilterChartReq", value = "Release by filter chart data", required = true) @RequestBody ReleaseByFilterChartReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response = null;
		try {
			
			res = auditorDashboardBO.releaseByFilterChart(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(RELEASE_BY_FILTER_CHART, formattedDate);
				response = CommonUtils.getResponseObject(RELEASE_BY_FILTER_CHART, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.RELEASE_BY_FILTER_CHART);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(RELEASE_BY_FILTER_CHART, formattedDate);
				response = CommonUtils.getResponseObject(RELEASE_BY_FILTER_CHART, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.RELEASE_BY_FILTER_CHART);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(RELEASE_BY_FILTER_CHART, formattedDate);
			response = CommonUtils.getResponseObject(RELEASE_BY_FILTER_CHART, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.RELEASE_BY_FILTER_CHART);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Add Or Remove Pinned Filter")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/addOrRemovePinnedFilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> addOrRemovePinnedFilter(
			@ApiParam(name = "addOrRemovePinnedFilterReq", value = "Add Or Remove Pinned Filter", required = true) @RequestBody addOrRemovePinnedFilterReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response = null;
		try {
			
			res = auditorDashboardBO.addOrRemovePinnedFilter(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ADD_OR_REMOVE_PINNED_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(ADD_OR_REMOVE_PINNED_FILTER, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ADD_OR_REMOVE_PINNED_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ADD_OR_REMOVE_PINNED_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(ADD_OR_REMOVE_PINNED_FILTER, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ADD_OR_REMOVE_PINNED_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADD_OR_REMOVE_PINNED_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(ADD_OR_REMOVE_PINNED_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ADD_OR_REMOVE_PINNED_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}

