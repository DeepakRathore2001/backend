package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.CMC_FILTER_DASHBOARD;
import static com.healogics.encode.constants.ControllerConstants.CODER_PENDING_REASONS;
import static com.healogics.encode.constants.ControllerConstants.CMC_UNBILLABLE_REASONS;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.PROVIDER_LIST_GET;
import static com.healogics.encode.constants.ControllerConstants.GET_CMC_RECORD;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.CMCDashboardRes;
import com.healogics.encode.dto.CMCData;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptionsRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ProviderListRes;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.service.CMCDashboardBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class CMCDashboardController {
	private final Logger log = LoggerFactory.getLogger(CMCDashboardController.class);

	private final CMCDashboardBO dashboardBO;

	@Autowired
	public CMCDashboardController(CMCDashboardBO dashboardBO) {
		this.dashboardBO = dashboardBO;
	}
 
	@ApiOperation(value = "Fetch Filtered CMC Dashboard Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/cmcdashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredData(
			@ApiParam(name = "DashboardReq", value = "DashboardReq data", required = true) @RequestBody DashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CMCDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (dashboardReq.getFilters() != null && !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}

			res = dashboardBO.getCMCData(isFilter, dashboardReq, dashboardReq.getIndex(),
					dashboardReq.getTaskType(),
					dashboardReq.getUsername(), dashboardReq.getMasterToken(), true);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(CMC_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(CMC_FILTER_DASHBOARD, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.CMC_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(CMC_FILTER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(CMC_FILTER_DASHBOARD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.CMC_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(CMC_FILTER_DASHBOARD, formattedDate);
			response = CommonUtils.getResponseObject(CMC_FILTER_DASHBOARD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.CMC_FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Dashboard columns Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/searchfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody DashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {
			filterOptions = dashboardBO.getSearchFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get coordinator pending reasons")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getpendingreasons", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getPendingReasons() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes pendingReasonsRes = null;

		try {

			pendingReasonsRes = dashboardBO.getPendingReasons();
			if (pendingReasonsRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(CODER_PENDING_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CODER_PENDING_REASONS, "200", "0", SUCCESS_DESC);

				json = pendingReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_PENDING_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(CODER_PENDING_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CODER_PENDING_REASONS, "500", "556", "Invalid response");

				json = pendingReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_PENDING_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(CODER_PENDING_REASONS, formattedDate);
			response = CommonUtils.getResponseObject(CODER_PENDING_REASONS, "556", "556", e.getMessage());

			json = pendingReasonsRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_PENDING_REASONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Provider List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getproviderslist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> searchPatient(
			@ApiParam(name = "Provider List Request", value = "Provider List ", required = true)
			@RequestBody ProviderListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ProviderListRes providerRes = null;
		Map<String, Object> response;
		try {
			providerRes = dashboardBO.getProvidersNames(req);

			if (providerRes != null && providerRes.getResponseCode() != null) {
				if (providerRes.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, providerRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "500", providerRes.getResponseCode(),
							providerRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, providerRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, providerRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
			response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, providerRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To Load Chart Details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/cmcrecordbyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCMCRecordById(
			@ApiParam(name = "DashboardReq", value = "DashboardReq data", required = true)
			@RequestBody DashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		CMCData res = null;
		Map<String, Object> response = null;
		try {

			if (dashboardReq.getVisitId() <= 0) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.GET_CMC_RECORD, statusCode,
						errorCode, statusDesc);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_CMC_RECORD);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);

			}

			res = dashboardBO.getCMCRecordById(dashboardReq);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						GET_CMC_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(
						GET_CMC_RECORD, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_CMC_RECORD);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_CMC_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(GET_CMC_RECORD, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_CMC_RECORD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					GET_CMC_RECORD, formattedDate);
			response = CommonUtils.getResponseObject(
					GET_CMC_RECORD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.GET_CMC_RECORD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get coordinator unbillable reasons")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getcmcunbillablereasons", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getUnbillableReasons() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes unbillableReasonsRes = null;

		try {

			unbillableReasonsRes = dashboardBO.getCMCUnbillableReasons();
			if (unbillableReasonsRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(CMC_UNBILLABLE_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CMC_UNBILLABLE_REASONS, "200", "0", SUCCESS_DESC);

				json = unbillableReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CMC_UNBILLABLE_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(CMC_UNBILLABLE_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CMC_UNBILLABLE_REASONS, "500", "556", "Invalid response");

				json = unbillableReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CMC_UNBILLABLE_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(CMC_UNBILLABLE_REASONS, formattedDate);
			response = CommonUtils.getResponseObject(CODER_PENDING_REASONS, "556", "556", e.getMessage());

			json = unbillableReasonsRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CMC_UNBILLABLE_REASONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
}
