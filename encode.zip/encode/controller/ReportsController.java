package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT;
import static com.healogics.encode.constants.ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT;
import static com.healogics.encode.constants.ControllerConstants.DRILL_DOWN_POST_AUDIT_REPORT;
import static com.healogics.encode.constants.ControllerConstants.GET_CPT_CODES_REPORT;
import static com.healogics.encode.constants.ControllerConstants.MISSING_CHART_REPORT;
import static com.healogics.encode.constants.ControllerConstants.MONTHLY_CHARGE_SUMMARY_REPORT;
import static com.healogics.encode.constants.ControllerConstants.POST_AUDIT_REPORT;
import static com.healogics.encode.constants.ControllerConstants.PROVIDER_LIST_GET;
import static com.healogics.encode.constants.ControllerConstants.RECON_REPORT;
import static com.healogics.encode.constants.ControllerConstants.GUIDANCE_REPORT;
import static com.healogics.encode.constants.ControllerConstants.REPORT_FILTER;
import static com.healogics.encode.constants.ControllerConstants.SEARCH_CODER_DASHBOARD;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.SUPERBILL_VARIANCE;
import static com.healogics.encode.constants.ControllerConstants.SUPERBILL_VARIANCE_REPORT;
import static com.healogics.encode.constants.ControllerConstants.ENCOUNTER_UNDER_REVIEW_MONTHLY;
import static com.healogics.encode.constants.ControllerConstants.ENCOUNTER_UNDER_REVIEW_COUNT;
import static com.healogics.encode.constants.ControllerConstants.ENCOUNTER_UNDER_REVIEW;
import static com.healogics.encode.constants.ControllerConstants.CHART_WEAKNESS_REPORT;
import static com.healogics.encode.constants.ControllerConstants.SUPERBILL_VARIANCE_FILTERED_DATA;
import static com.healogics.encode.constants.ControllerConstants.NURSE_AUDIT_NOTES_REPORT;
import static com.healogics.encode.constants.ControllerConstants.ECW_SENT_REPORT;
import static com.healogics.encode.constants.ControllerConstants.CODER_PRODUCTIVITY_REPORT;
import static com.healogics.encode.constants.ControllerConstants.CODER_PRODUCTIVITY_REPORT_DRILLDOWN;
import static com.healogics.encode.constants.ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.CPTCodesReportRes;
import com.healogics.encode.dto.ChartWeaknessReportRes;
import com.healogics.encode.dto.CoderProductivityReportDrilldownRes;
import com.healogics.encode.dto.CoderProductivityReportReq;
import com.healogics.encode.dto.CoderProductivityReportRes;
import com.healogics.encode.dto.DrillDownMissingChartReportRes;
import com.healogics.encode.dto.DrillDownMonthlyChargeSummaryRes;
import com.healogics.encode.dto.DrillDownPostAuditReportRes;
import com.healogics.encode.dto.EncounterMonthlyReviewRes;
import com.healogics.encode.dto.EncounterUnderReviewCountRes;
import com.healogics.encode.dto.EncounterUnderReviewRes;
import com.healogics.encode.dto.FilterOptionsRes;
import com.healogics.encode.dto.GuidanceReportReq;
import com.healogics.encode.dto.GuidanceReportRes;
import com.healogics.encode.dto.MissingChartDataRes;
import com.healogics.encode.dto.MissingChartFilterOptionsRes;
import com.healogics.encode.dto.MonthlyChargeSummaryReportRes;
import com.healogics.encode.dto.NurseAuditNotesReportReq;
import com.healogics.encode.dto.NurseAuditNotesReportRes;
import com.healogics.encode.dto.PostAuditFiltersRes;
import com.healogics.encode.dto.PostAuditReportRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ProviderListRes;
import com.healogics.encode.dto.ReconReportReq;
import com.healogics.encode.dto.ReconReportRes;
import com.healogics.encode.dto.ReportFilterReq;
import com.healogics.encode.dto.ReportRes;
import com.healogics.encode.dto.SuperbillVarianceReportRes;
import com.healogics.encode.dto.SuperbillVarianceRes;
import com.healogics.encode.dto.UnderReviewFilterOptionsRes;
import com.healogics.encode.dto.ecWSentReportReq;
import com.healogics.encode.dto.ecWSentReportRes;
import com.healogics.encode.entity.ReconReportFilterOptionsRes;
import com.healogics.encode.service.ReportBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController 
public class ReportsController {
	 
	private final Logger log = LoggerFactory.getLogger(ReportsController.class);
	
	private final ReportBO reportBO;
	
	@Autowired
	public ReportsController(ReportBO reportBO) {
		this.reportBO = reportBO;
	}
	
	@ApiOperation(value = "To view recon report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/reconreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> reconReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ReconReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.reconReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(RECON_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(RECON_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.RECON_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(RECON_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(RECON_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.RECON_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			} 
  
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(RECON_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(RECON_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.RECON_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To view Monthly Charge Summary By Procedure report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/monthlysummmarydata", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> monthlyChargeSummaryReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MonthlyChargeSummaryReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.monthlyChargeSummaryReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MONTHLY_CHARGE_SUMMARY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(MONTHLY_CHARGE_SUMMARY_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MONTHLY_CHARGE_SUMMARY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MONTHLY_CHARGE_SUMMARY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(MONTHLY_CHARGE_SUMMARY_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MONTHLY_CHARGE_SUMMARY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MONTHLY_CHARGE_SUMMARY_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(MONTHLY_CHARGE_SUMMARY_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MONTHLY_CHARGE_SUMMARY_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view Monthly Charge Summary By Procedure report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getCPTCodesForReports", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCPTCodesForReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CPTCodesReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.getCPTCodes(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(GET_CPT_CODES_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_CPT_CODES_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_CPT_CODES_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_CPT_CODES_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_CPT_CODES_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_CPT_CODES_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_CPT_CODES_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_CPT_CODES_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_CPT_CODES_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view Monthly Charge Summary By Procedure report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatemonthlysummaryreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> drillDownMonthlyChargeSummaryReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DrillDownMonthlyChargeSummaryRes res = null;
		Map<String, Object> response = null;
		try {
			/*if (StringUtils.isBlank(req.getCptCodes())) {
				
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}*/
			
			//res = reportBO.drillDownMonthlyChargeSummaryReport(req.getCptCodes());
			res = reportBO.drillDownMonthlyChargeSummaryReport(req.getCptCodes(),req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Provider List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getprovidersbybbc", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> searchPatient(
			@ApiParam(name = "Provider List Request", value = "Provider List ", required = true)
			@RequestBody ProviderListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		ProviderListRes providerRes = null;
		Map<String, Object> response;
		try {
			
					if (req.getFacilityIds() == null && req.getFacilityIds().isEmpty()) {
						statusCode = ControllerConstants.INVALID_PARAMETERS;
						errorCode = ControllerConstants.ERROR_CODE_NUMBER;
						statusDesc = ControllerConstants.INVALID_PARAMETERS;
						response = CommonUtils.getResponseObject(
								ControllerConstants.PROVIDER_LIST_GET, statusCode,
								errorCode, statusDesc);
						Map<String, Object> json = new HashMap<>();
						json.put(ControllerConstants.API_RESPONSE, providerRes);
						HttpHeaders headers = new HttpHeaders();
						headers.add(ControllerConstants.TIMESTAMP, formattedDate);
						headers.add(ControllerConstants.ACTION,
								ControllerConstants.PROVIDER_LIST_GET);
						headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
						return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
					}
					
					providerRes = reportBO.getProvidersNamesByBBC(req);
			if (providerRes != null && providerRes.getResponseCode() != null) {
				if (providerRes.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, providerRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
					response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "500", providerRes.getResponseCode(),
							providerRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, providerRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
					headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "500", "556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, providerRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PROVIDER_LIST_GET, formattedDate);
			response = CommonUtils.getResponseObject(PROVIDER_LIST_GET, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, providerRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.PROVIDER_LIST_GET);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view filters")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getBasicReportFilters", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getReportFilter(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.getReportFilter(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(REPORT_FILTER,
						formattedDate);
				response = CommonUtils.getResponseObject(REPORT_FILTER, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(REPORT_FILTER,
						formattedDate);
				response = CommonUtils.getResponseObject(REPORT_FILTER, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(REPORT_FILTER,
					formattedDate);
			response = CommonUtils.getResponseObject(REPORT_FILTER, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view Superbill Variance Report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatesuperbillvariancecount", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> superbillVarianceReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DrillDownMonthlyChargeSummaryRes res = null;
		Map<String, Object> response = null;
		try {
			if (StringUtils.isBlank(req.getCptCodes())) {
				
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}
			
			//res = reportBO.drillDownMonthlyChargeSummaryReport(req.getCptCodes());
			res = reportBO.drillDownMonthlyChargeSummaryReport(req.getCptCodes(),req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.DRILL_DOWN_MONTHLY_CHARGE_SUMMARY_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view Superbill Variance data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/superbillvariancedata", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> superbillVarianceReportData(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SuperbillVarianceRes res = null;
		Map<String, Object> response = null;
		try {
			res = reportBO.superbillVarianceReportData(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SUPERBILL_VARIANCE,
						formattedDate);
				response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUPERBILL_VARIANCE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SUPERBILL_VARIANCE,
						formattedDate);
				response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUPERBILL_VARIANCE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SUPERBILL_VARIANCE,
					formattedDate);
			response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SUPERBILL_VARIANCE);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To view Missing Chart Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/missingchartdata", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> missingChartData(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MissingChartDataRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.missingChartDataReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MISSING_CHART_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(MISSING_CHART_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MISSING_CHART_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MISSING_CHART_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(MISSING_CHART_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MISSING_CHART_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MISSING_CHART_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(MISSING_CHART_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MISSING_CHART_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To view Missing Chart report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatemissingchartreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> drillDownMissingChartReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DrillDownMissingChartReportRes res = null;
		Map<String, Object> response = null;
		try {
			if (req == null) {
				
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}
			
			res = reportBO.drillDownMissingChartReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MISSING_CHART_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_MISSING_CHART_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MISSING_CHART_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_MISSING_CHART_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_MISSING_CHART_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(DRILL_DOWN_MISSING_CHART_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To view Post Audit Chart Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@GetMapping(value = "/app/getfilters", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> postAuditData() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		PostAuditFiltersRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.postAuditFilters();

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(POST_AUDIT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(POST_AUDIT_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.POST_AUDIT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(POST_AUDIT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(POST_AUDIT_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.POST_AUDIT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(POST_AUDIT_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(POST_AUDIT_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.POST_AUDIT_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view Post Audit Chart report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatepostauditreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> drillDownPostAuditReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DrillDownPostAuditReportRes res = null;
		Map<String, Object> response = null;
		boolean isExcel = false;
		try {
			if (req == null) {
				
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_MISSING_CHART_REPORT);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}
			
			res = reportBO.drillDownPostAuditReport(req, isExcel);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_POST_AUDIT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_POST_AUDIT_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_POST_AUDIT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_POST_AUDIT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(DRILL_DOWN_POST_AUDIT_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DRILL_DOWN_POST_AUDIT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DRILL_DOWN_POST_AUDIT_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(DRILL_DOWN_POST_AUDIT_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.DRILL_DOWN_POST_AUDIT_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view encounters needing guidance report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/guidancereport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> guidanceReport(
			@ApiParam(name = "GuidanceReportReq", value = "GuidanceReportReq data", required = true)
			@RequestBody GuidanceReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		GuidanceReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.guidanceReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(GUIDANCE_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(GUIDANCE_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GUIDANCE_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GUIDANCE_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(GUIDANCE_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GUIDANCE_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GUIDANCE_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(GUIDANCE_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GUIDANCE_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To view Suberbill Variance report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatesuperbillvariancereport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> generateSuperbillVarianceReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SuperbillVarianceReportRes res = null;
		Map<String, Object> response = null;
		try {
			res = reportBO.generateSuperbillVarianceReport(req.getFacilityId(), req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SUPERBILL_VARIANCE_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUPERBILL_VARIANCE_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SUPERBILL_VARIANCE_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUPERBILL_VARIANCE_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SUPERBILL_VARIANCE_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SUPERBILL_VARIANCE_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view encounter under review count")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getencounterunderreviewcount", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEncounterUnderReviewCount(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EncounterUnderReviewCountRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.getEncounterUnderReviewCount(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW_COUNT,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW_COUNT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW_COUNT,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW_COUNT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW_COUNT,
					formattedDate);
			response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW_COUNT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view encounter under review report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getencounterunderreviewreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEncounterUnderReviewReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EncounterUnderReviewRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.getEncounterUnderReviewReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW,
					formattedDate);
			response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To view Encounter Under Review Monthly report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getencounterunderreviewmonthly", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEncounterUnderReviewMonthly(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EncounterMonthlyReviewRes res = null;
		Map<String, Object> response = null;
		try {
			if(req.isIsfilterapplied()== true){
				res = reportBO.getFilteredEncounterUnderReviewmonthly(req);
				
			}else{
			res = reportBO.getEncounterUnderReviewmonthly(req);
			}

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW_MONTHLY,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW_MONTHLY, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW_MONTHLY,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW_MONTHLY, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ENCOUNTER_UNDER_REVIEW_MONTHLY,
					formattedDate);
			response = CommonUtils.getResponseObject(ENCOUNTER_UNDER_REVIEW_MONTHLY, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view Chart Weakness report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatedeficiencyagingreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> deficiencyAgingReport(
			@ApiParam(name = "reconReportReq", value = "reconReportReq data", required = true)
			@RequestBody ReconReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ChartWeaknessReportRes res = null;
		Map<String, Object> response = null;
		
		try {
			if(req.isIsfilterapplied() == true){
				res =reportBO.deficiencyAgingReportFilteredData(req);
				
			}else{
				res = reportBO.deficiencyAgingReport(req);
			}
			

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(CHART_WEAKNESS_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(CHART_WEAKNESS_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CHART_WEAKNESS_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(CHART_WEAKNESS_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(CHART_WEAKNESS_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CHART_WEAKNESS_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(CHART_WEAKNESS_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(CHART_WEAKNESS_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CHART_WEAKNESS_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get Post Compliance Audit Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/searchpostauditreportfilter", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditReportMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody ReportFilterReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = reportBO.getAuditReportFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Filtered Post Compliance Audit Report")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/filteredpostauditreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredPostAuditReport(
			@ApiParam(name = "CoderDashboardReq", value = "Coder DashboardReq Data", required = true)
			@RequestBody ReportFilterReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		PostAuditReportRes res = null;
		Map<String, Object> response = null;
		try {
				res = reportBO.getFilteredPostAuditReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						SEARCH_CODER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_CODER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SEARCH_CODER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						SEARCH_CODER_DASHBOARD, formattedDate);
				response = CommonUtils.getResponseObject(
						SEARCH_CODER_DASHBOARD, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SEARCH_CODER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					SEARCH_CODER_DASHBOARD, formattedDate);
			response = CommonUtils.getResponseObject(
					SEARCH_CODER_DASHBOARD, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SEARCH_CODER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get Recon Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/reconreportfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getReconReportFilterOption(
			@ApiParam(name = "Recon Report Filter Options",
				value = "Recon Report Filter Options", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		ReconReportFilterOptionsRes reconReportFilter = null;
		Map<String, Object> messageHeader;
		try {

			reconReportFilter = reportBO.getReconReportFilterOptions(req);

			if (reconReportFilter == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.RECON_REPORT_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.RECON_REPORT_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, reconReportFilter);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.RECON_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.RECON_REPORT_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.RECON_REPORT_FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, reconReportFilter);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.RECON_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.RECON_REPORT_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.RECON_REPORT_FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, reconReportFilter);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, 
					ControllerConstants.RECON_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	
	@ApiOperation(value = "To get Missing Chart Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/missingchartfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getMissingChartFilterOption(
			@ApiParam(name = "Missing Chart Filter Options",
				value = "Missing Chart Filter Options", required = true)
			@RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		MissingChartFilterOptionsRes missingChartReportFilter = null;
		Map<String, Object> messageHeader;
		try {

			missingChartReportFilter = reportBO.getMissingChartFilterOption(req);

			if (missingChartReportFilter == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.MISSING_CHART_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.MISSING_CHART_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, missingChartReportFilter);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.MISSING_CHART_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.MISSING_CHART_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.MISSING_CHART_FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, missingChartReportFilter);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ControllerConstants.MISSING_CHART_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.MISSING_CHART_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.MISSING_CHART_FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, missingChartReportFilter);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, 
					ControllerConstants.MISSING_CHART_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	@ApiOperation(value = "To get Deficiency Aging Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/deficiencyagingfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDeficiencyAgingMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody ReportFilterReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = reportBO.getDeficiencyAgingMultiFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.DEFICIENCY__AGING_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Superbill Variance Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/superbillvariancefilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSuperbillVarianceMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody ReportFilterReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = reportBO.getSuperbillVarianceMultiFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.SUPERBILL_VARIANCE_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get Encounter Under Review Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getencounterunderreviewfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEncounterUnderReviewFilterOption(
			@ApiParam(name = "Encounter Under Review Filter Options", value = "Encounter Under Review Filter Options", required = true) @RequestBody ReconReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		UnderReviewFilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = reportBO.getEncounterUnderReviewFilterOption(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS,
						"406", "22", "No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS,
						"200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS, "500",
					"556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_UNDER_REVIEW_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch SuperbillVariance Report Filter Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/superbillvariancefiltereddata", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredSuperbillVarianceReport(
			@ApiParam(name = "ReportFilterReq", value = "ReportFilterReq Data", required = true)
			@RequestBody ReportFilterReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SuperbillVarianceReportRes res = null;
		Map<String, Object> response = null;
		try {
				res = reportBO.getFilteredSuperbillVarianceReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						SUPERBILL_VARIANCE_FILTERED_DATA, formattedDate);
				response = CommonUtils.getResponseObject(SUPERBILL_VARIANCE_FILTERED_DATA,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUPERBILL_VARIANCE_FILTERED_DATA);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						SUPERBILL_VARIANCE_FILTERED_DATA, formattedDate);
				response = CommonUtils.getResponseObject(
						SUPERBILL_VARIANCE_FILTERED_DATA, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUPERBILL_VARIANCE_FILTERED_DATA);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					SUPERBILL_VARIANCE_FILTERED_DATA, formattedDate);
			response = CommonUtils.getResponseObject(
					SUPERBILL_VARIANCE_FILTERED_DATA, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SUPERBILL_VARIANCE_FILTERED_DATA);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "To get Encounter Needing Guidence Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/encounterneedingguidencefilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEncounterNeedingGuidenceFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody ReportFilterReq req) {
 
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {
 
			filterOptions = reportBO.getEncounterNeedingGuidenceFilterOptions(req);
 
			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS, "500", "556", e.getMessage());
 
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_NEEDING_GUIDENCE_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view nurse audit notes report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/nurseauditnotesreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> nurseAuditNotesReport(	
			@ApiParam(name = "Filter nurseauditnotesreport", value = "Filter nurseauditnotesreport data", required = true)@RequestBody NurseAuditNotesReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NurseAuditNotesReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.nurseAuditNotesReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(NURSE_AUDIT_NOTES_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(NURSE_AUDIT_NOTES_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NURSE_AUDIT_NOTES_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(NURSE_AUDIT_NOTES_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(NURSE_AUDIT_NOTES_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NURSE_AUDIT_NOTES_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			} 
  
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NURSE_AUDIT_NOTES_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(NURSE_AUDIT_NOTES_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NURSE_AUDIT_NOTES_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get Encounter Under Review Mthly Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/encounterunderreviewmthlyfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEncounterUnderReviewMthlyFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody ReconReportReq req) {
 
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {
 
			filterOptions = reportBO.getEncounterUnderReviewMthlyFilterOptions(req);
 
			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS, "500", "556", e.getMessage());
 
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ENCOUNTER_UNDER_REVIEW_MTHLY_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To view ecw sent report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/ecwsentreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> ecWSentReport(
			@ApiParam(name = "ecWSentReportReq", value = "ecWSentReportReq data", required = true)
			@RequestBody ecWSentReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ecWSentReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.ecWSentReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ECW_SENT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(ECW_SENT_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ECW_SENT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ECW_SENT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(ECW_SENT_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ECW_SENT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			} 
  
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ECW_SENT_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(ECW_SENT_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.RECON_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "To get Post Compliance Audit Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/nurseauditnotesreportoptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAuditReportMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody NurseAuditNotesReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = reportBO.getNurseAuditNotesReportOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.FILTER_OPTIONS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To view coder productivity report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/coderproductivityreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> coderProductivityReport(	
			@ApiParam(name = "Coderproductivityreport", value = "Coderproductivityreport data", required = true)@RequestBody CoderProductivityReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CoderProductivityReportRes res = null;
		Map<String, Object> response = null;
		try {

			res = reportBO.coderProductivityReport(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(CODER_PRODUCTIVITY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(CODER_PRODUCTIVITY_REPORT, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_PRODUCTIVITY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(CODER_PRODUCTIVITY_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(CODER_PRODUCTIVITY_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_PRODUCTIVITY_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			} 
  
		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(CODER_PRODUCTIVITY_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(CODER_PRODUCTIVITY_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CODER_PRODUCTIVITY_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Coder ProductivityReport Drilldown Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/coderproductivityreportdrilldown", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCoderProductivityReportDrilldown(
			@ApiParam(name = "ReportFilterReq", value = "ReportFilterReq Data", required = true)
			@RequestBody ReportFilterReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CoderProductivityReportDrilldownRes res = null;
		Map<String, Object> response = null;
		try {
				res = reportBO.getCoderProductivityReportDrilldown(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_PRODUCTIVITY_REPORT_DRILLDOWN, formattedDate);
				response = CommonUtils.getResponseObject(CODER_PRODUCTIVITY_REPORT_DRILLDOWN,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_PRODUCTIVITY_REPORT_DRILLDOWN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						CODER_PRODUCTIVITY_REPORT_DRILLDOWN, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_PRODUCTIVITY_REPORT_DRILLDOWN, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CODER_PRODUCTIVITY_REPORT_DRILLDOWN);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_PRODUCTIVITY_REPORT_DRILLDOWN, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_PRODUCTIVITY_REPORT_DRILLDOWN, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CODER_PRODUCTIVITY_REPORT_DRILLDOWN);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get Coder Productivity Report Filter Options")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/coderproductivityreportfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCoderProductivityReportFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody ReportFilterReq req) {
 
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {
 
			filterOptions = reportBO.getCoderProductivityFilterOptions(req);
 
			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS, "500", "556", e.getMessage());
 
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.CODER_PRODUCTIVITY_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
