package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SAVE_AUDIT_HISTORY;
import static com.healogics.encode.constants.ControllerConstants.GET_BILL_HISTORY;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.AuditHistoryData;
import com.healogics.encode.dto.AuditHistoryRes;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.dto.BillHistoryRes;
import com.healogics.encode.dto.IHealGetVisitsReq;
import com.healogics.encode.dto.VisitDocumentListReq;
import com.healogics.encode.service.AuditHistoryBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AuditHistoryController {

	private final Logger log = LoggerFactory.getLogger(HistoryTimelineController.class);

	private final AuditHistoryBO auditHistoryBO;

	@Autowired
	public AuditHistoryController(AuditHistoryBO auditHistoryBO) {
		this.auditHistoryBO = auditHistoryBO;
	}

	@ApiOperation(value = "To save audithistory data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/saveaudithistory", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getHistoryTimeline(
			@ApiParam(name = "AuditHistoryData", value = "AuditHistoryData data", required = true) 
			@RequestBody AuditHistoryData data) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AuditHistoryRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditHistoryBO.saveAuditHistory(data);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_AUDIT_HISTORY, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_AUDIT_HISTORY, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, SAVE_AUDIT_HISTORY);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_AUDIT_HISTORY, formattedDate);
				response = CommonUtils.getResponseObject(SAVE_AUDIT_HISTORY, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, SAVE_AUDIT_HISTORY);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_AUDIT_HISTORY, formattedDate);
			response = CommonUtils.getResponseObject(SAVE_AUDIT_HISTORY, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, SAVE_AUDIT_HISTORY);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To save billhistory data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getbillhistory", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getBillHistoryData(
			@ApiParam(name = "BillHistoryData", value = "BillHistoryData data", required = true) 
			@RequestBody  BillHistoryReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		BillHistoryRes res = null;
		Map<String, Object> response = null;
		try {
			res = auditHistoryBO.getBillHistoryData(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(GET_BILL_HISTORY, formattedDate);
				response = CommonUtils.getResponseObject(GET_BILL_HISTORY, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_BILL_HISTORY);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_BILL_HISTORY, formattedDate);
				response = CommonUtils.getResponseObject(GET_BILL_HISTORY, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_BILL_HISTORY);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_BILL_HISTORY, formattedDate);
			response = CommonUtils.getResponseObject(GET_BILL_HISTORY, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, GET_BILL_HISTORY);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
