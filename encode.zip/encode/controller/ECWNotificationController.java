package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.GET_NOTIFICATION;
import static com.healogics.encode.constants.ControllerConstants.IHEAL_PATIENTHSPBALANCEDUESAVE;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.IHealPatientHSPBalanceDueSaveReq;
import com.healogics.encode.dto.IHealPatientHSPBalanceDueSaveRes;
import com.healogics.encode.dto.IHealVisitDocumentRes;
import com.healogics.encode.dto.ParsedDataDTO;
import com.healogics.encode.dto.SNSNotificationDetails;
import com.healogics.encode.dto.SNSNotificationResponse;
import com.healogics.encode.dto.VisitDocumentListReq;
import com.healogics.encode.service.ECWService;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ECWNotificationController {
	private final Logger log = LoggerFactory
			.getLogger(ECWNotificationController.class);

	private final ECWService eCWService;

	@Autowired
	public ECWNotificationController(ECWService eCWService) {
		this.eCWService = eCWService;
	}
	
	@ApiOperation(value = "Get SNS Notification")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/user/getecwnotification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEcwNotification(			
			@ApiParam(name = "SNSNotificationDetails",
				value = "SNSNotificationDetails data", required = true)
			@RequestBody SNSNotificationDetails req) {
		log.info("req : " +req);
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response = null;
		SNSNotificationResponse res = null;
		try {
			res = eCWService.processeCWNotifcation(req);

			messageHeader = CommonUtils
					.getMessageHeader(GET_NOTIFICATION, formattedDate);
			response = CommonUtils.getResponseObject(GET_NOTIFICATION,
					"200", "0", SUCCESS_DESC);
			
			Map<String, Object> json = new HashMap<String, Object>();
			json.put(ControllerConstants.API_RESPONSE, res);

			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_NOTIFICATION);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE,
					String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_NOTIFICATION,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_NOTIFICATION,
					"556", "556", excp.getMessage());
			
			Map<String, Object> json = new HashMap<String, Object>();
			json.put(ControllerConstants.API_RESPONSE, res);

			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_NOTIFICATION);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/user/parse-file")
    public List<ParsedDataDTO> parseFile(@RequestParam String fileName) {
        log.info("Received file name: " + fileName);
 
        File file;
        try {
            file = new ClassPathResource(fileName).getFile();
        } catch (IOException e) {
            throw new IllegalArgumentException("File not found: " + fileName, e);
        }
 
        List<ParsedDataDTO> parsedData = eCWService.parseFile(file.getAbsolutePath());
        if (parsedData.isEmpty()) {
            throw new IllegalArgumentException("No data parsed. Check the file and its format.");
        }
        return parsedData;
    }
	
	@GetMapping("/user/processhistoricalpatientbalancecsv")
    public String processHistoricalPatientBalanceCSVs() {
		Boolean apiResponse = false;
		try {
			apiResponse = eCWService.processHistoricalPatientBalanceCSVs();
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
		}
		return "Historical files processed Successfully";
    }
	
	
	@ApiOperation(value = "To get Response for Iheal PatientHSPBalanceDueSave API")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/user/patienthspbalanceduesave", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> patientHSPBalanceDueSave(
			@ApiParam(name = "IHealPatientHSPBalanceDueSave Req", value = "IHealPatientHSPBalanceDueSave Req", required = true) @RequestBody IHealPatientHSPBalanceDueSaveReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealPatientHSPBalanceDueSaveRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getFacilityId()) || StringUtils.isBlank(req.getPatientId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_PATIENTHSPBALANCEDUESAVE, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PATIENTHSPBALANCEDUESAVE);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = eCWService.testIhealPatientHSPBalanceDueSave(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_PATIENTHSPBALANCEDUESAVE, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_PATIENTHSPBALANCEDUESAVE, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_PATIENTHSPBALANCEDUESAVE);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(IHEAL_PATIENTHSPBALANCEDUESAVE, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_PATIENTHSPBALANCEDUESAVE, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PATIENTHSPBALANCEDUESAVE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_PATIENTHSPBALANCEDUESAVE, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_PATIENTHSPBALANCEDUESAVE, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PATIENTHSPBALANCEDUESAVE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_PATIENTHSPBALANCEDUESAVE, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_PATIENTHSPBALANCEDUESAVE, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PATIENTHSPBALANCEDUESAVE);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
