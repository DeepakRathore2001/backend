package com.healogics.encode.controller;

import java.util.HashMap;
import java.util.Map;

import static com.healogics.encode.constants.ControllerConstants.IHEAL_PROGRESS_NOTES_LIST;
import static com.healogics.encode.constants.ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST;
import static com.healogics.encode.constants.ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.WOUND_LIST;
import static com.healogics.encode.constants.ControllerConstants.IHEAL_DEBRIDEMENTS_LIST;
import static com.healogics.encode.constants.ControllerConstants.GET_DOCUMENT_LIST;
import static com.healogics.encode.constants.ControllerConstants.UPLOAD_CMC_DOCUMENTS;
import static com.healogics.encode.constants.ControllerConstants.UPLOAD_DOCUMENTS;
import static com.healogics.encode.constants.ControllerConstants.GET_DOC_URL;
import static com.healogics.encode.constants.ControllerConstants.DELETE_DOCUMENT_LIST;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.DBDocumentContentRes;
import com.healogics.encode.dto.DBDocumentListReq;
import com.healogics.encode.dto.DBDocumentListRes;
import com.healogics.encode.dto.DocumentDeleteReq;
import com.healogics.encode.dto.DocumentDeleteRes;
import com.healogics.encode.dto.DocumentURLReq;
import com.healogics.encode.dto.DocumentURLRes;
import com.healogics.encode.dto.DocumentsListReq;
import com.healogics.encode.dto.IHealDocumentRes;
import com.healogics.encode.dto.IHealVisitDocumentRes;
import com.healogics.encode.dto.VisitDocumentListReq;
import com.healogics.encode.dto.WoundListRes;
import com.healogics.encode.service.DocumentsBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DocumentsController {

	private final Logger log = LoggerFactory.getLogger(DocumentsController.class);

	private final DocumentsBO documentsBO;

	@Autowired
	public DocumentsController(DocumentsBO documentsBO) {
		this.documentsBO = documentsBO;
	}

	@ApiOperation(value = "To get List of Progress Notes from iHeal")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getprogressnotesload", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getProgressNotesDetails(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true)
			@RequestBody DocumentsListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getUserId())) {
				
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getProgressNotesLoad(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROGRESS_NOTES_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROGRESS_NOTES_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_PROGRESS_NOTES_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(IHEAL_PROGRESS_NOTES_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_PROGRESS_NOTES_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_PROGRESS_NOTES_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_PROGRESS_NOTES_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_PROGRESS_NOTES_LIST, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_PROGRESS_NOTES_LIST, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get List of document id from iHeal")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getvisitdocumentlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getVisitDocumentList(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody VisitDocumentListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealVisitDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken()) || StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getVisitDocumentList(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_VISIT_DOCUMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

 
	@ApiOperation(value = "To get Wound Assessment details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getwoundassessmentload", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getWoundAssessmentLoad(
			@ApiParam(name = "Wound List Req", value = "Wound List Req", required = true) @RequestBody DocumentsListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken()) || Integer.parseInt(req.getUserId()) == 0) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			WoundListRes woundListRes = documentsBO.getIHealWoundList(req);

			if (!woundListRes.getActiveWounds().isEmpty()) {
				log.debug("woundListRes", woundListRes);
				int woundDocumentEntityId = woundListRes.getActiveWounds().get(0).getDocument().getDocumentEntityId();
				log.debug("documentid", woundDocumentEntityId);
				req.setWoundDocumentEntityId(String.valueOf(woundDocumentEntityId));
			}

			res = documentsBO.getIHealWoundAssessmentLoad(req);

			if (res != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_WOUNDASSESSMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_WOUNDASSESSMENT_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// Unknown error
				messageHeader = CommonUtils.getMessageHeader(IHEAL_WOUNDASSESSMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_WOUNDASSESSMENT_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_WOUNDASSESSMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_WOUNDASSESSMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(WOUND_LIST, formattedDate);
			response = CommonUtils.getResponseObject(WOUND_LIST, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Debridements details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getdebridementload", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDebridementLoad(
			@ApiParam(name = "Wound List Req", value = "Wound List Req", required = true) @RequestBody DocumentsListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken()) || Integer.parseInt(req.getUserId()) == 0) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_DEBRIDEMENTS_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}
			WoundListRes woundListRes = documentsBO.getIHealWoundList(req);

			if (!woundListRes.getActiveWounds().isEmpty()) {
				log.debug("woundListRes", woundListRes);
				int woundDocumentEntityId = woundListRes.getActiveWounds().get(0).getDocument().getDocumentEntityId();
				log.debug("documentid", woundDocumentEntityId);
				req.setWoundDocumentEntityId(String.valueOf(woundDocumentEntityId));
			}

			res = documentsBO.getDebridementLoad(req);

			if (res != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_DEBRIDEMENTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_DEBRIDEMENTS_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// Unknown error
				messageHeader = CommonUtils.getMessageHeader(IHEAL_DEBRIDEMENTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_DEBRIDEMENTS_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_DEBRIDEMENTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_DEBRIDEMENTS_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(WOUND_LIST, formattedDate);
			response = CommonUtils.getResponseObject(WOUND_LIST, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get document URL")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getdocumenturl", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDocumentURL(
			@ApiParam(name = "Get DocumentURL Req", value = "Get DocumentURL Req", required = true) @RequestBody DocumentURLReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DocumentURLRes documentURLRes = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getDocumentId()) || StringUtils.isBlank(req.getMasterToken())
					|| req.getUserId() == 0 || StringUtils.isBlank(req.getFacilityId())) {

				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.GET_DOC_URL, statusCode, errorCode,
						statusDesc);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, documentURLRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOC_URL);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			documentURLRes = documentsBO.getDocumentURL(req);

			if (documentURLRes != null && documentURLRes.getResponseCode() != null
					&& documentURLRes.getResponseCode().equalsIgnoreCase("0")) {

				messageHeader = CommonUtils.getMessageHeader(GET_DOC_URL, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOC_URL, "200", documentURLRes.getResponseCode(),
						documentURLRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, documentURLRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_DOC_URL);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_DOC_URL, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOC_URL, "500",
						(documentURLRes != null ? documentURLRes.getResponseCode() : ""),
						(documentURLRes != null ? documentURLRes.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, documentURLRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOC_URL);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(GET_DOC_URL, formattedDate);
			response = CommonUtils.getResponseObject(GET_DOC_URL, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, documentURLRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOC_URL);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Document List from Database ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getdocumentlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDocumentList(
			@ApiParam(name = "DocumentListReq", value = "DocumentListReq data", required = true) @RequestBody DBDocumentListReq dbDocumentListReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DBDocumentListRes res = null;
		Map<String, Object> response = null;
		try {

			if (dbDocumentListReq.getPatientId() <= 0 || dbDocumentListReq.getVisitId() <= 0) {

				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.GET_DOCUMENT_LIST, statusCode, errorCode,
						statusDesc);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOCUMENT_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getDocumentList(dbDocumentListReq);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {

				messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_DOCUMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_LIST, formattedDate);
			response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOCUMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Document Content from Database")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getdocumentcontent", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDocumentContent(
			@ApiParam(name = "DocumentListReq", value = "DocumentListReq data", required = true) @RequestBody DBDocumentListReq dbDocumentListReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DBDocumentContentRes res = null;
		Map<String, Object> response = null;
		try {

			if (dbDocumentListReq.getPatientId() <= 0 || dbDocumentListReq.getVisitId() <= 0
					|| dbDocumentListReq.getDocumentType().isEmpty() || dbDocumentListReq.getDocumentType() == null) {

				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.GET_DOCUMENT_LIST, statusCode, errorCode,
						statusDesc);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOCUMENT_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);

			}

			res = documentsBO.getDocumentContent(dbDocumentListReq);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {

				messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_DOCUMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_LIST, formattedDate);
			response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.GET_DOCUMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Upload Documents")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/uploaddocuments", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> uploadDocument(
			@RequestParam("file") MultipartFile[] files,
			@RequestParam("dashboardName") String dashboardName) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		APIResponse res = null;
		Map<String, Object> response = null;
		try {
			log.info("dashboardName : {}", dashboardName);
			res = documentsBO.uploadDocuments(files,dashboardName);
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						UPLOAD_DOCUMENTS, formattedDate);
				response = CommonUtils.getResponseObject(
						UPLOAD_DOCUMENTS, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, UPLOAD_DOCUMENTS);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						UPLOAD_DOCUMENTS, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						UPLOAD_DOCUMENTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					UPLOAD_DOCUMENTS, formattedDate);
			response = CommonUtils.getResponseObject(
					UPLOAD_DOCUMENTS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, UPLOAD_DOCUMENTS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	} 
	
	@ApiOperation(value = "Delete Document List from Database ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/deletedocuments", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> deleteDocumentList(
			@ApiParam(name = "DocumentDeleteReq", value = "DocumentDeleteReq data", required = true) 
			@RequestBody DocumentDeleteReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DocumentDeleteRes res = null;
		Map<String, Object> response = null;
		try {

			if (req.getDocumentId() == null && req.getDocumentId().isEmpty()) {

				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.DELETE_DOCUMENT_LIST, statusCode,
						errorCode, statusDesc);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.DELETE_DOCUMENT_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.deleteDocumentList(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {

				messageHeader = CommonUtils.getMessageHeader(DELETE_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(DELETE_DOCUMENT_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, DELETE_DOCUMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DELETE_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(DELETE_DOCUMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.DELETE_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DELETE_DOCUMENT_LIST, formattedDate);
			response = CommonUtils.getResponseObject(DELETE_DOCUMENT_LIST, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.DELETE_DOCUMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
