package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.ADMINISTRATION_ENCODE_USERS;
import static com.healogics.encode.constants.ControllerConstants.NURSE_ROLE;
import static com.healogics.encode.constants.ControllerConstants.SAVE_NOTES;
import static com.healogics.encode.constants.ControllerConstants.ADMIN_FILTER_DASHBOARD;
import static com.healogics.encode.constants.ControllerConstants.ENCODEROLE;
import static com.healogics.encode.constants.ControllerConstants.ENCODE_ROLES;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.FACILITY_SETTINGS;
import static com.healogics.encode.constants.ControllerConstants.CAMPUS_INDICATOR;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.AdminDashboardFilterOptionsRes;
import com.healogics.encode.dto.AdminDashboardReq;
import com.healogics.encode.dto.AdminDashboardRes;
import com.healogics.encode.dto.AdministrationEncodeUsersRes;
import com.healogics.encode.dto.CampusIndicatorReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.EncodeRolesRes;
import com.healogics.encode.dto.FacilityDetailsReq;
import com.healogics.encode.dto.FacilitySettingsFilterOptionsRes;
import com.healogics.encode.dto.FacilitySettingsRes;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.NurseRoleResponse;
import com.healogics.encode.dto.RoleAssignmentRes;
import com.healogics.encode.service.AdministrationBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AdministrationController {

	private static final String ADMIN_FILTER_FACILITY_DETAILS = null;

	private final Logger log = LoggerFactory.getLogger(AdministrationController.class);

	private final AdministrationBO administrationBO;

	@Autowired
	public AdministrationController(AdministrationBO administrationBO) {
		this.administrationBO = administrationBO; 
	} 

	@ApiOperation(value = "Fetch Coder Users")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getusersbyrole", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCoderUsers(@RequestBody DashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdministrationEncodeUsersRes res = null;
		Map<String, Object> response = null;
		try {
			res = administrationBO.getCoderUsers(req);

			messageHeader = CommonUtils.getMessageHeader(ADMINISTRATION_ENCODE_USERS, formattedDate);
			response = CommonUtils.getResponseObject(ADMINISTRATION_ENCODE_USERS, "200", "0", SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ADMINISTRATION_ENCODE_USERS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADMINISTRATION_ENCODE_USERS, formattedDate);
			response = CommonUtils.getResponseObject(ADMINISTRATION_ENCODE_USERS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.ADMINISTRATION_ENCODE_USERS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Filtered Admin Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/filterencodeusers", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredData(
			@ApiParam(name = "AdminDashboardReq", value = "AdminDashboardReq data", required = true) @RequestBody AdminDashboardReq adminDashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdminDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (adminDashboardReq.getFilters() != null
					&& !adminDashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
				res = administrationBO.getEncodeUsers(isFilter,
						adminDashboardReq, adminDashboardReq.getIndex(), false);

			if (res != null
					&& res.getResponseCode() != null
					&& res.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(ADMIN_FILTER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ADMIN_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(ADMIN_FILTER_DASHBOARD,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ADMIN_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_DASHBOARD,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMIN_FILTER_DASHBOARD, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMIN_FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get Role Admin Dashboard columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/rolefilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody AdminDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AdminDashboardFilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = administrationBO.getSearchFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To save EncodeRole")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/saveencoderole", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveEncodeRole(
			@ApiParam(name = "AdminDashboardReq", value = "AdminDashboardReq data", required = true)
			@RequestBody AdminDashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		RoleAssignmentRes res = null;
		Map<String, Object> response = null;
		try {

			res = administrationBO.saveRoleAssignment(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ENCODEROLE,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCODEROLE, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_CHART_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ENCODEROLE,
						formattedDate);
				response = CommonUtils.getResponseObject(ENCODEROLE, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_CHART_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ENCODEROLE,
					formattedDate);
			response = CommonUtils.getResponseObject(ENCODEROLE, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_CHART_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get encode role values")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getencoderoles", headers = "Accept=application/json")
	public ResponseEntity<EncodeRolesRes> getEncodeRoles() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		EncodeRolesRes json = new EncodeRolesRes();
		EncodeRolesRes res = null;

		try {

			res = administrationBO.getEncodeRoles();
			if (res.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(ENCODE_ROLES, formattedDate);
				response = CommonUtils.getResponseObject(ENCODE_ROLES, "200", "0", SUCCESS_DESC);

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ENCODE_ROLES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ENCODE_ROLES, formattedDate);
				response = CommonUtils.getResponseObject(ENCODE_ROLES, "500", "556",
						"Invalid response");

				json = res;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ENCODE_ROLES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ENCODE_ROLES, formattedDate);
			response = CommonUtils.getResponseObject(ENCODE_ROLES, "556", "556", e.getMessage());

			json = res;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ENCODE_ROLES);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Nurse Role Users")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getnurserole", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNurseUsers(@RequestBody DashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NurseRoleResponse res = null;
		Map<String, Object> response = null;
		try {
			res = administrationBO.getNurseUsers(req);

			messageHeader = CommonUtils.getMessageHeader(NURSE_ROLE, formattedDate);
			response = CommonUtils.getResponseObject(NURSE_ROLE, "200", "0", SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.NURSE_ROLE);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NURSE_ROLE, formattedDate);
			response = CommonUtils.getResponseObject(NURSE_ROLE, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.NURSE_ROLE);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Nurse Role Users")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@GetMapping(value = "/app/getfacilitydetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityDetails() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		FacilitySettingsRes res = null;
		Map<String, Object> response = null;
		try {
			res = administrationBO.getFacilitySettings();

			messageHeader = CommonUtils.getMessageHeader(FACILITY_SETTINGS, formattedDate);
			response = CommonUtils.getResponseObject(FACILITY_SETTINGS, "200", "0", SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.FACILITY_SETTINGS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured in getFacilityDetails: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(FACILITY_SETTINGS, formattedDate);
			response = CommonUtils.getResponseObject(FACILITY_SETTINGS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.FACILITY_SETTINGS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "To Update On Or Off Campus indicator")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/updatecampusindicator", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> UpdateCampusIndicator(
			@ApiParam(name = "CampusIndicatorReq", value = "CampusIndicatorReq data", required = true)
			@RequestBody CampusIndicatorReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NotesRes res = null;
		Map<String, Object> response = null;
		try {
			res = administrationBO.UpdateCampusIndicator(req);
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(CAMPUS_INDICATOR,
						formattedDate);
				response = CommonUtils.getResponseObject(CAMPUS_INDICATOR, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CAMPUS_INDICATOR);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(CAMPUS_INDICATOR,
						formattedDate);
				response = CommonUtils.getResponseObject(CAMPUS_INDICATOR, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CAMPUS_INDICATOR);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_NOTES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "Fetch facility details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/filterfacilitydetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilterFacilityDetails(
			@ApiParam(name = "FacilityDetailsReq", value = "FacilityDetailsReq data", required = true) @RequestBody FacilityDetailsReq Req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		FacilitySettingsRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (Req.getFilters() != null
					&& !Req.getFilters().isEmpty()) {
				isFilter = true;
			}
				res = administrationBO.getFacilitySettingsFilterData(isFilter,
						Req, Req.getIndex(), false);

			if (res != null
					&& res.getResponseCode() != null
					&& res.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_FACILITY_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(ADMIN_FILTER_FACILITY_DETAILS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ADMIN_FILTER_FACILITY_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_FACILITY_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(ADMIN_FILTER_FACILITY_DETAILS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ADMIN_FILTER_FACILITY_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_FACILITY_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMIN_FILTER_FACILITY_DETAILS, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMIN_FILTER_FACILITY_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get facility settings columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/facilitydetailsfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody FacilityDetailsReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
	FacilitySettingsFilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = administrationBO.getFacilitySettingsFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}