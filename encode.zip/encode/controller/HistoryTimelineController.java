package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.HISTORY_TIMELINE_LIST;
import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.HistoryTimeLineListRes;
import com.healogics.encode.dto.HistoryTimelineReq;
import com.healogics.encode.service.HistoryTimelineBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class HistoryTimelineController {
	private final Logger log = LoggerFactory.getLogger(HistoryTimelineController.class);

	private final HistoryTimelineBO historyTimelineBO;

	@Autowired
	public HistoryTimelineController(HistoryTimelineBO historyTimelineBO) {
		this.historyTimelineBO = historyTimelineBO;
	}
	
	@ApiOperation(value = "To get historytimeline")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/gethistorytimeline", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getHistoryTimeline(
			@ApiParam(name = "HistoryTimelineReq", value = "HistoryTimelineReq data", required = true)
			@RequestBody HistoryTimelineReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		HistoryTimeLineListRes res = null;
		Map<String, Object> response = null;
		try {
			res = historyTimelineBO.getHistoryTimeline(req.getIndex(), req.getVisitId());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(HISTORY_TIMELINE_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(HISTORY_TIMELINE_LIST, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, HISTORY_TIMELINE_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(HISTORY_TIMELINE_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(HISTORY_TIMELINE_LIST, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						HISTORY_TIMELINE_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(HISTORY_TIMELINE_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(HISTORY_TIMELINE_LIST, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					HISTORY_TIMELINE_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}