package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.CODER_WEAKNESS_REASONS;
import static com.healogics.encode.constants.ControllerConstants.SEARCH_ESCALATED_STATUS;
import static com.healogics.encode.constants.ControllerConstants.SAVE_CHART_DETAILS;
import static com.healogics.encode.constants.ControllerConstants.SAVE_NOTES;
import static com.healogics.encode.constants.ControllerConstants.SAVE_RECORD;
import static com.healogics.encode.constants.ControllerConstants.SEARCH_ICD10_CODES;
import static com.healogics.encode.constants.ControllerConstants.RETRIEVE_NOTES;
import static com.healogics.encode.constants.ControllerConstants.DEFICIENCY_LIST;
import static com.healogics.encode.constants.ControllerConstants.ESCALATE_REASONS_LIST;
import static com.healogics.encode.constants.ControllerConstants.CODER_MODIFIERS_REASONS;
import static com.healogics.encode.constants.ControllerConstants.GET_CPT_CODES;
import static com.healogics.encode.constants.ControllerConstants.SEARCH_CPT_CODES;
import static com.healogics.encode.constants.ControllerConstants.GET_LAST_APPLIED_FILTER;
import static com.healogics.encode.constants.ControllerConstants.ESCALATION_DETAILS;
import static com.healogics.encode.constants.ControllerConstants.VALIDATE_CHART;
import static com.healogics.encode.constants.ControllerConstants.NOTE_DETAIL;
import static com.healogics.encode.constants.ControllerConstants.GET_INSURANCE_DETAILS;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.NotesListRes;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.NotesDetailsRes;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.dto.CPTCodesResponse;
import com.healogics.encode.dto.CPTDataResponse;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.ChartValidationRes;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.EscalatedChartDetailsReq;
import com.healogics.encode.dto.EscalatedChartRes;
import com.healogics.encode.dto.EscalationDetailsRes;
import com.healogics.encode.dto.ICDCPTRequest;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.InsuranceDetailsReq;
import com.healogics.encode.dto.InsuranceDetailsRes;
import com.healogics.encode.dto.LastAppliedFilterRes;
import com.healogics.encode.dto.ICD10Response;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.RetrieveNotesListRes;
import com.healogics.encode.dto.SaveRecordReq;
import com.healogics.encode.dto.SaveRecordRes;
import com.healogics.encode.service.DashboardBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController 
public class DashboardController {
	
	private final Logger log = LoggerFactory.getLogger(DashboardController.class);

	private final DashboardBO dashboardBO;

	@Autowired
	public DashboardController(DashboardBO dashboardBO) {
		this.dashboardBO = dashboardBO;
	}
	
	@ApiOperation(value = "To save notes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savenotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveNotes(
			@ApiParam(name = "SaveNotesReq", value = "SaveNotesReq data", required = true)
			@RequestBody NotesReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NotesRes res = null;
		Map<String, Object> response = null;
		try {

			res = dashboardBO.saveNotes(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_NOTES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_NOTES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_NOTES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getcmcretrievenotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCMCRetrieveNote(
			@ApiParam(name = "CMCRetrieveNotes", value = "CMCRetrieveNotes data", required = true)
			@RequestBody NoteListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NotesListRes res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.getCMCRetrieveNote(req, req.getUserRole(), req.getIndex());
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						RETRIEVE_NOTES, formattedDate);
				response = CommonUtils.getResponseObject(
						RETRIEVE_NOTES, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, RETRIEVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						RETRIEVE_NOTES, formattedDate);
				response = CommonUtils.getResponseObject(
						RETRIEVE_NOTES, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						RETRIEVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					RETRIEVE_NOTES, formattedDate);
			response = CommonUtils.getResponseObject(
					RETRIEVE_NOTES, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, RETRIEVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getretrievenotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getRetrieveNote(
			@ApiParam(name = "RetrieveNotes", value = "RetrieveNotes data", required = true)
			@RequestBody NoteListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		RetrieveNotesListRes res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.getRetrieveNote(req, req.getUserRole(), req.getIndex());
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						RETRIEVE_NOTES, formattedDate);
				response = CommonUtils.getResponseObject(
						RETRIEVE_NOTES, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, RETRIEVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						RETRIEVE_NOTES, formattedDate);
				response = CommonUtils.getResponseObject(
						RETRIEVE_NOTES, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						RETRIEVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					RETRIEVE_NOTES, formattedDate);
			response = CommonUtils.getResponseObject(
					RETRIEVE_NOTES, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, RETRIEVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getnotebyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNoteDetailById(
			@ApiParam(name = "NoteListReq", value = "NoteListReq data", required = true)
			@RequestBody NoteListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NotesDetailsRes res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.getNoteByNoteId(req.getVisitId(), req.getNoteId());
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						NOTE_DETAIL, formattedDate);
				response = CommonUtils.getResponseObject(
						NOTE_DETAIL, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTE_DETAIL);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
				
			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("2")) {
				messageHeader = CommonUtils.getMessageHeader(
						NOTE_DETAIL, formattedDate);
				response = CommonUtils.getResponseObject(
						NOTE_DETAIL, "404", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTE_DETAIL);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.NOT_FOUND);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						NOTE_DETAIL, formattedDate);
				response = CommonUtils.getResponseObject(
						NOTE_DETAIL, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						NOTE_DETAIL);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					NOTE_DETAIL, formattedDate);
			response = CommonUtils.getResponseObject(
					NOTE_DETAIL, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, NOTE_DETAIL);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

	@ApiOperation(value = "To save record")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/saverecord", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveRecord(
			@ApiParam(name = "SaveRecordReq", value = "SaveRecordReq data", required = true)
			@RequestBody SaveRecordReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveRecordRes res = null;
		Map<String, Object> response = null;
		try {

			res = dashboardBO.saveRecord(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_RECORD,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_RECORD, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_RECORD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_RECORD,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_RECORD, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_RECORD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_RECORD,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_RECORD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_RECORD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get coder weakness reasons")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getweaknessreasons", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getWeaknessReasons() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes WeaknessReasonsRes = null;

		try {

			WeaknessReasonsRes = dashboardBO.getWeaknessReasons();
			if (WeaknessReasonsRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						CODER_WEAKNESS_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_WEAKNESS_REASONS, "200", "0", SUCCESS_DESC);

				json = WeaknessReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_WEAKNESS_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(CODER_WEAKNESS_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CODER_WEAKNESS_REASONS, "500", "556", "Invalid response");

				json = WeaknessReasonsRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_WEAKNESS_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_WEAKNESS_REASONS, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_WEAKNESS_REASONS, "556", "556", e.getMessage());

			json = WeaknessReasonsRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_WEAKNESS_REASONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	@ApiOperation(value = "To save ChartDetails")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savechartdetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveChartDetails(
			@ApiParam(name = "ChartDetailsReq", value = "ChartDetailsReq data", required = true)
			@RequestBody ChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveRecordRes res = null;
		Map<String, Object> response = null;
		try {
			log.info("Request::::: {}", req);
			res = dashboardBO.saveChartDetails(req);
 
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_CHART_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_CHART_DETAILS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_CHART_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				log.info("Response:::::::::::::: {}", json);
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_CHART_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_CHART_DETAILS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_CHART_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				log.info("Response:::::::::::::: {}", json);
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_CHART_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_CHART_DETAILS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_CHART_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get coder Deficiency List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getdeficiencylist", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getDeficiencyList() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes DeficiencyListRes = null;

		try {

			DeficiencyListRes = dashboardBO.getDeficiencyList();
			if (DeficiencyListRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						DEFICIENCY_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						DEFICIENCY_LIST, "200", "0", SUCCESS_DESC);

				json = DeficiencyListRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, DEFICIENCY_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(DEFICIENCY_LIST, formattedDate);
				response = CommonUtils.getResponseObject(DEFICIENCY_LIST, "500", "556", "Invalid response");

				json = DeficiencyListRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, DEFICIENCY_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					DEFICIENCY_LIST, formattedDate);
			response = CommonUtils.getResponseObject(
					DEFICIENCY_LIST, "556", "556", e.getMessage());

			json = DeficiencyListRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, DEFICIENCY_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get Escalate Reasons List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getescalatereasonslist", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getEscalateReasonsList() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes EscalateReasonsListRes = null;

		try {

			EscalateReasonsListRes = dashboardBO.getEscalateReasonsList();
			if (EscalateReasonsListRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						ESCALATE_REASONS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						ESCALATE_REASONS_LIST, "200", "0", SUCCESS_DESC);

				json = EscalateReasonsListRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, DEFICIENCY_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(ESCALATE_REASONS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(ESCALATE_REASONS_LIST, "500", "556", "Invalid response");

				json = EscalateReasonsListRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ESCALATE_REASONS_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ESCALATE_REASONS_LIST, formattedDate);
			response = CommonUtils.getResponseObject(
					ESCALATE_REASONS_LIST, "556", "556", e.getMessage());

			json = EscalateReasonsListRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ESCALATE_REASONS_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get Modifiers List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/getmodifierslist", headers = "Accept=application/json")
	public ResponseEntity<ReasonsRes> getModifiersList() {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Map<String, Object> response;
		ReasonsRes json = new ReasonsRes();
		ReasonsRes modifiersRes = null;

		try {

			modifiersRes = dashboardBO.getModifiersReasonsList();
			if (modifiersRes.getResponseCode().equals("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						CODER_MODIFIERS_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(
						CODER_MODIFIERS_REASONS, "200", "0", SUCCESS_DESC);

				json = modifiersRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_MODIFIERS_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(CODER_MODIFIERS_REASONS, formattedDate);
				response = CommonUtils.getResponseObject(CODER_MODIFIERS_REASONS, "500", "556", "Invalid response");

				json = modifiersRes;

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, CODER_MODIFIERS_REASONS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			log.error(String.format("Exception occurred: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					CODER_MODIFIERS_REASONS, formattedDate);
			response = CommonUtils.getResponseObject(
					CODER_MODIFIERS_REASONS, "556", "556", e.getMessage());

			json = modifiersRes;
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, CODER_MODIFIERS_REASONS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, e.getMessage());

			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To Get CPT Codes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getcptcodesbyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> seachCPTCodes(
			@ApiParam(name = "ChartDetailsReq", value = "ChartDetailsReq data", required = true)
			@RequestBody ChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CPTDataResponse res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.getCPTCodes(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(GET_CPT_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_CPT_CODES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_CPT_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_CPT_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_CPT_CODES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						GET_CPT_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_CPT_CODES,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_CPT_CODES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					GET_CPT_CODES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	   
	@ApiOperation(value = "To search ICD10Codes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/searchicd10codes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> seachICD10Text(
			@ApiParam(name = "ICDCPTRequest", value = "ICDCPTRequest data", required = true)
			@RequestBody ICDCPTRequest req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ICD10Response res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.searchICD10Codes(req.getSearchText(),
					req.getSearchType(), req.getOffset(), req.getCount());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SEARCH_ICD10_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_ICD10_CODES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, SEARCH_ICD10_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SEARCH_ICD10_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_ICD10_CODES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SEARCH_ICD10_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SEARCH_ICD10_CODES,
					formattedDate);
			response = CommonUtils.getResponseObject(SEARCH_ICD10_CODES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					SEARCH_ICD10_CODES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To search ICD10Codes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/searchcptcodes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> seachCPTCodes(
			@ApiParam(name = "ICDCPTRequest", value = "ICDCPTRequest data", required = true)
			@RequestBody ICDCPTRequest req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CPTCodesResponse res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.searchCPTCodes(req.getSearchText());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SEARCH_CPT_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_CPT_CODES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, SEARCH_CPT_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SEARCH_CPT_CODES,
						formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_CPT_CODES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SEARCH_CPT_CODES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SEARCH_CPT_CODES,
					formattedDate);
			response = CommonUtils.getResponseObject(SEARCH_CPT_CODES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					SEARCH_CPT_CODES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "To Search Excalated Chart")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/searchescalatedchart", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> searchEscalatedChart(
			@ApiParam(name = "CoderDashboardReq", value = "Coder DashboardReq data", required = true)
			@RequestBody EscalatedChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EscalatedChartRes res = null;
		Map<String, Object> response = null;
		boolean isFilter = false;
		try {
			res = dashboardBO.searchEscalatedChart(
					req,req.getIndex(),
					req.getTaskType(), req.getUsername(),
					req.getMasterToken(),formattedDate);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SEARCH_ESCALATED_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_ESCALATED_STATUS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, SEARCH_ESCALATED_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SEARCH_ESCALATED_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(SEARCH_ESCALATED_STATUS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SEARCH_ESCALATED_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SEARCH_ESCALATED_STATUS,
					formattedDate);
			response = CommonUtils.getResponseObject(SEARCH_ESCALATED_STATUS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					SEARCH_ESCALATED_STATUS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To Fetch Last Applied Dashboard Filter")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getuserpreference", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getUserPreference(
			@ApiParam(name = "userId", value = "userId data", required = true)
			@RequestBody DashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		LastAppliedFilterRes res = null;
		Map<String, Object> response = null;
		try {
			
			long userId = Long.parseLong(req.getUserId());

			if (req.getUserId() == null) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.GET_LAST_APPLIED_FILTER, statusCode,
						errorCode, statusDesc);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_LAST_APPLIED_FILTER);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);

			}

			res = dashboardBO.getLastAppliedFilter(userId);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {

				messageHeader = CommonUtils.getMessageHeader(
						GET_LAST_APPLIED_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(
						GET_LAST_APPLIED_FILTER, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_LAST_APPLIED_FILTER);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_LAST_APPLIED_FILTER, formattedDate);
				response = CommonUtils.getResponseObject(GET_LAST_APPLIED_FILTER, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.GET_LAST_APPLIED_FILTER);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(
					GET_LAST_APPLIED_FILTER, formattedDate);
			response = CommonUtils.getResponseObject(
					GET_LAST_APPLIED_FILTER, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.GET_LAST_APPLIED_FILTER);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/getescalationdetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getEscalationDetails(
			@ApiParam(name = "NoteListReq", value = "NoteListReq data", required = true)
			@RequestBody NoteListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		EscalationDetailsRes res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.getEscalationDetails(req.getVisitId());
			
			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						ESCALATION_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(
						ESCALATION_DETAILS, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ESCALATION_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ESCALATION_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(
						ESCALATION_DETAILS, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, 
						ESCALATION_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					ESCALATION_DETAILS, formattedDate);
			response = CommonUtils.getResponseObject(
					ESCALATION_DETAILS, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ESCALATION_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/validatechart", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> validateChart(
			@ApiParam(name = "ChartDetailsReq", value = "ChartDetailsReq data", required = true)
			@RequestBody ChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ChartValidationRes res = null;
		Map<String, Object> response = null;
		try {
			res = dashboardBO.validateChart(req);
			
			messageHeader = CommonUtils.getMessageHeader(
					VALIDATE_CHART, formattedDate);
			response = CommonUtils.getResponseObject(
					VALIDATE_CHART, "200", "0", SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, VALIDATE_CHART);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s ", excp));
			messageHeader = CommonUtils.getMessageHeader(
					VALIDATE_CHART, formattedDate);
			response = CommonUtils.getResponseObject(
					VALIDATE_CHART, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, VALIDATE_CHART);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get insuranceDetails")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getinsurancedetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getInsuranceDetails(
			@ApiParam(name = "InsuranceDetailsReq", value = "InsuranceDetailsReq data", required = true)
			@RequestBody IHealPatientLoadReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		InsuranceDetailsRes res = null;
		Map<String, Object> response = null;
		try {

			res = dashboardBO.getInsuranceDetails(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(GET_INSURANCE_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_INSURANCE_DETAILS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_INSURANCE_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(GET_INSURANCE_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_INSURANCE_DETAILS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_INSURANCE_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_INSURANCE_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_INSURANCE_DETAILS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_INSURANCE_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
