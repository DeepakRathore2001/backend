package com.healogics.encode.controller;

import static com.healogics.encode.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.encode.constants.ControllerConstants.CLICK_STREAM;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.ClickStreamReq;
import com.healogics.encode.dto.ClickStreamRes;
import com.healogics.encode.service.ClickStreamBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ClickStreamController {
	
	private final Logger log = LoggerFactory
			.getLogger(ClickStreamController.class);

	private final ClickStreamBO clickStreamBO;
	
	@Autowired
	public ClickStreamController(ClickStreamBO clickStreamBO) {
		this.clickStreamBO = clickStreamBO;
	}
	
	@ApiOperation(value = "Save ClickSream Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/saveclickstream", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveClickStream(
			@ApiParam(name = "ClickStreamReq", value = "ClickStreamReq data", required = true)
			@RequestBody ClickStreamReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ClickStreamRes res = null;
		Map<String, Object> response = null;
		try {

			res = clickStreamBO.saveClickStreamData(req);

			if (res != null
					&& res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils
						.getMessageHeader(CLICK_STREAM, formattedDate);
				response = CommonUtils.getResponseObject(CLICK_STREAM,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CLICK_STREAM);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils
						.getMessageHeader(CLICK_STREAM, formattedDate);
				response = CommonUtils.getResponseObject(CLICK_STREAM,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CLICK_STREAM);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(CLICK_STREAM,
					formattedDate);
			response = CommonUtils.getResponseObject(CLICK_STREAM,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CLICK_STREAM);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
