package com.healogics.encode.controller;

import java.util.HashMap;
import java.util.Map;

import static com.healogics.encode.constants.ControllerConstants.NOTIFICATION_LIST;
import static com.healogics.encode.constants.ControllerConstants.NOTIFICATION_DELETE;
import static com.healogics.encode.constants.ControllerConstants.NOTIFICATION_CREATION;
import static com.healogics.encode.constants.ControllerConstants.USER_NOTIFICATION_CREATION;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.encode.constants.ControllerConstants;
import com.healogics.encode.dto.DeleteNotificationReq;
import com.healogics.encode.dto.SystemNotificationListReq;
import com.healogics.encode.dto.SystemNotificationListRes;
import com.healogics.encode.dto.SystemNotificationWSAReq;
import com.healogics.encode.dto.SystemNotificationWSARes;
import com.healogics.encode.dto.UserNotificationReq;
import com.healogics.encode.dto.UserNotificationRes;
import com.healogics.encode.service.SystemNotificationBO;
import com.healogics.encode.util.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class SystemNotificationController {

	private final Logger log = LoggerFactory.getLogger(SystemNotificationController.class);

	private final SystemNotificationBO notificationBO;

	@Autowired
	public SystemNotificationController(SystemNotificationBO notificationBO) {
		this.notificationBO = notificationBO;
	}

	@ApiOperation(value = "Creates a new Notification")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/user/createnotification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> createNotification(
			@RequestBody SystemNotificationWSAReq systemNotificationReq) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		SystemNotificationWSARes systemNotRes = null;
		Map<String, Object> messageHeader;
		try {
			if (systemNotificationReq.getIntegrationKey().equals("WSAENC1$ntegration")) {

				systemNotRes = notificationBO.createNotifications(systemNotificationReq);

				messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_CREATION, formattedDate);
				response = CommonUtils.getResponseObject(NOTIFICATION_CREATION, ControllerConstants.SUCCESS_CODE, "0",
						ControllerConstants.SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, systemNotRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTIFICATION_CREATION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				log.info("Notification created: {}", systemNotificationReq);
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_CREATION, formattedDate);
				response = CommonUtils.getResponseObject(NOTIFICATION_CREATION, "500", "401",
						ControllerConstants.INVALID_CREDENTIALS);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, systemNotRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTIFICATION_CREATION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.UNAUTHORIZED);
			}

		} catch (Exception e) {
			log.error("Exception occured: ", e);
			messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_CREATION, formattedDate);
			response = CommonUtils.getResponseObject(NOTIFICATION_CREATION, "500", "505", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, systemNotRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, NOTIFICATION_CREATION);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

	@ApiOperation(value = "Get Notification List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/notificationlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSystemNotificationList(
			@RequestBody SystemNotificationListReq systemNotListReq) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		SystemNotificationListRes systemNotListRes = null;
		Map<String, Object> messageHeader;

		try {
			if (systemNotListReq.getUserId() == null && systemNotListReq.getUserId().isEmpty()) {

				messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_LIST, formattedDate);
				response = CommonUtils.getResponseObject(NOTIFICATION_LIST, "401", "404", "INVALID PARAMETERS");

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTIFICATION_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(headers, HttpStatus.BAD_REQUEST);
			}
			systemNotListRes = notificationBO.getSystemNotificationList(systemNotListReq);
			messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_LIST, formattedDate);
			response = CommonUtils.getResponseObject(NOTIFICATION_LIST, ControllerConstants.SUCCESS_CODE, "0",
					ControllerConstants.SUCCESS_DESC);
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, systemNotListRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, NOTIFICATION_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			log.info("Notification List: {}", systemNotListReq);
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {

			log.error("Exception occured: ", e);
			messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_LIST, formattedDate);
			response = CommonUtils.getResponseObject(NOTIFICATION_LIST, "500", "505", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, systemNotListRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, NOTIFICATION_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

	@ApiOperation(value = "Delete system notification")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/user/deletenotification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> deleteSystemNotification(@RequestBody DeleteNotificationReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		UserNotificationRes systemNotRes = null;
		Map<String, Object> messageHeader;

		try {
			
			if (req.getIntegrationKey().equals("WSAENC1$ntegration")) {
				systemNotRes = notificationBO.deleteSystemNotifications(req.getNotificationId());
				messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_DELETE, formattedDate);
				response = CommonUtils.getResponseObject(NOTIFICATION_DELETE, ControllerConstants.SUCCESS_CODE, "0",
						ControllerConstants.SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, systemNotRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTIFICATION_DELETE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			} else {
				messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_DELETE, formattedDate);
				response = CommonUtils.getResponseObject(NOTIFICATION_DELETE, "500", "401",
						ControllerConstants.INVALID_CREDENTIALS);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, systemNotRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, NOTIFICATION_DELETE);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.UNAUTHORIZED);
			}

		} catch (Exception e) {
			log.error("Exception occured: {}", e);
			messageHeader = CommonUtils.getMessageHeader(NOTIFICATION_DELETE, formattedDate);
			response = CommonUtils.getResponseObject(NOTIFICATION_DELETE, "500", "505", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, systemNotRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, NOTIFICATION_DELETE);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}
	
	@ApiOperation(value = "Save a new User Notification")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/saveusernotification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> createUserDisableNotification(
			@RequestBody UserNotificationReq userNotificationReq) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		UserNotificationRes userNotRes = null;
		Map<String, Object> messageHeader;
		try {

			if (userNotificationReq.getUserId().isEmpty()
					&& userNotificationReq.getUserId() == null
					&& userNotificationReq.getNotificationId() == null
					&& userNotificationReq.getNotificationId().isEmpty()) {

				messageHeader = CommonUtils.getMessageHeader(
						USER_NOTIFICATION_CREATION, formattedDate);
				response = CommonUtils.getResponseObject(
						USER_NOTIFICATION_CREATION, "401", "404",
						"INVALID PARAMETERS");

				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, USER_NOTIFICATION_CREATION);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(headers, HttpStatus.BAD_REQUEST);

			}
			userNotRes = notificationBO.saveUserNotifications(userNotificationReq);
			messageHeader = CommonUtils.getMessageHeader(
					USER_NOTIFICATION_CREATION, formattedDate);
			response = CommonUtils.getResponseObject(
					USER_NOTIFICATION_CREATION, ControllerConstants.SUCCESS_CODE, "0",
					ControllerConstants.SUCCESS_DESC);
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, userNotRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, USER_NOTIFICATION_CREATION);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			log.info("User Notification created: ", userNotificationReq);
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception occured: ", e);
			messageHeader = CommonUtils.getMessageHeader(USER_NOTIFICATION_CREATION, formattedDate);
			response = CommonUtils.getResponseObject(USER_NOTIFICATION_CREATION, "500", "505", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, userNotRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, USER_NOTIFICATION_CREATION);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

}