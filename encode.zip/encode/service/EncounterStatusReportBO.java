package com.healogics.encode.service;

import com.healogics.encode.dto.EncounterStatusReportGenerateRes;
import com.healogics.encode.dto.EncounterStatusReportReq;
import com.healogics.encode.dto.EncouterStatusReportRes;

public interface EncounterStatusReportBO {

	EncouterStatusReportRes getEncounterStatusReportdata();

	EncounterStatusReportGenerateRes generateEncounterReport(EncounterStatusReportReq req);

}
