package com.healogics.encode.service;

import com.healogics.encode.dto.BuildDetailsResponse;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.SaveBuildDetailsReq;

public interface AboutPopupBO {

	public BuildDetailsResponse getBuildDetails();

	public NotesRes saveBuildDetails(SaveBuildDetailsReq req);

}
