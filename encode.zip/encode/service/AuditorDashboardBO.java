package com.healogics.encode.service;

import java.util.List;

import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AllInAuditChartsRes;
import com.healogics.encode.dto.AuditNotesListRes;
import com.healogics.encode.dto.AuditorCollapsibleSectionReq;
import com.healogics.encode.dto.AuditorCollapsibleSectionRes;
import com.healogics.encode.dto.AuditorDashboardFilterRes;
import com.healogics.encode.dto.AuditorDashboardReq;
import com.healogics.encode.dto.AuditorDashboardRes;
import com.healogics.encode.dto.AuditorExcelRes;
import com.healogics.encode.dto.AuditorReasonRes;
import com.healogics.encode.dto.ChartByStatusReq;
import com.healogics.encode.dto.ChartByStatusRes;
import com.healogics.encode.dto.ChartStatusUpdateByFilterReq;
import com.healogics.encode.dto.InsuranceCarrierRes;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.ReleaseByFilterChartReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.dto.SaveAuditDetailsRes;
import com.healogics.encode.dto.UpdateChartstatusReq;
import com.healogics.encode.dto.UpdateChartstatusRes;
import com.healogics.encode.dto.addOrRemovePinnedFilterReq;
import com.healogics.encode.entity.CollapsibleFilterRes;

public interface AuditorDashboardBO {

	InsuranceCarrierRes getInsuranceCarrier();

	public AuditorReasonRes getAuditorReasons();
	
	SaveAuditDetailsRes saveAuditDetails(SaveAuditDetailsReq req);

	AuditorDashboardRes getAuditorData(boolean isFilter, AuditorDashboardReq auditorDashboardReq, int index);
	
	AuditorCollapsibleSectionRes getCollapsibleSectionDetails(int filterId, AuditorCollapsibleSectionReq req);

	AuditorDashboardFilterRes getAuditorFilterOptions(AuditorDashboardReq req);

	UpdateChartstatusRes updateChartStatus(UpdateChartstatusReq req);

	AuditorExcelRes getAllAuditorData(boolean isFilter, AuditorDashboardReq req, int index);

    public AuditNotesListRes getAuditNotes(NoteListReq req, String userRole);

	CollapsibleFilterRes getCollapsibleFilterOption(AuditorCollapsibleSectionReq req, int filterId);

	AuditorCollapsibleSectionRes getCollapsibleFilteredData(int filterId, AuditorCollapsibleSectionReq req, boolean isfilter, int index, boolean isApplyPagination);

	AllInAuditChartsRes getAllInAuditCharts();

	ChartByStatusRes getChartByStatus(ChartByStatusReq req);
	
	ReasonsRes getNurseDispositionList();

	AuditorDashboardRes getAuditorReleaseData(boolean isFilter, AuditorDashboardReq auditorDashboardReq, int index);

	APIResponse releaseByFilterChart(ReleaseByFilterChartReq req);

	APIResponse addOrRemovePinnedFilter(addOrRemovePinnedFilterReq req);

}

