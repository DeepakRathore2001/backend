package com.healogics.encode.service;

import com.healogics.encode.dto.AuditFilterDetails;
import com.healogics.encode.dto.AuditorDrillDownReq;
import com.healogics.encode.dto.AuditorDrillDownRes;
import com.healogics.encode.dto.CodingTeamRes;
import com.healogics.encode.dto.DeleteFilterReq;
import com.healogics.encode.dto.CodersRes;
import com.healogics.encode.dto.EditFilterNameRes;
import com.healogics.encode.dto.FilterLogicReq;
import com.healogics.encode.dto.FilterLogicRes;
import com.healogics.encode.dto.SaveAuditFilterReq;
import com.healogics.encode.dto.SaveAuditorFilterRes;
import com.healogics.encode.dto.ViewAuditorFilterRes;

public interface AuditorFilterBO {
	public SaveAuditorFilterRes saveAuditorFilter(AuditFilterDetails filter);

	public ViewAuditorFilterRes getAuditorFilters(int filterId);

	public CodingTeamRes getCodingTeam();
	
	public CodersRes getCoders();
	
	public SaveAuditorFilterRes saveFilter(SaveAuditFilterReq filter);

	public EditFilterNameRes updateFilters(SaveAuditFilterReq filterReq);

	public AuditorDrillDownRes getDrillDownData(AuditorDrillDownReq auditorDrillDownReq);

	public FilterLogicRes applyFilterLogic(FilterLogicReq req);

	public EditFilterNameRes editFilter(AuditFilterDetails filterReq);

	public EditFilterNameRes deleteFilter(DeleteFilterReq filterReq);


}
