package com.healogics.encode.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.AuditorFiltetDAO;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AuditFilterDetails;
import com.healogics.encode.dto.AuditorDrillDownReq;
import com.healogics.encode.dto.AuditorDrillDownRes;
import com.healogics.encode.dto.CPTObj;
import com.healogics.encode.dto.CodingTeamRes;
import com.healogics.encode.dto.DeleteFilterReq;
import com.healogics.encode.dto.Coder;
import com.healogics.encode.dto.CodersRes;
import com.healogics.encode.dto.EditFilterNameRes;
import com.healogics.encode.dto.FilterLogicReq;
import com.healogics.encode.dto.FilterLogicRes;
import com.healogics.encode.dto.SaveAuditFilterReq;
import com.healogics.encode.dto.SaveAuditorFilterRes;
import com.healogics.encode.dto.ViewAuditorFilterRes;
import com.healogics.encode.dto.VisitDetails;
import com.healogics.encode.entity.AuditFiltersSource;
import com.healogics.encode.entity.Filters;
import com.healogics.encode.service.AuditorFilterBO;

@Service
public class AuditorFilterBOImpl implements AuditorFilterBO {
	private final Logger log = LoggerFactory.getLogger(AuditorFilterBOImpl.class);

	private final AuditorFiltetDAO filterDAO;

	@Autowired
	public AuditorFilterBOImpl(AuditorFiltetDAO filterDAO) {
		this.filterDAO = filterDAO;
	}

	@Override
	public SaveAuditorFilterRes saveAuditorFilter(AuditFilterDetails filter) {
		SaveAuditorFilterRes res = new SaveAuditorFilterRes();
		String reqId = UUID.randomUUID().toString();
		log.info("Received saveAuditorFilter request with id: " + reqId);

		res.setRequestId(UUID.randomUUID().toString());

		try {
			res = filterDAO.saveAuditorFilter(filter);

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}
	
	@Override
	public SaveAuditorFilterRes saveFilter(SaveAuditFilterReq filter) {
		SaveAuditorFilterRes res = new SaveAuditorFilterRes();
		String reqId = UUID.randomUUID().toString();
		log.info("Received saveAuditorFilter request with id: " + reqId);

		res.setRequestId(UUID.randomUUID().toString());

		try {
			filterDAO.saveAuditFilter(filter);
			res.setResponseCode("0");
			res.setResponseMessage("Success");

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}

	@Override
	public ViewAuditorFilterRes getAuditorFilters(int filterId) {
	    ViewAuditorFilterRes res = new ViewAuditorFilterRes();
	    String reqId = UUID.randomUUID().toString();
	    log.info("Received getAuditorFilters request with id: " + reqId);
	    res.setRequestId(reqId);
		ObjectMapper objectMapper = new ObjectMapper();
	    try {
	        Filters filter = filterDAO.getAuditFilters(filterId); 
	 
	        if (filter != null) {
	            AuditFilterDetails aFilter = new AuditFilterDetails();
	            aFilter.setFilterId(filter.getFilterId());
	            aFilter.setFilterName(filter.getFilterName());
	            aFilter.setActive(filter.getActive());
	           // aFilter.setCodingTeam(filter.getTeam());
	            String codingTeamJson = filter.getCodingTeam();
	            if (codingTeamJson != null) {
	                List<String> codingTeamList = objectMapper.readValue(codingTeamJson,
	                        objectMapper.getTypeFactory().constructCollectionType(List.class, String.class));
	                aFilter.setCodingTeam(codingTeamList);
	            } else {
	                aFilter.setCodingTeam(Collections.emptyList());
	            }
	            aFilter.setCodersFullName(filter.getCoderFullName());
	            aFilter.setCoders(filter.getCoders());
	            aFilter.setCount(filter.getCount());
	            aFilter.setCptCodes(filter.getCptCodes());
	            aFilter.setDowncoded(filter.getDowncoded());
	            aFilter.setFacilities(filter.getFacilities());
	            aFilter.setIcdCodes(filter.getIcdCodes());
	            aFilter.setInsurance(filter.getInsurance());
	            aFilter.setModifiers(filter.getModifiers());
	            aFilter.setPercentage(filter.getPercentage());
	            aFilter.setProviders(filter.getProviders());
	            aFilter.setUnits(filter.getUnits());
	            aFilter.setCreatedUserFullName(filter.getCreatedUser());
	            aFilter.setCreatedUserName(filter.getCreatedUsername());
	            aFilter.setCreatedTimestamp(filter.getCreatedTimestamp());
	            aFilter.setCodersId(filter.getCoderId());
	            aFilter.setProvidersId(filter.getProviderId());
	            aFilter.setFacilitiesId(filter.getFacilityId());
	            aFilter.setCptName(filter.getCptName());
	            aFilter.setModifierName(filter.getModifierName());
	            
	            String cptObject = filter.getCptObject();
	            if (cptObject != null) {
	                List<CPTObj> cptData = objectMapper.readValue(cptObject,
	                        objectMapper.getTypeFactory().constructCollectionType(List.class, CPTObj.class));
	                aFilter.setCptData(cptData);
	            } else {
	                aFilter.setCptData(Collections.emptyList()); 
	            }
	            
	            if ("Nurse".equals(filter.getFilterAudience())) {
	                aFilter.setNurseFilter(1);
	            }
	             
	            res.setFilterData(aFilter);
	            res.setResponseCode("0");
	            res.setResponseMessage("Success");
	        } else {
	            res.setResponseCode("1");
	            res.setResponseMessage("Filter not found");
	        }
	 
	    } catch (Exception e) {
	        res.setResponseCode("1");
	        res.setResponseMessage("Failed");
	        log.error("Exception occurred while fetching auditor filters: " + e.getMessage(), e);
	    }
	    return res;
	}

	@Override
	public CodingTeamRes getCodingTeam() {
		CodingTeamRes res = new CodingTeamRes();
		try {
			List<String> codingTeam = filterDAO.getCodingTeam();
			res.setCodingTeam(codingTeam);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while fetching auditor search values : {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public CodersRes getCoders() {
		CodersRes res = new CodersRes();
		try {
			List<Coder> coders = filterDAO.getCoders();
			res.setCoders(coders);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while fetching auditor search values : {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public EditFilterNameRes updateFilters(SaveAuditFilterReq filterReq) {
		EditFilterNameRes res = new EditFilterNameRes();
		try {
			log.debug("Inside updateFilters method");
			res = filterDAO.updateFilters(filterReq);

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}
	
	@Override
	public EditFilterNameRes editFilter(AuditFilterDetails filterReq){
		EditFilterNameRes res = new EditFilterNameRes();
		try {
			log.debug("Inside updateFilters method");
			res = filterDAO.editFilter(filterReq);

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}
	
	@Override
	public EditFilterNameRes deleteFilter(DeleteFilterReq filterReq){
		EditFilterNameRes res = new EditFilterNameRes();
		try {
			log.debug("filter has been deleted");
			res = filterDAO.deleteFilter(filterReq);

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}
	
	@Override
	public AuditorDrillDownRes getDrillDownData(AuditorDrillDownReq auditorDrillDownReq) {
		AuditorDrillDownRes res = new AuditorDrillDownRes();
		try {
			res = filterDAO.getDrillDownData(auditorDrillDownReq);

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}
	
	@Override
	public FilterLogicRes applyFilterLogic(FilterLogicReq req) {
	    FilterLogicRes res = new FilterLogicRes();
	    Map<Integer, List<VisitDetails>> filterResults = new HashMap<>(); 
	    Set<Long> usedVisitIds = new HashSet<>(); 
	    try {
	        List<Filters> filters = filterDAO.getAllFilters(req);
	        for (Filters filter : filters) {
	        	log.debug(" count : {} ", filter.getCount());
	        	log.debug(" percentage : {} ", filter.getPercentage());
	            if (filter.getCount() < 0 || filter.getPercentage() < 0) {
	                continue;
	            }
	            
	            boolean isLimitAvailable = filterDAO.checkFilterLimit(filter);
	            log.info("Filter limit check for filter ID {}: {}", filter.getFilterId(), isLimitAvailable);
	            
	           
	            if (!isLimitAvailable) {
	                log.info("Filter {} has reached its daily limit.", filter.getFilterId());
	                continue; // Skip the filter if daily limit reached
	            }
	            
	            // Apply filter logic for each filter, excluding already assigned visit IDs
	            List<Long> visitIds = filterDAO.getFilteredVisitIdsExcludingAssigned(filter, usedVisitIds);
	            // Filter out any visitIds that have already been assigned to a previous filter
	            List<Long> uniqueVisitIds = visitIds.stream()
	                                                .filter(id -> !usedVisitIds.contains(id)) // Check for unassigned IDs
	                                                .collect(Collectors.toList());
	 
	            // Fetch visit details from Dashboard table
	            List<VisitDetails> visitDetailsList = filterDAO.fetchVisitDetails(uniqueVisitIds, filter.getFilterId(), filter.getTeam(),filter.getUnits());
	 
	            // Store the result for this filterId
	            filterResults.put(filter.getFilterId(), visitDetailsList);
	 
	            // Add these visit IDs to the used set to prevent them from being assigned again
	            usedVisitIds.addAll(uniqueVisitIds);
	            
	            log.info("uniqueVisitIds : {}",uniqueVisitIds.size());
	            
	            // After processing, update the filter's current count in the filter limit table
	            filterDAO.updateFilterLimit(filter, uniqueVisitIds.size());
	        }
	 
	        res.setFilteredData(filterResults); 
	        res.setResponseCode("0");
	        res.setResponseMessage("Success");
	    } catch (Exception e) {
	        res.setResponseCode("1");
	        res.setResponseMessage("Failed: " + e.getMessage());
	    }
	    return res;
	}
	



}
