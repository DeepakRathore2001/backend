package com.healogics.encode.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.encode.dao.AppNotificationDAO;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AppNotificationCountRes;
import com.healogics.encode.dto.AppNotificationListRes;
import com.healogics.encode.dto.AppNotificationsReq;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.EncodeAppNotifications;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.entity.AppNotification;
import com.healogics.encode.entity.UserPreference;
import com.healogics.encode.service.AppNotificationBO;
import com.healogics.encode.service.LoginBO;
import com.healogics.encode.constants.BOConstants;
 
@Service
public class AppNotificationBOImpl implements AppNotificationBO{

	private final Logger log = LoggerFactory.getLogger(AboutPopupBOImpl.class);
	
	private final AppNotificationDAO appNotificationDAO;
	
	private final LoginBO loginBO;

	@Autowired
	public AppNotificationBOImpl(AppNotificationDAO appNotificationDAO, LoginBO loginBO) {
		this.appNotificationDAO = appNotificationDAO;
		this.loginBO = loginBO;
	}
	
	@Override
	public Boolean saveAppNotifications(NotesReq req, int noteId) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveNoteNotifications(req, noteId);
		} catch (Exception e) {
			log.error("Exception occured while Saving Note App Notification :  {}",
					e.getMessage());
		}
		return status;
	}

	@Override
	public Boolean saveEscalateAppNotifications(ChartDetailsReq req) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveEscalateNoteNotifications(req);
		} catch (Exception e) {
			log.error("Exception occured while Saving Escalated Note App Notification :  {}",
					e.getMessage());
		}
		return status;
	}
	
	@Override
	public Boolean saveWeaknessAppNotifications(ChartDetailsReq req) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveWeaknessAppNotifications(req);
		} catch (Exception e) {
			log.error("Exception occured while Saving Weakness Note App Notification :  {}",
					e.getMessage());
		}
		return status;
	}
	
	@Override
	public APIResponse updateNotifications(AppNotificationsReq req) {
		APIResponse res = new APIResponse();
		try {
			Long count = appNotificationDAO.updateNotifications(req);

			if (count != null) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while updating App Notification:  {}"
					, e.getMessage());
		}
		return res;
	}

	@Override
	public AppNotificationListRes getAppNotifications(AppNotificationsReq req) {
		AppNotificationListRes res = new AppNotificationListRes();
		List<EncodeAppNotifications> encodeAppNotifications = new ArrayList<>();

		try {
			UserPreference userPreference = loginBO.getUserPreference(req.getUserId());
			
			Timestamp clearNotificationTimestamp = null;
			if (userPreference != null) {
				clearNotificationTimestamp = userPreference.getClearNotificationTimestamp();
			}

			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd");
			Calendar c1 = Calendar.getInstance();
			String currentDate = df.format(date);
			log.info("currentDate :  {}", currentDate);
			
			// now add 30 day in Calendar instance
			c1.add(Calendar.DAY_OF_YEAR, -30);
			df = new SimpleDateFormat("yyyy-MM-dd");
			Date resultDate = c1.getTime();
			String last30DaysDate = df.format(resultDate);
			log.info("last30DaysDate :  {}", last30DaysDate);
			
			List<AppNotification> appNotifications = appNotificationDAO
					.getAppNotification(Long.valueOf(req.getUserId()),
							clearNotificationTimestamp, last30DaysDate);

			if (appNotifications != null) {
				for (AppNotification appNotification : appNotifications) {
					EncodeAppNotifications encApp = new EncodeAppNotifications();
					encApp.setNotificationId(appNotification.getNotificationId());
					encApp.setUserId(appNotification.getUserId());
					encApp.setUserName(appNotification.getUsername());
					encApp.setReadFlag(appNotification.getReadFlag());
					encApp.setNotificationDescription(appNotification.getNotificationDescription());
					encApp.setNotificationTitle(appNotification.getNotificationTitle());
					encApp.setHyperlink(appNotification.getHyperlink());
					encApp.setCreatedTimestamp(appNotification.getCreatedTimestamp());
					encApp.setLastUpdatedTimestamp(appNotification.getLastUpdatedTimestamp());
					encApp.setUserFullname(appNotification.getUserFullname());
					encApp.setCreatorUserId(appNotification.getCreatorUserId());
					encApp.setCreatorUsername(appNotification.getCreatorUsername());
					encApp.setCreatorUserFullname(appNotification.getCreatorUserFullname());
					UserPreference userPref = loginBO.getUserPreference(
							appNotification.getUserId() + "");
					if (userPref != null && userPref.getAvatarColor() != null && !userPref.getAvatarColor().isEmpty()) {
						encApp.setUserColorCodes(userPref.getAvatarColor());
					} else {
						encApp.setUserColorCodes("");
					}

					UserPreference userPrefere = loginBO.getUserPreference(
							appNotification.getCreatorUserId() + "");
					if (userPrefere != null && userPrefere.getAvatarColor() != null && !userPrefere.getAvatarColor().isEmpty()) {
						encApp.setCreatorColorCodes(userPrefere.getAvatarColor());
					} else {
						encApp.setCreatorColorCodes("");
					}

					encodeAppNotifications.add(encApp);
				}
			}
			res.setAppNotifications(encodeAppNotifications);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching App Notification:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setAppNotifications(encodeAppNotifications);
		}
		return res;
	}
	
	@Override
	public AppNotificationCountRes isNotificationExists(String userId) {
		AppNotificationCountRes res = new AppNotificationCountRes();
		try {
			Long notificationCount = appNotificationDAO.getNotificationCount(
					Long.valueOf(userId));

			log.debug("Notifications count:   {}", notificationCount);

			if (notificationCount != null && notificationCount > 0) {
				res.setNotificationExists(true);
			} else {
				res.setNotificationExists(false);
			}
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			log.error("Exception occured while fetching App Notification Count: {}",
					e.getMessage());
		}
		return res;
	}
	
	@Override
	public Boolean saveWeaknessAppNotificationsAuditor(SaveAuditDetailsReq req) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveWeaknessAppNotificationsAuditor(req);
		} catch (Exception e) {
			log.error("Exception occured while Saving Weakness Note App Notification :  {}",
					e.getMessage());
		}
		return status;
	}
}