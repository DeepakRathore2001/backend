package com.healogics.encode.service.impl;

import static com.healogics.encode.constants.DAOConstants.ERRORCODE;
import static com.healogics.encode.constants.DAOConstants.ERRORMESSAGE;
import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;
import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE_DOUBLE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.CMCDashboardDAO;
import com.healogics.encode.dto.CMCDashboardRes;
import com.healogics.encode.dto.CMCData;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.FilterOptionsRes;
import com.healogics.encode.dto.IHealProviderListReq;
import com.healogics.encode.dto.IHealProviderListRes;
import com.healogics.encode.dto.IHealProviderObject;
import com.healogics.encode.dto.IHealUser;
import com.healogics.encode.dto.IHealUserFacilityListGetRes;
import com.healogics.encode.dto.IhealFacility;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ProviderListRes;
import com.healogics.encode.dto.ProviderObj;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.UserFacilities;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.service.CMCDashboardBO;

@Service
public class CMCDashboardBOImpl implements CMCDashboardBO {
	private final Logger log = LoggerFactory
			.getLogger(CMCDashboardBOImpl.class);

	private final Environment env;
	private final RestTemplate restTemplate;
	private final CMCDashboardDAO dashboardDAO;

	@Autowired
	public CMCDashboardBOImpl(Environment env, RestTemplate restTemplate,
			CMCDashboardDAO dashboardDAO) {
		this.dashboardDAO = dashboardDAO;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	@Override
	public CMCDashboardRes getCMCData(boolean isFilter, DashboardReq req, int index, String taskType, String assignee,
			String masterToken, boolean isApplyPagination) {
		CMCDashboardRes cmcDashboardRes = new CMCDashboardRes();
		List<CMCData> cmcDataList = new ArrayList<>();

		log.debug("index: {}", index);
		List<Dashboard> cmcDashboard = new ArrayList<>();
		List<String> bbcList = new ArrayList<>();
		List<String> FacilityIdList = new ArrayList<>();
		try {
			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
			/*	UserFacilityRes userFacilityRes = dashboardDAO.getuserFacilities(req.getUserId());
				
				if (userFacilityRes != null 
						&& userFacilityRes.getResponseCode() != null
						&& userFacilityRes.getResponseCode().equalsIgnoreCase("0")) {
					
					if (userFacilityRes.getFacilities() != null 
							&& userFacilityRes.getFacilities().size() > 0) {
						
						for (UserFacilities fac : userFacilityRes.getFacilities()) {
							
							String facilityBluebookId = fac.getFacilityBluebookId();
							
							if (facilityBluebookId != null && !facilityBluebookId.isEmpty()) {
								bbcList.add(facilityBluebookId);
							}
						}
					}
				}
			}*/
				String facilityIdString = dashboardDAO.getUserBBCList(req.getUserId());
				//if(bbcString != null && !bbcString.isEmpty()) {
					//bbcList = Arrays.asList(bbcString.split(","));
				//}
				if(facilityIdString != null && !facilityIdString.isEmpty()) {
					FacilityIdList = Arrays.asList(facilityIdString.split(","));
				}
			}

			log.debug("FacilityIdList.........." + FacilityIdList);

			//log.debug("bbcList.........." + bbcList);

			Long totalCount = 0L;
			boolean isExhausted = false;
			if (req.getTaskType().equalsIgnoreCase("MY")) {
				// Saving Filter List
				try {
					dashboardDAO.saveUserPreferences(req.getUserId(), req);
				} catch (Exception e) {
					log.error("Exception occured while saving filters : {}", e.getMessage());
					throw new EncodeExceptionHandler(e.getMessage());
				}
			}

			if (isFilter) {

				Map<String, Object> filterList = new HashMap<>();

				filterList = dashboardDAO.getFilteredCMCList(req, index, taskType, assignee, bbcList,
						isApplyPagination,FacilityIdList );
				totalCount = Long.valueOf((Integer) filterList.get("Count"));

				cmcDashboard = (List<Dashboard>) filterList.get("data");

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					cmcDashboardRes.setNextIndex(0);
				} else {
					cmcDashboardRes.setNextIndex(index + PAGE_SIZE);
				}

			} else {
				totalCount = dashboardDAO.getTotalCount(index, taskType, assignee, req, bbcList,FacilityIdList);
				cmcDashboard = dashboardDAO.getAllCMCRecords(req, index, taskType, assignee, bbcList,
						isApplyPagination,FacilityIdList);

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					cmcDashboardRes.setNextIndex(0);
				} else {
					cmcDashboardRes.setNextIndex(index + PAGE_SIZE);
				}

			}
			
			 EncodeUsers userEntity = dashboardDAO.findByUserId(Long.valueOf(req.getUserId()));
			   Set<String> allowedFacilityIds = new HashSet<>();
			    
			   if (userEntity != null && userEntity.getFacilityIdList() != null) {
			       allowedFacilityIds = Arrays.stream(userEntity.getFacilityIdList().split(","))
			                                  .map(String::trim)
			                                  .collect(Collectors.toSet());
			   }

	            log.info("allowedFacilityIds : {} ", allowedFacilityIds);

			if (cmcDashboard != null) {
				// SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd
				// HH:mm:ss");

				for (Dashboard cmcRecord : cmcDashboard) {
					CMCData cmc = new CMCData();
					
					boolean isFacilityMatched = allowedFacilityIds.contains(String.valueOf(cmcRecord.getFacilityId()));
					log.info("isFacilityMatched : {} ", isFacilityMatched);
					log.info("facilityId : {} ", cmcRecord.getFacilityId());

					cmc.setBbc(cmcRecord.getSnfLocationBBC());	
					cmc.setVisitId(cmcRecord.getVisitId());
				 
				    if (!isFacilityMatched) {
				        // All other fields set to null
				    	cmcDataList.add(cmc);
				        continue;
				    }

//					cmc.setVisitId(cmcRecord.getVisitId());
					cmc.setFacilityId(cmcRecord.getFacilityId());
					cmc.setFacilityName(cmcRecord.getFacilityAlias());
//					cmc.setBbc(cmcRecord.getSnfLocationBBC());
					cmc.setPatientId(cmcRecord.getPatientId());
					cmc.setPatientName(cmcRecord.getPatientName());
					cmc.setReceivedDate(cmcRecord.getReceivedDate());
					cmc.setInterfaceDate(cmcRecord.getReceivedDate());
					cmc.setDashboardName(cmcRecord.getLastStatusChangeRole());

					if (cmcRecord.getProviderName() == null || cmcRecord.getProviderName().isEmpty()) {
						cmc.setProviderName("");
					} else {
						cmc.setProviderName(cmcRecord.getProviderName());
					}
					cmc.setDateOfService(cmcRecord.getDateOfService());
					if (cmcRecord.getMedicalRecordNumber() == null || cmcRecord.getMedicalRecordNumber().isEmpty()) {
						cmc.setMedicalRecordNumber("");
					} else {
						cmc.setMedicalRecordNumber(cmcRecord.getMedicalRecordNumber());
					}
					if (cmcRecord.getEncounterType() == null || cmcRecord.getEncounterType().isEmpty()) {
						cmc.setEncounterType("");
					} else {
						cmc.setEncounterType(cmcRecord.getEncounterType());
					}
					if (cmcRecord.getAssigneeUsername() == null || cmcRecord.getAssigneeUsername().isEmpty()) {
						cmc.setAssigneeUsername("");
					} else {
						cmc.setAssigneeUsername(cmcRecord.getAssigneeUsername());
					}
					Long assignUserId = 0L;
					if (cmcRecord.getAssigneeUserId() == null) {
						cmc.setAssigneeUserId((Long) assignUserId);

					} else {
						cmc.setAssigneeUserId(cmcRecord.getAssigneeUserId());
					}

					if (cmcRecord.getAssigneeUserFullname() == null || cmcRecord.getAssigneeUserFullname().isEmpty()) {
						cmc.setAssigneeUserFullname("");
					} else {
						cmc.setAssigneeUserFullname(cmcRecord.getAssigneeUserFullname());
					}

					cmc.setStatus(cmcRecord.getStatus());
					if (cmcRecord.getCmcNotes() == null || cmcRecord.getCmcNotes().isEmpty()) {
						cmc.setCmcNotes("");
					} else {
						cmc.setCmcNotes(cmcRecord.getCmcNotes());
					}
					cmc.setAccountNumber(cmcRecord.getAccountNumber());
					cmc.setAge("");

					if (cmcRecord.getPrimaryInsurance() == null || cmcRecord.getPrimaryInsurance().isEmpty()) {
						cmc.setInsurance("");
					} else {
						cmc.setInsurance(cmcRecord.getPrimaryInsurance());
					}
					if (cmcRecord.getGender() == null || cmcRecord.getGender().isEmpty()) {
						cmc.setInsurance("");
					} else {
						cmc.setSex(cmcRecord.getGender());
					}
					if (cmcRecord.getIhealConfig() == null || cmcRecord.getIhealConfig().isEmpty()) {
						cmc.setIhealConfig("");
					} else {
						cmc.setIhealConfig(cmcRecord.getIhealConfig());
					}
					String date = "";
					if (cmcRecord.getPatientDOB() == null) {
						// January 1, 1970, GMT Default date
						cmc.setPatientDOB(new Date(0));
					} else {
						cmc.setPatientDOB(cmcRecord.getPatientDOB());
					}
					cmc.setServiceLine(cmcRecord.getServiceLine());
					cmc.setStatusChangeTimestamp(cmcRecord.getStatusChangeTimestamp());

					cmcDataList.add(cmc);
				}

				cmcDashboardRes.setCurrentIndex(index);
				cmcDashboardRes.setTotalCount(totalCount);
				cmcDashboardRes.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				cmcDashboardRes.setExhausted(isExhausted);

			} else {
				cmcDashboard = null;
			}
			log.debug("Next index: {}", (index + PAGE_SIZE));

			cmcDashboardRes.setResponseCode("0");
			cmcDashboardRes.setResponseMessage(BOConstants.SUCCESS);
			cmcDashboardRes.setCmcData(cmcDataList);

		} catch (Exception e) {
			log.error("Exception occured while fetching CMC Data:  {}", e.getMessage());
			cmcDashboardRes.setResponseCode("1");
			cmcDashboardRes.setResponseMessage(BOConstants.FAILED);
			cmcDashboardRes.setCmcData(cmcDataList);
			cmcDashboardRes.setNextIndex(index);
			cmcDashboardRes.setCurrentIndex(index);
			cmcDashboardRes.setTotalCount(0L);
			cmcDashboardRes.setTotalPage(0);
			cmcDashboardRes.setExhausted(false);
		}

		return cmcDashboardRes;
	}

	@Override
	public CMCDashboardRes getAllCMCData(boolean isFilter, DashboardReq req,
			int index, String taskType, String assignee, boolean isApplyPagination) {
		CMCDashboardRes cmcDashboardRes = new CMCDashboardRes();
		List<CMCData> cmcDataList = new ArrayList<>();

		List<Dashboard> cmcDashboard = new ArrayList<>();
		try {
			Long totalCount = 0L;
			List<String> bbcs = new ArrayList<>();
			List<String> FacilityIdList = new ArrayList<>();
			
			if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				/*UserFacilityRes userFacilityRes = dashboardDAO.getuserFacilities(req.getUserId());
				
				if (userFacilityRes != null 
						&& userFacilityRes.getResponseCode() != null
						&& userFacilityRes.getResponseCode().equalsIgnoreCase("0")) {
					
					if (userFacilityRes.getFacilities() != null 
							&& userFacilityRes.getFacilities().size() > 0) {
						
						for (UserFacilities fac : userFacilityRes.getFacilities()) {
							
							String facilityBluebookId = fac.getFacilityBluebookId();
							
							if (facilityBluebookId != null && !facilityBluebookId.isEmpty()) {
								bbcs.add(facilityBluebookId);
							}
						}
					}
				}
			}*/
				String facilityIdString = dashboardDAO.getUserBBCList(req.getUserId());
				//if(bbcString != null && !bbcString.isEmpty()) {
					//bbcList = Arrays.asList(bbcString.split(","));
				//}
				if(facilityIdString != null && !facilityIdString.isEmpty()) {
					FacilityIdList = Arrays.asList(facilityIdString.split(","));
				}
			}

			log.debug("FacilityIdList.........." + FacilityIdList);


			log.debug("bbcs.........." + bbcs);
			
			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = new HashMap<>();

				filterList = dashboardDAO.getFilteredCMCList(req, index,
						taskType, assignee, bbcs, isApplyPagination,FacilityIdList);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));

				cmcDashboard = (List<Dashboard>) filterList.get("data");
			} else {
				/*
				 * totalCount = dashboardDAO.getTotalCount(index, taskType,
				 * assignee, req);
				 */
				cmcDashboard = dashboardDAO.getAllCMCRecords(req, index,
						taskType, assignee,bbcs, isApplyPagination,FacilityIdList);
			}

			if (cmcDashboard != null) {
				// SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd
				// HH:mm:ss");

				for (Dashboard cmcRecord : cmcDashboard) {
					CMCData cmc = new CMCData();

					cmc.setVisitId(cmcRecord.getVisitId());
					cmc.setFacilityId(cmcRecord.getFacilityId());
					cmc.setFacilityName(cmcRecord.getFacilityAlias());
					cmc.setBbc(cmcRecord.getSnfLocationBBC());
					cmc.setPatientId(cmcRecord.getPatientId());
					cmc.setPatientName(cmcRecord.getPatientName());
					cmc.setReceivedDate(cmcRecord.getReceivedDate());
					cmc.setInterfaceDate(cmcRecord.getReceivedDate());
					if (cmcRecord.getProviderName() == null
							|| cmcRecord.getProviderName().isEmpty()) {
						cmc.setProviderName("");
					} else {
						cmc.setProviderName(cmcRecord.getProviderName());
					}
					cmc.setDateOfService(cmcRecord.getDateOfService());
					if (cmcRecord.getMedicalRecordNumber() == null
							|| cmcRecord.getMedicalRecordNumber().isEmpty()) {
						cmc.setMedicalRecordNumber("");
					} else {
						cmc.setMedicalRecordNumber(
								cmcRecord.getMedicalRecordNumber());
					}
					if (cmcRecord.getEncounterType() == null
							|| cmcRecord.getEncounterType().isEmpty()) {
						cmc.setEncounterType("");
					} else {
						cmc.setEncounterType(cmcRecord.getEncounterType());
					}
					if (cmcRecord.getAssigneeUsername() == null
							|| cmcRecord.getAssigneeUsername().isEmpty()) {
						cmc.setAssigneeUsername("");
					} else {
						cmc.setAssigneeUsername(
								cmcRecord.getAssigneeUsername());
					}
					Long assignUserId = 0L;
					if (cmcRecord.getAssigneeUserId() == null) {
						cmc.setAssigneeUserId((Long) assignUserId);

					} else {
						cmc.setAssigneeUserId(cmcRecord.getAssigneeUserId());
					}
					if (cmcRecord.getAssigneeUserFullname() == null
							|| cmcRecord.getAssigneeUserFullname().isEmpty()) {
						cmc.setAssigneeUserFullname("");
					} else {
						cmc.setAssigneeUserFullname(
								cmcRecord.getAssigneeUserFullname());
					}
					cmc.setStatus(cmcRecord.getStatus());
					if (cmcRecord.getCmcNotes() == null
							|| cmcRecord.getCmcNotes().isEmpty()) {
						cmc.setCmcNotes("");
					} else {
						cmc.setCmcNotes(cmcRecord.getCmcNotes());
					}
					cmc.setAccountNumber(cmcRecord.getAccountNumber());
					if (cmcRecord.getPrimaryInsurance() == null
							|| cmcRecord.getPrimaryInsurance().isEmpty()) {
						cmc.setInsurance("");
					} else {
						cmc.setInsurance(cmcRecord.getPrimaryInsurance());
					}
					if (cmcRecord.getGender() == null
							|| cmcRecord.getGender().isEmpty()) {
						cmc.setInsurance("");
					} else {
						cmc.setSex(cmcRecord.getGender());
					}
					if (cmcRecord.getIhealConfig() == null
							|| cmcRecord.getIhealConfig().isEmpty()) {
						cmc.setIhealConfig("");
					} else {
						cmc.setIhealConfig(cmcRecord.getIhealConfig());
					}
					if (cmcRecord.getServiceLine() == null
							|| cmcRecord.getServiceLine().isEmpty()) {
						cmc.setServiceLine("");
					} else {
						cmc.setServiceLine(cmcRecord.getServiceLine());
					}
					cmc.setStatusChangeTimestamp(cmcRecord.getStatusChangeTimestamp());
					
					cmcDataList.add(cmc);
				}

				cmcDashboardRes.setCurrentIndex(index);
				cmcDashboardRes.setTotalCount(totalCount);
			} else {
				cmcDashboard = null;
			}

			cmcDashboardRes.setResponseCode("0");
			cmcDashboardRes.setResponseMessage(BOConstants.SUCCESS);
			cmcDashboardRes.setCmcData(cmcDataList);

		} catch (Exception e) {
			log.error("Exception occured while fetching CMC Data:  {}",
					e.getMessage());
			cmcDashboardRes.setResponseCode("1");
			cmcDashboardRes.setResponseMessage(BOConstants.FAILED);
			cmcDashboardRes.setCmcData(cmcDataList);
			cmcDashboardRes.setNextIndex(index);
			cmcDashboardRes.setCurrentIndex(index);
			cmcDashboardRes.setTotalCount(0L);
			cmcDashboardRes.setTotalPage(0);
			cmcDashboardRes.setExhausted(false);
		}

		return cmcDashboardRes;
	}

	@Override
	public FilterOptionsRes getSearchFilterOptions(DashboardReq req)
			throws EncodeExceptionHandler {
		FilterOptionsRes res = new FilterOptionsRes();
		try {
			List<String> bbcList = new ArrayList<>();
			List<String> FacilityIdList = new ArrayList<>();

			if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				/*UserFacilityRes userFacilityRes = dashboardDAO.getuserFacilities(req.getUserId());
				
				if (userFacilityRes != null 
						&& userFacilityRes.getResponseCode() != null
						&& userFacilityRes.getResponseCode().equalsIgnoreCase("0")) {
					
					if (userFacilityRes.getFacilities() != null 
							&& userFacilityRes.getFacilities().size() > 0) {
						
						for (UserFacilities fac : userFacilityRes.getFacilities()) {
							
							String facilityBluebookId = fac.getFacilityBluebookId();
							
							if (facilityBluebookId != null && !facilityBluebookId.isEmpty()) {
								bbcList.add(facilityBluebookId);
							}
						}
					}
				}
			}*/
				
				String facilityIdString = dashboardDAO.getUserBBCList(req.getUserId());
				//if(bbcString != null && !bbcString.isEmpty()) {
					//bbcList = Arrays.asList(bbcString.split(","));
				//}
				if(facilityIdString != null && !facilityIdString.isEmpty()) {
					FacilityIdList = Arrays.asList(facilityIdString.split(","));
				}
			}

			log.debug("FacilityIdList.........." + FacilityIdList);

			log.debug("bbcList.........." + bbcList);

			FilterOptions filterOptions = dashboardDAO.getFilterOptions(req, bbcList,FacilityIdList);
			
			if (filterOptions != null) {
				res.setFilterOptions(filterOptions);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Filter Options:  {}",
					e.getMessage());
		}
		return res;
	}

	@Override
	public ReasonsRes getPendingReasons() {
		ReasonsRes res = new ReasonsRes();
		try {

			Reasons reasons = dashboardDAO.getPendingReasons();
			if (reasons != null) {
				String pending = reasons.getReasons();
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				ObjectMapper mapper = new ObjectMapper();
				Map<String, Map<String, String>> testMap = new HashMap<>();	
				try {
					// Convert the JSON string into a Map
					testMap = mapper.readValue(pending, new TypeReference<Map<String, Map<String, String>>>() {
					});
					
					Map<String, Map<String, String>> testMap2 = testMap.entrySet().stream().collect(Collectors.toMap(
							Map.Entry::getKey, entry -> entry.getValue().entrySet().stream().sorted(Map.Entry.comparingByValue())
							.collect(Collectors.toMap(
									Map.Entry::getKey, Map.Entry::getValue,
									(e1, e2)->e1,LinkedHashMap::new))));
					res.setReasons(testMap2);
				} catch (Exception e) {
					log.debug("JSON Parsing error: ",e.getMessage());
				}
				res.setRole(reasons.getRole());
				res.setTitle(reasons.getTitle());
			} else {
				res.setResponseCode("1");
				res.setResponseMessage("No pending reasons found");
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching pending reasons : {}",
					e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	private IHealProviderListRes getProvider(ProviderListReq req) {
		IHealProviderListReq ihealReq = new IHealProviderListReq();
		IHealProviderListRes ihealProviderListRes = null;

		ihealReq.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
		ihealReq.setSelectionName("Provider");
		ihealReq.setFacilityId(req.getFacilityId());
		String url = env.getProperty(BOConstants.IHEAL_SELECTIION_ADMIN_GET);

		try {
			log.info("IHeal Provider URL post started");
			HttpEntity<Object> request = new HttpEntity<>(ihealReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealProviderListRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealProviderListRes.class);
			log.info("IHeal Provider URL post Completed");
			log.debug("iHeal Provider Response : {}", sresponse.getBody());
			ihealProviderListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in IHealProvider - ",
					e);
			ihealProviderListRes = new IHealProviderListRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealProviderListRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealProviderListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in IHealProvider: ", e);
			ihealProviderListRes = new IHealProviderListRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealProviderListRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealProviderListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealProviderListRes;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	@Override
	public ProviderListRes getProvidersNames(ProviderListReq req) {
		ProviderListRes res = new ProviderListRes();
		List<ProviderObj> providerObj = new ArrayList<>();
		try {
			IHealProviderListRes iHealProviderListRes = getProvider(req);
			if (iHealProviderListRes != null
					&& iHealProviderListRes.getErrorCode().equals("0")) {
				for (IHealProviderObject obj : iHealProviderListRes
						.getCodeValues()) {
					ProviderObj proObj = new ProviderObj();
					proObj.setId(obj.getCode());
					proObj.setProviderName(obj.getValue());
					providerObj.add(proObj);
				}
				res.setProviderList(providerObj);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode(iHealProviderListRes.getErrorCode());
				res.setResponseMessage(iHealProviderListRes.getErrorMessage());
			}
		} catch (Exception e) {
			res.setProviderList(null);
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public ProviderListRes getProvidersNamesList(ProviderListReq req) {
	    ProviderListRes res = new ProviderListRes();
	    List<ProviderObj> providerObj = new ArrayList<>();  // List to store providers
	    try {
	        // Loop through each facilityId and fetch its providers
	        for (String facilityId : req.getFacilityIds()) {
	            
	            IHealProviderListReq ihealReq = new IHealProviderListReq();
	            ihealReq.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
	            ihealReq.setSelectionName("Provider");
	            ihealReq.setFacilityId(facilityId); // Set the current facilityId directly
	            IHealProviderListRes iHealProviderListRes = getProviderList(ihealReq);  // Get providers for the current facility
	            if (iHealProviderListRes != null && "0".equals(iHealProviderListRes.getErrorCode())) {
	                // Add the providers to the list
	                for (IHealProviderObject obj : iHealProviderListRes.getCodeValues()) {
	                    ProviderObj proObj = new ProviderObj();
	                    proObj.setId(obj.getCode());
	                    proObj.setProviderName(obj.getValue());
	                    providerObj.add(proObj);
	                }
	            }
	            // If there are no providers for the current facility, do nothing (i.e., no change to providerObj)
	        }
	        res.setProviderList(providerObj);  // Set the provider list (it will be empty if no providers were added)
	        res.setResponseCode("0");
	        res.setResponseMessage(BOConstants.SUCCESS);
	    } catch (Exception e) {
	        res.setProviderList(new ArrayList<>());  
	        res.setResponseCode("1");
	        res.setResponseMessage(BOConstants.FAILED);
	    }
	    return res;
	}

	
	@Override
	public CMCData getCMCRecordById(DashboardReq req)
			throws EncodeExceptionHandler {
		CMCData res = new CMCData();
		try {
			res = dashboardDAO.getCMCRecordById(req);

			if (res != null) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res = new CMCData();
				res.setResponseCode("1");
				res.setResponseMessage("No records found");
			}

		} catch (Exception e) {
			log.error("Exception occured while getting CMC Record from Database: {}",
					e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public UserFacilityRes getUserFacilities(String userId,
			String masterToken) {
		IHealUserFacilityListGetRes facilitiesResponse = null;

		String url = env.getProperty(BOConstants.IHEAL_USERFACILITIES_URL);
		log.debug("url" + url);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		log.debug("privateKey" + privateKey);
		IHealUser user = new IHealUser();
		user.setMasterToken(masterToken);
		user.setUserId(userId);
		user.setPrivateKey(privateKey);
		// user.setFacilitySettings(v2Settings);
		UserFacilityRes userFacilityRes = new UserFacilityRes();
		try {
			log.info("IHeal userfacility URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(user, getHeaders());
			assert url != null;
			ResponseEntity<IHealUserFacilityListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealUserFacilityListGetRes.class);
			facilitiesResponse = sresponse.getBody();
			//log.debug("iHeal facilitiesResponse : " + facilitiesResponse);
		} catch (HttpClientErrorException e) {
			log.error(String.format(
					"HttpClientErrorException occurred in getUserFacilities: %s",
					e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(String.format(
					"HttpStatusCodeException occurred in getUserFacilities: %s",
					e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		if (facilitiesResponse != null
				&& facilitiesResponse.getErrorCode() != null
				&& facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			List<UserFacilities> facilities = new ArrayList<>();

			for (IhealFacility facility : facilitiesResponse.getFacilities()) {
				UserFacilities fac = new UserFacilities();
				fac.setFacilityId(facility.getFacilityId());
				fac.setFacilityBluebookId(facility.getFacilityBluebookId());
				fac.setFacilityName(facility.getFacilityName());
				fac.setConfiguration(facility.getConfiguration());
				facilities.add(fac);
			}
			userFacilityRes.setFacilities(facilities);
			userFacilityRes.setResponseCode("0");
			userFacilityRes.setResponseDesc("Success");

		} else if (facilitiesResponse != null
				&& facilitiesResponse.getErrorCode() != null
				&& !facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			userFacilityRes.setResponseCode(facilitiesResponse.getErrorCode());
			userFacilityRes
					.setResponseDesc(facilitiesResponse.getErrorMessage());
		}
		//log.debug("UserFacilityRes:  {}", userFacilityRes);
		return userFacilityRes;
	}
 
	@Override
	public ReasonsRes getCMCUnbillableReasons() {
		ReasonsRes res = new ReasonsRes();
		try {

			Reasons reasons = dashboardDAO.getUnbillableReasons();
			if (reasons != null) {
				String pending = reasons.getReasons();
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				ObjectMapper mapper = new ObjectMapper();
				Map<String, Map<String, String>> testMap = new HashMap<>();	
				try {
					// Convert the JSON string into a Map
					testMap = mapper.readValue(pending, new TypeReference<Map<String, Map<String, String>>>() {
					});
					
					Map<String, Map<String, String>> testMap2 = testMap.entrySet().stream().collect(Collectors.toMap(
							Map.Entry::getKey, entry -> entry.getValue().entrySet().stream().sorted(Map.Entry.comparingByValue())
							.collect(Collectors.toMap(
									Map.Entry::getKey, Map.Entry::getValue,
									(e1, e2)->e1,LinkedHashMap::new))));
					res.setReasons(testMap2);
				} catch (Exception e) {
					log.debug("JSON Parsing error: ",e.getMessage());
				}
				res.setRole(reasons.getRole());
				res.setTitle(reasons.getTitle());
			} else {
				res.setResponseCode("1");
				res.setResponseMessage("No unbillable reasons found");
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching unbillable reasons : {}",
					e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	private IHealProviderListRes getProviderList(IHealProviderListReq ihealReq2) {
		IHealProviderListReq ihealReq = new IHealProviderListReq();
		IHealProviderListRes ihealProviderListRes = null;

		ihealReq.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
		ihealReq.setSelectionName("Provider");
		ihealReq.setFacilityId(ihealReq2.getFacilityId());
		String url = env.getProperty(BOConstants.IHEAL_SELECTIION_ADMIN_GET);

		try {
			log.info("IHeal Provider URL post started");
			HttpEntity<Object> request = new HttpEntity<>(ihealReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealProviderListRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealProviderListRes.class);
			log.info("IHeal Provider URL post Completed");
			log.debug("iHeal Provider Response : {}", sresponse.getBody());
			ihealProviderListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in IHealProvider - ",
					e);
			ihealProviderListRes = new IHealProviderListRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealProviderListRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealProviderListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in IHealProvider: ", e);
			ihealProviderListRes = new IHealProviderListRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealProviderListRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealProviderListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealProviderListRes;
	}

}
