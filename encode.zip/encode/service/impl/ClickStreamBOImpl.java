package com.healogics.encode.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.ClickStreamDAO;
import com.healogics.encode.dto.ClickStreamReq;
import com.healogics.encode.dto.ClickStreamRes;
import com.healogics.encode.service.ClickStreamBO;

@Service
public class ClickStreamBOImpl implements ClickStreamBO{

	private final Logger log = LoggerFactory.getLogger(ClickStreamBOImpl.class);

	private final ClickStreamDAO clickStreamDAO;
	
	@Autowired
	public ClickStreamBOImpl(ClickStreamDAO clickStreamDAO) {
		this.clickStreamDAO = clickStreamDAO;
	}

	@Override
	public ClickStreamRes saveClickStreamData(ClickStreamReq req) {
		ClickStreamRes res = new ClickStreamRes();

		try {
			clickStreamDAO.saveClickStreamData(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while saving clickstream data: {}", e.getMessage());
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

}
