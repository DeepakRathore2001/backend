package com.healogics.encode.service.impl;

import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.AdministrationDAO;
import com.healogics.encode.dto.AdminDashboardFilterOptionsRes;
import com.healogics.encode.dto.AdminDashboardReq;
import com.healogics.encode.dto.AdminDashboardRes;
import com.healogics.encode.dto.AdministrationEncodeUsersRes;
import com.healogics.encode.dto.CampusIndicatorReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.EncodeRolesRes;
import com.healogics.encode.dto.EncodeUserData;
import com.healogics.encode.dto.EncodeUserDetails;
import com.healogics.encode.dto.EncodeUserDetailsForNurseRole;
import com.healogics.encode.dto.FacilityDetailsReq;
import com.healogics.encode.dto.FacilitySettings;
import com.healogics.encode.dto.FacilitySettingsFilterOptionsRes;
import com.healogics.encode.dto.FacilitySettingsRes;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.NurseRoleResponse;
import com.healogics.encode.dto.RoleAssignmentRes;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.FacilityDetails;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.service.AdministrationBO;

@Service
public class AdministrationBOImpl implements AdministrationBO {

	private final Logger log = LoggerFactory.getLogger(AdministrationBOImpl.class);

	private final AdministrationDAO administrationDAO;

	@Autowired
	public AdministrationBOImpl(AdministrationDAO administrationDAO) {
		this.administrationDAO = administrationDAO;
	}

	@Override
	public AdministrationEncodeUsersRes getCoderUsers(DashboardReq req) {
		AdministrationEncodeUsersRes res = new AdministrationEncodeUsersRes();
		List<EncodeUserDetails> usersDetailsList = new ArrayList<>();

		log.debug("usersDetailsList......." + usersDetailsList);
		try {
			List<EncodeUsers> users = new ArrayList<>();

			users = administrationDAO.getCoderUsersData(req.getEncodeRole());
			if (users != null) {

				for (EncodeUsers data : users) {
					EncodeUserDetails details = new EncodeUserDetails();
					details.setEmailId(data.getEmailId());
					if (data.getLastLoggedInTimestamp() == null || data.getLastLoggedInTimestamp().isEmpty()) {
						details.setLastLoggedInTimestamp("");
					} else {
						details.setLastLoggedInTimestamp(data.getLastLoggedInTimestamp());
					}

					if (users != null) {
						List<String> encodeRoleList = new ArrayList<>();
						log.debug("encodeRoleList.." + encodeRoleList);
						for (String role : data.getEncodeRole().split(",")) {
							encodeRoleList.add(role.trim());
						}
						details.setEncodeRole(encodeRoleList);
					}

					details.setUserFullName(data.getUserFullName());
					details.setUserId(data.getUserId());
					details.setUsername(data.getUsername());
					if (data.getIhealRole() == null || data.getIhealRole().isEmpty()) {
						details.setIhealRole("");
					} else {
						details.setIhealRole(data.getIhealRole());
					}
					if (data.getEncodeRoleDesc() == null || data.getEncodeRoleDesc().isEmpty()) {
						details.setEncodeRoleDesc("");
					} else {
						details.setEncodeRoleDesc(data.getEncodeRoleDesc());
					}

					usersDetailsList.add(details);
				}

				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setEncodeUsers(usersDetailsList);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Coder Users Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public AdminDashboardRes getEncodeUsers(boolean isFilter, AdminDashboardReq req, int index, boolean isExport) {
		AdminDashboardRes res = new AdminDashboardRes();
		List<EncodeUserData> usersDetailsList = new ArrayList<>();
		try {
			List<EncodeUsers> users = new ArrayList<>();
			log.debug("index: {}", index);
			Long totalCount = 0L;
			boolean isExhausted = false;

			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = administrationDAO.getFilteredEncodeUsers(req);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));
				users = (List<EncodeUsers>) filterList.get("data");
			} else {
				// Fetch all data without pagination
				users = administrationDAO.getEncodeUsersData(req);
				totalCount = (long) users.size();
			}

			// Process each user to sort ihealRole and encodeRole
			List<EncodeUserData> sortedUsersDetailsList = new ArrayList<>();
			List<EncodeUserData> sortedUsersDetailsLists = new ArrayList<>();
			for (EncodeUsers data : users) {
				EncodeUserData details = new EncodeUserData();
				details.setUserFullName(data.getUserFullName());
				details.setUserName(data.getUsername());

				if (data.getIhealRole() != null && !data.getIhealRole().isEmpty()) {
					List<String> ihealRoles = Arrays
							.stream(data.getIhealRole().replace("[", "").replace("]", "").split(",")).map(String::trim)
							.sorted().collect(Collectors.toList());
					details.setIhealRole(ihealRoles);
				}
				if (data.getEncodeRole() != null && !data.getEncodeRole().isEmpty()) {
					List<String> encodeRoleList = Arrays.stream(data.getEncodeRole().split(",")).map(String::trim)
							.sorted().collect(Collectors.toList());
					details.setEncodeRole(encodeRoleList);
				}
				
				if (data.getTeam() != null && !data.getTeam().isEmpty()) {
					List<String> teamsList = Arrays.stream(data.getTeam().split(",")).map(String::trim)
							.sorted().collect(Collectors.toList());
					details.setCodingTeam(teamsList);
				}

				details.setUserId(data.getUserId());
				details.setStatus(data.getStatus());
				sortedUsersDetailsList.add(details);
			}

			// Apply sorting for ihealRole and encodeRole
			if ("ihealRole".equals(req.getSortBy())) {
				if (req.getOrder() == 0) {
					sortedUsersDetailsList
							.sort(Comparator.comparing((EncodeUserData u) -> u.getIhealRole().toString()).reversed());
				} else {
					sortedUsersDetailsList
							.sort(Comparator.comparing((EncodeUserData u) -> u.getIhealRole().toString()));
				}
			} else if ("encodeRole".equals(req.getSortBy())) {
				if (req.getOrder() == 0) {
					sortedUsersDetailsLists
							.sort(Comparator.comparing((EncodeUserData u) -> u.getEncodeRole().toString()).reversed());
				} else {
					sortedUsersDetailsLists
							.sort(Comparator.comparing((EncodeUserData u) -> u.getEncodeRole().toString()));
				}
			}

			if (!isExport) {
				// Apply pagination after sorting
				int startIndex = index;
				int endIndex = Math.min(startIndex + PAGE_SIZE, sortedUsersDetailsList.size());
				List<EncodeUserData> paginatedUsers = sortedUsersDetailsList.subList(startIndex, endIndex);

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					res.setNextIndex(0);
				} else {
					res.setNextIndex(index + PAGE_SIZE);
				}
				res.setEncodeUsers(paginatedUsers);
			} else {
				res.setEncodeUsers(sortedUsersDetailsList);
			}

			res.setCurrentIndex(index);
			res.setTotalCount(totalCount);
			res.setTotalPage(Math.ceil(totalCount / (double) PAGE_SIZE));
			res.setExhausted(isExhausted);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occurred while fetching Encode Users Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setEncodeUsers(usersDetailsList);
			res.setNextIndex(index);
			res.setCurrentIndex(index);
			res.setTotalCount(0L);
			res.setTotalPage(0);
			res.setExhausted(false);
		}
		return res;
	}

	@Override
	public AdminDashboardFilterOptionsRes getSearchFilterOptions(AdminDashboardReq req) {
		AdminDashboardFilterOptionsRes res = new AdminDashboardFilterOptionsRes();
		try {
			List<String> filterOptions = administrationDAO.getRoleAssignmentFilterOptions(req);
			if (filterOptions != null) {
				res.setOptions(filterOptions);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while  Role Admin Dashboard Filter Options:  {}", e.getMessage());
		}
		return res;
	}

	@Override
	public RoleAssignmentRes saveRoleAssignment(AdminDashboardReq req) {
		RoleAssignmentRes res = new RoleAssignmentRes();
		log.debug("inside saveRoleAssignment Method...");
		try {
			if (req.getUserRoles() != null) {
				administrationDAO.saveEncodeRole(req.getUserRoles());
				res.setResponseCode("0");
				res.setResponseMessage("Success");
			}

		} catch (EncodeExceptionHandler e) {
			log.error("Exception occured while Saving EncodeRole: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("Failed - " + e.getMessage());
		}
		return res;
	}
	
	@Override
	public EncodeRolesRes getEncodeRoles() {
		EncodeRolesRes res = new EncodeRolesRes();
		try {
			List<String>  encodeRoles= administrationDAO.getEncodeRoles();
			res.setEncodeRoles(encodeRoles);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while fetching encode role values : {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public NurseRoleResponse getNurseUsers(DashboardReq req) {
		NurseRoleResponse res = new NurseRoleResponse();
		List<EncodeUserDetailsForNurseRole> usersDetailsList = new ArrayList<>();

		log.debug("usersDetailsList......." + usersDetailsList);
		try {
			List<EncodeUsers> users = new ArrayList<>();

			users = administrationDAO.getNurseUsers(req.getEncodeRole());
			if (users != null) {

				for (EncodeUsers data : users) {
					EncodeUserDetailsForNurseRole details = new EncodeUserDetailsForNurseRole();

					details.setUserFullName(data.getUserFullName());
					details.setUserId(data.getUserId());
					details.setUsername(data.getUsername());
					usersDetailsList.add(details);
				}
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setEncodeUsers(usersDetailsList);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Coder Users Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public FacilitySettingsRes getFacilitySettings() {
		FacilitySettingsRes res = new FacilitySettingsRes();
		try {
			List<FacilityDetails> facilities = administrationDAO.getFacilityDetails();
			log.debug("facilities : " +facilities);
			
			List<FacilitySettings> facilitySettings = new ArrayList<>();
			
			if (facilities != null && facilities.size() > 0) {
				
				facilitySettings = facilities.stream().map(
						facility -> {
							FacilitySettings facSettings = new FacilitySettings();
							facSettings.setId(facility.getId());
							facSettings.setFacilityId(facility.getFacilityId());
							facSettings.setFacilityBBC(facility.getBluebookId());
							facSettings.setFacilityName((facility.getFacilityName() != null)
									? facility.getFacilityName() : "");
							facSettings.setFacilityConfig(facility.getCurrentIHealConfig());
							facSettings.setFacilityType(facility.getCurrentFacilityType());
							facSettings.setPlaceOfService(facility.getPlaceOfService());
							facSettings.setCampusCode((facility.getPlaceOfService() != null)
									? getCampousCode(facility.getPlaceOfService())
									: 0);
							facSettings.setId(facility.getId());
							return facSettings;
						}
				).collect(Collectors.toList());
				
				Collections.sort(facilitySettings, new Comparator<FacilitySettings>() {
					public int compare(FacilitySettings f1, FacilitySettings f2) {
						return f1.getFacilityBBC().compareTo(f2.getFacilityBBC());
					}
				});
			}
			res.setFacilities(facilitySettings);
			res.setResponseCode("0");
			res.setResponseMessage("Success");
		} catch (Exception e) {
			log.error("Exception occured while fetching facility settings:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	private int getCampousCode(String placeOfService) {
		int campousCode = 0;

		switch (placeOfService) {
			case "22": {
				campousCode = 1;
				break;
			}
			case "19": {
				campousCode = 0;
				break;
			}
			default: {
				campousCode = 0;
			}
		}
		return campousCode;
	}

	@Override
	public NotesRes UpdateCampusIndicator(CampusIndicatorReq req) {
		NotesRes res = new NotesRes();
		try {
			if (req.getIndicator() != null) {
				administrationDAO.UpdateCampusIndicator(req.getIndicator());
				res.setResponseCode("0");
				res.setResponseMessage("Success");
			}
			//administrationDAO.UpdateCampusIndicator(req.getCampusCode());
		} catch (Exception e) {
			log.error("Exception occured while Saving campus indecator: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	public FacilitySettingsRes getFacilitySettingsFilterData(boolean isFilter, FacilityDetailsReq req, int index, boolean isExport) {
	    FacilitySettingsRes res = new FacilitySettingsRes();
	    List<FacilitySettings> facilitySettingsList = new ArrayList<>();
	    try {
	        List<FacilityDetails> facilities = administrationDAO.getFilteredFacilityDetails(req);
//	        log.debug("facilities : {}", facilities);

	        List<FacilitySettings> facilitySettings = new ArrayList<>();
	        Long totalCount = 0L;
	        boolean isExhausted = false;

	        if (facilities != null && !facilities.isEmpty()) {
	            facilitySettings = facilities.stream().map(facility -> {
	                FacilitySettings facSettings = new FacilitySettings();
	                facSettings.setFacilityId(facility.getFacilityId());
	                facSettings.setFacilityBBC(facility.getBluebookId());
	                facSettings.setFacilityName((facility.getFacilityName() != null) ? facility.getFacilityName() : "");
	                facSettings.setFacilityConfig(facility.getCurrentIHealConfig());
	                facSettings.setFacilityType(facility.getCurrentFacilityType());
	                facSettings.setPlaceOfService(facility.getPlaceOfService());
	                facSettings.setCampusCode((facility.getPlaceOfService() != null) ? getCampousCode(facility.getPlaceOfService()) : 0);
	                facSettings.setId(facility.getId());
	                return facSettings;
	            }).collect(Collectors.toList());

//	            facilitySettings.sort(Comparator.comparing(FacilitySettings::getFacilityBBC));
	            totalCount = (long) facilitySettings.size();
	        }

	        if (!isExport) {
	            // Apply pagination after sorting
	            int startIndex = index;
	            int endIndex = Math.min(startIndex + PAGE_SIZE, facilitySettings.size());
	            List<FacilitySettings> paginatedFacilities = facilitySettings.subList(startIndex, endIndex);

	            if ((index + PAGE_SIZE) >= totalCount) {
	                isExhausted = true;
	                res.setNextIndex(0);
	            } else {
	                res.setNextIndex(index + PAGE_SIZE);
	            }
	            res.setFacilities(paginatedFacilities);
	            log.debug("facilities : {}",paginatedFacilities );
	        } else {
	            res.setFacilities(facilitySettings);
	        }

	        res.setCurrentIndex(index);
	        res.setTotalCount(totalCount);
	        res.setTotalPage((int) Math.ceil(totalCount / (double) PAGE_SIZE));
	        res.setExhausted(isExhausted);
	        res.setResponseCode("0");
	        res.setResponseMessage("Success");

	    } catch (Exception e) {
	        log.error("Exception occurred while fetching facility settings: {}", e.getMessage());
	        res.setResponseCode("1");
	        res.setResponseMessage(BOConstants.FAILED);
	        res.setFacilities(facilitySettingsList);
	        res.setNextIndex(index);
	        res.setCurrentIndex(index);
	        res.setTotalCount(0L);
	        res.setTotalPage(0);
	        res.setExhausted(false);
	    }
	    return res;
	}
//	@Override
//	public FacilitySettingsRes getFacilitySettingsFilterData(boolean isFilter, AdminDashboardReq adminDashboardReq,
//			int index, boolean isExport) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public FacilitySettingsFilterOptionsRes getFacilitySettingsFilterOptions(FacilityDetailsReq req) {
		FacilitySettingsFilterOptionsRes res = new FacilitySettingsFilterOptionsRes();
		try {
			List<String> filterOptions = administrationDAO.getFacilitySettingsFilterOptions(req);
			if (filterOptions != null) {
				res.setOptions(filterOptions);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while  Role Admin Dashboard Filter Options:  {}", e.getMessage());
		}
		return res;
	}
}