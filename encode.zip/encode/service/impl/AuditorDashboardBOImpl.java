package com.healogics.encode.service.impl;

import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE;
import static com.healogics.encode.constants.DAOConstants.PAGE_SIZE_DOUBLE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.AuditorDashboardDAO;
import com.healogics.encode.dao.DashboardDAO;
import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AllInAuditChartsRes;
import com.healogics.encode.dto.Audit;
import com.healogics.encode.dto.AuditNotesListRes;
import com.healogics.encode.dto.AuditorCollapsibleSectionData;
import com.healogics.encode.dto.AuditorCollapsibleSectionReq;
import com.healogics.encode.dto.AuditorCollapsibleSectionRes;
import com.healogics.encode.dto.AuditorDashboardFilter;
import com.healogics.encode.dto.AuditorDashboardFilterRes;
import com.healogics.encode.dto.AuditorDashboardReq;
import com.healogics.encode.dto.AuditorDashboardRes;
import com.healogics.encode.dto.AuditorExcelData;
import com.healogics.encode.dto.AuditorExcelRes;
import com.healogics.encode.dto.AuditorReasonRes;
import com.healogics.encode.dto.ChartByStatusReq;
import com.healogics.encode.dto.ChartByStatusRes;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.ChartStatusUpdateByFilterReq;
import com.healogics.encode.dto.CollapsibleSection;
import com.healogics.encode.dto.CollapsibleSectionRes;
import com.healogics.encode.dto.FilterOptions;
import com.healogics.encode.dto.HistoryTimelineData;
import com.healogics.encode.dto.IHealCustomScanListReq;
import com.healogics.encode.dto.IHealInboxMessageMini;
import com.healogics.encode.dto.IHealProviderProfileGetRes;
import com.healogics.encode.dto.IHealUserInboxMessageSendRes;
import com.healogics.encode.dto.IHealVisitDocumentListGetRes;
import com.healogics.encode.dto.IHealVisitDocumentRes;
import com.healogics.encode.dto.InsuranceCarrierList;
import com.healogics.encode.dto.InsuranceCarrierRes;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.NotesDetails;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.ReleaseByFilterChartReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;
import com.healogics.encode.dto.SaveAuditDetailsRes;
import com.healogics.encode.dto.UpdateChartstatusReq;
import com.healogics.encode.dto.UpdateChartstatusRes;
import com.healogics.encode.dto.UserFacilities;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.dto.VisitDocumentListReq;
import com.healogics.encode.dto.addOrRemovePinnedFilterReq;
import com.healogics.encode.entity.AuditQueue;
import com.healogics.encode.entity.CollapsibleFilterRes;
import com.healogics.encode.entity.Dashboard;
import com.healogics.encode.entity.EncodeUsers;
import com.healogics.encode.entity.Filters;
import com.healogics.encode.entity.InsuranceCarrier;
import com.healogics.encode.entity.Notes;
import com.healogics.encode.entity.Notification;
import com.healogics.encode.entity.PatientMedicalRecords;
import com.healogics.encode.entity.Reasons;
import com.healogics.encode.exception.EncodeExceptionHandler;
import com.healogics.encode.service.AuditorDashboardBO;
import com.healogics.encode.service.CoderDashboardBO;
import com.healogics.encode.service.DocumentsBO;
import com.healogics.encode.service.HistoryTimelineBO;
import com.healogics.encode.service.ProviderInboxService;

@Service
public class AuditorDashboardBOImpl implements AuditorDashboardBO {

	private final Logger log = LoggerFactory.getLogger(AuditorFilterBOImpl.class);

	private final AuditorDashboardDAO auditorDashboardDAO;
	private HistoryTimelineBO historyTimelineBO;
	private ProviderInboxService providerInboxService;
	private final DashboardDAO dashboardDAO;
	private final DocumentsBO documentsBO;
	private final CoderDashboardBO coderDashboardBO;

	@Autowired
	public AuditorDashboardBOImpl(AuditorDashboardDAO auditorDashboardDAO, DashboardDAO dashboardDAO,
			HistoryTimelineBO historyTimelineBO, DocumentsBO documentsBO, ProviderInboxService providerInboxService,
			CoderDashboardBO coderDashboardBO) {
		this.documentsBO = documentsBO;
		this.auditorDashboardDAO = auditorDashboardDAO;
		this.historyTimelineBO = historyTimelineBO;
		this.dashboardDAO = dashboardDAO;
		this.providerInboxService = providerInboxService;
		this.coderDashboardBO = coderDashboardBO;
	}

	@Override
	public InsuranceCarrierRes getInsuranceCarrier() {
		InsuranceCarrierRes res = new InsuranceCarrierRes();
		try {
			List<InsuranceCarrier> insuranceCarrierList = auditorDashboardDAO.getInsuranceCarrier();
			List<InsuranceCarrierList> insuranceCarrierLists = new ArrayList<>();

			if (insuranceCarrierList != null) {
				for (InsuranceCarrier insuranceCarriers : insuranceCarrierList) {
					InsuranceCarrierList areq = new InsuranceCarrierList();
					areq.setId(insuranceCarriers.getId());
					areq.setCreatedTimestamp(insuranceCarriers.getCreatedTimestamp());
					areq.setDeleteFlag(insuranceCarriers.getDeleteFlag());
					areq.setInsuranceDescription(insuranceCarriers.getInsuranceDescription());
					areq.setLastUpdatedTimestamp(insuranceCarriers.getLastUpdatedTimestamp());
					insuranceCarrierLists.add(areq);
				}
				res.setInsuranceCarrierList(insuranceCarrierLists);
				res.setResponseCode("0");
				res.setResponseMessage("Success");
			} else {
				res.setResponseCode("1");
				res.setResponseMessage("No data found");
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching insuranceCarrierList search values : {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}

	@Override
	public AuditorReasonRes getAuditorReasons() {
		AuditorReasonRes res = new AuditorReasonRes();
		try {
			List<Reasons> reasonList = auditorDashboardDAO.getAuditorReasons();
			List<Map<String, Object>> reasonmap = new ArrayList<>();

			if (reasonList != null && !reasonList.isEmpty()) {

				String role = reasonList.get(0).getRole();
				ObjectMapper mapper = new ObjectMapper();

				for (Reasons reasonobj : reasonList) {
					String title = reasonobj.getTitle();
					String reasonjson = reasonobj.getReasons();

					Map<String, Object> reasonMapEntry = new LinkedHashMap<>();
					reasonMapEntry.put("title", title);
					if (reasonjson == null || reasonjson.trim().isEmpty()) {
						log.warn("ReasonJson is null or empty for the title : {}", title);
						reasonMapEntry.put("reasons", " ");

					} else {
						try {
							Map<String, Object> nestedReasons = mapper.readValue(reasonjson,
									new TypeReference<Map<String, Object>>() {
									});
							reasonMapEntry.put("reasons", nestedReasons);

						} catch (JsonProcessingException e) {
							log.error("Error processing JSON for title : {}", title, e);
							reasonMapEntry.put("reasons", "Error parsing reason");

						}
					}

					reasonmap.add(reasonMapEntry);

				}
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setRole(role);
				res.setListOfReasons(reasonmap);

			} else {
				res.setResponseCode("1");
				res.setResponseMessage("No reasons found");
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching reasons : {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public SaveAuditDetailsRes saveAuditDetails(SaveAuditDetailsReq req) {
		SaveAuditDetailsRes res = new SaveAuditDetailsRes();
		log.info("Saving Record of visitId: " + req.getVisitId());
		log.info("Action: " + req.getAction());

		switch (req.getAction()) {
		case "Save": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);
				res.setResponseCode("0");
				res.setResponseMessage("Success");

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving In Audit Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		case "Complete": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);

				long nextRecordVisitId = auditorDashboardDAO.fetchNextRecord(req.getFilterId(), req.getVisitId(),
						"Auditor");

				if (nextRecordVisitId != 0) {
					res.setNextRecordVisitId(nextRecordVisitId);
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode("2");
					res.setResponseMessage("Success - Reached end of records for the filterId " + req.getFilterId());
				}
				Long userId = Long.valueOf(req.getUserId());
				String action = "Audit Completed";
				// Saving Pend action in timeline
				saveTimeline(req.getVisitId(), action, req.getUserFullName(), userId, req.getUserName(),
						" completed the chart audit", "Auditor");

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving completed Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;
		case "Assign Nurse": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);
				res.setResponseCode("0");
				res.setResponseMessage("Success");

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving In Audit Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;
		case "Nurse Deficiency": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);
				long nextRecordVisitId = auditorDashboardDAO.fetchNextRecord(req.getFilterId(), req.getVisitId(),
						"Nurse");

				if (nextRecordVisitId != 0) {
					res.setNextRecordVisitId(nextRecordVisitId);
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode("2");
					res.setResponseMessage("Success - Reached end of records for the filterId " + req.getFilterId());
				}
				res.setResponseCode("0");
				res.setResponseMessage("Success");

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving In Audit Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		case "Nurse Complete": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);
				long nextRecordVisitId = auditorDashboardDAO.fetchNextRecord(req.getFilterId(), req.getVisitId(),
						"Nurse");

				if (nextRecordVisitId != 0) {
					res.setNextRecordVisitId(nextRecordVisitId);
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode("2");
					res.setResponseMessage("Success - Reached end of records for the filterId " + req.getFilterId());
				}

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving In Audit Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;
		case "Deficiency": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);
				long nextRecordVisitId = auditorDashboardDAO.fetchNextRecord(req.getFilterId(), req.getVisitId(),
						"Auditor");

				if (nextRecordVisitId != 0) {
					res.setNextRecordVisitId(nextRecordVisitId);
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode("2");
					res.setResponseMessage("Success - Reached end of records for the filterId " + req.getFilterId());
				}

				Dashboard dashboard = dashboardDAO.getRecordByVisitId(req.getVisitId());

				String dashboardStatus = "Deficiency";
				boolean notifyProvider = true;

				if (dashboard != null) {
					boolean isIhealConfigMatch = dashboard.getIhealConfig() != null && (dashboard.getIhealConfig()
							.equalsIgnoreCase("OT")
							|| dashboard.getIhealConfig().equalsIgnoreCase("POS")
							|| (dashboard.getIhealConfig().equalsIgnoreCase("EMR") && dashboard.getServiceLine() != null
									&& (dashboard.getServiceLine().equalsIgnoreCase("HSP Inpatient Consult")
											|| dashboard.getServiceLine().equalsIgnoreCase("Inpatient"))));
					log.info("step 1");
					if (isIhealConfigMatch && req.getDeficiencyReason() != null
							&& req.getDeficiencyReason().contains("Needs addendum")) {

						dashboardStatus = "Pending";
						notifyProvider = false;
						log.info("step 2");
					} else if (isIhealConfigMatch && req.getDeficiencyReason() != null
							&& !req.getDeficiencyReason().contains("Needs addendum")) {

						dashboardStatus = "Deficiency";
						log.info("step 3");
					} else if (dashboard.getServiceLine() != null && dashboard.getIhealConfig() != null
							&& (!"HSP Inpatient Consult".equalsIgnoreCase(dashboard.getServiceLine()))
							&& (!"OT".equalsIgnoreCase(dashboard.getIhealConfig()))
							&& (!"POS".equalsIgnoreCase(dashboard.getIhealConfig()))) {

						dashboardStatus = "Deficiency";
						log.info("step 4");
					}
				}

				if (notifyProvider) {
					boolean status = sendInboxMessageToProvider(req);
					log.info("step 5");
				}

				saveTimeline(req.getVisitId(), dashboardStatus, req.getUserFullName(), Long.valueOf(req.getUserId()),
						req.getUserName(), " added deficiency details", "Auditor");

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving deficiency: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		case "Weakness": {
			try {
				auditorDashboardDAO.saveAuditDetails(req);

				Dashboard dashboard = dashboardDAO.getRecordByVisitId(req.getVisitId());

				res.setResponseCode("0");
				res.setResponseMessage("Success");

				// Saving Weakness action in timeline
//    			saveTimeline(req.getVisitId(), "Weakness", req.getUserFullName(), Long.valueOf(req.getUserId()),
//						req.getUserName(), " added weakness details", "Auditor");

				saveTimeline(req.getVisitId(), dashboard.getStatus(), req.getUserFullName(),
						Long.valueOf(req.getUserId()), req.getUserName(), " added weakness details", "Auditor");

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving Weakness: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		default:
			break;
		}
		return res;
	}

	@Override
	public AuditorDashboardRes getAuditorData(boolean isFilter, AuditorDashboardReq req, int index) {
		AuditorDashboardRes auditorDashboardRes = new AuditorDashboardRes();
		List<Audit> auditDataList = new ArrayList<>();
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			Long totalCount = 0L;
			boolean isExhausted = false;

			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = auditorDashboardDAO.getFilteredAuditorList(req, index);
				totalCount = ((Number) filterList.get("Count")).longValue();
				List<Map<String, Object>> filteredAuditorList = (List<Map<String, Object>>) filterList.get("data");

				for (Map<String, Object> map : filteredAuditorList) {
					Audit audit = new Audit();
					audit.setFilterId((Integer) map.get("filterId"));
					audit.setFilterName((String) map.get("filterName"));
					// audit.setCodingTeam((String) map.get("codingTeam"));
					String codingTeamJson = (String) map.get("codingTeam");
					Object filterDateObj = map.get("filterDate");
					if (filterDateObj != null) {
						if (filterDateObj instanceof Timestamp) {
							Timestamp filterDateTimestamp = (Timestamp) filterDateObj;
							SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
							String formattedDate = dateFormat.format(new Date(filterDateTimestamp.getTime()));
							audit.setDateCreated(formattedDate);
						}
					}
					audit.setAuditRecordExists((Integer) map.get("auditRecordExists"));
					List<String> codingTeamList = objectMapper.readValue(codingTeamJson,
							new TypeReference<List<String>>() {
							});
					audit.setCodingTeam(codingTeamList);
					Long count = auditorDashboardDAO.getCountOfAuditQueueByFilterId(audit.getFilterId(), req);
					audit.setCount(count);
					auditDataList.add(audit);
				}

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					auditorDashboardRes.setNextIndex(0);
				} else {
					auditorDashboardRes.setNextIndex(index + PAGE_SIZE);
				}

			} else {
				totalCount = auditorDashboardDAO.getTotalCount(index, req);
				List<Filters> auditorDashboard = auditorDashboardDAO.getAllAuditRecords(req, index, false);

				for (Filters auditQueue : auditorDashboard) {
					Audit audit = new Audit();
					audit.setFilterId(auditQueue.getFilterId());
					audit.setFilterName(auditQueue.getFilterName());
					// audit.setCodingTeam(String.valueOf(auditQueue.getTeam()));
					String codingTeamJson = String.valueOf(auditQueue.getCodingTeam());
					List<String> codingTeamList = objectMapper.readValue(codingTeamJson,
							new TypeReference<List<String>>() {
							});
					audit.setCodingTeam(codingTeamList);

					Long count = auditorDashboardDAO.getCountOfAuditQueueByFilterId(audit.getFilterId(), req);
					audit.setCount(count);
					auditDataList.add(audit);
				}

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					auditorDashboardRes.setNextIndex(0);
				} else {
					auditorDashboardRes.setNextIndex(index + PAGE_SIZE);
				}
			}

			auditorDashboardRes.setCurrentIndex(index);
			auditorDashboardRes.setTotalCount(totalCount);
			auditorDashboardRes.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));
			auditorDashboardRes.setExhausted(isExhausted);
			auditorDashboardRes.setAuditorData(auditDataList);

			log.debug("Next index: {}", auditorDashboardRes.getNextIndex());

			auditorDashboardRes.setResponseCode("0");
			auditorDashboardRes.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occurred while fetching Auditor Data: {}", e.getMessage());
			auditorDashboardRes.setResponseCode("1");
			auditorDashboardRes.setResponseMessage(BOConstants.FAILED);
			auditorDashboardRes.setAuditorData(auditDataList);
			auditorDashboardRes.setNextIndex(index);
			auditorDashboardRes.setCurrentIndex(index);
			auditorDashboardRes.setTotalCount(0L);
			auditorDashboardRes.setTotalPage(0);
			auditorDashboardRes.setExhausted(false);
		}

		return auditorDashboardRes;
	}

	@Override
	public AuditorDashboardRes getAuditorReleaseData(boolean isFilter, AuditorDashboardReq req, int index) {
		AuditorDashboardRes auditorDashboardRes = new AuditorDashboardRes();
		List<Audit> auditDataList = new ArrayList<>();
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			Long totalCount = 0L;

			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = auditorDashboardDAO.getFilteredAuditorReleaseList(req, index);
				totalCount = ((Number) filterList.get("Count")).longValue();
				List<Map<String, Object>> filteredAuditorList = (List<Map<String, Object>>) filterList.get("data");

				for (Map<String, Object> map : filteredAuditorList) {
					Audit audit = new Audit();
					audit.setFilterId((Integer) map.get("filterId"));
					audit.setFilterName((String) map.get("filterName"));
					String codingTeamJson = (String) map.get("codingTeam");
					Object filterDateObj = map.get("filterDate");
					if (filterDateObj != null) {
						if (filterDateObj instanceof Timestamp) {
							Timestamp filterDateTimestamp = (Timestamp) filterDateObj;
							SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
							String formattedDate = dateFormat.format(new Date(filterDateTimestamp.getTime()));
							audit.setDateCreated(formattedDate);
						}
					}

					List<String> codingTeamList = objectMapper.readValue(codingTeamJson,
							new TypeReference<List<String>>() {
							});
					audit.setCodingTeam(codingTeamList);
					Long count = auditorDashboardDAO.getCountOfAuditQueueByFilterIdRelease(audit.getFilterId(), req);
					audit.setCount(count);
					auditDataList.add(audit);
				}

			}

			auditorDashboardRes.setTotalCount(totalCount);
			auditorDashboardRes.setAuditorData(auditDataList);
			auditorDashboardRes.setResponseCode("0");
			auditorDashboardRes.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occurred while fetching Auditor Data Release: {}", e.getMessage());
			auditorDashboardRes.setResponseCode("1");
			auditorDashboardRes.setResponseMessage(BOConstants.FAILED);
			auditorDashboardRes.setAuditorData(auditDataList);
			auditorDashboardRes.setTotalCount(0L);
		}

		return auditorDashboardRes;
	}

	@Override
	public AuditorCollapsibleSectionRes getCollapsibleSectionDetails(int filterId, AuditorCollapsibleSectionReq req) {
		AuditorCollapsibleSectionRes res = new AuditorCollapsibleSectionRes();
		List<AuditorCollapsibleSectionData> collapsiblesectionlist = new ArrayList<>();
		try {
			List<AuditQueue> collapsibleSections = auditorDashboardDAO.getCollapseDetails(filterId, req);

			EncodeUsers userEntity = auditorDashboardDAO.findByUserId(Long.valueOf(req.getUserId()));
			Set<String> allowedFacilityIds = new HashSet<>();

			if (userEntity != null && userEntity.getFacilityIdList() != null) {
				allowedFacilityIds = Arrays.stream(userEntity.getFacilityIdList().split(",")).map(String::trim)
						.collect(Collectors.toSet());
			}

			log.info("allowedFacilityIds : {} ", allowedFacilityIds);

			if (collapsibleSections != null) {
				for (AuditQueue auditor : collapsibleSections) {
					AuditorCollapsibleSectionData data = new AuditorCollapsibleSectionData();
					boolean isFacilityMatched = allowedFacilityIds.contains(String.valueOf(auditor.getFacilityId()));
					log.info("isFacilityMatched : {} ", isFacilityMatched);
					data.setVisitId(auditor.getVisitId());
					data.setBbc(auditor.getBBC());

					if (!isFacilityMatched) {
						// All other fields set to null
						collapsiblesectionlist.add(data);
						continue;
					}

					data.setFilterId(auditor.getFilterId());
					data.setPatientId(auditor.getPatientId());
					data.setPatientName(auditor.getPatientName());
					data.setFacilityId(auditor.getFacilityId());
					data.setFacilityAlias(auditor.getFacilityAlias());
					data.setDateOfService(auditor.getDOS());
					data.setDateQueued(auditor.getDateAdded());
					data.setStatus(auditor.getStatus());
					data.setAssigneeUserId(auditor.getAssigneeUserId());
					;
					if (auditor.getAssigneeUserName() == null || auditor.getAssigneeUserName().isEmpty()) {
						data.setAssigneeUserName("");
					} else {
						data.setAssigneeUserName(auditor.getAssigneeUserName());
					}
					if (auditor.getAssigneeUserFullName() == null || auditor.getAssigneeUserFullName().isEmpty()) {
						data.setAssigneeUserFullName("");
					} else {
						data.setAssigneeUserFullName(auditor.getAssigneeUserFullName());
					}
					if (auditor.getMRN() == null || auditor.getMRN().isEmpty()) {
						data.setMedicalRecordNumber("");
					} else {
						data.setMedicalRecordNumber(auditor.getMRN());
					}
					data.setPatientFirstName(auditor.getPatientFirstName());
					data.setPatientLastName(auditor.getPatientLastName());
					if (auditor.getInsurance() == null || auditor.getInsurance().isEmpty()) {
						data.setInsurance("");
					} else {
						data.setInsurance(auditor.getInsurance());
					}
					data.setIsLocked(auditor.getIsLocked());
					String userFullName = auditor.getLastUpdatedByUserFullName();
					if (userFullName != null && userFullName.contains(",")) {
						String[] nameparts = userFullName.split(",");
						if (nameparts.length == 2) {
							String formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
							data.setUserFullName(formattedName);
						} else {
							data.setUserFullName(userFullName);
						}

					} else {
						data.setUserFullName("");
					}
					collapsiblesectionlist.add(data);
				}
				res.setCount(collapsiblesectionlist.size());
				res.setCollapsibleSection(collapsiblesectionlist);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching CollapsibleSectionData:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public AuditorDashboardFilterRes getAuditorFilterOptions(AuditorDashboardReq req) {
		AuditorDashboardFilterRes res = new AuditorDashboardFilterRes();
		try {

			AuditorDashboardFilter filterOptions = auditorDashboardDAO.getAuditorFilterOptions(req);

			if (filterOptions != null) {
				res.setAuditorDashboardFilter(filterOptions);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Filter Options:  {}", e.getMessage());
		}
		return res;

	}

	@Override
	public UpdateChartstatusRes updateChartStatus(UpdateChartstatusReq req) {
		log.info("Saving Record of visitId: " + req.getVisitId());
		log.info("Action: " + req.getAction());
		Timestamp dosTimestamp = null;
		Timestamp nextDaytTimestamp = null;
		UpdateChartstatusRes res = new UpdateChartstatusRes();

		switch (req.getAction()) {
		case "AUDIT": {
			try {
				auditorDashboardDAO.updateAuditChartStatus(req, BOConstants.AUDIT_STATUS, "Auditor");
				res.setResponseCode("0");
				res.setResponseMessage("Success");

				List<Long> visitIds = req.getVisitId();
				Long userId = Long.valueOf(req.getUserId());

				for (Long visitId : visitIds) {
					String action = "In Audit";
					// Saving Pend action in timeline
					saveTimeline(visitId, action, req.getUserFullName(), userId, req.getUserName(),
							" audited the chart", "Auditor");

				}

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving In Audit Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		case "RELEASE": {
			try {
				auditorDashboardDAO.updatedCompletedStatus(req, "Released");
				res.setResponseCode("0");
				res.setResponseMessage("Success");

				List<Long> visitIds = req.getVisitId();
				Long userId = Long.valueOf(req.getUserId());

				for (Long visitId : visitIds) {
					String action = "Released";
					// Saving Pend action in timeline
					saveTimeline(visitId, action, req.getUserFullName(), userId, req.getUserName(),
							" released the audited chart", "Auditor");

				}

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving completed Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		case "Reactivate": {
			try {
				List<Long> visitIds = req.getVisitId();
				Long userId = Long.valueOf(req.getUserId());
				for (Long visitId : visitIds) {
					Dashboard dashObj = dashboardDAO.getRecordByVisitId(visitId);

					VisitDocumentListReq docReq = new VisitDocumentListReq();
					Integer facilityId = dashObj.getFacilityId();
					docReq.setMasterToken(req.getMasterToken());
					docReq.setFacilityId(facilityId.toString());
					Long patientId = dashObj.getPatientId();
					docReq.setPatientId(patientId.toString());
					docReq.setUserId(req.getUserId());
					docReq.setVisitId(visitId.toString());

					log.info(" getvisitdocumentlist URL post started ");

					IHealVisitDocumentRes response = new IHealVisitDocumentRes(); // Initialize the response object

					response = getVisitDocumentListHandler(docReq);
					boolean PN = dashObj.isProgNoteSigned();
					boolean HBO = dashObj.isHBOSigned();

					log.debug("response from getVisitDocumentList", response);

					log.info("PatientId=" + patientId);
					Dashboard dashboard = auditorDashboardDAO.getDashboardByVisitId(visitId);
					String oldStatus = dashboard.getStatus();
					if (dashboard != null) {
						String action = "";
						String timelineAction = "";
						if ("CMC".equalsIgnoreCase(dashboard.getLastStatusChangeRole())) {
							List<Notification> notification = null;

							// check Notification Obj for documentType=SuperBill
							notification = auditorDashboardDAO.fetchNotificationsByvisitId(visitId);
							if (notification != null) {
								auditorDashboardDAO.updateStatus(req, "New");
								// update status to "New"
								action = "New";
								timelineAction = "updated the chart status from Unbillable to New";

							} else {

								log.info("Document not exits");
								// No need to change status, stay in Unbillable
								// Document not exits
							}
							saveTimeline1(visitId, action, req.getUserFullName(), userId, req.getUserName(),
									timelineAction, "System admin OR Coder Team Lead");
						} else if ("Coder".equalsIgnoreCase(dashboard.getLastStatusChangeRole())) {

							List<Notification> notification = null;
							// check Notification Obj for documentType=SuperBill
							notification = auditorDashboardDAO.fetchNotificationsByvisitId(visitId);

							PatientMedicalRecords pmr = null;
							List<String> docTypeList = Arrays.asList("HBO", "PN");
							pmr = auditorDashboardDAO.getPatientMedicalRecord(patientId, visitId, docTypeList);
							log.debug("pmr={}", pmr);
							// check PMR contains HBO or PN
							// Query visitId, patientId, documentType= PN or HBO
							if ((pmr != null)
									|| (response.getDocumentList() != null && !response.getDocumentList().isEmpty())
									|| PN || HBO) {

								// update status to "Ready"
								auditorDashboardDAO.updateStatus(req, "Ready");

								action = "Ready";
								timelineAction = "updated the chart status from " + oldStatus + " to Ready";

							} else if (pmr == null && response.getDocumentList() == null) {
								// update status to "Received"
								auditorDashboardDAO.updateStatus(req, "Received");
								action = "Received";

								timelineAction = "updated the chart status from " + oldStatus + " to Received";

							}
							saveTimeline1(visitId, action, req.getUserFullName(), userId, req.getUserName(),
									timelineAction, "System admin OR Coder Team Lead");
						} else if ("Auditor".equalsIgnoreCase(dashboard.getLastStatusChangeRole())) {
							// auditorDashboardDAO.updateStatus(req, "In Audit");
							auditorDashboardDAO.updateAuditChartStatus(req, BOConstants.AUDIT_STATUS, "Auditor");
							// update status to "In Audit"
							action = "In Audit";
							// timelineAction = "updated the chart status from Audit Completed to In Audit";
							timelineAction = "updated the chart status from " + oldStatus + " to In Audit";
							saveTimeline1(visitId, action, req.getUserFullName(), userId, req.getUserName(),
									timelineAction, "Auditor");
						}

					} else {
						log.info("No dashboard record found for visitId: " + visitId);
					}
				}
				res.setResponseCode("0");
				res.setResponseMessage("Success");
			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving completed Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;

		case "NURSE_AUDIT": {
			try {
				auditorDashboardDAO.updateAuditChartStatus(req, BOConstants.NURSE_REVIEW, "Nurse");
				res.setResponseCode("0");
				res.setResponseMessage("Success");

				List<Long> visitIds = req.getVisitId();
				Long userId = Long.valueOf(req.getUserId());

				for (Long visitId : visitIds) {
					String action = "Nurse Review";
					// Saving Pend action in timeline
					saveTimeline(visitId, action, req.getUserFullName(), userId, req.getUserName(),
							" audited the chart", "Nurse");

				}

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while Saving Nurse Audit Status: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}
			break;
		case "Unbillable": {
			try {

				String oldStatus = req.getOldStatus();

				auditorDashboardDAO.performUnbillableAction(req, "Unbillable", req.getUserRole());

				// List<String> bbcList = getBbcList(String.valueOf(req.getUserId()),
				// req.getMasterToken());

				// res.setNextRecordVisitId(dashboardDAO.fetchNextRecord(BOConstants.CODER_ROLE,
				// bbcList,
				// dosTimestamp,nextDaytTimestamp, req.getVisitId()));
				List<String> facilityidlist = getFacilityIdList(String.valueOf(req.getUserId()), req.getMasterToken());
//				res.setNextRecordVisitId(dashboardDAO.fetchNextRecords(BOConstants.CODER_ROLE, facilityidlist,
//						dosTimestamp,nextDaytTimestamp, req.getVisitId().get(0),req));
				res.setResponseCode("0");
				res.setResponseMessage("Success");

				// Saving Unbillable action in timeline
				for (Long visitId : req.getVisitId()) {
					String action = "Unbillable";
					// Saving Pend action in timeline
					saveTimeline(visitId, action, req.getUserFullName(), Long.valueOf(req.getUserId()),
							req.getUserName(), "marked the chart as Unbillable", req.getUserRole());

				}

			} catch (EncodeExceptionHandler e) {
				log.error("Exception occured while adding Unbillable reason: {}", e.getMessage());
				res.setResponseCode("1");
				res.setResponseMessage("Failed - " + e.getMessage());
			}
		}

		default:
			break;
		}
		return res;
	}

	private List<String> getFacilityIdList(String userId, String masterToken) {
		UserFacilityRes userFacilityRes = coderDashboardBO.getUserFacilities(userId, masterToken);

		List<String> facilityIdList = new ArrayList<>();

		if (userFacilityRes != null && userFacilityRes.getResponseCode() != null
				&& userFacilityRes.getResponseCode().equalsIgnoreCase("0")) {

			if (userFacilityRes.getFacilities() != null && userFacilityRes.getFacilities().size() > 0) {

				for (UserFacilities fac : userFacilityRes.getFacilities()) {
					if (fac.getFacilityId() != null && !fac.getFacilityId().isEmpty()) {
						facilityIdList.add(fac.getFacilityId());
					}
				}
			}
		}

		log.info("facilityIdList : " + facilityIdList);
		return facilityIdList;
	}

	private IHealVisitDocumentRes getVisitDocumentListHandler(VisitDocumentListReq docReq) {
		try {
			// Use the injected documentsBO instance to call the method
			return documentsBO.getVisitDocumentList(docReq);
		} catch (EncodeExceptionHandler e) {
			// Log the exception and handle it appropriately
			log.error("Error while fetching visit document list", e);

			// Return a default response or throw a custom exception if needed
			return new IHealVisitDocumentRes(); // Example: Return an empty/default response
		}
	}

	private void saveTimeline(long visitId, String action, String userFullName, long userId, String userName,
			String chartDesc, String userRole) {
		log.info("Inside saveTimeline");
		try {
			log.info("action : {} ", action);
			AuditQueue dashObj = auditorDashboardDAO.getRecordByVisitId(visitId);

			if (dashObj != null) {
				String formattedName = "";
				HistoryTimelineData timeline = new HistoryTimelineData();
				timeline.setBluebookId(dashObj.getBBC());

				if (userFullName != null && userFullName.contains(",")) {
					String[] nameparts = userFullName.split(",");
					if (nameparts.length == 2) {
						if ("Audit Completed".equals(action) || "Deficiency".equals(action)
								|| "Weakness".equals(action)) {
							formattedName = nameparts[0].trim() + " " + nameparts[1].trim();
							log.info("Formatted Name correct : {} ", formattedName);
						} else {
							formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
							log.info("Formatted Name wrong : {}", formattedName);
						}
					}
				} else if (userFullName != null && !userFullName.contains(",")) {
					formattedName = userFullName;
					log.info("Formatted Name wrong 2 : {} ", formattedName);
				}

				timeline.setChartDescription(formattedName + "#" + chartDesc);
				timeline.setChartStatus(action);
				timeline.setDateOfService(dashObj.getDOS());
				timeline.setFacilityId(dashObj.getFacilityId());
				timeline.setPatientId(dashObj.getPatientId());
				timeline.setPatientName(dashObj.getPatientName());
				timeline.setUserFullName(formattedName);
				timeline.setUserId(userId);
				timeline.setUserRole(userRole);
				timeline.setUserName(userName);
				timeline.setVisitId(visitId);

				historyTimelineBO.saveHistoryTimeline(timeline);
			}
		} catch (Exception e) {
			log.error("Exception occured while Saving timeline: {}", e.getMessage());
		}
	}

	private void saveTimeline1(long visitId, String action, String userFullName, long userId, String userName,
			String chartDesc, String userRole) {
		try {
			Dashboard dashObj = dashboardDAO.getRecordByVisitId(visitId);

			if (dashObj != null) {
				String formattedName = "";
				if (userFullName != null && userFullName.contains(",")) {
					String[] nameparts = userFullName.split(",");
					if (nameparts.length == 2) {
						formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
					}
				} else if (userFullName != null && !userFullName.contains(",")) {
					formattedName = userFullName;
				}

				HistoryTimelineData timeline = new HistoryTimelineData();
				timeline.setBluebookId(dashObj.getBluebookId());
				timeline.setChartDescription(formattedName + "#" + chartDesc);
				timeline.setChartStatus(action);
				timeline.setDateOfService(dashObj.getDateOfService());
				timeline.setFacilityId(dashObj.getFacilityId());
				timeline.setPatientId(dashObj.getPatientId());
				timeline.setPatientName(dashObj.getPatientName());
				timeline.setUserFullName(formattedName);
				timeline.setUserId(userId);
				timeline.setUserRole(userRole);
				timeline.setUserName(userName);
				timeline.setVisitId(visitId);

				historyTimelineBO.saveHistoryTimeline(timeline);
			}
		} catch (Exception e) {
			log.error("Exception occured while Saving timeline: {}", e.getMessage());
		}
	}

	@Override
	public AuditorExcelRes getAllAuditorData(boolean isFilter, AuditorDashboardReq req, int index) {
		AuditorExcelRes auditorDashboardRes = new AuditorExcelRes();
		List<AuditorExcelData> auditDataList = new ArrayList<>();
		ObjectMapper objectMapper = new ObjectMapper();

		try {

			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = auditorDashboardDAO.getAllFilteredAuditorList(req, index, true);
				List<Map<String, Object>> filteredAuditorList = (List<Map<String, Object>>) filterList.get("data");

				for (Map<String, Object> map : filteredAuditorList) {
					AuditorExcelData audit = new AuditorExcelData();
					audit.setFilterId(map.get("filterId") != null ? (Integer) map.get("filterId") : 0);
					audit.setFilterName(map.get("filterName") != null ? (String) map.get("filterName") : "");
					String codingTeamJson = (String) map.get("codingTeam");
					List<String> codingTeamList = codingTeamJson != null
							? objectMapper.readValue(codingTeamJson, new TypeReference<List<String>>() {
							})
							: Collections.emptyList();
					audit.setCodingTeam(String.join(", ", codingTeamList));
					// audit.setCodingTeam(map.get("codingTeam") != null ? (String)
					// map.get("codingTeam") : "");
					audit.setVisitId(map.get("visitId") != null ? (Long) map.get("visitId") : 0);
					audit.setPatientId(map.get("patientId") != null ? (Long) map.get("patientId") : 0);
					audit.setPatientName(map.get("patientName") != null ? (String) map.get("patientName") : "");
					audit.setFacilityId(map.get("facilityId") != null ? (Integer) map.get("facilityId") : 0);
					audit.setBluebookId(map.get("BBC") != null ? (String) map.get("BBC") : "");
					audit.setFacilityAlias(map.get("facilityAlias") != null ? (String) map.get("facilityAlias") : "");
					Object dosObject = map.get("DOS");
					if (dosObject instanceof Timestamp) {
						audit.setDateOfService((Timestamp) dosObject);
					} else {
						log.debug("Expected Timestamp for DOS but found: {}",
								dosObject != null ? dosObject.getClass().getName() : "null");
						audit.setDateOfService(null);
					}
					audit.setStatus(map.get("status") != null ? (String) map.get("status") : "");
					audit.setMedicalRecordNumber(map.get("MRN") != null ? (String) map.get("MRN") : "");
					audit.setPatientFirstName(
							map.get("patientFirstName") != null ? (String) map.get("patientFirstName") : "");
					audit.setPatientLastName(
							map.get("patientLastName") != null ? (String) map.get("patientLastName") : "");
					audit.setInsurance(map.get("insurance") != null ? (String) map.get("insurance") : "");
					audit.setDateAdded((Date) map.get("dateAdded"));
					audit.setAssigneeUserFullName(
							map.get("assigneeUserFullName") != null ? (String) map.get("assigneeUserFullName") : "");
					auditDataList.add(audit);
				}

			} else {

				List<Object[]> auditorDashboard = auditorDashboardDAO.getExcelAllAuditRecords(req, index, true);
				for (Object[] result : auditorDashboard) {
					AuditorExcelData audit = new AuditorExcelData();

					// Set the filterId and filterName, which will always be present
					audit.setFilterId((Integer) result[0]);
					audit.setFilterName((String) result[1]);
					// audit.setCodingTeam(result[2] != null ? String.valueOf(result[2]) : "");
					String codingTeamJson = (String) result[2];
					List<String> codingTeamList = codingTeamJson != null
							? objectMapper.readValue(codingTeamJson, new TypeReference<List<String>>() {
							})
							: Collections.emptyList();
					audit.setCodingTeam(String.join(", ", codingTeamList));
					audit.setVisitId(result[3] != null ? (Long) result[3] : 0);
					audit.setPatientId(result[4] != null ? (Long) result[4] : 0);
					audit.setPatientName(result[5] != null ? (String) result[5] : "");
					audit.setFacilityId(result[6] != null ? (Integer) result[6] : 0);
					audit.setBluebookId(result[7] != null ? (String) result[7] : "");
					audit.setFacilityAlias(result[8] != null ? (String) result[8] : "");
					Object dosObject = result[9];
					if (dosObject instanceof Timestamp) {
						audit.setDateOfService((Timestamp) dosObject);
					} else {
						log.debug("Expected Timestamp for DOS but found: {}",
								dosObject != null ? dosObject.getClass().getName() : "null");
						audit.setDateOfService(null);
					}
					audit.setStatus(result[10] != null ? (String) result[10] : "");
					audit.setMedicalRecordNumber(result[11] != null ? (String) result[11] : "");
					audit.setPatientFirstName(result[12] != null ? (String) result[12] : "");
					audit.setPatientLastName(result[13] != null ? (String) result[13] : "");
					audit.setInsurance(result[14] != null ? (String) result[14] : "");
					audit.setDateAdded((Date) result[15]);
					audit.setAssigneeUserFullName(result[16] != null ? (String) result[16] : "");

					auditDataList.add(audit);
				}

			}

			auditorDashboardRes.setCollapsibleSection(auditDataList);

			auditorDashboardRes.setResponseCode("0");
			auditorDashboardRes.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occurred while fetching Auditor Data: {}", e.getMessage());
			auditorDashboardRes.setResponseCode("1");
			auditorDashboardRes.setResponseMessage(BOConstants.FAILED);
			auditorDashboardRes.setCollapsibleSection(auditDataList);
		}

		return auditorDashboardRes;

	}

	@Override
	public AuditNotesListRes getAuditNotes(NoteListReq req, String userRole) {
		AuditNotesListRes auditNoteRes = new AuditNotesListRes();
		List<NotesDetails> auditNotesList = new ArrayList<>();

		log.debug("retrieveNoteList... :" + auditNotesList);
		try {
			List<Notes> retrieveNotes = auditorDashboardDAO.getAuditNotes(req);

			log.debug("retrieveNotes :" + retrieveNotes);

			if (retrieveNotes != null) {
				for (Notes retrieveNote : retrieveNotes) {
					NotesDetails notes = new NotesDetails();
					notes.setVisitId(retrieveNote.getVisitId());
					notes.setPatientId(retrieveNote.getPatientId());
					notes.setUserRole(retrieveNote.getUserRole());
					notes.setUserName(retrieveNote.getUserName());
					notes.setUserFullName(retrieveNote.getUserFullName());
					notes.setDescription(retrieveNote.getDescription());
					notes.setNoteAddedTimestamp(retrieveNote.getCreatedTimestamp());
					notes.setNoteId(retrieveNote.getNoteId());
					notes.setCreatorUserId(retrieveNote.getCreatorUserId());
					auditNotesList.add(notes);
				}

			} else {
				retrieveNotes = null;
			}

			auditNoteRes.setResponseCode("0");
			auditNoteRes.setResponseMessage(BOConstants.SUCCESS);
			auditNoteRes.setAuditNotes(auditNotesList);
		} catch (Exception e) {
			log.error("Exception occured while fetching audit notes Data.:  {}", e.getMessage());
			auditNoteRes.setResponseCode("1");
			auditNoteRes.setResponseMessage(BOConstants.FAILED);
			auditNoteRes.setAuditNotes(auditNotesList);
		}
		return auditNoteRes;
	}

	@Override
	public CollapsibleFilterRes getCollapsibleFilterOption(AuditorCollapsibleSectionReq req, int filterId) {
		CollapsibleFilterRes res = new CollapsibleFilterRes();
		try {

			FilterOptions collapsibleFilter = auditorDashboardDAO.retrieveCollapsibleFilterOption(req, filterId);
			if (collapsibleFilter != null) {
				res.setCollapsibleFilter(collapsibleFilter);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Filter Options:  {}", e.getMessage());
		}
		return res;
	}

	@Override
	public AuditorCollapsibleSectionRes getCollapsibleFilteredData(int filterId, AuditorCollapsibleSectionReq req,
			boolean isfilter, int index, boolean isApplyPagination) {
		AuditorCollapsibleSectionRes filterres = new AuditorCollapsibleSectionRes();
		List<AuditorCollapsibleSectionData> collapsiblesectionlist = new ArrayList<>();

		List<AuditQueue> collapsibleSections = new ArrayList<>();
		List<String> bbcList = new ArrayList<>();
		try {

			Long totalCount = 0L;
			boolean isExhausted = false;

			if (isfilter) {

				Map<String, Object> filterList = new HashMap<>();

				filterList = auditorDashboardDAO.getCollapsibleFilteredData(filterId, req, index, isApplyPagination);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));

				collapsibleSections = (List<AuditQueue>) filterList.get("data");

			}

			EncodeUsers userEntity = auditorDashboardDAO.findByUserId(Long.valueOf(req.getUserId()));
			Set<String> allowedFacilityIds = new HashSet<>();

			if (userEntity != null && userEntity.getFacilityIdList() != null) {
				allowedFacilityIds = Arrays.stream(userEntity.getFacilityIdList().split(",")).map(String::trim)
						.collect(Collectors.toSet());
			}

			if (collapsibleSections != null) {
				for (AuditQueue auditor : collapsibleSections) {
					AuditorCollapsibleSectionData data = new AuditorCollapsibleSectionData();
					boolean isFacilityMatched = allowedFacilityIds.contains(String.valueOf(auditor.getFacilityId()));

					data.setVisitId(auditor.getVisitId());
					data.setBbc(auditor.getBBC());

					if (!isFacilityMatched) {
						// All other fields set to null
						collapsiblesectionlist.add(data);
						continue;
					}

					data.setFilterId(auditor.getFilterId());
					data.setPatientId(auditor.getPatientId());
					data.setPatientName(auditor.getPatientName());
					data.setFacilityId(auditor.getFacilityId());
					data.setFacilityAlias(auditor.getFacilityAlias());
					data.setDateOfService(auditor.getDOS());
					data.setDateQueued(auditor.getDateAdded());
					data.setStatus(auditor.getStatus());
					data.setAssigneeUserId(auditor.getAssigneeUserId());
					;
					if (auditor.getAssigneeUserName() == null || auditor.getAssigneeUserName().isEmpty()) {
						data.setAssigneeUserName("");
					} else {
						data.setAssigneeUserName(auditor.getAssigneeUserName());
					}
					if (auditor.getAssigneeUserFullName() == null || auditor.getAssigneeUserFullName().isEmpty()) {
						data.setAssigneeUserFullName("");
					} else {
						data.setAssigneeUserFullName(auditor.getAssigneeUserFullName());
					}
					if (auditor.getMRN() == null || auditor.getMRN().isEmpty()) {
						data.setMedicalRecordNumber("");
					} else {
						data.setMedicalRecordNumber(auditor.getMRN());
					}
					data.setPatientFirstName(auditor.getPatientFirstName());
					data.setPatientLastName(auditor.getPatientLastName());
					if (auditor.getInsurance() == null || auditor.getInsurance().isEmpty()) {
						data.setInsurance("");
					} else {
						data.setInsurance(auditor.getInsurance());
					}
					data.setIsLocked(auditor.getIsLocked());
					String userFullName = auditor.getLastUpdatedByUserFullName();
					if (userFullName != null && userFullName.contains(",")) {
						String[] nameparts = userFullName.split(",");
						if (nameparts.length == 2) {
							String formattedName = nameparts[1].trim() + " " + nameparts[0].trim();
							data.setUserFullName(formattedName);
						} else {
							data.setUserFullName(userFullName);
						}

					} else {
						data.setUserFullName("");
					}
					collapsiblesectionlist.add(data);
				}
			} else {
				filterres = null;
			}
			log.debug("Next index: {}", (index + PAGE_SIZE));

			filterres.setResponseCode("0");
			filterres.setResponseMessage(BOConstants.SUCCESS);
			filterres.setCount(collapsiblesectionlist.size());
			filterres.setCollapsibleSection(collapsiblesectionlist);
		} catch (Exception e) {
			log.error("Exception occured while fetching CMC Data:  {}", e.getMessage());
			filterres.setResponseCode("1");
			filterres.setResponseMessage(BOConstants.FAILED);
			filterres.setCollapsibleSection(collapsiblesectionlist);
		}

		return filterres;
	}

//	@Override
//	public AllInAuditChartsRes getAllInAuditCharts(){
//	    AllInAuditChartsRes res = new AllInAuditChartsRes();
//	    try {
//	        List<AuditorCollapsibleSectionData> allInAuditDataList = auditorDashboardDAO.getALLInAuditRecords();
//	        List<AuditorCollapsibleSectionData> inAuditDataLists = new ArrayList<>();
//	 
//	        if (allInAuditDataList != null && !allInAuditDataList.isEmpty()) {
//	            inAuditDataLists.addAll(allInAuditDataList);
//	            res.setInAuditData(inAuditDataLists);
//	            res.setResponseCode("0");
//	            res.setResponseMessage("Success");
//	        } else {
//	            res.setResponseCode("1");
//	            res.setResponseMessage("No data found");
//	        }
//	    } catch (Exception e) {
//	        log.error("Exception occurred while fetching the in audit data: {}", e.getMessage());
//	        res.setResponseCode("1");
//	        res.setResponseMessage("Failed");
//	    }
//	    return res;
//	}

	@Override
	public AllInAuditChartsRes getAllInAuditCharts() {
		AllInAuditChartsRes res = new AllInAuditChartsRes();
		try {
			List<AuditorCollapsibleSectionData> allInAuditDataList = auditorDashboardDAO.getALLInAuditRecords();
			List<AuditorCollapsibleSectionData> inAuditDataLists = new ArrayList<>();
			if (allInAuditDataList != null && !allInAuditDataList.isEmpty()) {
				inAuditDataLists.addAll(allInAuditDataList);
			}
			res.setInAuditData(inAuditDataLists);
			res.setResponseCode("0");
			res.setResponseMessage(inAuditDataLists.isEmpty() ? "No data found" : "Success");
		} catch (Exception e) {
			log.error("Exception occurred while fetching the in audit data: {}", e.getMessage());
			res.setInAuditData(new ArrayList<>()); // Ensure an empty list is returned in case of an error
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}

	@Override
	public ChartByStatusRes getChartByStatus(ChartByStatusReq req) {
		ChartByStatusRes res = new ChartByStatusRes();
		try {
			List<AuditorCollapsibleSectionData> allDataList = auditorDashboardDAO.getChartByStatus(req);
			List<AuditorCollapsibleSectionData> dataLists = new ArrayList<>();
			if (allDataList != null && !allDataList.isEmpty()) {
				dataLists.addAll(allDataList);
			}
			res.setChartData(dataLists);
			res.setResponseCode("0");
			res.setResponseMessage(dataLists.isEmpty() ? "No data found" : "Success");
		} catch (Exception e) {
			log.error("Exception occurred while fetching the in audit data: {}", e.getMessage());
			res.setChartData(new ArrayList<>()); // Ensure an empty list is returned in case of an error
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}

	@Override
	public ReasonsRes getNurseDispositionList() {
		ReasonsRes res = new ReasonsRes();
		try {
			Reasons reasons = auditorDashboardDAO.getNurseDispositionList();
			if (reasons != null) {
				String nurseDisposition = reasons.getReasons();
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);

				ObjectMapper mapper = new ObjectMapper();
				Map<String, Map<String, String>> testMap = new HashMap<>();
				try {
					// Convert the JSON string into a Map
					testMap = mapper.readValue(nurseDisposition, new TypeReference<Map<String, Map<String, String>>>() {
					});

					Map<String, Map<String, String>> testMap2 = testMap.entrySet().stream()
							.collect(Collectors.toMap(Map.Entry::getKey,
									entry -> entry.getValue().entrySet().stream().sorted(Map.Entry.comparingByValue())
											.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
													(e1, e2) -> e1, LinkedHashMap::new))));
					res.setReasons(testMap2);
				} catch (Exception e) {
					log.debug("JSON Parsing error: ", e.getMessage());
				}

				res.setRole(reasons.getRole());
				res.setTitle(reasons.getTitle());
			} else {
				res.setResponseCode("1");
				res.setResponseMessage("No Nurse Disposition found");
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching nurse disposition list : {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public APIResponse releaseByFilterChart(ReleaseByFilterChartReq req) {
		APIResponse res = new APIResponse();
		try {
			auditorDashboardDAO.releaseByFilterChart(req);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (EncodeExceptionHandler e) {
			log.error("Exception occurred while updating chart status to Released: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("Failed to release charts - " + e.getMessage());
		}
		return res;
	}

	private boolean sendInboxMessageToProvider(SaveAuditDetailsReq req) {
		boolean status = false;

		try {
			Integer providerUserId = 0;
			Integer facilityId = 0;

			Dashboard dashboard = dashboardDAO.getRecordByVisitId(req.getVisitId());

			if (dashboard != null) {
				facilityId = dashboard.getFacilityId();
			}

			int provUserId = 0;
			if (req.getDeficientProviderUserId() != null) {
				provUserId = req.getDeficientProviderUserId().intValue();
			}

			int patientId = 0;
			if (req.getPatientId() != null) {
				patientId = req.getPatientId().intValue();
			}

			// Call i-heal ProviderProfileGet API to get Provider User Id
			IHealProviderProfileGetRes providerRes = providerInboxService.callProviderProfileGetAPI(facilityId,
					provUserId);

			if (providerRes != null && providerRes.getErrorCode() != null
					&& providerRes.getErrorCode().equalsIgnoreCase("0")) {
				// Success
				if (providerRes.getProviderProfile() != null) {
					providerUserId = providerRes.getProviderProfile().getProviderUserId();
				}
			} else {
				// Failed
				log.error("ProviderProfileGet API failed");
			}

			log.debug("providerUserId : " + providerUserId);

			if (providerUserId != 0) {

				List<Integer> providerIds = new ArrayList<>();
				providerIds.add(providerUserId);

				if (req.getiHealConfig() != null && req.getiHealConfig().equalsIgnoreCase("EMR")) {

					// Call i-heal UserInboxMessageSend API to notify Provider
					IHealUserInboxMessageSendRes inboxSendRes = providerInboxService
							.callUserInboxMessageSendAPIForEMRAuditor(providerIds, req.getVisitId(), facilityId,
									patientId, req);

					if (inboxSendRes != null && inboxSendRes.getErrorCode() != null
							&& inboxSendRes.getErrorCode().equalsIgnoreCase("0")) {
						// Success

						if (inboxSendRes.getInboxMessages() != null && !inboxSendRes.getInboxMessages().isEmpty()) {

							for (IHealInboxMessageMini inboxMessage : inboxSendRes.getInboxMessages()) {
								int mesageId = inboxMessage.getMessageId();

								// Capture messageId in chart_details table
								// dashboardDAO.saveMessageIdInChartDetails(req.getVisitId(), new
								// Long(mesageId));
							}
						}

						if (inboxSendRes.getRecipientsUndelivered() != null
								&& !inboxSendRes.getRecipientsUndelivered().isEmpty()) {
							// Need to handle undelivered messages here
						}
					} else {
						// Error
						log.error("inboxSendRes : " + inboxSendRes);
					}
				} else if (req.getiHealConfig() != null && (req.getiHealConfig().equalsIgnoreCase("OT")
						|| req.getiHealConfig().equalsIgnoreCase("POS"))) {
					// Call i-heal UserInboxMessageSend API to notify Provider
					IHealUserInboxMessageSendRes inboxSendRes = providerInboxService
							.callUserInboxMessageSendAPIForOTPOSAuditor(providerIds, req.getVisitId(), facilityId,
									patientId, req);

					if (inboxSendRes != null && inboxSendRes.getErrorCode() != null
							&& inboxSendRes.getErrorCode().equalsIgnoreCase("0")) {
						// Success

						if (inboxSendRes.getInboxMessages() != null && !inboxSendRes.getInboxMessages().isEmpty()) {

							for (IHealInboxMessageMini inboxMessage : inboxSendRes.getInboxMessages()) {
								int mesageId = inboxMessage.getMessageId();

								// Capture messageId in chart_details table
								// dashboardDAO.saveMessageIdInChartDetails(req.getVisitId(), new
								// Long(mesageId));
							}
						}

						if (inboxSendRes.getRecipientsUndelivered() != null
								&& !inboxSendRes.getRecipientsUndelivered().isEmpty()) {
							// Need to handle undelivered messages here
						}
					} else {
						// Error
						log.error("inboxSendRes : " + inboxSendRes);
					}
				}

			}

			status = true;
		} catch (Exception e) {
			log.error("Exception occurred : {}", e.getMessage());
		}
		return status;
	}
	
	@Override
	public APIResponse addOrRemovePinnedFilter(addOrRemovePinnedFilterReq req) {
		APIResponse res = new APIResponse();
		try {
			auditorDashboardDAO.addOrRemovePinnedFilter(req);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (EncodeExceptionHandler e) {
			log.error("Exception occurred while add or remove pinned filter: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("Failed to add or remove pinned filter - " + e.getMessage());
		}
		return res;
	}


}
