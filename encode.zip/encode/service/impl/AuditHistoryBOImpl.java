package com.healogics.encode.service.impl;


import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.healogics.encode.constants.BOConstants.ERRORCODE;
import static com.healogics.encode.constants.BOConstants.ERRORMESSAGE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.AuditHistoryDAO;
import com.healogics.encode.dto.AuditHistoryData;
import com.healogics.encode.dto.AuditHistoryRes;
import com.healogics.encode.dto.AuditorCollapsibleSectionData;
import com.healogics.encode.dto.AuditorCollapsibleSectionRes;
import com.healogics.encode.dto.BillHistoryData;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.dto.BillHistoryRes;
import com.healogics.encode.dto.IHealCustomScanListReq;
import com.healogics.encode.dto.IHealGetVisitsReq;
import com.healogics.encode.dto.IHealVisitListGetRes;
import com.healogics.encode.dto.IHealVisitObject;
import com.healogics.encode.dto.VisitDocumentListReq;
import com.healogics.encode.dto.VisitObj;
import com.healogics.encode.dto.VisitsListRes;
import com.healogics.encode.entity.AuditQueue;
import com.healogics.encode.entity.SuperBillHistory;
import com.healogics.encode.service.AuditHistoryBO;
import com.healogics.encode.service.IHealNotificationBO;


@Service
public class AuditHistoryBOImpl implements AuditHistoryBO {
	
	private final Logger log = LoggerFactory.getLogger(HistoryTimelineBOImpl.class);
	
	@Value("${visit.end.date}")
	private String iHealVisitEndDate;
	
	private final AuditHistoryDAO auditHistoryDAO;
	private final IHealNotificationBO notificationBO;
	private final Environment env;
	private final RestTemplate restTemplate;
	
	@Autowired
	public AuditHistoryBOImpl(AuditHistoryDAO auditHistoryDAO, IHealNotificationBO notificationBO, Environment env,
			RestTemplate restTemplate) {
		this.auditHistoryDAO = auditHistoryDAO;
		this.notificationBO = notificationBO;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	@Override
	public AuditHistoryRes saveAuditHistory(AuditHistoryData data) {
		AuditHistoryRes res = new AuditHistoryRes();
		try {
			auditHistoryDAO.saveAuditHistory(data);
			res.setResponseCode("0");
			res.setResponseMessage("Success");
		} catch (Exception e) {
			log.error("Exception in saveHistoryTimeline: {}", e.getMessage());
		}
		return res;
	}
	
	private Timestamp getTimestampByDateStr(String dateStr) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Timestamp nextDaytTimestamp = null;
		try {
			log.debug("dateStr : " + dateStr);
			java.util.Date parsedDate = dateFormat.parse(dateStr);

			log.debug("parsedDate : " + parsedDate);
			log.debug("parsedDate.getTime : " + parsedDate.getTime());

			// Convert java.util.Date to java.sql.Timestamp
			Timestamp dosTimestamp = new Timestamp(parsedDate.getTime());

			log.debug("dosTimestamp : " + dosTimestamp);

			Calendar cal = Calendar.getInstance();
			cal.setTime(dosTimestamp);
			cal.add(Calendar.DATE, 1);

			nextDaytTimestamp = new Timestamp(cal.getTime().getTime());
			log.debug("nextDaytTimestamp : " + nextDaytTimestamp);

		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());
		}
		return nextDaytTimestamp;
	}

	@Override
	public BillHistoryRes getBillHistoryData(BillHistoryReq req) {
		BillHistoryRes res = new BillHistoryRes();
		List<BillHistoryData> billHistory = new ArrayList<>();
		
		log.debug("Starting bill history data for request : {}", req);
		try {
			List<SuperBillHistory> billHistorydatas = auditHistoryDAO.getBillHistoryData(
					req, getTimestampByDateStr(iHealVisitEndDate));
			
			Map<Long, BillHistoryData> billHistoryMap = new HashMap<>();
			
			String patientFullName = "";
			String patientFirstName = "";
			String patientLastName = "";
			String facilityName = "";
			Date patientDOB = null;
			String patientMRN = "";
			String bluebookId = "";
			
			log.debug("billHistorydatas : " +billHistorydatas);
			
			if (billHistorydatas != null && billHistorydatas.size() > 0) {
				
				log.debug("billHistorydatas.size : " +billHistorydatas.size());
				
				for (SuperBillHistory superbillhistory : billHistorydatas) {
					BillHistoryData data = new BillHistoryData();

					data.setVisitId(superbillhistory.getVisitId());
					data.setPatientDOS(superbillhistory.getPatientDOS());
					data.setPatientId(superbillhistory.getPatientId());
					data.setFacilityId(superbillhistory.getFacilityId());
					data.setFacilityName(superbillhistory.getFacilityName());
					data.setBluebookId(superbillhistory.getBluebookId());
					data.setPatientFirstName(superbillhistory.getPatientFirstName());
					data.setPatientLastName(superbillhistory.getPatientLastName());
					data.setPatientFullName(superbillhistory.getPatientFullName());
					data.setPatientDob(superbillhistory.getPatientDob());
					data.setPatientMrn(superbillhistory.getPatientMrn());
					data.setStatus(superbillhistory.getStatus());
					data.setCreatedTimestamp(superbillhistory.getCreatedTimestamp());
					data.setLastUpdatedTimestamp(superbillhistory.getLastUpdatedTimestamp());
					data.setClaimSentDate(superbillhistory.getClaimSentDate());
					data.setLastUpdatedByUser(superbillhistory.getLastUpdatedByUser());
					
					if (superbillhistory.getProviderId() == null) {
						data.setProviderId("");
					} else {
						data.setProviderId(Long.toString(superbillhistory.getProviderId()));
					}
					
					String providerFullName = (superbillhistory.getProviderLastName() != null
							? superbillhistory.getProviderLastName() : "")
						+ (superbillhistory.getProviderFirstName() != null
									? ", " + superbillhistory.getProviderFirstName() : "");
					
					if (providerFullName == null || providerFullName.trim().isEmpty()) {
						data.setProviderName("");
					} else {
						data.setProviderName(providerFullName);
					}

					billHistoryMap.put(data.getVisitId(), data);

					patientFirstName = data.getPatientFirstName();
					patientLastName = data.getPatientLastName();
					patientFullName = data.getPatientFullName();
					facilityName = data.getFacilityName();
					patientDOB = data.getPatientDob();
					patientMRN = data.getPatientMrn();
					bluebookId = data.getBluebookId();
				}
			}
			
			//log.debug("receive bill history data for DAO : {}", billHistorydatas);
			VisitsListRes visitsListRes = getVisitsList(req);
			
			if (visitsListRes != null && visitsListRes.getVisitList() != null) {
				// log.debug("visit list retrieve successfully: {}",
				// visitsListRes.getVisitList());
				List<VisitObj> visitList = visitsListRes.getVisitList();
				
				for (VisitObj visit : visitList) {
					BillHistoryData visitHistory = new BillHistoryData();
					
					visitHistory.setiHealVisit(true);
					visitHistory.setVisitId(visit.getVisitId());
					visitHistory.setPatientDOS(visit.getPatientDOS());
					visitHistory.setPatientDOSStr(visit.getPatientDOSStr());
					visitHistory.setProviderName(visit.getProviderName());
					visitHistory.setProviderId(visit.getProviderId());
					
					visitHistory.setFacilityName(facilityName);
					visitHistory.setBluebookId(bluebookId);
					visitHistory.setPatientFullName(patientFullName);
					visitHistory.setPatientFirstName(patientFirstName);
					visitHistory.setPatientLastName(patientLastName);
					visitHistory.setPatientDob(patientDOB);
					visitHistory.setPatientMrn(patientMRN);
					
					billHistoryMap.put(visitHistory.getVisitId(), visitHistory);
				}
			}
			
			billHistory.addAll(billHistoryMap.values());
			Collections.sort(billHistory, new Comparator<BillHistoryData>() {
				@Override
				public int compare(BillHistoryData o1, BillHistoryData o2) {
					return o1.getVisitId().compareTo(o2.getVisitId());
				}
			});
			

			res.setBillHistoryData(billHistory);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while fetching billhistory data:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	
	public VisitsListRes getVisitsList(BillHistoryReq req) {

		SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");

		VisitsListRes response = new VisitsListRes();
		IHealVisitListGetRes visitListRes = null;
		
		String url = env.getProperty(BOConstants.IHEAL_VISIT_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq.setEndDate(iHealVisitEndDate);
		
		log.debug("customScanReq : " +customScanReq);
		
		try {
			log.info("IHeal VisitListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq, getHeaders());
			assert url != null;
			ResponseEntity<IHealVisitListGetRes> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request,
					IHealVisitListGetRes.class);
			log.info("IHeal VisitListGet URL post Completed ");
			log.debug("iHeal VisitListGet Response : {}", sresponse.getBody());
			visitListRes = sresponse.getBody();

		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in VisitListGet API - ", e);
			visitListRes = new IHealVisitListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			visitListRes.setErrorCode(errorResponse.get(ERRORCODE));
			visitListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));

		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in VisitListGet API: ", e);
			visitListRes = new IHealVisitListGetRes();
			HashMap<String, String> errorResponse = extractResponse(e.getResponseBodyAsString());
			visitListRes.setErrorCode(errorResponse.get(ERRORCODE));
			visitListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		log.debug("visitListRes: " +visitListRes);
		List<VisitObj> visitList = new ArrayList<>();
		
		if (visitListRes != null && visitListRes.getErrorCode() != null
				&& visitListRes.getErrorCode().equalsIgnoreCase("0")) {
			
			List<IHealVisitObject> visitObjs = (List<IHealVisitObject>) visitListRes.getVisits();
			
			if (visitObjs != null && !visitObjs.isEmpty()) {
				for (IHealVisitObject iHealObj : visitObjs) {

					VisitObj doc = new VisitObj();
					doc.setVisitId((long) iHealObj.getVisitId());
					doc.setFacilityId(Integer.parseInt(req.getFacilityId()));
					
					String visitDateTimeStr = iHealObj.getVisitDateTime();
					
					doc.setPatientDOS(null);
					doc.setPatientDOSStr(visitDateTimeStr);
					doc.setProviderId(String.valueOf(iHealObj.getProviderId()));
					doc.setPatientId(Long.parseLong(req.getPatientId()));
					doc.setProviderName(iHealObj.getProviderLastName()
							+ ", " + iHealObj.getProviderFirstName());

					visitList.add(doc);
				}
				response.setResponseCode("0");
				response.setResponseMessage(BOConstants.SUCCESS);
			}

			response.setVisitList(visitList);

		} else if (visitListRes != null && visitListRes.getErrorCode() != null
				&& !visitListRes.getErrorCode().equalsIgnoreCase("0")) {
			response.setResponseCode(visitListRes.getErrorCode());
			response.setResponseMessage(visitListRes.getErrorMessage());
		} else {
			response.setResponseCode("25");
			response.setResponseMessage("Invalid Response");
		}

		if (response.getVisitList() != null && response.getVisitList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Visits found!");
		}

		return response;
	}
     
     private HashMap<String, String> extractResponse(String responseBody) {
 		HashMap<String, String> data = new HashMap<>();
 		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
 		String[] arr = body.split(",");
 		for (String tmp : arr) {
 			data.put(tmp.substring(0, tmp.indexOf(':')), tmp.substring(tmp.indexOf(':') + 1));
 		}
 		return data;
 	}
     
     private HttpHeaders getHeaders() {
 		HttpHeaders headers = new HttpHeaders();
 		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
 		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
 		return headers;
 	}

}

	