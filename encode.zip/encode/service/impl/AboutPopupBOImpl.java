package com.healogics.encode.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.healogics.encode.constants.BOConstants;
import com.healogics.encode.dao.AboutPopupDAO;
import com.healogics.encode.dto.Build;
import com.healogics.encode.dto.BuildDetailsResponse;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.SaveBuildDetailsReq;
import com.healogics.encode.entity.BuildDetails;
import com.healogics.encode.repository.BuildDetailsRepository;
import com.healogics.encode.service.AboutPopupBO;
 
@Service
public class AboutPopupBOImpl implements AboutPopupBO {

	private final Logger log = LoggerFactory.getLogger(AboutPopupBOImpl.class);

	private final Environment env;

	private final BuildDetailsRepository buildRepo;

	private final AboutPopupDAO aboutPopupDAO;

	@Autowired
	public AboutPopupBOImpl(Environment env, BuildDetailsRepository buildRepo, AboutPopupDAO aboutPopupDAO) {
		this.env = env;
		this.buildRepo = buildRepo;
		this.aboutPopupDAO = aboutPopupDAO;
	}

	@Override
	public BuildDetailsResponse getBuildDetails() {
		BuildDetailsResponse bd = new BuildDetailsResponse();

		try {
			String appEnv = env.getProperty(BOConstants.APP_ENV);

			if (appEnv == null) {
				appEnv = "UAT";
			}

			String apiKey = "Encode" + "#" + appEnv + "#" + "API";
			String uiKey = "Encode" + "#" + appEnv + "#" + "UI";

			BuildDetails apiBuild = buildRepo.getBuildByKey(apiKey);
			log.info("API Key:  {}", apiKey);
			log.info("API Build: {}", apiBuild);
			
			BuildDetails uiBuild = buildRepo.getBuildByKey(uiKey);
			log.info("UI Key: {}", uiKey);
			log.info("UI Build: {}", uiBuild);
			
			if (apiBuild != null) {
				Build api = new Build();
				api.setVersion(apiBuild.getBuildVersion());
				api.setCommitId(apiBuild.getApplicationVersion());
				bd.setApi(api);
			}

			if (uiBuild != null) {
				Build ui = new Build();
				ui.setVersion(uiBuild.getBuildVersion());
				ui.setCommitId(uiBuild.getApplicationVersion());
				bd.setUi(ui);
			}
			bd.setResponseCode("0");
			bd.setResponseDesc(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
			bd = null;
		}

		return bd;
	}

	@Override
	public NotesRes saveBuildDetails(SaveBuildDetailsReq req) {
		NotesRes res = new NotesRes();
		try {
			aboutPopupDAO.saveBuildDetails(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while Saving Notes Details: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

}
