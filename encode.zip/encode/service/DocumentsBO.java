package com.healogics.encode.service;

import org.springframework.web.multipart.MultipartFile;

import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.DBDocumentContentRes;
import com.healogics.encode.dto.DBDocumentListReq;
import com.healogics.encode.dto.DBDocumentListRes;
import com.healogics.encode.dto.DocumentDeleteReq;
import com.healogics.encode.dto.DocumentDeleteRes;
import com.healogics.encode.dto.DocumentURLReq;
import com.healogics.encode.dto.DocumentURLRes;
import com.healogics.encode.dto.DocumentsListReq;
import com.healogics.encode.dto.IHealDocumentRes;
import com.healogics.encode.dto.IHealVisitDocumentRes;
import com.healogics.encode.dto.VisitDocumentListReq;
import com.healogics.encode.dto.WoundListRes;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface DocumentsBO {

	IHealDocumentRes getProgressNotesLoad(DocumentsListReq req) throws EncodeExceptionHandler;

	IHealDocumentRes getIHealWoundAssessmentLoad(DocumentsListReq req) throws EncodeExceptionHandler;

	IHealDocumentRes getDebridementLoad(DocumentsListReq req) throws EncodeExceptionHandler;

	public DocumentURLRes getDocumentURL(DocumentURLReq req);

	WoundListRes getIHealWoundList(DocumentsListReq req) throws EncodeExceptionHandler;

	DBDocumentListRes getDocumentList(DBDocumentListReq req) throws EncodeExceptionHandler;
	
	DBDocumentContentRes getDocumentContent(DBDocumentListReq req) throws EncodeExceptionHandler;
	
	public APIResponse uploadDocuments(MultipartFile[] files, String dashboardName);

	IHealVisitDocumentRes getVisitDocumentList(VisitDocumentListReq req) throws EncodeExceptionHandler;

	DocumentDeleteRes deleteDocumentList(DocumentDeleteReq req)throws EncodeExceptionHandler;

}
