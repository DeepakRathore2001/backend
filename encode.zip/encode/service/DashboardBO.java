package com.healogics.encode.service;

import com.healogics.encode.dto.NotesListRes;
import com.healogics.encode.dto.NoteListReq;
import com.healogics.encode.dto.NotesDetailsRes;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.dto.CPTCodesResponse;
import com.healogics.encode.dto.CPTDataResponse;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.ChartValidationRes;
import com.healogics.encode.dto.EscalatedChartDetailsReq;
import com.healogics.encode.dto.EscalatedChartRes;
import com.healogics.encode.dto.EscalationDetailsRes;
import com.healogics.encode.dto.ICD10Response;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.InsuranceDetailsReq;
import com.healogics.encode.dto.InsuranceDetailsRes;
import com.healogics.encode.dto.LastAppliedFilterRes;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.RetrieveNotesListRes;
import com.healogics.encode.dto.SaveRecordReq;
import com.healogics.encode.dto.SaveRecordRes;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface DashboardBO {
	public SaveRecordRes saveRecord(SaveRecordReq req);
	
	public NotesRes saveNotes(NotesReq req);

	public NotesListRes getCMCRetrieveNote(NoteListReq req,
			String userRole, int index);
	
	public ReasonsRes getWeaknessReasons();
	
	public ReasonsRes getDeficiencyList();
	
	public ReasonsRes getEscalateReasonsList();

	public SaveRecordRes saveChartDetails(ChartDetailsReq req);

	public ReasonsRes getModifiersReasonsList();
	
	public ICD10Response searchICD10Codes(String searchText, int searchType,
			int offset, int count);

	public CPTDataResponse getCPTCodes(ChartDetailsReq req);
	
	public CPTCodesResponse searchCPTCodes(String searchText)
			throws EncodeExceptionHandler;
	
	public EscalatedChartRes searchEscalatedChart(EscalatedChartDetailsReq req,
			int index, String taskType,
			String username, String masterToken, String assignee);
	
	public LastAppliedFilterRes getLastAppliedFilter(long userId);
	
	public EscalationDetailsRes getEscalationDetails(Long visitId);
	
	public ChartValidationRes validateChart(ChartDetailsReq req);
	
	public NotesDetailsRes getNoteByNoteId(Long visitId, int noteId);

	public RetrieveNotesListRes getRetrieveNote(NoteListReq req, String userRole, int index);

	public InsuranceDetailsRes getInsuranceDetails(IHealPatientLoadReq req);
}
