package com.healogics.encode.service;

import com.healogics.encode.dto.AuditHistoryData;
import com.healogics.encode.dto.AuditHistoryRes;
import com.healogics.encode.dto.BillHistoryReq;
import com.healogics.encode.dto.BillHistoryRes;
import com.healogics.encode.dto.IHealGetVisitsReq;
import com.healogics.encode.dto.VisitDocumentListReq;

public interface AuditHistoryBO {

	AuditHistoryRes saveAuditHistory(AuditHistoryData data);

	BillHistoryRes getBillHistoryData(BillHistoryReq req);

}
