package com.healogics.encode.service;

import com.healogics.encode.dto.HistoryTimeLineListRes;
import com.healogics.encode.dto.HistoryTimelineData;

public interface HistoryTimelineBO {
	public HistoryTimeLineListRes getHistoryTimeline(int index, long visitId);
	public void saveHistoryTimeline(HistoryTimelineData history);
}
