package com.healogics.encode.service;

import java.util.List;

import com.healogics.encode.dto.AdminDashboardFilterOptionsRes;
import com.healogics.encode.dto.AdminDashboardReq;
import com.healogics.encode.dto.AdminDashboardRes;
import com.healogics.encode.dto.AdministrationEncodeUsersRes;
import com.healogics.encode.dto.CampusIndicatorReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.EncodeRolesRes;
import com.healogics.encode.dto.FacilityDetailsReq;
import com.healogics.encode.dto.FacilitySettingsFilterOptionsRes;
import com.healogics.encode.dto.FacilitySettingsRes;
import com.healogics.encode.dto.NotesRes;
import com.healogics.encode.dto.NurseRoleResponse;
import com.healogics.encode.dto.RoleAssignmentRes;

public interface AdministrationBO {

	public AdministrationEncodeUsersRes getCoderUsers(DashboardReq req);

	public AdminDashboardRes getEncodeUsers(boolean isFilter, AdminDashboardReq adminDashboardReq, int index, boolean isExport);

	public AdminDashboardFilterOptionsRes getSearchFilterOptions(AdminDashboardReq req);

	public RoleAssignmentRes saveRoleAssignment(AdminDashboardReq req);
	
	public EncodeRolesRes getEncodeRoles();

	public NurseRoleResponse getNurseUsers(DashboardReq req);
	
	public FacilitySettingsRes getFacilitySettings();
	
	public FacilitySettingsRes getFacilitySettingsFilterData(boolean isFilter, FacilityDetailsReq Req, int index, boolean isExport);

	public FacilitySettingsFilterOptionsRes getFacilitySettingsFilterOptions(FacilityDetailsReq req);


	public NotesRes UpdateCampusIndicator(CampusIndicatorReq req);

}
