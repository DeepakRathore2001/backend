package com.healogics.encode.service;

import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.CoderChartRes;
import com.healogics.encode.dto.CoderDashboardFilterRes;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.CoderDashboardRes;
import com.healogics.encode.dto.CollapsibleSectionRes;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptionsRes;
import com.healogics.encode.dto.FilterResultRes;
import com.healogics.encode.dto.LockRecordRes;
import com.healogics.encode.dto.PlaceOfServiceRes;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.SearchCoderDashboardRes;
import com.healogics.encode.dto.SuperBillReq;
import com.healogics.encode.dto.SuperBillRes;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.entity.CollapsibleFilterRes;
import com.healogics.encode.exception.EncodeExceptionHandler;


public interface CoderDashboardBO {

	CoderDashboardRes getCoderData(boolean isFilter, CoderDashboardReq coderDashboardReq, int index, String taskType,
			String username, String masterToken, CoderDashboardReq coderDashboardReq2);

	CollapsibleSectionRes getCollapsibleSectionDetails(String bbc,
			String assigneeName, String taskType, DashboardReq req) throws EncodeExceptionHandler;

	ReasonsRes getUnbillableReasons();
	PlaceOfServiceRes getplaceOfServices();

	CoderDashboardFilterRes getCoderDashboardFilterOptions(CoderDashboardReq req);

	//res getAllCoderData(boolean isFilter, DashboardReq req, int index, String taskType,
		//	String assignee);
	public UserFacilityRes getUserFacilities(String userId,
			String masterToken);
	
	public LockRecordRes saveLockStatus (DashboardReq req);

	public SearchCoderDashboardRes searchCoderData(
			CoderDashboardReq coderDashboardReq);
	
	public CoderChartRes getCoderRecordById(Long visitId, CoderDashboardReq req);

	public CollapsibleFilterRes getCollapsibleFilterOption(DashboardReq req, String bbc);

	CollapsibleSectionRes getCollapsibleFilteredData(boolean isFilter, DashboardReq req, int index, String taskType, String assignee,
			String masterToken, boolean isApplyPagination, String bbc);

	CollapsibleFilterRes advanceSearchFilterOption(CoderDashboardReq req);

	SearchCoderDashboardRes searchCoderfilterData(CoderDashboardReq req);

	CoderDashboardRes getCoderDatas(boolean isFilter, CoderDashboardReq coderDashboardReq, int index, String taskType,
			String username, String masterToken, CoderDashboardReq coderDashboardReq2);

	FilterOptionsRes getCoderDashboardFilterOption(CoderDashboardReq req);

	CoderDashboardRes getAllCoderDataForExcel(boolean isFilter, CoderDashboardReq req, int index, String taskType,
			String assignee);


	SuperBillRes getSuperBillByVersion(SuperBillReq req);

}
