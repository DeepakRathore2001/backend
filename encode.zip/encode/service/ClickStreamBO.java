package com.healogics.encode.service;

import com.healogics.encode.dto.ClickStreamReq;
import com.healogics.encode.dto.ClickStreamRes;

public interface ClickStreamBO {

	ClickStreamRes saveClickStreamData(ClickStreamReq req);

}
