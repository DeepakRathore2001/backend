package com.healogics.encode.service;

import java.time.Instant;
import java.util.List;

import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.IHealGetVisitsReq;
import com.healogics.encode.dto.IHealPatientLoadReq;
import com.healogics.encode.dto.IHealPatientLoadRes;
import com.healogics.encode.dto.IHealSuperBillLoadReq;
import com.healogics.encode.dto.IHealVisitLoadRes;
import com.healogics.encode.dto.PatientLoadRes;
import com.healogics.encode.dto.PlaceOfServiceRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ReloadPatientInsuranceReq;
import com.healogics.encode.dto.ReloadRequest;
import com.healogics.encode.dto.SuperBillLoadRes;
import com.healogics.encode.entity.ReloadCMCMetrics;
import com.healogics.encode.entity.ReloadCoderMetrics;
import com.healogics.encode.dto.IHealNotificationReq;

public interface IHealNotificationBO {

	String validateNotificationReq(
			IHealNotificationReq superbillNotReq);

	boolean consumeNotificationData(
			IHealNotificationReq superbillNotReq, Instant serviceStart);

	IHealPatientLoadRes getPatientLoad(IHealPatientLoadReq patientSearchReq);

	IHealVisitLoadRes getVisits(IHealGetVisitsReq req);

	PatientLoadRes getPatientFromIHeal(
			IHealPatientLoadReq patientSearchReq);

	SuperBillLoadRes getSuperBillLoad(IHealSuperBillLoadReq superBillLoadReq);

	PlaceOfServiceRes getPlaceOfServices(ProviderListReq req);
	
	public boolean reloadSuperBillNotification(ReloadRequest req);
	
	public boolean reloadDocumentNotification(ReloadRequest req);

	APIResponse reloadPatientInsurance(ReloadPatientInsuranceReq req);
	
	public boolean reloadCMCChart(ReloadCMCMetrics cmcMetrics);
	
	public boolean reloadCoderChart(ReloadCoderMetrics coderMetrics);
	
	public boolean reloadCmc(ReloadRequest req);
	
	public boolean reloadCoder(ReloadRequest req);
	
	

	APIResponse reloadPatient(ReloadPatientInsuranceReq req);

	APIResponse reloadDeficiency(ReloadPatientInsuranceReq req);

}
