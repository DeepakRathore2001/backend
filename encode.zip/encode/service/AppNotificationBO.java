package com.healogics.encode.service;

import com.healogics.encode.dto.APIResponse;
import com.healogics.encode.dto.AppNotificationCountRes;
import com.healogics.encode.dto.AppNotificationListRes;
import com.healogics.encode.dto.AppNotificationsReq;
import com.healogics.encode.dto.ChartDetailsReq;
import com.healogics.encode.dto.NotesReq;
import com.healogics.encode.dto.SaveAuditDetailsReq;

public interface AppNotificationBO {
	public Boolean saveAppNotifications(NotesReq req, int noteId);

	public Boolean saveEscalateAppNotifications(ChartDetailsReq req);

	public APIResponse updateNotifications(AppNotificationsReq req);

	public AppNotificationListRes getAppNotifications(AppNotificationsReq req);

	public AppNotificationCountRes isNotificationExists(String userId);
	
	public Boolean saveWeaknessAppNotifications(ChartDetailsReq req);

	public Boolean saveWeaknessAppNotificationsAuditor(SaveAuditDetailsReq req);
	
}
