package com.healogics.encode.service;

import java.util.List;

import com.healogics.encode.dto.IHealPatientHSPBalanceDueSaveReq;
import com.healogics.encode.dto.IHealPatientHSPBalanceDueSaveRes;
import com.healogics.encode.dto.ParsedDataDTO;
import com.healogics.encode.dto.SNSNotificationDetails;
import com.healogics.encode.dto.SNSNotificationResponse;

public interface ECWService {
	public SNSNotificationResponse processeCWNotifcation(SNSNotificationDetails req);

	List<ParsedDataDTO> parseFile(String filePath);

	public IHealPatientHSPBalanceDueSaveRes testIhealPatientHSPBalanceDueSave(IHealPatientHSPBalanceDueSaveReq req);
	
	public boolean processHistoricalPatientBalanceCSVs();

	
}
