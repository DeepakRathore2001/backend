package com.healogics.encode.service;

import java.util.List;

import com.healogics.encode.dto.CMCDashboardRes;
import com.healogics.encode.dto.CMCData;
import com.healogics.encode.dto.CoderDashboardReq;
import com.healogics.encode.dto.DashboardReq;
import com.healogics.encode.dto.FilterOptionsRes;
import com.healogics.encode.dto.ProviderListReq;
import com.healogics.encode.dto.ProviderListRes;
import com.healogics.encode.dto.ReasonsRes;
import com.healogics.encode.dto.UserFacilityRes;
import com.healogics.encode.exception.EncodeExceptionHandler;

public interface CMCDashboardBO {

	CMCDashboardRes getCMCData(boolean isFilter, DashboardReq dashboardReq, int index, String taskType,
			String username, String masterToken, boolean isApplyPagination);

	public FilterOptionsRes getSearchFilterOptions(DashboardReq req) throws EncodeExceptionHandler;

	public CMCDashboardRes getAllCMCData(boolean isFilter, DashboardReq req, int index, String taskType,
			String assignee, boolean isApplyPagination);

	ReasonsRes getPendingReasons();

	ProviderListRes getProvidersNames(ProviderListReq req);
	
	CMCData getCMCRecordById(DashboardReq req) throws EncodeExceptionHandler;
	
	public UserFacilityRes getUserFacilities(String userId,
			String masterToken);

	ReasonsRes getCMCUnbillableReasons();

	ProviderListRes getProvidersNamesList(ProviderListReq req);

}
