package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "jobs_heartbeat")
public class JobsHeartBeat {

	@Id
	@Column(name = "job_name")
	private String jobName;

	@Column(name = "table_name")
	private String tableName;

	@Column(name = "start_time")
	private Timestamp startTime;

	@Column(name = "end_time")
	private Timestamp endTime;

	@Column(name = "next_scheduled_at")
	private Timestamp nextScheduledAt;

	@Column(name = "duration_mins")
	private Integer durationMins;

	@Column(name = "duration_secs")
	private Integer durationSecs;

	@Column(name = "status")
	private String status;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "duration_millisecs")
	private Integer durationMillisecs;

	public Integer getDurationMillisecs() {
		return durationMillisecs;
	}

	public void setDurationMillisecs(Integer durationMillisecs) {
		this.durationMillisecs = durationMillisecs;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public Timestamp getNextScheduledAt() {
		return nextScheduledAt;
	}

	public void setNextScheduledAt(Timestamp nextScheduledAt) {
		this.nextScheduledAt = nextScheduledAt;
	}

	public int getDurationMins() {
		return durationMins;
	}

	public void setDurationMins(int durationMins) {
		this.durationMins = durationMins;
	}

	public int getDurationSecs() {
		return durationSecs;
	}

	public void setDurationSecs(int durationSecs) {
		this.durationSecs = durationSecs;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "JobsHeartBeat [jobName=" + jobName + ", tableName=" + tableName + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", nextScheduledAt=" + nextScheduledAt + ", durationMins=" + durationMins
				+ ", durationSecs=" + durationSecs + ", status=" + status + ", errorMessage=" + errorMessage + "]";
	}

}
