package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document_request")
public class DocumentRequest {
	@Id
	@Column(name = "request_id")
	private String requestId;

	@Column(name = "facility_id")
	private Integer facilityId;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "vendor_order_no")
	private String vendorOrderNo;
	
	@Column(name = "vendor_customer_no")
	private String vendorCustomerNo;
	
	@Column(name = "patient_first_name")
	private String patientFirstName;
	
	@Column(name = "patient_last_name")
	private String patientLastName;
	
	@Column(name = "patient_name")
	private String patientName;
	
	@Column(name = "medical_record_number")
	private String medicalRecordNumber;
	
	@Column(name = "documents", columnDefinition = "json")
	private String documents;
	
	@Column(name = "order_source")
	private String orderSource;
	
	@Column(name = "woundq_order_token")
	private String woundqOrderToken;
	
	@Column(name = "woundq_order_no")
	private String woundqOrderNo;
	
	@Column(name = "patient_id")
	private Integer patientId;
	
	@Column(name = "vendor_id")
	private Integer vendorId;
	
	@Column(name = "visit_id")
	private Long visitId;
	
	@Column(name = "visit_date")
	private Timestamp visitDate;
	
	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getVendorOrderNo() {
		return vendorOrderNo;
	}

	public void setVendorOrderNo(String vendorOrderNo) {
		this.vendorOrderNo = vendorOrderNo;
	}

	public String getVendorCustomerNo() {
		return vendorCustomerNo;
	}

	public void setVendorCustomerNo(String vendorCustomerNo) {
		this.vendorCustomerNo = vendorCustomerNo;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getWoundqOrderToken() {
		return woundqOrderToken;
	}

	public void setWoundqOrderToken(String woundqOrderToken) {
		this.woundqOrderToken = woundqOrderToken;
	}

	public String getWoundqOrderNo() {
		return woundqOrderNo;
	}

	public void setWoundqOrderNo(String woundqOrderNo) {
		this.woundqOrderNo = woundqOrderNo;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Timestamp getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Timestamp visitDate) {
		this.visitDate = visitDate;
	}
	
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	@Override
	public String toString() {
		return "DocumentRequest [requestId=" + requestId + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", vendorOrderNo=" + vendorOrderNo + ", vendorCustomerNo=" + vendorCustomerNo + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName + ", patientName=" + patientName
				+ ", medicalRecordNumber=" + medicalRecordNumber + ", documents=" + documents + ", orderSource="
				+ orderSource + ", woundqOrderToken=" + woundqOrderToken + ", woundqOrderNo=" + woundqOrderNo
				+ ", patientId=" + patientId + ", vendorId=" + vendorId + ", visitId=" + visitId + ", visitDate="
				+ visitDate + ", createdTimestamp=" + createdTimestamp + "]";
	}
}
