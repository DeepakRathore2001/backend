package com.healogics.rtrv.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "npwt_report")
public class NPWTReport {

	@Id
	@Column(name = "ro_no")
	private long roNo;

	@Column(name = "bluebook_code")
	private String bluebookCode;

	@Column(name = "hl_wq_order_no")
	private long hlWqOrderNo;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "first_received_date")
	private Date firstReceivedDate;

	@Column(name = "documents_first_sent")
	private Date documentsFirstSent;

	@Column(name = "documents_last_sent")
	private Date documentsLastSent;

	@Column(name = "vendor_status")
	private String vendorStatus;

	@Column(name = "retrieve_status")
	private String retrieveStatus;

	@Column(name = "num_of_files_sent")
	private int filesSent;

	public String getBluebookCode() {
		return bluebookCode;
	}

	public void setBluebookCode(String bluebookCode) {
		this.bluebookCode = bluebookCode;
	}

	public long getHlWqOrderNo() {
		return hlWqOrderNo;
	}

	public void setHlWqOrderNo(long hlWqOrderNo) {
		this.hlWqOrderNo = hlWqOrderNo;
	}

	public long getRoNo() {
		return roNo;
	}

	public void setRoNo(long roNo) {
		this.roNo = roNo;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getFirstReceivedDate() {
		return firstReceivedDate;
	}

	public void setFirstReceivedDate(Date firstReceivedDate) {
		this.firstReceivedDate = firstReceivedDate;
	}

	public Date getDocumentsFirstSent() {
		return documentsFirstSent;
	}

	public void setDocumentsFirstSent(Date documentsFirstSent) {
		this.documentsFirstSent = documentsFirstSent;
	}

	public Date getDocumentsLastSent() {
		return documentsLastSent;
	}

	public void setDocumentsLastSent(Date documentsLastSent) {
		this.documentsLastSent = documentsLastSent;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public int getFilesSent() {
		return filesSent;
	}

	public void setFilesSent(int filesSent) {
		this.filesSent = filesSent;
	}

	@Override
	public String toString() {
		return "NPWTReport [roNo=" + roNo + ", bluebookCode=" + bluebookCode + ", hlWqOrderNo=" + hlWqOrderNo
				+ ", patientName=" + patientName + ", firstReceivedDate=" + firstReceivedDate + ", documentsFirstSent="
				+ documentsFirstSent + ", documentsLastSent=" + documentsLastSent + ", vendorStatus=" + vendorStatus
				+ ", retrieveStatus=" + retrieveStatus + ", filesSent=" + filesSent + "]";
	}

}
