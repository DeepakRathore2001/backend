package com.healogics.rtrv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "byram_notes")
public class BHCNotes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "note_id")
	private Long noteId;

	@Column(name = "bhc_medical_record_id")
	private Long bhcMedicalRecordId;

	@Column(name = "bhc_invoice_order_no")
	private Long bhcInvoiceOrderId;

	@Column(name = "bhc_document_status")
	private String bhcDocumentStatus;

	@Column(name = "bhc_missing_doc_type")
	private String bhcMissingDocType;

	@Column(name = "bhc_missing_doc_notes")
	private String bhcMissingDocNotes;

	@Column(name = "bhc_missing_documents")
	private String bhcMissingDocuments;

	@Column(name = "addendum_received")
	private Boolean addendumReceived;

	@Column(name = "received_rx")
	private Boolean receivedRx;

	@Column(name = "patient_not_seen_30_days")
	private Boolean patientNotSeen30Days;

	public Long getNoteId() {
		return noteId;
	}

	public void setNoteId(Long noteId) {
		this.noteId = noteId;
	}

	public Long getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(Long bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public Long getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}

	public void setBhcInvoiceOrderId(Long bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}

	public String getBhcDocumentStatus() {
		return bhcDocumentStatus;
	}

	public void setBhcDocumentStatus(String bhcDocumentStatus) {
		this.bhcDocumentStatus = bhcDocumentStatus;
	}

	public String getBhcMissingDocType() {
		return bhcMissingDocType;
	}

	public void setBhcMissingDocType(String bhcMissingDocType) {
		this.bhcMissingDocType = bhcMissingDocType;
	}

	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}

	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}

	public String getBhcMissingDocuments() {
		return bhcMissingDocuments;
	}

	public void setBhcMissingDocuments(String bhcMissingDocuments) {
		this.bhcMissingDocuments = bhcMissingDocuments;
	}

	public Boolean getAddendumReceived() {
		return addendumReceived;
	}

	public void setAddendumReceived(Boolean addendumReceived) {
		this.addendumReceived = addendumReceived;
	}

	public Boolean getReceivedRx() {
		return receivedRx;
	}

	public void setReceivedRx(Boolean receivedRx) {
		this.receivedRx = receivedRx;
	}

	public Boolean getPatientNotSeen30Days() {
		return patientNotSeen30Days;
	}

	public void setPatientNotSeen30Days(Boolean patientNotSeen30Days) {
		this.patientNotSeen30Days = patientNotSeen30Days;
	}

	@Override
	public String toString() {
		return "ByramNotes [noteId=" + noteId + ", bhcMedicalRecordId="
				+ bhcMedicalRecordId + ", bhcInvoiceOrderId="
				+ bhcInvoiceOrderId + ", bhcDocumentStatus=" + bhcDocumentStatus
				+ ", bhcMissingDocType=" + bhcMissingDocType
				+ ", bhcMissingDocNotes=" + bhcMissingDocNotes
				+ ", bhcMissingDocuments=" + bhcMissingDocuments
				+ ", addendumReceived=" + addendumReceived + ", receivedRx="
				+ receivedRx + ", patientNotSeen30Days=" + patientNotSeen30Days
				+ "]";
	}

}
