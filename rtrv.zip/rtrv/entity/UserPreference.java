package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_preference")
public class UserPreference {

	@Id
	@Column(name = "user_id")
	private Long userId;

	@Column(name = "username")
	private String username;

	@Column(name = "service_line_code")
	private String serviceLineCode;

	@Column(name = "service_line_desc")
	private String serviceLineDesc;

	@Column(name = "awd_dashboard", columnDefinition = "json")
	private String awdDashboard;

	@Column(name = "npwt_dashboard", columnDefinition = "json")
	private String npwtDashboard;

	@Column(name = "ctp_dashboard", columnDefinition = "json")
	private String ctpDashboard;

	@Column(name = "created_timestamp")
	private LocalDateTime createdTimestamp;

	@Column(name = "user_full_name")
	private String userFullname;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "last_updated_timestamp")
	private LocalDateTime lastUpdatedTimestamp;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "facility_id")
	private Long facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "clear_notification")
	private Timestamp clearNotificationTimestamp;

	@Column(name = "avatar_color")
	private String avatarColor;
	
	@Column(name = "master_clear_notification")
	private Timestamp masterClearNotificationTimestamp;
	
	public Timestamp getMasterClearNotificationTimestamp() {
		return masterClearNotificationTimestamp;
	}

	public void setMasterClearNotificationTimestamp(Timestamp masterClearNotificationTimestamp) {
		this.masterClearNotificationTimestamp = masterClearNotificationTimestamp;
	}

	public String getAvatarColor() {
		return avatarColor;
	}

	public void setAvatarColor(String avatarColor) {
		this.avatarColor = avatarColor;
	}

	public Timestamp getClearNotificationTimestamp() {
		return clearNotificationTimestamp;
	}

	public void setClearNotificationTimestamp(
			Timestamp clearNotificationTimestamp) {
		this.clearNotificationTimestamp = clearNotificationTimestamp;
	}

	public String getServiceLineDesc() {
		return serviceLineDesc;
	}

	public void setServiceLineDesc(String serviceLineDesc) {
		this.serviceLineDesc = serviceLineDesc;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getServiceLineCode() {
		return serviceLineCode;
	}

	public void setServiceLineCode(String serviceLineCode) {
		this.serviceLineCode = serviceLineCode;
	}

	public String getAwdDashboard() {
		return awdDashboard;
	}

	public void setAwdDashboard(String awdDashboard) {
		this.awdDashboard = awdDashboard;
	}

	public String getNpwtDashboard() {
		return npwtDashboard;
	}

	public void setNpwtDashboard(String npwtDashboard) {
		this.npwtDashboard = npwtDashboard;
	}

	public String getCtpDashboard() {
		return ctpDashboard;
	}

	public void setCtpDashboard(String ctpDashboard) {
		this.ctpDashboard = ctpDashboard;
	}

	public LocalDateTime getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(LocalDateTime createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(LocalDateTime lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Long getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	@Override
	public String toString() {
		return "UserPreference [userId=" + userId + ", username=" + username
				+ ", serviceLineCode=" + serviceLineCode + ", serviceLineDesc="
				+ serviceLineDesc + ", awdDashboard=" + awdDashboard
				+ ", npwtDashboard=" + npwtDashboard + ", ctpDashboard="
				+ ctpDashboard + ", createdTimestamp=" + createdTimestamp
				+ ", userFullname=" + userFullname + ", createdBy=" + createdBy
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", lastUpdatedBy=" + lastUpdatedBy + ", facilityId="
				+ facilityId + ", bluebookId=" + bluebookId
				+ ", clearNotificationTimestamp=" + clearNotificationTimestamp
				+ ", masterClearNotificationTimestamp=" + masterClearNotificationTimestamp
				+ ", avatarColor=" + avatarColor + "]";
	}

}
