package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "documentation_history")
public class DocumentationHistory {

	@Id
	@Column(name = "document_id")
	private String documentId;

	@Column(name = "note_id")
	private int noteId;

	@Column(name = "bhc_medical_record_id")
	private int bhcMedicalRecordId;

	@Column(name = "bhc_invoice_order_no")
	private int bhcInvoiceOrderNo;

	@Column(name = "bhc_missing_doc_notes")
	private String bhcMissingDocNotes;

	@Column(name = "bhc_missing_doc_type")
	private String bhcMissingDocType;

	@Column(name = "bhc_document_status")
	private String bhcDocumentStatus;

	@Column(name = "retrieve_status")
	private String retrieveStatus;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Lob
	@Column(name = "user_notes")
	private String userNotes;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;

	@Column(name = "last_updated_userid")
	private Long lastUpdatedUserId;

	@Column(name = "record_active")
	private Boolean recordActive;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "facility_id")
	private Long facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "assigned_to")
	private String assignedTo;
	
	@Column(name = "addendum")
	private int addendum;
	
	@Column(name = "record_modify")
	private int recordModify;
	
	public int getAddendum() {
		return addendum;
	}

	public void setAddendum(int addendum) {
		this.addendum = addendum;
	}

	public int getRecordModify() {
		return recordModify;
	}

	public void setRecordModify(int recordModify) {
		this.recordModify = recordModify;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getUserNotes() {
		return userNotes;
	}

	public void setUserNotes(String userNotes) {
		this.userNotes = userNotes;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public Boolean getRecordActive() {
		return recordActive;
	}

	public void setRecordActive(Boolean recordActive) {
		this.recordActive = recordActive;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public Long getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getNoteId() {
		return noteId;
	}

	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}

	public int getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(int bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public int getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}

	public void setBhcInvoiceOrderNo(int bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}

	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}

	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}

	public String getBhcMissingDocType() {
		return bhcMissingDocType;
	}

	public void setBhcMissingDocType(String bhcMissingDocType) {
		this.bhcMissingDocType = bhcMissingDocType;
	}

	public String getBhcDocumentStatus() {
		return bhcDocumentStatus;
	}

	public void setBhcDocumentStatus(String bhcDocumentStatus) {
		this.bhcDocumentStatus = bhcDocumentStatus;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "DocumentationHistory [documentId=" + documentId + ", noteId="
				+ noteId + ", bhcMedicalRecordId=" + bhcMedicalRecordId
				+ ", bhcInvoiceOrderNo=" + bhcInvoiceOrderNo
				+ ", bhcMissingDocNotes=" + bhcMissingDocNotes
				+ ", bhcMissingDocType=" + bhcMissingDocType
				+ ", bhcDocumentStatus=" + bhcDocumentStatus
				+ ", retrieveStatus=" + retrieveStatus
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", userNotes=" + userNotes + ", lastUpdatedUsername="
				+ lastUpdatedUsername + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", recordActive=" + recordActive
				+ ", patientId=" + patientId + ", patientName=" + patientName
				+ ", patientDOB=" + patientDOB + ", facilityId=" + facilityId
				+ ", bluebookId=" + bluebookId + ", assignedTo=" + assignedTo
				+ "]";
	}

}
