package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_notification")
public class UserNotification {

	@Id
	@Column(name = "notification_id")
	private String notificationId;

	@Column(name = "user_id")
	private int userId;

	@Column(name = "user_notificationcol")
	private String userNotificationCol;

	@Column(name = "is_dismissed")
	private Boolean isDismissed;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserNotificationCol() {
		return userNotificationCol;
	}

	public void setUserNotificationCol(String userNotificationCol) {
		this.userNotificationCol = userNotificationCol;
	}

	public Boolean getIsDismissed() {
		return isDismissed;
	}

	public void setIsDismissed(Boolean isDismissed) {
		this.isDismissed = isDismissed;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	@Override
	public String toString() {
		return "UserNotification [notificationId=" + notificationId
				+ ", userId=" + userId + ", userNotificationCol="
				+ userNotificationCol + ", isDismissed=" + isDismissed
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + "]";
	}

}
