package com.healogics.rtrv.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document_status")
public class DocumentStatus {
	@Id
	@Column(name = "client_state")
	private String clientState;

	@Column(name = "iheal_job_id")
	private String ihealJobId;

	@Column(name = "bhc_medical_record_id")
	private Long bhcMedRecId;

	@Column(name = "bhc_invoice_order_no")
	private Long bhcInvOrderNo;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "pdf_filename")
	private String pdfFileName;

	@Column(name = "doc_req_status")
	private String docReqStatus;

	@Column(name = "doc_notification_status")
	private String docNotificationStatus;

	@Column(name = "send_to_byram_status")
	private String sendToByramStatus;

	@Column(name = "last_updated_timestamp")
	private LocalDateTime lastUpdatedTimestamp;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_user_id")
	private Long lastUpdatedUserId;

	@Column(name = "doc_pdf_request_timestamp")
	private LocalDateTime docPdfRequestTimestamp;

	@Column(name = "doc_notification_timestamp")
	private LocalDateTime docNotificationTimestamp;

	@Column(name = "doc_pdf_get_timestamp")
	private LocalDateTime docPdfGetTimestamp;

	@Column(name = "send_to_s3_timestamp")
	private LocalDateTime sendToS3Timestamp;

	@Column(name = "doc_submitted_by_username")
	private String docSubmittedByUsername;

	@Column(name = "doc_submitted_by_user_id")
	private Long docSubmittedByUserId;

	@Column(name = "doc_submitted_by_user_fullname")
	private String docSubmittedByUserFullname;

	@Column(name = "master_token")
	private String masterToken;

	@Column(name = "doc_pdf_get_status")
	private String docPDFGetStatus;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "bhc_ship_date")
	private Date bhcShipDate;

	@Column(name = "bhc_patient_acct_no")
	private Long bhcPatientAcctNo;

	@Column(name = "bhc_patient_inv")
	private String bhcPatientInv;

	@Column(name = "date_doc_sent")
	private Date dateDocSent;

	@Column(name = "visit_date")
	private Date visitDate;

	@Column(name = "documentation_history_note_id")
	private String documentationHistoryNoteId;

	@Column(name = "doc_upload_status")
	private String docUploadStatus;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "get_pdf_request_timestamp")
	private LocalDateTime getPDFRequestTimestamp;

	@Column(name = "get_pdf_response_timestamp")
	private LocalDateTime getPDFResponseTimestamp;

	public LocalDateTime getGetPDFRequestTimestamp() {
		return getPDFRequestTimestamp;
	}

	public void setGetPDFRequestTimestamp(
			LocalDateTime getPDFRequestTimestamp) {
		this.getPDFRequestTimestamp = getPDFRequestTimestamp;
	}

	public LocalDateTime getGetPDFResponseTimestamp() {
		return getPDFResponseTimestamp;
	}

	public void setGetPDFResponseTimestamp(
			LocalDateTime getPDFResponseTimestamp) {
		this.getPDFResponseTimestamp = getPDFResponseTimestamp;
	}

	public String getDocUploadStatus() {
		return docUploadStatus;
	}

	public void setDocUploadStatus(String docUploadStatus) {
		this.docUploadStatus = docUploadStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public Date getBhcShipDate() {
		return bhcShipDate;
	}

	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}

	public Long getBhcPatientAcctNo() {
		return bhcPatientAcctNo;
	}

	public void setBhcPatientAcctNo(Long bhcPatientAcctNo) {
		this.bhcPatientAcctNo = bhcPatientAcctNo;
	}

	public String getBhcPatientInv() {
		return bhcPatientInv;
	}

	public void setBhcPatientInv(String bhcPatientInv) {
		this.bhcPatientInv = bhcPatientInv;
	}

	public Date getDateDocSent() {
		return dateDocSent;
	}

	public void setDateDocSent(Date dateDocSent) {
		this.dateDocSent = dateDocSent;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public String getIhealJobId() {
		return ihealJobId;
	}

	public void setIhealJobId(String ihealJobId) {
		this.ihealJobId = ihealJobId;
	}

	public Long getBhcMedRecId() {
		return bhcMedRecId;
	}

	public void setBhcMedRecId(Long bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}

	public Long getBhcInvOrderNo() {
		return bhcInvOrderNo;
	}

	public void setBhcInvOrderNo(Long bhcInvOrderNo) {
		this.bhcInvOrderNo = bhcInvOrderNo;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getPdfFileName() {
		return pdfFileName;
	}

	public void setPdfFileName(String pdfFileName) {
		this.pdfFileName = pdfFileName;
	}

	public String getClientState() {
		return clientState;
	}

	public void setClientState(String clientState) {
		this.clientState = clientState;
	}

	public String getDocReqStatus() {
		return docReqStatus;
	}

	public void setDocReqStatus(String docReqStatus) {
		this.docReqStatus = docReqStatus;
	}

	public String getDocNotificationStatus() {
		return docNotificationStatus;
	}

	public void setDocNotificationStatus(String docNotificationStatus) {
		this.docNotificationStatus = docNotificationStatus;
	}

	public String getSendToByramStatus() {
		return sendToByramStatus;
	}

	public void setSendToByramStatus(String sendToByramStatus) {
		this.sendToByramStatus = sendToByramStatus;
	}

	public LocalDateTime getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(LocalDateTime lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public LocalDateTime getDocPdfRequestTimestamp() {
		return docPdfRequestTimestamp;
	}

	public void setDocPdfRequestTimestamp(
			LocalDateTime docPdfRequestTimestamp) {
		this.docPdfRequestTimestamp = docPdfRequestTimestamp;
	}

	public LocalDateTime getDocNotificationTimestamp() {
		return docNotificationTimestamp;
	}

	public void setDocNotificationTimestamp(
			LocalDateTime docNotificationTimestamp) {
		this.docNotificationTimestamp = docNotificationTimestamp;
	}

	public LocalDateTime getDocPdfGetTimestamp() {
		return docPdfGetTimestamp;
	}

	public void setDocPdfGetTimestamp(LocalDateTime docPdfGetTimestamp) {
		this.docPdfGetTimestamp = docPdfGetTimestamp;
	}

	public LocalDateTime getSendToS3Timestamp() {
		return sendToS3Timestamp;
	}

	public void setSendToS3Timestamp(LocalDateTime sendToS3Timestamp) {
		this.sendToS3Timestamp = sendToS3Timestamp;
	}

	public String getDocSubmittedByUsername() {
		return docSubmittedByUsername;
	}

	public void setDocSubmittedByUsername(String docSubmittedByUsername) {
		this.docSubmittedByUsername = docSubmittedByUsername;
	}

	public Long getDocSubmittedByUserId() {
		return docSubmittedByUserId;
	}

	public void setDocSubmittedByUserId(Long docSubmittedByUserId) {
		this.docSubmittedByUserId = docSubmittedByUserId;
	}

	public String getDocSubmittedByUserFullname() {
		return docSubmittedByUserFullname;
	}

	public void setDocSubmittedByUserFullname(
			String docSubmittedByUserFullname) {
		this.docSubmittedByUserFullname = docSubmittedByUserFullname;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getDocPDFGetStatus() {
		return docPDFGetStatus;
	}

	public void setDocPDFGetStatus(String docPDFGetStatus) {
		this.docPDFGetStatus = docPDFGetStatus;
	}

	public String getDocumentationHistoryNoteId() {
		return documentationHistoryNoteId;
	}

	public void setDocumentationHistoryNoteId(
			String documentationHistoryNoteId) {
		this.documentationHistoryNoteId = documentationHistoryNoteId;
	}

	@Override
	public String toString() {
		return "DocumentStatus [clientState=" + clientState + ", ihealJobId="
				+ ihealJobId + ", bhcMedRecId=" + bhcMedRecId
				+ ", bhcInvOrderNo=" + bhcInvOrderNo + ", facilityId="
				+ facilityId + ", bluebookId=" + bluebookId + ", patientId="
				+ patientId + ", visitId=" + visitId + ", documentType="
				+ documentType + ", pdfFileName=" + pdfFileName
				+ ", docReqStatus=" + docReqStatus + ", docNotificationStatus="
				+ docNotificationStatus + ", sendToByramStatus="
				+ sendToByramStatus + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", lastUpdatedUsername="
				+ lastUpdatedUsername + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", docPdfRequestTimestamp="
				+ docPdfRequestTimestamp + ", docNotificationTimestamp="
				+ docNotificationTimestamp + ", docPdfGetTimestamp="
				+ docPdfGetTimestamp + ", sendToS3Timestamp="
				+ sendToS3Timestamp + ", docSubmittedByUsername="
				+ docSubmittedByUsername + ", docSubmittedByUserId="
				+ docSubmittedByUserId + ", docSubmittedByUserFullname="
				+ docSubmittedByUserFullname + ", masterToken=" + masterToken
				+ ", docPDFGetStatus=" + docPDFGetStatus + ", facilityName="
				+ facilityName + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", bhcShipDate="
				+ bhcShipDate + ", bhcPatientAcctNo=" + bhcPatientAcctNo
				+ ", bhcPatientInv=" + bhcPatientInv + ", dateDocSent="
				+ dateDocSent + ", visitDate=" + visitDate
				+ ", documentationHistoryNoteId=" + documentationHistoryNoteId
				+ ", docUploadStatus=" + docUploadStatus + ", errorMessage="
				+ errorMessage + ", getPDFRequestTimestamp="
				+ getPDFRequestTimestamp + ", getPDFResponseTimestamp="
				+ getPDFResponseTimestamp + "]";
	}
}