package com.healogics.rtrv.entity;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "app_build_version")
public class BuildDetails {
	private String environment;
	private String applicationName;
	private String component;
	private String applicationVersion;
	private String buildVersion;
	private String applicationPlatform;
	private String lastUpdatedUser;
	private String lastUpdatedTimestamp;
	private String pk;
	private String sk;

	@DynamoDBHashKey(attributeName = "pk")
	public String getPk() {
		return pk;
	}
	public void setPk(String pk) {
		this.pk = pk;
	}
	@DynamoDBRangeKey(attributeName = "sk")
	public String getSk() {
		return sk;
	}
	public void setSk(String sk) {
		this.sk = sk;
	}
	@DynamoDBAttribute(attributeName = "environment")
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	@DynamoDBAttribute(attributeName = "application_name")
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	@DynamoDBAttribute(attributeName = "component")
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	@DynamoDBAttribute(attributeName = "application_version")
	public String getApplicationVersion() {
		return applicationVersion;
	}
	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}
	@DynamoDBAttribute(attributeName = "build_version")
	public String getBuildVersion() {
		return buildVersion;
	}
	public void setBuildVersion(String buildVersion) {
		this.buildVersion = buildVersion;
	}
	@DynamoDBAttribute(attributeName = "application_platform")
	public String getApplicationPlatform() {
		return applicationPlatform;
	}
	public void setApplicationPlatform(String applicationPlatform) {
		this.applicationPlatform = applicationPlatform;
	}
	@DynamoDBAttribute(attributeName = "last_updated_user")
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}
	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}
	@DynamoDBAttribute(attributeName = "last_updated_timestamp")
	public String getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(String lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	@Override
	public String toString() {
		return "BuildDetails{" + "environment='" + environment + '\''
				+ ", applicationName='" + applicationName + '\''
				+ ", component='" + component + '\'' + ", applicationVersion='"
				+ applicationVersion + '\'' + ", buildVersion='" + buildVersion
				+ '\'' + ", applicationPlatform='" + applicationPlatform + '\''
				+ ", lastUpdatedUser='" + lastUpdatedUser + '\''
				+ ", lastUpdatedTimestamp='" + lastUpdatedTimestamp + '\''
				+ ", pk='" + pk + '\'' + ", sk='" + sk + '\'' + '}';
	}
}
