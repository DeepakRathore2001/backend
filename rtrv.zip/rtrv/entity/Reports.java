package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reports")
public class Reports {

	@Id
	@Column(name = "bhc_invoice_order_no")
	private Long bhcInvoiceOrderId;

	@Column(name = "bhc_medical_record_id")
	private Long bhcMedicalRecordId;

	@Column(name = "bluebook_code")
	private String bbc;

	@Column(name = "bhc_order_source")
	private String bhcOrderSource;

	@Column(name = "bhc_patient_acct_no")
	private Long bhcPatientAcctId;

	@Column(name = "last_received")
	private Date lastReceived;

	@Column(name = "first_received")
	private Date firstReceived;

	@Column(name = "bhc_order_received_date")
	private Date bhcOrderReceivedDate;

	@Column(name = "bhc_ship_date")
	private Date bhcShipDate;

	@Column(name = "insurance_category")
	private String insuranceCategory;

	@Column(name = "docs_first_sent")
	private Date docsFirstSent;

	@Column(name = "last_file_uploaded")
	private Timestamp docsLastSent;

	@Column(name = "no_files_sent")
	private Integer noFilesSent;

	@Column(name = "status")
	private String status;

	@Column(name = "date_difference")
	private Integer dateDifference;

	public Long getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(Long bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getBhcOrderSource() {
		return bhcOrderSource;
	}

	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}

	public Long getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}

	public void setBhcInvoiceOrderId(Long bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}

	public Long getBhcPatientAcctId() {
		return bhcPatientAcctId;
	}

	public void setBhcPatientAcctId(Long bhcPatientAcctId) {
		this.bhcPatientAcctId = bhcPatientAcctId;
	}

	public Date getLastReceived() {
		return lastReceived;
	}

	public void setLastReceived(Date lastReceived) {
		this.lastReceived = lastReceived;
	}

	public Date getFirstReceived() {
		return firstReceived;
	}

	public void setFirstReceived(Date firstReceived) {
		this.firstReceived = firstReceived;
	}

	public Date getBhcOrderReceivedDate() {
		return bhcOrderReceivedDate;
	}

	public void setBhcOrderReceivedDate(Date bhcOrderReceivedDate) {
		this.bhcOrderReceivedDate = bhcOrderReceivedDate;
	}

	public Date getBhcShipDate() {
		return bhcShipDate;
	}

	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}

	public String getInsuranceCategory() {
		return insuranceCategory;
	}

	public void setInsuranceCategory(String insuranceCategory) {
		this.insuranceCategory = insuranceCategory;
	}

	public Date getDocsFirstSent() {
		return docsFirstSent;
	}

	public void setDocsFirstSent(Date docsFirstSent) {
		this.docsFirstSent = docsFirstSent;
	}

	public Timestamp getDocsLastSent() {
		return docsLastSent;
	}

	public void setDocsLastSent(Timestamp docsLastSent) {
		this.docsLastSent = docsLastSent;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getNoFilesSent() {
		return noFilesSent;
	}

	public void setNoFilesSent(Integer noFilesSent) {
		this.noFilesSent = noFilesSent;
	}

	public Integer getDateDifference() {
		return dateDifference;
	}

	public void setDateDifference(Integer dateDifference) {
		this.dateDifference = dateDifference;
	}

	@Override
	public String toString() {
		return "Reports [bhcMedicalRecordId=" + bhcMedicalRecordId + ", bbc="
				+ bbc + ", bhcOrderSource=" + bhcOrderSource
				+ ", bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", bhcPatientAcctId=" + bhcPatientAcctId + ", lastReceived="
				+ lastReceived + ", firstReceived=" + firstReceived
				+ ", bhcOrderReceivedDate=" + bhcOrderReceivedDate
				+ ", bhcShipDate=" + bhcShipDate + ", insuranceCategory="
				+ insuranceCategory + ", docsFirstSent=" + docsFirstSent
				+ ", docsLastSent=" + docsLastSent + ", noFilesSent="
				+ noFilesSent + ", status=" + status + ", dateDifference="
				+ dateDifference + "]";
	}

}
