package com.healogics.rtrv.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class AWDDashboardId implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer bhcInvoiceOrderId;
	private int bhcMedicalRecordId;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bhcInvoiceOrderId == null) ? 0 : bhcInvoiceOrderId.hashCode());
		result = prime * result + bhcMedicalRecordId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;

		if (obj == null)
			return false;

		if (getClass() != obj.getClass())
			return false;

		AWDDashboardId other = (AWDDashboardId) obj;

		if (bhcInvoiceOrderId == null) {
			if (other.bhcInvoiceOrderId != null)
				return false;
		} else if (!bhcInvoiceOrderId.equals(other.bhcInvoiceOrderId))
			return false;
		if (bhcMedicalRecordId != other.bhcMedicalRecordId)
			return false;
		return true;
	}

}
