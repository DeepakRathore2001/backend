package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "app_notification")
public class MasterAppNotification {
	@Id
	@Column(name = "notification_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long notificationId;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "username")
	private String username;

	@Column(name = "read_flag")
	private Boolean readFlag;

	@Lob
	@Column(name = "notification_description")
	private String notificationDescription;

	@Lob
	@Column(name = "notification_title")
	private String notificationTitle;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "user_fullname")
	private String userFullname;
	
	@Lob
	@Column(name = "hyperlink")
	private String hyperlink;

	@Column(name = "creator_user_id")
	private Long creatorUserId;

	@Column(name = "creator_username")
	private String creatorUsername;

	@Column(name = "creator_user_fullname")
	private String creatorUserFullname;

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Boolean getReadFlag() {
		return readFlag;
	}

	public void setReadFlag(Boolean readFlag) {
		this.readFlag = readFlag;
	}

	public String getNotificationDescription() {
		return notificationDescription;
	}

	public void setNotificationDescription(String notificationDescription) {
		this.notificationDescription = notificationDescription;
	}

	public String getNotificationTitle() {
		return notificationTitle;
	}

	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public String getHyperlink() {
		return hyperlink;
	}

	public void setHyperlink(String hyperlink) {
		this.hyperlink = hyperlink;
	}

	public Long getCreatorUserId() {
		return creatorUserId;
	}

	public void setCreatorUserId(Long creatorUserId) {
		this.creatorUserId = creatorUserId;
	}

	public String getCreatorUsername() {
		return creatorUsername;
	}

	public void setCreatorUsername(String creatorUsername) {
		this.creatorUsername = creatorUsername;
	}

	public String getCreatorUserFullname() {
		return creatorUserFullname;
	}

	public void setCreatorUserFullname(String creatorUserFullname) {
		this.creatorUserFullname = creatorUserFullname;
	}

	@Override
	public String toString() {
		return "MasterAppNotification [notificationId=" + notificationId + ", userId=" + userId + ", username="
				+ username + ", readFlag=" + readFlag + ", notificationDescription=" + notificationDescription
				+ ", notificationTitle=" + notificationTitle + ", createdTimestamp=" + createdTimestamp
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", userFullname=" + userFullname + ", hyperlink="
				+ hyperlink + ", creatorUserId=" + creatorUserId + ", creatorUsername=" + creatorUsername
				+ ", creatorUserFullname=" + creatorUserFullname + "]";
	}
}
