package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "document_store")
public class MasterDocumentStore {

	@Id
	@Column(name = "document_token")
	private String documentToken;

	@Column(name = "request_id")
	private String orderId;

	@Column(name = "doc_request_id")
	private String docRequestId;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "document_available")
	private Integer documentAvailable;

	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "visit_date")
	private Date visitDate;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_type")
	private String facilityType;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "vendor_id")
	private Integer vendorId;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "patient_id")
	private Integer patientId;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "iheal_doc_request_status")
	private String ihealDocRequestStatus;

	@Column(name = "iheal_doc_request_timestamp")
	private Timestamp ihealDocRequestTimestamp;

	@Column(name = "doc_download_status")
	private String docDownloadStatus;

	@Column(name = "doc_download_timestamp")
	private Timestamp docDownloadTimestamp;

	@Column(name = "doc_notification_status")
	private String docNotificationStatus;

	@Column(name = "doc_notification_timestamp")
	private Timestamp docNotificationTimestamp;

	@Column(name = "vendor_doc_get_status")
	private String vendorDocGetStatus;

	@Column(name = "vendor_doc_get_timestamp")
	private Timestamp vendorDocGetTimestamp;

	@Column(name = "doc_sent_status")
	private String docSentStatus;

	@Column(name = "doc_sent_timestamp")
	private Timestamp docSentTimestamp;

	@Column(name = "username")
	private String lastUpdatedUsername;

	@Column(name = "user_fullname")
	private String lastUpdatedUserFullname;

	@Column(name = "user_id")
	private Long lastUpdatedUserId;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message", columnDefinition = "TEXT")
	private String errorMessage;

	@Column(name = "store_id")
	private Integer storeId;

	@Lob
	@Column(name = "document_content", columnDefinition = "LONGTEXT")
	private String documentContent;

	@Column(name = "document_status")
	private String documentStatus;

	@Column(name = "service_line")
	private String serviceLine;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "document_source")
	private String documentSource;

	@Column(name = "iheal_document_id")
	private Long ihealDocumentId;
	
	@Column(name = "iheal_version_id")
	private Long ihealVersionId;
	
	@Column(name = "doc_mime_type")
	private String docMimeType;
	
	public String getDocMimeType() {
		return docMimeType;
	}

	public void setDocMimeType(String docMimeType) {
		this.docMimeType = docMimeType;
	}

	public Long getIhealVersionId() {
		return ihealVersionId;
	}

	public void setIhealVersionId(Long ihealVersionId) {
		this.ihealVersionId = ihealVersionId;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getDocumentSource() {
		return documentSource;
	}

	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDocRequestId() {
		return docRequestId;
	}

	public void setDocRequestId(String docRequestId) {
		this.docRequestId = docRequestId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentToken() {
		return documentToken;
	}

	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}

	public Integer getDocumentAvailable() {
		return documentAvailable;
	}

	public void setDocumentAvailable(Integer documentAvailable) {
		this.documentAvailable = documentAvailable;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public Long getIhealDocumentId() {
		return ihealDocumentId;
	}

	public void setIhealDocumentId(Long ihealDocumentId) {
		this.ihealDocumentId = ihealDocumentId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}

	public String getIhealDocRequestStatus() {
		return ihealDocRequestStatus;
	}

	public void setIhealDocRequestStatus(String ihealDocRequestStatus) {
		this.ihealDocRequestStatus = ihealDocRequestStatus;
	}

	public Timestamp getIhealDocRequestTimestamp() {
		return ihealDocRequestTimestamp;
	}

	public void setIhealDocRequestTimestamp(
			Timestamp ihealDocRequestTimestamp) {
		this.ihealDocRequestTimestamp = ihealDocRequestTimestamp;
	}

	public String getDocDownloadStatus() {
		return docDownloadStatus;
	}

	public void setDocDownloadStatus(String docDownloadStatus) {
		this.docDownloadStatus = docDownloadStatus;
	}

	public Timestamp getDocDownloadTimestamp() {
		return docDownloadTimestamp;
	}

	public void setDocDownloadTimestamp(Timestamp docDownloadTimestamp) {
		this.docDownloadTimestamp = docDownloadTimestamp;
	}

	public String getDocNotificationStatus() {
		return docNotificationStatus;
	}

	public void setDocNotificationStatus(String docNotificationStatus) {
		this.docNotificationStatus = docNotificationStatus;
	}

	public Timestamp getDocNotificationTimestamp() {
		return docNotificationTimestamp;
	}

	public void setDocNotificationTimestamp(
			Timestamp docNotificationTimestamp) {
		this.docNotificationTimestamp = docNotificationTimestamp;
	}

	public String getVendorDocGetStatus() {
		return vendorDocGetStatus;
	}

	public void setVendorDocGetStatus(String vendorDocGetStatus) {
		this.vendorDocGetStatus = vendorDocGetStatus;
	}

	public Timestamp getVendorDocGetTimestamp() {
		return vendorDocGetTimestamp;
	}

	public void setVendorDocGetTimestamp(Timestamp vendorDocGetTimestamp) {
		this.vendorDocGetTimestamp = vendorDocGetTimestamp;
	}

	public String getDocSentStatus() {
		return docSentStatus;
	}

	public void setDocSentStatus(String docSentStatus) {
		this.docSentStatus = docSentStatus;
	}

	public Timestamp getDocSentTimestamp() {
		return docSentTimestamp;
	}

	public void setDocSentTimestamp(Timestamp docSentTimestamp) {
		this.docSentTimestamp = docSentTimestamp;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "MasterDocumentStore [documentToken=" + documentToken + ", orderId=" + orderId + ", docRequestId="
				+ docRequestId + ", documentType=" + documentType + ", documentAvailable=" + documentAvailable
				+ ", visitId=" + visitId + ", visitDate=" + visitDate + ", facilityId=" + facilityId + ", bluebookId="
				+ bluebookId + ", facilityType=" + facilityType + ", ihealConfig=" + ihealConfig + ", vendorId="
				+ vendorId + ", vendorName=" + vendorName + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", ihealDocRequestStatus=" + ihealDocRequestStatus + ", ihealDocRequestTimestamp="
				+ ihealDocRequestTimestamp + ", docDownloadStatus=" + docDownloadStatus + ", docDownloadTimestamp="
				+ docDownloadTimestamp + ", docNotificationStatus=" + docNotificationStatus
				+ ", docNotificationTimestamp=" + docNotificationTimestamp + ", vendorDocGetStatus="
				+ vendorDocGetStatus + ", vendorDocGetTimestamp=" + vendorDocGetTimestamp + ", docSentStatus="
				+ docSentStatus + ", docSentTimestamp=" + docSentTimestamp + ", lastUpdatedUsername="
				+ lastUpdatedUsername + ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", storeId="
				+ storeId + ", documentContent=" + documentContent + ", documentStatus=" + documentStatus
				+ ", serviceLine=" + serviceLine + ", documentName=" + documentName + ", documentSource="
				+ documentSource + ", ihealDocumentId=" + ihealDocumentId + ", ihealVersionId=" + ihealVersionId
				+ ", docMimeType=" + docMimeType + "]";
	}

}
