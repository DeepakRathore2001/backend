package com.healogics.rtrv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "retrieve_members")
public class RetrieveMembers {
	@Id
	@Column(name = "retrieve_member_id")
	private Long retrieveMemberId;

	@Column(name = "bluebook_code")
	private String bluebookCode;

	@Column(name = "operations_specialist")
	private String operationsSpecialist;

	@Column(name = "awd_doc_specialist")
	private String awdDocSpecialist;

	@Column(name = "awd_doc_clerk")
	private String awdDocClerk;

	@Column(name = "byram_acct_mgr")
	private String byramAcctMgr;

	@Column(name = "byram_rsm")
	private String byramRsm;

	@Column(name = "active")
	private int active;

	@Column(name = "awd_doc_specialist_username")
	private String awdDocSpecialistUsername;

	@Column(name = "awd_doc_clerk_username")
	private String awdDocClerkUsername;

	@Column(name = "npwt_doc_analyst")
	private String npwtDocAnalyst;

	@Column(name = "npwt_doc_clerk")
	private String npwtDocClerk;

	@Column(name = "apria_rep")
	private String apriaRep;

	@Column(name = "lymphedema_analyst")
	private String lymphedemaAnalyst;

	@Column(name = "lymphedema_clerk")
	private String lymphedemaClerk;

	@Column(name = "ctp_analyst")
	private String ctpAnalyst;

	@Column(name = "ctp_clerk")
	private String ctpClerk;

	@Column(name = "analyst_1")
	private String analyst1;

	@Column(name = "analyst_2")
	private String analyst2;

	@Column(name = "operations_specialist_username")
	private String operationsSpecialistUsername;

	@Column(name = "operations_specialist_user_id")
	private Long operationsSpecialistUserId;

	@Column(name = "awd_doc_specialist_user_id")
	private Long awdDocSpecialistUserId;

	@Column(name = "awd_doc_clerk_user_id")
	private Long awdDocClerkUserId;

	@Column(name = "facility_type")
	private String facilityType;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "npwt_doc_analyst_username")
	private String npwtDocAnalystUsername;

	@Column(name = "npwt_doc_anlyst_user_id")
	private Long npwtDocAnalystUserId;

	@Column(name = "npwt_doc_clerk_username")
	private String npwtDocClerkUsername;

	@Column(name = "npwt_doc_clerk_user_id")
	private Long npwtDocClerkUserId;

	@Column(name = "lymphedema_analyst_username")
	private String lymphedemaAnalystUsername;

	@Column(name = "lymphedema_analyst_user_id")
	private Long lymphedemaAnalystUserId;

	@Column(name = "lymphedema_clerk_username")
	private String lymphedemaClerkUsername;

	@Column(name = "lymphedema_clerk_user_id")
	private Long lymphedemaClerkUserId;

	@Column(name = "ctp_analyst_username")
	private String ctpAnalystUsername;

	@Column(name = "ctp_analyst_user_id")
	private Long ctpAnalystUserId;

	@Column(name = "ctp_clerk_username")
	private String ctpClerkUsername;

	@Column(name = "ctp_clerk_user_id")
	private Long ctpClerkUserId;

	@Column(name = "analyst_1_username")
	private String analyst1Username;

	@Column(name = "analyst_1_user_id")
	private Long analyst1UserId;

	@Column(name = "analyst_2_username")
	private String analyst2Username;

	@Column(name = "analyst_2_user_id")
	private Long analyst2UserId;

	public String getOperationsSpecialist() {
		return operationsSpecialist;
	}

	public void setOperationsSpecialist(String operationsSpecialist) {
		this.operationsSpecialist = operationsSpecialist;
	}

	public String getByramAcctMgr() {
		return byramAcctMgr;
	}

	public void setByramAcctMgr(String byramAcctMgr) {
		this.byramAcctMgr = byramAcctMgr;
	}

	public String getByramRsm() {
		return byramRsm;
	}

	public void setByramRsm(String byramRsm) {
		this.byramRsm = byramRsm;
	}

	public String getNpwtDocAnalyst() {
		return npwtDocAnalyst;
	}

	public void setNpwtDocAnalyst(String npwtDocAnalyst) {
		this.npwtDocAnalyst = npwtDocAnalyst;
	}

	public String getNpwtDocClerk() {
		return npwtDocClerk;
	}

	public void setNpwtDocClerk(String npwtDocClerk) {
		this.npwtDocClerk = npwtDocClerk;
	}

	public String getApriaRep() {
		return apriaRep;
	}

	public void setApriaRep(String apriaRep) {
		this.apriaRep = apriaRep;
	}

	public String getLymphedemaAnalyst() {
		return lymphedemaAnalyst;
	}

	public void setLymphedemaAnalyst(String lymphedemaAnalyst) {
		this.lymphedemaAnalyst = lymphedemaAnalyst;
	}

	public String getLymphedemaClerk() {
		return lymphedemaClerk;
	}

	public void setLymphedemaClerk(String lymphedemaClerk) {
		this.lymphedemaClerk = lymphedemaClerk;
	}

	public String getCtpAnalyst() {
		return ctpAnalyst;
	}

	public void setCtpAnalyst(String ctpAnalyst) {
		this.ctpAnalyst = ctpAnalyst;
	}

	public String getCtpClerk() {
		return ctpClerk;
	}

	public void setCtpClerk(String ctpClerk) {
		this.ctpClerk = ctpClerk;
	}

	public String getAnalyst1() {
		return analyst1;
	}

	public void setAnalyst1(String analyst1) {
		this.analyst1 = analyst1;
	}

	public String getAnalyst2() {
		return analyst2;
	}

	public void setAnalyst2(String analyst2) {
		this.analyst2 = analyst2;
	}

	public String getOperationsSpecialistUsername() {
		return operationsSpecialistUsername;
	}

	public void setOperationsSpecialistUsername(
			String operationsSpecialistUsername) {
		this.operationsSpecialistUsername = operationsSpecialistUsername;
	}

	public Long getOperationsSpecialistUserId() {
		return operationsSpecialistUserId;
	}

	public void setOperationsSpecialistUserId(Long operationsSpecialistUserId) {
		this.operationsSpecialistUserId = operationsSpecialistUserId;
	}

	public Long getAwdDocSpecialistUserId() {
		return awdDocSpecialistUserId;
	}

	public void setAwdDocSpecialistUserId(Long awdDocSpecialistUserId) {
		this.awdDocSpecialistUserId = awdDocSpecialistUserId;
	}

	public Long getAwdDocClerkUserId() {
		return awdDocClerkUserId;
	}

	public void setAwdDocClerkUserId(Long awdDocClerkUserId) {
		this.awdDocClerkUserId = awdDocClerkUserId;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getNpwtDocAnalystUsername() {
		return npwtDocAnalystUsername;
	}

	public void setNpwtDocAnalystUsername(String npwtDocAnalystUsername) {
		this.npwtDocAnalystUsername = npwtDocAnalystUsername;
	}

	public Long getNpwtDocAnalystUserId() {
		return npwtDocAnalystUserId;
	}

	public void setNpwtDocAnalystUserId(Long npwtDocAnalystUserId) {
		this.npwtDocAnalystUserId = npwtDocAnalystUserId;
	}

	public String getNpwtDocClerkUsername() {
		return npwtDocClerkUsername;
	}

	public void setNpwtDocClerkUsername(String npwtDocClerkUsername) {
		this.npwtDocClerkUsername = npwtDocClerkUsername;
	}

	public Long getNpwtDocClerkUserId() {
		return npwtDocClerkUserId;
	}

	public void setNpwtDocClerkUserId(Long npwtDocClerkUserId) {
		this.npwtDocClerkUserId = npwtDocClerkUserId;
	}

	public String getLymphedemaAnalystUsername() {
		return lymphedemaAnalystUsername;
	}

	public void setLymphedemaAnalystUsername(String lymphedemaAnalystUsername) {
		this.lymphedemaAnalystUsername = lymphedemaAnalystUsername;
	}

	public Long getLymphedemaAnalystUserId() {
		return lymphedemaAnalystUserId;
	}

	public void setLymphedemaAnalystUserId(Long lymphedemaAnalystUserId) {
		this.lymphedemaAnalystUserId = lymphedemaAnalystUserId;
	}

	public String getLymphedemaClerkUsername() {
		return lymphedemaClerkUsername;
	}

	public void setLymphedemaClerkUsername(String lymphedemaClerkUsername) {
		this.lymphedemaClerkUsername = lymphedemaClerkUsername;
	}

	public Long getLymphedemaClerkUserId() {
		return lymphedemaClerkUserId;
	}

	public void setLymphedemaClerkUserId(Long lymphedemaClerkUserId) {
		this.lymphedemaClerkUserId = lymphedemaClerkUserId;
	}

	public String getCtpAnalystUsername() {
		return ctpAnalystUsername;
	}

	public void setCtpAnalystUsername(String ctpAnalystUsername) {
		this.ctpAnalystUsername = ctpAnalystUsername;
	}

	public Long getCtpAnalystUserId() {
		return ctpAnalystUserId;
	}

	public void setCtpAnalystUserId(Long ctpAnalystUserId) {
		this.ctpAnalystUserId = ctpAnalystUserId;
	}

	public String getCtpClerkUsername() {
		return ctpClerkUsername;
	}

	public void setCtpClerkUsername(String ctpClerkUsername) {
		this.ctpClerkUsername = ctpClerkUsername;
	}

	public Long getCtpClerkUserId() {
		return ctpClerkUserId;
	}

	public void setCtpClerkUserId(Long ctpClerkUserId) {
		this.ctpClerkUserId = ctpClerkUserId;
	}

	public String getAnalyst1Username() {
		return analyst1Username;
	}

	public void setAnalyst1Username(String analyst1Username) {
		this.analyst1Username = analyst1Username;
	}

	public Long getAnalyst1UserId() {
		return analyst1UserId;
	}

	public void setAnalyst1UserId(Long analyst1UserId) {
		this.analyst1UserId = analyst1UserId;
	}

	public String getAnalyst2Username() {
		return analyst2Username;
	}

	public void setAnalyst2Username(String analyst2Username) {
		this.analyst2Username = analyst2Username;
	}

	public Long getAnalyst2UserId() {
		return analyst2UserId;
	}

	public void setAnalyst2UserId(Long analyst2UserId) {
		this.analyst2UserId = analyst2UserId;
	}

	public Long getRetrieveMemberId() {
		return retrieveMemberId;
	}

	public void setRetrieveMemberId(Long retrieveMemberId) {
		this.retrieveMemberId = retrieveMemberId;
	}

	public String getBluebookCode() {
		return bluebookCode;
	}

	public void setBluebookCode(String bluebookCode) {
		this.bluebookCode = bluebookCode;
	}

	public String getAwdDocSpecialist() {
		return awdDocSpecialist;
	}

	public void setAwdDocSpecialist(String awdDocSpecialist) {
		this.awdDocSpecialist = awdDocSpecialist;
	}

	public String getAwdDocClerk() {
		return awdDocClerk;
	}

	public void setAwdDocClerk(String awdDocClerk) {
		this.awdDocClerk = awdDocClerk;
	}

	public String getAwdDocSpecialistUsername() {
		return awdDocSpecialistUsername;
	}

	public void setAwdDocSpecialistUsername(String awdDocSpecialistUsername) {
		this.awdDocSpecialistUsername = awdDocSpecialistUsername;
	}

	public String getAwdDocClerkUsername() {
		return awdDocClerkUsername;
	}

	public void setAwdDocClerkUsername(String awdDocClerkUsername) {
		this.awdDocClerkUsername = awdDocClerkUsername;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "RetrieveMembers [retrieveMemberId=" + retrieveMemberId
				+ ", bluebookCode=" + bluebookCode + ", operationsSpecialist="
				+ operationsSpecialist + ", awdDocSpecialist="
				+ awdDocSpecialist + ", awdDocClerk=" + awdDocClerk
				+ ", byramAcctMgr=" + byramAcctMgr + ", byramRsm=" + byramRsm
				+ ", active=" + active + ", awdDocSpecialistUsername="
				+ awdDocSpecialistUsername + ", awdDocClerkUsername="
				+ awdDocClerkUsername + ", npwtDocAnalyst=" + npwtDocAnalyst
				+ ", npwtDocClerk=" + npwtDocClerk + ", apriaRep=" + apriaRep
				+ ", lymphedemaAnalyst=" + lymphedemaAnalyst
				+ ", lymphedemaClerk=" + lymphedemaClerk + ", ctpAnalyst="
				+ ctpAnalyst + ", ctpClerk=" + ctpClerk + ", analyst1="
				+ analyst1 + ", analyst2=" + analyst2
				+ ", operationsSpecialistUsername="
				+ operationsSpecialistUsername + ", operationsSpecialistUserId="
				+ operationsSpecialistUserId + ", awdDocSpecialistUserId="
				+ awdDocSpecialistUserId + ", awdDocClerkUserId="
				+ awdDocClerkUserId + ", facilityType=" + facilityType
				+ ", facilityId=" + facilityId + ", npwtDocAnalystUsername="
				+ npwtDocAnalystUsername + ", npwtDocAnalystUserId="
				+ npwtDocAnalystUserId + ", npwtDocClerkUsername="
				+ npwtDocClerkUsername + ", npwtDocClerkUserId="
				+ npwtDocClerkUserId + ", lymphedemaAnalystUsername="
				+ lymphedemaAnalystUsername + ", lymphedemaAnalystUserId="
				+ lymphedemaAnalystUserId + ", lymphedemaClerkUsername="
				+ lymphedemaClerkUsername + ", lymphedemaClerkUserId="
				+ lymphedemaClerkUserId + ", ctpAnalystUsername="
				+ ctpAnalystUsername + ", ctpAnalystUserId=" + ctpAnalystUserId
				+ ", ctpClerkUsername=" + ctpClerkUsername + ", ctpClerkUserId="
				+ ctpClerkUserId + ", analyst1Username=" + analyst1Username
				+ ", analyst1UserId=" + analyst1UserId + ", analyst2Username="
				+ analyst2Username + ", analyst2UserId=" + analyst2UserId + "]";
	}
}
