package com.healogics.rtrv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vendor_auth_details")
public class VendorAuthDetails {
	@Id
	@Column(name = "vendor_id")
	private int vendorId;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "api_username")
	private String userName;

	@Column(name = "api_password")
	private String password;

	@Column(name = "service_line")
	private String serviceLine;

	@Column(name = "service_line_description")
	private String serviceLineDescription;

	@Column(name = "active")
	private int active;

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getServiceLineDescription() {
		return serviceLineDescription;
	}

	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "VendorAuthDetails [vendorId=" + vendorId + ", vendorName=" + vendorName + ", userName=" + userName
				+ ", password=" + password + ", serviceLine=" + serviceLine + ", serviceLineDescription="
				+ serviceLineDescription + ", active=" + active + "]";
	}
}
