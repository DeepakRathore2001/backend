package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient_medical_records")
public class PatientMedicalRecords {
	@Id
	@Column(name = "document_id")
	private String documentId;

	@Column(name = "bhc_medical_record_id")
	private int bhcMedicalRecordId;

	@Column(name = "bhc_invoice_order_no")
	private int bhcInvoiceOrderNo;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "document_content")
	private String documentContent;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;

	@Column(name = "last_updated_user_id")
	private Long lastUpdatedUserId;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "is_submitted")
	private int isSubmitted;

	@Column(name = "documentation_history_note_id")
	private String documentationHistoryNoteId;

	public String getDocumentationHistoryNoteId() {
		return documentationHistoryNoteId;
	}

	public void setDocumentationHistoryNoteId(
			String documentationHistoryNoteId) {
		this.documentationHistoryNoteId = documentationHistoryNoteId;
	}

	public int getIsSubmitted() {
		return isSubmitted;
	}

	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public int getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(int bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public int getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}

	public void setBhcInvoiceOrderNo(int bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	@Override
	public String toString() {
		return "PatientMedicalRecords [documentId=" + documentId
				+ ", bhcMedicalRecordId=" + bhcMedicalRecordId
				+ ", bhcInvoiceOrderNo=" + bhcInvoiceOrderNo + ", documentName="
				+ documentName + ", documentContent=" + documentContent
				+ ", documentType=" + documentType + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", lastUpdatedUsername="
				+ lastUpdatedUsername + ", isSubmitted=" + isSubmitted
				+ ", documentationHistoryNoteId=" + documentationHistoryNoteId
				+ "]";
	}
}
