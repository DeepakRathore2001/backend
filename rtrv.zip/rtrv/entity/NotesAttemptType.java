package com.healogics.rtrv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "notes_options")
public class NotesAttemptType {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "service_line")
	private String serviceLine;
	
	@Column(name = "attempt_category")
	private String attemptCategory;
	
	@Column(name = "attempt_type",  columnDefinition = "json")
	private String attemptType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getAttemptCategory() {
		return attemptCategory;
	}

	public void setAttemptCategory(String attemptCategory) {
		this.attemptCategory = attemptCategory;
	}

	public String getAttemptType() {
		return attemptType;
	}

	public void setAttemptType(String attemptType) {
		this.attemptType = attemptType;
	}

	@Override
	public String toString() {
		return "NotesAttemptType [id=" + id + ", serviceLine=" + serviceLine
				+ ", attemptCategory=" + attemptCategory
				+ ", attemptType=" + attemptType + "]";
	}
}
