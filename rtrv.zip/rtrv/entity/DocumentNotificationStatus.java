package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document_notification_status")
public class DocumentNotificationStatus {

	@Id
	@Column(name = "bhc_medical_record_id")
	private Long bhcMedicalRecordId;

	@Column(name = "bhc_invoice_order_no")
	private Long bhcInvoiceOrderNo;

	@Column(name = "document_details", columnDefinition = "json")
	private String documentDetails;

	@Column(name = "notification_sent")
	private int notificationSent;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdateTimestamp;

	public Long getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(Long bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public Long getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}

	public void setBhcInvoiceOrderNo(Long bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}

	public String getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(String documentDetails) {
		this.documentDetails = documentDetails;
	}

	public int getNotificationSent() {
		return notificationSent;
	}

	public void setNotificationSent(int notificationSent) {
		this.notificationSent = notificationSent;
	}

	public Timestamp getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	@Override
	public String toString() {
		return "DocumentNotificationStatus [bhcMedicalRecordId="
				+ bhcMedicalRecordId + ", bhcInvoiceOrderNo="
				+ bhcInvoiceOrderNo + ", documentDetails=" + documentDetails
				+ ", notificationSent=" + notificationSent
				+ ", lastUpdateTimestamp=" + lastUpdateTimestamp + "]";
	}

}
