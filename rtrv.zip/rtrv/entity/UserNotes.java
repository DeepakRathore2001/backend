package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "user_notes")
public class UserNotes {

	@Id
	@Column(name = "note_id")
	private String noteId;

	@Column(name = "bhc_medical_record_id")
	private Long bhcMedicalRecordId;

	@Column(name = "bhc_invoice_order_no")
	private Long bhcInvoiceOrderNo;

	@Column(name = "attempt_category")
	private String attemptCategory;

	@Column(name = "attempt_type")
	private String attemptType;

	@Column(name = "contact_method")
	private String contactMethod;

	@Column(name = "followup_date")
	private Date followupDate;

	@Column(name = "addendum_received")
	private Boolean addendumReceived;

	@Column(name = "received_rx")
	private Boolean receivedRX;
	
	@Column(name="rx_sent")
	private Boolean RXSent;

	@Column(name = "addendum_sent")
	private Boolean addendumSent;

	@Column(name = "patient_not_seen_30_days")
	private Boolean patientNotSeen30Days;

	@Lob
	@Column(name = "description")
	private String description;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "patient_fullname")
	private String patientFullname;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_user_id")
	private Long lastUpdatedUserId;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "delete_flag")
	private boolean deleteFlag;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;

	public Boolean getRXSent() {
		return RXSent;
	}

	public void setRXSent(Boolean RXSent) {
		this.RXSent = RXSent;
	}

	public String getContactMethod() {
		return contactMethod;
	}

	public void setContactMethod(String contactMethod) {
		this.contactMethod = contactMethod;
	}

	public String getNoteId() {
		return noteId;
	}

	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}

	public Long getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(Long bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public Long getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}

	public void setBhcInvoiceOrderNo(Long bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}

	public String getAttemptCategory() {
		return attemptCategory;
	}

	public void setAttemptCategory(String attemptCategory) {
		this.attemptCategory = attemptCategory;
	}

	public String getAttemptType() {
		return attemptType;
	}

	public void setAttemptType(String attemptType) {
		this.attemptType = attemptType;
	}

	public Date getFollowupDate() {
		return followupDate;
	}

	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}

	public boolean isAddendumSent() {
		return addendumSent;
	}

	public void setAddendumSent(boolean addendumSent) {
		this.addendumSent = addendumSent;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getPatientFullname() {
		return patientFullname;
	}

	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public boolean isDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public Boolean getAddendumReceived() {
		return addendumReceived;
	}

	public void setAddendumReceived(Boolean addendumReceived) {
		this.addendumReceived = addendumReceived;
	}

	public Boolean getReceivedRX() {
		return receivedRX;
	}

	public void setReceivedRX(Boolean receivedRX) {
		this.receivedRX = receivedRX;
	}

	public Boolean getAddendumSent() {
		return addendumSent;
	}

	public void setAddendumSent(Boolean addendumSent) {
		this.addendumSent = addendumSent;
	}

	public Boolean getPatientNotSeen30Days() {
		return patientNotSeen30Days;
	}

	public void setPatientNotSeen30Days(Boolean patientNotSeen30Days) {
		this.patientNotSeen30Days = patientNotSeen30Days;
	}

	@Override
	public String toString() {
		return "UserNotes [noteId=" + noteId + ", bhcMedicalRecordId=" + bhcMedicalRecordId + ", bhcInvoiceOrderNo="
				+ bhcInvoiceOrderNo + ", attemptCategory=" + attemptCategory + ", attemptType=" + attemptType
				+ ", contactMethod=" + contactMethod + ", followupDate=" + followupDate + ", addendumReceived="
				+ addendumReceived + ", receivedRX=" + receivedRX + ", RXSent=" + RXSent + ", addendumSent="
				+ addendumSent + ", patientNotSeen30Days=" + patientNotSeen30Days + ", description=" + description
				+ ", patientId=" + patientId + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId
				+ ", patientFullname=" + patientFullname + ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", lastUpdatedUserId=" + lastUpdatedUserId + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", deleteFlag=" + deleteFlag + ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + "]";
	}

}
