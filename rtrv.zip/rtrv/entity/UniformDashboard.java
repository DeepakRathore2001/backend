package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "uniform_dashboard")
public class UniformDashboard {

	@Id
	@Column(name = "request_id")
	private String requestId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "vendor_order_no")
	private String vendorOrderNo;

	@Column(name = "vendor_id")
	private Integer vendorId;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "age")
	private Integer age;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "assigned_to")
	private String assignedTo;

	@Column(name = "assignee_user_id")
	private String assigneeUserId;

	@Column(name = "assignee_username")
	private String assigneeUsername;

	@Column(name = "last_team_updated")
	private Timestamp lastTeamUpdatedTimestamp;

	@Column(name = "last_team_updated_userfullname")
	private String lastTeamUpdatedFullName;

	@Column(name = "response_date")
	private Date responseDate;

	@Column(name = "order_source")
	private String orderSource;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "followup_date")
	private Date followupDate;

	@Column(name = "insurance", columnDefinition = "json")
	private String insurance;

	@Column(name = "primary_insurance", columnDefinition = "TEXT")
	private String primaryInsurance;

	@Column(name = "vendor_order_date")
	private Date vendorOrderDate;

	@Column(name = "retrieve_status")
	private String retrieveStatus;

	@Column(name = "vendor_status")
	private String vendorStatus;

	@Column(name = "received_date")
	private Date receivedDate;

	@Column(name = "first_received")
	private Timestamp firstReceived;

	@Column(name = "status_updated_user_id")
	private String statusUpdatedUserId;

	@Column(name = "status_updated_username")
	private String statusUpdatedUsername;

	@Column(name = "status_updated_user_fullname")
	private String statusUpdatedUserFullname;

	@Column(name = "status_updated_timestamp")
	private Timestamp statusUpdatedTimestamp;

	@Column(name = "provider_id")
	private Long providerId;

	@Column(name = "provider_first_name")
	private String providerFirstName;

	@Column(name = "provider_last_name")
	private String providerLastName;

	@Column(name = "medical_record_number")
	private String medicalRecordNumber;

	@Column(name = "vendor_patient_no")
	private String vendorPatientNo;

	@Column(name = "vendor_notes", columnDefinition = "TEXT")
	private String vendorNotes;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "woundq_order_no")
	private String woundQOrderNo;

	@Column(name = "files_sent")
	private Integer filesSent;

	@Column(name = "documents_first_sent")
	private Timestamp documentsFirstSent;

	@Column(name = "documents_last_sent")
	private Timestamp documentsLastSent;

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Long getProviderId() {
		return providerId;
	}

	public void setProviderId(Long providerId) {
		this.providerId = providerId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}

	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}

	public String getVendorPatientNo() {
		return vendorPatientNo;
	}

	public void setVendorPatientNo(String vendorPatientNo) {
		this.vendorPatientNo = vendorPatientNo;
	}

	public String getVendorNotes() {
		return vendorNotes;
	}

	public void setVendorNotes(String vendorNotes) {
		this.vendorNotes = vendorNotes;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getVendorOrderNo() {
		return vendorOrderNo;
	}

	public void setVendorOrderNo(String vendorOrderNo) {
		this.vendorOrderNo = vendorOrderNo;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(String assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUsername() {
		return assigneeUsername;
	}

	public void setAssigneeUsername(String assigneeUsername) {
		this.assigneeUsername = assigneeUsername;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public Timestamp getFirstReceived() {
		return firstReceived;
	}

	public void setFirstReceived(Timestamp firstReceived) {
		this.firstReceived = firstReceived;
	}

	public String getStatusUpdatedUserId() {
		return statusUpdatedUserId;
	}

	public void setStatusUpdatedUserId(String statusUpdatedUserId) {
		this.statusUpdatedUserId = statusUpdatedUserId;
	}

	public String getStatusUpdatedUsername() {
		return statusUpdatedUsername;
	}

	public void setStatusUpdatedUsername(String statusUpdatedUsername) {
		this.statusUpdatedUsername = statusUpdatedUsername;
	}

	public String getStatusUpdatedUserFullname() {
		return statusUpdatedUserFullname;
	}

	public void setStatusUpdatedUserFullname(String statusUpdatedUserFullname) {
		this.statusUpdatedUserFullname = statusUpdatedUserFullname;
	}

	public Timestamp getStatusUpdatedTimestamp() {
		return statusUpdatedTimestamp;
	}

	public void setStatusUpdatedTimestamp(Timestamp statusUpdatedTimestamp) {
		this.statusUpdatedTimestamp = statusUpdatedTimestamp;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public Timestamp getLastTeamUpdatedTimestamp() {
		return lastTeamUpdatedTimestamp;
	}

	public void setLastTeamUpdatedTimestamp(Timestamp lastTeamUpdatedTimestamp) {
		this.lastTeamUpdatedTimestamp = lastTeamUpdatedTimestamp;
	}

	public String getLastTeamUpdatedFullName() {
		return lastTeamUpdatedFullName;
	}

	public void setLastTeamUpdatedFullName(String lastTeamUpdatedFullName) {
		this.lastTeamUpdatedFullName = lastTeamUpdatedFullName;
	}

	public Date getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(Date responseDate) {
		this.responseDate = responseDate;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public Date getFollowupDate() {
		return followupDate;
	}

	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public Date getVendorOrderDate() {
		return vendorOrderDate;
	}

	public void setVendorOrderDate(Date vendorOrderDate) {
		this.vendorOrderDate = vendorOrderDate;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public String getWoundQOrderNo() {
		return woundQOrderNo;
	}

	public void setWoundQOrderNo(String woundQOrderNo) {
		this.woundQOrderNo = woundQOrderNo;
	}

	public Integer getFilesSent() {
		return filesSent;
	}

	public void setFilesSent(Integer filesSent) {
		this.filesSent = filesSent;
	}

	public Timestamp getDocumentsFirstSent() {
		return documentsFirstSent;
	}

	public void setDocumentsFirstSent(Timestamp documentsFirstSent) {
		this.documentsFirstSent = documentsFirstSent;
	}

	public Timestamp getDocumentsLastSent() {
		return documentsLastSent;
	}

	public void setDocumentsLastSent(Timestamp documentsLastSent) {
		this.documentsLastSent = documentsLastSent;
	}

	@Override
	public String toString() {
		return "UniformDashboard [requestId=" + requestId + ", bluebookId=" + bluebookId + ", vendorOrderNo="
				+ vendorOrderNo + ", vendorId=" + vendorId + ", vendorName=" + vendorName + ", age=" + age
				+ ", patientId=" + patientId + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", patientDOB=" + patientDOB + ", assignedTo=" + assignedTo + ", assigneeUserId="
				+ assigneeUserId + ", assigneeUsername=" + assigneeUsername + ", lastTeamUpdatedTimestamp="
				+ lastTeamUpdatedTimestamp + ", lastTeamUpdatedFullName=" + lastTeamUpdatedFullName + ", responseDate="
				+ responseDate + ", orderSource=" + orderSource + ", ihealConfig=" + ihealConfig + ", followupDate="
				+ followupDate + ", insurance=" + insurance + ", primaryInsurance=" + primaryInsurance
				+ ", vendorOrderDate=" + vendorOrderDate + ", retrieveStatus=" + retrieveStatus + ", vendorStatus="
				+ vendorStatus + ", receivedDate=" + receivedDate + ", firstReceived=" + firstReceived
				+ ", statusUpdatedUserId=" + statusUpdatedUserId + ", statusUpdatedUsername=" + statusUpdatedUsername
				+ ", statusUpdatedUserFullname=" + statusUpdatedUserFullname + ", statusUpdatedTimestamp="
				+ statusUpdatedTimestamp + ", providerId=" + providerId + ", providerFirstName=" + providerFirstName
				+ ", providerLastName=" + providerLastName + ", medicalRecordNumber=" + medicalRecordNumber
				+ ", vendorPatientNo=" + vendorPatientNo + ", vendorNotes=" + vendorNotes + ", createdTimestamp="
				+ createdTimestamp + ", woundQOrderNo=" + woundQOrderNo + ", filesSent=" + filesSent
				+ ", documentsFirstSent=" + documentsFirstSent + ", documentsLastSent=" + documentsLastSent + "]";
	}

}
