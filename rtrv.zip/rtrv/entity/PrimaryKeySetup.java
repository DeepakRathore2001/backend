package com.healogics.rtrv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "primary_key_setup")
public class PrimaryKeySetup {
	@Id
	@Column(name = "vendor_id")
	private int vendorId;
	
	@Column(name = "vendor_name")
	private String vendorName;
	
	@Column(name = "primary_key",  columnDefinition = "json")
	private String primaryKey;
	
	@Column(name = "service_line")
	private String serviceLine;
	
	@Column(name = "service_line_description")
	private String serviceLineDesc;

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getServiceLineDesc() {
		return serviceLineDesc;
	}

	public void setServiceLineDesc(String serviceLineDesc) {
		this.serviceLineDesc = serviceLineDesc;
	}

	@Override
	public String toString() {
		return "PrimaryKeySetup [vendorId=" + vendorId + ", vendorName=" + vendorName + ", primaryKey=" + primaryKey
				+ ", serviceLine=" + serviceLine + ", serviceLineDesc=" + serviceLineDesc + "]";
	}
}
