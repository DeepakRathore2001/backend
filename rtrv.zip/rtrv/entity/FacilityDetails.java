package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "facility_details")
public class FacilityDetails {

	@Id
	@Column(name = "bluebook_id")
	private String bluebookId;

	@Lob
	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "facility_id")
	private int facilityId;

	@Lob
	@Column(name = "division")
	private String division;

	@Lob
	@Column(name = "market")
	private String market;

	@Lob
	@Column(name = "territory")
	private String territory;

	@Lob
	@Column(name = "center_address")
	private String centerAddress;

	@Lob
	@Column(name = "center_city")
	private String centerCity;

	@Lob
	@Column(name = "center_state")
	private String centerState;

	@Column(name = "center_zip")
	private int centerZip;

	@Column(name = "center_phone")
	private long centerPhone;

	@Column(name = "center_fax")
	private long centerFax;

	@Column(name = "old_facility_type")
	private String oldFacilityType;

	@Column(name = "current_facility_type")
	private String currentFacilityType;

	@Column(name = "facility_type_changed")
	private Integer facilityTypeChanged;
	
	@Column(name = "active")
	private int active;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	
	@Column(name = "iheal_config")
	private String ihealConfig;
	
	@Column(name = "facility_type")
	private String facilityType;
	

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getOldFacilityType() {
		return oldFacilityType;
	}

	public void setOldFacilityType(String oldFacilityType) {
		this.oldFacilityType = oldFacilityType;
	}

	public String getCurrentFacilityType() {
		return currentFacilityType;
	}

	public void setCurrentFacilityType(String currentFacilityType) {
		this.currentFacilityType = currentFacilityType;
	}

	public Integer getFacilityTypeChanged() {
		return facilityTypeChanged;
	}

	public void setFacilityTypeChanged(Integer facilityTypeChanged) {
		this.facilityTypeChanged = facilityTypeChanged;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getTerritory() {
		return territory;
	}

	public void setTerritory(String territory) {
		this.territory = territory;
	}

	public String getCenterAddress() {
		return centerAddress;
	}

	public void setCenterAddress(String centerAddress) {
		this.centerAddress = centerAddress;
	}

	public String getCenterCity() {
		return centerCity;
	}

	public void setCenterCity(String centerCity) {
		this.centerCity = centerCity;
	}

	public String getCenterState() {
		return centerState;
	}

	public void setCenterState(String centerState) {
		this.centerState = centerState;
	}

	public int getCenterZip() {
		return centerZip;
	}

	public void setCenterZip(int centerZip) {
		this.centerZip = centerZip;
	}

	public long getCenterPhone() {
		return centerPhone;
	}

	public void setCenterPhone(long centerPhone) {
		this.centerPhone = centerPhone;
	}

	public long getCenterFax() {
		return centerFax;
	}

	public void setCenterFax(long centerFax) {
		this.centerFax = centerFax;
	}

	@Override
	public String toString() {
		return "FacilityDetails [bluebookId=" + bluebookId + ", facilityName=" + facilityName + ", facilityId="
				+ facilityId + ", division=" + division + ", market=" + market + ", territory=" + territory
				+ ", centerAddress=" + centerAddress + ", centerCity=" + centerCity + ", centerState=" + centerState
				+ ", centerZip=" + centerZip + ", centerPhone=" + centerPhone + ", centerFax=" + centerFax
				+ ", oldFacilityType=" + oldFacilityType + ", currentFacilityType=" + currentFacilityType
				+ ", facilityTypeChanged=" + facilityTypeChanged + ", active=" + active + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", ihealConfig=" + ihealConfig + ", facilityType=" + facilityType + "]";
	}

}
