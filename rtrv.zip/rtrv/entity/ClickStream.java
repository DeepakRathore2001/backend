package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "clickstream")
public class ClickStream {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "username")
	private String username;
	
	@Column(name = "user_id")
	private Long userId;
	
	@Column(name = "user_fullname")
	private String userFullname;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "facility_id")
	private int facilityId;
	
	@Column(name = "module_name")
	private String moduleName;
	
	@Column(name = "module_description")
	private String moduleDescription;
	
	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;
	
	@Column(name = "service_line")
	private String serviceLine;
	
	@Column(name = "vendor")
	private String vendor;
	
	@Column(name = "bhc_medical_record_id")
	private Long bhcMedicalRecordId;
	
	@Column(name = "bhc_invoice_order_id")
	private Long bhcInvoiceOrderId;
	
	public Long getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(Long bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public Long getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}

	public void setBhcInvoiceOrderId(Long bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModuleDescription() {
		return moduleDescription;
	}

	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	@Override
	public String toString() {
		return "ClickStream [id=" + id + ", username=" + username + ", userId=" + userId + ", userFullname="
				+ userFullname + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", moduleName="
				+ moduleName + ", moduleDescription=" + moduleDescription + ", createdTimestamp=" + createdTimestamp
				+ ", serviceLine=" + serviceLine + ", vendor=" + vendor + ", bhcMedicalRecordId=" + bhcMedicalRecordId
				+ ", bhcInvoiceOrderId=" + bhcInvoiceOrderId + "]";
	}
	
}
