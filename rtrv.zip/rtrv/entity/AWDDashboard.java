package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(AWDDashboardId.class)
@Table(name = "awd_dashboard")
public class AWDDashboard {
	
	@Id
	@Column(name = "bhc_invoice_order_no")
	private Integer bhcInvoiceOrderId;
	
	@Id
	@Column(name = "bhc_medical_record_id")
	private int bhcMedicalRecordId;

	@Column(name = "bluebook_code")
	private String bbc;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "facility_type")
	private String facilityType;

	@Column(name = "bhc_referral_no")
	private String bhcReferralId;

	@Column(name = "bhc_order_source")
	private String bhcOrderSource;

	@Column(name = "healogics_order_no")
	private Integer healogicsOrderId;

	@Column(name = "healogics_patient_id")
	private Integer healogicsPatientId;

	@Column(name = "healogics_patient_mrn")
	private String healogicsPatientMRN;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "patient_fullname")
	private String patientFullname;

	@Column(name = "patient_dob")
	private LocalDate patientDOB;

	@Column(name = "bhc_order_received_date")
	private Date bhcOrderReceivedDate;

	@Column(name = "bhc_ship_date")
	private Date bhcShipDate;

	@Column(name = "bhc_primary_insurance")
	private String bhcPrimaryInsurance;

	@Column(name = "bhc_primary_insurance_received")
	private String bhcPrimaryInsuranceReceived;

	@Column(name = "primary_insurance_policy_no")
	private String primaryInsurancePolicyId;

	@Column(name = "bhc_physician_no")
	private Integer bhcPhysicianId;

	@Column(name = "provider_first_name")
	private String providerFirstName;

	@Column(name = "provider_last_name")
	private String providerLastName;

	@Column(name = "provider_npi")
	private Long providerNPI;

	@Column(name = "provider_phone")
	private String providerPhone;

	@Column(name = "provider_fax")
	private String providerFax;

	@Column(name = "bhc_patient_acct_no")
	private Integer bhcPatientAcctId;

	@Column(name = "manufacturer_name")
	private String manufacturerName;

	@Column(name = "manufacturer_product_name")
	private String manufacturerProductName;

	@Column(name = "manufacturer_item_number")
	private String manufacturerItemNumber;

	@Column(name = "product_description")
	private String productDescription;

	@Column(name = "quantity")
	private String quantity;

	@Column(name = "unit_of_measure")
	private String unitOfMeasure;

	@Column(name = "hcpcs")
	private String hcpcs;

	@Column(name = "byram_catalog_number")
	private String byramCatalogNumber;

	@Column(name = "rx_validated")
	private String rxValidated;

	@Column(name = "shipping_carrier")
	private String shippingCarrier;

	@Column(name = "tracking_no")
	private String trackingId;

	@Column(name = "shipping_address_1")
	private String shippingAddress1;

	@Column(name = "shipping_address_2")
	private String shippingAddress2;

	@Column(name = "shipping_city")
	private String shippingCity;

	@Column(name = "shipping_state")
	private String shippingState;

	@Column(name = "shipping_zip")
	private String shippingZip;

	@Column(name = "medical_record_added_date")
	private Date medicalRecordAddedDate;

	@Column(name = "bhc_document_status")
	private String bhcDocumentStatus;

	@Column(name = "bhc_document_type")
	private String bhcDocumentType;

	@Column(name = "medical_record_start_date")
	private Date medicalRecordStartDate;

	@Column(name = "bhc_missing_doc_type")
	private String bhcMissingDocType;

	@Column(name = "bhc_missing_doc_notes")
	private String bhcMissingDocNotes;

	@Column(name = "backorder")
	private String backorder;

	@Column(name = "overage")
	private String overage;

	@Column(name = "bhc_missing_doc")
	private String bhcMissingDoc;

	@Column(name = "last_updated_date")
	private Date lastUpdatedDate;

	@Column(name = "last_team_updated")
	private Timestamp lastTeamUpdated;

	@Column(name = "last_team_updated_userfullname")
	private String lastTeamUpdatedUserFullname;

	@Column(name = "invoice_net_balance")
	private String invoiceNetBalance;

	@Column(name = "invoice_balance_due")
	private String invoiceBalanceDue;

	@Column(name = "status")
	private String status;

	@Column(name = "assignee")
	private String assignee;

	@Column(name = "assignee_fullname ")
	private String assigneeFullName;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedDateTime;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullName;

	@Column(name = "last_updated_user_id")
	private Long lastUpdatedUserId;

	@Column(name = "last_updated_username")
	private String lastUpdatedUserName;

	@Column(name = "status_updated_timestamp")
	private Timestamp statusUpdatedDateTime;

	@Column(name = "status_updated_user_fullname")
	private String statusUpdatedUserFullName;

	@Column(name = "status_updated_user_id")
	private Long statusUpdatedUserId;

	@Column(name = "status_updated_username")
	private String statusUpdatedUserName;

	@Column(name = "active")
	private Integer active;

	@Column(name = "insurance_category")
	private String insuranceCategory;

	@Column(name = "provider_fullname")
	private String providerFullname;

	@Column(name = "age")
	private Date age;

	@Column(name = "record_active")
	private Boolean recordActive;

	@Column(name = "last_received")
	private Date lastReceived;

	@Column(name = "last_file_uploaded")
	private Timestamp lastFileUploaded;

	@Column(name = "files_sent")
	private Long filesSent;

	@Column(name = "no_of_updates")
	private Long noOfUpdates;

	@Column(name = "last_actioned")
	private Timestamp lastActioned;

	@Column(name = "followup_date")
	private Date followupDate;

	@Column(name = "first_received")
	private Date firstReceived;

	@Column(name = "docs_first_sent")
	private Date docsFirstSent;

	@Column(name = "bhc_last_updated")
	private Date bhcLastUpdated;

	@Column(name = "doc_team_clerk")
	private String docTeamClerk;

	@Column(name = "addendum_received")
	private Integer addendumReceived;

	@Column(name = "rx_received")
	private Integer rxReceived;
	
	@Column(name="rx_sent")
	private Boolean RXSent;

	@Column(name = "patient_not_seen_30")
	private Integer patientNotSeen30;

	@Column(name = "attachments", columnDefinition = "json")
	private String attachments;

	@Column(name = "reassigned_to")
	private Integer reassignedTo;

	@Column(name = "patient_linked")
	private Boolean patientLinked;

	@Column(name = "patient_link_username")
	private String patientLinkUsername;

	@Column(name = "patient_link_user_id")
	private Long patientLinkUserId;

	@Column(name = "patient_link_userfullname")
	private String patientLinkUserFullname;

	@Column(name = "patient_link_timestamp")
	private Timestamp patientLinkTimestamp;

	@Column(name = "addendum")
	private Integer addendum;

	@Column(name = "addendum_user_fullname")
	private String addendumUserFullname;

	@Column(name = "addendum_user_id")
	private Long addendumUserId;

	@Column(name = "addendum_username")
	private String addendumUsername;

	@Column(name = "record_modify")
	private Integer recordModify;

	@Column(name = "record_modify_user_fullname")
	private String recordModifyUserFullname;

	@Column(name = "record_modify_user_id")
	private Long recordModifyUserId;

	@Column(name = "record_modify_username")
	private String recordModifyUsername;

	public Boolean getRXSent() {
		return RXSent;
	}

	public void setRXSent(Boolean rXSent) {
		RXSent = rXSent;
	}

	public Date getDocsFirstSent() {
		return docsFirstSent;
	}

	public void setDocsFirstSent(Date docsFirstSent) {
		this.docsFirstSent = docsFirstSent;
	}

	public Integer getAddendum() {
		return addendum;
	}

	public void setAddendum(Integer addendum) {
		this.addendum = addendum;
	}

	public String getAddendumUserFullname() {
		return addendumUserFullname;
	}

	public void setAddendumUserFullname(String addendumUserFullname) {
		this.addendumUserFullname = addendumUserFullname;
	}

	public Long getAddendumUserId() {
		return addendumUserId;
	}

	public void setAddendumUserId(Long addendumUserId) {
		this.addendumUserId = addendumUserId;
	}

	public String getAddendumUsername() {
		return addendumUsername;
	}

	public void setAddendumUsername(String addendumUsername) {
		this.addendumUsername = addendumUsername;
	}

	public Integer getRecordModify() {
		return recordModify;
	}

	public void setRecordModify(Integer recordModify) {
		this.recordModify = recordModify;
	}

	public String getRecordModifyUserFullname() {
		return recordModifyUserFullname;
	}

	public void setRecordModifyUserFullname(String recordModifyUserFullname) {
		this.recordModifyUserFullname = recordModifyUserFullname;
	}

	public Long getRecordModifyUserId() {
		return recordModifyUserId;
	}

	public void setRecordModifyUserId(Long recordModifyUserId) {
		this.recordModifyUserId = recordModifyUserId;
	}

	public String getRecordModifyUsername() {
		return recordModifyUsername;
	}

	public void setRecordModifyUsername(String recordModifyUsername) {
		this.recordModifyUsername = recordModifyUsername;
	}

	public String getLastTeamUpdatedUserFullname() {
		return lastTeamUpdatedUserFullname;
	}

	public void setLastTeamUpdatedUserFullname(
			String lastTeamUpdatedUserFullname) {
		this.lastTeamUpdatedUserFullname = lastTeamUpdatedUserFullname;
	}

	public Boolean getPatientLinked() {
		return patientLinked;
	}

	public void setPatientLinked(Boolean patientLinked) {
		this.patientLinked = patientLinked;
	}

	public String getPatientLinkUsername() {
		return patientLinkUsername;
	}

	public void setPatientLinkUsername(String patientLinkUsername) {
		this.patientLinkUsername = patientLinkUsername;
	}

	public Long getPatientLinkUserId() {
		return patientLinkUserId;
	}

	public void setPatientLinkUserId(Long patientLinkUserId) {
		this.patientLinkUserId = patientLinkUserId;
	}

	public String getPatientLinkUserFullname() {
		return patientLinkUserFullname;
	}

	public void setPatientLinkUserFullname(String patientLinkUserFullname) {
		this.patientLinkUserFullname = patientLinkUserFullname;
	}

	public Timestamp getPatientLinkTimestamp() {
		return patientLinkTimestamp;
	}

	public void setPatientLinkTimestamp(Timestamp patientLinkTimestamp) {
		this.patientLinkTimestamp = patientLinkTimestamp;
	}

	public Integer getReassignedTo() {
		return reassignedTo;
	}

	public void setReassignedTo(Integer reassignedTo) {
		this.reassignedTo = reassignedTo;
	}

	public Integer getAddendumReceived() {
		return addendumReceived;
	}

	public void setAddendumReceived(Integer addendumReceived) {
		this.addendumReceived = addendumReceived;
	}

	public Integer getRxReceived() {
		return rxReceived;
	}

	public void setRxReceived(Integer rxReceived) {
		this.rxReceived = rxReceived;
	}

	public Integer getPatientNotSeen30() {
		return patientNotSeen30;
	}

	public void setPatientNotSeen30(Integer patientNotSeen30) {
		this.patientNotSeen30 = patientNotSeen30;
	}

	public String getDocTeamClerk() {
		return docTeamClerk;
	}

	public void setDocTeamClerk(String docTeamClerk) {
		this.docTeamClerk = docTeamClerk;
	}

	public String getInsuranceCategory() {
		return insuranceCategory;
	}

	public void setInsuranceCategory(String insuranceCategory) {
		this.insuranceCategory = insuranceCategory;
	}

	public String getProviderFullname() {
		return providerFullname;
	}

	public void setProviderFullname(String providerFullname) {
		this.providerFullname = providerFullname;
	}

	public Date getAge() {
		return age;
	}

	public void setAge(Date age) {
		this.age = age;
	}

	public Boolean getRecordActive() {
		return recordActive;
	}

	public void setRecordActive(Boolean recordActive) {
		this.recordActive = recordActive;
	}

	public Date getLastReceived() {
		return lastReceived;
	}

	public void setLastReceived(Date lastReceived) {
		this.lastReceived = lastReceived;
	}

	public Timestamp getLastFileUploaded() {
		return lastFileUploaded;
	}

	public void setLastFileUploaded(Timestamp lastFileUploaded) {
		this.lastFileUploaded = lastFileUploaded;
	}

	public Long getFilesSent() {
		return filesSent;
	}

	public void setFilesSent(Long filesSent) {
		this.filesSent = filesSent;
	}

	public Long getNoOfUpdates() {
		return noOfUpdates;
	}

	public void setNoOfUpdates(Long noOfUpdates) {
		this.noOfUpdates = noOfUpdates;
	}

	public Timestamp getLastActioned() {
		return lastActioned;
	}

	public void setLastActioned(Timestamp lastActioned) {
		this.lastActioned = lastActioned;
	}

	public Date getFollowupDate() {
		return followupDate;
	}

	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}

	public Date getFirstReceived() {
		return firstReceived;
	}

	public void setFirstReceived(Date firstReceived) {
		this.firstReceived = firstReceived;
	}

	public Date getBhcLastUpdated() {
		return bhcLastUpdated;
	}

	public void setBhcLastUpdated(Date bhcLastUpdated) {
		this.bhcLastUpdated = bhcLastUpdated;
	}

	public Timestamp getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Timestamp lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}

	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}

	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}

	public Timestamp getStatusUpdatedDateTime() {
		return statusUpdatedDateTime;
	}

	public void setStatusUpdatedDateTime(Timestamp statusUpdatedDateTime) {
		this.statusUpdatedDateTime = statusUpdatedDateTime;
	}

	public String getStatusUpdatedUserFullName() {
		return statusUpdatedUserFullName;
	}

	public void setStatusUpdatedUserFullName(String statusUpdatedUserFullName) {
		this.statusUpdatedUserFullName = statusUpdatedUserFullName;
	}

	public Long getStatusUpdatedUserId() {
		return statusUpdatedUserId;
	}

	public void setStatusUpdatedUserId(Long statusUpdatedUserId) {
		this.statusUpdatedUserId = statusUpdatedUserId;
	}

	public String getStatusUpdatedUserName() {
		return statusUpdatedUserName;
	}

	public void setStatusUpdatedUserName(String statusUpdatedUserName) {
		this.statusUpdatedUserName = statusUpdatedUserName;
	}

	public String getPatientFullname() {
		return patientFullname;
	}

	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}

	public Timestamp getLastTeamUpdated() {
		return lastTeamUpdated;
	}

	public void setLastTeamUpdated(Timestamp lastTeamUpdated) {
		this.lastTeamUpdated = lastTeamUpdated;
	}

	public int getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(int bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getBhcReferralId() {
		return bhcReferralId;
	}

	public void setBhcReferralId(String bhcReferralId) {
		this.bhcReferralId = bhcReferralId;
	}

	public String getBhcOrderSource() {
		return bhcOrderSource;
	}

	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}

	public Integer getHealogicsOrderId() {
		return healogicsOrderId;
	}

	public void setHealogicsOrderId(Integer healogicsOrderId) {
		this.healogicsOrderId = healogicsOrderId;
	}

	public Integer getHealogicsPatientId() {
		return healogicsPatientId;
	}

	public void setHealogicsPatientId(Integer healogicsPatientId) {
		this.healogicsPatientId = healogicsPatientId;
	}

	public String getHealogicsPatientMRN() {
		return healogicsPatientMRN;
	}

	public void setHealogicsPatientMRN(String healogicsPatientMRN) {
		this.healogicsPatientMRN = healogicsPatientMRN;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public LocalDate getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(LocalDate patientDOB) {
		this.patientDOB = patientDOB;
	}

	public Date getBhcOrderReceivedDate() {
		return bhcOrderReceivedDate;
	}

	public void setBhcOrderReceivedDate(Date bhcOrderReceivedDate) {
		this.bhcOrderReceivedDate = bhcOrderReceivedDate;
	}

	public Date getBhcShipDate() {
		return bhcShipDate;
	}

	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}

	public String getBhcPrimaryInsurance() {
		return bhcPrimaryInsurance;
	}

	public void setBhcPrimaryInsurance(String bhcPrimaryInsurance) {
		this.bhcPrimaryInsurance = bhcPrimaryInsurance;
	}

	public String getPrimaryInsurancePolicyId() {
		return primaryInsurancePolicyId;
	}

	public void setPrimaryInsurancePolicyId(String primaryInsurancePolicyId) {
		this.primaryInsurancePolicyId = primaryInsurancePolicyId;
	}

	public Integer getBhcPhysicianId() {
		return bhcPhysicianId;
	}

	public void setBhcPhysicianId(Integer bhcPhysicianId) {
		this.bhcPhysicianId = bhcPhysicianId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public Long getProviderNPI() {
		return providerNPI;
	}

	public void setProviderNPI(Long providerNPI) {
		this.providerNPI = providerNPI;
	}

	public String getProviderPhone() {
		return providerPhone;
	}

	public void setProviderPhone(String providerPhone) {
		this.providerPhone = providerPhone;
	}

	public String getProviderFax() {
		return providerFax;
	}

	public void setProviderFax(String providerFax) {
		this.providerFax = providerFax;
	}

	public Integer getBhcPatientAcctId() {
		return bhcPatientAcctId;
	}

	public void setBhcPatientAcctId(Integer bhcPatientAcctId) {
		this.bhcPatientAcctId = bhcPatientAcctId;
	}

	public Integer getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}

	public void setBhcInvoiceOrderId(Integer bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}

	public String getManufacturerName() {
		return manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public String getManufacturerProductName() {
		return manufacturerProductName;
	}

	public void setManufacturerProductName(String manufacturerProductName) {
		this.manufacturerProductName = manufacturerProductName;
	}

	public String getManufacturerItemNumber() {
		return manufacturerItemNumber;
	}

	public void setManufacturerItemNumber(String manufacturerItemNumber) {
		this.manufacturerItemNumber = manufacturerItemNumber;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getHcpcs() {
		return hcpcs;
	}

	public void setHcpcs(String hcpcs) {
		this.hcpcs = hcpcs;
	}

	public String getByramCatalogNumber() {
		return byramCatalogNumber;
	}

	public void setByramCatalogNumber(String byramCatalogNumber) {
		this.byramCatalogNumber = byramCatalogNumber;
	}

	public String getRxValidated() {
		return rxValidated;
	}

	public void setRxValidated(String rxValidated) {
		this.rxValidated = rxValidated;
	}

	public String getShippingCarrier() {
		return shippingCarrier;
	}

	public void setShippingCarrier(String shippingCarrier) {
		this.shippingCarrier = shippingCarrier;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getShippingAddress1() {
		return shippingAddress1;
	}

	public void setShippingAddress1(String shippingAddress1) {
		this.shippingAddress1 = shippingAddress1;
	}

	public String getShippingAddress2() {
		return shippingAddress2;
	}

	public void setShippingAddress2(String shippingAddress2) {
		this.shippingAddress2 = shippingAddress2;
	}

	public String getShippingCity() {
		return shippingCity;
	}

	public void setShippingCity(String shippingCity) {
		this.shippingCity = shippingCity;
	}

	public String getShippingState() {
		return shippingState;
	}

	public void setShippingState(String shippingState) {
		this.shippingState = shippingState;
	}

	public String getShippingZip() {
		return shippingZip;
	}

	public void setShippingZip(String shippingZip) {
		this.shippingZip = shippingZip;
	}

	public Date getMedicalRecordAddedDate() {
		return medicalRecordAddedDate;
	}

	public void setMedicalRecordAddedDate(Date medicalRecordAddedDate) {
		this.medicalRecordAddedDate = medicalRecordAddedDate;
	}

	public String getBhcDocumentStatus() {
		return bhcDocumentStatus;
	}

	public void setBhcDocumentStatus(String bhcDocumentStatus) {
		this.bhcDocumentStatus = bhcDocumentStatus;
	}

	public String getBhcDocumentType() {
		return bhcDocumentType;
	}

	public void setBhcDocumentType(String bhcDocumentType) {
		this.bhcDocumentType = bhcDocumentType;
	}

	public Date getMedicalRecordStartDate() {
		return medicalRecordStartDate;
	}

	public void setMedicalRecordStartDate(Date medicalRecordStartDate) {
		this.medicalRecordStartDate = medicalRecordStartDate;
	}

	public String getBhcMissingDocType() {
		return bhcMissingDocType;
	}

	public void setBhcMissingDocType(String bhcMissingDocType) {
		this.bhcMissingDocType = bhcMissingDocType;
	}

	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}

	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}

	public String getBackorder() {
		return backorder;
	}

	public void setBackorder(String backorder) {
		this.backorder = backorder;
	}

	public String getOverage() {
		return overage;
	}

	public void setOverage(String overage) {
		this.overage = overage;
	}

	public String getBhcMissingDoc() {
		return bhcMissingDoc;
	}

	public void setBhcMissingDoc(String bhcMissingDoc) {
		this.bhcMissingDoc = bhcMissingDoc;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getInvoiceNetBalance() {
		return invoiceNetBalance;
	}

	public void setInvoiceNetBalance(String invoiceNetBalance) {
		this.invoiceNetBalance = invoiceNetBalance;
	}

	public String getInvoiceBalanceDue() {
		return invoiceBalanceDue;
	}

	public void setInvoiceBalanceDue(String invoiceBalanceDue) {
		this.invoiceBalanceDue = invoiceBalanceDue;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getAssigneeFullName() {
		return assigneeFullName;
	}

	public void setAssigneeFullName(String assigneeFullName) {
		this.assigneeFullName = assigneeFullName;
	}

	public Integer getActive() {
		return active;
	}

	public void setActive(Integer active) {
		this.active = active;
	}

	public String getAttachments() {
		return attachments;
	}

	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}

	public String getBhcPrimaryInsuranceReceived() {
		return bhcPrimaryInsuranceReceived;
	}

	public void setBhcPrimaryInsuranceReceived(
			String bhcPrimaryInsuranceReceived) {
		this.bhcPrimaryInsuranceReceived = bhcPrimaryInsuranceReceived;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	@Override
	public String toString() {
		return "AWDDashboard [bhcInvoiceOrderId=" + bhcInvoiceOrderId + ", bhcMedicalRecordId=" + bhcMedicalRecordId
				+ ", bbc=" + bbc + ", facilityName=" + facilityName + ", facilityType=" + facilityType
				+ ", bhcReferralId=" + bhcReferralId + ", bhcOrderSource=" + bhcOrderSource + ", healogicsOrderId="
				+ healogicsOrderId + ", healogicsPatientId=" + healogicsPatientId + ", healogicsPatientMRN="
				+ healogicsPatientMRN + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", patientFullname=" + patientFullname + ", patientDOB=" + patientDOB
				+ ", bhcOrderReceivedDate=" + bhcOrderReceivedDate + ", bhcShipDate=" + bhcShipDate
				+ ", bhcPrimaryInsurance=" + bhcPrimaryInsurance + ", bhcPrimaryInsuranceReceived="
				+ bhcPrimaryInsuranceReceived + ", primaryInsurancePolicyId=" + primaryInsurancePolicyId
				+ ", bhcPhysicianId=" + bhcPhysicianId + ", providerFirstName=" + providerFirstName
				+ ", providerLastName=" + providerLastName + ", providerNPI=" + providerNPI + ", providerPhone="
				+ providerPhone + ", providerFax=" + providerFax + ", bhcPatientAcctId=" + bhcPatientAcctId
				+ ", manufacturerName=" + manufacturerName + ", manufacturerProductName=" + manufacturerProductName
				+ ", manufacturerItemNumber=" + manufacturerItemNumber + ", productDescription=" + productDescription
				+ ", quantity=" + quantity + ", unitOfMeasure=" + unitOfMeasure + ", hcpcs=" + hcpcs
				+ ", byramCatalogNumber=" + byramCatalogNumber + ", rxValidated=" + rxValidated + ", shippingCarrier="
				+ shippingCarrier + ", trackingId=" + trackingId + ", shippingAddress1=" + shippingAddress1
				+ ", shippingAddress2=" + shippingAddress2 + ", shippingCity=" + shippingCity + ", shippingState="
				+ shippingState + ", shippingZip=" + shippingZip + ", medicalRecordAddedDate=" + medicalRecordAddedDate
				+ ", bhcDocumentStatus=" + bhcDocumentStatus + ", bhcDocumentType=" + bhcDocumentType
				+ ", medicalRecordStartDate=" + medicalRecordStartDate + ", bhcMissingDocType=" + bhcMissingDocType
				+ ", bhcMissingDocNotes=" + bhcMissingDocNotes + ", backorder=" + backorder + ", overage=" + overage
				+ ", bhcMissingDoc=" + bhcMissingDoc + ", lastUpdatedDate=" + lastUpdatedDate + ", lastTeamUpdated="
				+ lastTeamUpdated + ", lastTeamUpdatedUserFullname=" + lastTeamUpdatedUserFullname
				+ ", invoiceNetBalance=" + invoiceNetBalance + ", invoiceBalanceDue=" + invoiceBalanceDue + ", status="
				+ status + ", assignee=" + assignee + ", assigneeFullName=" + assigneeFullName
				+ ", lastUpdatedDateTime=" + lastUpdatedDateTime + ", lastUpdatedUserFullName="
				+ lastUpdatedUserFullName + ", lastUpdatedUserId=" + lastUpdatedUserId + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", statusUpdatedDateTime=" + statusUpdatedDateTime
				+ ", statusUpdatedUserFullName=" + statusUpdatedUserFullName + ", statusUpdatedUserId="
				+ statusUpdatedUserId + ", statusUpdatedUserName=" + statusUpdatedUserName + ", active=" + active
				+ ", insuranceCategory=" + insuranceCategory + ", providerFullname=" + providerFullname + ", age=" + age
				+ ", recordActive=" + recordActive + ", lastReceived=" + lastReceived + ", lastFileUploaded="
				+ lastFileUploaded + ", filesSent=" + filesSent + ", noOfUpdates=" + noOfUpdates + ", lastActioned="
				+ lastActioned + ", followupDate=" + followupDate + ", firstReceived=" + firstReceived
				+ ", docsFirstSent=" + docsFirstSent + ", bhcLastUpdated=" + bhcLastUpdated + ", docTeamClerk="
				+ docTeamClerk + ", addendumReceived=" + addendumReceived + ", rxReceived=" + rxReceived + ", RXSent="
				+ RXSent + ", patientNotSeen30=" + patientNotSeen30 + ", attachments=" + attachments + ", reassignedTo="
				+ reassignedTo + ", patientLinked=" + patientLinked + ", patientLinkUsername=" + patientLinkUsername
				+ ", patientLinkUserId=" + patientLinkUserId + ", patientLinkUserFullname=" + patientLinkUserFullname
				+ ", patientLinkTimestamp=" + patientLinkTimestamp + ", addendum=" + addendum
				+ ", addendumUserFullname=" + addendumUserFullname + ", addendumUserId=" + addendumUserId
				+ ", addendumUsername=" + addendumUsername + ", recordModify=" + recordModify
				+ ", recordModifyUserFullname=" + recordModifyUserFullname + ", recordModifyUserId="
				+ recordModifyUserId + ", recordModifyUsername=" + recordModifyUsername + "]";
	}

}
