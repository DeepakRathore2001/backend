package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "documentation_history")
public class DocumentationHistory2 {

	@Id
	@Column(name = "history_id")
	private Long historyId;

	@Column(name = "request_id")
	private String requestId;

	@Column(name = "user_notes")
	private String userNotes;

	@Column(name = "retrieve_status")
	private String retrieveStatus;

	@Column(name = "patient_id")
	private Long patientId;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "facility_id")
	private Long facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "document_object")
	private String documentObject;

	@Column(name = "assigned_to")
	private String assignedTo;

	@Column(name = "reassigned_to")
	private String reAssignedTo;

	@Column(name = "vendor_status")
	private String vendorStatus;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "last_updated_username")
	private String lastUpdatedUserName;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullName;

	@Column(name = "last_updated_user_id")
	private Long lastUpdatedUserId;

	public Long getHistoryId() {
		return historyId;
	}

	public void setHistoryId(Long historyId) {
		this.historyId = historyId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getUserNotes() {
		return userNotes;
	}

	public void setUserNotes(String userNotes) {
		this.userNotes = userNotes;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public Long getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getDocumentObject() {
		return documentObject;
	}

	public void setDocumentObject(String documentObject) {
		this.documentObject = documentObject;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getReAssignedTo() {
		return reAssignedTo;
	}

	public void setReAssignedTo(String reAssignedTo) {
		this.reAssignedTo = reAssignedTo;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}

	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}

	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}

	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}

	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	@Override
	public String toString() {
		return "DocumentationHistory2 [historyId=" + historyId + ", requestId=" + requestId + ", userNotes=" + userNotes
				+ ", retrieveStatus=" + retrieveStatus + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", patientDOB=" + patientDOB + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", documentObject=" + documentObject + ", assignedTo=" + assignedTo + ", reAssignedTo=" + reAssignedTo
				+ ", vendorStatus=" + vendorStatus + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", lastUpdatedUserName=" + lastUpdatedUserName + ", lastUpdatedUserFullName="
				+ lastUpdatedUserFullName + ", lastUpdatedUserId=" + lastUpdatedUserId + "]";
	}

}
