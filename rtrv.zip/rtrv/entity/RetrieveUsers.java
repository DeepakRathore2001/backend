package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "retrieve_users")
public class RetrieveUsers {
	@Id
	@Column(name = "user_id")
	private Long userId;

	@Column(name = "username")
	private String username;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "last_logged_in_timestamp")
	private Timestamp lastLoggedInTimestamp;

	@Column(name = "user_full_name")
	private String userFullName;

	@Column(name = "retrieve_role")
	private String retrieveRole;

	@Column(name = "business_role", columnDefinition = "json")
	private String businessRole;

	@Column(name = "facilities", columnDefinition = "json")
	private String facilities;

	@Column(name = "is_super_user")
	private Boolean isSuperUser;

	public Boolean getIsSuperUser() {
		return isSuperUser;
	}

	public void setIsSuperUser(Boolean isSuperUser) {
		this.isSuperUser = isSuperUser;
	}

	public String getBusinessRole() {
		return businessRole;
	}

	public void setBusinessRole(String businessRole) {
		this.businessRole = businessRole;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Timestamp getLastLoggedInTimestamp() {
		return lastLoggedInTimestamp;
	}

	public void setLastLoggedInTimestamp(Timestamp lastLoggedInTimestamp) {
		this.lastLoggedInTimestamp = lastLoggedInTimestamp;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getRetrieveRole() {
		return retrieveRole;
	}

	public void setRetrieveRole(String retrieveRole) {
		this.retrieveRole = retrieveRole;
	}

	@Override
	public String toString() {
		return "RetrieveUsers [userId=" + userId + ", username=" + username
				+ ", emailId=" + emailId + ", lastLoggedInTimestamp="
				+ lastLoggedInTimestamp + ", userFullName=" + userFullName
				+ ", retrieveRole=" + retrieveRole + ", businessRole="
				+ businessRole + ", facilities=" + facilities + ", isSuperUser="
				+ isSuperUser + "]";
	}

}
