package com.healogics.rtrv.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "primary_key_lookup")
public class PrimaryKeyLookup {
	@Id
	@Column(name = "retrieve_request_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long retrieveReqId;
	
	@Column(name = "vendor_id")
	private int vendorId;
	
	@Column(name = "vendor_name")
	private String vendorName;
	
	@Column(name = "service_line")
	private String serviceLine;
	
	@Column(name = "_1")
	private String primaryKey1;
	
	@Column(name = "_2")
	private String primaryKey2;
	
	@Column(name = "_3")
	private String primaryKey3;
	
	@Column(name = "_4")
	private String primaryKey4;
	
	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Long getRetrieveReqId() {
		return retrieveReqId;
	}

	public void setRetrieveReqId(Long retrieveReqId) {
		this.retrieveReqId = retrieveReqId;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getPrimaryKey1() {
		return primaryKey1;
	}

	public void setPrimaryKey1(String primaryKey1) {
		this.primaryKey1 = primaryKey1;
	}

	public String getPrimaryKey2() {
		return primaryKey2;
	}

	public void setPrimaryKey2(String primaryKey2) {
		this.primaryKey2 = primaryKey2;
	}

	public String getPrimaryKey3() {
		return primaryKey3;
	}

	public void setPrimaryKey3(String primaryKey3) {
		this.primaryKey3 = primaryKey3;
	}

	public String getPrimaryKey4() {
		return primaryKey4;
	}

	public void setPrimaryKey4(String primaryKey4) {
		this.primaryKey4 = primaryKey4;
	}

	@Override
	public String toString() {
		return "PrimaryKeyLookup [retrieveReqId=" + retrieveReqId + ", vendorId=" + vendorId + ", vendorName="
				+ vendorName + ", serviceLine=" + serviceLine + ", primaryKey1=" + primaryKey1 + ", primaryKey2="
				+ primaryKey2 + ", primaryKey3=" + primaryKey3 + ", primaryKey4=" + primaryKey4 + ", createdTimestamp="
				+ createdTimestamp + "]";
	}
}
