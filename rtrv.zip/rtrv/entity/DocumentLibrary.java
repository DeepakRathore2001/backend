package com.healogics.rtrv.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document_library")
public class DocumentLibrary {

	@Id
	@Column(name = "vendor_id")
	private Integer vendorId;

	@Column(name = "vendor_name")
	private String vendorName;
	
	@Column(name = "service_line")
	private String serviceLine;
	
	@Column(name = "document_list", columnDefinition = "json")
	private String documentList;

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getDocumentList() {
		return documentList;
	}

	public void setDocumentList(String documentList) {
		this.documentList = documentList;
	}

	@Override
	public String toString() {
		return "DocumentLibrary [vendorId=" + vendorId + ", vendorName=" + vendorName + ", serviceLine=" + serviceLine
				+ ", documentList=" + documentList + "]";
	}
}
