package com.healogics.rtrv.entity;

import java.util.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document_name")
public class DocumentName {
	@Id
	@Column(name = "bhc_medical_record_id")
	private Long bhcMedRecId;
	
	@Column(name = "bhc_invoice_order_no")
	private Long bhcInvOrderNo;
	
	@Column(name = "document_type")
	private String documentType;
	
	@Column(name = "document_id")
	private Long documentId;
	
	@Column(name = "bluebook_id")
	private String bluebookId;
	
	@Column(name = "facility_id")
	private int facilityId;
	
	@Column(name = "facility_name")
	private String facilityName;
	
	@Column(name = "patient_first_name")
	private String patientFirstName;
	
	@Column(name = "patient_last_name")
	private String patientLastName;
	
	@Column(name = "bhc_ship_date")
	private Date bhcShipDate;
	
	@Column(name = "bhc_patient_acct_no")
	private Long bhcPatientAcctNo;
	
	@Column(name = "bhc_patient_inv")
	private String bhcPatientInv;
	
	@Column(name = "date_doc_sent")
	private Date dateDocSent;
	
	@Column(name = "visit_date")
	private Date visitDate;
	
	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;
	
	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;
	
	@Column(name = "created_username")
	private String createdUsername;
	
	@Column(name = "last_updated_by_username")
	private String lastUpdatedByUsername;
	
	@Column(name = "created_user_id")
	private Long createdUserId;
	
	@Column(name = "last_updated_by_user_id")
	private Long lastUpdatedByUserId;
	
	@Column(name = "created_user_fullname")
	private String createdUserFullname;
	
	@Column(name = "last_updated_by_user_fullname")
	private String lastUpdatedByUserFullname;

	public Long getBhcMedRecId() {
		return bhcMedRecId;
	}

	public void setBhcMedRecId(Long bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}

	public Long getBhcInvOrderNo() {
		return bhcInvOrderNo;
	}

	public void setBhcInvOrderNo(Long bhcInvOrderNo) {
		this.bhcInvOrderNo = bhcInvOrderNo;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Long getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public Date getBhcShipDate() {
		return bhcShipDate;
	}

	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}

	public Long getBhcPatientAcctNo() {
		return bhcPatientAcctNo;
	}

	public void setBhcPatientAcctNo(Long bhcPatientAcctNo) {
		this.bhcPatientAcctNo = bhcPatientAcctNo;
	}

	public String getBhcPatientInv() {
		return bhcPatientInv;
	}

	public void setBhcPatientInv(String bhcPatientInv) {
		this.bhcPatientInv = bhcPatientInv;
	}

	public Date getDateDocSent() {
		return dateDocSent;
	}

	public void setDateDocSent(Date dateDocSent) {
		this.dateDocSent = dateDocSent;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getCreatedUsername() {
		return createdUsername;
	}

	public void setCreatedUsername(String createdUsername) {
		this.createdUsername = createdUsername;
	}

	public String getLastUpdatedByUsername() {
		return lastUpdatedByUsername;
	}

	public void setLastUpdatedByUsername(String lastUpdatedByUsername) {
		this.lastUpdatedByUsername = lastUpdatedByUsername;
	}

	public Long getCreatedUserId() {
		return createdUserId;
	}

	public void setCreatedUserId(Long createdUserId) {
		this.createdUserId = createdUserId;
	}

	public Long getLastUpdatedByUserId() {
		return lastUpdatedByUserId;
	}

	public void setLastUpdatedByUserId(Long lastUpdatedByUserId) {
		this.lastUpdatedByUserId = lastUpdatedByUserId;
	}

	public String getCreatedUserFullname() {
		return createdUserFullname;
	}

	public void setCreatedUserFullname(String createdUserFullname) {
		this.createdUserFullname = createdUserFullname;
	}

	public String getLastUpdatedByUserFullname() {
		return lastUpdatedByUserFullname;
	}

	public void setLastUpdatedByUserFullname(String lastUpdatedByUserFullname) {
		this.lastUpdatedByUserFullname = lastUpdatedByUserFullname;
	}

	@Override
	public String toString() {
		return "DocumentName [bhcMedRecId=" + bhcMedRecId + ", bhcInvOrderNo=" + bhcInvOrderNo + ", documentType="
				+ documentType + ", documentId=" + documentId + ", bluebookId=" + bluebookId + ", facilityId="
				+ facilityId + ", facilityName=" + facilityName + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", bhcShipDate=" + bhcShipDate + ", bhcPatientAcctNo="
				+ bhcPatientAcctNo + ", bhcPatientInv=" + bhcPatientInv + ", dateDocSent=" + dateDocSent
				+ ", visitDate=" + visitDate + ", createdTimestamp=" + createdTimestamp + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", createdUsername=" + createdUsername + ", lastUpdatedByUsername="
				+ lastUpdatedByUsername + ", createdUserId=" + createdUserId + ", lastUpdatedByUserId="
				+ lastUpdatedByUserId + ", createdUserFullname=" + createdUserFullname + ", lastUpdatedByUserFullname="
				+ lastUpdatedByUserFullname + "]";
	}
}
