package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "chart_details")
public class MasterChartDetails {

	@Id
	@Column(name = "request_id")
	private String orderId;

	@Column(name = "facility_id")
	private Integer facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_name")
	private String facilityName;

	@Column(name = "healogics_patient_id")
	private Integer healogicsPatientId;

	@Column(name = "healogics_patient_mrn")
	private String healogicsPatientMRN;

	@Column(name = "vendor_id")
	private Integer vendorId;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "order_source")
	private String orderSource;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "patient_fullname")
	private String patientFullname;

	@Column(name = "patient_dob")
	private Date patientDOB;

	@Column(name = "physician_first_name")
	private String physicianFirstName;

	@Column(name = "physician_last_name")
	private String physicianLastName;

	@Column(name = "case_manager_first_name")
	private String caseManagerFirstName;

	@Column(name = "case_manager_last_name")
	private String caseManagerLastName;

	@Column(name = "received_date")
	private Date receivedDate;

	@Column(name = "vendor_status")
	private String vendorStatus;

	@Column(name = "waiting_docs_sec_status")
	private String waitingDocsSecStatus;

	@Column(name = "pend_prior_auth_date")
	private Date pendPriorAuthDate;

	@Column(name = "pend_prior_auth_waiting")
	private String pendPriorAuthWaiting;

	@Column(name = "under_appeal_date")
	private Date underAppealDate;

	@Column(name = "under_appeal_status")
	private String underAppealStatus;

	@Column(name = "followup_date")
	private Date followupDate;

	@Lob
	@Column(name = "missing_elements")
	private String missingElements;

	@Lob
	@Column(name = "special_instructions")
	private String specialInstructions;

	@Column(name = "primary_insurance", columnDefinition = "json")
	private String primaryInsurance;

	@Column(name = "primary_insurance_company")
	private String primaryInsuranceCompany;

	@Column(name = "secondary_insurance", columnDefinition = "json")
	private String sencondaryInsurance;

	@Column(name = "tertiary_insruance", columnDefinition = "json")
	private String tertiaryInsurance;

	@Column(name = "hcpc")
	private String hcpc;

	@Column(name = "product_sku")
	private String productSKU;

	@Column(name = "product_name")
	private String productName;

	@Column(name = "no_app_approved")
	private String noAppApproved;

	@Column(name = "no_units_approved")
	private String noUnitsApproved;

	@Column(name = "approval_timeframe")
	private String approvalTimeframe;

	@Column(name = "icd10_codes", columnDefinition = "json")
	private String icd10Codes;

	@Column(name = "place_of_service")
	private String placeOfService;

	@Column(name = "wound_id")
	private String woundId;

	@Column(name = "completed_date")
	private Date completedDate;

	@Column(name = "completed_status")
	private String completedStatus;

	@Lob
	@Column(name = "coverage_summary")
	private String coverageSummary;

	@Column(name = "sales_rep_manager")
	private String salesRepManager;

	@Column(name = "regional_director")
	private String reginalDirector;

	@Column(name = "sgp")
	private String sgp;

	@Column(name = "sgp_date")
	private Date sgpDate;

	@Column(name = "sgp_cpt_code")
	private String sgpCPTCode;

	@Column(name = "last_updated_timestamp")
	private Timestamp lastUpdatedTimestamp;

	@Column(name = "last_updated_username")
	private String lastUpdatedUsername;

	@Column(name = "last_updated_user_fullname")
	private String lastUpdatedUserFullname;

	@Column(name = "last_updated_user_id")
	private String lastUpdatedUserId;

	@Column(name = "retrieve_status")
	private String retrieveStatus;

	@Column(name = "status_updated_time")
	private Timestamp statusUpdatedTimestamp;

	@Column(name = "provider_name")
	private String providerName;

	@Column(name = "last_received")
	private Timestamp lastReceived;

	@Column(name = "last_actioned")
	private Timestamp lastActioned;

	@Column(name = "woundq_order_no")
	private String woundqOrderNo;

	@Column(name = "first_received")
	private Timestamp firstReceived;

	@Column(name = "last_file_updated")
	private Timestamp lastFileUpdated;

	@Column(name = "files_sent")
	private Integer filesSent;

	@Column(name = "no_of_updates")
	private Integer noOfUpdates;

	@Column(name = "last_team_updated")
	private Timestamp lastTeamUpdatedTimestamp;

	@Column(name = "last_team_updated_userfullname")
	private String lastTeamUpdatedUserFullname;

	@Column(name = "status_updated_user_fullname")
	private String statusUpdatedUserFullName;

	@Column(name = "status_updated_user_id")
	private String statusUpdatedUserId;

	@Column(name = "status_updated_username")
	private String statusUpdatedUserName;

	@Lob
	@Column(name = "status_change_notes")
	private String statusChangeNotes;

	@Column(name = "secondary_status")
	private String secondaryStatus;

	@Column(name = "addendum")
	private Integer addendum;

	@Column(name = "addendum_user_fullname")
	private String addendumUserFullname;

	@Column(name = "addendum_user_id")
	private Integer addendumUserId;

	@Column(name = "addendum_username")
	private String addendumUsername;

	@Column(name = "record_modify")
	private Integer recordModify;

	@Column(name = "record_modify_user_fullname")
	private String recordModifyUserFullname;

	@Column(name = "record_modify_user_id")
	private Integer recordModifyUserId;

	@Column(name = "record_modify_username")
	private String recordModifyUsername;

	@Column(name = "vendor_referral_no")
	private String vendorReferralNo;

	@Column(name = "order_no")
	private String rentalOrderNo;
	
	@Column(name = "csr_name")
	private String csrName;
	
	@Column(name = "csr_phone")
	private String csrPhone;
	
	@Column(name = "csr_email")
	private String csrEmail;
	
	@Column (name="patient_linked")
	private Boolean patientLinked;
	
	@Column (name="patient_link_username")
	private String patientLinkUsername;
	
	@Column (name= "patient_link_user_id")
	private String patientLinkUserId;
	
	@Column (name= "patient_link_user_fullname")
	private String patientLinkUserFullname;
	
	@Column (name="patient_link_timestamp")
	private Timestamp patientLinkTimestamp;
	
	public Timestamp getPatientLinkTimestamp() {
		return patientLinkTimestamp;
	}

	public void setPatientLinkTimestamp(Timestamp patientLinkTimestamp) {
		this.patientLinkTimestamp = patientLinkTimestamp;
	}

	public Boolean getPatientLinked() {
		return patientLinked;
	}

	public void setPatientLinked(Boolean patientLinked) {
		this.patientLinked = patientLinked;
	}

	public String getPatientLinkUsername() {
		return patientLinkUsername;
	}

	public void setPatientLinkUsername(String patientLinkUsername) {
		this.patientLinkUsername = patientLinkUsername;
	}

	public String getPatientLinkUserId() {
		return patientLinkUserId;
	}

	public void setPatientLinkUserId(String patientLinkUserId) {
		this.patientLinkUserId = patientLinkUserId;
	}

	public String getPatientLinkUserFullname() {
		return patientLinkUserFullname;
	}

	public void setPatientLinkUserFullname(String patientLinkUserFullname) {
		this.patientLinkUserFullname = patientLinkUserFullname;
	}
	
	public String getCsrName() {
		return csrName;
	}

	public void setCsrName(String csrName) {
		this.csrName = csrName;
	}

	public String getCsrPhone() {
		return csrPhone;
	}

	public void setCsrPhone(String csrPhone) {
		this.csrPhone = csrPhone;
	}

	public String getCsrEmail() {
		return csrEmail;
	}

	public void setCsrEmail(String csrEmail) {
		this.csrEmail = csrEmail;
	}

	public String getVendorReferralNo() {
		return vendorReferralNo;
	}

	public void setVendorReferralNo(String vendorReferralNo) {
		this.vendorReferralNo = vendorReferralNo;
	}

	public String getRentalOrderNo() {
		return rentalOrderNo;
	}

	public void setRentalOrderNo(String rentalOrderNo) {
		this.rentalOrderNo = rentalOrderNo;
	}

	public Integer getAddendum() {
		return addendum;
	}

	public void setAddendum(Integer addendum) {
		this.addendum = addendum;
	}

	public String getAddendumUserFullname() {
		return addendumUserFullname;
	}

	public void setAddendumUserFullname(String addendumUserFullname) {
		this.addendumUserFullname = addendumUserFullname;
	}

	public Integer getAddendumUserId() {
		return addendumUserId;
	}

	public void setAddendumUserId(Integer addendumUserId) {
		this.addendumUserId = addendumUserId;
	}

	public String getAddendumUsername() {
		return addendumUsername;
	}

	public void setAddendumUsername(String addendumUsername) {
		this.addendumUsername = addendumUsername;
	}

	public Integer getRecordModify() {
		return recordModify;
	}

	public void setRecordModify(Integer recordModify) {
		this.recordModify = recordModify;
	}

	public String getRecordModifyUserFullname() {
		return recordModifyUserFullname;
	}

	public void setRecordModifyUserFullname(String recordModifyUserFullname) {
		this.recordModifyUserFullname = recordModifyUserFullname;
	}

	public Integer getRecordModifyUserId() {
		return recordModifyUserId;
	}

	public void setRecordModifyUserId(Integer recordModifyUserId) {
		this.recordModifyUserId = recordModifyUserId;
	}

	public String getRecordModifyUsername() {
		return recordModifyUsername;
	}

	public void setRecordModifyUsername(String recordModifyUsername) {
		this.recordModifyUsername = recordModifyUsername;
	}

	public String getSecondaryStatus() {
		return secondaryStatus;
	}

	public void setSecondaryStatus(String secondaryStatus) {
		this.secondaryStatus = secondaryStatus;
	}

	public String getStatusChangeNotes() {
		return statusChangeNotes;
	}

	public void setStatusChangeNotes(String statusChangeNotes) {
		this.statusChangeNotes = statusChangeNotes;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public Integer getHealogicsPatientId() {
		return healogicsPatientId;
	}

	public void setHealogicsPatientId(Integer healogicsPatientId) {
		this.healogicsPatientId = healogicsPatientId;
	}

	public String getHealogicsPatientMRN() {
		return healogicsPatientMRN;
	}

	public void setHealogicsPatientMRN(String healogicsPatientMRN) {
		this.healogicsPatientMRN = healogicsPatientMRN;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientFullname() {
		return patientFullname;
	}

	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}

	public Date getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPhysicianFirstName() {
		return physicianFirstName;
	}

	public void setPhysicianFirstName(String physicianFirstName) {
		this.physicianFirstName = physicianFirstName;
	}

	public String getPhysicianLastName() {
		return physicianLastName;
	}

	public void setPhysicianLastName(String physicianLastName) {
		this.physicianLastName = physicianLastName;
	}

	public String getCaseManagerFirstName() {
		return caseManagerFirstName;
	}

	public void setCaseManagerFirstName(String caseManagerFirstName) {
		this.caseManagerFirstName = caseManagerFirstName;
	}

	public String getCaseManagerLastName() {
		return caseManagerLastName;
	}

	public void setCaseManagerLastName(String caseManagerLastName) {
		this.caseManagerLastName = caseManagerLastName;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public String getWaitingDocsSecStatus() {
		return waitingDocsSecStatus;
	}

	public void setWaitingDocsSecStatus(String waitingDocsSecStatus) {
		this.waitingDocsSecStatus = waitingDocsSecStatus;
	}

	public Date getPendPriorAuthDate() {
		return pendPriorAuthDate;
	}

	public void setPendPriorAuthDate(Date pendPriorAuthDate) {
		this.pendPriorAuthDate = pendPriorAuthDate;
	}

	public String getPendPriorAuthWaiting() {
		return pendPriorAuthWaiting;
	}

	public void setPendPriorAuthWaiting(String pendPriorAuthWaiting) {
		this.pendPriorAuthWaiting = pendPriorAuthWaiting;
	}

	public Date getUnderAppealDate() {
		return underAppealDate;
	}

	public void setUnderAppealDate(Date underAppealDate) {
		this.underAppealDate = underAppealDate;
	}

	public String getUnderAppealStatus() {
		return underAppealStatus;
	}

	public void setUnderAppealStatus(String underAppealStatus) {
		this.underAppealStatus = underAppealStatus;
	}

	public Date getFollowupDate() {
		return followupDate;
	}

	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}

	public String getMissingElements() {
		return missingElements;
	}

	public void setMissingElements(String missingElements) {
		this.missingElements = missingElements;
	}

	public String getSpecialInstructions() {
		return specialInstructions;
	}

	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getPrimaryInsuranceCompany() {
		return primaryInsuranceCompany;
	}

	public void setPrimaryInsuranceCompany(String primaryInsuranceCompany) {
		this.primaryInsuranceCompany = primaryInsuranceCompany;
	}

	public String getSencondaryInsurance() {
		return sencondaryInsurance;
	}

	public void setSencondaryInsurance(String sencondaryInsurance) {
		this.sencondaryInsurance = sencondaryInsurance;
	}

	public String getTertiaryInsurance() {
		return tertiaryInsurance;
	}

	public void setTertiaryInsurance(String tertiaryInsurance) {
		this.tertiaryInsurance = tertiaryInsurance;
	}

	public String getHcpc() {
		return hcpc;
	}

	public void setHcpc(String hcpc) {
		this.hcpc = hcpc;
	}

	public String getProductSKU() {
		return productSKU;
	}

	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getNoAppApproved() {
		return noAppApproved;
	}

	public void setNoAppApproved(String noAppApproved) {
		this.noAppApproved = noAppApproved;
	}

	public String getNoUnitsApproved() {
		return noUnitsApproved;
	}

	public void setNoUnitsApproved(String noUnitsApproved) {
		this.noUnitsApproved = noUnitsApproved;
	}

	public String getApprovalTimeframe() {
		return approvalTimeframe;
	}

	public void setApprovalTimeframe(String approvalTimeframe) {
		this.approvalTimeframe = approvalTimeframe;
	}

	public String getIcd10Codes() {
		return icd10Codes;
	}

	public void setIcd10Codes(String icd10Codes) {
		this.icd10Codes = icd10Codes;
	}

	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public String getWoundId() {
		return woundId;
	}

	public void setWoundId(String woundId) {
		this.woundId = woundId;
	}

	public Date getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	public String getCompletedStatus() {
		return completedStatus;
	}

	public void setCompletedStatus(String completedStatus) {
		this.completedStatus = completedStatus;
	}

	public String getCoverageSummary() {
		return coverageSummary;
	}

	public void setCoverageSummary(String coverageSummary) {
		this.coverageSummary = coverageSummary;
	}

	public String getSalesRepManager() {
		return salesRepManager;
	}

	public void setSalesRepManager(String salesRepManager) {
		this.salesRepManager = salesRepManager;
	}

	public String getReginalDirector() {
		return reginalDirector;
	}

	public void setReginalDirector(String reginalDirector) {
		this.reginalDirector = reginalDirector;
	}

	public String getSgp() {
		return sgp;
	}

	public void setSgp(String sgp) {
		this.sgp = sgp;
	}

	public Date getSgpDate() {
		return sgpDate;
	}

	public void setSgpDate(Date sgpDate) {
		this.sgpDate = sgpDate;
	}

	public String getSgpCPTCode() {
		return sgpCPTCode;
	}

	public void setSgpCPTCode(String sgpCPTCode) {
		this.sgpCPTCode = sgpCPTCode;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}

	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}

	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}

	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public Timestamp getStatusUpdatedTimestamp() {
		return statusUpdatedTimestamp;
	}

	public void setStatusUpdatedTimestamp(Timestamp statusUpdatedTimestamp) {
		this.statusUpdatedTimestamp = statusUpdatedTimestamp;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Timestamp getLastReceived() {
		return lastReceived;
	}

	public void setLastReceived(Timestamp lastReceived) {
		this.lastReceived = lastReceived;
	}

	public Timestamp getLastActioned() {
		return lastActioned;
	}

	public void setLastActioned(Timestamp lastActioned) {
		this.lastActioned = lastActioned;
	}

	public String getWoundqOrderNo() {
		return woundqOrderNo;
	}

	public void setWoundqOrderNo(String woundqOrderNo) {
		this.woundqOrderNo = woundqOrderNo;
	}

	public Timestamp getFirstReceived() {
		return firstReceived;
	}

	public void setFirstReceived(Timestamp firstReceived) {
		this.firstReceived = firstReceived;
	}

	public Timestamp getLastFileUpdated() {
		return lastFileUpdated;
	}

	public void setLastFileUpdated(Timestamp lastFileUpdated) {
		this.lastFileUpdated = lastFileUpdated;
	}

	public Integer getFilesSent() {
		return filesSent;
	}

	public void setFilesSent(Integer filesSent) {
		this.filesSent = filesSent;
	}

	public Integer getNoOfUpdates() {
		return noOfUpdates;
	}

	public void setNoOfUpdates(Integer noOfUpdates) {
		this.noOfUpdates = noOfUpdates;
	}

	public Timestamp getLastTeamUpdatedTimestamp() {
		return lastTeamUpdatedTimestamp;
	}

	public void setLastTeamUpdatedTimestamp(
			Timestamp lastTeamUpdatedTimestamp) {
		this.lastTeamUpdatedTimestamp = lastTeamUpdatedTimestamp;
	}

	public String getLastTeamUpdatedUserFullname() {
		return lastTeamUpdatedUserFullname;
	}

	public void setLastTeamUpdatedUserFullname(
			String lastTeamUpdatedUserFullname) {
		this.lastTeamUpdatedUserFullname = lastTeamUpdatedUserFullname;
	}

	public String getStatusUpdatedUserFullName() {
		return statusUpdatedUserFullName;
	}

	public void setStatusUpdatedUserFullName(String statusUpdatedUserFullName) {
		this.statusUpdatedUserFullName = statusUpdatedUserFullName;
	}

	public String getStatusUpdatedUserId() {
		return statusUpdatedUserId;
	}

	public void setStatusUpdatedUserId(String statusUpdatedUserId) {
		this.statusUpdatedUserId = statusUpdatedUserId;
	}

	public String getStatusUpdatedUserName() {
		return statusUpdatedUserName;
	}

	public void setStatusUpdatedUserName(String statusUpdatedUserName) {
		this.statusUpdatedUserName = statusUpdatedUserName;
	}

	@Override
	public String toString() {
		return "MasterChartDetails [orderId=" + orderId + ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", facilityName=" + facilityName + ", healogicsPatientId=" + healogicsPatientId
				+ ", healogicsPatientMRN=" + healogicsPatientMRN + ", vendorId=" + vendorId + ", vendorName="
				+ vendorName + ", orderSource=" + orderSource + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientFullname=" + patientFullname + ", patientDOB="
				+ patientDOB + ", physicianFirstName=" + physicianFirstName + ", physicianLastName=" + physicianLastName
				+ ", caseManagerFirstName=" + caseManagerFirstName + ", caseManagerLastName=" + caseManagerLastName
				+ ", receivedDate=" + receivedDate + ", vendorStatus=" + vendorStatus + ", waitingDocsSecStatus="
				+ waitingDocsSecStatus + ", pendPriorAuthDate=" + pendPriorAuthDate + ", pendPriorAuthWaiting="
				+ pendPriorAuthWaiting + ", underAppealDate=" + underAppealDate + ", underAppealStatus="
				+ underAppealStatus + ", followupDate=" + followupDate + ", missingElements=" + missingElements
				+ ", specialInstructions=" + specialInstructions + ", primaryInsurance=" + primaryInsurance
				+ ", primaryInsuranceCompany=" + primaryInsuranceCompany + ", sencondaryInsurance="
				+ sencondaryInsurance + ", tertiaryInsurance=" + tertiaryInsurance + ", hcpc=" + hcpc + ", productSKU="
				+ productSKU + ", productName=" + productName + ", noAppApproved=" + noAppApproved
				+ ", noUnitsApproved=" + noUnitsApproved + ", approvalTimeframe=" + approvalTimeframe + ", icd10Codes="
				+ icd10Codes + ", placeOfService=" + placeOfService + ", woundId=" + woundId + ", completedDate="
				+ completedDate + ", completedStatus=" + completedStatus + ", coverageSummary=" + coverageSummary
				+ ", salesRepManager=" + salesRepManager + ", reginalDirector=" + reginalDirector + ", sgp=" + sgp
				+ ", sgpDate=" + sgpDate + ", sgpCPTCode=" + sgpCPTCode + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUserId=" + lastUpdatedUserId + ", retrieveStatus="
				+ retrieveStatus + ", statusUpdatedTimestamp=" + statusUpdatedTimestamp + ", providerName="
				+ providerName + ", lastReceived=" + lastReceived + ", lastActioned=" + lastActioned
				+ ", woundqOrderNo=" + woundqOrderNo + ", firstReceived=" + firstReceived + ", lastFileUpdated="
				+ lastFileUpdated + ", filesSent=" + filesSent + ", noOfUpdates=" + noOfUpdates
				+ ", lastTeamUpdatedTimestamp=" + lastTeamUpdatedTimestamp + ", lastTeamUpdatedUserFullname="
				+ lastTeamUpdatedUserFullname + ", statusUpdatedUserFullName=" + statusUpdatedUserFullName
				+ ", statusUpdatedUserId=" + statusUpdatedUserId + ", statusUpdatedUserName=" + statusUpdatedUserName
				+ ", statusChangeNotes=" + statusChangeNotes + ", secondaryStatus=" + secondaryStatus + ", addendum="
				+ addendum + ", addendumUserFullname=" + addendumUserFullname + ", addendumUserId=" + addendumUserId
				+ ", addendumUsername=" + addendumUsername + ", recordModify=" + recordModify
				+ ", recordModifyUserFullname=" + recordModifyUserFullname + ", recordModifyUserId="
				+ recordModifyUserId + ", recordModifyUsername=" + recordModifyUsername + ", vendorReferralNo="
				+ vendorReferralNo + ", rentalOrderNo=" + rentalOrderNo + ", csrName=" + csrName + ", csrPhone="
				+ csrPhone + ", csrEmail=" + csrEmail + ", patientLinked=" + patientLinked + ", patientLinkUsername="
				+ patientLinkUsername + ", patientLinkUserId=" + patientLinkUserId + ", patientLinkUserFullname="
				+ patientLinkUserFullname + ", patientLinkTimestamp=" + patientLinkTimestamp + "]";
	}

}
