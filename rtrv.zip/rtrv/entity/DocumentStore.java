package com.healogics.rtrv.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document_store")
public class DocumentStore {

	@Id
	@Column(name = "request_id")
	private String requestId;

	@Column(name = "document_token")
	private String documentToken;

	@Column(name = "doc_request_id")
	private String docRequestId;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "document_available")
	private int documentAvailable;

	@Column(name = "visit_id")
	private Long visitId;

	@Column(name = "visit_date")
	private Date visitDate;

	@Column(name = "facility_id")
	private int facilityId;

	@Column(name = "bluebook_id")
	private String bluebookId;

	@Column(name = "facility_type")
	private String facilityType;

	@Column(name = "iheal_config")
	private String ihealConfig;

	@Column(name = "vendor_id")
	private int vendorId;

	@Column(name = "vendor_name")
	private String vendorName;

	@Column(name = "patient_id")
	private int patientId;

	@Column(name = "patient_name")
	private String patientName;

	@Column(name = "iheal_doc_request_status")
	private String ihealDocRequestStatus;

	@Column(name = "iheal_doc_request_timestamp")
	private Timestamp ihealDocRequestTimestamp;

	@Column(name = "doc_download_status")
	private String docDownloadStatus;

	@Column(name = "doc_download_timestamp")
	private Timestamp docDownloadTimestamp;

	@Column(name = "doc_notification_status")
	private String docNotificationStatus;

	@Column(name = "doc_notification_timestamp")
	private Timestamp docNotificationTimestamp;

	@Column(name = "vendor_doc_get_status")
	private String vendorDocGetStatus;

	@Column(name = "vendor_doc_get_timestamp")
	private Timestamp vendorDocGetTimestamp;

	@Column(name = "doc_sent_status")
	private String docSentStatus;

	@Column(name = "doc_sent_timestamp")
	private Timestamp docSentTimestamp;

	@Column(name = "username")
	private String userName;

	@Column(name = "user_fullname")
	private String userFullName;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "store_id")
	private int storeId;

	@Column(name = "document_status")
	private String documentStatus;

	@Column(name = "document_content")
	private String documentContent;

	@Column(name = "service_line")
	private String serviceLine;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "document_source")
	private String documentSource;

	@Column(name = "iheal_document_id")
	private Long ihealDocumentId;

	@Column(name = "iheal_version_id")
	private Long ihealVersionId;

	@Column(name = "created_timestamp")
	private Timestamp createdTimestamp;

	@Column(name = "vendor_request_id")
	private String vendorRequestId;

	@Column(name = "vendor_status")
	private String vendorStatus;

	@Column(name = "patient_first_name")
	private String patientFirstName;

	@Column(name = "patient_last_name")
	private String patientLastName;

	@Column(name = "primary_insurance")
	private String primaryInsurance;

	@Column(name = "secondary_insurance")
	private String secondaryInsurance;

	@Column(name = "provider_first_name")
	private String providerFirstName;

	@Column(name = "provider_last_name")
	private String providerLastName;

	@Column(name = "clinician_first_name")
	private String clinicianFirstName;

	@Column(name = "clinician_last_name")
	private String clinicianLastName;

	@Column(name = "response_date")
	private Date responseDate;

	@Column(name = "vendor_referral_no")
	private String vendorReferralNo;

	@Column(name = "need_by_date")
	private Date needByDate;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getDocumentToken() {
		return documentToken;
	}

	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}

	public String getDocRequestId() {
		return docRequestId;
	}

	public void setDocRequestId(String docRequestId) {
		this.docRequestId = docRequestId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public int getDocumentAvailable() {
		return documentAvailable;
	}

	public void setDocumentAvailable(int documentAvailable) {
		this.documentAvailable = documentAvailable;
	}

	public Long getVisitId() {
		return visitId;
	}

	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public String getIhealConfig() {
		return ihealConfig;
	}

	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getIhealDocRequestStatus() {
		return ihealDocRequestStatus;
	}

	public void setIhealDocRequestStatus(String ihealDocRequestStatus) {
		this.ihealDocRequestStatus = ihealDocRequestStatus;
	}

	public Timestamp getIhealDocRequestTimestamp() {
		return ihealDocRequestTimestamp;
	}

	public void setIhealDocRequestTimestamp(Timestamp ihealDocRequestTimestamp) {
		this.ihealDocRequestTimestamp = ihealDocRequestTimestamp;
	}

	public String getDocDownloadStatus() {
		return docDownloadStatus;
	}

	public void setDocDownloadStatus(String docDownloadStatus) {
		this.docDownloadStatus = docDownloadStatus;
	}

	public Timestamp getDocDownloadTimestamp() {
		return docDownloadTimestamp;
	}

	public void setDocDownloadTimestamp(Timestamp docDownloadTimestamp) {
		this.docDownloadTimestamp = docDownloadTimestamp;
	}

	public String getDocNotificationStatus() {
		return docNotificationStatus;
	}

	public void setDocNotificationStatus(String docNotificationStatus) {
		this.docNotificationStatus = docNotificationStatus;
	}

	public Timestamp getDocNotificationTimestamp() {
		return docNotificationTimestamp;
	}

	public void setDocNotificationTimestamp(Timestamp docNotificationTimestamp) {
		this.docNotificationTimestamp = docNotificationTimestamp;
	}

	public String getVendorDocGetStatus() {
		return vendorDocGetStatus;
	}

	public void setVendorDocGetStatus(String vendorDocGetStatus) {
		this.vendorDocGetStatus = vendorDocGetStatus;
	}

	public Timestamp getVendorDocGetTimestamp() {
		return vendorDocGetTimestamp;
	}

	public void setVendorDocGetTimestamp(Timestamp vendorDocGetTimestamp) {
		this.vendorDocGetTimestamp = vendorDocGetTimestamp;
	}

	public String getDocSentStatus() {
		return docSentStatus;
	}

	public void setDocSentStatus(String docSentStatus) {
		this.docSentStatus = docSentStatus;
	}

	public Timestamp getDocSentTimestamp() {
		return docSentTimestamp;
	}

	public void setDocSentTimestamp(Timestamp docSentTimestamp) {
		this.docSentTimestamp = docSentTimestamp;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentSource() {
		return documentSource;
	}

	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}

	public Long getIhealDocumentId() {
		return ihealDocumentId;
	}

	public void setIhealDocumentId(Long ihealDocumentId) {
		this.ihealDocumentId = ihealDocumentId;
	}

	public Long getIhealVersionId() {
		return ihealVersionId;
	}

	public void setIhealVersionId(Long ihealVersionId) {
		this.ihealVersionId = ihealVersionId;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getVendorRequestId() {
		return vendorRequestId;
	}

	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPrimaryInsurance() {
		return primaryInsurance;
	}

	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}

	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}

	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public String getClinicianFirstName() {
		return clinicianFirstName;
	}

	public void setClinicianFirstName(String clinicianFirstName) {
		this.clinicianFirstName = clinicianFirstName;
	}

	public String getClinicianLastName() {
		return clinicianLastName;
	}

	public void setClinicianLastName(String clinicianLastName) {
		this.clinicianLastName = clinicianLastName;
	}

	public Date getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(Date responseDate) {
		this.responseDate = responseDate;
	}

	public String getVendorReferralNo() {
		return vendorReferralNo;
	}

	public void setVendorReferralNo(String vendorReferralNo) {
		this.vendorReferralNo = vendorReferralNo;
	}

	public Date getNeedByDate() {
		return needByDate;
	}

	public void setNeedByDate(Date needByDate) {
		this.needByDate = needByDate;
	}

	@Override
	public String toString() {
		return "DocumentStore [requestId=" + requestId + ", documentToken=" + documentToken + ", docRequestId="
				+ docRequestId + ", documentType=" + documentType + ", documentAvailable=" + documentAvailable
				+ ", visitId=" + visitId + ", visitDate=" + visitDate + ", facilityId=" + facilityId + ", bluebookId="
				+ bluebookId + ", facilityType=" + facilityType + ", ihealConfig=" + ihealConfig + ", vendorId="
				+ vendorId + ", vendorName=" + vendorName + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", ihealDocRequestStatus=" + ihealDocRequestStatus + ", ihealDocRequestTimestamp="
				+ ihealDocRequestTimestamp + ", docDownloadStatus=" + docDownloadStatus + ", docDownloadTimestamp="
				+ docDownloadTimestamp + ", docNotificationStatus=" + docNotificationStatus
				+ ", docNotificationTimestamp=" + docNotificationTimestamp + ", vendorDocGetStatus="
				+ vendorDocGetStatus + ", vendorDocGetTimestamp=" + vendorDocGetTimestamp + ", docSentStatus="
				+ docSentStatus + ", docSentTimestamp=" + docSentTimestamp + ", userName=" + userName
				+ ", userFullName=" + userFullName + ", userId=" + userId + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + ", storeId=" + storeId + ", documentStatus=" + documentStatus
				+ ", documentContent=" + documentContent + ", serviceLine=" + serviceLine + ", documentName="
				+ documentName + ", documentSource=" + documentSource + ", ihealDocumentId=" + ihealDocumentId
				+ ", ihealVersionId=" + ihealVersionId + ", createdTimestamp=" + createdTimestamp + ", vendorRequestId="
				+ vendorRequestId + ", vendorStatus=" + vendorStatus + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", primaryInsurance=" + primaryInsurance
				+ ", secondaryInsurance=" + secondaryInsurance + ", providerFirstName=" + providerFirstName
				+ ", providerLastName=" + providerLastName + ", clinicianFirstName=" + clinicianFirstName
				+ ", clinicianLastName=" + clinicianLastName + ", responseDate=" + responseDate + ", vendorReferralNo="
				+ vendorReferralNo + ", needByDate=" + needByDate + "]";
	}

}
