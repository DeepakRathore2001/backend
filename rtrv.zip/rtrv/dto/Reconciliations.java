package com.healogics.rtrv.dto;

public class Reconciliations {

	private int reconciliationId;
	private int userId;
	private String reconciliationDate;
	private Boolean unableToPerform;
	private String unableToPerformReason;

	public int getReconciliationId() {
		return reconciliationId;
	}

	public void setReconciliationId(int reconciliationId) {
		this.reconciliationId = reconciliationId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getReconciliationDate() {
		return reconciliationDate;
	}

	public void setReconciliationDate(String reconciliationDate) {
		this.reconciliationDate = reconciliationDate;
	}

	public Boolean getUnableToPerform() {
		return unableToPerform;
	}

	public void setUnableToPerform(Boolean unableToPerform) {
		this.unableToPerform = unableToPerform;
	}

	public String getUnableToPerformReason() {
		return unableToPerformReason;
	}

	public void setUnableToPerformReason(String unableToPerformReason) {
		this.unableToPerformReason = unableToPerformReason;
	}

	@Override
	public String toString() {
		return "Reconciliations [reconciliationId=" + reconciliationId + ", userId=" + userId + ", reconciliationDate="
				+ reconciliationDate + ", unableToPerform=" + unableToPerform + ", unableToPerformReason="
				+ unableToPerformReason + "]";
	}

}
