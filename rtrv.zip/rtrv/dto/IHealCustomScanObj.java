package com.healogics.rtrv.dto;

import java.io.Serializable;

public class IHealCustomScanObj implements Serializable {

	private static final long serialVersionUID = 1L;
	private String scanId;
	private String externalScanId;
	private String title;
	private String scanExtension;
	private IHealCustomScanGroup group;
	private IHealDocumentObj document;
	private String effectiveDate;
	
	public String getScanId() {
		return scanId;
	}
	public void setScanId(String scanId) {
		this.scanId = scanId;
	}
	public String getExternalScanId() {
		return externalScanId;
	}
	public void setExternalScanId(String externalScanId) {
		this.externalScanId = externalScanId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getScanExtension() {
		return scanExtension;
	}
	public void setScanExtension(String scanExtension) {
		this.scanExtension = scanExtension;
	}
	public IHealCustomScanGroup getGroup() {
		return group;
	}
	public void setGroup(IHealCustomScanGroup group) {
		this.group = group;
	}
	public IHealDocumentObj getDocument() {
		return document;
	}
	public void setDocument(IHealDocumentObj document) {
		this.document = document;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	@Override
	public String toString() {
		return "IHealCustomScanObj [scanId=" + scanId + ", externalScanId="
				+ externalScanId + ", title=" + title + ", scanExtension="
				+ scanExtension + ", group=" + group + ", document=" + document
				+ ", effectiveDate=" + effectiveDate + "]";
	}

}
