package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.List;

public class MasterSaveChartReq {

	private String orderId;

	private Timestamp lastUpdatedTimestamp;
	private String lastUpdatedUserName;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserId;
	private String assigneeFullName;
	private String assigneeUserName;
	private String assigneeUserId;
	private String retrieveStatus;
	private Integer assigneeChanged;
	private String serviceLine;
	private Integer isCompleted;
	private List<MasterSaveAttachmentObj> documents;

	private String requestId;
	private Integer vendorId;
	private String vendorName;
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public Integer getIsCompleted() {
		return isCompleted;
	}
	public void setIsCompleted(Integer isCompleted) {
		this.isCompleted = isCompleted;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public List<MasterSaveAttachmentObj> getDocuments() {
		return documents;
	}
	public void setDocuments(List<MasterSaveAttachmentObj> documents) {
		this.documents = documents;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getAssigneeUserId() {
		return assigneeUserId;
	}
	public void setAssigneeUserId(String assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public Integer getAssigneeChanged() {
		return assigneeChanged;
	}
	public void setAssigneeChanged(Integer assigneeChanged) {
		this.assigneeChanged = assigneeChanged;
	}

	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}
	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}
	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}
	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}
	public String getAssigneeFullName() {
		return assigneeFullName;
	}
	public void setAssigneeFullName(String assigneeFullName) {
		this.assigneeFullName = assigneeFullName;
	}
	public String getAssigneeUserName() {
		return assigneeUserName;
	}
	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}
	@Override
	public String toString() {
		return "MasterSaveChartReq [orderId=" + orderId + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", lastUpdatedUserName=" + lastUpdatedUserName + ", lastUpdatedUserFullName="
				+ lastUpdatedUserFullName + ", lastUpdatedUserId=" + lastUpdatedUserId + ", assigneeFullName="
				+ assigneeFullName + ", assigneeUserName=" + assigneeUserName + ", assigneeUserId=" + assigneeUserId
				+ ", retrieveStatus=" + retrieveStatus + ", assigneeChanged=" + assigneeChanged + ", serviceLine="
				+ serviceLine + ", isCompleted=" + isCompleted + ", documents=" + documents + ", requestId=" + requestId
				+ ", vendorId=" + vendorId + "]";

	}

}
