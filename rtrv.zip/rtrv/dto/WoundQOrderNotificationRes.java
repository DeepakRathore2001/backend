package com.healogics.rtrv.dto;

import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;

public class WoundQOrderNotificationRes extends RTRVAPIResponse {	
}
