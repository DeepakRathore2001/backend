package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

public class IhealUserdetails implements Serializable{
	private static final long serialVersionUID = 1L;
	private String masterToken;
	private String errorCode;
	private String errorMessage;
	private IhealUserRes user;
	private String lastLoginFacilityId;
	private UUID loginUUID;
	private List<NHWarningDetails> warnings;
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public IhealUserRes getUser() {
		return user;
	}
	public void setUser(IhealUserRes user) {
		this.user = user;
	}
	public String getLastLoginFacilityId() {
		return lastLoginFacilityId;
	}
	public void setLastLoginFacilityId(String lastLoginFacilityId) {
		this.lastLoginFacilityId = lastLoginFacilityId;
	}
	public UUID getLoginUUID() {
		return loginUUID;
	}
	public void setLoginUUID(UUID loginUUID) {
		this.loginUUID = loginUUID;
	}
	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IhealUserdetails [masterToken=" + masterToken
				+ ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + ", user=" + user
				+ ", lastLoginFacilityId=" + lastLoginFacilityId
				+ ", loginUUID=" + loginUUID + ", warnings=" + warnings + "]";
	}	
	
}
