package com.healogics.rtrv.dto;

public class AttachmentReqObj {

	private String documentEntityId;
	private String documentType;
	private String documentRequestId;
	public String getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(String documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentRequestId() {
		return documentRequestId;
	}
	public void setDocumentRequestId(String documentRequestId) {
		this.documentRequestId = documentRequestId;
	}
	@Override
	public String toString() {
		return "AttachmentReqObj [documentEntityId=" + documentEntityId
				+ ", documentType=" + documentType + ", documentRequestId="
				+ documentRequestId + "]";
	}

}
