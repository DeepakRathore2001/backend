package com.healogics.rtrv.dto;

public class DocumentsListReq {

	private String masterToken;
	private String privateKey;
	private String userId;
	private String facilityId;
	private String patientId;
	private String startDate;
	private String endDate;
	private String bhcOrderReceivedDate;
	private String woundDocumentEntityId;
	private String medRecId;
	private String bhcInvoiceOrderId;
	private boolean activeOnly;

	public String getBhcOrderReceivedDate() {
		return bhcOrderReceivedDate;
	}
	public void setBhcOrderReceivedDate(String bhcOrderReceivedDate) {
		this.bhcOrderReceivedDate = bhcOrderReceivedDate;
	}
	public boolean isActiveOnly() {
		return activeOnly;
	}
	public void setActiveOnly(boolean activeOnly) {
		this.activeOnly = activeOnly;
	}
	public String getMedRecId() {
		return medRecId;
	}
	public void setMedRecId(String medRecId) {
		this.medRecId = medRecId;
	}
	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getWoundDocumentEntityId() {
		return woundDocumentEntityId;
	}
	public void setWoundDocumentEntityId(String woundDocumentEntityId) {
		this.woundDocumentEntityId = woundDocumentEntityId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	@Override
	public String toString() {
		return "DocumentsListReq [masterToken=" + masterToken + ", privateKey="
				+ privateKey + ", userId=" + userId + ", facilityId="
				+ facilityId + ", patientId=" + patientId + ", startDate="
				+ startDate + ", endDate=" + endDate + ", bhcOrderReceivedDate="
				+ bhcOrderReceivedDate + ", woundDocumentEntityId="
				+ woundDocumentEntityId + ", medRecId=" + medRecId
				+ ", bhcInvoiceOrderId=" + bhcInvoiceOrderId + ", activeOnly="
				+ activeOnly + "]";
	}

}
