package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;

public class IHealFileGetRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private String imageStream;
	private String imageMimeType;
	private String errorCode;
	private String errorMessage;
	private List<IHealErrorDetails> errors;
	private List<IHealErrorDetails> warnings;
	public String getImageStream() {
		return imageStream;
	}
	public void setImageStream(String imageStream) {
		this.imageStream = imageStream;
	}
	public String getImageMimeType() {
		return imageMimeType;
	}
	public void setImageMimeType(String imageMimeType) {
		this.imageMimeType = imageMimeType;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<IHealErrorDetails> getErrors() {
		return errors;
	}
	public void setErrors(List<IHealErrorDetails> errors) {
		this.errors = errors;
	}
	public List<IHealErrorDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<IHealErrorDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealFileGetRes [imageStream=" + imageStream
				+ ", imageMimeType=" + imageMimeType + ", errorCode="
				+ errorCode + ", errorMessage=" + errorMessage + ", errors="
				+ errors + ", warnings=" + warnings + "]";
	}

}
