package com.healogics.rtrv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MasterIHealAttachment {

	private String docEntityId;
	private String docType;
	private String docName;
	@JsonProperty
	private boolean isDeleted;
	@JsonProperty
	private boolean isNewFile;
	private int isSubmitted;

	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public boolean isNewFile() {
		return isNewFile;
	}
	public void setNewFile(boolean isNewFile) {
		this.isNewFile = isNewFile;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public int getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}

	@Override
	public String toString() {
		return "MasterIHealAttachment [docEntityId=" + docEntityId
				+ ", docType=" + docType + ", docName=" + docName
				+ ", isDeleted=" + isDeleted + ", isNewFile=" + isNewFile
				+ ", isSubmitted=" + isSubmitted + "]";
	}

}
