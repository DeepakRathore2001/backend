package com.healogics.rtrv.dto;

public class AttachmentDetails {

	private String docName;
	private int visitId;
	private String groupName;
	private String docEntityId;
	private String testDesc;
	private String addedDate;
	private String visitDate;
	private boolean isManually;
	private boolean isSigned;
	private int isSubmitted;
	private int versionId;
	private String documentStatus;
	private String docType;

	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocumentStatus() {
		return documentStatus;
	}
	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}
	public int getVersionId() {
		return versionId;
	}
	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}

	public int getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
	public boolean isSigned() {
		return isSigned;
	}
	public void setSigned(boolean isSigned) {
		this.isSigned = isSigned;
	}
	public String getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public boolean isManually() {
		return isManually;
	}
	public void setManually(boolean isManually) {
		this.isManually = isManually;
	}
	public String getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(String addedDate) {
		this.addedDate = addedDate;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	public String getTestDesc() {
		return testDesc;
	}
	public void setTestDesc(String testDesc) {
		this.testDesc = testDesc;
	}
	@Override
	public String toString() {
		return "AttachmentDetails [docName=" + docName + ", visitId=" + visitId
				+ ", groupName=" + groupName + ", docEntityId=" + docEntityId
				+ ", testDesc=" + testDesc + ", addedDate=" + addedDate
				+ ", visitDate=" + visitDate + ", isManually=" + isManually
				+ ", isSigned=" + isSigned + ", isSubmitted=" + isSubmitted
				+ ", versionId=" + versionId + ", documentStatus="
				+ documentStatus + ", docType=" + docType + "]";
	}

}
