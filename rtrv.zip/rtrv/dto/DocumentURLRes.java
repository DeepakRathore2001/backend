package com.healogics.rtrv.dto;

public class DocumentURLRes {
	private String documentURL;
	private String responseCode;
	private String responseMessage;

	public String getDocumentURL() {
		return documentURL;
	}

	public void setDocumentURL(String documentURL) {
		this.documentURL = documentURL;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	@Override
	public String toString() {
		return "DocumentURLRes [documentURL=" + documentURL + ", responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + "]";
	}
}
