package com.healogics.rtrv.dto;

import java.util.List;

public class UserRolesRes {

	private List<UserRolesDetails> userList;
	private String responseCode;
	private String responseMessage;

	public List<UserRolesDetails> getUserList() {
		return userList;
	}
	public void setUserList(List<UserRolesDetails> userList) {
		this.userList = userList;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "UserRolesRes [userList=" + userList + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
