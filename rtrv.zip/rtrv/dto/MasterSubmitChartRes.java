package com.healogics.rtrv.dto;

public class MasterSubmitChartRes extends APIResponse {

}
