package com.healogics.rtrv.dto;

public class TestResultsDocument {
	private int documentEntityId;
	private int versionId;
	private String documentType;
	private int facilityId;
	private int patientId;
	private int visitId;
	private String visitDateTime;
	private String addedDateTime;
	private int providerId;
	private int provider2Id;
	private int clinicianId;
	private int clinician2Id;
	public int getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(int documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	public int getVersionId() {
		return versionId;
	}
	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getVisitDateTime() {
		return visitDateTime;
	}
	public void setVisitDateTime(String visitDateTime) {
		this.visitDateTime = visitDateTime;
	}
	public String getAddedDateTime() {
		return addedDateTime;
	}
	public void setAddedDateTime(String addedDateTime) {
		this.addedDateTime = addedDateTime;
	}
	public int getProviderId() {
		return providerId;
	}
	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}
	public int getProvider2Id() {
		return provider2Id;
	}
	public void setProvider2Id(int provider2Id) {
		this.provider2Id = provider2Id;
	}
	public int getClinicianId() {
		return clinicianId;
	}
	public void setClinicianId(int clinicianId) {
		this.clinicianId = clinicianId;
	}
	public int getClinician2Id() {
		return clinician2Id;
	}
	public void setClinician2Id(int clinician2Id) {
		this.clinician2Id = clinician2Id;
	}
	@Override
	public String toString() {
		return "TestResultsDocument [documentEntityId=" + documentEntityId
				+ ", versionId=" + versionId + ", documentType=" + documentType
				+ ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", visitId=" + visitId + ", visitDateTime=" + visitDateTime
				+ ", addedDateTime=" + addedDateTime + ", providerId="
				+ providerId + ", provider2Id=" + provider2Id + ", clinicianId="
				+ clinicianId + ", clinician2Id=" + clinician2Id + "]";
	}

}
