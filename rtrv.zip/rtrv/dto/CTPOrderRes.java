package com.healogics.rtrv.dto;

public class CTPOrderRes {
	private String responseCode;
	private String responseMessage;
	private String requestId;

	private OrderInfoObj orderInfoObj;

	public OrderInfoObj getOrderInfoObj() {
		return orderInfoObj;
	}
	public void setOrderInfoObj(OrderInfoObj orderInfoObj) {
		this.orderInfoObj = orderInfoObj;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	@Override
	public String toString() {
		return "CTPOrderRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", requestId="
				+ requestId + ", orderInfoObj=" + orderInfoObj + "]";
	}
}
