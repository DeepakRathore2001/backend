package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;

public class PatientSearchRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<PatientSearchObj> patients;
	private String resultCount;
	private String pageIndex;
	private String maxPageSize;
	private String responseMessage;
	private String responseCode;
	public List<PatientSearchObj> getPatients() {
		return patients;
	}
	public void setPatients(List<PatientSearchObj> patients) {
		this.patients = patients;
	}
	public String getResultCount() {
		return resultCount;
	}
	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}
	public String getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(String pageIndex) {
		this.pageIndex = pageIndex;
	}
	public String getMaxPageSize() {
		return maxPageSize;
	}
	public void setMaxPageSize(String maxPageSize) {
		this.maxPageSize = maxPageSize;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	@Override
	public String toString() {
		return "PatientSearchRes [patients=" + patients + ", resultCount="
				+ resultCount + ", pageIndex=" + pageIndex + ", maxPageSize="
				+ maxPageSize + ", responseMessage=" + responseMessage
				+ ", responseCode=" + responseCode + "]";
	}

}
