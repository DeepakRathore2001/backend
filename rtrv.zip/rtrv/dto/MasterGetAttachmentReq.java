package com.healogics.rtrv.dto;

import java.util.List;

public class MasterGetAttachmentReq {

	private String masterToken;
	private String privateKey;
	private String userId;
	private String facilityId;
	private String patientId;
	private List<AttachmentReqObj> documentObjs;

	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public List<AttachmentReqObj> getDocumentObjs() {
		return documentObjs;
	}
	public void setDocumentObjs(List<AttachmentReqObj> documentObjs) {
		this.documentObjs = documentObjs;
	}
	@Override
	public String toString() {
		return "MasterGetAttachmentReq [masterToken=" + masterToken
				+ ", privateKey=" + privateKey + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", documentObjs=" + documentObjs + "]";
	}

}
