package com.healogics.rtrv.dto;

import java.util.List;

public class UserNotificationReq {

	private String userId;
	private String lastUpdatedUserFullname;
	private List<String> notificationId;
	private String lastUpdatedUsername;

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public List<String> getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(List<String> notificationId) {
		this.notificationId = notificationId;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}

	@Override
	public String toString() {
		return "UserNotificationReq [userId=" + userId
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname
				+ ", notificationId=" + notificationId
				+ ", lastUpdatedUsername=" + lastUpdatedUsername + "]";
	}

}
