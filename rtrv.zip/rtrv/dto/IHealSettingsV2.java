package com.healogics.rtrv.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IHealSettingsV2 implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("RetrieveInterfaces")
	private boolean retrieveInterfaces;

	public boolean getRetrieveInterfaces() {
		return retrieveInterfaces;
	}

	@JsonSetter("RetrieveInterfaces")
	public void setRetrieveInterfaces(boolean retrieveInterfaces) {
		this.retrieveInterfaces = retrieveInterfaces;
	}

	@Override
	public String toString() {
		return "IHealSettingsV2 [RetrieveInterfaces=" + retrieveInterfaces
				+ "]";
	}

}
