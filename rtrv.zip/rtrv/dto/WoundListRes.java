package com.healogics.rtrv.dto;

import java.util.List;

public class WoundListRes {

	private List<IHealWound> activeWounds;
	private List<IHealWound> inactiveWounds;
	private String responseCode;
	private String responseMessage;

	public List<IHealWound> getActiveWounds() {
		return activeWounds;
	}
	public void setActiveWounds(List<IHealWound> activeWounds) {
		this.activeWounds = activeWounds;
	}
	public List<IHealWound> getInactiveWounds() {
		return inactiveWounds;
	}
	public void setInactiveWounds(List<IHealWound> inactiveWounds) {
		this.inactiveWounds = inactiveWounds;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "WoundListRes [activeWounds=" + activeWounds
				+ ", inactiveWounds=" + inactiveWounds + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
