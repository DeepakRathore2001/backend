package com.healogics.rtrv.dto;

import java.util.List;

public class NPWTReportReq {

	private List<Long> roNo;
	private String bbc;
	private List<Long> hlWqOrderNo;
	private String patientName;
	private String firstReceivedDate;
	private String firstReceivedStartDate;
	private String firstReceivedEndDate;
	private String documentsFirstSent;
	private String docsFirstSentStartDate;
	private String docsFirstSentEndDate;
	private String documentsLastSent;
	private String docsLastSentStartDate;
	private String docsLastSentEndDate;
	private String vendorStatus;
	private String retrieveStatus;
	private String noOfFilesSent;
	private String filterOptions;
	private String filters;
	private int index;
	private int order;
	private String sortBy;

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public List<Long> getRoNo() {
		return roNo;
	}

	public void setRoNo(List<Long> roNo) {
		this.roNo = roNo;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public List<Long> getHlWqOrderNo() {
		return hlWqOrderNo;
	}

	public void setHlWqOrderNo(List<Long> hlWqOrderNo) {
		this.hlWqOrderNo = hlWqOrderNo;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getFirstReceivedDate() {
		return firstReceivedDate;
	}

	public void setFirstReceivedDate(String firstReceivedDate) {
		this.firstReceivedDate = firstReceivedDate;
	}

	public String getFirstReceivedStartDate() {
		return firstReceivedStartDate;
	}

	public void setFirstReceivedStartDate(String firstReceivedStartDate) {
		this.firstReceivedStartDate = firstReceivedStartDate;
	}

	public String getFirstReceivedEndDate() {
		return firstReceivedEndDate;
	}

	public void setFirstReceivedEndDate(String firstReceivedEndDate) {
		this.firstReceivedEndDate = firstReceivedEndDate;
	}

	public String getDocumentsFirstSent() {
		return documentsFirstSent;
	}

	public void setDocumentsFirstSent(String documentsFirstSent) {
		this.documentsFirstSent = documentsFirstSent;
	}

	public String getDocsFirstSentStartDate() {
		return docsFirstSentStartDate;
	}

	public void setDocsFirstSentStartDate(String docsFirstSentStartDate) {
		this.docsFirstSentStartDate = docsFirstSentStartDate;
	}

	public String getDocsFirstSentEndDate() {
		return docsFirstSentEndDate;
	}

	public void setDocsFirstSentEndDate(String docsFirstSentEndDate) {
		this.docsFirstSentEndDate = docsFirstSentEndDate;
	}

	public String getDocsLastSentStartDate() {
		return docsLastSentStartDate;
	}

	public void setDocsLastSentStartDate(String docsLastSentStartDate) {
		this.docsLastSentStartDate = docsLastSentStartDate;
	}

	public String getDocsLastSentEndDate() {
		return docsLastSentEndDate;
	}

	public void setDocsLastSentEndDate(String docsLastSentEndDate) {
		this.docsLastSentEndDate = docsLastSentEndDate;
	}

	public String getDocumentsLastSent() {
		return documentsLastSent;
	}

	public void setDocumentsLastSent(String documentsLastSent) {
		this.documentsLastSent = documentsLastSent;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public String getNoOfFilesSent() {
		return noOfFilesSent;
	}

	public void setNoOfFilesSent(String noOfFilesSent) {
		this.noOfFilesSent = noOfFilesSent;
	}

	@Override
	public String toString() {
		return "NPWTReportReq [roNo=" + roNo + ", bbc=" + bbc + ", hlWqOrderNo=" + hlWqOrderNo + ", patientName="
				+ patientName + ", firstReceivedDate=" + firstReceivedDate + ", firstReceivedStartDate="
				+ firstReceivedStartDate + ", firstReceivedEndDate=" + firstReceivedEndDate + ", documentsFirstSent="
				+ documentsFirstSent + ", docsFirstSentStartDate=" + docsFirstSentStartDate + ", docsFirstSentEndDate="
				+ docsFirstSentEndDate + ", documentsLastSent=" + documentsLastSent + ", docsLastSentStartDate="
				+ docsLastSentStartDate + ", docsLastSentEndDate=" + docsLastSentEndDate + ", vendorStatus="
				+ vendorStatus + ", retrieveStatus=" + retrieveStatus + ", noOfFilesSent=" + noOfFilesSent
				+ ", filterOptions=" + filterOptions + ", filters=" + filters + ", index=" + index + ", order=" + order
				+ ", sortBy=" + sortBy + "]";
	}

}
