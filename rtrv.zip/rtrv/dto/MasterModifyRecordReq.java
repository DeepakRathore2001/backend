package com.healogics.rtrv.dto;

public class MasterModifyRecordReq {

	private String orderId;
	private String lastUpdatedUsername;
	private Integer lastUpdatedUserId;
	private String lastUpdatedUserFullname;
	private int addendum;
	private int recordModify;
	private String requestId;
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	private String serviceLine;

	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public Integer getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(Integer lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public int getAddendum() {
		return addendum;
	}
	public void setAddendum(int addendum) {
		this.addendum = addendum;
	}
	public int getRecordModify() {
		return recordModify;
	}
	public void setRecordModify(int recordModify) {
		this.recordModify = recordModify;
	}
	@Override
	public String toString() {
		return "MasterModifyRecordReq [orderId=" + orderId
				+ ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", lastUpdatedUserId=" + lastUpdatedUserId
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname
				+ ", addendum=" + addendum + ", recordModify=" + recordModify
				+ ", requestId=" + requestId + ", serviceLine=" + serviceLine
				+ "]";
	}

}
