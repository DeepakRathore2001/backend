package com.healogics.rtrv.dto;

import java.util.List;

public class UpdateAssignedToReq {

	private String lastUpdatedUserFullname;
	private String lastUpdatedUsername;
	private String lastUpdatedUserId;
	private List<UpdateAssignedTo> assignees;

	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public List<UpdateAssignedTo> getAssignees() {
		return assignees;
	}
	public void setAssignees(List<UpdateAssignedTo> assignees) {
		this.assignees = assignees;
	}
	@Override
	public String toString() {
		return "UpdateAssignedToReq [lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUsername="
				+ lastUpdatedUsername + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", assignees=" + assignees + "]";
	}

}
