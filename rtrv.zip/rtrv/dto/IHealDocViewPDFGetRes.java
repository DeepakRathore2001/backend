package com.healogics.rtrv.dto;

import java.util.List;

public class IHealDocViewPDFGetRes {
	private String pdfStream;
	private String pdfMimeType;
	private String clientState;
	private String errorCode;
	private String errorMessage;
	private List<IHealErrorDetails> errors;
	private List<IHealErrorDetails> warnings;

	public String getPdfStream() {
		return pdfStream;
	}
	public void setPdfStream(String pdfStream) {
		this.pdfStream = pdfStream;
	}
	public String getPdfMimeType() {
		return pdfMimeType;
	}
	public void setPdfMimeType(String pdfMimeType) {
		this.pdfMimeType = pdfMimeType;
	}
	public String getClientState() {
		return clientState;
	}
	public void setClientState(String clientState) {
		this.clientState = clientState;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<IHealErrorDetails> getErrors() {
		return errors;
	}
	public void setErrors(List<IHealErrorDetails> errors) {
		this.errors = errors;
	}
	public List<IHealErrorDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<IHealErrorDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "DocViewPDFGetRes [pdfStream=" + pdfStream + ", pdfMimeType=" + pdfMimeType + ", clientState="
				+ clientState + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", errors=" + errors
				+ ", warnings=" + warnings + "]";
	}
}
