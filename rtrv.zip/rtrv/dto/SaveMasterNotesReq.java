package com.healogics.rtrv.dto;

import java.util.List;

public class SaveMasterNotesReq {
	private String requestId;
	private Long bhcInvoiceOrderNo;
	private String attemptCategory;
	private String attemptType;
	private String followupDate;
	private Boolean addendumSent;
	private Boolean addendumReceived;
	private Boolean receivedRX;
	private Boolean patientNotSeen30Days;
	private String description;
	private Long patientId;
	private String bluebookId;
	private int facilityId;
	private String patientFullname;
	private String lastUpdatedUsername;
	private String lastUpdatedUserId;
	private String lastUpdatedUserFullname;
	private String status;
	private List<TaggedUser> taggedUsers;
	private String contactMethod;
	private String contact;
	
	private String noteId;

	private String statusUpdatedUserFullName;
	private int addendum;
	private int recordModify;
	
	private String serviceLine;
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public int getAddendum() {
		return addendum;
	}
	public void setAddendum(int addendum) {
		this.addendum = addendum;
	}
	public int getRecordModify() {
		return recordModify;
	}
	public void setRecordModify(int recordModify) {
		this.recordModify = recordModify;
	}
	public String getStatusUpdatedUserFullName() {
		return statusUpdatedUserFullName;
	}
	public void setStatusUpdatedUserFullName(String statusUpdatedUserFullName) {
		this.statusUpdatedUserFullName = statusUpdatedUserFullName;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public Long getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}
	public void setBhcInvoiceOrderNo(Long bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}
	public String getAttemptCategory() {
		return attemptCategory;
	}
	public void setAttemptCategory(String attemptCategory) {
		this.attemptCategory = attemptCategory;
	}
	public String getAttemptType() {
		return attemptType;
	}
	public void setAttemptType(String attemptType) {
		this.attemptType = attemptType;
	}
	public String getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(String followupDate) {
		this.followupDate = followupDate;
	}
	public Boolean getAddendumSent() {
		return addendumSent;
	}
	public void setAddendumSent(Boolean addendumSent) {
		this.addendumSent = addendumSent;
	}
	public Boolean getAddendumReceived() {
		return addendumReceived;
	}
	public void setAddendumReceived(Boolean addendumReceived) {
		this.addendumReceived = addendumReceived;
	}
	public Boolean getReceivedRX() {
		return receivedRX;
	}
	public void setReceivedRX(Boolean receivedRX) {
		this.receivedRX = receivedRX;
	}
	public Boolean getPatientNotSeen30Days() {
		return patientNotSeen30Days;
	}
	public void setPatientNotSeen30Days(Boolean patientNotSeen30Days) {
		this.patientNotSeen30Days = patientNotSeen30Days;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientFullname() {
		return patientFullname;
	}
	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<TaggedUser> getTaggedUsers() {
		return taggedUsers;
	}
	public void setTaggedUsers(List<TaggedUser> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}
	public String getContactMethod() {
		return contactMethod;
	}
	public void setContactMethod(String contactMethod) {
		this.contactMethod = contactMethod;
	}
	@Override
	public String toString() {
		return "SaveMasterNotesReq [requestId=" + requestId + ", bhcInvoiceOrderNo=" + bhcInvoiceOrderNo
				+ ", attemptCategory=" + attemptCategory + ", attemptType=" + attemptType + ", followupDate="
				+ followupDate + ", addendumSent=" + addendumSent + ", addendumReceived=" + addendumReceived
				+ ", receivedRX=" + receivedRX + ", patientNotSeen30Days=" + patientNotSeen30Days + ", description="
				+ description + ", patientId=" + patientId + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId
				+ ", patientFullname=" + patientFullname + ", lastUpdatedUsername=" + lastUpdatedUsername
				+ ", lastUpdatedUserId=" + lastUpdatedUserId + ", lastUpdatedUserFullname=" + lastUpdatedUserFullname
				+ ", status=" + status + ", taggedUsers=" + taggedUsers + ", contactMethod=" + contactMethod
				+ ", contact=" + contact + ", noteId=" + noteId + ", statusUpdatedUserFullName="
				+ statusUpdatedUserFullName + ", addendum=" + addendum + ", recordModify=" + recordModify
				+ ", serviceLine=" + serviceLine + "]";
	}
}
