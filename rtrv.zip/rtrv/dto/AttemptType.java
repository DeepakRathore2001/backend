package com.healogics.rtrv.dto;

import java.util.List;

public class AttemptType {
	private List<String> type;
	private List<String> contact;
	private List<String> vendorContact;
	
	public List<String> getVendorContact() {
		return vendorContact;
	}

	public void setVendorContact(List<String> vendorContact) {
		this.vendorContact = vendorContact;
	}

	public List<String> getType() {
		return type;
	}

	public void setType(List<String> type) {
		this.type = type;
	}

	public List<String> getContact() {
		return contact;
	}

	public void setContact(List<String> contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "AttemptType [type=" + type + ", contact=" + contact + ", vendorContact=" + vendorContact + "]";
	}
}
