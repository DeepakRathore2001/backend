package com.healogics.rtrv.dto;

public class IHealDocViewPDFGetReq {
	private String privateKey;
	private String masterToken;
	private int userId;
	private int facilityId;
	private int patientId;
	private int visitId;
	private String pdfFilename;
	private int jobId;

	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getPdfFilename() {
		return pdfFilename;
	}
	public void setPdfFilename(String pdfFilename) {
		this.pdfFilename = pdfFilename;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	@Override
	public String toString() {
		return "DocViewPDFGetReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId + ", visitId=" + visitId + ", pdfFilename="
				+ pdfFilename + ", jobId=" + jobId + "]";
	}
}
