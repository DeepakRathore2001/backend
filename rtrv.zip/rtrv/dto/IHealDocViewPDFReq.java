package com.healogics.rtrv.dto;

public class IHealDocViewPDFReq {
	private String privateKey;
	private String masterToken;
	private int userId;
	private int facilityId;
	private int patientId;
	private int visitId;
	private String jobSavePdfFileName;
	private String documentationViewName;
	private Boolean requireSignatures;
	private String clientState;

	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getJobSavePdfFileName() {
		return jobSavePdfFileName;
	}
	public void setJobSavePdfFileName(String jobSavePdfFileName) {
		this.jobSavePdfFileName = jobSavePdfFileName;
	}
	public String getDocumentationViewName() {
		return documentationViewName;
	}
	public void setDocumentationViewName(String documentationViewName) {
		this.documentationViewName = documentationViewName;
	}
	public Boolean getRequireSignatures() {
		return requireSignatures;
	}
	public void setRequireSignatures(Boolean requireSignatures) {
		this.requireSignatures = requireSignatures;
	}
	public String getClientState() {
		return clientState;
	}
	public void setClientState(String clientState) {
		this.clientState = clientState;
	}
	@Override
	public String toString() {
		return "IHealDocViewPDFReq [privateKey=" + privateKey
				+ ", masterToken=" + masterToken + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId + ", visitId=" + visitId
				+ ", jobSavePdfFileName=" + jobSavePdfFileName + ", documentationViewName=" + documentationViewName
				+ ", requireSignatures=" + requireSignatures + ", clientState=" + clientState + "]";
	}
}
