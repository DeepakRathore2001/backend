package com.healogics.rtrv.dto;

import java.util.List;

public class TeamMemberRes {
	private String responseCode;
	private String responseMessage;
	private List<TeamMember> teamMembers;

	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<TeamMember> getTeamMembers() {
		return teamMembers;
	}
	public void setTeamMembers(List<TeamMember> teamMembers) {
		this.teamMembers = teamMembers;
	}
	@Override
	public String toString() {
		return "TeamMemberRes [responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + ", teamMembers=" + teamMembers + "]";
	}
}
