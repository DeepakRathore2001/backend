package com.healogics.rtrv.dto;

import java.util.List;

public class SubmitRequest {
	private int bhcMedicalRecordId;
	private int bhcInvoiceOrderId;

	private int assigneeUserId;
	private String assigneeUserName;
	private String assigneeFullName;

	private String lastUpdatedUserId;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserName;
	
	private List<ManualAttachment> manualAttachments;
	private List<IHealDocument> iHealAttachments;
	
	private String masterToken;
	private String bluebookId;
	private int facilityId;
	private int patientId;
	
	private String facilityName;
	private String patientFirstName;
	private String patientLastName;
	private String bhcShipDate;
	private Long bhcPatientAccountNo;
	private String bhcPatientInv;
	private String lastTeamUpdatedUserFullname;
	
	private String currentStatus;
	
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getLastTeamUpdatedUserFullname() {
		return lastTeamUpdatedUserFullname;
	}
	public void setLastTeamUpdatedUserFullname(
			String lastTeamUpdatedUserFullname) {
		this.lastTeamUpdatedUserFullname = lastTeamUpdatedUserFullname;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getBhcShipDate() {
		return bhcShipDate;
	}
	public void setBhcShipDate(String bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}
	public Long getBhcPatientAccountNo() {
		return bhcPatientAccountNo;
	}
	public void setBhcPatientAccountNo(Long bhcPatientAccountNo) {
		this.bhcPatientAccountNo = bhcPatientAccountNo;
	}
	public String getBhcPatientInv() {
		return bhcPatientInv;
	}
	public void setBhcPatientInv(String bhcPatientInv) {
		this.bhcPatientInv = bhcPatientInv;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}
	public void setBhcMedicalRecordId(int bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}
	public int getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(int bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public int getAssigneeUserId() {
		return assigneeUserId;
	}
	public void setAssigneeUserId(int assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}
	public String getAssigneeUserName() {
		return assigneeUserName;
	}
	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}
	public String getAssigneeFullName() {
		return assigneeFullName;
	}
	public void setAssigneeFullName(String assigneeFullName) {
		this.assigneeFullName = assigneeFullName;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}
	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}
	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}
	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}
	public List<ManualAttachment> getManualAttachments() {
		return manualAttachments;
	}
	public void setManualAttachments(List<ManualAttachment> manualAttachments) {
		this.manualAttachments = manualAttachments;
	}
	public List<IHealDocument> getiHealAttachments() {
		return iHealAttachments;
	}
	public void setiHealAttachments(List<IHealDocument> iHealAttachments) {
		this.iHealAttachments = iHealAttachments;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	@Override
	public String toString() {
		return "SubmitRequest [bhcMedicalRecordId=" + bhcMedicalRecordId + ", bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", assigneeUserId=" + assigneeUserId + ", assigneeUserName=" + assigneeUserName
				+ ", assigneeFullName=" + assigneeFullName + ", lastUpdatedUserId=" + lastUpdatedUserId
				+ ", lastUpdatedUserFullName=" + lastUpdatedUserFullName + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", manualAttachments=" + manualAttachments + ", iHealAttachments="
				+ iHealAttachments + ", masterToken=" + masterToken + ", bluebookId=" + bluebookId + ", facilityId="
				+ facilityId + ", patientId=" + patientId + ", facilityName=" + facilityName + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName + ", bhcShipDate=" + bhcShipDate
				+ ", bhcPatientAccountNo=" + bhcPatientAccountNo + ", bhcPatientInv=" + bhcPatientInv
				+ ", lastTeamUpdatedUserFullname=" + lastTeamUpdatedUserFullname + ", currentStatus="
				+ currentStatus + "]";
	}
}
