package com.healogics.rtrv.dto;

import java.time.LocalDateTime;

public class Email {
	private Long bhcMedRecId;
	private Long bhcInOrderNo;
	private String noteId;
	private Long patientId;
	private String patientName;
	private String emailStatus;
	private LocalDateTime emailSentTime;
	private Long facilityId;
	private String bluebookId;
	private String responseCode;
	private String responseMessage;
	private String toEmailId;
	private LocalDateTime createdTimestamp;
	private Long noteCreatorUserId;
	private String noteCreatorUsername;
	private String noteCreatorUserFullname;
	private Long taggedUserId;
	private String taggedUsername;
	private String taggedUserFullname;
	private String noteURL;

	// CTP
	private String vendorRequestId;

	public String getVendorRequestId() {
		return vendorRequestId;
	}
	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}
	public Long getBhcMedRecId() {
		return bhcMedRecId;
	}
	public void setBhcMedRecId(Long bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}
	public Long getBhcInOrderNo() {
		return bhcInOrderNo;
	}
	public void setBhcInOrderNo(Long bhcInOrderNo) {
		this.bhcInOrderNo = bhcInOrderNo;
	}
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getEmailStatus() {
		return emailStatus;
	}
	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}
	public LocalDateTime getEmailSentTime() {
		return emailSentTime;
	}
	public void setEmailSentTime(LocalDateTime emailSentTime) {
		this.emailSentTime = emailSentTime;
	}
	public Long getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getToEmailId() {
		return toEmailId;
	}
	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}
	public LocalDateTime getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(LocalDateTime createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public Long getNoteCreatorUserId() {
		return noteCreatorUserId;
	}
	public void setNoteCreatorUserId(Long noteCreatorUserId) {
		this.noteCreatorUserId = noteCreatorUserId;
	}
	public String getNoteCreatorUsername() {
		return noteCreatorUsername;
	}
	public void setNoteCreatorUsername(String noteCreatorUsername) {
		this.noteCreatorUsername = noteCreatorUsername;
	}
	public String getNoteCreatorUserFullname() {
		return noteCreatorUserFullname;
	}
	public void setNoteCreatorUserFullname(String noteCreatorUserFullname) {
		this.noteCreatorUserFullname = noteCreatorUserFullname;
	}
	public Long getTaggedUserId() {
		return taggedUserId;
	}
	public void setTaggedUserId(Long taggedUserId) {
		this.taggedUserId = taggedUserId;
	}
	public String getTaggedUsername() {
		return taggedUsername;
	}
	public void setTaggedUsername(String taggedUsername) {
		this.taggedUsername = taggedUsername;
	}
	public String getTaggedUserFullname() {
		return taggedUserFullname;
	}
	public void setTaggedUserFullname(String taggedUserFullname) {
		this.taggedUserFullname = taggedUserFullname;
	}
	public String getNoteURL() {
		return noteURL;
	}
	public void setNoteURL(String noteURL) {
		this.noteURL = noteURL;
	}
	@Override
	public String toString() {
		return "Email [bhcMedRecId=" + bhcMedRecId + ", bhcInOrderNo="
				+ bhcInOrderNo + ", noteId=" + noteId + ", patientId="
				+ patientId + ", patientName=" + patientName + ", emailStatus="
				+ emailStatus + ", emailSentTime=" + emailSentTime
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + ", toEmailId=" + toEmailId
				+ ", createdTimestamp=" + createdTimestamp
				+ ", noteCreatorUserId=" + noteCreatorUserId
				+ ", noteCreatorUsername=" + noteCreatorUsername
				+ ", noteCreatorUserFullname=" + noteCreatorUserFullname
				+ ", taggedUserId=" + taggedUserId + ", taggedUsername="
				+ taggedUsername + ", taggedUserFullname=" + taggedUserFullname
				+ ", noteURL=" + noteURL + ", vendorRequestId="
				+ vendorRequestId + "]";
	}
}
