package com.healogics.rtrv.dto;

public class ChartReviewReq {

	private String medRecId;
	private String patientId;
	private String bhcInvoiceOrderId;
	private String noteId;
	private int index;

	// GetUserRolesList
	private Boolean isSuperUser;

	public Boolean getIsSuperUser() {
		return isSuperUser;
	}
	public void setIsSuperUser(Boolean isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getMedRecId() {
		return medRecId;
	}
	public void setMedRecId(String medRecId) {
		this.medRecId = medRecId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	@Override
	public String toString() {
		return "ChartReviewReq [medRecId=" + medRecId + ", patientId="
				+ patientId + ", bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", noteId=" + noteId + ", index=" + index + ", isSuperUser="
				+ isSuperUser + "]";
	}

}
