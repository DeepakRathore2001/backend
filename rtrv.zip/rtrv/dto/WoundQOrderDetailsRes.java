package com.healogics.rtrv.dto;

import java.util.Date;

public class WoundQOrderDetailsRes {
	private String placeOfService;
	private int responseCode;
	private Integer vendorId;
	private Integer patientId;
	private String orderStatus;
	private String orderPdfKey;
	private Date visitDate;
	private Date orderDate;
	private Integer orderStatusId;
	private Date poDate;
	private WoundQOrderFacilityObj facilityObject;
	private WoundQOrderPatientObj patient;
	private WoundQOrderDetails orderDetails;
	
	public String getPlaceOfService() {
		return placeOfService;
	}

	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}

	public WoundQOrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(WoundQOrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	public WoundQOrderPatientObj getPatient() {
		return patient;
	}

	public void setPatient(WoundQOrderPatientObj patient) {
		this.patient = patient;
	}

	public WoundQOrderFacilityObj getFacilityObject() {
		return facilityObject;
	}

	public void setFacilityObject(WoundQOrderFacilityObj facilityObject) {
		this.facilityObject = facilityObject;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public Integer getVendorId() {
		return vendorId;
	}

	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderPdfKey() {
		return orderPdfKey;
	}

	public void setOrderPdfKey(String orderPdfKey) {
		this.orderPdfKey = orderPdfKey;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Integer getOrderStatusId() {
		return orderStatusId;
	}

	public void setOrderStatusId(Integer orderStatusId) {
		this.orderStatusId = orderStatusId;
	}

	public Date getPoDate() {
		return poDate;
	}

	public void setPoDate(Date poDate) {
		this.poDate = poDate;
	}

	@Override
	public String toString() {
		return "WoundQOrderDetailsRes [responseCode=" + responseCode + ", vendorId=" + vendorId
				+ ", patientId=" + patientId + ", orderStatus="
				+ orderStatus + ", orderPdfKey=" + orderPdfKey + ", visitDate=" + visitDate + ", orderDate=" + orderDate
				+ ", orderStatusId=" + orderStatusId + ", poDate=" + poDate + ", facilityObject=" + facilityObject
				+ ", patient=" + patient + ", orderDetails=" + orderDetails + "]";
	}
}
