package com.healogics.rtrv.dto;

public class MasterCTPDashboardReq {

	private String serviceLine;
	private int index;
	private String taskType;
	private String username;
	private String userId;
	private int order;
	private String sortBy;

	// Filter options
	private String filterOptions;
	private String filters;

	private String bhcReferralId;
	private String bbc;
	private String vendor;
	private String firstReceivedStartDate;
	private String firstReceivedEndDate;
	private String followupStartDate;
	private String followupEndDate;
	private String patientName;
	private String age;
	private String assignedTo;
	private String orderSource;
	private String lastTeamUpdatedStartDate;
	private String lastTeamUpdatedEndDate;
	private String iHealConfiguration;

	private String patientDOB;
	
	private String excelColumns;
	private int offsetMinutes;

	private String orderId;
	private String retrieveStatus;
	private String currentStatus;
	private String primaryInsuranceCompany;

	// Batch Assigned Req
	private int batchAssigneeUserId;
	private String batchAssigneeUserName;
	private String batchAssigneeFullName;
	private int batchAssigneeChanged;
	private String lastUpdatedUserId;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserName;

	// Custom LastTeam UPdated Date:
	private boolean customDates;
	private String dateFilters;

	private Boolean isDataEmpty;

	private String todayMinDate;
	private String todayMaxDate;
	private String yesterdayMinDate;
	private String yesterdayMaxDate;
	private String thisWeekMinDate;
	private String thisWeekMaxDate;
	private String lastWeekMinDate;
	private String lastWeekMaxDate;

	// UniformDashboard Additional Columns
	private String bhcOrderSource;
	private String requestId;
	private String vendorOrderNo;
	private String insurance;
	private String responseStartDate;
	private String responseEndDate;
	private String vendorOrderStartDate;
	private String vendorOrderEndDate;
	private String receivedStartDate;
	private String receivedEndDate;
	private String vendorStatus;


	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	public String getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public String getReceivedStartDate() {
		return receivedStartDate;
	}
	public void setReceivedStartDate(String receivedStartDate) {
		this.receivedStartDate = receivedStartDate;
	}
	public String getReceivedEndDate() {
		return receivedEndDate;
	}
	public void setReceivedEndDate(String receivedEndDate) {
		this.receivedEndDate = receivedEndDate;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getVendorOrderNo() {
		return vendorOrderNo;
	}
	public void setVendorOrderNo(String vendorOrderNo) {
		this.vendorOrderNo = vendorOrderNo;
	}
	public String getInsurance() {
		return insurance;
	}
	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}
	public String getResponseStartDate() {
		return responseStartDate;
	}
	public void setResponseStartDate(String responseStartDate) {
		this.responseStartDate = responseStartDate;
	}
	public String getResponseEndDate() {
		return responseEndDate;
	}
	public void setResponseEndDate(String responseEndDate) {
		this.responseEndDate = responseEndDate;
	}
	public String getVendorOrderStartDate() {
		return vendorOrderStartDate;
	}
	public void setVendorOrderStartDate(String vendorOrderStartDate) {
		this.vendorOrderStartDate = vendorOrderStartDate;
	}
	public String getVendorOrderEndDate() {
		return vendorOrderEndDate;
	}
	public void setVendorOrderEndDate(String vendorOrderEndDate) {
		this.vendorOrderEndDate = vendorOrderEndDate;
	}
	public int getBatchAssigneeUserId() {
		return batchAssigneeUserId;
	}
	public void setBatchAssigneeUserId(int batchAssigneeUserId) {
		this.batchAssigneeUserId = batchAssigneeUserId;
	}
	public String getBatchAssigneeUserName() {
		return batchAssigneeUserName;
	}
	public void setBatchAssigneeUserName(String batchAssigneeUserName) {
		this.batchAssigneeUserName = batchAssigneeUserName;
	}
	public String getBatchAssigneeFullName() {
		return batchAssigneeFullName;
	}
	public void setBatchAssigneeFullName(String batchAssigneeFullName) {
		this.batchAssigneeFullName = batchAssigneeFullName;
	}
	public int getBatchAssigneeChanged() {
		return batchAssigneeChanged;
	}
	public void setBatchAssigneeChanged(int batchAssigneeChanged) {
		this.batchAssigneeChanged = batchAssigneeChanged;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}
	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}
	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}
	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}
	public int getOffsetMinutes() {
		return offsetMinutes;
	}
	public void setOffsetMinutes(int offsetMinutes) {
		this.offsetMinutes = offsetMinutes;
	}
	public boolean isCustomDates() {
		return customDates;
	}
	public void setCustomDates(boolean customDates) {
		this.customDates = customDates;
	}
	public String getDateFilters() {
		return dateFilters;
	}
	public void setDateFilters(String dateFilters) {
		this.dateFilters = dateFilters;
	}
	public Boolean getIsDataEmpty() {
		return isDataEmpty;
	}
	public void setIsDataEmpty(Boolean isDataEmpty) {
		this.isDataEmpty = isDataEmpty;
	}
	public String getTodayMinDate() {
		return todayMinDate;
	}
	public void setTodayMinDate(String todayMinDate) {
		this.todayMinDate = todayMinDate;
	}
	public String getTodayMaxDate() {
		return todayMaxDate;
	}
	public void setTodayMaxDate(String todayMaxDate) {
		this.todayMaxDate = todayMaxDate;
	}
	public String getYesterdayMinDate() {
		return yesterdayMinDate;
	}
	public void setYesterdayMinDate(String yesterdayMinDate) {
		this.yesterdayMinDate = yesterdayMinDate;
	}
	public String getYesterdayMaxDate() {
		return yesterdayMaxDate;
	}
	public void setYesterdayMaxDate(String yesterdayMaxDate) {
		this.yesterdayMaxDate = yesterdayMaxDate;
	}
	public String getThisWeekMinDate() {
		return thisWeekMinDate;
	}
	public void setThisWeekMinDate(String thisWeekMinDate) {
		this.thisWeekMinDate = thisWeekMinDate;
	}
	public String getThisWeekMaxDate() {
		return thisWeekMaxDate;
	}
	public void setThisWeekMaxDate(String thisWeekMaxDate) {
		this.thisWeekMaxDate = thisWeekMaxDate;
	}
	public String getLastWeekMinDate() {
		return lastWeekMinDate;
	}
	public void setLastWeekMinDate(String lastWeekMinDate) {
		this.lastWeekMinDate = lastWeekMinDate;
	}
	public String getLastWeekMaxDate() {
		return lastWeekMaxDate;
	}
	public void setLastWeekMaxDate(String lastWeekMaxDate) {
		this.lastWeekMaxDate = lastWeekMaxDate;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getFilterOptions() {
		return filterOptions;
	}
	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}
	public String getFilters() {
		return filters;
	}
	public void setFilters(String filters) {
		this.filters = filters;
	}
	public String getBhcReferralId() {
		return bhcReferralId;
	}
	public void setBhcReferralId(String bhcReferralId) {
		this.bhcReferralId = bhcReferralId;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getFirstReceivedStartDate() {
		return firstReceivedStartDate;
	}
	public void setFirstReceivedStartDate(String firstReceivedStartDate) {
		this.firstReceivedStartDate = firstReceivedStartDate;
	}
	public String getFirstReceivedEndDate() {
		return firstReceivedEndDate;
	}
	public void setFirstReceivedEndDate(String firstReceivedEndDate) {
		this.firstReceivedEndDate = firstReceivedEndDate;
	}
	public String getFollowupStartDate() {
		return followupStartDate;
	}
	public void setFollowupStartDate(String followupStartDate) {
		this.followupStartDate = followupStartDate;
	}
	public String getFollowupEndDate() {
		return followupEndDate;
	}
	public void setFollowupEndDate(String followupEndDate) {
		this.followupEndDate = followupEndDate;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getBhcOrderSource() {
		return bhcOrderSource;
	}
	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}
	public String getLastTeamUpdatedStartDate() {
		return lastTeamUpdatedStartDate;
	}
	public void setLastTeamUpdatedStartDate(String lastTeamUpdatedStartDate) {
		this.lastTeamUpdatedStartDate = lastTeamUpdatedStartDate;
	}
	public String getLastTeamUpdatedEndDate() {
		return lastTeamUpdatedEndDate;
	}
	public void setLastTeamUpdatedEndDate(String lastTeamUpdatedEndDate) {
		this.lastTeamUpdatedEndDate = lastTeamUpdatedEndDate;
	}
	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}
	public String getExcelColumns() {
		return excelColumns;
	}
	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getPrimaryInsuranceCompany() {
		return primaryInsuranceCompany;
	}
	public void setPrimaryInsuranceCompany(String primaryInsuranceCompany) {
		this.primaryInsuranceCompany = primaryInsuranceCompany;
	}
	@Override
	public String toString() {
		return "MasterCTPDashboardReq [serviceLine=" + serviceLine + ", index="
				+ index + ", taskType=" + taskType + ", username=" + username
				+ ", userId=" + userId + ", order=" + order + ", sortBy="
				+ sortBy + ", filterOptions=" + filterOptions + ", filters="
				+ filters + ", bhcReferralId=" + bhcReferralId + ", bbc=" + bbc
				+ ", vendor=" + vendor + ", firstReceivedStartDate="
				+ firstReceivedStartDate + ", firstReceivedEndDate="
				+ firstReceivedEndDate + ", followupStartDate="
				+ followupStartDate + ", followupEndDate=" + followupEndDate
				+ ", patientName=" + patientName + ", age=" + age
				+ ", assignedTo=" + assignedTo + ", orderSource=" + orderSource
				+ ", lastTeamUpdatedStartDate=" + lastTeamUpdatedStartDate
				+ ", lastTeamUpdatedEndDate=" + lastTeamUpdatedEndDate
				+ ", iHealConfiguration=" + iHealConfiguration + ", patientDOB="
				+ patientDOB + ", excelColumns=" + excelColumns
				+ ", offsetMinutes=" + offsetMinutes + ", orderId=" + orderId
				+ ", retrieveStatus=" + retrieveStatus + ", currentStatus="
				+ currentStatus + ", primaryInsuranceCompany="
				+ primaryInsuranceCompany + ", batchAssigneeUserId="
				+ batchAssigneeUserId + ", batchAssigneeUserName="
				+ batchAssigneeUserName + ", batchAssigneeFullName="
				+ batchAssigneeFullName + ", batchAssigneeChanged="
				+ batchAssigneeChanged + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", lastUpdatedUserFullName="
				+ lastUpdatedUserFullName + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", customDates=" + customDates
				+ ", dateFilters=" + dateFilters + ", isDataEmpty="
				+ isDataEmpty + ", todayMinDate=" + todayMinDate
				+ ", todayMaxDate=" + todayMaxDate + ", yesterdayMinDate="
				+ yesterdayMinDate + ", yesterdayMaxDate=" + yesterdayMaxDate
				+ ", thisWeekMinDate=" + thisWeekMinDate + ", thisWeekMaxDate="
				+ thisWeekMaxDate + ", lastWeekMinDate=" + lastWeekMinDate
				+ ", lastWeekMaxDate=" + lastWeekMaxDate + ", bhcOrderSource="
				+ bhcOrderSource + ", requestId=" + requestId
				+ ", vendorOrderNo=" + vendorOrderNo + ", insurance="
				+ insurance + ", responseStartDate=" + responseStartDate
				+ ", responseEndDate=" + responseEndDate
				+ ", vendorOrderStartDate=" + vendorOrderStartDate
				+ ", vendorOrderEndDate=" + vendorOrderEndDate
				+ ", receivedStartDate=" + receivedStartDate
				+ ", receivedEndDate=" + receivedEndDate + ", vendorStatus="
				+ vendorStatus + "]";
	}

}
