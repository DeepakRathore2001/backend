package com.healogics.rtrv.dto;

public class MasterNoteByIdRes {
	private String responseCode;
	private String responseMessage;
	private MasterNotesDetails note;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public MasterNotesDetails getNote() {
		return note;
	}

	public void setNote(MasterNotesDetails note) {
		this.note = note;
	}

	@Override
	public String toString() {
		return "MasterNoteByIdRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage + ", note="
				+ note + "]";
	}

}
