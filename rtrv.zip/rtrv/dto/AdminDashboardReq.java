package com.healogics.rtrv.dto;

import java.util.List;

public class AdminDashboardReq {

	// ISSuperUser
	private Boolean isSuperUser;

	private String serviceLine;
	private int index;
	private int order;
	private String sortBy;

	private String dropDown;
	// Filter options
	private String filterOptions;
	private String filters;

	// center assignments table
	private String bbc;
	private String territory;
	private String awdClerk;
	private String awdSpecialist;
	private String npwtClerk;
	private String npwtSpecialist;
	private String ctpClerk;
	private String ctpSpecialist;
	private String division;
	private String market;
	private String ihealConfig;
	private String opsSpecialist;

	// role assignments table
	private String assigneeFullname;
	private String role;
	private String businessRole;
	private String email;
	private String assigneeUsername;

	// update retrieve users request fields
	
	private List<UpdateRetrieveUsersReq> userRoles;

	public String getDropDown() {
		return dropDown;
	}
	public void setDropDown(String dropDown) {
		this.dropDown = dropDown;
	}
	public Boolean getIsSuperUser() {
		return isSuperUser;
	}
	public void setIsSuperUser(Boolean isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public String getBusinessRole() {
		return businessRole;
	}
	public void setBusinessRole(String businessRole) {
		this.businessRole = businessRole;
	}
	public String getAssigneeFullname() {
		return assigneeFullname;
	}
	public void setAssigneeFullname(String assigneeFullname) {
		this.assigneeFullname = assigneeFullname;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAssigneeUsername() {
		return assigneeUsername;
	}
	public void setAssigneeUsername(String assigneeUsername) {
		this.assigneeUsername = assigneeUsername;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getFilterOptions() {
		return filterOptions;
	}
	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}
	public String getFilters() {
		return filters;
	}
	public void setFilters(String filters) {
		this.filters = filters;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public String getTerritory() {
		return territory;
	}
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	public String getAwdClerk() {
		return awdClerk;
	}
	public void setAwdClerk(String awdClerk) {
		this.awdClerk = awdClerk;
	}
	public String getAwdSpecialist() {
		return awdSpecialist;
	}
	public void setAwdSpecialist(String awdSpecialist) {
		this.awdSpecialist = awdSpecialist;
	}
	public String getNpwtClerk() {
		return npwtClerk;
	}
	public void setNpwtClerk(String npwtClerk) {
		this.npwtClerk = npwtClerk;
	}
	public String getNpwtSpecialist() {
		return npwtSpecialist;
	}
	public void setNpwtSpecialist(String npwtSpecialist) {
		this.npwtSpecialist = npwtSpecialist;
	}
	public String getCtpClerk() {
		return ctpClerk;
	}
	public void setCtpClerk(String ctpClerk) {
		this.ctpClerk = ctpClerk;
	}
	public String getCtpSpecialist() {
		return ctpSpecialist;
	}
	public void setCtpSpecialist(String ctpSpecialist) {
		this.ctpSpecialist = ctpSpecialist;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getIhealConfig() {
		return ihealConfig;
	}
	public void setIhealConfig(String ihealConfig) {
		this.ihealConfig = ihealConfig;
	}
	public String getOpsSpecialist() {
		return opsSpecialist;
	}
	public void setOpsSpecialist(String opsSpecialist) {
		this.opsSpecialist = opsSpecialist;
	}
	public List<UpdateRetrieveUsersReq> getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(List<UpdateRetrieveUsersReq> userRoles) {
		this.userRoles = userRoles;
	}
	@Override
	public String toString() {
		return "AdminDashboardReq [isSuperUser=" + isSuperUser + ", serviceLine=" + serviceLine + ", index=" + index
				+ ", order=" + order + ", sortBy=" + sortBy + ", dropDown=" + dropDown + ", filterOptions="
				+ filterOptions + ", filters=" + filters + ", bbc=" + bbc + ", territory=" + territory + ", awdClerk="
				+ awdClerk + ", awdSpecialist=" + awdSpecialist + ", npwtClerk=" + npwtClerk + ", npwtSpecialist="
				+ npwtSpecialist + ", ctpClerk=" + ctpClerk + ", ctpSpecialist=" + ctpSpecialist + ", division="
				+ division + ", market=" + market + ", ihealConfig=" + ihealConfig + ", opsSpecialist=" + opsSpecialist
				+ ", assigneeFullname=" + assigneeFullname + ", role=" + role + ", businessRole=" + businessRole
				+ ", email=" + email + ", assigneeUsername=" + assigneeUsername + ", userRoles=" + userRoles + "]";
	}

}
