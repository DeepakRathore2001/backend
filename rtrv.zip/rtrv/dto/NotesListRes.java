package com.healogics.rtrv.dto;

import java.util.List;

public class NotesListRes {
	private String responseCode;
	private String responseMessage;
	private int currentIndex;
	private int nextIndex;
	private double totalPage;
	private Long totalCount;
	private boolean isExhausted;
	private List<NotesDetails> notes;

	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	public int getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	public int getNextIndex() {
		return nextIndex;
	}
	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<NotesDetails> getNotes() {
		return notes;
	}
	public void setNotes(List<NotesDetails> notes) {
		this.notes = notes;
	}
	@Override
	public String toString() {
		return "NotesListRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", currentIndex="
				+ currentIndex + ", nextIndex=" + nextIndex + ", totalPage="
				+ totalPage + ", totalCount=" + totalCount + ", isExhausted="
				+ isExhausted + ", notes=" + notes + "]";
	}

}
