package com.healogics.rtrv.dto;

import java.util.List;

public class NotesAttemptDetails extends APIResponse {
	private List<AttemptCategory> notesAttempt;
	private String serviceLine;

	public List<AttemptCategory> getNotesAttempt() {
		return notesAttempt;
	}

	public void setNotesAttempt(List<AttemptCategory> notesAttempt) {
		this.notesAttempt = notesAttempt;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	@Override
	public String toString() {
		return "NotesAttemptDetails [notesAttempt=" + notesAttempt
				+ ", serviceLine=" + serviceLine + "]";
	}

}
