package com.healogics.rtrv.dto;

import java.util.List;

public class MasterAppNotificaionReq {
	private String userId;
	private String serviceLine;
	private Boolean readFlag;
	private Boolean clearedFlag;
	private Boolean readAllFlag;
	private List<String> notificationId;
	
	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Boolean getReadFlag() {
		return readFlag;
	}

	public void setReadFlag(Boolean readFlag) {
		this.readFlag = readFlag;
	}

	public Boolean getClearedFlag() {
		return clearedFlag;
	}

	public void setClearedFlag(Boolean clearedFlag) {
		this.clearedFlag = clearedFlag;
	}

	public Boolean getReadAllFlag() {
		return readAllFlag;
	}

	public void setReadAllFlag(Boolean readAllFlag) {
		this.readAllFlag = readAllFlag;
	}

	public List<String> getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(List<String> notificationId) {
		this.notificationId = notificationId;
	}

	@Override
	public String toString() {
		return "MasterAppNotificaionReq [userId=" + userId + ", serviceLine=" + serviceLine + ", readFlag=" + readFlag
				+ ", clearedFlag=" + clearedFlag + ", readAllFlag=" + readAllFlag + ", notificationId=" + notificationId
				+ "]";
	}
}
