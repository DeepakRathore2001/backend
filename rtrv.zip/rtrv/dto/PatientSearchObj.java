package com.healogics.rtrv.dto;

import java.io.Serializable;

public class PatientSearchObj implements Serializable {
	private static final long serialVersionUID = 1L;
	private String firstName;
	private String lastName;
	private String sex;
	private int age;
	private String mrnNumber;
	private String patientId;
	private String patientDOB;
	private String dischargeDate;
	private String dischargeStatusCode;

	public String getDischargeDate() {
		return dischargeDate;
	}
	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}
	public String getDischargeStatusCode() {
		return dischargeStatusCode;
	}
	public void setDischargeStatusCode(String dischargeStatusCode) {
		this.dischargeStatusCode = dischargeStatusCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMrnNumber() {
		return mrnNumber;
	}
	public void setMrnNumber(String mrnNumber) {
		this.mrnNumber = mrnNumber;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	@Override
	public String toString() {
		return "PatientSearchObj [firstName=" + firstName + ", lastName="
				+ lastName + ", sex=" + sex + ", age=" + age + ", mrnNumber="
				+ mrnNumber + ", patientId=" + patientId + ", patientDOB="
				+ patientDOB + ", dischargeDate=" + dischargeDate
				+ ", dischargeStatusCode=" + dischargeStatusCode + "]";
	}

}
