package com.healogics.rtrv.dto;

import java.util.List;

public class WoundQOrderDetails {
	private String physician;
	private String caseManager;
	private Integer orderDisplayNumber;
	private List<WoundQWoundDetails> wounds;
	
	public List<WoundQWoundDetails> getWounds() {
		return wounds;
	}

	public void setWounds(List<WoundQWoundDetails> wounds) {
		this.wounds = wounds;
	}

	public Integer getOrderDisplayNumber() {
		return orderDisplayNumber;
	}

	public void setOrderDisplayNumber(Integer orderDisplayNumber) {
		this.orderDisplayNumber = orderDisplayNumber;
	}

	public String getPhysician() {
		return physician;
	}

	public void setPhysician(String physician) {
		this.physician = physician;
	}

	public String getCaseManager() {
		return caseManager;
	}

	public void setCaseManager(String caseManager) {
		this.caseManager = caseManager;
	}

	@Override
	public String toString() {
		return "WoundQOrderDetails [physician=" + physician + ", caseManager=" + caseManager + ", orderDisplayNumber="
				+ orderDisplayNumber + ", wounds=" + wounds + "]";
	}
}
