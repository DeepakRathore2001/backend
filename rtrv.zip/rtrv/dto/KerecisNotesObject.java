package com.healogics.rtrv.dto;

public class KerecisNotesObject {
	private String id;
	private String description;
	private String user;
	private String timestamp;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "KerecisNotesObject [id=" + id + ", description=" + description
				+ ", user=" + user + ", timestamp="
				+ timestamp + "]";
	}
}
