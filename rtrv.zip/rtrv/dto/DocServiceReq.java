package com.healogics.rtrv.dto;

public class DocServiceReq {
	private String bluebookId;
	private int facilityId;
	private int patientId;
	private int visitId;
	private String docType;
	private String pdfFilename;
	private int jobId;
	private String clientState;
	private String masterToken;
	private int userId;
	private String docEntityId;
	
	private String jobSavePdfFileName;
	private String documentationViewName;
	private Boolean requireSignatures;

	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getPdfFilename() {
		return pdfFilename;
	}
	public void setPdfFilename(String pdfFilename) {
		this.pdfFilename = pdfFilename;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getClientState() {
		return clientState;
	}
	public void setClientState(String clientState) {
		this.clientState = clientState;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getJobSavePdfFileName() {
		return jobSavePdfFileName;
	}
	public void setJobSavePdfFileName(String jobSavePdfFileName) {
		this.jobSavePdfFileName = jobSavePdfFileName;
	}
	public String getDocumentationViewName() {
		return documentationViewName;
	}
	public void setDocumentationViewName(String documentationViewName) {
		this.documentationViewName = documentationViewName;
	}
	public Boolean getRequireSignatures() {
		return requireSignatures;
	}
	public void setRequireSignatures(Boolean requireSignatures) {
		this.requireSignatures = requireSignatures;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	@Override
	public String toString() {
		return "DocServiceReq [bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", visitId=" + visitId + ", docType=" + docType + ", pdfFilename=" + pdfFilename + ", jobId=" + jobId
				+ ", clientState=" + clientState + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", docEntityId=" + docEntityId + ", jobSavePdfFileName=" + jobSavePdfFileName
				+ ", documentationViewName=" + documentationViewName + ", requireSignatures=" + requireSignatures + "]";
	}
}
