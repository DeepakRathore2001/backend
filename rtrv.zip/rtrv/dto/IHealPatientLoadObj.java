package com.healogics.rtrv.dto;

import java.io.Serializable;

public class IHealPatientLoadObj implements Serializable {
	private static final long serialVersionUID = 1L;
	private String patientId;
	private String patientFirstName;
	private String patientLastName;
	private String patientNumber;
	private String patientDOB;
	private String patientSex;
	private String admissionDate;
	private String preregistrationDate;

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getPatientNumber() {
		return patientNumber;
	}

	public void setPatientNumber(String patientNumber) {
		this.patientNumber = patientNumber;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientSex() {
		return patientSex;
	}

	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}

	public String getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getPreregistrationDate() {
		return preregistrationDate;
	}

	public void setPreregistrationDate(String preregistrationDate) {
		this.preregistrationDate = preregistrationDate;
	}

	@Override
	public String toString() {
		return "IHealPatientLoadObj [patientId=" + patientId + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientNumber=" + patientNumber + ", patientDOB="
				+ patientDOB + ", patientSex=" + patientSex + ", admissionDate=" + admissionDate + ", preregistrationDate="
				+ preregistrationDate + "]";
	}
}
