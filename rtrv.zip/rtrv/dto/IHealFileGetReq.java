package com.healogics.rtrv.dto;

import java.io.Serializable;

public class IHealFileGetReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String eventDateTime;
	private int userId;
	private int facilityId;
	private int patientId;
	private String documentEntityId;
	private String type;
	private String reconciliationId;
	
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getEventDateTime() {
		return eventDateTime;
	}
	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(String documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getReconciliationId() {
		return reconciliationId;
	}
	public void setReconciliationId(String reconciliationId) {
		this.reconciliationId = reconciliationId;
	}
	@Override
	public String toString() {
		return "IHealFileGetReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", eventDateTime="
				+ eventDateTime + ", userId=" + userId + ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", documentEntityId=" + documentEntityId + ", type=" + type + ", reconciliationId=" + reconciliationId
				+ "]";
	}

}
