package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class LoginRes implements Serializable {

	private static final long serialVersionUID = -6036965257257155474L;
	private String accessToken;
	private String refreshToken;
	private String responseCode;
	private String responseMessage;
	private IhealUserdetails ihealUserdetails;
	private UserPreferenceDetails userPreferenceDetails;
	private List<ServiceLineList> serviceLineList;
	private List<UserFacilities> facilities;
	private String userRole;
	private List<String> businessRole;
	private Boolean isSuperUser;

	public Boolean getIsSuperUser() {
		return isSuperUser;
	}
	public void setIsSuperUser(Boolean isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public List<String> getBusinessRole() {
		return businessRole;
	}
	public void setBusinessRole(List<String> businessRole) {
		this.businessRole = businessRole;
	}
	public List<UserFacilities> getFacilities() {
		return facilities;
	}
	public void setFacilities(List<UserFacilities> facilities) {
		this.facilities = facilities;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public List<ServiceLineList> getServiceLineList() {
		return serviceLineList;
	}
	public void setServiceLineList(List<ServiceLineList> serviceLineList) {
		this.serviceLineList = serviceLineList;
	}
	public UserPreferenceDetails getUserPreferenceDetails() {
		return userPreferenceDetails;
	}
	public void setUserPreferenceDetails(
			UserPreferenceDetails userPreferenceDetails) {
		this.userPreferenceDetails = userPreferenceDetails;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public IhealUserdetails getIhealUserdetails() {
		return ihealUserdetails;
	}
	public void setIhealUserdetails(IhealUserdetails ihealUserdetails) {
		this.ihealUserdetails = ihealUserdetails;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	@Override
	public String toString() {
		return "LoginRes [accessToken=" + accessToken + ", refreshToken="
				+ refreshToken + ", responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", ihealUserdetails="
				+ ihealUserdetails + ", userPreferenceDetails="
				+ userPreferenceDetails + ", serviceLineList=" + serviceLineList
				+ ", facilities=" + facilities + ", userRole=" + userRole
				+ ", businessRole=" + businessRole + ", isSuperUser="
				+ isSuperUser + "]";
	}

}
