package com.healogics.rtrv.dto;

public class VisitObj {

	private int visitId;
	private String dateOfService;
	private int visitTypeCode;
	private String visitTypeDescription;
	private int serviceLineId;
	private String serviceLineDescription;
	private int visitStatus;
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getDateOfService() {
		return dateOfService;
	}
	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}
	public int getVisitTypeCode() {
		return visitTypeCode;
	}
	public void setVisitTypeCode(int visitTypeCode) {
		this.visitTypeCode = visitTypeCode;
	}
	public String getVisitTypeDescription() {
		return visitTypeDescription;
	}
	public void setVisitTypeDescription(String visitTypeDescription) {
		this.visitTypeDescription = visitTypeDescription;
	}
	public int getServiceLineId() {
		return serviceLineId;
	}
	public void setServiceLineId(int serviceLineId) {
		this.serviceLineId = serviceLineId;
	}
	public String getServiceLineDescription() {
		return serviceLineDescription;
	}
	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}
	public int getVisitStatus() {
		return visitStatus;
	}
	public void setVisitStatus(int visitStatus) {
		this.visitStatus = visitStatus;
	}
	@Override
	public String toString() {
		return "VisitObj [visitId=" + visitId + ", dateOfService="
				+ dateOfService + ", visitTypeCode=" + visitTypeCode
				+ ", visitTypeDescription=" + visitTypeDescription
				+ ", serviceLineId=" + serviceLineId
				+ ", serviceLineDescription=" + serviceLineDescription
				+ ", visitStatus=" + visitStatus + "]";
	}

}
