package com.healogics.rtrv.dto;

public class WoundQOrderDetailsReq {
	
	private String orderToken;
	private Integer patientId;
	private Integer vendorId;
	public String getOrderToken() {
		return orderToken;
	}
	public void setOrderToken(String orderToken) {
		this.orderToken = orderToken;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	@Override
	public String toString() {
		return "WoundQOrderDetailsReq [orderToken=" + orderToken + ", patientId=" + patientId + ", vendorId=" + vendorId
				+ "]";
	}
	
	
	
}
