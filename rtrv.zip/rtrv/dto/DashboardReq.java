package com.healogics.rtrv.dto;

public class DashboardReq {
	private String serviceLine;
	private int index;
	private String taskType;
	private String username;
	private String userId;
	private int order;
	private String sortBy;

	// Filter options
	private String filterOptions;
	private String filters;
	private boolean customDates;
	private String dateFilters;

	private Boolean isDataEmpty;

	private String todayMinDate;
	private String todayMaxDate;
	private String yesterdayMinDate;
	private String yesterdayMaxDate;
	private String thisWeekMinDate;
	private String thisWeekMaxDate;
	private String lastWeekMinDate;
	private String lastWeekMaxDate;

	private int offsetMinutes;

	private String bhcReferralId;
	private String bbc;
	private String bhcMedRecId;
	private String vendor;
	private String bhcInvoiceOrderId;
	private String bhcOrderReceivedStartDate;
	private String bhcOrderReceivedEndDate;
	private String firstReceivedStartDate;
	private String firstReceivedEndDate;
	private String followupStartDate;
	private String followupEndDate;
	private String patientName;
	private String age;
	private String assignedTo;
	private String bhcOrderSource;
	private String lastTeamUpdatedStartDate;
	private String lastTeamUpdatedEndDate;
	private String iHealConfiguration;
	private String status;
	private String bhcMedRecAddedStartDate;
	private String bhcMedRecAddedEndDate;
	private String bhcDocStatus;
	private String insuranceType;
	private String bhcMissingDocNotes;
	private String patientDOB;
	private String providerName;
	private String bhcPatientAcctId;
	private String bhcShipStartDate;
	private String bhcShipEndDate;
	private String bhcLastUpdateStartDate;
	private String bhcLastUpdateEndDate;

	private String excelColumns;

	private int batchAssigneeUserId;
	private String batchAssigneeUserName;
	private String batchAssigneeFullName;
	private int batchAssigneeChanged;
	private String lastUpdatedUserId;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserName;

	// CTP
	private String caseId;
	private String retrieveStatus;
	private String currentStatus;
	private String primaryInsCompany;

	public String getBhcLastUpdateStartDate() {
		return bhcLastUpdateStartDate;
	}

	public void setBhcLastUpdateStartDate(String bhcLastUpdateStartDate) {
		this.bhcLastUpdateStartDate = bhcLastUpdateStartDate;
	}

	public String getBhcLastUpdateEndDate() {
		return bhcLastUpdateEndDate;
	}

	public void setBhcLastUpdateEndDate(String bhcLastUpdateEndDate) {
		this.bhcLastUpdateEndDate = bhcLastUpdateEndDate;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getPrimaryInsCompany() {
		return primaryInsCompany;
	}

	public void setPrimaryInsCompany(String primaryInsCompany) {
		this.primaryInsCompany = primaryInsCompany;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getBhcPatientAcctId() {
		return bhcPatientAcctId;
	}

	public void setBhcPatientAcctId(String bhcPatientAcctId) {
		this.bhcPatientAcctId = bhcPatientAcctId;
	}

	public String getBhcShipStartDate() {
		return bhcShipStartDate;
	}

	public void setBhcShipStartDate(String bhcShipStartDate) {
		this.bhcShipStartDate = bhcShipStartDate;
	}

	public String getBhcShipEndDate() {
		return bhcShipEndDate;
	}

	public void setBhcShipEndDate(String bhcShipEndDate) {
		this.bhcShipEndDate = bhcShipEndDate;
	}

	public String getFirstReceivedStartDate() {
		return firstReceivedStartDate;
	}

	public void setFirstReceivedStartDate(String firstReceivedStartDate) {
		this.firstReceivedStartDate = firstReceivedStartDate;
	}

	public String getFirstReceivedEndDate() {
		return firstReceivedEndDate;
	}

	public void setFirstReceivedEndDate(String firstReceivedEndDate) {
		this.firstReceivedEndDate = firstReceivedEndDate;
	}

	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}

	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}

	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}

	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}

	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}

	public int getBatchAssigneeUserId() {
		return batchAssigneeUserId;
	}

	public void setBatchAssigneeUserId(int batchAssigneeUserId) {
		this.batchAssigneeUserId = batchAssigneeUserId;
	}

	public String getBatchAssigneeUserName() {
		return batchAssigneeUserName;
	}

	public void setBatchAssigneeUserName(String batchAssigneeUserName) {
		this.batchAssigneeUserName = batchAssigneeUserName;
	}

	public String getBatchAssigneeFullName() {
		return batchAssigneeFullName;
	}

	public void setBatchAssigneeFullName(String batchAssigneeFullName) {
		this.batchAssigneeFullName = batchAssigneeFullName;
	}

	public int getBatchAssigneeChanged() {
		return batchAssigneeChanged;
	}

	public void setBatchAssigneeChanged(int batchAssigneeChanged) {
		this.batchAssigneeChanged = batchAssigneeChanged;
	}

	public String getBhcDocStatus() {
		return bhcDocStatus;
	}

	public void setBhcDocStatus(String bhcDocStatus) {
		this.bhcDocStatus = bhcDocStatus;
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public String getExcelColumns() {
		return excelColumns;
	}

	public void setExcelColumns(String excelColumns) {
		this.excelColumns = excelColumns;
	}

	public String getFollowupStartDate() {
		return followupStartDate;
	}

	public void setFollowupStartDate(String followupStartDate) {
		this.followupStartDate = followupStartDate;
	}

	public String getFollowupEndDate() {
		return followupEndDate;
	}

	public void setFollowupEndDate(String followupEndDate) {
		this.followupEndDate = followupEndDate;
	}

	public Boolean getIsDataEmpty() {
		return isDataEmpty;
	}

	public void setIsDataEmpty(Boolean isDataEmpty) {
		this.isDataEmpty = isDataEmpty;
	}

	public int getOffsetMinutes() {
		return offsetMinutes;
	}

	public void setOffsetMinutes(int offsetMinutes) {
		this.offsetMinutes = offsetMinutes;
	}

	public String getBhcMedRecId() {
		return bhcMedRecId;
	}

	public void setBhcMedRecId(String bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}

	public boolean getCustomDates() {
		return customDates;
	}

	public void setCustomDates(boolean customDates) {
		this.customDates = customDates;
	}

	public String getDateFilters() {
		return dateFilters;
	}

	public void setDateFilters(String dateFilters) {
		this.dateFilters = dateFilters;
	}

	public String getTodayMinDate() {
		return todayMinDate;
	}

	public void setTodayMinDate(String todayMinDate) {
		this.todayMinDate = todayMinDate;
	}

	public String getTodayMaxDate() {
		return todayMaxDate;
	}

	public void setTodayMaxDate(String todayMaxDate) {
		this.todayMaxDate = todayMaxDate;
	}

	public String getYesterdayMinDate() {
		return yesterdayMinDate;
	}

	public void setYesterdayMinDate(String yesterdayMinDate) {
		this.yesterdayMinDate = yesterdayMinDate;
	}

	public String getYesterdayMaxDate() {
		return yesterdayMaxDate;
	}

	public void setYesterdayMaxDate(String yesterdayMaxDate) {
		this.yesterdayMaxDate = yesterdayMaxDate;
	}

	public String getThisWeekMinDate() {
		return thisWeekMinDate;
	}

	public void setThisWeekMinDate(String thisWeekMinDate) {
		this.thisWeekMinDate = thisWeekMinDate;
	}

	public String getThisWeekMaxDate() {
		return thisWeekMaxDate;
	}

	public void setThisWeekMaxDate(String thisWeekMaxDate) {
		this.thisWeekMaxDate = thisWeekMaxDate;
	}

	public String getLastWeekMinDate() {
		return lastWeekMinDate;
	}

	public void setLastWeekMinDate(String lastWeekMinDate) {
		this.lastWeekMinDate = lastWeekMinDate;
	}

	public String getLastWeekMaxDate() {
		return lastWeekMaxDate;
	}

	public void setLastWeekMaxDate(String lastWeekMaxDate) {
		this.lastWeekMaxDate = lastWeekMaxDate;
	}

	public String getLastTeamUpdatedStartDate() {
		return lastTeamUpdatedStartDate;
	}

	public void setLastTeamUpdatedStartDate(String lastTeamUpdatedStartDate) {
		this.lastTeamUpdatedStartDate = lastTeamUpdatedStartDate;
	}

	public String getLastTeamUpdatedEndDate() {
		return lastTeamUpdatedEndDate;
	}

	public void setLastTeamUpdatedEndDate(String lastTeamUpdatedEndDate) {
		this.lastTeamUpdatedEndDate = lastTeamUpdatedEndDate;
	}

	public String getBhcReferralId() {
		return bhcReferralId;
	}

	public void setBhcReferralId(String bhcReferralId) {
		this.bhcReferralId = bhcReferralId;
	}

	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}

	public String getBbc() {
		return bbc;
	}

	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}

	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}

	public String getBhcOrderReceivedStartDate() {
		return bhcOrderReceivedStartDate;
	}

	public void setBhcOrderReceivedStartDate(String bhcOrderReceivedStartDate) {
		this.bhcOrderReceivedStartDate = bhcOrderReceivedStartDate;
	}

	public String getBhcOrderReceivedEndDate() {
		return bhcOrderReceivedEndDate;
	}

	public void setBhcOrderReceivedEndDate(String bhcOrderReceivedEndDate) {
		this.bhcOrderReceivedEndDate = bhcOrderReceivedEndDate;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getBhcOrderSource() {
		return bhcOrderSource;
	}

	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}

	public String getLastUpdatedStartDate() {
		return lastTeamUpdatedStartDate;
	}

	public void setLastUpdatedStartDate(String lastUpdatedStartDate) {
		this.lastTeamUpdatedStartDate = lastUpdatedStartDate;
	}

	public String getLastUpdatedEndDate() {
		return lastTeamUpdatedEndDate;
	}

	public void setLastUpdatedEndDate(String lastUpdatedEndDate) {
		this.lastTeamUpdatedEndDate = lastUpdatedEndDate;
	}

	public String getiHealConfiguration() {
		return iHealConfiguration;
	}

	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getBhcMedRecAddedStartDate() {
		return bhcMedRecAddedStartDate;
	}

	public void setBhcMedRecAddedStartDate(String bhcMedRecAddedStartDate) {
		this.bhcMedRecAddedStartDate = bhcMedRecAddedStartDate;
	}

	public String getBhcMedRecAddedEndDate() {
		return bhcMedRecAddedEndDate;
	}

	public void setBhcMedRecAddedEndDate(String bhcMedRecAddedEndDate) {
		this.bhcMedRecAddedEndDate = bhcMedRecAddedEndDate;
	}

	@Override
	public String toString() {
		return "DashboardReq [serviceLine=" + serviceLine + ", index=" + index
				+ ", taskType=" + taskType + ", username=" + username
				+ ", userId=" + userId + ", order=" + order + ", sortBy="
				+ sortBy + ", filterOptions=" + filterOptions + ", filters="
				+ filters + ", customDates=" + customDates + ", dateFilters="
				+ dateFilters + ", isDataEmpty=" + isDataEmpty
				+ ", todayMinDate=" + todayMinDate + ", todayMaxDate="
				+ todayMaxDate + ", yesterdayMinDate=" + yesterdayMinDate
				+ ", yesterdayMaxDate=" + yesterdayMaxDate
				+ ", thisWeekMinDate=" + thisWeekMinDate + ", thisWeekMaxDate="
				+ thisWeekMaxDate + ", lastWeekMinDate=" + lastWeekMinDate
				+ ", lastWeekMaxDate=" + lastWeekMaxDate + ", offsetMinutes="
				+ offsetMinutes + ", bhcReferralId=" + bhcReferralId + ", bbc="
				+ bbc + ", bhcMedRecId=" + bhcMedRecId + ", vendor=" + vendor
				+ ", bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", bhcOrderReceivedStartDate=" + bhcOrderReceivedStartDate
				+ ", bhcOrderReceivedEndDate=" + bhcOrderReceivedEndDate
				+ ", firstReceivedStartDate=" + firstReceivedStartDate
				+ ", firstReceivedEndDate=" + firstReceivedEndDate
				+ ", followupStartDate=" + followupStartDate
				+ ", followupEndDate=" + followupEndDate + ", patientName="
				+ patientName + ", age=" + age + ", assignedTo=" + assignedTo
				+ ", bhcOrderSource=" + bhcOrderSource
				+ ", lastTeamUpdatedStartDate=" + lastTeamUpdatedStartDate
				+ ", lastTeamUpdatedEndDate=" + lastTeamUpdatedEndDate
				+ ", iHealConfiguration=" + iHealConfiguration + ", status="
				+ status + ", bhcMedRecAddedStartDate="
				+ bhcMedRecAddedStartDate + ", bhcMedRecAddedEndDate="
				+ bhcMedRecAddedEndDate + ", bhcDocStatus=" + bhcDocStatus
				+ ", insuranceType=" + insuranceType + ", bhcMissingDocNotes="
				+ bhcMissingDocNotes + ", patientDOB=" + patientDOB
				+ ", providerName=" + providerName + ", bhcPatientAcctId="
				+ bhcPatientAcctId + ", bhcShipStartDate=" + bhcShipStartDate
				+ ", bhcShipEndDate=" + bhcShipEndDate
				+ ", bhcLastUpdateStartDate=" + bhcLastUpdateStartDate
				+ ", bhcLastUpdateEndDate=" + bhcLastUpdateEndDate
				+ ", excelColumns=" + excelColumns + ", batchAssigneeUserId="
				+ batchAssigneeUserId + ", batchAssigneeUserName="
				+ batchAssigneeUserName + ", batchAssigneeFullName="
				+ batchAssigneeFullName + ", batchAssigneeChanged="
				+ batchAssigneeChanged + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", lastUpdatedUserFullName="
				+ lastUpdatedUserFullName + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", caseId=" + caseId
				+ ", retrieveStatus=" + retrieveStatus + ", currentStatus="
				+ currentStatus + ", primaryInsCompany=" + primaryInsCompany
				+ "]";
	}

}
