package com.healogics.rtrv.dto;

public class DocumentUploadStatusRes {

	private String responseCode;
	private String responseMessage;
	private String docUploadStatus;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getDocUploadStatus() {
		return docUploadStatus;
	}
	public void setDocUploadStatus(String docUploadStatus) {
		this.docUploadStatus = docUploadStatus;
	}
	@Override
	public String toString() {
		return "DocumentUploadStatusRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", docUploadStatus="
				+ docUploadStatus + "]";
	}

}
