package com.healogics.rtrv.dto;

import java.util.Date;
import java.util.List;

public class FilterOptions {

	private Date minLastTeamUpdatedDate;
	private Date maxLastTeamUpdatedDate;
	private Date minFirstReceivedDate;
	private Date maxFirstReceivedDate;
	private Date minFollowupDate;
	private Date maxFollowupDate;
	private Date minBhcShipDate;
	private Date maxBhcShipDate;
	private Date minBhcLastUpdateDate;
	private Date maxBhclastUpdateDate;

	private List<String> options;

	public Date getMinBhcLastUpdateDate() {
		return minBhcLastUpdateDate;
	}

	public void setMinBhcLastUpdateDate(Date minBhcLastUpdateDate) {
		this.minBhcLastUpdateDate = minBhcLastUpdateDate;
	}

	public Date getMaxBhclastUpdateDate() {
		return maxBhclastUpdateDate;
	}

	public void setMaxBhclastUpdateDate(Date maxBhclastUpdateDate) {
		this.maxBhclastUpdateDate = maxBhclastUpdateDate;
	}

	public Date getMinBhcShipDate() {
		return minBhcShipDate;
	}

	public void setMinBhcShipDate(Date minBhcShipDate) {
		this.minBhcShipDate = minBhcShipDate;
	}

	public Date getMaxBhcShipDate() {
		return maxBhcShipDate;
	}

	public void setMaxBhcShipDate(Date maxBhcShipDate) {
		this.maxBhcShipDate = maxBhcShipDate;
	}

	public Date getMinFirstReceivedDate() {
		return minFirstReceivedDate;
	}

	public void setMinFirstReceivedDate(Date minFirstReceivedDate) {
		this.minFirstReceivedDate = minFirstReceivedDate;
	}

	public Date getMaxFirstReceivedDate() {
		return maxFirstReceivedDate;
	}

	public void setMaxFirstReceivedDate(Date maxFirstReceivedDate) {
		this.maxFirstReceivedDate = maxFirstReceivedDate;
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}

	public Date getMinLastTeamUpdatedDate() {
		return minLastTeamUpdatedDate;
	}

	public void setMinLastTeamUpdatedDate(Date minLastTeamUpdatedDate) {
		this.minLastTeamUpdatedDate = minLastTeamUpdatedDate;
	}

	public Date getMaxLastTeamUpdatedDate() {
		return maxLastTeamUpdatedDate;
	}

	public void setMaxLastTeamUpdatedDate(Date maxLastTeamUpdatedDate) {
		this.maxLastTeamUpdatedDate = maxLastTeamUpdatedDate;
	}

	public Date getMinFollowupDate() {
		return minFollowupDate;
	}

	public void setMinFollowupDate(Date minFollowupDate) {
		this.minFollowupDate = minFollowupDate;
	}

	public Date getMaxFollowupDate() {
		return maxFollowupDate;
	}

	public void setMaxFollowupDate(Date maxFollowupDate) {
		this.maxFollowupDate = maxFollowupDate;
	}

	@Override
	public String toString() {
		return "FilterOptions [minLastTeamUpdatedDate=" + minLastTeamUpdatedDate
				+ ", maxLastTeamUpdatedDate=" + maxLastTeamUpdatedDate
				+ ", minFirstReceivedDate=" + minFirstReceivedDate
				+ ", maxFirstReceivedDate=" + maxFirstReceivedDate
				+ ", minFollowupDate=" + minFollowupDate + ", maxFollowupDate="
				+ maxFollowupDate + ", minBhcShipDate=" + minBhcShipDate
				+ ", maxBhcShipDate=" + maxBhcShipDate
				+ ", minBhcLastUpdateDate=" + minBhcLastUpdateDate
				+ ", maxBhclastUpdateDate=" + maxBhclastUpdateDate
				+ ", options=" + options + "]";
	}

}
