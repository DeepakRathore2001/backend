package com.healogics.rtrv.dto;

public class TertiaryInsuranceMaster {

	private String tertiaryInsName;
	private String tertiaryInsPolicyNo;
	private String tertiaryInsCompany;
	private String tertiaryInsMac;
	private String tertiaryInsDeductible;
	private String tertiaryInsDeducMet;
	private String tertiaryInsCopay;
	private String tertiaryInsCoinsurance;
	private String tertiaryInsOOPMax;
	private String tertiaryInsOOPMet;
	private String tertiaryInsStatus;
	private String tertiaryInsPercentCovered;
	private String tertiaryInsReasonNotCovered;
	private String tertiaryInsReasonNA;
	public String getTertiaryInsName() {
		return tertiaryInsName;
	}
	public void setTertiaryInsName(String tertiaryInsName) {
		this.tertiaryInsName = tertiaryInsName;
	}
	public String getTertiaryInsPolicyNo() {
		return tertiaryInsPolicyNo;
	}
	public void setTertiaryInsPolicyNo(String tertiaryInsPolicyNo) {
		this.tertiaryInsPolicyNo = tertiaryInsPolicyNo;
	}
	public String getTertiaryInsCompany() {
		return tertiaryInsCompany;
	}
	public void setTertiaryInsCompany(String tertiaryInsCompany) {
		this.tertiaryInsCompany = tertiaryInsCompany;
	}
	public String getTertiaryInsMac() {
		return tertiaryInsMac;
	}
	public void setTertiaryInsMac(String tertiaryInsMac) {
		this.tertiaryInsMac = tertiaryInsMac;
	}
	public String getTertiaryInsDeductible() {
		return tertiaryInsDeductible;
	}
	public void setTertiaryInsDeductible(String tertiaryInsDeductible) {
		this.tertiaryInsDeductible = tertiaryInsDeductible;
	}
	public String getTertiaryInsDeducMet() {
		return tertiaryInsDeducMet;
	}
	public void setTertiaryInsDeducMet(String tertiaryInsDeducMet) {
		this.tertiaryInsDeducMet = tertiaryInsDeducMet;
	}
	public String getTertiaryInsCopay() {
		return tertiaryInsCopay;
	}
	public void setTertiaryInsCopay(String tertiaryInsCopay) {
		this.tertiaryInsCopay = tertiaryInsCopay;
	}
	public String getTertiaryInsCoinsurance() {
		return tertiaryInsCoinsurance;
	}
	public void setTertiaryInsCoinsurance(String tertiaryInsCoinsurance) {
		this.tertiaryInsCoinsurance = tertiaryInsCoinsurance;
	}
	public String getTertiaryInsOOPMax() {
		return tertiaryInsOOPMax;
	}
	public void setTertiaryInsOOPMax(String tertiaryInsOOPMax) {
		this.tertiaryInsOOPMax = tertiaryInsOOPMax;
	}
	public String getTertiaryInsOOPMet() {
		return tertiaryInsOOPMet;
	}
	public void setTertiaryInsOOPMet(String tertiaryInsOOPMet) {
		this.tertiaryInsOOPMet = tertiaryInsOOPMet;
	}
	public String getTertiaryInsStatus() {
		return tertiaryInsStatus;
	}
	public void setTertiaryInsStatus(String tertiaryInsStatus) {
		this.tertiaryInsStatus = tertiaryInsStatus;
	}
	public String getTertiaryInsPercentCovered() {
		return tertiaryInsPercentCovered;
	}
	public void setTertiaryInsPercentCovered(String tertiaryInsPercentCovered) {
		this.tertiaryInsPercentCovered = tertiaryInsPercentCovered;
	}
	public String getTertiaryInsReasonNotCovered() {
		return tertiaryInsReasonNotCovered;
	}
	public void setTertiaryInsReasonNotCovered(
			String tertiaryInsReasonNotCovered) {
		this.tertiaryInsReasonNotCovered = tertiaryInsReasonNotCovered;
	}
	public String getTertiaryInsReasonNA() {
		return tertiaryInsReasonNA;
	}
	public void setTertiaryInsReasonNA(String tertiaryInsReasonNA) {
		this.tertiaryInsReasonNA = tertiaryInsReasonNA;
	}
	@Override
	public String toString() {
		return "TertiaryInsuranceMaster [tertiaryInsName=" + tertiaryInsName
				+ ", tertiaryInsPolicyNo=" + tertiaryInsPolicyNo
				+ ", tertiaryInsCompany=" + tertiaryInsCompany
				+ ", tertiaryInsMac=" + tertiaryInsMac
				+ ", tertiaryInsDeductible=" + tertiaryInsDeductible
				+ ", tertiaryInsDeducMet=" + tertiaryInsDeducMet
				+ ", tertiaryInsCopay=" + tertiaryInsCopay
				+ ", tertiaryInsCoinsurance=" + tertiaryInsCoinsurance
				+ ", tertiaryInsOOPMax=" + tertiaryInsOOPMax
				+ ", tertiaryInsOOPMet=" + tertiaryInsOOPMet
				+ ", tertiaryInsStatus=" + tertiaryInsStatus
				+ ", tertiaryInsPercentCovered=" + tertiaryInsPercentCovered
				+ ", tertiaryInsReasonNotCovered=" + tertiaryInsReasonNotCovered
				+ ", tertiaryInsReasonNA=" + tertiaryInsReasonNA + "]";
	}

}
