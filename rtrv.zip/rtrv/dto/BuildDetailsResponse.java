package com.healogics.rtrv.dto;

public class BuildDetailsResponse {
	private String responseCode;
	private String responseDesc;

	private Build ui;
	private Build api;

	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public Build getUi() {
		return ui;
	}
	public void setUi(Build ui) {
		this.ui = ui;
	}
	public Build getApi() {
		return api;
	}
	public void setApi(Build api) {
		this.api = api;
	}
	@Override
	public String toString() {
		return "BuildDetails [responseCode=" + responseCode + ", responseDesc="
				+ responseDesc + ", ui=" + ui + ", api=" + api + "]";
	}
}
