package com.healogics.rtrv.dto;

import java.util.List;

public class AdminDashboardFilterOptionsRes {

	private String responseCode;
	private String responseDesc;
	private List<String> options;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public List<String> getOptions() {
		return options;
	}
	public void setOptions(List<String> options) {
		this.options = options;
	}
	@Override
	public String toString() {
		return "AdminDashboardFilterOptionsRes [responseCode=" + responseCode
				+ ", responseDesc=" + responseDesc + ", options=" + options
				+ "]";
	}

}
