package com.healogics.rtrv.dto;

public class PlainTextObj {
	private String documentId;
	private String facilityId;

	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	@Override
	public String toString() {
		return "PlainTextObj [documentId=" + documentId + ", facilityId=" + facilityId + "]";
	}
}
