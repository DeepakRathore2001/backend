package com.healogics.rtrv.dto;

import java.util.List;
import java.util.Map;

public class ManualAttachmentRes {

	private Map<String, List<AttachmentDetails>> documentsList;

	private String responseCode;
	private String responseMessage;
	public Map<String, List<AttachmentDetails>> getDocumentsList() {
		return documentsList;
	}
	public void setDocumentsList(
			Map<String, List<AttachmentDetails>> documentsList) {
		this.documentsList = documentsList;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "ManualAttachmentRes [documentsList=" + documentsList
				+ ", responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + "]";
	}

}
