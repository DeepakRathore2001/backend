package com.healogics.rtrv.dto;

import java.util.List;

public class AttemptCategory {
	private String category;
	private List<String> types;
	private List<String> contacts;
	private List<String> vendorContact;

	public List<String> getVendorContact() {
		return vendorContact;
	}

	public void setVendorContact(List<String> vendorContact) {
		this.vendorContact = vendorContact;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

	public List<String> getContacts() {
		return contacts;
	}

	public void setContacts(List<String> contacts) {
		this.contacts = contacts;
	}

	@Override
	public String toString() {
		return "AttemptCategory [category=" + category + ", types=" + types + ", contacts=" + contacts
				+ ", vendorContact=" + vendorContact + "]";
	}
}
