package com.healogics.rtrv.dto;

public class DocumentNotificationReq {
	private int facilityId;
	private int patientId;
	private int visitId;
	private String pdfFileName;
	private String clientState;

	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getPdfFileName() {
		return pdfFileName;
	}
	public void setPdfFileName(String pdfFileName) {
		this.pdfFileName = pdfFileName;
	}
	public String getClientState() {
		return clientState;
	}
	public void setClientState(String clientState) {
		this.clientState = clientState;
	}
	@Override
	public String toString() {
		return "DocumentNotificationReq [facilityId=" + facilityId + ", patientId=" + patientId + ", visitId=" + visitId
				+ ", pdfFileName=" + pdfFileName + ", clientState=" + clientState + "]";
	}
}
