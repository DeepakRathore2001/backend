package com.healogics.rtrv.dto;

public class PrimaryInsuranceMaster {

	private String primaryInsName;
	private String primaryInsPolicyNo;
	private String primaryInsCompany;
	private String primaryInsMac;
	private String primaryInsDeductible;
	private String primaryInsDeducMet;
	private String primaryInsCopay;
	private String primaryInsCoinsurance;
	private String primaryInsOOPMax;
	private String primaryInsOOPMet;
	private String primaryInsStatus;
	private String primaryInsPercentCovered;
	private String primaryInsReasonNotCovered;
	private String primaryInsReasonNA;
	
	public String getPrimaryInsName() {
		return primaryInsName;
	}
	public void setPrimaryInsName(String primaryInsName) {
		this.primaryInsName = primaryInsName;
	}
	public String getPrimaryInsPolicyNo() {
		return primaryInsPolicyNo;
	}
	public void setPrimaryInsPolicyNo(String primaryInsPolicyNo) {
		this.primaryInsPolicyNo = primaryInsPolicyNo;
	}
	public String getPrimaryInsCompany() {
		return primaryInsCompany;
	}
	public void setPrimaryInsCompany(String primaryInsCompany) {
		this.primaryInsCompany = primaryInsCompany;
	}
	public String getPrimaryInsMac() {
		return primaryInsMac;
	}
	public void setPrimaryInsMac(String primaryInsMac) {
		this.primaryInsMac = primaryInsMac;
	}
	public String getPrimaryInsDeductible() {
		return primaryInsDeductible;
	}
	public void setPrimaryInsDeductible(String primaryInsDeductible) {
		this.primaryInsDeductible = primaryInsDeductible;
	}
	public String getPrimaryInsDeducMet() {
		return primaryInsDeducMet;
	}
	public void setPrimaryInsDeducMet(String primaryInsDeducMet) {
		this.primaryInsDeducMet = primaryInsDeducMet;
	}
	public String getPrimaryInsCopay() {
		return primaryInsCopay;
	}
	public void setPrimaryInsCopay(String primaryInsCopay) {
		this.primaryInsCopay = primaryInsCopay;
	}
	public String getPrimaryInsCoinsurance() {
		return primaryInsCoinsurance;
	}
	public void setPrimaryInsCoinsurance(String primaryInsCoinsurance) {
		this.primaryInsCoinsurance = primaryInsCoinsurance;
	}
	public String getPrimaryInsOOPMax() {
		return primaryInsOOPMax;
	}
	public void setPrimaryInsOOPMax(String primaryInsOOPMax) {
		this.primaryInsOOPMax = primaryInsOOPMax;
	}
	public String getPrimaryInsOOPMet() {
		return primaryInsOOPMet;
	}
	public void setPrimaryInsOOPMet(String primaryInsOOPMet) {
		this.primaryInsOOPMet = primaryInsOOPMet;
	}
	public String getPrimaryInsStatus() {
		return primaryInsStatus;
	}
	public void setPrimaryInsStatus(String primaryInsStatus) {
		this.primaryInsStatus = primaryInsStatus;
	}
	public String getPrimaryInsPercentCovered() {
		return primaryInsPercentCovered;
	}
	public void setPrimaryInsPercentCovered(String primaryInsPercentCovered) {
		this.primaryInsPercentCovered = primaryInsPercentCovered;
	}
	public String getPrimaryInsReasonNotCovered() {
		return primaryInsReasonNotCovered;
	}
	public void setPrimaryInsReasonNotCovered(
			String primaryInsReasonNotCovered) {
		this.primaryInsReasonNotCovered = primaryInsReasonNotCovered;
	}
	public String getPrimaryInsReasonNA() {
		return primaryInsReasonNA;
	}
	public void setPrimaryInsReasonNA(String primaryInsReasonNA) {
		this.primaryInsReasonNA = primaryInsReasonNA;
	}
	@Override
	public String toString() {
		return "PrimaryInsuranceMaster [primaryInsName=" + primaryInsName
				+ ", primaryInsPolicyNo=" + primaryInsPolicyNo
				+ ", primaryInsCompany=" + primaryInsCompany
				+ ", primaryInsMac=" + primaryInsMac + ", primaryInsDeductible="
				+ primaryInsDeductible + ", primaryInsDeducMet="
				+ primaryInsDeducMet + ", primaryInsCopay=" + primaryInsCopay
				+ ", primaryInsCoinsurance=" + primaryInsCoinsurance
				+ ", primaryInsOOPMax=" + primaryInsOOPMax
				+ ", primaryInsOOPMet=" + primaryInsOOPMet
				+ ", primaryInsStatus=" + primaryInsStatus
				+ ", primaryInsPercentCovered=" + primaryInsPercentCovered
				+ ", primaryInsReasonNotCovered=" + primaryInsReasonNotCovered
				+ ", primaryInsReasonNA=" + primaryInsReasonNA + "]";
	}

}
