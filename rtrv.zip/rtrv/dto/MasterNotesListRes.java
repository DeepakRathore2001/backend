package com.healogics.rtrv.dto;

import java.util.List;

import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;

public class MasterNotesListRes extends RTRVAPIResponse {
	private int currentIndex;
	private int nextIndex;
	private double totalPage;
	private Long totalCount;
	private boolean isExhausted;
	private List<MasterNotesDetails> notes;

	public int getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	public int getNextIndex() {
		return nextIndex;
	}
	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}
	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	public List<MasterNotesDetails> getNotes() {
		return notes;
	}
	public void setNotes(List<MasterNotesDetails> notes) {
		this.notes = notes;
	}
	
	
}
