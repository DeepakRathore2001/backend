package com.healogics.rtrv.dto;

public class HistoryUserNotes {
	private String description;
	private String missingElements;
	private String statusChangeNotes;

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMissingElements() {
		return missingElements;
	}
	public void setMissingElements(String missingElements) {
		this.missingElements = missingElements;
	}
	public String getStatusChangeNotes() {
		return statusChangeNotes;
	}
	public void setStatusChangeNotes(String statusChangeNotes) {
		this.statusChangeNotes = statusChangeNotes;
	}
	@Override
	public String toString() {
		return "HistoryUserNotes [description=" + description + ", missingElements=" + missingElements
				+ ", statusChangeNotes=" + statusChangeNotes + "]";
	}
	
	
}
