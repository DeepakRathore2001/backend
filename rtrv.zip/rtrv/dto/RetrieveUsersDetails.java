package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.List;

public class RetrieveUsersDetails {

	private Long userId;
	private String username;
	private String emailId;
	private Timestamp last_logged_in_timestamp;
	private String userFullName;
	private String retrieveRole;
	private List<String> businessRole;
	private Boolean isSuperUser;

	public Boolean getIsSuperUser() {
		return isSuperUser;
	}
	public void setIsSuperUser(Boolean isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public List<String> getBusinessRole() {
		return businessRole;
	}
	public void setBusinessRole(List<String> businessRole) {
		this.businessRole = businessRole;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Timestamp getLast_logged_in_timestamp() {
		return last_logged_in_timestamp;
	}
	public void setLast_logged_in_timestamp(
			Timestamp last_logged_in_timestamp) {
		this.last_logged_in_timestamp = last_logged_in_timestamp;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public String getRetrieveRole() {
		return retrieveRole;
	}
	public void setRetrieveRole(String retrieveRole) {
		this.retrieveRole = retrieveRole;
	}
	@Override
	public String toString() {
		return "RetrieveUsersDetails [userId=" + userId + ", username="
				+ username + ", emailId=" + emailId
				+ ", last_logged_in_timestamp=" + last_logged_in_timestamp
				+ ", userFullName=" + userFullName + ", retrieveRole="
				+ retrieveRole + ", businessRole=" + businessRole
				+ ", isSuperUser=" + isSuperUser + "]";
	}

}
