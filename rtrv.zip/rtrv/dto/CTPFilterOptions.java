package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class CTPFilterOptions {

	private Date minLastTeamUpdatedDate;
	private Date maxLastTeamUpdatedDate;
	private Timestamp minFirstReceivedDate;
	private Timestamp maxFirstReceivedDate;
	private Date minFollowupDate;
	private Date maxFollowupDate;

	private List<String> options;

	// AdditionalNPWT
	private Date minReceivedDate;
	private Date maxReceivedDate;
	private Date minResponseDate;
	private Date maxResponseDate;
	private Date minVendorOrderDate;
	private Date maxVendorOrderDate;

	public Date getMinReceivedDate() {
		return minReceivedDate;
	}

	public void setMinReceivedDate(Date minReceivedDate) {
		this.minReceivedDate = minReceivedDate;
	}

	public Date getMaxReceivedDate() {
		return maxReceivedDate;
	}

	public void setMaxReceivedDate(Date maxReceivedDate) {
		this.maxReceivedDate = maxReceivedDate;
	}

	public Date getMinResponseDate() {
		return minResponseDate;
	}

	public void setMinResponseDate(Date minResponseDate) {
		this.minResponseDate = minResponseDate;
	}

	public Date getMaxResponseDate() {
		return maxResponseDate;
	}

	public void setMaxResponseDate(Date maxResponseDate) {
		this.maxResponseDate = maxResponseDate;
	}

	public Date getMinVendorOrderDate() {
		return minVendorOrderDate;
	}

	public void setMinVendorOrderDate(Date minVendorOrderDate) {
		this.minVendorOrderDate = minVendorOrderDate;
	}

	public Date getMaxVendorOrderDate() {
		return maxVendorOrderDate;
	}

	public void setMaxVendorOrderDate(Date maxVendorOrderDate) {
		this.maxVendorOrderDate = maxVendorOrderDate;
	}

	public Date getMinLastTeamUpdatedDate() {
		return minLastTeamUpdatedDate;
	}

	public void setMinLastTeamUpdatedDate(Date minLastTeamUpdatedDate) {
		this.minLastTeamUpdatedDate = minLastTeamUpdatedDate;
	}

	public Date getMaxLastTeamUpdatedDate() {
		return maxLastTeamUpdatedDate;
	}

	public void setMaxLastTeamUpdatedDate(Date maxLastTeamUpdatedDate) {
		this.maxLastTeamUpdatedDate = maxLastTeamUpdatedDate;
	}

	public Timestamp getMinFirstReceivedDate() {
		return minFirstReceivedDate;
	}

	public void setMinFirstReceivedDate(Timestamp minFirstReceivedDate) {
		this.minFirstReceivedDate = minFirstReceivedDate;
	}

	public Timestamp getMaxFirstReceivedDate() {
		return maxFirstReceivedDate;
	}

	public void setMaxFirstReceivedDate(Timestamp maxFirstReceivedDate) {
		this.maxFirstReceivedDate = maxFirstReceivedDate;
	}

	public Date getMinFollowupDate() {
		return minFollowupDate;
	}

	public void setMinFollowupDate(Date minFollowupDate) {
		this.minFollowupDate = minFollowupDate;
	}

	public Date getMaxFollowupDate() {
		return maxFollowupDate;
	}

	public void setMaxFollowupDate(Date maxFollowupDate) {
		this.maxFollowupDate = maxFollowupDate;
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}

	@Override
	public String toString() {
		return "CTPFilterOptions [minLastTeamUpdatedDate="
				+ minLastTeamUpdatedDate + ", maxLastTeamUpdatedDate="
				+ maxLastTeamUpdatedDate + ", minFirstReceivedDate="
				+ minFirstReceivedDate + ", maxFirstReceivedDate="
				+ maxFirstReceivedDate + ", minFollowupDate=" + minFollowupDate
				+ ", maxFollowupDate=" + maxFollowupDate + ", options="
				+ options + ", minReceivedDate=" + minReceivedDate
				+ ", maxReceivedDate=" + maxReceivedDate + ", minResponseDate="
				+ minResponseDate + ", maxResponseDate=" + maxResponseDate
				+ ", minVendorOrderDate=" + minVendorOrderDate
				+ ", maxVendorOrderDate=" + maxVendorOrderDate + "]";
	}

}
