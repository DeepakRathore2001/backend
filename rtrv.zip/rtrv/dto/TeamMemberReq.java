package com.healogics.rtrv.dto;

public class TeamMemberReq {
	private String serviceLine;

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	@Override
	public String toString() {
		return "TeamMemberReq [serviceLine=" + serviceLine + "]";
	}
}
