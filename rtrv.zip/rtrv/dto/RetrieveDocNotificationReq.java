package com.healogics.rtrv.dto;

public class RetrieveDocNotificationReq {
	private String vendorRequestId;
	private String documentType;
	private String documentAvailable;
	private String documentToken;
	private String documentRequestId;

	public String getVendorRequestId() {
		return vendorRequestId;
	}
	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentAvailable() {
		return documentAvailable;
	}
	public void setDocumentAvailable(String documentAvailable) {
		this.documentAvailable = documentAvailable;
	}
	public String getDocumentToken() {
		return documentToken;
	}
	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}
	public String getDocumentRequestId() {
		return documentRequestId;
	}
	public void setDocumentRequestId(String documentRequestId) {
		this.documentRequestId = documentRequestId;
	}
	@Override
	public String toString() {
		return "KerecisDocNotificationReq [vendorRequestId=" + vendorRequestId + ", documentType=" + documentType
				+ ", documentAvailable=" + documentAvailable + ", documentToken=" + documentToken
				+ ", documentRequestId=" + documentRequestId + "]";
	}
}
