package com.healogics.rtrv.dto;

import java.util.List;

public class VendorStatus {
	private String currentStatus;
	private String secondaryStatus;
	private String coverageSummary;
	private String statusDetail;
	private List<String> requestedDocs;
	
	public String getStatusDetail() {
		return statusDetail;
	}
	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}
	public List<String> getRequestedDocs() {
		return requestedDocs;
	}
	public void setRequestedDocs(List<String> requestedDocs) {
		this.requestedDocs = requestedDocs;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getSecondaryStatus() {
		return secondaryStatus;
	}
	public void setSecondaryStatus(String secondaryStatus) {
		this.secondaryStatus = secondaryStatus;
	}
	public String getCoverageSummary() {
		return coverageSummary;
	}
	public void setCoverageSummary(String coverageSummary) {
		this.coverageSummary = coverageSummary;
	}
	@Override
	public String toString() {
		return "VendorStatus [currentStatus=" + currentStatus + ", secondaryStatus=" + secondaryStatus
				+ ", coverageSummary=" + coverageSummary + ", statusDetail=" + statusDetail + ", requestedDocs="
				+ requestedDocs + "]";
	}
	
	
}
