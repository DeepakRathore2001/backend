package com.healogics.rtrv.dto;

public class UserFacilityListGetReq {
	private String userId;
	private String masterToken;
	private String privateKey;
	private String facilitySettings;

	public String getFacilitySettings() {
		return facilitySettings;
	}
	public void setFacilitySettings(String facilitySettings) {
		this.facilitySettings = facilitySettings;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	@Override
	public String toString() {
		return "UserFacilityListGetReq [userId=" + userId + ", masterToken="
				+ masterToken + ", privateKey=" + privateKey
				+ ", facilitySettings=" + facilitySettings + "]";
	}

}
