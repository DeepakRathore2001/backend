package com.healogics.rtrv.dto;

public class TestResultsResult {

	private String orderDate;
	private String groupName;
	private String testDescription;
	private String fileId;
	private IHealDocumentObj document;
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getTestDescription() {
		return testDescription;
	}
	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public IHealDocumentObj getDocument() {
		return document;
	}
	public void setDocument(IHealDocumentObj document) {
		this.document = document;
	}
	@Override
	public String toString() {
		return "TestResultsResult [orderDate=" + orderDate + ", groupName="
				+ groupName + ", testDescription=" + testDescription
				+ ", fileId=" + fileId + ", document=" + document + "]";
	}
	
}
