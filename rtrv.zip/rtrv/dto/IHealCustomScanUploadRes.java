package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;

public class IHealCustomScanUploadRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private IHealCustomScanObj scan;
	private String errorCode;
	private String errorMessage;
	private String responseCode;
	private String responseMessage;
	private List<IHealErrorDetails> errors;
	private List<IHealErrorDetails> warnings;
	public IHealCustomScanObj getScan() {
		return scan;
	}
	public void setScan(IHealCustomScanObj scan) {
		this.scan = scan;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<IHealErrorDetails> getErrors() {
		return errors;
	}
	public void setErrors(List<IHealErrorDetails> errors) {
		this.errors = errors;
	}
	public List<IHealErrorDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<IHealErrorDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealCustomScanUploadRes [scan=" + scan + ", errorCode="
				+ errorCode + ", errorMessage=" + errorMessage
				+ ", responseCode=" + responseCode + ", responseMessage="
				+ responseMessage + ", errors=" + errors + ", warnings="
				+ warnings + "]";
	}

}
