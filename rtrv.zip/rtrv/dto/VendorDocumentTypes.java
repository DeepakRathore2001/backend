package com.healogics.rtrv.dto;

import java.util.List;

public class VendorDocumentTypes {
	private List<String> documents;

	public List<String> getDocuments() {
		return documents;
	}

	public void setDocuments(List<String> documents) {
		this.documents = documents;
	}

	@Override
	public String toString() {
		return "VendorDocumentTypes [documents=" + documents + "]";
	}
}
