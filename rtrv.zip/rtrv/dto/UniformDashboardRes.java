package com.healogics.rtrv.dto;

import java.util.List;

public class UniformDashboardRes {

	private int nextIndex;
	private int currentIndex;
	private Long totalCount;
	private double totalPage;
	private boolean isExhausted;
	private String responseCode;
	private String responseMessage;
	private List<UniformData> records;

	public int getNextIndex() {
		return nextIndex;
	}
	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}
	public int getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<UniformData> getRecords() {
		return records;
	}
	public void setRecords(List<UniformData> records) {
		this.records = records;
	}
	@Override
	public String toString() {
		return "UniformDashboardRes [nextIndex=" + nextIndex + ", currentIndex="
				+ currentIndex + ", totalCount=" + totalCount + ", totalPage="
				+ totalPage + ", isExhausted=" + isExhausted + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage
				+ ", records=" + records + "]";
	}

}
