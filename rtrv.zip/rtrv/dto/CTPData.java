package com.healogics.rtrv.dto;

import java.sql.Timestamp;

import java.util.Date;

public class CTPData {

	private String bbc;
	private String orderId;
	private String orderSource;
	private Date receivedDate;
	private Timestamp firstReceived;
	private Date followupDate;
	private String patientFirstName;
	private String patientLastName;
	private String patientName;
	private String assignedTo;
	private String retrieveStatus;
	private Timestamp statusUpdatedDateTime;
	private String currentStatus;
	private String vendor;
	private String age;
	private Timestamp lastTeamUpdated;
	private String lastTeamUpdatedUserFullName;
	private String iHealConfiguration;
	private String primaryInsuranceCompany;
	private Date patientDOB;

	public Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Timestamp getStatusUpdatedDateTime() {
		return statusUpdatedDateTime;
	}
	public void setStatusUpdatedDateTime(Timestamp statusUpdatedDateTime) {
		this.statusUpdatedDateTime = statusUpdatedDateTime;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public Timestamp getFirstReceived() {
		return firstReceived;
	}
	public void setFirstReceived(Timestamp firstReceived) {
		this.firstReceived = firstReceived;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}
	public Date getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Timestamp getLastTeamUpdated() {
		return lastTeamUpdated;
	}
	public void setLastTeamUpdated(Timestamp lastTeamUpdated) {
		this.lastTeamUpdated = lastTeamUpdated;
	}
	public String getLastTeamUpdatedUserFullName() {
		return lastTeamUpdatedUserFullName;
	}
	public void setLastTeamUpdatedUserFullName(
			String lastTeamUpdatedUserFullName) {
		this.lastTeamUpdatedUserFullName = lastTeamUpdatedUserFullName;
	}
	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}

	public String getPrimaryInsuranceCompany() {
		return primaryInsuranceCompany;
	}
	public void setPrimaryInsuranceCompany(String primaryInsuranceCompany) {
		this.primaryInsuranceCompany = primaryInsuranceCompany;
	}
	@Override
	public String toString() {
		return "CTPData [bbc=" + bbc + ", orderId=" + orderId + ", orderSource="
				+ orderSource + ", receivedDate=" + receivedDate
				+ ", firstReceived=" + firstReceived + ", followupDate="
				+ followupDate + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientName="
				+ patientName + ", assignedTo=" + assignedTo
				+ ", retrieveStatus=" + retrieveStatus
				+ ", statusUpdatedDateTime=" + statusUpdatedDateTime
				+ ", currentStatus=" + currentStatus + ", vendor=" + vendor
				+ ", age=" + age + ", lastTeamUpdated=" + lastTeamUpdated
				+ ", lastTeamUpdatedUserFullName=" + lastTeamUpdatedUserFullName
				+ ", iHealConfiguration=" + iHealConfiguration
				+ ", primaryInsuranceCompany=" + primaryInsuranceCompany
				+ ", patientDOB=" + patientDOB + "]";
	}

}
