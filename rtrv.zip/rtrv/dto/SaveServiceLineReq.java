package com.healogics.rtrv.dto;

public class SaveServiceLineReq {

	private Long userId;
	private String username;
	private String serviceLineCode;
	private String serviceLineDesc;
	private String awdDashboard;
	private String npwtDashboard;
	private String ctpDashboard;
	private String userFullname;
	private String createdBy;
	private String lastUpdatedBy;
	private Long facilityId;
	private String bluebookId;
	private String colorCodes;

	public String getColorCodes() {
		return colorCodes;
	}
	public void setColorCodes(String colorCodes) {
		this.colorCodes = colorCodes;
	}
	public String getServiceLineDesc() {
		return serviceLineDesc;
	}
	public void setServiceLineDesc(String serviceLineDesc) {
		this.serviceLineDesc = serviceLineDesc;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getServiceLineCode() {
		return serviceLineCode;
	}
	public void setServiceLineCode(String serviceLineCode) {
		this.serviceLineCode = serviceLineCode;
	}

	public String getAwdDashboard() {
		return awdDashboard;
	}
	public void setAwdDashboard(String awdDashboard) {
		this.awdDashboard = awdDashboard;
	}
	public String getNpwtDashboard() {
		return npwtDashboard;
	}
	public void setNpwtDashboard(String npwtDashboard) {
		this.npwtDashboard = npwtDashboard;
	}
	public String getCtpDashboard() {
		return ctpDashboard;
	}
	public void setCtpDashboard(String ctpDashboard) {
		this.ctpDashboard = ctpDashboard;
	}
	public String getUserFullname() {
		return userFullname;
	}
	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Long getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	@Override
	public String toString() {
		return "SaveServiceLineReq [userId=" + userId + ", username=" + username
				+ ", serviceLineCode=" + serviceLineCode + ", serviceLineDesc="
				+ serviceLineDesc + ", awdDashboard=" + awdDashboard
				+ ", npwtDashboard=" + npwtDashboard + ", ctpDashboard="
				+ ctpDashboard + ", userFullname=" + userFullname
				+ ", createdBy=" + createdBy + ", lastUpdatedBy="
				+ lastUpdatedBy + ", facilityId=" + facilityId + ", bluebookId="
				+ bluebookId + ", colorCodes=" + colorCodes + "]";
	}

}
