package com.healogics.rtrv.dto;

public class OrderInfoUpdateReq {
	private String orderSource;
	private String orderToken;
	private Integer orderDisplayNumber;
	private Integer vendorId;
	
	private String retrieveStatus;
	private String userNotes;
	private String kerecisStatus;

	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	public String getOrderToken() {
		return orderToken;
	}
	public void setOrderToken(String orderToken) {
		this.orderToken = orderToken;
	}
	public Integer getOrderDisplayNumber() {
		return orderDisplayNumber;
	}
	public void setOrderDisplayNumber(Integer orderDisplayNumber) {
		this.orderDisplayNumber = orderDisplayNumber;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public String getUserNotes() {
		return userNotes;
	}
	public void setUserNotes(String userNotes) {
		this.userNotes = userNotes;
	}
	public String getKerecisStatus() {
		return kerecisStatus;
	}
	public void setKerecisStatus(String kerecisStatus) {
		this.kerecisStatus = kerecisStatus;
	}
	@Override
	public String toString() {
		return "OrderInfoUpdateReq [orderSource=" + orderSource + ", orderToken=" + orderToken + ", orderDisplayNumber="
				+ orderDisplayNumber + ", vendorId=" + vendorId + ", retrieveStatus=" + retrieveStatus + ", userNotes="
				+ userNotes + ", kerecisStatus=" + kerecisStatus + "]";
	}
}
