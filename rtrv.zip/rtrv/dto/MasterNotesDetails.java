package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.Date;

public class MasterNotesDetails {
	private String noteId;
	private String attemptCategory;
	private String attemptType;
	private Date followupDate;
	private String description;
	private String patientId;
	private String bluebookId;
	private String facilityId;
	private String patientFullname;
	private String lastUpdatedUsername;
	private String lastUpdatedUserId;
	private Timestamp lastUpdatedTimestamp;
	private String lastUpdatedUserFullname;
	private boolean deleteFlag;
	private String contactMethod;
	private String contact;
	
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getContactMethod() {
		return contactMethod;
	}
	public void setContactMethod(String contactMethod) {
		this.contactMethod = contactMethod;
	}
	public boolean isDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public String getAttemptCategory() {
		return attemptCategory;
	}
	public void setAttemptCategory(String attemptCategory) {
		this.attemptCategory = attemptCategory;
	}
	public String getAttemptType() {
		return attemptType;
	}
	public void setAttemptType(String attemptType) {
		this.attemptType = attemptType;
	}
	public Date getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientFullname() {
		return patientFullname;
	}
	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	@Override
	public String toString() {
		return "MasterNotesDetails [noteId=" + noteId + ", attemptCategory=" + attemptCategory + ", attemptType="
				+ attemptType + ", followupDate=" + followupDate + ", description=" + description + ", patientId="
				+ patientId + ", bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", patientFullname="
				+ patientFullname + ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", deleteFlag=" + deleteFlag + ", contactMethod=" + contactMethod
				+ ", contact=" + contact + "]";
	}
}
