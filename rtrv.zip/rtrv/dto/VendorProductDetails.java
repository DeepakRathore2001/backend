package com.healogics.rtrv.dto;

public class VendorProductDetails {
	private String hcpcCode;
	private String productName;

	public String getHcpcCode() {
		return hcpcCode;
	}

	public void setHcpcCode(String hcpcCode) {
		this.hcpcCode = hcpcCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Override
	public String toString() {
		return "VendorProductDetails [hcpcCode=" + hcpcCode + ", productName=" + productName + "]";
	}
}
