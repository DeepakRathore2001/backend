package com.healogics.rtrv.dto;

public class AWDFilterOptionsRes extends APIResponse {
	
	private AWDFilterOptions filterOptions;

	public AWDFilterOptions getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(AWDFilterOptions filterOptions) {
		this.filterOptions = filterOptions;
	}

	@Override
	public String toString() {
		return "AWDFilterOptionsRes [filterOptions=" + filterOptions + "]";
	}
	
	
	
	
	
}
