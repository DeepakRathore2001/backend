package com.healogics.rtrv.dto;

import java.sql.Timestamp;

public class StatusHistory {
	private int noteId;
	private String historyDocumentId;
	private Timestamp dateTimestamp;
	private String bhcMissingDocNotes;
	private String bhcMissingDocType;
	private String bhcDocStatus;
	private String retrieveStatus;
	private String lastUpdatedUserFullname;
	private String lastUpdatedUserId;
	private String userNotes;
	private String assignedTo;
	private int addendum;
	private int recordModify;

	public String getHistoryDocumentId() {
		return historyDocumentId;
	}
	public void setHistoryDocumentId(String historyDocumentId) {
		this.historyDocumentId = historyDocumentId;
	}
	public int getNoteId() {
		return noteId;
	}
	public void setNoteId(int noteId) {
		this.noteId = noteId;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getUserNotes() {
		return userNotes;
	}
	public void setUserNotes(String userNotes) {
		this.userNotes = userNotes;
	}
	public Timestamp getDateTimestamp() {
		return dateTimestamp;
	}
	public void setDateTimestamp(Timestamp dateTimestamp) {
		this.dateTimestamp = dateTimestamp;
	}
	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}
	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}
	public String getBhcMissingDocType() {
		return bhcMissingDocType;
	}
	public void setBhcMissingDocType(String bhcMissingDocType) {
		this.bhcMissingDocType = bhcMissingDocType;
	}
	public String getBhcDocStatus() {
		return bhcDocStatus;
	}
	public void setBhcDocStatus(String bhcDocStatus) {
		this.bhcDocStatus = bhcDocStatus;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public int getAddendum() {
		return addendum;
	}
	public void setAddendum(int addendum) {
		this.addendum = addendum;
	}
	public int getRecordModify() {
		return recordModify;
	}
	public void setRecordModify(int recordModify) {
		this.recordModify = recordModify;
	}
	@Override
	public String toString() {
		return "StatusHistory [noteId=" + noteId + ", historyDocumentId="
				+ historyDocumentId + ", dateTimestamp=" + dateTimestamp
				+ ", bhcMissingDocNotes=" + bhcMissingDocNotes
				+ ", bhcMissingDocType=" + bhcMissingDocType + ", bhcDocStatus="
				+ bhcDocStatus + ", retrieveStatus=" + retrieveStatus
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname
				+ ", lastUpdatedUserId=" + lastUpdatedUserId + ", userNotes="
				+ userNotes + ", assignedTo=" + assignedTo + ", addendum="
				+ addendum + ", recordModify=" + recordModify + "]";
	}
}
