package com.healogics.rtrv.dto;

import java.util.List;

public class IHealMedRecRes{

	private List<Reconciliations> reconciliations;

	private String errorCode;
	private String errorMessage;

	public List<Reconciliations> getReconciliations() {
		return reconciliations;
	}

	public void setReconciliations(List<Reconciliations> reconciliations) {
		this.reconciliations = reconciliations;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "IHealMedRecRes [reconciliations=" + reconciliations + ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + "]";
	}

}
