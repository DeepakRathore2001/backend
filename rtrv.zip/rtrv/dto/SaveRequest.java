package com.healogics.rtrv.dto;

import java.util.List;

public class SaveRequest {
	private int bhcMedicalRecordId;
	private int bhcInvoiceOrderId;

	private int isAddendumReceived;
	private int isRxReceived;
	private int isPatientNotSeen30;

	private int assigneeUserId;
	private String assigneeUserName;
	private String assigneeFullName;
	private int assigneeChanged;

	private String lastUpdatedUserId;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserName;

	private String patientName;
	private String patientId;
	private String patientDOB;
	private String facilityId;
	private String bluebookId;

	private List<ManualAttachment> manualAttachments;

	private List<IHealDocument> iHealAttachments;

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public int getAssigneeChanged() {
		return assigneeChanged;
	}

	public void setAssigneeChanged(int assigneeChanged) {
		this.assigneeChanged = assigneeChanged;
	}

	public List<IHealDocument> getiHealAttachments() {
		return iHealAttachments;
	}

	public void setiHealAttachments(List<IHealDocument> iHealAttachments) {
		this.iHealAttachments = iHealAttachments;
	}

	public int getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}

	public void setBhcMedicalRecordId(int bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public int getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}

	public void setBhcInvoiceOrderId(int bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}

	public int isAddendumReceived() {
		return isAddendumReceived;
	}

	public void setAddendumReceived(int isAddendumReceived) {
		this.isAddendumReceived = isAddendumReceived;
	}

	public int isRxReceived() {
		return isRxReceived;
	}

	public void setRxReceived(int isRxReceived) {
		this.isRxReceived = isRxReceived;
	}

	public int isPatientNotSeen30() {
		return isPatientNotSeen30;
	}

	public void setPatientNotSeen30(int isPatientNotSeen30) {
		this.isPatientNotSeen30 = isPatientNotSeen30;
	}

	public int getAssigneeUserId() {
		return assigneeUserId;
	}

	public void setAssigneeUserId(int assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}

	public String getAssigneeUserName() {
		return assigneeUserName;
	}

	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}

	public String getAssigneeFullName() {
		return assigneeFullName;
	}

	public void setAssigneeFullName(String assigneeFullName) {
		this.assigneeFullName = assigneeFullName;
	}

	public List<ManualAttachment> getManualAttachments() {
		return manualAttachments;
	}

	public void setManualAttachments(List<ManualAttachment> manualAttachments) {
		this.manualAttachments = manualAttachments;
	}

	public int getIsAddendumReceived() {
		return isAddendumReceived;
	}

	public void setIsAddendumReceived(int isAddendumReceived) {
		this.isAddendumReceived = isAddendumReceived;
	}

	public int getIsRxReceived() {
		return isRxReceived;
	}

	public void setIsRxReceived(int isRxReceived) {
		this.isRxReceived = isRxReceived;
	}

	public int getIsPatientNotSeen30() {
		return isPatientNotSeen30;
	}

	public void setIsPatientNotSeen30(int isPatientNotSeen30) {
		this.isPatientNotSeen30 = isPatientNotSeen30;
	}

	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}

	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}

	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}

	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}
}
