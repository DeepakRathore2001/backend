package com.healogics.rtrv.dto;

import java.util.List;

public class MasterHistoryTimelineRes extends APIResponse {
	private int currentIndex;
	private int nextIndex;
	private double totalPage;
	private Long totalCount;
	private boolean isExhausted;
	private List<MasterHistoryTimelineDetails> historyList;

	public List<MasterHistoryTimelineDetails> getHistoryList() {
		return historyList;
	}

	public void setHistoryList(List<MasterHistoryTimelineDetails> historyList) {
		this.historyList = historyList;
	}
	
	public int getCurrentIndex() {
		return currentIndex;
	}

	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}

	public int getNextIndex() {
		return nextIndex;
	}

	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}

	public double getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public boolean isExhausted() {
		return isExhausted;
	}

	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}

	@Override
	public String toString() {
		return "MasterHistoryTimelineRes [currentIndex=" + currentIndex + ", nextIndex=" + nextIndex + ", totalPage="
				+ totalPage + ", totalCount=" + totalCount + ", isExhausted=" + isExhausted + ", historyList="
				+ historyList + "]";
	}
}
