package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.Date;

public class UniformData {

	private String requestId;
	private String bbc;
	private String vendorOrderNo;
	private Integer vendorId;
	private String vendor;
	private String age;
	private Long patientId;
	private String patientName;
	private String assignedTo;
	private Timestamp lastTeamUpdated;
	private String lastTeamUpdatedFullName;
	private Date responseDate;
	private String bhcOrderSource;
	private String iHealConfiguration;
	private Date followupDate;
	private String insurance;
	private Date vendorOrderDate;
	private String retrieveStatus;
	private String vendorStatus;
	private Date receivedDate;
	private Date patientDOB;
	private String currentStatus;
	private Timestamp createdTimestamp;
	
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public String getVendorOrderNo() {
		return vendorOrderNo;
	}
	public void setVendorOrderNo(String vendorOrderNo) {
		this.vendorOrderNo = vendorOrderNo;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}

	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getLastTeamUpdatedFullName() {
		return lastTeamUpdatedFullName;
	}
	public void setLastTeamUpdatedFullName(String lastTeamUpdatedFullName) {
		this.lastTeamUpdatedFullName = lastTeamUpdatedFullName;
	}
	public Date getResponseDate() {
		return responseDate;
	}
	public void setResponseDate(Date responseDate) {
		this.responseDate = responseDate;
	}

	public Date getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}
	public String getInsurance() {
		return insurance;
	}
	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}
	public Date getVendorOrderDate() {
		return vendorOrderDate;
	}
	public void setVendorOrderDate(Date vendorOrderDate) {
		this.vendorOrderDate = vendorOrderDate;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public String getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public Timestamp getLastTeamUpdated() {
		return lastTeamUpdated;
	}
	public void setLastTeamUpdated(Timestamp lastTeamUpdated) {
		this.lastTeamUpdated = lastTeamUpdated;
	}
	public String getBhcOrderSource() {
		return bhcOrderSource;
	}
	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}
	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}
	@Override
	public String toString() {
		return "UniformData [requestId=" + requestId + ", bbc=" + bbc + ", vendorOrderNo=" + vendorOrderNo
				+ ", vendorId=" + vendorId + ", vendor=" + vendor + ", age=" + age + ", patientId=" + patientId
				+ ", patientName=" + patientName + ", assignedTo=" + assignedTo + ", lastTeamUpdated=" + lastTeamUpdated
				+ ", lastTeamUpdatedFullName=" + lastTeamUpdatedFullName + ", responseDate=" + responseDate
				+ ", bhcOrderSource=" + bhcOrderSource + ", iHealConfiguration=" + iHealConfiguration
				+ ", followupDate=" + followupDate + ", insurance=" + insurance + ", vendorOrderDate=" + vendorOrderDate
				+ ", retrieveStatus=" + retrieveStatus + ", vendorStatus=" + vendorStatus + ", receivedDate="
				+ receivedDate + ", patientDOB=" + patientDOB + ", currentStatus=" + currentStatus
				+ ", createdTimestamp=" + createdTimestamp + "]";
	}

}
