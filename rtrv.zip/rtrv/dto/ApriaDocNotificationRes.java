package com.healogics.rtrv.dto;

public class ApriaDocNotificationRes {
	private String responseCode;
	private String responseMessage;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	@Override
	public String toString() {
		return "ApriaDocNotificationRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage + "]";
	}
}
