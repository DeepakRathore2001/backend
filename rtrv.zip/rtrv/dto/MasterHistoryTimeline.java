package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class MasterHistoryTimeline {
	private Integer historyId;
	private String requestId;
	
	private Timestamp lastUpdatedTimestamp;
	private String lastUpdatedUsername;
	private String lastUpdatedUserFullname;
	private Long lastUpdatedUserId;
	private String retrieveStatus;
	private Boolean recordActive;
	private Long patientId;
	private String patientName;
	private Date patientDOB;
	private Long facilityId;
	private String bluebookId;
	private String assignedTo;
	private String reassignedTo;
	
	private VendorStatus vendorStatus;
	private HistoryUserNotes userNotes;
	private List<HistoryTimelineDocStatus> docStatusObj;

	public List<HistoryTimelineDocStatus> getDocStatusObj() {
		return docStatusObj;
	}
	public void setDocStatusObj(List<HistoryTimelineDocStatus> docStatusObj) {
		this.docStatusObj = docStatusObj;
	}
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public Integer getHistoryId() {
		return historyId;
	}
	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public VendorStatus getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(VendorStatus vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public HistoryUserNotes getUserNotes() {
		return userNotes;
	}
	public void setUserNotes(HistoryUserNotes userNotes) {
		this.userNotes = userNotes;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public Boolean getRecordActive() {
		return recordActive;
	}
	public void setRecordActive(Boolean recordActive) {
		this.recordActive = recordActive;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Long getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getReassignedTo() {
		return reassignedTo;
	}
	public void setReassignedTo(String reassignedTo) {
		this.reassignedTo = reassignedTo;
	}
	@Override
	public String toString() {
		return "MasterHistoryTimeline [historyId=" + historyId + ", requestId=" + requestId + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUserId=" + lastUpdatedUserId + ", retrieveStatus="
				+ retrieveStatus + ", recordActive=" + recordActive + ", patientId=" + patientId + ", patientName="
				+ patientName + ", patientDOB=" + patientDOB + ", facilityId=" + facilityId + ", bluebookId="
				+ bluebookId + ", assignedTo=" + assignedTo + ", reassignedTo=" + reassignedTo + ", vendorStatus="
				+ vendorStatus + ", userNotes=" + userNotes + ", docStatusObj=" + docStatusObj + "]";
	}
}
