package com.healogics.rtrv.dto;

public class SecondaryInsuranceMaster {

	private String secondaryInsName;
	private String secondaryInsPolicyNo;
	private String secondaryInsCompany;
	private String secondaryInsMac;
	private String secondaryInsDeductible;
	private String secondaryInsDeducMet;
	private String secondaryInsCopay;
	private String secondaryInsCoinsurance;
	private String secondaryInsOOPMax;
	private String secondaryInsOOPMet;
	private String secondaryInsStatus;
	private String secondaryInsPercentCovered;
	private String secondaryInsReasonNotCovered;
	private String secondaryInsReasonNA;
	public String getSecondaryInsName() {
		return secondaryInsName;
	}
	public void setSecondaryInsName(String secondaryInsName) {
		this.secondaryInsName = secondaryInsName;
	}
	public String getSecondaryInsPolicyNo() {
		return secondaryInsPolicyNo;
	}
	public void setSecondaryInsPolicyNo(String secondaryInsPolicyNo) {
		this.secondaryInsPolicyNo = secondaryInsPolicyNo;
	}
	public String getSecondaryInsCompany() {
		return secondaryInsCompany;
	}
	public void setSecondaryInsCompany(String secondaryInsCompany) {
		this.secondaryInsCompany = secondaryInsCompany;
	}
	public String getSecondaryInsMac() {
		return secondaryInsMac;
	}
	public void setSecondaryInsMac(String secondaryInsMac) {
		this.secondaryInsMac = secondaryInsMac;
	}
	public String getSecondaryInsDeductible() {
		return secondaryInsDeductible;
	}
	public void setSecondaryInsDeductible(String secondaryInsDeductible) {
		this.secondaryInsDeductible = secondaryInsDeductible;
	}
	public String getSecondaryInsDeducMet() {
		return secondaryInsDeducMet;
	}
	public void setSecondaryInsDeducMet(String secondaryInsDeducMet) {
		this.secondaryInsDeducMet = secondaryInsDeducMet;
	}
	public String getSecondaryInsCopay() {
		return secondaryInsCopay;
	}
	public void setSecondaryInsCopay(String secondaryInsCopay) {
		this.secondaryInsCopay = secondaryInsCopay;
	}
	public String getSecondaryInsCoinsurance() {
		return secondaryInsCoinsurance;
	}
	public void setSecondaryInsCoinsurance(String secondaryInsCoinsurance) {
		this.secondaryInsCoinsurance = secondaryInsCoinsurance;
	}
	public String getSecondaryInsOOPMax() {
		return secondaryInsOOPMax;
	}
	public void setSecondaryInsOOPMax(String secondaryInsOOPMax) {
		this.secondaryInsOOPMax = secondaryInsOOPMax;
	}
	public String getSecondaryInsOOPMet() {
		return secondaryInsOOPMet;
	}
	public void setSecondaryInsOOPMet(String secondaryInsOOPMet) {
		this.secondaryInsOOPMet = secondaryInsOOPMet;
	}
	public String getSecondaryInsStatus() {
		return secondaryInsStatus;
	}
	public void setSecondaryInsStatus(String secondaryInsStatus) {
		this.secondaryInsStatus = secondaryInsStatus;
	}
	public String getSecondaryInsPercentCovered() {
		return secondaryInsPercentCovered;
	}
	public void setSecondaryInsPercentCovered(
			String secondaryInsPercentCovered) {
		this.secondaryInsPercentCovered = secondaryInsPercentCovered;
	}
	public String getSecondaryInsReasonNotCovered() {
		return secondaryInsReasonNotCovered;
	}
	public void setSecondaryInsReasonNotCovered(
			String secondaryInsReasonNotCovered) {
		this.secondaryInsReasonNotCovered = secondaryInsReasonNotCovered;
	}
	public String getSecondaryInsReasonNA() {
		return secondaryInsReasonNA;
	}
	public void setSecondaryInsReasonNA(String secondaryInsReasonNA) {
		this.secondaryInsReasonNA = secondaryInsReasonNA;
	}
	@Override
	public String toString() {
		return "SecondaryInsuranceMaster [secondaryInsName=" + secondaryInsName
				+ ", secondaryInsPolicyNo=" + secondaryInsPolicyNo
				+ ", secondaryInsCompany=" + secondaryInsCompany
				+ ", secondaryInsMac=" + secondaryInsMac
				+ ", secondaryInsDeductible=" + secondaryInsDeductible
				+ ", secondaryInsDeducMet=" + secondaryInsDeducMet
				+ ", secondaryInsCopay=" + secondaryInsCopay
				+ ", secondaryInsCoinsurance=" + secondaryInsCoinsurance
				+ ", secondaryInsOOPMax=" + secondaryInsOOPMax
				+ ", secondaryInsOOPMet=" + secondaryInsOOPMet
				+ ", secondaryInsStatus=" + secondaryInsStatus
				+ ", secondaryInsPercentCovered=" + secondaryInsPercentCovered
				+ ", secondaryInsReasonNotCovered="
				+ secondaryInsReasonNotCovered + ", secondaryInsReasonNA="
				+ secondaryInsReasonNA + "]";
	}

}
