package com.healogics.rtrv.dto;

public class IHealCustomScanListReq {

	private String masterToken;
	private String privateKey;
	private String userId;
	private String facilityId;
	private String patientId;
	private String woundDocumentEntityId;
	private String conditionDocumentEntityId;
	private String startDate;
	private String endDate;
	private String activeOnly;
	private boolean currentAdmissionOnly;
	private String visitId;

	public String getVisitId() {
		return visitId;
	}
	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}
	public boolean isCurrentAdmissionOnly() {
		return currentAdmissionOnly;
	}
	public void setCurrentAdmissionOnly(boolean currentAdmissionOnly) {
		this.currentAdmissionOnly = currentAdmissionOnly;
	}
	public String getActiveOnly() {
		return activeOnly;
	}
	public void setActiveOnly(String activeOnly) {
		this.activeOnly = activeOnly;
	}
	public String getConditionDocumentEntityId() {
		return conditionDocumentEntityId;
	}
	public void setConditionDocumentEntityId(String conditionDocumentEntityId) {
		this.conditionDocumentEntityId = conditionDocumentEntityId;
	}

	public String getWoundDocumentEntityId() {
		return woundDocumentEntityId;
	}
	public void setWoundDocumentEntityId(String woundDocumentEntityId) {
		this.woundDocumentEntityId = woundDocumentEntityId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	@Override
	public String toString() {
		return "IHealCustomScanListReq [masterToken=" + masterToken
				+ ", privateKey=" + privateKey + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", woundDocumentEntityId=" + woundDocumentEntityId
				+ ", conditionDocumentEntityId=" + conditionDocumentEntityId
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", activeOnly=" + activeOnly + ", currentAdmissionOnly="
				+ currentAdmissionOnly + ", visitId=" + visitId + "]";
	}

}
