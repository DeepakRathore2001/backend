package com.healogics.rtrv.dto;

import java.util.List;

public class UpdateRetrieveUsersReq {

	private String userId;
	private String username;
	private String role;
	private List<String> businessRole;

	public List<String> getBusinessRole() {
		return businessRole;
	}
	public void setBusinessRole(List<String> businessRole) {
		this.businessRole = businessRole;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "UpdateRetrieveUsersReq [userId=" + userId + ", username="
				+ username + ", role=" + role + ", businessRole=" + businessRole
				+ "]";
	}

}
