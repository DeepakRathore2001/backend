package com.healogics.rtrv.dto;

import java.util.List;

public class DocumentRes {

	private List<DocumentObj> documents;

	private String responseCode;
	private String responseMessage;

	public List<DocumentObj> getDocuments() {
		return documents;
	}
	public void setDocuments(List<DocumentObj> documents) {
		this.documents = documents;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "DocumentRes [documents=" + documents + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
