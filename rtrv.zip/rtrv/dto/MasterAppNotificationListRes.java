package com.healogics.rtrv.dto;

import java.util.List;

public class MasterAppNotificationListRes {
	private String responseCode;
	private String responseMessage;
	private List<RTRVMasterAppNotifications> appNotificationList;

	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<RTRVMasterAppNotifications> getAppNotificationList() {
		return appNotificationList;
	}
	public void setAppNotificationList(List<RTRVMasterAppNotifications> appNotificationList) {
		this.appNotificationList = appNotificationList;
	}
	@Override
	public String toString() {
		return "MasterAppNotificationListRes [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", appNotificationList=" + appNotificationList + "]";
	}
	
	
}
