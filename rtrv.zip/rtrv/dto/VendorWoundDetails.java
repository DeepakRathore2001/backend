package com.healogics.rtrv.dto;

import java.util.List;

public class VendorWoundDetails {
	private String woundNumber;
	private String woundId;
	private List<VendorProductDetails> products;
	
	public String getWoundId() {
		return woundId;
	}

	public void setWoundId(String woundId) {
		this.woundId = woundId;
	}

	public String getWoundNumber() {
		return woundNumber;
	}

	public void setWoundNumber(String woundNumber) {
		this.woundNumber = woundNumber;
	}

	public List<VendorProductDetails> getProducts() {
		return products;
	}

	public void setProducts(List<VendorProductDetails> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "VendorWoundDetails [woundNumber=" + woundNumber + ", woundId=" + woundId + ", products=" + products
				+ "]";
	}

}
