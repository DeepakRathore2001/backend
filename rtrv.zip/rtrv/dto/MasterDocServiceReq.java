package com.healogics.rtrv.dto;

public class MasterDocServiceReq {
	private String masterToken;
	private int userId;
	private String docEntityId;
	private int facilityId;
	private int patientId;
	
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	
	
}
