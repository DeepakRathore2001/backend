package com.healogics.rtrv.dto;

public class ChartReviewInvoiceList {

	private int bhcInvoiceOrderId;
	private String amount;
	
	public int getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(int bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "ChartReviewInvoiceList [bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", amount=" + amount + "]";
	}

}
