package com.healogics.rtrv.dto;

public class UserRolesDetails {

	private String userId;
	private String username;
	private String userFullname;
	private String emailId;
	private String userRoles;
	private Boolean isSuperUser;

	public Boolean getIsSuperUser() {
		return isSuperUser;
	}
	public void setIsSuperUser(Boolean isSuperUser) {
		this.isSuperUser = isSuperUser;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserFullname() {
		return userFullname;
	}
	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}
	@Override
	public String toString() {
		return "UserRolesDetails [userId=" + userId + ", username=" + username
				+ ", userFullname=" + userFullname + ", emailId=" + emailId
				+ ", userRoles=" + userRoles + ", isSuperUser=" + isSuperUser
				+ "]";
	}

}
