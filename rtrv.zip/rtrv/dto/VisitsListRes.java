package com.healogics.rtrv.dto;

import java.util.List;

public class VisitsListRes {

	private List<VisitObj> visitList;

	private String responseCode;
	private String responseMessage;
	
	public List<VisitObj> getVisitList() {
		return visitList;
	}
	public void setVisitList(List<VisitObj> visitList) {
		this.visitList = visitList;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "VisitsListRes [visitList=" + visitList + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
