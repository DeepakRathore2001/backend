package com.healogics.rtrv.dto;

public class VendorNotes {
	private String id;
	
}
