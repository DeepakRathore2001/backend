package com.healogics.rtrv.dto;

import java.util.List;
import java.util.Map;

public class MedRecListRes extends APIResponse {

	private Map<String, List<MedRecDocObj>> documentsList;
	private String errorCode;
	private String errorMessage;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Map<String, List<MedRecDocObj>> getDocumentsList() {
		return documentsList;
	}

	public void setDocumentsList(Map<String, List<MedRecDocObj>> groupedDocuments) {
		this.documentsList = groupedDocuments;
	}

	@Override
	public String toString() {
		return "MedRecListRes [documentsList=" + documentsList + ", errorCode=" + errorCode + ", errorMessage="
				+ errorMessage + "]";
	}

}
