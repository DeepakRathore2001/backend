package com.healogics.rtrv.dto;

public class ServiceLineList {

	private Long id;
	private String serviceLineCode;
	private String vendor;
	private String serviceLine;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getServiceLineCode() {
		return serviceLineCode;
	}
	public void setServiceLineCode(String serviceLineCode) {
		this.serviceLineCode = serviceLineCode;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	@Override
	public String toString() {
		return "ServiceLineList [id=" + id + ", serviceLineCode="
				+ serviceLineCode + ", vendor=" + vendor + ", serviceLine="
				+ serviceLine + "]";
	}

}
