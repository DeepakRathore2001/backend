package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.Date;

public class AWDData {
	private String bbc;
	private int bhcMedRecId;
	private String facilityName;
	private String bhcReferralId;
	private String bhcOrderSource;
	private Date bhcOrderReceivedDate;
	private Date firstReceived;
	private Date followupDate;
	private String patientName;
	private String providerName;
	private String bhcInvoiceOrderId;
	private String assignedTo;
	private String status;
	private String vendor;
	private String age;
	private Date lastUpdatedDate;
	private Timestamp lastTeamUpdated;
	private String lastTeamUpdatedUserFullName;
	private String iHealConfiguration;
	private Timestamp lastUpdatedDateTime;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserId;
	private String lastUpdatedUserName;
	private Timestamp statusUpdatedDateTime;
	private String statusUpdatedUserFullName;
	private String statusUpdatedUserId;
	private String statusUpdatedUserName;
	private Date bhcMedicalRecAddedDate;
	private String invoiceIdsWithAmount;
	private String bhcDocStatus;
	private String insuranceType;

	private String bhcMissingDocNotes;
	private String patientDOB;

	private String bhcPatientAcctId;
	private Date bhcShipDate;
	private Date bhcLastUpdateDate;

	public Date getBhcLastUpdateDate() {
		return bhcLastUpdateDate;
	}
	public void setBhcLastUpdateDate(Date bhcLastUpdateDate) {
		this.bhcLastUpdateDate = bhcLastUpdateDate;
	}
	public String getBhcPatientAcctId() {
		return bhcPatientAcctId;
	}
	public void setBhcPatientAcctId(String bhcPatientAcctId) {
		this.bhcPatientAcctId = bhcPatientAcctId;
	}
	public Date getBhcShipDate() {
		return bhcShipDate;
	}
	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}
	public Date getFirstReceived() {
		return firstReceived;
	}
	public void setFirstReceived(Date firstReceived) {
		this.firstReceived = firstReceived;
	}
	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}
	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	public String getLastTeamUpdatedUserFullName() {
		return lastTeamUpdatedUserFullName;
	}
	public void setLastTeamUpdatedUserFullName(
			String lastTeamUpdatedUserFullName) {
		this.lastTeamUpdatedUserFullName = lastTeamUpdatedUserFullName;
	}
	public String getBhcDocStatus() {
		return bhcDocStatus;
	}
	public void setBhcDocStatus(String bhcDocStatus) {
		this.bhcDocStatus = bhcDocStatus;
	}
	public String getInsuranceType() {
		return insuranceType;
	}
	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}
	public Date getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}
	public String getInvoiceIdsWithAmount() {
		return invoiceIdsWithAmount;
	}
	public void setInvoiceIdsWithAmount(String invoiceIdsWithAmount) {
		this.invoiceIdsWithAmount = invoiceIdsWithAmount;
	}
	public Date getBhcMedicalRecAddedDate() {
		return bhcMedicalRecAddedDate;
	}
	public void setBhcMedicalRecAddedDate(Date bhcMedicalRecAddedDate) {
		this.bhcMedicalRecAddedDate = bhcMedicalRecAddedDate;
	}

	public Timestamp getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}
	public void setLastUpdatedDateTime(Timestamp lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}
	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}
	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}
	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}
	public Timestamp getStatusUpdatedDateTime() {
		return statusUpdatedDateTime;
	}
	public void setStatusUpdatedDateTime(Timestamp statusUpdatedDateTime) {
		this.statusUpdatedDateTime = statusUpdatedDateTime;
	}
	public String getStatusUpdatedUserFullName() {
		return statusUpdatedUserFullName;
	}
	public void setStatusUpdatedUserFullName(String statusUpdatedUserFullName) {
		this.statusUpdatedUserFullName = statusUpdatedUserFullName;
	}
	public String getStatusUpdatedUserId() {
		return statusUpdatedUserId;
	}
	public void setStatusUpdatedUserId(String statusUpdatedUserId) {
		this.statusUpdatedUserId = statusUpdatedUserId;
	}
	public String getStatusUpdatedUserName() {
		return statusUpdatedUserName;
	}
	public void setStatusUpdatedUserName(String statusUpdatedUserName) {
		this.statusUpdatedUserName = statusUpdatedUserName;
	}
	public Timestamp getLastTeamUpdated() {
		return lastTeamUpdated;
	}
	public void setLastTeamUpdated(Timestamp lastTeamUpdated) {
		this.lastTeamUpdated = lastTeamUpdated;
	}
	public int getBhcMedRecId() {
		return bhcMedRecId;
	}
	public void setBhcMedRecId(int bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public String getBhcReferralId() {
		return bhcReferralId;
	}
	public void setBhcReferralId(String bhcReferralId) {
		this.bhcReferralId = bhcReferralId;
	}
	public String getBhcOrderSource() {
		return bhcOrderSource;
	}
	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}
	public Date getBhcOrderReceivedDate() {
		return bhcOrderReceivedDate;
	}
	public void setBhcOrderReceivedDate(Date bhcOrderReceivedDate) {
		this.bhcOrderReceivedDate = bhcOrderReceivedDate;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}
	@Override
	public String toString() {
		return "AWDData [bbc=" + bbc + ", bhcMedRecId=" + bhcMedRecId
				+ ", facilityName=" + facilityName + ", bhcReferralId="
				+ bhcReferralId + ", bhcOrderSource=" + bhcOrderSource
				+ ", bhcOrderReceivedDate=" + bhcOrderReceivedDate
				+ ", firstReceived=" + firstReceived + ", followupDate="
				+ followupDate + ", patientName=" + patientName
				+ ", providerName=" + providerName + ", bhcInvoiceOrderId="
				+ bhcInvoiceOrderId + ", assignedTo=" + assignedTo + ", status="
				+ status + ", vendor=" + vendor + ", age=" + age
				+ ", lastUpdatedDate=" + lastUpdatedDate + ", lastTeamUpdated="
				+ lastTeamUpdated + ", lastTeamUpdatedUserFullName="
				+ lastTeamUpdatedUserFullName + ", iHealConfiguration="
				+ iHealConfiguration + ", lastUpdatedDateTime="
				+ lastUpdatedDateTime + ", lastUpdatedUserFullName="
				+ lastUpdatedUserFullName + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", statusUpdatedDateTime="
				+ statusUpdatedDateTime + ", statusUpdatedUserFullName="
				+ statusUpdatedUserFullName + ", statusUpdatedUserId="
				+ statusUpdatedUserId + ", statusUpdatedUserName="
				+ statusUpdatedUserName + ", bhcMedicalRecAddedDate="
				+ bhcMedicalRecAddedDate + ", invoiceIdsWithAmount="
				+ invoiceIdsWithAmount + ", bhcDocStatus=" + bhcDocStatus
				+ ", insuranceType=" + insuranceType + ", bhcMissingDocNotes="
				+ bhcMissingDocNotes + ", patientDOB=" + patientDOB
				+ ", bhcPatientAcctId=" + bhcPatientAcctId + ", bhcShipDate="
				+ bhcShipDate + ", bhcLastUpdateDate=" + bhcLastUpdateDate
				+ "]";
	}

}
