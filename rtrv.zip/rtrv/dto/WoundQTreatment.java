package com.healogics.rtrv.dto;

import java.util.List;

public class WoundQTreatment {
	private String description;
	private List<WoundQProduct> products;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<WoundQProduct> getProducts() {
		return products;
	}

	public void setProducts(List<WoundQProduct> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "WoundQTreatment [description=" + description + ", products=" + products + "]";
	}
}
