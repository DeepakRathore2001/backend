package com.healogics.rtrv.dto;

import java.util.List;

public class IHealWoundList {
	private List<IHealDocumentObj> wound;
	private String responseCode;
	private String responseMessage;
	public List<IHealDocumentObj> getWound() {
		return wound;
	}
	public void setWound(List<IHealDocumentObj> wound) {
		this.wound = wound;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "IHealWoundList [wound=" + wound + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage + "]";
	}

}
