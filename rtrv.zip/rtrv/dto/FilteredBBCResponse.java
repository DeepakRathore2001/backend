package com.healogics.rtrv.dto;

import java.util.List;

public class FilteredBBCResponse {
	private String responseCode;
	private String responseMessage;

	private List<String> ihealConfig;
    private List<String> businessRole;
    private List<String> division;
    private List<String> name;
    private List<String> market;
    private List<String> territory;
    private List<String> bbc;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<String> getIhealConfig() {
		return ihealConfig;
	}
	public void setIhealConfig(List<String> ihealConfig) {
		this.ihealConfig = ihealConfig;
	}
	public List<String> getBusinessRole() {
		return businessRole;
	}
	public void setBusinessRole(List<String> businessRole) {
		this.businessRole = businessRole;
	}
	public List<String> getDivision() {
		return division;
	}
	public void setDivision(List<String> division) {
		this.division = division;
	}
	public List<String> getName() {
		return name;
	}
	public void setName(List<String> name) {
		this.name = name;
	}
	public List<String> getMarket() {
		return market;
	}
	public void setMarket(List<String> market) {
		this.market = market;
	}
	public List<String> getTerritory() {
		return territory;
	}
	public void setTerritory(List<String> territory) {
		this.territory = territory;
	}
	public List<String> getBbc() {
		return bbc;
	}
	public void setBbc(List<String> bbc) {
		this.bbc = bbc;
	}
	@Override
	public String toString() {
		return "FilteredBBCResponse [responseCode=" + responseCode + ", responseMessage=" + responseMessage
				+ ", ihealConfig=" + ihealConfig + ", businessRole=" + businessRole + ", division=" + division
				+ ", name=" + name + ", market=" + market + ", territory=" + territory + ", bbc=" + bbc + "]";
	}

}
