package com.healogics.rtrv.dto;

import java.util.List;

public class MasterSubmitChartReq {
	private String orderId;
	private String lastUpdatedUserId;
	private String lastUpdatedUserFullName;
	private String lastUpdatedUserName;
	private int userId;
	private int patientId;
	private int facilityId;
	private String masterToken;
	private String serviceLine;
	private String requestId;
	private List<MasterSaveAttachmentObj> documents;
	
	//LifeNet
	private String vendorName;
	private String bluebookId;
	private String facilityName;
	private String patientFirstName;
	private String patientLastName;
	private String vendorOrderNo;
	
	public String getVendorOrderNo() {
		return vendorOrderNo;
	}

	public void setVendorOrderNo(String vendorOrderNo) {
		this.vendorOrderNo = vendorOrderNo;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getPatientFirstName() {
		return patientFirstName;
	}

	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}

	public String getPatientLastName() {
		return patientLastName;
	}

	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getBluebookId() {
		return bluebookId;
	}

	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public List<MasterSaveAttachmentObj> getDocuments() {
		return documents;
	}

	public void setDocuments(List<MasterSaveAttachmentObj> documents) {
		this.documents = documents;
	}

	public String getLastUpdatedUserFullName() {
		return lastUpdatedUserFullName;
	}

	public void setLastUpdatedUserFullName(String lastUpdatedUserFullName) {
		this.lastUpdatedUserFullName = lastUpdatedUserFullName;
	}

	public String getLastUpdatedUserName() {
		return lastUpdatedUserName;
	}

	public void setLastUpdatedUserName(String lastUpdatedUserName) {
		this.lastUpdatedUserName = lastUpdatedUserName;
	}

	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "MasterSubmitChartReq [orderId=" + orderId + ", lastUpdatedUserId=" + lastUpdatedUserId
				+ ", lastUpdatedUserFullName=" + lastUpdatedUserFullName + ", lastUpdatedUserName="
				+ lastUpdatedUserName + ", userId=" + userId + ", patientId=" + patientId + ", facilityId=" + facilityId
				+ ", masterToken=" + masterToken + ", serviceLine=" + serviceLine + ", requestId=" + requestId
				+ ", documents=" + documents + ", vendorName=" + vendorName + ", bluebookId=" + bluebookId
				+ ", facilityName=" + facilityName + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", vendorOrderNo=" + vendorOrderNo + "]";
	}
}
