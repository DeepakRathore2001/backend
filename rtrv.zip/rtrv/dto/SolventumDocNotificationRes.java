package com.healogics.rtrv.dto;

public class SolventumDocNotificationRes {
	private boolean item;
	private boolean succeeded;
	private SolvemtumErrorDetails error;

	public boolean isItem() {
		return item;
	}

	public void setItem(boolean item) {
		this.item = item;
	}

	public boolean isSucceeded() {
		return succeeded;
	}

	public void setSucceeded(boolean succeeded) {
		this.succeeded = succeeded;
	}

	public SolvemtumErrorDetails getError() {
		return error;
	}

	public void setError(SolvemtumErrorDetails error) {
		this.error = error;
	}

	@Override
	public String toString() {
		return "SolventumDocNotificationRes [item=" + item + ", succeeded=" + succeeded + ", error=" + error + "]";
	}
}
