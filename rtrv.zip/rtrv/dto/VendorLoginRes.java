package com.healogics.rtrv.dto;

public class VendorLoginRes {
	private String requestId;
	private String accessToken;
	private String responseCode;
	private String responseMessage;

	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "VendorLoginRes [requestId=" + requestId + ", accessToken="
				+ accessToken + ", responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + "]";
	}

}
