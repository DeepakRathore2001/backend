package com.healogics.rtrv.dto;

import java.util.Date;

public class NPWTReportData {

	private long roNo;
	private String BBC;
	private long hlWqOrderNo;
	private String patientName;
	private Date firstReceivedDate;
	private Date documentsFirstSent;
	private Date documentsLastSent;
	private String vendorStatus;
	private String retrieveStatus;
	private int noFilesSent;

	public long getRoNo() {
		return roNo;
	}

	public void setRoNo(long roNo) {
		this.roNo = roNo;
	}

	public String getBBC() {
		return BBC;
	}

	public void setBBC(String bBC) {
		BBC = bBC;
	}

	public long getHlWqOrderNo() {
		return hlWqOrderNo;
	}

	public void setHlWqOrderNo(long hlWqOrderNo) {
		this.hlWqOrderNo = hlWqOrderNo;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getFirstReceivedDate() {
		return firstReceivedDate;
	}

	public void setFirstReceivedDate(Date firstReceivedDate) {
		this.firstReceivedDate = firstReceivedDate;
	}

	public Date getDocumentsFirstSent() {
		return documentsFirstSent;
	}

	public void setDocumentsFirstSent(Date documentsFirstSent) {
		this.documentsFirstSent = documentsFirstSent;
	}

	public Date getDocumentsLastSent() {
		return documentsLastSent;
	}

	public void setDocumentsLastSent(Date documentsLastSent) {
		this.documentsLastSent = documentsLastSent;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

	public String getRetrieveStatus() {
		return retrieveStatus;
	}

	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public int getNoFilesSent() {
		return noFilesSent;
	}

	public void setNoFilesSent(int noFilesSent) {
		this.noFilesSent = noFilesSent;
	}

	@Override
	public String toString() {
		return "NPWTReportData [roNo=" + roNo + ", BBC=" + BBC + ", hlWqOrderNo=" + hlWqOrderNo + ", patientName="
				+ patientName + ", firstReceivedDate=" + firstReceivedDate + ", documentsFirstSent="
				+ documentsFirstSent + ", documentsLastSent=" + documentsLastSent + ", vendorStatus=" + vendorStatus
				+ ", retrieveStatus=" + retrieveStatus + ", noFilesSent=" + noFilesSent + "]";
	}

}
