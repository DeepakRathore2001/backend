package com.healogics.rtrv.dto;

public class Build {
	private String version;
	private String commitId;
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getCommitId() {
		return commitId;
	}
	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}
	@Override
	public String toString() {
		return "Build [version=" + version + ", commitId=" + commitId + "]";
	}
}
