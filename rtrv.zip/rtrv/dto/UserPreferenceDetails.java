package com.healogics.rtrv.dto;

import java.sql.Timestamp;

public class UserPreferenceDetails {

	private Long userId;
	private String username;
	private String serviceLineCode;
	private String serviceLineDesc;
	private String awdDashboard;
	private String npwtDashboard;
	private String ctpDashboard;
	private String createdTimestamp;
	private String userFullname;
	private String createdBy;
	private String lastUpdatedTimestamp;
	private String lastUpdatedBy;
	private Long facilityId;
	private String bluebookId;
	private Timestamp clearNotifcationTimestamp;
	private String colorCodes;

	public String getColorCodes() {
		return colorCodes;
	}
	public void setColorCodes(String colorCodes) {
		this.colorCodes = colorCodes;
	}
	public Timestamp getClearNotifcationTimestamp() {
		return clearNotifcationTimestamp;
	}
	public void setClearNotifcationTimestamp(
			Timestamp clearNotifcationTimestamp) {
		this.clearNotifcationTimestamp = clearNotifcationTimestamp;
	}
	public String getServiceLineDesc() {
		return serviceLineDesc;
	}
	public void setServiceLineDesc(String serviceLineDesc) {
		this.serviceLineDesc = serviceLineDesc;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getServiceLineCode() {
		return serviceLineCode;
	}
	public void setServiceLineCode(String serviceLineCode) {
		this.serviceLineCode = serviceLineCode;
	}

	public String getAwdDashboard() {
		return awdDashboard;
	}
	public void setAwdDashboard(String awdDashboard) {
		this.awdDashboard = awdDashboard;
	}
	public String getNpwtDashboard() {
		return npwtDashboard;
	}
	public void setNpwtDashboard(String npwtDashboard) {
		this.npwtDashboard = npwtDashboard;
	}
	public String getCtpDashboard() {
		return ctpDashboard;
	}
	public void setCtpDashboard(String ctpDashboard) {
		this.ctpDashboard = ctpDashboard;
	}
	public String getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(String createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public String getUserFullname() {
		return userFullname;
	}
	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(String lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Long getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	@Override
	public String toString() {
		return "UserPreferenceDetails [userId=" + userId + ", username="
				+ username + ", serviceLineCode=" + serviceLineCode
				+ ", serviceLineDesc=" + serviceLineDesc + ", awdDashboard="
				+ awdDashboard + ", npwtDashboard=" + npwtDashboard
				+ ", ctpDashboard=" + ctpDashboard + ", createdTimestamp="
				+ createdTimestamp + ", userFullname=" + userFullname
				+ ", createdBy=" + createdBy + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", facilityId=" + facilityId + ", bluebookId=" + bluebookId
				+ ", clearNotifcationTimestamp=" + clearNotifcationTimestamp
				+ ", colorCodes=" + colorCodes + "]";
	}

}
