package com.healogics.rtrv.dto;

public class DocumentObj {

	private String docName;
	private String docEntityId;
	private String documentType;
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	@Override
	public String toString() {
		return "DocumentObj [docName=" + docName + ", docEntityId="
				+ docEntityId + ", documentType=" + documentType + "]";
	}

}
