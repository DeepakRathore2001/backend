package com.healogics.rtrv.dto;

public class IHealWoundMeasurement {

	private IHealWound wound;
	private IHealMeasurement measurement;

	public IHealMeasurement getMeasurement() {
		return measurement;
	}

	public void setMeasurement(IHealMeasurement measurement) {
		this.measurement = measurement;
	}

	public IHealWound getWound() {
		return wound;
	}

	public void setWound(IHealWound wound) {
		this.wound = wound;
	}

	@Override
	public String toString() {
		return "IHealWoundMeasurement [wound=" + wound + ", measurement="
				+ measurement + "]";
	}

}
