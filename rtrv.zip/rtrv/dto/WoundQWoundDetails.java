package com.healogics.rtrv.dto;

import java.util.List;

public class WoundQWoundDetails {
	private String woundNumber;
	private String woundId;
	private List<WoundQTreatment> treatments;

	public String getWoundNumber() {
		return woundNumber;
	}

	public void setWoundNumber(String woundNumber) {
		this.woundNumber = woundNumber;
	}

	public String getWoundId() {
		return woundId;
	}

	public void setWoundId(String woundId) {
		this.woundId = woundId;
	}

	public List<WoundQTreatment> getTreatments() {
		return treatments;
	}

	public void setTreatments(List<WoundQTreatment> treatments) {
		this.treatments = treatments;
	}

	@Override
	public String toString() {
		return "WoundQWoundDetails [woundNumber=" + woundNumber + ", woundId=" + woundId + ", treatments=" + treatments
				+ "]";
	}
}
