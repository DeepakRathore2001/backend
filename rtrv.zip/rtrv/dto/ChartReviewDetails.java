package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class ChartReviewDetails {

	private String bbc;
	private int bhcMedRecId;
	private int bhcInvoiceOrderNo;
	private int facilityId;
	private String facilityName;
	private String bhcReferralId;
	private String bhcOrderSource;
	private Date bhcOrderReceivedDate;
	private String patientName;
	private String patientFirstName;
	private String patientLastName;
	private LocalDate patientDOB;
	private Integer healogicsPatientId;
	private String healogicsPatientMRN;
	private Integer bhcPatientAcctId;
	private String insuranceCategory;
	private String primaryInsurance;
	private String providerName;
	private List<ChartReviewInvoiceList> bhcInvoiceOrderId;
	private String assignedTo;
	private String assignedToUsername;
	private String status;
	private String vendor;
	private Date age;
	private Date lastUpdatedDate;
	private Date bhcMedicalRecAddedDate;
	private String market;
	private String division;
	private String territory;
	private String facilityPhone;
	private String facilityFax;
	private String docTeamAnalyst;
	private String docTeamClerk;
	private Integer wqOrderId;
	private Date bhcShipDate;
	private Date firstReceived;
	private Date lastUpdated;
	private Date lastReceived;
	private Timestamp lastFileUploaded;
	private Long filesSent;
	private Long noOfUpdates;
	private Timestamp lastActioned;
	private Date followupDate;
	private Long noteId;
	private String bhcDocumentType;
	private String bhcDocumentStatus;
	private String bhcMissingDocType;
	private String bhcMissingDocuments;
	private String bhcMissingDocNotes;
	private Integer addendumReceived;
	private Integer receivedRx;
	private Integer patientNotSeen30Days;
	private String awdDocSpecialist;
	private String awdDocClerk;
	private Integer addendum;
	private Long addendumAddedByUserId;
	private String addendumAddedByUserName;
	private String addendumAddedByUserFullName;
	private Integer recordModify;
	private Long recordModifedByUserId;
	private String recordModifiedByUserName;
	private String recordModifiedByUserFullName;

	private String iHealConfiguration;
	private String opsSpecialist;

	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}
	public String getOpsSpecialist() {
		return opsSpecialist;
	}
	public void setOpsSpecialist(String opsSpecialist) {
		this.opsSpecialist = opsSpecialist;
	}
	public int getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}
	public void setBhcInvoiceOrderNo(int bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}
	public Integer getAddendum() {
		return addendum;
	}
	public void setAddendum(Integer addendum) {
		this.addendum = addendum;
	}
	public Long getAddendumAddedByUserId() {
		return addendumAddedByUserId;
	}
	public void setAddendumAddedByUserId(Long addendumAddedByUserId) {
		this.addendumAddedByUserId = addendumAddedByUserId;
	}
	public String getAddendumAddedByUserName() {
		return addendumAddedByUserName;
	}
	public void setAddendumAddedByUserName(String addendumAddedByUserName) {
		this.addendumAddedByUserName = addendumAddedByUserName;
	}
	public String getAddendumAddedByUserFullName() {
		return addendumAddedByUserFullName;
	}
	public void setAddendumAddedByUserFullName(
			String addendumAddedByUserFullName) {
		this.addendumAddedByUserFullName = addendumAddedByUserFullName;
	}
	public Integer getRecordModify() {
		return recordModify;
	}
	public void setRecordModify(Integer recordModify) {
		this.recordModify = recordModify;
	}
	public Long getRecordModifedByUserId() {
		return recordModifedByUserId;
	}
	public void setRecordModifedByUserId(Long recordModifedByUserId) {
		this.recordModifedByUserId = recordModifedByUserId;
	}
	public String getRecordModifiedByUserName() {
		return recordModifiedByUserName;
	}
	public void setRecordModifiedByUserName(String recordModifiedByUserName) {
		this.recordModifiedByUserName = recordModifiedByUserName;
	}
	public String getRecordModifiedByUserFullName() {
		return recordModifiedByUserFullName;
	}
	public void setRecordModifiedByUserFullName(
			String recordModifiedByUserFullName) {
		this.recordModifiedByUserFullName = recordModifiedByUserFullName;
	}
	public String getAwdDocSpecialist() {
		return awdDocSpecialist;
	}
	public void setAwdDocSpecialist(String awdDocSpecialist) {
		this.awdDocSpecialist = awdDocSpecialist;
	}
	public String getAwdDocClerk() {
		return awdDocClerk;
	}
	public void setAwdDocClerk(String awdDocClerk) {
		this.awdDocClerk = awdDocClerk;
	}
	private List<IHealDocument> iHealAttachments;

	private List<AttachmentDetails> manualAttachments;
	private List<AttachmentDetails> docReceivedFromByram;

	public List<AttachmentDetails> getDocReceivedFromByram() {
		return docReceivedFromByram;
	}
	public void setDocReceivedFromByram(
			List<AttachmentDetails> docReceivedFromByram) {
		this.docReceivedFromByram = docReceivedFromByram;
	}
	public List<AttachmentDetails> getManualAttachments() {
		return manualAttachments;
	}
	public void setManualAttachments(
			List<AttachmentDetails> manualAttachments) {
		this.manualAttachments = manualAttachments;
	}
	public List<IHealDocument> getiHealAttachments() {
		return iHealAttachments;
	}
	public void setiHealAttachments(List<IHealDocument> iHealAttachments) {
		this.iHealAttachments = iHealAttachments;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public int getBhcMedRecId() {
		return bhcMedRecId;
	}
	public void setBhcMedRecId(int bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getBhcReferralId() {
		return bhcReferralId;
	}
	public void setBhcReferralId(String bhcReferralId) {
		this.bhcReferralId = bhcReferralId;
	}
	public String getBhcOrderSource() {
		return bhcOrderSource;
	}
	public void setBhcOrderSource(String bhcOrderSource) {
		this.bhcOrderSource = bhcOrderSource;
	}
	public Date getBhcOrderReceivedDate() {
		return bhcOrderReceivedDate;
	}
	public void setBhcOrderReceivedDate(Date bhcOrderReceivedDate) {
		this.bhcOrderReceivedDate = bhcOrderReceivedDate;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public LocalDate getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(LocalDate patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Integer getHealogicsPatientId() {
		return healogicsPatientId;
	}
	public void setHealogicsPatientId(Integer healogicsPatientId) {
		this.healogicsPatientId = healogicsPatientId;
	}
	public String getHealogicsPatientMRN() {
		return healogicsPatientMRN;
	}
	public void setHealogicsPatientMRN(String healogicsPatientMRN) {
		this.healogicsPatientMRN = healogicsPatientMRN;
	}

	public Integer getBhcPatientAcctId() {
		return bhcPatientAcctId;
	}
	public void setBhcPatientAcctId(Integer bhcPatientAcctId) {
		this.bhcPatientAcctId = bhcPatientAcctId;
	}
	public String getInsuranceCategory() {
		return insuranceCategory;
	}
	public void setInsuranceCategory(String insuranceCategory) {
		this.insuranceCategory = insuranceCategory;
	}
	public String getPrimaryInsurance() {
		return primaryInsurance;
	}
	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public List<ChartReviewInvoiceList> getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(
			List<ChartReviewInvoiceList> bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public Date getAge() {
		return age;
	}
	public void setAge(Date age) {
		this.age = age;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public Date getBhcMedicalRecAddedDate() {
		return bhcMedicalRecAddedDate;
	}
	public void setBhcMedicalRecAddedDate(Date bhcMedicalRecAddedDate) {
		this.bhcMedicalRecAddedDate = bhcMedicalRecAddedDate;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getTerritory() {
		return territory;
	}
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	public String getFacilityPhone() {
		return facilityPhone;
	}
	public void setFacilityPhone(String facilityPhone) {
		this.facilityPhone = facilityPhone;
	}
	public String getFacilityFax() {
		return facilityFax;
	}
	public void setFacilityFax(String facilityFax) {
		this.facilityFax = facilityFax;
	}
	public String getDocTeamAnalyst() {
		return docTeamAnalyst;
	}
	public void setDocTeamAnalyst(String docTeamAnalyst) {
		this.docTeamAnalyst = docTeamAnalyst;
	}
	public String getDocTeamClerk() {
		return docTeamClerk;
	}
	public void setDocTeamClerk(String docTeamClerk) {
		this.docTeamClerk = docTeamClerk;
	}
	public Integer getWqOrderId() {
		return wqOrderId;
	}
	public void setWqOrderId(Integer wqOrderId) {
		this.wqOrderId = wqOrderId;
	}
	public Date getBhcShipDate() {
		return bhcShipDate;
	}
	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}
	public Date getFirstReceived() {
		return firstReceived;
	}
	public void setFirstReceived(Date firstReceived) {
		this.firstReceived = firstReceived;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public Date getLastReceived() {
		return lastReceived;
	}
	public void setLastReceived(Date lastReceived) {
		this.lastReceived = lastReceived;
	}
	public Timestamp getLastFileUploaded() {
		return lastFileUploaded;
	}
	public void setLastFileUploaded(Timestamp lastFileUploaded) {
		this.lastFileUploaded = lastFileUploaded;
	}
	public Long getFilesSent() {
		return filesSent;
	}
	public void setFilesSent(Long filesSent) {
		this.filesSent = filesSent;
	}
	public Long getNoOfUpdates() {
		return noOfUpdates;
	}
	public void setNoOfUpdates(Long noOfUpdates) {
		this.noOfUpdates = noOfUpdates;
	}
	public Timestamp getLastActioned() {
		return lastActioned;
	}
	public void setLastActioned(Timestamp lastActioned) {
		this.lastActioned = lastActioned;
	}
	public Date getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}
	public Long getNoteId() {
		return noteId;
	}
	public void setNoteId(Long noteId) {
		this.noteId = noteId;
	}
	public String getBhcDocumentType() {
		return bhcDocumentType;
	}
	public void setBhcDocumentType(String bhcDocumentType) {
		this.bhcDocumentType = bhcDocumentType;
	}
	public String getBhcDocumentStatus() {
		return bhcDocumentStatus;
	}
	public void setBhcDocumentStatus(String bhcDocumentStatus) {
		this.bhcDocumentStatus = bhcDocumentStatus;
	}
	public String getBhcMissingDocType() {
		return bhcMissingDocType;
	}
	public void setBhcMissingDocType(String bhcMissingDocType) {
		this.bhcMissingDocType = bhcMissingDocType;
	}
	public String getBhcMissingDocuments() {
		return bhcMissingDocuments;
	}
	public void setBhcMissingDocuments(String bhcMissingDocuments) {
		this.bhcMissingDocuments = bhcMissingDocuments;
	}
	public String getBhcMissingDocNotes() {
		return bhcMissingDocNotes;
	}
	public void setBhcMissingDocNotes(String bhcMissingDocNotes) {
		this.bhcMissingDocNotes = bhcMissingDocNotes;
	}
	public Integer getAddendumReceived() {
		return addendumReceived;
	}
	public void setAddendumReceived(Integer addendumReceived) {
		this.addendumReceived = addendumReceived;
	}
	public Integer getReceivedRx() {
		return receivedRx;
	}
	public void setReceivedRx(Integer receivedRx) {
		this.receivedRx = receivedRx;
	}
	public Integer getPatientNotSeen30Days() {
		return patientNotSeen30Days;
	}
	public void setPatientNotSeen30Days(Integer patientNotSeen30Days) {
		this.patientNotSeen30Days = patientNotSeen30Days;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getAssignedToUsername() {
		return assignedToUsername;
	}
	public void setAssignedToUsername(String assignedToUsername) {
		this.assignedToUsername = assignedToUsername;
	}
	@Override
	public String toString() {
		return "ChartReviewDetails [bbc=" + bbc + ", bhcMedRecId=" + bhcMedRecId
				+ ", bhcInvoiceOrderNo=" + bhcInvoiceOrderNo + ", facilityId="
				+ facilityId + ", facilityName=" + facilityName
				+ ", bhcReferralId=" + bhcReferralId + ", bhcOrderSource="
				+ bhcOrderSource + ", bhcOrderReceivedDate="
				+ bhcOrderReceivedDate + ", patientName=" + patientName
				+ ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientDOB="
				+ patientDOB + ", healogicsPatientId=" + healogicsPatientId
				+ ", healogicsPatientMRN=" + healogicsPatientMRN
				+ ", bhcPatientAcctId=" + bhcPatientAcctId
				+ ", insuranceCategory=" + insuranceCategory
				+ ", primaryInsurance=" + primaryInsurance + ", providerName="
				+ providerName + ", bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", assignedTo=" + assignedTo + ", assignedToUsername="
				+ assignedToUsername + ", status=" + status + ", vendor="
				+ vendor + ", age=" + age + ", lastUpdatedDate="
				+ lastUpdatedDate + ", bhcMedicalRecAddedDate="
				+ bhcMedicalRecAddedDate + ", market=" + market + ", division="
				+ division + ", territory=" + territory + ", facilityPhone="
				+ facilityPhone + ", facilityFax=" + facilityFax
				+ ", docTeamAnalyst=" + docTeamAnalyst + ", docTeamClerk="
				+ docTeamClerk + ", wqOrderId=" + wqOrderId + ", bhcShipDate="
				+ bhcShipDate + ", firstReceived=" + firstReceived
				+ ", lastUpdated=" + lastUpdated + ", lastReceived="
				+ lastReceived + ", lastFileUploaded=" + lastFileUploaded
				+ ", filesSent=" + filesSent + ", noOfUpdates=" + noOfUpdates
				+ ", lastActioned=" + lastActioned + ", followupDate="
				+ followupDate + ", noteId=" + noteId + ", bhcDocumentType="
				+ bhcDocumentType + ", bhcDocumentStatus=" + bhcDocumentStatus
				+ ", bhcMissingDocType=" + bhcMissingDocType
				+ ", bhcMissingDocuments=" + bhcMissingDocuments
				+ ", bhcMissingDocNotes=" + bhcMissingDocNotes
				+ ", addendumReceived=" + addendumReceived + ", receivedRx="
				+ receivedRx + ", patientNotSeen30Days=" + patientNotSeen30Days
				+ ", awdDocSpecialist=" + awdDocSpecialist + ", awdDocClerk="
				+ awdDocClerk + ", addendum=" + addendum
				+ ", addendumAddedByUserId=" + addendumAddedByUserId
				+ ", addendumAddedByUserName=" + addendumAddedByUserName
				+ ", addendumAddedByUserFullName=" + addendumAddedByUserFullName
				+ ", recordModify=" + recordModify + ", recordModifedByUserId="
				+ recordModifedByUserId + ", recordModifiedByUserName="
				+ recordModifiedByUserName + ", recordModifiedByUserFullName="
				+ recordModifiedByUserFullName + ", iHealConfiguration="
				+ iHealConfiguration + ", opsSpecialist=" + opsSpecialist
				+ ", iHealAttachments=" + iHealAttachments
				+ ", manualAttachments=" + manualAttachments
				+ ", docReceivedFromByram=" + docReceivedFromByram + "]";
	}

}
