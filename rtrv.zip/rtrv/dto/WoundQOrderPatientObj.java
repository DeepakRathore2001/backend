package com.healogics.rtrv.dto;

import java.util.Date;
import java.util.List;

public class WoundQOrderPatientObj {
	private String lastName;
	private String firstName;
	private String patientMrn;
	private int patientId;
	private String gender;
	private String email;
	private Date dob;
	private List<WoundQOrderInsuranceObj> insurance;
	private List<ICDCodes> icdCodes;
	
	public List<ICDCodes> getIcdCodes() {
		return icdCodes;
	}

	public void setIcdCodes(List<ICDCodes> icdCodes) {
		this.icdCodes = icdCodes;
	}

	public List<WoundQOrderInsuranceObj> getInsurance() {
		return insurance;
	}

	public void setInsurance(List<WoundQOrderInsuranceObj> insurance) {
		this.insurance = insurance;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getPatientMrn() {
		return patientMrn;
	}

	public void setPatientMrn(String patientMrn) {
		this.patientMrn = patientMrn;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "WoundQOrderPatientObj [lastName=" + lastName + ", firstName=" + firstName + ", patientMrn=" + patientMrn
				+ ", patientId=" + patientId + ", gender=" + gender + ", email=" + email + ", dob=" + dob
				+ ", insurance=" + insurance + ", icdCodes=" + icdCodes + "]";
	}
}
