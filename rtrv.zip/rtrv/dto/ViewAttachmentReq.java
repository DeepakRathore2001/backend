package com.healogics.rtrv.dto;

public class ViewAttachmentReq {

	private String documentEntityId;
	private String facilityId;
	private String userId;
	private String patientId;
	private String masterToken;
	private String iHealFileType;
	private String documentId;
	private String documentName;
	private String medRecId;
	private String bhcInvoiceOrderId;

	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getMedRecId() {
		return medRecId;
	}
	public void setMedRecId(String medRecId) {
		this.medRecId = medRecId;
	}
	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(String documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getiHealFileType() {
		return iHealFileType;
	}
	public void setiHealFileType(String iHealFileType) {
		this.iHealFileType = iHealFileType;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	@Override
	public String toString() {
		return "ViewAttachmentReq [documentEntityId=" + documentEntityId
				+ ", facilityId=" + facilityId + ", userId=" + userId
				+ ", patientId=" + patientId + ", masterToken=" + masterToken
				+ ", iHealFileType=" + iHealFileType + ", documentId="
				+ documentId + ", documentName=" + documentName + ", medRecId="
				+ medRecId + ", bhcInvoiceOrderId=" + bhcInvoiceOrderId + "]";
	}

}
