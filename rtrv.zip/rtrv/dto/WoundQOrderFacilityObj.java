package com.healogics.rtrv.dto;

public class WoundQOrderFacilityObj {
	private String facilityBbc;
	private int facilityId;
	private String facilityName;
	private String facilityConfiguration;

	public String getFacilityBbc() {
		return facilityBbc;
	}

	public void setFacilityBbc(String facilityBbc) {
		this.facilityBbc = facilityBbc;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityConfiguration() {
		return facilityConfiguration;
	}

	public void setFacilityConfiguration(String facilityConfiguration) {
		this.facilityConfiguration = facilityConfiguration;
	}

	@Override
	public String toString() {
		return "WoundQOrderFacilityObj [facilityBbc=" + facilityBbc + ", facilityId=" + facilityId + ", facilityName="
				+ facilityName + ", facilityConfiguration=" + facilityConfiguration + "]";
	}

}
