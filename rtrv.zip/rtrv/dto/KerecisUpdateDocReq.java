package com.healogics.rtrv.dto;

public class KerecisUpdateDocReq {
	private String retrieveStatus;
	private KerecisNotesObject note;

	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public KerecisNotesObject getNote() {
		return note;
	}
	public void setNote(KerecisNotesObject note) {
		this.note = note;
	}

	@Override
	public String toString() {
		return "KerecisUpdateDocReq [retrieveStatus=" + retrieveStatus + ", note=" + note + "]";
	}
}
