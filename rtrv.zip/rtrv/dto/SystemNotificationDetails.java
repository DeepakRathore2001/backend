package com.healogics.rtrv.dto;

public class SystemNotificationDetails {

	private String notificationId;
	private String title;
	private String description;
	private String hyperlink;
	
	public String getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHyperlink() {
		return hyperlink;
	}
	public void setHyperlink(String hyperlink) {
		this.hyperlink = hyperlink;
	}
	@Override
	public String toString() {
		return "SystemNotificationDetails [notificationId=" + notificationId
				+ ", title=" + title + ", description=" + description
				+ ", hyperlink=" + hyperlink + "]";
	}

}
