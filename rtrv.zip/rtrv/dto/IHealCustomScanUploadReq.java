package com.healogics.rtrv.dto;

import java.io.Serializable;

public class IHealCustomScanUploadReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String eventDateTime;
	private int userId;
	private int facilityId;
	private int patientId;
	private int groupId;
	private String scanId;
	private String title;
	private String extension;
	private String groupName;
	private String scanURL;
	private String scanStream;
	private String scanExtension;
	private String scanDocumentEntityId;

	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getEventDateTime() {
		return eventDateTime;
	}
	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getScanId() {
		return scanId;
	}
	public void setScanId(String scanId) {
		this.scanId = scanId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getScanURL() {
		return scanURL;
	}
	public void setScanURL(String scanURL) {
		this.scanURL = scanURL;
	}
	public String getScanStream() {
		return scanStream;
	}
	public void setScanStream(String scanStream) {
		this.scanStream = scanStream;
	}
	public String getScanExtension() {
		return scanExtension;
	}
	public void setScanExtension(String scanExtension) {
		this.scanExtension = scanExtension;
	}
	public String getScanDocumentEntityId() {
		return scanDocumentEntityId;
	}
	public void setScanDocumentEntityId(String scanDocumentEntityId) {
		this.scanDocumentEntityId = scanDocumentEntityId;
	}
	@Override
	public String toString() {
		return "IHealCustomScanUploadReq [privateKey=" + privateKey
				+ ", masterToken=" + masterToken + ", eventDateTime="
				+ eventDateTime + ", userId=" + userId + ", facilityId="
				+ facilityId + ", patientId=" + patientId + ", groupId="
				+ groupId + ", scanId=" + scanId + ", title=" + title
				+ ", extension=" + extension + ", groupName=" + groupName
				+ ", scanURL=" + scanURL + ", scanStream=" + scanStream
				+ ", scanExtension=" + scanExtension + ", scanDocumentEntityId="
				+ scanDocumentEntityId + "]";
	}

}
