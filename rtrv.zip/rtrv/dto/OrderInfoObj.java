package com.healogics.rtrv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderInfoObj {

	@JsonProperty("Vendor Id")
	private String vendorRequestId;
	@JsonProperty("Facility")
	private String facilityName;
	@JsonProperty("DX Code")
	private String dxCode;
	@JsonProperty("BBC")
	private String bbc;
	@JsonProperty("Sales Person")
	private String salesPerson;
	@JsonProperty("Created From")
	private String createFrom;
	@JsonProperty("SGP")
	private String sgp;
	@JsonProperty("Date Created")
	private String dateCreated;
	@JsonProperty("Patient Name")
	private String patientName;
	@JsonProperty("Primary Insurance Company")
	private String primaryInsuranceCompany;
	@JsonProperty("Secondary Insurance Company")
	private String secondaryInsuranceCompany;
	@JsonProperty("Case Id")
	private String caseId;
	@JsonProperty("Primary Insurance Status")
	private String primarInsuranceStatus;
	@JsonProperty("Healogic Pilot")
	private String healogicsPilot;
	@JsonProperty("patientId")
	private String patientId;
	@JsonProperty("Physician Name")
	private String physicianName;
	@JsonProperty("Follow Up Date")
	private String followupDate;
	@JsonProperty("Special Instructions")
	private String specialInstructions;
	@JsonProperty("Primary Insurance Policy #")
	private String primaryInsurancePolicyNo;
	@JsonProperty("Primary Insurance MAC")
	private String primaryInsuranceMac;
	@JsonProperty("Primary Insurance Deductible")
	private String primaryInsuranceDeductible;
	@JsonProperty("Primary Insurance Deductible Met")
	private String primaryInsuranceDeductibleMet;
	@JsonProperty("Primary Insurance Copay")
	private String primaryInsuranceCopay;
	@JsonProperty("Primary Insurance Co-Insurance")
	private String primaryInsuranceCoInsurance;
	@JsonProperty("Primary Insurance OOP Max")
	private String primaryInsuranceOOPMax;
	@JsonProperty("Primary Insurance OOP Met")
	private String primaryInsuranceOOPMet;
	@JsonProperty("Primary Insurance Percent Covered")
	private String primaryInsurancePercentCovered;
	@JsonProperty("Primary Insurance Reason Not Covered")
	private String primaryInsuranceReasonNotCovered;
	@JsonProperty("Primary Insurance Reason NA")
	private String primaryInsuranceReasonNA;
	@JsonProperty("Secondary Insurance Policy #")
	private String secondaryInsurancePolicyNo;
	@JsonProperty("Secondary Insurance MAC")
	private String secondaryInsuranceMac;
	@JsonProperty("Secondary Insurance Deductible")
	private String secondaryInsuranceDeductible;
	@JsonProperty("Secondary Insurance Deductible Met")
	private String secondaryInsuranceDeductibleMet;
	@JsonProperty("Secondary Insurance Copay")
	private String secondaryInsuranceCopay;
	@JsonProperty("Secondary Insurance Co-Insurance")
	private String secondaryInsuranceCoInsurance;
	@JsonProperty("Secondary Insurance OOP Max")
	private String secondaryInsuranceOOPMax;
	@JsonProperty("Secondary Insurance OOP Met")
	private String secondaryInsuranceOOPMet;
	@JsonProperty("Secondary Insurance Status")
	private String secondaryInsuranceStatus;
	@JsonProperty("Secondary Insurance Percent Covered")
	private String secondaryInsurancePercentCovered;
	@JsonProperty("Secondary Insurance Reason Not Covered")
	private String secondaryInsuranceReasonNotCovered;
	@JsonProperty("Secondary Insurance Reason NA")
	private String secondaryInsuranceReasonNA;
	@JsonProperty("Tertiary Insurance Policy #")
	private String tertiaryInsurancePolicyNo;
	@JsonProperty("Tertiary Insurance Company")
	private String tertiaryInsuranceCompany;
	@JsonProperty("Tertiary Insurance MAC")
	private String tertiaryInsuranceMac;
	@JsonProperty("Tertiary Insurance Deductible")
	private String tertiaryInsuranceDeductible;
	@JsonProperty("Tertiary Insurance Deductible Met")
	private String tertiaryInsuranceDeductibleMet;
	@JsonProperty("Tertiary Insurance Copay")
	private String tertiaryInsuranceCopay;
	@JsonProperty("Tertiary Insurance Co-Insurance")
	private String tertiaryInsuranceCoInsurance;
	@JsonProperty("Tertiary Insurance OOP Max")
	private String tertiaryInsuranceOOPMax;
	@JsonProperty("Tertiary Insurance OOP Met")
	private String tertiaryInsuranceOOPMet;
	@JsonProperty("Tertiary Insurance Status")
	private String tertiaryInsuranceStatus;
	@JsonProperty("Tertiary Insurance Percent Covered")
	private String tertiaryInsurancePercentCovered;
	@JsonProperty("Tertiary Insurance Reason Not Covered")
	private String tertiaryInsuranceReasonNotCovered;
	@JsonProperty("Tertiary Insurance Reason NA")
	private String tertiaryInsuranceReasonNA;
	@JsonProperty("HCPC")
	private String hcpc;
	@JsonProperty("ICD10 Codes")
	private String icd10Codes;
	@JsonProperty("Place of Service")
	private String placeOfService;
	@JsonProperty("Coverage Summary")
	private String coverageSummary;
	@JsonProperty("SGPDate")
	private String sgpDate;
	@JsonProperty("HL Order #")
	private String hlOrderNo;
	@JsonProperty("HL Patient ID")
	private String hlPatientID;

	// New Update
	@JsonProperty("Vendor Status")
	private String vendorStatus;
	@JsonProperty("Patient DOB")
	private String patientDOB;

	public String getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	public String getVendorRequestId() {
		return vendorRequestId;
	}
	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getDxCode() {
		return dxCode;
	}
	public void setDxCode(String dxCode) {
		this.dxCode = dxCode;
	}
	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public String getSalesPerson() {
		return salesPerson;
	}
	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}
	public String getCreateFrom() {
		return createFrom;
	}
	public void setCreateFrom(String createFrom) {
		this.createFrom = createFrom;
	}
	public String getSgp() {
		return sgp;
	}
	public void setSgp(String sgp) {
		this.sgp = sgp;
	}
	public String getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPrimaryInsuranceCompany() {
		return primaryInsuranceCompany;
	}
	public void setPrimaryInsuranceCompany(String primaryInsuranceCompany) {
		this.primaryInsuranceCompany = primaryInsuranceCompany;
	}
	public String getSecondaryInsuranceCompany() {
		return secondaryInsuranceCompany;
	}
	public void setSecondaryInsuranceCompany(String secondaryInsuranceCompany) {
		this.secondaryInsuranceCompany = secondaryInsuranceCompany;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getPrimarInsuranceStatus() {
		return primarInsuranceStatus;
	}
	public void setPrimarInsuranceStatus(String primarInsuranceStatus) {
		this.primarInsuranceStatus = primarInsuranceStatus;
	}
	public String getHealogicsPilot() {
		return healogicsPilot;
	}
	public void setHealogicsPilot(String healogicsPilot) {
		this.healogicsPilot = healogicsPilot;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPhysicianName() {
		return physicianName;
	}
	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}
	public String getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(String followupDate) {
		this.followupDate = followupDate;
	}
	public String getSpecialInstructions() {
		return specialInstructions;
	}
	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}
	public String getPrimaryInsurancePolicyNo() {
		return primaryInsurancePolicyNo;
	}
	public void setPrimaryInsurancePolicyNo(String primaryInsurancePolicyNo) {
		this.primaryInsurancePolicyNo = primaryInsurancePolicyNo;
	}
	public String getPrimaryInsuranceMac() {
		return primaryInsuranceMac;
	}
	public void setPrimaryInsuranceMac(String primaryInsuranceMac) {
		this.primaryInsuranceMac = primaryInsuranceMac;
	}
	public String getPrimaryInsuranceDeductible() {
		return primaryInsuranceDeductible;
	}
	public void setPrimaryInsuranceDeductible(
			String primaryInsuranceDeductible) {
		this.primaryInsuranceDeductible = primaryInsuranceDeductible;
	}
	public String getPrimaryInsuranceDeductibleMet() {
		return primaryInsuranceDeductibleMet;
	}
	public void setPrimaryInsuranceDeductibleMet(
			String primaryInsuranceDeductibleMet) {
		this.primaryInsuranceDeductibleMet = primaryInsuranceDeductibleMet;
	}
	public String getPrimaryInsuranceCopay() {
		return primaryInsuranceCopay;
	}
	public void setPrimaryInsuranceCopay(String primaryInsuranceCopay) {
		this.primaryInsuranceCopay = primaryInsuranceCopay;
	}
	public String getPrimaryInsuranceCoInsurance() {
		return primaryInsuranceCoInsurance;
	}
	public void setPrimaryInsuranceCoInsurance(
			String primaryInsuranceCoInsurance) {
		this.primaryInsuranceCoInsurance = primaryInsuranceCoInsurance;
	}
	public String getPrimaryInsuranceOOPMax() {
		return primaryInsuranceOOPMax;
	}
	public void setPrimaryInsuranceOOPMax(String primaryInsuranceOOPMax) {
		this.primaryInsuranceOOPMax = primaryInsuranceOOPMax;
	}
	public String getPrimaryInsuranceOOPMet() {
		return primaryInsuranceOOPMet;
	}
	public void setPrimaryInsuranceOOPMet(String primaryInsuranceOOPMet) {
		this.primaryInsuranceOOPMet = primaryInsuranceOOPMet;
	}
	public String getPrimaryInsurancePercentCovered() {
		return primaryInsurancePercentCovered;
	}
	public void setPrimaryInsurancePercentCovered(
			String primaryInsurancePercentCovered) {
		this.primaryInsurancePercentCovered = primaryInsurancePercentCovered;
	}
	public String getPrimaryInsuranceReasonNotCovered() {
		return primaryInsuranceReasonNotCovered;
	}
	public void setPrimaryInsuranceReasonNotCovered(
			String primaryInsuranceReasonNotCovered) {
		this.primaryInsuranceReasonNotCovered = primaryInsuranceReasonNotCovered;
	}
	public String getPrimaryInsuranceReasonNA() {
		return primaryInsuranceReasonNA;
	}
	public void setPrimaryInsuranceReasonNA(String primaryInsuranceReasonNA) {
		this.primaryInsuranceReasonNA = primaryInsuranceReasonNA;
	}
	public String getSecondaryInsurancePolicyNo() {
		return secondaryInsurancePolicyNo;
	}
	public void setSecondaryInsurancePolicyNo(
			String secondaryInsurancePolicyNo) {
		this.secondaryInsurancePolicyNo = secondaryInsurancePolicyNo;
	}
	public String getSecondaryInsuranceMac() {
		return secondaryInsuranceMac;
	}
	public void setSecondaryInsuranceMac(String secondaryInsuranceMac) {
		this.secondaryInsuranceMac = secondaryInsuranceMac;
	}
	public String getSecondaryInsuranceDeductible() {
		return secondaryInsuranceDeductible;
	}
	public void setSecondaryInsuranceDeductible(
			String secondaryInsuranceDeductible) {
		this.secondaryInsuranceDeductible = secondaryInsuranceDeductible;
	}
	public String getSecondaryInsuranceDeductibleMet() {
		return secondaryInsuranceDeductibleMet;
	}
	public void setSecondaryInsuranceDeductibleMet(
			String secondaryInsuranceDeductibleMet) {
		this.secondaryInsuranceDeductibleMet = secondaryInsuranceDeductibleMet;
	}
	public String getSecondaryInsuranceCopay() {
		return secondaryInsuranceCopay;
	}
	public void setSecondaryInsuranceCopay(String secondaryInsuranceCopay) {
		this.secondaryInsuranceCopay = secondaryInsuranceCopay;
	}
	public String getSecondaryInsuranceCoInsurance() {
		return secondaryInsuranceCoInsurance;
	}
	public void setSecondaryInsuranceCoInsurance(
			String secondaryInsuranceCoInsurance) {
		this.secondaryInsuranceCoInsurance = secondaryInsuranceCoInsurance;
	}
	public String getSecondaryInsuranceOOPMax() {
		return secondaryInsuranceOOPMax;
	}
	public void setSecondaryInsuranceOOPMax(String secondaryInsuranceOOPMax) {
		this.secondaryInsuranceOOPMax = secondaryInsuranceOOPMax;
	}
	public String getSecondaryInsuranceOOPMet() {
		return secondaryInsuranceOOPMet;
	}
	public void setSecondaryInsuranceOOPMet(String secondaryInsuranceOOPMet) {
		this.secondaryInsuranceOOPMet = secondaryInsuranceOOPMet;
	}
	public String getSecondaryInsuranceStatus() {
		return secondaryInsuranceStatus;
	}
	public void setSecondaryInsuranceStatus(String secondaryInsuranceStatus) {
		this.secondaryInsuranceStatus = secondaryInsuranceStatus;
	}
	public String getSecondaryInsurancePercentCovered() {
		return secondaryInsurancePercentCovered;
	}
	public void setSecondaryInsurancePercentCovered(
			String secondaryInsurancePercentCovered) {
		this.secondaryInsurancePercentCovered = secondaryInsurancePercentCovered;
	}
	public String getSecondaryInsuranceReasonNotCovered() {
		return secondaryInsuranceReasonNotCovered;
	}
	public void setSecondaryInsuranceReasonNotCovered(
			String secondaryInsuranceReasonNotCovered) {
		this.secondaryInsuranceReasonNotCovered = secondaryInsuranceReasonNotCovered;
	}
	public String getSecondaryInsuranceReasonNA() {
		return secondaryInsuranceReasonNA;
	}
	public void setSecondaryInsuranceReasonNA(
			String secondaryInsuranceReasonNA) {
		this.secondaryInsuranceReasonNA = secondaryInsuranceReasonNA;
	}
	public String getTertiaryInsurancePolicyNo() {
		return tertiaryInsurancePolicyNo;
	}
	public void setTertiaryInsurancePolicyNo(String tertiaryInsurancePolicyNo) {
		this.tertiaryInsurancePolicyNo = tertiaryInsurancePolicyNo;
	}
	public String getTertiaryInsuranceCompany() {
		return tertiaryInsuranceCompany;
	}
	public void setTertiaryInsuranceCompany(String tertiaryInsuranceCompany) {
		this.tertiaryInsuranceCompany = tertiaryInsuranceCompany;
	}
	public String getTertiaryInsuranceMac() {
		return tertiaryInsuranceMac;
	}
	public void setTertiaryInsuranceMac(String tertiaryInsuranceMac) {
		this.tertiaryInsuranceMac = tertiaryInsuranceMac;
	}
	public String getTertiaryInsuranceDeductible() {
		return tertiaryInsuranceDeductible;
	}
	public void setTertiaryInsuranceDeductible(
			String tertiaryInsuranceDeductible) {
		this.tertiaryInsuranceDeductible = tertiaryInsuranceDeductible;
	}
	public String getTertiaryInsuranceDeductibleMet() {
		return tertiaryInsuranceDeductibleMet;
	}
	public void setTertiaryInsuranceDeductibleMet(
			String tertiaryInsuranceDeductibleMet) {
		this.tertiaryInsuranceDeductibleMet = tertiaryInsuranceDeductibleMet;
	}
	public String getTertiaryInsuranceCopay() {
		return tertiaryInsuranceCopay;
	}
	public void setTertiaryInsuranceCopay(String tertiaryInsuranceCopay) {
		this.tertiaryInsuranceCopay = tertiaryInsuranceCopay;
	}
	public String getTertiaryInsuranceCoInsurance() {
		return tertiaryInsuranceCoInsurance;
	}
	public void setTertiaryInsuranceCoInsurance(
			String tertiaryInsuranceCoInsurance) {
		this.tertiaryInsuranceCoInsurance = tertiaryInsuranceCoInsurance;
	}
	public String getTertiaryInsuranceOOPMax() {
		return tertiaryInsuranceOOPMax;
	}
	public void setTertiaryInsuranceOOPMax(String tertiaryInsuranceOOPMax) {
		this.tertiaryInsuranceOOPMax = tertiaryInsuranceOOPMax;
	}
	public String getTertiaryInsuranceOOPMet() {
		return tertiaryInsuranceOOPMet;
	}
	public void setTertiaryInsuranceOOPMet(String tertiaryInsuranceOOPMet) {
		this.tertiaryInsuranceOOPMet = tertiaryInsuranceOOPMet;
	}
	public String getTertiaryInsuranceStatus() {
		return tertiaryInsuranceStatus;
	}
	public void setTertiaryInsuranceStatus(String tertiaryInsuranceStatus) {
		this.tertiaryInsuranceStatus = tertiaryInsuranceStatus;
	}
	public String getTertiaryInsurancePercentCovered() {
		return tertiaryInsurancePercentCovered;
	}
	public void setTertiaryInsurancePercentCovered(
			String tertiaryInsurancePercentCovered) {
		this.tertiaryInsurancePercentCovered = tertiaryInsurancePercentCovered;
	}
	public String getTertiaryInsuranceReasonNotCovered() {
		return tertiaryInsuranceReasonNotCovered;
	}
	public void setTertiaryInsuranceReasonNotCovered(
			String tertiaryInsuranceReasonNotCovered) {
		this.tertiaryInsuranceReasonNotCovered = tertiaryInsuranceReasonNotCovered;
	}
	public String getTertiaryInsuranceReasonNA() {
		return tertiaryInsuranceReasonNA;
	}
	public void setTertiaryInsuranceReasonNA(String tertiaryInsuranceReasonNA) {
		this.tertiaryInsuranceReasonNA = tertiaryInsuranceReasonNA;
	}
	public String getHcpc() {
		return hcpc;
	}
	public void setHcpc(String hcpc) {
		this.hcpc = hcpc;
	}
	public String getIcd10Codes() {
		return icd10Codes;
	}
	public void setIcd10Codes(String icd10Codes) {
		this.icd10Codes = icd10Codes;
	}
	public String getPlaceOfService() {
		return placeOfService;
	}
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}
	public String getCoverageSummary() {
		return coverageSummary;
	}
	public void setCoverageSummary(String coverageSummary) {
		this.coverageSummary = coverageSummary;
	}
	public String getSgpDate() {
		return sgpDate;
	}
	public void setSgpDate(String sgpDate) {
		this.sgpDate = sgpDate;
	}
	public String getHlOrderNo() {
		return hlOrderNo;
	}
	public void setHlOrderNo(String hlOrderNo) {
		this.hlOrderNo = hlOrderNo;
	}
	public String getHlPatientID() {
		return hlPatientID;
	}
	public void setHlPatientID(String hlPatientID) {
		this.hlPatientID = hlPatientID;
	}
	@Override
	public String toString() {
		return "OrderInfoObj [vendorRequestId=" + vendorRequestId
				+ ", facilityName=" + facilityName + ", dxCode=" + dxCode
				+ ", bbc=" + bbc + ", salesPerson=" + salesPerson
				+ ", createFrom=" + createFrom + ", sgp=" + sgp
				+ ", dateCreated=" + dateCreated + ", patientName="
				+ patientName + ", primaryInsuranceCompany="
				+ primaryInsuranceCompany + ", secondaryInsuranceCompany="
				+ secondaryInsuranceCompany + ", caseId=" + caseId
				+ ", primarInsuranceStatus=" + primarInsuranceStatus
				+ ", healogicsPilot=" + healogicsPilot + ", patientId="
				+ patientId + ", physicianName=" + physicianName
				+ ", followupDate=" + followupDate + ", specialInstructions="
				+ specialInstructions + ", primaryInsurancePolicyNo="
				+ primaryInsurancePolicyNo + ", primaryInsuranceMac="
				+ primaryInsuranceMac + ", primaryInsuranceDeductible="
				+ primaryInsuranceDeductible
				+ ", primaryInsuranceDeductibleMet="
				+ primaryInsuranceDeductibleMet + ", primaryInsuranceCopay="
				+ primaryInsuranceCopay + ", primaryInsuranceCoInsurance="
				+ primaryInsuranceCoInsurance + ", primaryInsuranceOOPMax="
				+ primaryInsuranceOOPMax + ", primaryInsuranceOOPMet="
				+ primaryInsuranceOOPMet + ", primaryInsurancePercentCovered="
				+ primaryInsurancePercentCovered
				+ ", primaryInsuranceReasonNotCovered="
				+ primaryInsuranceReasonNotCovered
				+ ", primaryInsuranceReasonNA=" + primaryInsuranceReasonNA
				+ ", secondaryInsurancePolicyNo=" + secondaryInsurancePolicyNo
				+ ", secondaryInsuranceMac=" + secondaryInsuranceMac
				+ ", secondaryInsuranceDeductible="
				+ secondaryInsuranceDeductible
				+ ", secondaryInsuranceDeductibleMet="
				+ secondaryInsuranceDeductibleMet + ", secondaryInsuranceCopay="
				+ secondaryInsuranceCopay + ", secondaryInsuranceCoInsurance="
				+ secondaryInsuranceCoInsurance + ", secondaryInsuranceOOPMax="
				+ secondaryInsuranceOOPMax + ", secondaryInsuranceOOPMet="
				+ secondaryInsuranceOOPMet + ", secondaryInsuranceStatus="
				+ secondaryInsuranceStatus
				+ ", secondaryInsurancePercentCovered="
				+ secondaryInsurancePercentCovered
				+ ", secondaryInsuranceReasonNotCovered="
				+ secondaryInsuranceReasonNotCovered
				+ ", secondaryInsuranceReasonNA=" + secondaryInsuranceReasonNA
				+ ", tertiaryInsurancePolicyNo=" + tertiaryInsurancePolicyNo
				+ ", tertiaryInsuranceCompany=" + tertiaryInsuranceCompany
				+ ", tertiaryInsuranceMac=" + tertiaryInsuranceMac
				+ ", tertiaryInsuranceDeductible=" + tertiaryInsuranceDeductible
				+ ", tertiaryInsuranceDeductibleMet="
				+ tertiaryInsuranceDeductibleMet + ", tertiaryInsuranceCopay="
				+ tertiaryInsuranceCopay + ", tertiaryInsuranceCoInsurance="
				+ tertiaryInsuranceCoInsurance + ", tertiaryInsuranceOOPMax="
				+ tertiaryInsuranceOOPMax + ", tertiaryInsuranceOOPMet="
				+ tertiaryInsuranceOOPMet + ", tertiaryInsuranceStatus="
				+ tertiaryInsuranceStatus + ", tertiaryInsurancePercentCovered="
				+ tertiaryInsurancePercentCovered
				+ ", tertiaryInsuranceReasonNotCovered="
				+ tertiaryInsuranceReasonNotCovered
				+ ", tertiaryInsuranceReasonNA=" + tertiaryInsuranceReasonNA
				+ ", hcpc=" + hcpc + ", icd10Codes=" + icd10Codes
				+ ", placeOfService=" + placeOfService + ", coverageSummary="
				+ coverageSummary + ", sgpDate=" + sgpDate + ", hlOrderNo="
				+ hlOrderNo + ", hlPatientID=" + hlPatientID + ", vendorStatus="
				+ vendorStatus + ", patientDOB=" + patientDOB + "]";
	}

}
