package com.healogics.rtrv.dto;

public class KerecisDocumentRes {
	private int code;
	private int responseCode;
	private String responseMessage;
	
	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "KerecisDocumentRes [code=" + code + ", responseCode="
				+ responseCode + ", responseMessage="
				+ responseMessage + "]";
	}
}
