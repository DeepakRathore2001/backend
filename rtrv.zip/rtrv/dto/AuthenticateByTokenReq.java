package com.healogics.rtrv.dto;

public class AuthenticateByTokenReq {
	private String privateKey;
	private String authenticateToken;
	private String userId;
	private CipherText cipherTexts;

	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getAuthenticateToken() {
		return authenticateToken;
	}
	public void setAuthenticateToken(String authenticateToken) {
		this.authenticateToken = authenticateToken;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public CipherText getCipherTexts() {
		return cipherTexts;
	}
	public void setCipherTexts(CipherText cipherTexts) {
		this.cipherTexts = cipherTexts;
	}

	@Override
	public String toString() {
		return "AuthenticateByTokenReq [privateKey=" + privateKey + ", authenticateToken=" + authenticateToken
				+ ", userId=" + userId + ", cipherTexts=" + cipherTexts + "]";
	}	
}
