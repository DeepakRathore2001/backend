package com.healogics.rtrv.dto;

public class MasterGetDocumentReq {

	private String documentToken;
	private String documentRequestId;

	public String getDocumentToken() {
		return documentToken;
	}
	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}
	public String getDocumentRequestId() {
		return documentRequestId;
	}
	public void setDocumentRequestId(String documentRequestId) {
		this.documentRequestId = documentRequestId;
	}
	@Override
	public String toString() {
		return "MasterGetDocumentReq [documentToken=" + documentToken
				+ ", documentRequestId=" + documentRequestId + "]";
	}

}
