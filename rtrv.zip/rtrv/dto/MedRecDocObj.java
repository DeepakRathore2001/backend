package com.healogics.rtrv.dto;

public class MedRecDocObj {

	private String addedDate;
	private int docEntityId;
	private String docName;
	private String docType;
	private String documentStatus;
	private String groupName;
	private int isSubmitted;
	private Boolean manually;
	private Boolean signed;
	private String testDesc;
	private int versionId;
	private String visitDate;
	private int visitId;

	public String getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(String addedDate) {
		this.addedDate = addedDate;
	}

	public int getDocEntityId() {
		return docEntityId;
	}

	public void setDocEntityId(int docEntityId) {
		this.docEntityId = docEntityId;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public int getIsSubmitted() {
		return isSubmitted;
	}

	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}

	public Boolean getManually() {
		return manually;
	}

	public void setManually(Boolean manually) {
		this.manually = manually;
	}

	public Boolean getSigned() {
		return signed;
	}

	public void setSigned(Boolean signed) {
		this.signed = signed;
	}

	public String getTestDesc() {
		return testDesc;
	}

	public void setTestDesc(String testDesc) {
		this.testDesc = testDesc;
	}

	public int getVersionId() {
		return versionId;
	}

	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}

	public String getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	@Override
	public String toString() {
		return "MedRecDocObj [addedDate=" + addedDate + ", docEntityId=" + docEntityId + ", docName=" + docName
				+ ", docType=" + docType + ", documentStatus=" + documentStatus + ", groupName=" + groupName
				+ ", isSubmitted=" + isSubmitted + ", manually=" + manually + ", signed=" + signed + ", testDesc="
				+ testDesc + ", versionId=" + versionId + ", visitDate=" + visitDate + ", visitId=" + visitId + "]";
	}

}
