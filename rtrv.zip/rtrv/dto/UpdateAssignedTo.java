package com.healogics.rtrv.dto;

public class UpdateAssignedTo {

	private String assigneeUserName;
	private String assigneeFullName;
	private String bhcMedicalRecordId;
	private String bhcInvoiceOrderId;
	private int assigneeChanged;
	public String getAssigneeUserName() {
		return assigneeUserName;
	}
	public void setAssigneeUserName(String assigneeUserName) {
		this.assigneeUserName = assigneeUserName;
	}
	public String getAssigneeFullName() {
		return assigneeFullName;
	}
	public void setAssigneeFullName(String assigneeFullName) {
		this.assigneeFullName = assigneeFullName;
	}
	public String getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}
	public void setBhcMedicalRecordId(String bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}
	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public int getAssigneeChanged() {
		return assigneeChanged;
	}
	public void setAssigneeChanged(int assigneeChanged) {
		this.assigneeChanged = assigneeChanged;
	}
	@Override
	public String toString() {
		return "UpdateAssignedTo [assigneeUserName=" + assigneeUserName
				+ ", assigneeFullName=" + assigneeFullName
				+ ", bhcMedicalRecordId=" + bhcMedicalRecordId
				+ ", bhcInvoiceOrderId=" + bhcInvoiceOrderId
				+ ", assigneeChanged=" + assigneeChanged + "]";
	}

}
