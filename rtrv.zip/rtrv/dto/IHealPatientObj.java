package com.healogics.rtrv.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IHealPatientObj implements Serializable {

	private static final long serialVersionUID = 1L;
	@JsonProperty("PatientId")
	private String patientId;

	@JsonProperty("PatientFirstName")
	private String patientFirstName;

	@JsonProperty("PatientLastName")
	private String patientLastName;

	@JsonProperty("PatientNumber")
	private String patientNumber;

	@JsonProperty("PatientDOB")
	private String patientDOB;

	@JsonProperty("PatientSex")
	private String patientSex;

	@JsonProperty("WeeksInTreatment")
	private String weeksInTreatment;

	@JsonProperty("AdmissionDate")
	private String admissionDate;

	@JsonProperty("PreRegistrationDate")
	private String preregistrationDate;

	@JsonProperty("LocationId")
	private String locationId;

	@JsonProperty("LocationDescription")
	private String locationDescription;

	@JsonProperty("ServiceLineId")
	private String serviceLineId;

	@JsonProperty("ServiceLineDescription")
	private String serviceLineDescription;

	@JsonProperty("DischargeDate")
	private String dischargeDate;

	@JsonProperty("DischargeStatusCode")
	private String dischargeStatusCode;

	@JsonProperty("DischargeStatusDescription")
	private String dischargeStatusDescription;

	public String getDischargeDate() {
		return dischargeDate;
	}
	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}
	public String getDischargeStatusCode() {
		return dischargeStatusCode;
	}
	public void setDischargeStatusCode(String dischargeStatusCode) {
		this.dischargeStatusCode = dischargeStatusCode;
	}
	public String getDischargeStatusDescription() {
		return dischargeStatusDescription;
	}
	public void setDischargeStatusDescription(
			String dischargeStatusDescription) {
		this.dischargeStatusDescription = dischargeStatusDescription;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getPatientNumber() {
		return patientNumber;
	}
	public void setPatientNumber(String patientNumber) {
		this.patientNumber = patientNumber;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	public String getPatientSex() {
		return patientSex;
	}
	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}
	public String getWeeksInTreatment() {
		return weeksInTreatment;
	}
	public void setWeeksInTreatment(String weeksInTreatment) {
		this.weeksInTreatment = weeksInTreatment;
	}
	public String getAdmissionDate() {
		return admissionDate;
	}
	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}
	public String getPreregistrationDate() {
		return preregistrationDate;
	}
	public void setPreregistrationDate(String preregistrationDate) {
		this.preregistrationDate = preregistrationDate;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getLocationDescription() {
		return locationDescription;
	}
	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}
	public String getServiceLineId() {
		return serviceLineId;
	}
	public void setServiceLineId(String serviceLineId) {
		this.serviceLineId = serviceLineId;
	}
	public String getServiceLineDescription() {
		return serviceLineDescription;
	}
	public void setServiceLineDescription(String serviceLineDescription) {
		this.serviceLineDescription = serviceLineDescription;
	}
	@Override
	public String toString() {
		return "IHealPatientObj [patientId=" + patientId + ", patientFirstName="
				+ patientFirstName + ", patientLastName=" + patientLastName
				+ ", patientNumber=" + patientNumber + ", patientDOB="
				+ patientDOB + ", patientSex=" + patientSex
				+ ", weeksInTreatment=" + weeksInTreatment + ", admissionDate="
				+ admissionDate + ", preregistrationDate=" + preregistrationDate
				+ ", locationId=" + locationId + ", locationDescription="
				+ locationDescription + ", serviceLineId=" + serviceLineId
				+ ", serviceLineDescription=" + serviceLineDescription
				+ ", dischargeDate=" + dischargeDate + ", dischargeStatusCode="
				+ dischargeStatusCode + ", dischargeStatusDescription="
				+ dischargeStatusDescription + "]";
	}

}
