package com.healogics.rtrv.dto;

import java.io.Serializable;

import org.joda.time.DateTime;

public class IHealMedRecReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String userId;
	private String eventDateTime;
	private String facilityId;
	private int patientId;
	private DateTime startDate;
	private DateTime endDate;
	private Boolean currentAdmissionOnly;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public DateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(DateTime startDate) {
		this.startDate = startDate;
	}

	public DateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(DateTime endDate) {
		this.endDate = endDate;
	}

	public Boolean getCurrentAdmissionOnly() {
		return currentAdmissionOnly;
	}

	public void setCurrentAdmissionOnly(Boolean currentAdmissionOnly) {
		this.currentAdmissionOnly = currentAdmissionOnly;
	}

	@Override
	public String toString() {
		return "IHealMedRecReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", eventDateTime=" + eventDateTime + ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", currentAdmissionOnly=" + currentAdmissionOnly
				+ "]";
	}

}