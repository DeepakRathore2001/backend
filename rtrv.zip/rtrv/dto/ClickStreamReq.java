package com.healogics.rtrv.dto;

public class ClickStreamReq {
	private String username;
	private Long userId;
	private String userFullname;
	private String bluebookId;
	private int facilityId;
	private String moduleName;
	private String moduleDescription;
	private String serviceLine;
	private String vendor;
	private Long bhcMedRecId;
	private Long bhcInvOrderId;
	
	public Long getBhcMedRecId() {
		return bhcMedRecId;
	}
	public void setBhcMedRecId(Long bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}
	public Long getBhcInvOrderId() {
		return bhcInvOrderId;
	}
	public void setBhcInvOrderId(Long bhcInvOrderId) {
		this.bhcInvOrderId = bhcInvOrderId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserFullname() {
		return userFullname;
	}
	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getModuleDescription() {
		return moduleDescription;
	}
	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	@Override
	public String toString() {
		return "ClickStreamReq [username=" + username + ", userId=" + userId + ", userFullname=" + userFullname
				+ ", bluebookId=" + bluebookId + ", facilityId=" + facilityId + ", moduleName=" + moduleName
				+ ", moduleDescription=" + moduleDescription + ", serviceLine=" + serviceLine + ", vendor=" + vendor
				+ ", bhcMedRecId=" + bhcMedRecId + ", bhcInvOrderId=" + bhcInvOrderId + "]";
	}
}
