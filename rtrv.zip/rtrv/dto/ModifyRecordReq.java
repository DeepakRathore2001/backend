package com.healogics.rtrv.dto;

public class ModifyRecordReq {
	private String bhcMedicalRecordId;
	private String bhcInvoiceOrderNo;
	private String lastUpdatedUsername;
	private Long lastUpdatedUserId;
	private String lastUpdatedUserFullname;
	private int addendum;
	private int recordModify;
	
	public String getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}
	public void setBhcMedicalRecordId(String bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}
	public String getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}
	public void setBhcInvoiceOrderNo(String bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public int getAddendum() {
		return addendum;
	}
	public void setAddendum(int addendum) {
		this.addendum = addendum;
	}
	public int getRecordModify() {
		return recordModify;
	}
	public void setRecordModify(int recordModify) {
		this.recordModify = recordModify;
	}
	
	@Override
	public String toString() {
		return "ModifyRecordReq [bhcMedicalRecordId=" + bhcMedicalRecordId + ", bhcInvoiceOrderNo=" + bhcInvoiceOrderNo
				+ ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserId=" + lastUpdatedUserId
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + ", addendum=" + addendum + ", recordModify="
				+ recordModify + "]";
	}
}
