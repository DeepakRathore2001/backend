package com.healogics.rtrv.dto;

public class MasterGetDocumentRes {

	private String fileStream;
	private String fileName;
	private String errorCode;
	private String errorMessage;

	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileStream() {
		return fileStream;
	}
	public void setFileStream(String fileStream) {
		this.fileStream = fileStream;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "MasterGetDocumentRes [fileStream=" + fileStream + ", fileName=" + fileName + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + "]";
	}

}
