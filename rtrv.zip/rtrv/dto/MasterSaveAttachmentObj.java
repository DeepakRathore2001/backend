package com.healogics.rtrv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MasterSaveAttachmentObj {

	private String documentName;
	private String documentContent;
	private String documentToken;
	private String documentEntityId;
	private String documentType;
	private String documentSource;
	private String addedDate;
	private Boolean isManualDoc;
	@JsonProperty
	private boolean isDeleted;
	@JsonProperty
	private boolean isNewFile;

	private int isSubmitted;
	private String versionId;

	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(String addedDate) {
		this.addedDate = addedDate;
	}
	public Boolean getIsManualDoc() {
		return isManualDoc;
	}
	public void setIsManualDoc(Boolean isManualDoc) {
		this.isManualDoc = isManualDoc;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentContent() {
		return documentContent;
	}
	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}

	public String getDocumentToken() {
		return documentToken;
	}
	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}
	public String getDocumentEntityId() {
		return documentEntityId;
	}
	public void setDocumentEntityId(String documentEntityId) {
		this.documentEntityId = documentEntityId;
	}
	public String getDocumentSource() {
		return documentSource;
	}
	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public int getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public boolean isNewFile() {
		return isNewFile;
	}
	public void setNewFile(boolean isNewFile) {
		this.isNewFile = isNewFile;
	}
	@Override
	public String toString() {
		return "MasterSaveAttachmentObj [documentName=" + documentName + ", documentContent=" + documentContent
				+ ", documentToken=" + documentToken + ", documentEntityId=" + documentEntityId + ", documentType="
				+ documentType + ", documentSource=" + documentSource + ", addedDate=" + addedDate + ", isManualDoc="
				+ isManualDoc + ", isDeleted=" + isDeleted + ", isNewFile=" + isNewFile + ", isSubmitted=" + isSubmitted
				+ ", versionId=" + versionId + "]";
	}

}
