package com.healogics.rtrv.dto;

public class OrderStatusRes extends APIResponse {

}
