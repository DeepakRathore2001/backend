package com.healogics.rtrv.dto;

import java.util.List;

public class SaveNotesReq {
	private String bhcMedicalRecordId;
	private String bhcInvoiceOrderNo;
	private String attemptCategory;
	private String attemptType;
	private String followupDate;
	private Boolean addendumSent;
	private Boolean addendumReceived;
	private Boolean receivedRX;
	private Boolean isRXSent;
	private Boolean patientNotSeen30Days;
	private String description;
	private String patientId;
	private String bluebookId;
	private String facilityId;
	private String patientFullname;
	private String lastUpdatedUsername;
	private String lastUpdatedUserId;
	private String lastUpdatedUserFullname;
	private String status;

	private Boolean userTaggedInNotes;
	private List<UsersInNotes> taggedUsers;
	private String notesId;
	private String lastTeamUpdatedUserFullname;
	private int addendum;
	private int recordModify;
	private String currentStatus;

	public Boolean getIsRXSent() {
		return isRXSent;
	}

	public void setIsRXSent(Boolean isRXSent) {
		this.isRXSent = isRXSent;
	}
	private String contactMethod;

	public String getContactMethod() {
		return contactMethod;
	}

	public void setContactMethod(String contactMethod) {
		this.contactMethod = contactMethod;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public int getRecordModify() {
		return recordModify;
	}

	public void setRecordModify(int recordModify) {
		this.recordModify = recordModify;
	}

	public int getAddendum() {
		return addendum;
	}

	public void setAddendum(int addendum) {
		this.addendum = addendum;
	}

	public String getLastTeamUpdatedUserFullname() {
		return lastTeamUpdatedUserFullname;
	}

	public void setLastTeamUpdatedUserFullname(
			String lastTeamUpdatedUserFullname) {
		this.lastTeamUpdatedUserFullname = lastTeamUpdatedUserFullname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNotesId() {
		return notesId;
	}

	public void setNotesId(String notesId) {
		this.notesId = notesId;
	}

	public List<UsersInNotes> getTaggedUsers() {
		return taggedUsers;
	}

	public void setTaggedUsers(List<UsersInNotes> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}

	public void setUserTaggedInNotes(Boolean userTaggedInNotes) {
		this.userTaggedInNotes = userTaggedInNotes;
	}

	public Boolean getUserTaggedInNotes() {
		return this.userTaggedInNotes;
	}

	public Boolean getAddendumReceived() {
		return addendumReceived;
	}
	public void setAddendumReceived(Boolean addendumReceived) {
		this.addendumReceived = addendumReceived;
	}
	public Boolean getReceivedRX() {
		return receivedRX;
	}
	public void setReceivedRX(Boolean receivedRX) {
		this.receivedRX = receivedRX;
	}
	public Boolean getPatientNotSeen30Days() {
		return patientNotSeen30Days;
	}
	public void setPatientNotSeen30Days(Boolean patientNotSeen30Days) {
		this.patientNotSeen30Days = patientNotSeen30Days;
	}
	public String getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}
	public void setBhcMedicalRecordId(String bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}
	public String getBhcInvoiceOrderNo() {
		return bhcInvoiceOrderNo;
	}
	public void setBhcInvoiceOrderNo(String bhcInvoiceOrderNo) {
		this.bhcInvoiceOrderNo = bhcInvoiceOrderNo;
	}
	public String getAttemptCategory() {
		return attemptCategory;
	}
	public void setAttemptCategory(String attemptCategory) {
		this.attemptCategory = attemptCategory;
	}
	public String getAttemptType() {
		return attemptType;
	}
	public void setAttemptType(String attemptType) {
		this.attemptType = attemptType;
	}
	public String getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(String followupDate) {
		this.followupDate = followupDate;
	}

	public Boolean getAddendumSent() {
		return addendumSent;
	}
	public void setAddendumSent(Boolean addendumSent) {
		this.addendumSent = addendumSent;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientFullname() {
		return patientFullname;
	}
	public void setPatientFullname(String patientFullname) {
		this.patientFullname = patientFullname;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	@Override
	public String toString() {
		return "SaveNotesReq [bhcMedicalRecordId=" + bhcMedicalRecordId + ", bhcInvoiceOrderNo=" + bhcInvoiceOrderNo
				+ ", attemptCategory=" + attemptCategory + ", attemptType=" + attemptType + ", followupDate="
				+ followupDate + ", addendumSent=" + addendumSent + ", addendumReceived=" + addendumReceived
				+ ", receivedRX=" + receivedRX + ", isRXSent=" + isRXSent + ", patientNotSeen30Days="
				+ patientNotSeen30Days + ", description=" + description + ", patientId=" + patientId + ", bluebookId="
				+ bluebookId + ", facilityId=" + facilityId + ", patientFullname=" + patientFullname
				+ ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserId=" + lastUpdatedUserId
				+ ", lastUpdatedUserFullname=" + lastUpdatedUserFullname + ", status=" + status + ", userTaggedInNotes="
				+ userTaggedInNotes + ", taggedUsers=" + taggedUsers + ", notesId=" + notesId
				+ ", lastTeamUpdatedUserFullname=" + lastTeamUpdatedUserFullname + ", addendum=" + addendum
				+ ", recordModify=" + recordModify + ", currentStatus=" + currentStatus + ", contactMethod="
				+ contactMethod + "]";
	}

}
