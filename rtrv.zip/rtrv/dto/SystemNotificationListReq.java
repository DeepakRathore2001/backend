package com.healogics.rtrv.dto;

public class SystemNotificationListReq {

	private String userId;
	private String serviceLine;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	@Override
	public String toString() {
		return "SystemNotificationListReq [userId=" + userId + ", serviceLine="
				+ serviceLine + "]";
	}

}
