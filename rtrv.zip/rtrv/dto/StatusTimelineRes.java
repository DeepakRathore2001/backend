package com.healogics.rtrv.dto;

import java.util.List;

public class StatusTimelineRes {
	private String responseCode;
	private String responseMessage;
	private int curentPage;
	private double totalPage;
	private double nextPage;
	private Long totalCount;
	private boolean isExhausted;
	private List<StatusHistory> statusList;

	public int getCurentPage() {
		return curentPage;
	}
	public void setCurentPage(int curentPage) {
		this.curentPage = curentPage;
	}
	public double getNextPage() {
		return nextPage;
	}
	public void setNextPage(double nextPage) {
		this.nextPage = nextPage;
	}
	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<StatusHistory> getStatusList() {
		return statusList;
	}
	public void setStatusList(List<StatusHistory> statusList) {
		this.statusList = statusList;
	}

	@Override
	public String toString() {
		return "StatusTimelineRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", curentPage="
				+ curentPage + ", totalPage=" + totalPage + ", nextPage="
				+ nextPage + ", totalCount=" + totalCount + ", isExhausted="
				+ isExhausted + ", statusList=" + statusList + "]";
	}
}
