package com.healogics.rtrv.dto;

public class AWDDashboardUserPreference {

	private String colorCodes;
	private String avatarColor;
	public String getColorCodes() {
		return colorCodes;
	}
	public void setColorCodes(String colorCodes) {
		this.colorCodes = colorCodes;
	}
	public String getAvatarColor() {
		return avatarColor;
	}
	public void setAvatarColor(String avatarColor) {
		this.avatarColor = avatarColor;
	}
	@Override
	public String toString() {
		return "AWDDashboardUserPreference [colorCodes=" + colorCodes
				+ ", avatarColor=" + avatarColor + "]";
	}

}
