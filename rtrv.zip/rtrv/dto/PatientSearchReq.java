package com.healogics.rtrv.dto;

import java.io.Serializable;

public class PatientSearchReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private String searchType;
	private String searchValue;
	private String patientFirstName;
	private String patientLastName;
	private String userId;
	private String masterToken;
	private String facilityId;
	private String locationId;
	private String pageIndex;
	private String maxPageSize;
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getSearchValue() {
		return searchValue;
	}
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(String pageIndex) {
		this.pageIndex = pageIndex;
	}
	public String getMaxPageSize() {
		return maxPageSize;
	}
	public void setMaxPageSize(String maxPageSize) {
		this.maxPageSize = maxPageSize;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	@Override
	public String toString() {
		return "PatientSearchReq [searchType=" + searchType + ", searchValue="
				+ searchValue + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", userId=" + userId
				+ ", masterToken=" + masterToken + ", facilityId=" + facilityId
				+ ", locationId=" + locationId + ", pageIndex=" + pageIndex
				+ ", maxPageSize=" + maxPageSize + "]";
	}

}
