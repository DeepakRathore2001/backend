package com.healogics.rtrv.dto;

import java.util.List;
import java.util.Map;

public class UpdateCenteAssignmentReq {


	private List<String> bbc;
	private List<String> businessRoles;
	private String name;
	public List<String> getBbc() {
		return bbc;
	}
	public void setBbc(List<String> bbc) {
		this.bbc = bbc;
	}
	public List<String> getBusinessRoles() {
		return businessRoles;
	}
	public void setBusinessRoles(List<String> businessRoles) {
		this.businessRoles = businessRoles;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "UpdateCenteAssignmentReq [bbc=" + bbc + ", businessRoles=" + businessRoles + ", name=" + name + "]";
	}

}