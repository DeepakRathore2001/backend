package com.healogics.rtrv.dto;

public class ViewAttachmentRes {

	private String responseCode;
	private String responseDesc;
	private String documentStream;
	private String mimeType;
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public String getDocumentStream() {
		return documentStream;
	}
	public void setDocumentStream(String documentStream) {
		this.documentStream = documentStream;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	@Override
	public String toString() {
		return "ViewAttachmentRes [responseCode=" + responseCode
				+ ", responseDesc=" + responseDesc + ", documentStream="
				+ documentStream + ", mimeType=" + mimeType + "]";
	}

}
