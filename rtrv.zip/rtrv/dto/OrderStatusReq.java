package com.healogics.rtrv.dto;

import java.util.Date;

import javax.validation.constraints.Pattern;

public class OrderStatusReq {
	private String orderToken;
	private int vendorId;
	private int facilityId;
	@Pattern(regexp = "^[0-9]+$", message = "Invalid Patient: PatientId can only be a number.")
	private String patientId;
	private Long orderDisplayNumber;
	private String statusIdentifier;
	private String orderStatus;
	private String status;
	private String statusDetail;
	private String vendorOrderNumber;
	private Date shipDate;
	private Date updatedAt;
	private String vendorRequestId;
	private String csrName;
	private String csrPhone;
	private String csrEmail;
	
	public String getCsrName() {
		return csrName;
	}

	public void setCsrName(String csrName) {
		this.csrName = csrName;
	}

	public String getCsrPhone() {
		return csrPhone;
	}

	public void setCsrPhone(String csrPhone) {
		this.csrPhone = csrPhone;
	}

	public String getCsrEmail() {
		return csrEmail;
	}

	public void setCsrEmail(String csrEmail) {
		this.csrEmail = csrEmail;
	}

	public String getVendorRequestId() {
		return vendorRequestId;
	}

	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}

	public String getOrderToken() {
		return orderToken;
	}

	public void setOrderToken(String orderToken) {
		this.orderToken = orderToken;
	}

	public Long getOrderDisplayNumber() {
		return orderDisplayNumber;
	}

	public void setOrderDisplayNumber(Long orderDisplayNumber) {
		this.orderDisplayNumber = orderDisplayNumber;
	}

	public String getStatusIdentifier() {
		return statusIdentifier;
	}

	public void setStatusIdentifier(String statusIdentifier) {
		this.statusIdentifier = statusIdentifier;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusDetail() {
		return statusDetail;
	}

	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}

	public Date getShipDate() {
		return shipDate;
	}

	public void setShipDate(Date shipDate) {
		this.shipDate = shipDate;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getVendorOrderNumber() {
		return vendorOrderNumber;
	}

	public void setVendorOrderNumber(String vendorOrderNumber) {
		this.vendorOrderNumber = vendorOrderNumber;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Override
	public String toString() {
		return "OrderStatusReq [orderToken=" + orderToken + ", vendorId=" + vendorId + ", facilityId=" + facilityId
				+ ", patientId=" + patientId + ", orderDisplayNumber=" + orderDisplayNumber + ", statusIdentifier="
				+ statusIdentifier + ", orderStatus=" + orderStatus + ", status=" + status + ", statusDetail="
				+ statusDetail + ", vendorOrderNumber=" + vendorOrderNumber + ", shipDate=" + shipDate + ", updatedAt="
				+ updatedAt + ", vendorRequestId=" + vendorRequestId + ", csrName=" + csrName + ", csrPhone=" + csrPhone
				+ ", csrEmail=" + csrEmail + "]";
	}
}
