package com.healogics.rtrv.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ManualAttachment {
	private String documentName;
	private String documentContent;
	private String documentId;
	private String documentType;
	@JsonProperty
	private boolean isDeleted;
	@JsonProperty
	private boolean isNewFile;
	private int isSubmitted;

	public int getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public boolean isNewFile() {
		return isNewFile;
	}
	public void setNewFile(boolean isNewFile) {
		this.isNewFile = isNewFile;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentContent() {
		return documentContent;
	}
	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}
	@Override
	public String toString() {
		return "ManualAttachment [documentName=" + documentName
				+ ", documentId=" + documentId + ", documentType=" + documentType + ", isDeleted=" + isDeleted
				+ ", isNewFile=" + isNewFile + ", isSubmitted=" + isSubmitted + "]";
	}
	
	
}
