package com.healogics.rtrv.dto;

import java.util.List;

public class AuthenticateByTokenRes {
	private String masterToken;
	private CipherText plainTexts;
	private IhealUserRes user;
	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	private List<NHWarningDetails> errors;

	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public CipherText getPlainTexts() {
		return plainTexts;
	}
	public void setPlainTexts(CipherText plainTexts) {
		this.plainTexts = plainTexts;
	}
	public IhealUserRes getUser() {
		return user;
	}
	public void setUser(IhealUserRes user) {
		this.user = user;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}
	public List<NHWarningDetails> getErrors() {
		return errors;
	}
	public void setErrors(List<NHWarningDetails> errors) {
		this.errors = errors;
	}
	@Override
	public String toString() {
		return "AuthenticateByTokenRes [masterToken=" + masterToken + ", plainTexts=" + plainTexts + ", user=" + user
				+ ", errorCode=" + errorCode + ", errorMessage=" + errorMessage + ", warnings=" + warnings + ", errors="
				+ errors + "]";
	}
}
