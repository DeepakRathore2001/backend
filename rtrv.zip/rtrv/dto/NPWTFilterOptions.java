package com.healogics.rtrv.dto;

import java.util.Date;
import java.util.List;

public class NPWTFilterOptions {

	private Date minFirstReceivedDate;
	private Date maxFirstReceivedDate;
	private Date minDocumentsFirstSent;
	private Date maxDocumentsFirstSent;
	private Date minDocumentsLastSent;
	private Date maxDocumentsLastSent;

	private List<Object> options;

	public Date getMinFirstReceivedDate() {
		return minFirstReceivedDate;
	}

	public void setMinFirstReceivedDate(Date minFirstReceivedDate) {
		this.minFirstReceivedDate = minFirstReceivedDate;
	}

	public Date getMaxFirstReceivedDate() {
		return maxFirstReceivedDate;
	}

	public void setMaxFirstReceivedDate(Date maxFirstReceivedDate) {
		this.maxFirstReceivedDate = maxFirstReceivedDate;
	}

	public Date getMinDocumentsFirstSent() {
		return minDocumentsFirstSent;
	}

	public void setMinDocumentsFirstSent(Date minDocumentsFirstSent) {
		this.minDocumentsFirstSent = minDocumentsFirstSent;
	}

	public Date getMaxDocumentsFirstSent() {
		return maxDocumentsFirstSent;
	}

	public void setMaxDocumentsFirstSent(Date maxDocumentsFirstSent) {
		this.maxDocumentsFirstSent = maxDocumentsFirstSent;
	}

	public Date getMinDocumentsLastSent() {
		return minDocumentsLastSent;
	}

	public void setMinDocumentsLastSent(Date minDocumentsLastSent) {
		this.minDocumentsLastSent = minDocumentsLastSent;
	}

	public Date getMaxDocumentsLastSent() {
		return maxDocumentsLastSent;
	}

	public void setMaxDocumentsLastSent(Date maxDocumentsLastSent) {
		this.maxDocumentsLastSent = maxDocumentsLastSent;
	}

	public List<Object> getOptions() {
		return options;
	}

	public void setOptions(List<Object> options) {
		this.options = options;
	}

	@Override
	public String toString() {
		return "NPWTFilterOptions [minFirstReceivedDate=" + minFirstReceivedDate + ", maxFirstReceivedDate="
				+ maxFirstReceivedDate + ", minDocumentsFirstSent=" + minDocumentsFirstSent + ", maxDocumentsFirstSent="
				+ maxDocumentsFirstSent + ", minDocumentsLastSent=" + minDocumentsLastSent + ", maxDocumentsLastSent="
				+ maxDocumentsLastSent + ", options=" + options + "]";
	}

}
