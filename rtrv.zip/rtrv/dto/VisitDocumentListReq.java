package com.healogics.rtrv.dto;

public class VisitDocumentListReq {

	private String masterToken;
	private String privateKey;
	private String userId;
	private String facilityId;
	private String patientId;
	private String visitId;
	private String documentType;

	// VisitListGet
	private String startDate;
	private String endDate;

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getVisitId() {
		return visitId;
	}

	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	@Override
	public String toString() {
		return "VisitDocumentListReq [masterToken=" + masterToken
				+ ", privateKey=" + privateKey + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", visitId=" + visitId + ", documentType=" + documentType
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}

}
