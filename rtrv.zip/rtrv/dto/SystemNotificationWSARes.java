package com.healogics.rtrv.dto;

public class SystemNotificationWSARes {

	private String notificationId;
	private String responseCode;
	private String responseDesc;
	public String getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	@Override
	public String toString() {
		return "SystemNotificationWSARes [notificationId=" + notificationId
				+ ", responseCode=" + responseCode + ", responseDesc="
				+ responseDesc + "]";
	}

}
