package com.healogics.rtrv.dto;

public class UpdatePatientDetailsReq {

	private String bhcMedicalRecordId;
	private String bhcInvoiceOrderId;
	private String patientId;
	private String patientMRN;
	private String patientDOB;
	private Boolean patientLinked;
	private String patientLinkUsername;
	private String patientLinkUserId;
	private String patientLinkUserFullname;
	private String patientFirstName;
	private String patientLastName;
	private String requestId;
	
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRequestId() {
		return requestId;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public Boolean getPatientLinked() {
		return patientLinked;
	}
	public void setPatientLinked(Boolean patientLinked) {
		this.patientLinked = patientLinked;
	}
	public String getPatientLinkUsername() {
		return patientLinkUsername;
	}
	public void setPatientLinkUsername(String patientLinkUsername) {
		this.patientLinkUsername = patientLinkUsername;
	}
	public String getPatientLinkUserId() {
		return patientLinkUserId;
	}
	public void setPatientLinkUserId(String patientLinkUserId) {
		this.patientLinkUserId = patientLinkUserId;
	}
	public String getPatientLinkUserFullname() {
		return patientLinkUserFullname;
	}
	public void setPatientLinkUserFullname(String patientLinkUserFullname) {
		this.patientLinkUserFullname = patientLinkUserFullname;
	}
	public String getBhcMedicalRecordId() {
		return bhcMedicalRecordId;
	}
	public void setBhcMedicalRecordId(String bhcMedicalRecordId) {
		this.bhcMedicalRecordId = bhcMedicalRecordId;
	}

	public String getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(String bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientMRN() {
		return patientMRN;
	}
	public void setPatientMRN(String patientMRN) {
		this.patientMRN = patientMRN;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	@Override
	public String toString() {
		return "UpdatePatientDetailsReq [bhcMedicalRecordId=" + bhcMedicalRecordId + ", bhcInvoiceOrderId="
				+ bhcInvoiceOrderId + ", patientId=" + patientId + ", patientMRN=" + patientMRN + ", patientDOB="
				+ patientDOB + ", patientLinked=" + patientLinked + ", patientLinkUsername=" + patientLinkUsername
				+ ", patientLinkUserId=" + patientLinkUserId + ", patientLinkUserFullname=" + patientLinkUserFullname
				+ ", patientFirstName=" + patientFirstName + ", patientLastName=" + patientLastName + ", requestId="
				+ requestId + "]";
	}


}
