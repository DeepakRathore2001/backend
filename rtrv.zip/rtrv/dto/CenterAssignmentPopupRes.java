package com.healogics.rtrv.dto;

import java.util.List;
import java.util.Map;

public class CenterAssignmentPopupRes {

	private String responseCode;
	private String responseMessage;
	private Map<String, List<String>> valuesMap;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public Map<String, List<String>> getValuesMap() {
		return valuesMap;
	}
	public void setValuesMap(Map<String, List<String>> valuesMap) {
		this.valuesMap = valuesMap;
	}
	@Override
	public String toString() {
		return "CenterAssignmentPopupRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", valuesMap="
				+ valuesMap + "]";
	}

}
