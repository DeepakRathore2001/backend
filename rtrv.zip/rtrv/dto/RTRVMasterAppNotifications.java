package com.healogics.rtrv.dto;

import java.sql.Timestamp;

public class RTRVMasterAppNotifications {
	private Long notifcationId;
	private Long userId;
	private String username;
	private boolean readFlag;
	private String notificationType;
	private String hyperlink;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;
	private String userFullname;
	private Long creatorUserId;
	private String creatorUsername;
	private String creatorUserFullname;
	private String description;
	private String userColorCodes;
	private String creatorColorCodes;

	public Long getNotifcationId() {
		return notifcationId;
	}

	public void setNotifcationId(Long notifcationId) {
		this.notifcationId = notifcationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public boolean isReadFlag() {
		return readFlag;
	}

	public void setReadFlag(boolean readFlag) {
		this.readFlag = readFlag;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getHyperlink() {
		return hyperlink;
	}

	public void setHyperlink(String hyperlink) {
		this.hyperlink = hyperlink;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getUserFullname() {
		return userFullname;
	}

	public void setUserFullname(String userFullname) {
		this.userFullname = userFullname;
	}

	public Long getCreatorUserId() {
		return creatorUserId;
	}

	public void setCreatorUserId(Long creatorUserId) {
		this.creatorUserId = creatorUserId;
	}

	public String getCreatorUsername() {
		return creatorUsername;
	}

	public void setCreatorUsername(String creatorUsername) {
		this.creatorUsername = creatorUsername;
	}

	public String getCreatorUserFullname() {
		return creatorUserFullname;
	}

	public void setCreatorUserFullname(String creatorUserFullname) {
		this.creatorUserFullname = creatorUserFullname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getUserColorCodes() {
		return userColorCodes;
	}

	public void setUserColorCodes(String userColorCodes) {
		this.userColorCodes = userColorCodes;
	}

	public String getCreatorColorCodes() {
		return creatorColorCodes;
	}

	public void setCreatorColorCodes(String creatorColorCodes) {
		this.creatorColorCodes = creatorColorCodes;
	}

	@Override
	public String toString() {
		return "RTRVMasterAppNotifications [notifcationId=" + notifcationId + ", userId=" + userId + ", username="
				+ username + ", readFlag=" + readFlag + ", notificationType=" + notificationType + ", hyperlink="
				+ hyperlink + ", createdTimestamp=" + createdTimestamp + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", userFullname=" + userFullname + ", creatorUserId=" + creatorUserId
				+ ", creatorUsername=" + creatorUsername + ", creatorUserFullname=" + creatorUserFullname
				+ ", description=" + description + ", userColorCodes=" + userColorCodes + ", creatorColorCodes="
				+ creatorColorCodes + "]";
	}
}
