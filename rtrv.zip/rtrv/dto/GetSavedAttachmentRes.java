package com.healogics.rtrv.dto;

import java.util.List;

public class GetSavedAttachmentRes {

	private String responseCode;
	private String responseMessage;
	private List<MasterSaveAttachmentObj> documents;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<MasterSaveAttachmentObj> getDocuments() {
		return documents;
	}
	public void setDocuments(List<MasterSaveAttachmentObj> documents) {
		this.documents = documents;
	}
	@Override
	public String toString() {
		return "GetSavedAttachmentRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", documents="
				+ documents + "]";
	}

}
