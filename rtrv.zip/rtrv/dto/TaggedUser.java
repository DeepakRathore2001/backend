package com.healogics.rtrv.dto;

public class TaggedUser {
	private Long userId;
	private String userName;
	private String userFullName;
	private String userEmail;

	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	@Override
	public String toString() {
		return "TaggedUser [userId=" + userId
				+ ", userName=" + userName
				+ ", userFullName=" + userFullName
				+ ", userEmail=" + userEmail + "]";
	}
	
	
}
