package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class MasterChartDetailsObj {

	private String orderId;
	private String requestId;
	private String facilityId;
	private String bbc;
	private String facilityName;
	private Integer healogicsPatientId;
	private String healogicsPatientMRN;
	private String vendorId;
	private String vendorName;
	private String orderSource;
	private String patientFirstName;
	private String patientLastName;
	private String patientName;
	private Date patientDOB;
	private Date receivedDate;
	private String currentStatus;
	private Date pendPriorAuthDate;
	private String pendPriorAuthWaiting;
	private Date underAppealDate;
	private String underAppealStatus;
	private Date followupDate;
	private String missingElements;
	private String specialInstructions;
	private PrimaryInsuranceMaster primaryInsurance;
	private SecondaryInsuranceMaster secondaryInsurance;
	private TertiaryInsuranceMaster tertiaryInsurance;
	private String hcpc;
	private String productSKU;
	private String productName;
	private String noAppApproved;
	private String noUnitsApproved;
	private String approvelTimeframe;

	private List<ICD10Data> icd10Codes;
	private String placeOfService;
	private String woundId;
	private Date completedDate;
	private String completedStatus;
	private String coverageSummary;
	private Timestamp lastUpdatedDate;
	private String lastIpdatedUsername;
	private String lastUpdatedUserFullname;
	private String lastUpdatedUserId;
	private String assignedTo;
	private String assignedToUsername;
	private String assigneeUserId;
	private String retrieveStatus;

	private Date ageDate;
	private String iHealConfiguration;
	private String market;
	private String division;
	private String territory;
	private String facilityPhone;
	private String facilityFax;

	private String docTeamAnalyst;
	private String docTeamClerk;
	private String opsSpecialist;

	private String secondaryStatus;
	private String providerName;
	private Timestamp lastReceived;
	private Timestamp lastActioned;
	private Integer wqOrderId;
	private Timestamp firstReceived;
	private Timestamp lastFileUpdated;
	private String filesSent;
	private String noOfUpdates;

	private String statusChangeNotes;

	private String vendorReferralNo;
	private String orderNo;
	private String caseManagerName;
	private String notes;
	
	private List<String> requestedDocs;
	
	private String csrName;
	private String csrPhone;
	private String csrEmail;
	
	private List<VendorWoundDetails> woundProducts;
	
	public List<VendorWoundDetails> getWoundProducts() {
		return woundProducts;
	}
	public void setWoundProducts(List<VendorWoundDetails> woundProducts) {
		this.woundProducts = woundProducts;
	}
	public String getCsrName() {
		return csrName;
	}
	public void setCsrName(String csrName) {
		this.csrName = csrName;
	}
	public String getCsrPhone() {
		return csrPhone;
	}
	public void setCsrPhone(String csrPhone) {
		this.csrPhone = csrPhone;
	}
	public String getCsrEmail() {
		return csrEmail;
	}
	public void setCsrEmail(String csrEmail) {
		this.csrEmail = csrEmail;
	}
	public List<String> getRequestedDocs() {
		return requestedDocs;
	}
	public void setRequestedDocs(List<String> requestedDocs) {
		this.requestedDocs = requestedDocs;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getCaseManagerName() {
		return caseManagerName;
	}
	public void setCaseManagerName(String caseManagerName) {
		this.caseManagerName = caseManagerName;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getVendorReferralNo() {
		return vendorReferralNo;
	}
	public void setVendorReferralNo(String vendorReferralNo) {
		this.vendorReferralNo = vendorReferralNo;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getStatusChangeNotes() {
		return statusChangeNotes;
	}
	public void setStatusChangeNotes(String statusChangeNotes) {
		this.statusChangeNotes = statusChangeNotes;
	}
	public String getSecondaryStatus() {
		return secondaryStatus;
	}
	public void setSecondaryStatus(String secondaryStatus) {
		this.secondaryStatus = secondaryStatus;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Timestamp getLastReceived() {
		return lastReceived;
	}
	public void setLastReceived(Timestamp lastReceived) {
		this.lastReceived = lastReceived;
	}
	public Timestamp getLastActioned() {
		return lastActioned;
	}
	public void setLastActioned(Timestamp lastActioned) {
		this.lastActioned = lastActioned;
	}

	public Integer getWqOrderId() {
		return wqOrderId;
	}
	public void setWqOrderId(Integer wqOrderId) {
		this.wqOrderId = wqOrderId;
	}
	public Timestamp getFirstReceived() {
		return firstReceived;
	}
	public void setFirstReceived(Timestamp firstReceived) {
		this.firstReceived = firstReceived;
	}
	public Timestamp getLastFileUpdated() {
		return lastFileUpdated;
	}
	public void setLastFileUpdated(Timestamp lastFileUpdated) {
		this.lastFileUpdated = lastFileUpdated;
	}
	public String getFilesSent() {
		return filesSent;
	}
	public void setFilesSent(String filesSent) {
		this.filesSent = filesSent;
	}
	public String getNoOfUpdates() {
		return noOfUpdates;
	}
	public void setNoOfUpdates(String noOfUpdates) {
		this.noOfUpdates = noOfUpdates;
	}
	public Date getAgeDate() {
		return ageDate;
	}
	public void setAgeDate(Date ageDate) {
		this.ageDate = ageDate;
	}

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public Integer getHealogicsPatientId() {
		return healogicsPatientId;
	}
	public void setHealogicsPatientId(Integer healogicsPatientId) {
		this.healogicsPatientId = healogicsPatientId;
	}
	public String getHealogicsPatientMRN() {
		return healogicsPatientMRN;
	}
	public void setHealogicsPatientMRN(String healogicsPatientMRN) {
		this.healogicsPatientMRN = healogicsPatientMRN;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}

	public String getBbc() {
		return bbc;
	}
	public void setBbc(String bbc) {
		this.bbc = bbc;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public Date getPendPriorAuthDate() {
		return pendPriorAuthDate;
	}
	public void setPendPriorAuthDate(Date pendPriorAuthDate) {
		this.pendPriorAuthDate = pendPriorAuthDate;
	}
	public String getPendPriorAuthWaiting() {
		return pendPriorAuthWaiting;
	}
	public void setPendPriorAuthWaiting(String pendPriorAuthWaiting) {
		this.pendPriorAuthWaiting = pendPriorAuthWaiting;
	}
	public Date getUnderAppealDate() {
		return underAppealDate;
	}
	public void setUnderAppealDate(Date underAppealDate) {
		this.underAppealDate = underAppealDate;
	}
	public String getUnderAppealStatus() {
		return underAppealStatus;
	}
	public void setUnderAppealStatus(String underAppealStatus) {
		this.underAppealStatus = underAppealStatus;
	}
	public Date getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(Date followupDate) {
		this.followupDate = followupDate;
	}
	public String getMissingElements() {
		return missingElements;
	}
	public void setMissingElements(String missingElements) {
		this.missingElements = missingElements;
	}
	public String getSpecialInstructions() {
		return specialInstructions;
	}
	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}
	public String getHcpc() {
		return hcpc;
	}
	public void setHcpc(String hcpc) {
		this.hcpc = hcpc;
	}
	public String getProductSKU() {
		return productSKU;
	}
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getNoAppApproved() {
		return noAppApproved;
	}
	public void setNoAppApproved(String noAppApproved) {
		this.noAppApproved = noAppApproved;
	}
	public String getNoUnitsApproved() {
		return noUnitsApproved;
	}
	public void setNoUnitsApproved(String noUnitsApproved) {
		this.noUnitsApproved = noUnitsApproved;
	}
	public String getApprovelTimeframe() {
		return approvelTimeframe;
	}
	public void setApprovelTimeframe(String approvelTimeframe) {
		this.approvelTimeframe = approvelTimeframe;
	}
	public String getPlaceOfService() {
		return placeOfService;
	}
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}
	public String getWoundId() {
		return woundId;
	}
	public void setWoundId(String woundId) {
		this.woundId = woundId;
	}
	public Date getCompletedDate() {
		return completedDate;
	}
	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}
	public String getCompletedStatus() {
		return completedStatus;
	}
	public void setCompletedStatus(String completedStatus) {
		this.completedStatus = completedStatus;
	}
	public String getCoverageSummary() {
		return coverageSummary;
	}
	public void setCoverageSummary(String coverageSummary) {
		this.coverageSummary = coverageSummary;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getLastIpdatedUsername() {
		return lastIpdatedUsername;
	}
	public void setLastIpdatedUsername(String lastIpdatedUsername) {
		this.lastIpdatedUsername = lastIpdatedUsername;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getAssignedToUsername() {
		return assignedToUsername;
	}
	public void setAssignedToUsername(String assignedToUsername) {
		this.assignedToUsername = assignedToUsername;
	}
	public String getAssigneeUserId() {
		return assigneeUserId;
	}
	public void setAssigneeUserId(String assigneeUserId) {
		this.assigneeUserId = assigneeUserId;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}

	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getTerritory() {
		return territory;
	}
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	public String getFacilityPhone() {
		return facilityPhone;
	}
	public void setFacilityPhone(String facilityPhone) {
		this.facilityPhone = facilityPhone;
	}
	public String getFacilityFax() {
		return facilityFax;
	}
	public void setFacilityFax(String facilityFax) {
		this.facilityFax = facilityFax;
	}
	public String getDocTeamAnalyst() {
		return docTeamAnalyst;
	}
	public void setDocTeamAnalyst(String docTeamAnalyst) {
		this.docTeamAnalyst = docTeamAnalyst;
	}
	public String getDocTeamClerk() {
		return docTeamClerk;
	}
	public void setDocTeamClerk(String docTeamClerk) {
		this.docTeamClerk = docTeamClerk;
	}
	public String getOpsSpecialist() {
		return opsSpecialist;
	}
	public void setOpsSpecialist(String opsSpecialist) {
		this.opsSpecialist = opsSpecialist;
	}

	public PrimaryInsuranceMaster getPrimaryInsurance() {
		return primaryInsurance;
	}
	public void setPrimaryInsurance(PrimaryInsuranceMaster primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}
	public SecondaryInsuranceMaster getSecondaryInsurance() {
		return secondaryInsurance;
	}
	public void setSecondaryInsurance(
			SecondaryInsuranceMaster secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}
	public TertiaryInsuranceMaster getTertiaryInsurance() {
		return tertiaryInsurance;
	}
	public void setTertiaryInsurance(
			TertiaryInsuranceMaster tertiaryInsurance) {
		this.tertiaryInsurance = tertiaryInsurance;
	}
	public List<ICD10Data> getIcd10Codes() {
		return icd10Codes;
	}
	public void setIcd10Codes(List<ICD10Data> icd10Codes) {
		this.icd10Codes = icd10Codes;
	}
	@Override
	public String toString() {
		return "MasterChartDetailsObj [orderId=" + orderId + ", requestId=" + requestId + ", facilityId=" + facilityId
				+ ", bbc=" + bbc + ", facilityName=" + facilityName + ", healogicsPatientId=" + healogicsPatientId
				+ ", healogicsPatientMRN=" + healogicsPatientMRN + ", vendorId=" + vendorId + ", vendorName="
				+ vendorName + ", orderSource=" + orderSource + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientName=" + patientName + ", patientDOB=" + patientDOB
				+ ", receivedDate=" + receivedDate + ", currentStatus=" + currentStatus + ", pendPriorAuthDate="
				+ pendPriorAuthDate + ", pendPriorAuthWaiting=" + pendPriorAuthWaiting + ", underAppealDate="
				+ underAppealDate + ", underAppealStatus=" + underAppealStatus + ", followupDate=" + followupDate
				+ ", missingElements=" + missingElements + ", specialInstructions=" + specialInstructions
				+ ", primaryInsurance=" + primaryInsurance + ", secondaryInsurance=" + secondaryInsurance
				+ ", tertiaryInsurance=" + tertiaryInsurance + ", hcpc=" + hcpc + ", productSKU=" + productSKU
				+ ", productName=" + productName + ", noAppApproved=" + noAppApproved + ", noUnitsApproved="
				+ noUnitsApproved + ", approvelTimeframe=" + approvelTimeframe + ", icd10Codes=" + icd10Codes
				+ ", placeOfService=" + placeOfService + ", woundId=" + woundId + ", completedDate=" + completedDate
				+ ", completedStatus=" + completedStatus + ", coverageSummary=" + coverageSummary + ", lastUpdatedDate="
				+ lastUpdatedDate + ", lastIpdatedUsername=" + lastIpdatedUsername + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUserId=" + lastUpdatedUserId + ", assignedTo=" + assignedTo
				+ ", assignedToUsername=" + assignedToUsername + ", assigneeUserId=" + assigneeUserId
				+ ", retrieveStatus=" + retrieveStatus + ", ageDate=" + ageDate + ", iHealConfiguration="
				+ iHealConfiguration + ", market=" + market + ", division=" + division + ", territory=" + territory
				+ ", facilityPhone=" + facilityPhone + ", facilityFax=" + facilityFax + ", docTeamAnalyst="
				+ docTeamAnalyst + ", docTeamClerk=" + docTeamClerk + ", opsSpecialist=" + opsSpecialist
				+ ", secondaryStatus=" + secondaryStatus + ", providerName=" + providerName + ", lastReceived="
				+ lastReceived + ", lastActioned=" + lastActioned + ", wqOrderId=" + wqOrderId + ", firstReceived="
				+ firstReceived + ", lastFileUpdated=" + lastFileUpdated + ", filesSent=" + filesSent + ", noOfUpdates="
				+ noOfUpdates + ", statusChangeNotes=" + statusChangeNotes + ", vendorReferralNo=" + vendorReferralNo
				+ ", orderNo=" + orderNo + ", caseManagerName=" + caseManagerName + ", notes=" + notes
				+ ", requestedDocs=" + requestedDocs + ", csrName=" + csrName + ", csrPhone=" + csrPhone + ", csrEmail="
				+ csrEmail + ", woundProducts=" + woundProducts + "]";
	}

}
