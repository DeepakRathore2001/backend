package com.healogics.rtrv.dto;

import java.sql.Timestamp;
import java.util.List;

public class MasterHistoryTimelineDetails {
	private Integer historyId;
	private Timestamp lastUpdatedTimestamp;
	private String lastUpdatedUsername;
	private String lastUpdatedUserFullname;
	private Long lastUpdatedUserId;
	private String retrieveStatus;
	private HistoryUserNotes userNotes;
	private VendorStatus vendorStatus;
	private List<HistoryTimelineDocStatus> documentStatus;
	
	public List<HistoryTimelineDocStatus> getDocumentStatus() {
		return documentStatus;
	}
	public void setDocumentStatus(List<HistoryTimelineDocStatus> documentStatus) {
		this.documentStatus = documentStatus;
	}
	public HistoryUserNotes getUserNotes() {
		return userNotes;
	}
	public void setUserNotes(HistoryUserNotes userNotes) {
		this.userNotes = userNotes;
	}
	public VendorStatus getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(VendorStatus vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public Integer getHistoryId() {
		return historyId;
	}
	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public Long getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(Long lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	@Override
	public String toString() {
		return "MasterHistoryTimelineDetails [historyId=" + historyId + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", lastUpdatedUsername=" + lastUpdatedUsername + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUserId=" + lastUpdatedUserId + ", retrieveStatus="
				+ retrieveStatus + ", userNotes=" + userNotes + ", vendorStatus=" + vendorStatus + ", documentStatus="
				+ documentStatus + "]";
	}
}
