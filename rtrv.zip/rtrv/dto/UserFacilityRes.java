package com.healogics.rtrv.dto;

import java.util.List;

public class UserFacilityRes {
	private List<UserFacilities> facilities;
	private String responseCode;
	private String responseDesc;
	public List<UserFacilities> getFacilities() {
		return facilities;
	}
	public void setFacilities(List<UserFacilities> facilities) {
		this.facilities = facilities;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	@Override
	public String toString() {
		return "UserFacilityRes [facilities=" + facilities + ", responseCode="
				+ responseCode + ", responseDesc=" + responseDesc + "]";
	}
}
