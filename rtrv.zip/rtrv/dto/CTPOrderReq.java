package com.healogics.rtrv.dto;

import java.util.Date;

public class CTPOrderReq {
	private String vendorReferenceId;
	private String vendorId;
	private String orderSource;
	private String patientFirstName;
	private String patientLastName;
	private String patientDOB;
	private String physicianFirstName;
	private String physicianLastName;
	private String caseManagerFirstName;
	private String caseManagerLastName;
	private String orderReceivedDate;
	private String currentStatus;
	private String missingElementsNotes;

	private String vendorReferralNo;
	private String healogicsOrderNo;
	private String healogicsPatientID;
	private String healogicsPatientMRN;
	private String waitingOnDocs;
	private String pendingPriorAuthDate;
	private String pendingPriorAuthWaiting;
	private String preAppAppealDate;
	private String postAppAppealDate;
	private String postAppAppealStatus;
	private String followupDate;
	private String notes;
	private String specialInstructions;
	private String primaryInsName;
	private String primaryInsPolicyNo;
	private String primaryInsCompany;
	private String primaryInsMac;
	private String primaryInsDeductible;
	private String primaryInsDeducMet;
	private String primaryInsCopay;
	private String primaryInsCoinsurance;
	private String primaryInsOOPMax;
	private String primaryInsOOPMet;
	private String primaryInsStatus;
	private String primaryInsPercentCovered;
	private String primaryInsReasonNotCovered;
	private String primaryInsReasonNA;
	private String secondaryInsName;
	private String secondaryInsCompany;
	private String secondaryInsMac;
	private String secondaryInsPolicyNo;
	private String secondaryInsDeductible;
	private String secondaryInsDeducMet;
	private String secondaryInsCopay;
	private String secondaryInsCoinsurance;
	private String secondaryInsOOPMax;
	private String secondaryInsOOPMet;
	private String secondaryInsStatus;
	private String secondaryInsPercentCovered;
	private String secondaryInsReasonNotCovered;
	private String secondaryInsReasonNA;
	private String tertiaryInsName;
	private String tertiaryInsPolicyNo;
	private String tertiaryInsCompany;
	private String tertiaryInsMac;
	private String tertiaryInsDeductible;
	private String tertiaryInsDeducMet;
	private String tertiaryInsCopay;
	private String tertiaryInsCoinsurance;
	private String tertiaryInsOOPMax;
	private String tertiaryInsOOPMet;
	private String tertiaryInsStatus;
	private String tertiaryInsPercentCovered;
	private String tertiaryInsReasonNotCovered;
	private String tertiaryInsReasonNA;
	private String hcpc;
	private String productSKU;
	private String productName;
	private String noOfAppApproved;
	private String noOfUnitsApproved;
	private String approvalTimeframe;
	private String ICD10Codes;
	private String placeOfService;
	private String woundNumber;
	private String completedDate;
	private String completedStatus;
	private String coverageSummary;
	private String insertTimestamp;
	private String salesRepManager;
	private String regionalDirector;
	private String sgp;
	private String sgpDate;
	private String sgpctpCode;
	
	private String facilityId;
	private String bluebookId;
	private Long patientId;
	
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getVendorReferralNo() {
		return vendorReferralNo;
	}
	public void setVendorReferralNo(String vendorReferralNo) {
		this.vendorReferralNo = vendorReferralNo;
	}
	public String getHealogicsOrderNo() {
		return healogicsOrderNo;
	}
	public void setHealogicsOrderNo(String healogicsOrderNo) {
		this.healogicsOrderNo = healogicsOrderNo;
	}
	public String getHealogicsPatientID() {
		return healogicsPatientID;
	}
	public void setHealogicsPatientID(String healogicsPatientID) {
		this.healogicsPatientID = healogicsPatientID;
	}
	public String getHealogicsPatientMRN() {
		return healogicsPatientMRN;
	}
	public void setHealogicsPatientMRN(String healogicsPatientMRN) {
		this.healogicsPatientMRN = healogicsPatientMRN;
	}
	public String getWaitingOnDocs() {
		return waitingOnDocs;
	}
	public void setWaitingOnDocs(String waitingOnDocs) {
		this.waitingOnDocs = waitingOnDocs;
	}

	public String getPendingPriorAuthWaiting() {
		return pendingPriorAuthWaiting;
	}
	public void setPendingPriorAuthWaiting(String pendingPriorAuthWaiting) {
		this.pendingPriorAuthWaiting = pendingPriorAuthWaiting;
	}

	public String getPostAppAppealStatus() {
		return postAppAppealStatus;
	}
	public void setPostAppAppealStatus(String postAppAppealStatus) {
		this.postAppAppealStatus = postAppAppealStatus;
	}
	public String getFollowupDate() {
		return followupDate;
	}
	public void setFollowupDate(String followupDate) {
		this.followupDate = followupDate;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getSpecialInstructions() {
		return specialInstructions;
	}
	public void setSpecialInstructions(String specialInstructions) {
		this.specialInstructions = specialInstructions;
	}
	public String getPrimaryInsName() {
		return primaryInsName;
	}
	public void setPrimaryInsName(String primaryInsName) {
		this.primaryInsName = primaryInsName;
	}
	public String getPrimaryInsPolicyNo() {
		return primaryInsPolicyNo;
	}
	public void setPrimaryInsPolicyNo(String primaryInsPolicyNo) {
		this.primaryInsPolicyNo = primaryInsPolicyNo;
	}
	public String getPrimaryInsCompany() {
		return primaryInsCompany;
	}
	public void setPrimaryInsCompany(String primaryInsCompany) {
		this.primaryInsCompany = primaryInsCompany;
	}
	public String getPrimaryInsMac() {
		return primaryInsMac;
	}
	public void setPrimaryInsMac(String primaryInsMac) {
		this.primaryInsMac = primaryInsMac;
	}
	public String getPrimaryInsDeductible() {
		return primaryInsDeductible;
	}
	public void setPrimaryInsDeductible(String primaryInsDeductible) {
		this.primaryInsDeductible = primaryInsDeductible;
	}
	public String getPrimaryInsDeducMet() {
		return primaryInsDeducMet;
	}
	public void setPrimaryInsDeducMet(String primaryInsDeducMet) {
		this.primaryInsDeducMet = primaryInsDeducMet;
	}
	public String getPrimaryInsCopay() {
		return primaryInsCopay;
	}
	public void setPrimaryInsCopay(String primaryInsCopay) {
		this.primaryInsCopay = primaryInsCopay;
	}
	public String getPrimaryInsCoinsurance() {
		return primaryInsCoinsurance;
	}
	public void setPrimaryInsCoinsurance(String primaryInsCoinsurance) {
		this.primaryInsCoinsurance = primaryInsCoinsurance;
	}
	public String getPrimaryInsOOPMax() {
		return primaryInsOOPMax;
	}
	public void setPrimaryInsOOPMax(String primaryInsOOPMax) {
		this.primaryInsOOPMax = primaryInsOOPMax;
	}
	public String getPrimaryInsOOPMet() {
		return primaryInsOOPMet;
	}
	public void setPrimaryInsOOPMet(String primaryInsOOPMet) {
		this.primaryInsOOPMet = primaryInsOOPMet;
	}
	public String getPrimaryInsStatus() {
		return primaryInsStatus;
	}
	public void setPrimaryInsStatus(String primaryInsStatus) {
		this.primaryInsStatus = primaryInsStatus;
	}
	public String getPrimaryInsPercentCovered() {
		return primaryInsPercentCovered;
	}
	public void setPrimaryInsPercentCovered(String primaryInsPercentCovered) {
		this.primaryInsPercentCovered = primaryInsPercentCovered;
	}
	public String getPrimaryInsReasonNotCovered() {
		return primaryInsReasonNotCovered;
	}
	public void setPrimaryInsReasonNotCovered(
			String primaryInsReasonNotCovered) {
		this.primaryInsReasonNotCovered = primaryInsReasonNotCovered;
	}
	public String getPrimaryInsReasonNA() {
		return primaryInsReasonNA;
	}
	public void setPrimaryInsReasonNA(String primaryInsReasonNA) {
		this.primaryInsReasonNA = primaryInsReasonNA;
	}
	public String getSecondaryInsName() {
		return secondaryInsName;
	}
	public void setSecondaryInsName(String secondaryInsName) {
		this.secondaryInsName = secondaryInsName;
	}
	public String getSecondaryInsCompany() {
		return secondaryInsCompany;
	}
	public void setSecondaryInsCompany(String secondaryInsCompany) {
		this.secondaryInsCompany = secondaryInsCompany;
	}
	public String getSecondaryInsMac() {
		return secondaryInsMac;
	}
	public void setSecondaryInsMac(String secondaryInsMac) {
		this.secondaryInsMac = secondaryInsMac;
	}
	public String getSecondaryInsPolicyNo() {
		return secondaryInsPolicyNo;
	}
	public void setSecondaryInsPolicyNo(String secondaryInsPolicyNo) {
		this.secondaryInsPolicyNo = secondaryInsPolicyNo;
	}
	public String getSecondaryInsDeductible() {
		return secondaryInsDeductible;
	}
	public void setSecondaryInsDeductible(String secondaryInsDeductible) {
		this.secondaryInsDeductible = secondaryInsDeductible;
	}
	public String getSecondaryInsDeducMet() {
		return secondaryInsDeducMet;
	}
	public void setSecondaryInsDeducMet(String secondaryInsDeducMet) {
		this.secondaryInsDeducMet = secondaryInsDeducMet;
	}
	public String getSecondaryInsCopay() {
		return secondaryInsCopay;
	}
	public void setSecondaryInsCopay(String secondaryInsCopay) {
		this.secondaryInsCopay = secondaryInsCopay;
	}
	public String getSecondaryInsCoinsurance() {
		return secondaryInsCoinsurance;
	}
	public void setSecondaryInsCoinsurance(String secondaryInsCoinsurance) {
		this.secondaryInsCoinsurance = secondaryInsCoinsurance;
	}
	public String getSecondaryInsOOPMax() {
		return secondaryInsOOPMax;
	}
	public void setSecondaryInsOOPMax(String secondaryInsOOPMax) {
		this.secondaryInsOOPMax = secondaryInsOOPMax;
	}
	public String getSecondaryInsOOPMet() {
		return secondaryInsOOPMet;
	}
	public void setSecondaryInsOOPMet(String secondaryInsOOPMet) {
		this.secondaryInsOOPMet = secondaryInsOOPMet;
	}
	public String getSecondaryInsStatus() {
		return secondaryInsStatus;
	}
	public void setSecondaryInsStatus(String secondaryInsStatus) {
		this.secondaryInsStatus = secondaryInsStatus;
	}
	public String getSecondaryInsPercentCovered() {
		return secondaryInsPercentCovered;
	}
	public void setSecondaryInsPercentCovered(
			String secondaryInsPercentCovered) {
		this.secondaryInsPercentCovered = secondaryInsPercentCovered;
	}
	public String getSecondaryInsReasonNotCovered() {
		return secondaryInsReasonNotCovered;
	}
	public void setSecondaryInsReasonNotCovered(
			String secondaryInsReasonNotCovered) {
		this.secondaryInsReasonNotCovered = secondaryInsReasonNotCovered;
	}
	public String getSecondaryInsReasonNA() {
		return secondaryInsReasonNA;
	}
	public void setSecondaryInsReasonNA(String secondaryInsReasonNA) {
		this.secondaryInsReasonNA = secondaryInsReasonNA;
	}
	public String getTertiaryInsName() {
		return tertiaryInsName;
	}
	public void setTertiaryInsName(String tertiaryInsName) {
		this.tertiaryInsName = tertiaryInsName;
	}
	public String getTertiaryInsPolicyNo() {
		return tertiaryInsPolicyNo;
	}
	public void setTertiaryInsPolicyNo(String tertiaryInsPolicyNo) {
		this.tertiaryInsPolicyNo = tertiaryInsPolicyNo;
	}
	public String getTertiaryInsCompany() {
		return tertiaryInsCompany;
	}
	public void setTertiaryInsCompany(String tertiaryInsCompany) {
		this.tertiaryInsCompany = tertiaryInsCompany;
	}
	public String getTertiaryInsMac() {
		return tertiaryInsMac;
	}
	public void setTertiaryInsMac(String tertiaryInsMac) {
		this.tertiaryInsMac = tertiaryInsMac;
	}
	public String getTertiaryInsDeductible() {
		return tertiaryInsDeductible;
	}
	public void setTertiaryInsDeductible(String tertiaryInsDeductible) {
		this.tertiaryInsDeductible = tertiaryInsDeductible;
	}
	public String getTertiaryInsDeducMet() {
		return tertiaryInsDeducMet;
	}
	public void setTertiaryInsDeducMet(String tertiaryInsDeducMet) {
		this.tertiaryInsDeducMet = tertiaryInsDeducMet;
	}
	public String getTertiaryInsCopay() {
		return tertiaryInsCopay;
	}
	public void setTertiaryInsCopay(String tertiaryInsCopay) {
		this.tertiaryInsCopay = tertiaryInsCopay;
	}
	public String getTertiaryInsCoinsurance() {
		return tertiaryInsCoinsurance;
	}
	public void setTertiaryInsCoinsurance(String tertiaryInsCoinsurance) {
		this.tertiaryInsCoinsurance = tertiaryInsCoinsurance;
	}
	public String getTertiaryInsOOPMax() {
		return tertiaryInsOOPMax;
	}
	public void setTertiaryInsOOPMax(String tertiaryInsOOPMax) {
		this.tertiaryInsOOPMax = tertiaryInsOOPMax;
	}
	public String getTertiaryInsOOPMet() {
		return tertiaryInsOOPMet;
	}
	public void setTertiaryInsOOPMet(String tertiaryInsOOPMet) {
		this.tertiaryInsOOPMet = tertiaryInsOOPMet;
	}
	public String getTertiaryInsStatus() {
		return tertiaryInsStatus;
	}
	public void setTertiaryInsStatus(String tertiaryInsStatus) {
		this.tertiaryInsStatus = tertiaryInsStatus;
	}
	public String getTertiaryInsPercentCovered() {
		return tertiaryInsPercentCovered;
	}
	public void setTertiaryInsPercentCovered(String tertiaryInsPercentCovered) {
		this.tertiaryInsPercentCovered = tertiaryInsPercentCovered;
	}
	public String getTertiaryInsReasonNotCovered() {
		return tertiaryInsReasonNotCovered;
	}
	public void setTertiaryInsReasonNotCovered(
			String tertiaryInsReasonNotCovered) {
		this.tertiaryInsReasonNotCovered = tertiaryInsReasonNotCovered;
	}
	public String getTertiaryInsReasonNA() {
		return tertiaryInsReasonNA;
	}
	public void setTertiaryInsReasonNA(String tertiaryInsReasonNA) {
		this.tertiaryInsReasonNA = tertiaryInsReasonNA;
	}
	public String getHcpc() {
		return hcpc;
	}
	public void setHcpc(String hcpc) {
		this.hcpc = hcpc;
	}
	public String getProductSKU() {
		return productSKU;
	}
	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getNoOfAppApproved() {
		return noOfAppApproved;
	}
	public void setNoOfAppApproved(String noOfAppApproved) {
		this.noOfAppApproved = noOfAppApproved;
	}
	public String getNoOfUnitsApproved() {
		return noOfUnitsApproved;
	}
	public void setNoOfUnitsApproved(String noOfUnitsApproved) {
		this.noOfUnitsApproved = noOfUnitsApproved;
	}
	public String getApprovalTimeframe() {
		return approvalTimeframe;
	}
	public void setApprovalTimeframe(String approvalTimeframe) {
		this.approvalTimeframe = approvalTimeframe;
	}
	public String getICD10Codes() {
		return ICD10Codes;
	}
	public void setICD10Codes(String iCD10Codes) {
		ICD10Codes = iCD10Codes;
	}
	public String getPlaceOfService() {
		return placeOfService;
	}
	public void setPlaceOfService(String placeOfService) {
		this.placeOfService = placeOfService;
	}
	public String getWoundNumber() {
		return woundNumber;
	}
	public void setWoundNumber(String woundNumber) {
		this.woundNumber = woundNumber;
	}
	public String getCompletedDate() {
		return completedDate;
	}
	public void setCompletedDate(String completedDate) {
		this.completedDate = completedDate;
	}
	public String getCompletedStatus() {
		return completedStatus;
	}
	public void setCompletedStatus(String completedStatus) {
		this.completedStatus = completedStatus;
	}
	public String getCoverageSummary() {
		return coverageSummary;
	}
	public void setCoverageSummary(String coverageSummary) {
		this.coverageSummary = coverageSummary;
	}
	public String getInsertTimestamp() {
		return insertTimestamp;
	}
	public void setInsertTimestamp(String insertTimestamp) {
		this.insertTimestamp = insertTimestamp;
	}
	public String getSalesRepManager() {
		return salesRepManager;
	}
	public void setSalesRepManager(String salesRepManager) {
		this.salesRepManager = salesRepManager;
	}
	public String getRegionalDirector() {
		return regionalDirector;
	}
	public void setRegionalDirector(String regionalDirector) {
		this.regionalDirector = regionalDirector;
	}
	public String getSgp() {
		return sgp;
	}
	public void setSgp(String sgp) {
		this.sgp = sgp;
	}
	public String getSgpDate() {
		return sgpDate;
	}
	public void setSgpDate(String sgpDate) {
		this.sgpDate = sgpDate;
	}
	public String getSgpctpCode() {
		return sgpctpCode;
	}
	public void setSgpctpCode(String sgpctpCode) {
		this.sgpctpCode = sgpctpCode;
	}
	public String getVendorReferenceId() {
		return vendorReferenceId;
	}
	public void setVendorReferenceId(String vendorReferenceId) {
		this.vendorReferenceId = vendorReferenceId;
	}

	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getPendingPriorAuthDate() {
		return pendingPriorAuthDate;
	}
	public void setPendingPriorAuthDate(String pendingPriorAuthDate) {
		this.pendingPriorAuthDate = pendingPriorAuthDate;
	}
	public String getPreAppAppealDate() {
		return preAppAppealDate;
	}
	public void setPreAppAppealDate(String preAppAppealDate) {
		this.preAppAppealDate = preAppAppealDate;
	}
	public String getPostAppAppealDate() {
		return postAppAppealDate;
	}
	public void setPostAppAppealDate(String postAppAppealDate) {
		this.postAppAppealDate = postAppAppealDate;
	}
	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	public String getPhysicianFirstName() {
		return physicianFirstName;
	}
	public void setPhysicianFirstName(String physicianFirstName) {
		this.physicianFirstName = physicianFirstName;
	}
	public String getPhysicianLastName() {
		return physicianLastName;
	}
	public void setPhysicianLastName(String physicianLastName) {
		this.physicianLastName = physicianLastName;
	}
	public String getCaseManagerFirstName() {
		return caseManagerFirstName;
	}
	public void setCaseManagerFirstName(String caseManagerFirstName) {
		this.caseManagerFirstName = caseManagerFirstName;
	}
	public String getCaseManagerLastName() {
		return caseManagerLastName;
	}
	public void setCaseManagerLastName(String caseManagerLastName) {
		this.caseManagerLastName = caseManagerLastName;
	}
	public String getOrderReceivedDate() {
		return orderReceivedDate;
	}
	public void setOrderReceivedDate(String orderReceivedDate) {
		this.orderReceivedDate = orderReceivedDate;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getMissingElementsNotes() {
		return missingElementsNotes;
	}
	public void setMissingElementsNotes(String missingElementsNotes) {
		this.missingElementsNotes = missingElementsNotes;
	}
	@Override
	public String toString() {
		return "CTPOrderReq [vendorReferenceId=" + vendorReferenceId
				+ ", vendorId=" + vendorId + ", orderSource=" + orderSource
				+ ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", patientDOB="
				+ patientDOB + ", physicianFirstName=" + physicianFirstName
				+ ", physicianLastName=" + physicianLastName
				+ ", caseManagerFirstName=" + caseManagerFirstName
				+ ", caseManagerLastName=" + caseManagerLastName
				+ ", orderReceivedDate=" + orderReceivedDate
				+ ", currentStatus=" + currentStatus + ", missingElementsNotes="
				+ missingElementsNotes + ", vendorReferralNo="
				+ vendorReferralNo + ", healogicsOrderNo=" + healogicsOrderNo
				+ ", healogicsPatientID=" + healogicsPatientID
				+ ", healogicsPatientMRN=" + healogicsPatientMRN
				+ ", waitingOnDocs=" + waitingOnDocs + ", pendingPriorAuthDate="
				+ pendingPriorAuthDate + ", pendingPriorAuthWaiting="
				+ pendingPriorAuthWaiting + ", preAppAppealDate="
				+ preAppAppealDate + ", postAppAppealDate=" + postAppAppealDate
				+ ", postAppAppealStatus=" + postAppAppealStatus
				+ ", followupDate=" + followupDate + ", notes=" + notes
				+ ", specialInstructions=" + specialInstructions
				+ ", primaryInsName=" + primaryInsName + ", primaryInsPolicyNo="
				+ primaryInsPolicyNo + ", primaryInsCompany="
				+ primaryInsCompany + ", primaryInsMac=" + primaryInsMac
				+ ", primaryInsDeductible=" + primaryInsDeductible
				+ ", primaryInsDeducMet=" + primaryInsDeducMet
				+ ", primaryInsCopay=" + primaryInsCopay
				+ ", primaryInsCoinsurance=" + primaryInsCoinsurance
				+ ", primaryInsOOPMax=" + primaryInsOOPMax
				+ ", primaryInsOOPMet=" + primaryInsOOPMet
				+ ", primaryInsStatus=" + primaryInsStatus
				+ ", primaryInsPercentCovered=" + primaryInsPercentCovered
				+ ", primaryInsReasonNotCovered=" + primaryInsReasonNotCovered
				+ ", primaryInsReasonNA=" + primaryInsReasonNA
				+ ", secondaryInsName=" + secondaryInsName
				+ ", secondaryInsCompany=" + secondaryInsCompany
				+ ", secondaryInsMac=" + secondaryInsMac
				+ ", secondaryInsPolicyNo=" + secondaryInsPolicyNo
				+ ", secondaryInsDeductible=" + secondaryInsDeductible
				+ ", secondaryInsDeducMet=" + secondaryInsDeducMet
				+ ", secondaryInsCopay=" + secondaryInsCopay
				+ ", secondaryInsCoinsurance=" + secondaryInsCoinsurance
				+ ", secondaryInsOOPMax=" + secondaryInsOOPMax
				+ ", secondaryInsOOPMet=" + secondaryInsOOPMet
				+ ", secondaryInsStatus=" + secondaryInsStatus
				+ ", secondaryInsPercentCovered=" + secondaryInsPercentCovered
				+ ", secondaryInsReasonNotCovered="
				+ secondaryInsReasonNotCovered + ", secondaryInsReasonNA="
				+ secondaryInsReasonNA + ", tertiaryInsName=" + tertiaryInsName
				+ ", tertiaryInsPolicyNo=" + tertiaryInsPolicyNo
				+ ", tertiaryInsCompany=" + tertiaryInsCompany
				+ ", tertiaryInsMac=" + tertiaryInsMac
				+ ", tertiaryInsDeductible=" + tertiaryInsDeductible
				+ ", tertiaryInsDeducMet=" + tertiaryInsDeducMet
				+ ", tertiaryInsCopay=" + tertiaryInsCopay
				+ ", tertiaryInsCoinsurance=" + tertiaryInsCoinsurance
				+ ", tertiaryInsOOPMax=" + tertiaryInsOOPMax
				+ ", tertiaryInsOOPMet=" + tertiaryInsOOPMet
				+ ", tertiaryInsStatus=" + tertiaryInsStatus
				+ ", tertiaryInsPercentCovered=" + tertiaryInsPercentCovered
				+ ", tertiaryInsReasonNotCovered=" + tertiaryInsReasonNotCovered
				+ ", tertiaryInsReasonNA=" + tertiaryInsReasonNA + ", hcpc="
				+ hcpc + ", productSKU=" + productSKU + ", productName="
				+ productName + ", noOfAppApproved=" + noOfAppApproved
				+ ", noOfUnitsApproved=" + noOfUnitsApproved
				+ ", approvalTimeframe=" + approvalTimeframe + ", ICD10Codes="
				+ ICD10Codes + ", placeOfService=" + placeOfService
				+ ", woundNumber=" + woundNumber + ", completedDate="
				+ completedDate + ", completedStatus=" + completedStatus
				+ ", coverageSummary=" + coverageSummary + ", insertTimestamp="
				+ insertTimestamp + ", salesRepManager=" + salesRepManager
				+ ", regionalDirector=" + regionalDirector + ", sgp=" + sgp
				+ ", sgpDate=" + sgpDate + ", sgpctpCode=" + sgpctpCode + "]";
	}
}
