package com.healogics.rtrv.dto;

import java.util.Date;

public class EDocument {
	private String documentType;
	private String documentRequestId;

	// Additional NPWT Parameters
	private String reason;
	private Date startDate;
	private Date endDate;

	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentRequestId() {
		return documentRequestId;
	}
	public void setDocumentRequestId(String documentRequestId) {
		this.documentRequestId = documentRequestId;
	}
	@Override
	public String toString() {
		return "EDocument [documentType=" + documentType
				+ ", documentRequestId=" + documentRequestId + ", reason="
				+ reason + ", startDate=" + startDate + ", endDate=" + endDate
				+ "]";
	}
}
