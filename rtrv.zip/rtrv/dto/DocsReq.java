package com.healogics.rtrv.dto;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.healogics.rtrv.utils.ValidIntegerId;

public class DocsReq {
	private String facilityBBC;
	private String facilityName;
	// Similar to vendorRequestId
	private String vendorOrderNumber;
	// Also Primary to NPWT as VendorOrderNumber
	private String vendorRequestId;
	private String vendorCustomerNumber;
	private String patientFirstName;
	private String patientLastName;
	private String medicalRecordNumber;
	private List<EDocument> documents;
	private String orderSource;
	private String orderToken;
	private Integer orderDisplayNumber;
	private Integer facilityId;
	@Pattern(message = "Invalid Patient: PatientId can only be a number.", regexp="^[0-9]+$")
	private String patientId;
	private Integer vendorId;
	private Long visitId;
	private Date visitDate;

	// NPWT
	private String vendorStatus;
	private String secondaryStatus;
	private Integer requestId;
	private Integer facilityID;
	private String primaryInsurance;
	private String secondaryInsurance;
	private String providerFirstName;
	private String providerLastName;
	private String clinicianFirstName;
	private String clinicianLastName;
	private String responseDate;
	private String vendorReferralNumber;
	private Date needByDate;
	private Date patientDOB;
	private String npiId;
	
	//Woundq
	private String woundqOrderToken;
	private String woundqOrderNo;
	
	
	public String getWoundqOrderToken() {
		return woundqOrderToken;
	}
	public void setWoundqOrderToken(String woundqOrderToken) {
		this.woundqOrderToken = woundqOrderToken;
	}
	public String getWoundqOrderNo() {
		return woundqOrderNo;
	}
	public void setWoundqOrderNo(String woundqOrderNo) {
		this.woundqOrderNo = woundqOrderNo;
	}
	public String getNpiId() {
		return npiId;
	}
	public void setNpiId(String npiId) {
		this.npiId = npiId;
	}
	public Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Integer getFacilityID() {
		return facilityID;
	}
	public void setFacilityID(Integer facilityID) {
		this.facilityID = facilityID;
	}
	public String getPrimaryInsurance() {
		return primaryInsurance;
	}
	public void setPrimaryInsurance(String primaryInsurance) {
		this.primaryInsurance = primaryInsurance;
	}
	public String getSecondaryInsurance() {
		return secondaryInsurance;
	}
	public void setSecondaryInsurance(String secondaryInsurance) {
		this.secondaryInsurance = secondaryInsurance;
	}
	public String getProviderFirstName() {
		return providerFirstName;
	}
	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}
	public String getProviderLastName() {
		return providerLastName;
	}
	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}
	public String getClinicianFirstName() {
		return clinicianFirstName;
	}
	public void setClinicianFirstName(String clinicianFirstName) {
		this.clinicianFirstName = clinicianFirstName;
	}
	public String getClinicianLastName() {
		return clinicianLastName;
	}
	public void setClinicianLastName(String clinicianLastName) {
		this.clinicianLastName = clinicianLastName;
	}
	public String getResponseDate() {
		return responseDate;
	}
	public void setResponseDate(String responseDate) {
		this.responseDate = responseDate;
	}
	public String getVendorReferralNumber() {
		return vendorReferralNumber;
	}
	public void setVendorReferralNumber(String vendorReferralNumber) {
		this.vendorReferralNumber = vendorReferralNumber;
	}
	public Date getNeedByDate() {
		return needByDate;
	}
	public void setNeedByDate(Date needByDate) {
		this.needByDate = needByDate;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getSecondaryStatus() {
		return secondaryStatus;
	}
	public void setSecondaryStatus(String secondaryStatus) {
		this.secondaryStatus = secondaryStatus;
	}
	public String getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public String getVendorRequestId() {
		return vendorRequestId;
	}
	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}
	public String getFacilityBBC() {
		return facilityBBC;
	}
	public void setFacilityBBC(String facilityBBC) {
		this.facilityBBC = facilityBBC;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getVendorOrderNumber() {
		return vendorOrderNumber;
	}
	public void setVendorOrderNumber(String vendorOrderNumber) {
		this.vendorOrderNumber = vendorOrderNumber;
	}
	public String getVendorCustomerNumber() {
		return vendorCustomerNumber;
	}
	public void setVendorCustomerNumber(String vendorCustomerNumber) {
		this.vendorCustomerNumber = vendorCustomerNumber;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getMedicalRecordNumber() {
		return medicalRecordNumber;
	}
	public void setMedicalRecordNumber(String medicalRecordNumber) {
		this.medicalRecordNumber = medicalRecordNumber;
	}
	public List<EDocument> getDocuments() {
		return documents;
	}
	public void setDocuments(List<EDocument> documents) {
		this.documents = documents;
	}
	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	public String getOrderToken() {
		return orderToken;
	}
	public void setOrderToken(String orderToken) {
		this.orderToken = orderToken;
	}
	public Integer getOrderDisplayNumber() {
		return orderDisplayNumber;
	}
	public void setOrderDisplayNumber(Integer orderDisplayNumber) {
		this.orderDisplayNumber = orderDisplayNumber;
	}
	public Integer getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public Long getVisitId() {
		return visitId;
	}
	public void setVisitId(Long visitId) {
		this.visitId = visitId;
	}
	public Date getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	@Override
	public String toString() {
		return "DocsReq [facilityBBC=" + facilityBBC + ", facilityName=" + facilityName + ", vendorOrderNumber="
				+ vendorOrderNumber + ", vendorRequestId=" + vendorRequestId + ", vendorCustomerNumber="
				+ vendorCustomerNumber + ", patientFirstName=" + patientFirstName + ", patientLastName="
				+ patientLastName + ", medicalRecordNumber=" + medicalRecordNumber + ", documents=" + documents
				+ ", orderSource=" + orderSource + ", orderToken=" + orderToken + ", orderDisplayNumber="
				+ orderDisplayNumber + ", facilityId=" + facilityId + ", patientId=" + patientId + ", vendorId="
				+ vendorId + ", visitId=" + visitId + ", visitDate=" + visitDate + ", vendorStatus=" + vendorStatus
				+ ", secondaryStatus=" + secondaryStatus + ", requestId=" + requestId + ", facilityID=" + facilityID
				+ ", primaryInsurance=" + primaryInsurance + ", secondaryInsurance=" + secondaryInsurance
				+ ", providerFirstName=" + providerFirstName + ", providerLastName=" + providerLastName
				+ ", clinicianFirstName=" + clinicianFirstName + ", clinicianLastName=" + clinicianLastName
				+ ", responseDate=" + responseDate + ", vendorReferralNumber=" + vendorReferralNumber + ", needByDate="
				+ needByDate + ", patientDOB=" + patientDOB + ", npiId=" + npiId + ", woundqOrderToken="
				+ woundqOrderToken + ", woundqOrderNo=" + woundqOrderNo + "]";
	}
}
