package com.healogics.rtrv.dto;

import java.util.Date;
import java.util.List;

public class AWDFilterOptions {


	private List<String> filterOptions;

	public List<String> getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(List<String> filterOptions) {
		this.filterOptions = filterOptions;
	}

	@Override
	public String toString() {
		return "AWDFilterOptions [filterOptions=" + filterOptions + "]";
	}
 

}
