package com.healogics.rtrv.dto;

import java.util.List;

public class DeleteNotificationReq {
	private String integrationKey;
	private List<String> notificationId;
	public String getIntegrationKey() {
		return integrationKey;
	}
	public void setIntegrationKey(String integrationKey) {
		this.integrationKey = integrationKey;
	}
	public List<String> getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(List<String> notificationId) {
		this.notificationId = notificationId;
	}
	@Override
	public String toString() {
		return "DeleteNotificationReq [integrationKey=" + integrationKey + ", notificationId=" + notificationId + "]";
	}
}
