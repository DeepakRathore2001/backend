package com.healogics.rtrv.dto;

public class MedicalRecodInvoiceDetails {
	private int bhcMedRecId;
	private int bhcInvoiceOrderId;
	private String invoiceAmount;

	public int getBhcMedRecId() {
		return bhcMedRecId;
	}
	public void setBhcMedRecId(int bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}
	public int getBhcInvoiceOrderId() {
		return bhcInvoiceOrderId;
	}
	public void setBhcInvoiceOrderId(int bhcInvoiceOrderId) {
		this.bhcInvoiceOrderId = bhcInvoiceOrderId;
	}
	public String getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	
	
}
