package com.healogics.rtrv.dto;

public class WoundQProduct {
	private String hcpcsCode;
	private String productName;
	private String itemNumber;

	public String getHcpcsCode() {
		return hcpcsCode;
	}

	public void setHcpcsCode(String hcpcsCode) {
		this.hcpcsCode = hcpcsCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	@Override
	public String toString() {
		return "WoundQProduct [hcpcsCode=" + hcpcsCode + ", productName=" + productName + ", itemNumber=" + itemNumber
				+ "]";
	}
}
