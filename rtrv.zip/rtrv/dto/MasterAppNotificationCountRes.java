package com.healogics.rtrv.dto;

import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;

public class MasterAppNotificationCountRes extends RTRVAPIResponse {
	private boolean unreadAppNotifcationExists;

	public boolean isUnreadAppNotifcationExists() {
		return unreadAppNotifcationExists;
	}

	public void setUnreadAppNotifcationExists(boolean unreadAppNotifcationExists) {
		this.unreadAppNotifcationExists = unreadAppNotifcationExists;
	}

	@Override
	public String toString() {
		return "MasterAppNotificationCountRes [unreadAppNotifcationExists=" + unreadAppNotifcationExists + "]";
	}
}
