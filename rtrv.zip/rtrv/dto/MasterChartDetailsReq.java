package com.healogics.rtrv.dto;

public class MasterChartDetailsReq {

	private String orderId;
	private String requestId;
	private String documentToken;
	private String serviceLine;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getDocumentToken() {
		return documentToken;
	}

	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "MasterChartDetailsReq [orderId=" + orderId + ", requestId="
				+ requestId + ", documentToken=" + documentToken
				+ ", serviceLine=" + serviceLine + "]";
	}

}
