package com.healogics.rtrv.dto;

import java.io.Serializable;

public class HistoryTimelineDocStatus implements Serializable {
	 private static final long serialVersionUID = 1L;
	 
	private String documentName;
	private String documentDownloadStatus;
	private String vendorDownloadStatus;
	private String documentToken;
	private String documentSource;
	private String documentType;
	private Long docEntityId;
	private Long versionId;
	private Integer facilityId;
	
	public Integer getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}
	public Long getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(Long docEntityId) {
		this.docEntityId = docEntityId;
	}
	public Long getVersionId() {
		return versionId;
	}
	public void setVersionId(Long versionId) {
		this.versionId = versionId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentDownloadStatus() {
		return documentDownloadStatus;
	}
	public void setDocumentDownloadStatus(String documentDownloadStatus) {
		this.documentDownloadStatus = documentDownloadStatus;
	}
	public String getVendorDownloadStatus() {
		return vendorDownloadStatus;
	}
	public void setVendorDownloadStatus(String vendorDownloadStatus) {
		this.vendorDownloadStatus = vendorDownloadStatus;
	}
	public String getDocumentToken() {
		return documentToken;
	}
	public void setDocumentToken(String documentToken) {
		this.documentToken = documentToken;
	}
	public String getDocumentSource() {
		return documentSource;
	}
	public void setDocumentSource(String documentSource) {
		this.documentSource = documentSource;
	}
	@Override
	public String toString() {
		return "HistoryTimelineDocStatus [documentName=" + documentName + ", documentDownloadStatus="
				+ documentDownloadStatus + ", vendorDownloadStatus=" + vendorDownloadStatus + ", documentToken="
				+ documentToken + ", documentSource=" + documentSource + ", documentType=" + documentType
				+ ", docEntityId=" + docEntityId + ", versionId=" + versionId + ", facilityId=" + facilityId + "]";
	}
}
