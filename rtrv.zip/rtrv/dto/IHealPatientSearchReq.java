package com.healogics.rtrv.dto;

import java.io.Serializable;

public class IHealPatientSearchReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String userId;
	private String facilityId;
	private String locationId;
	private String serviceLineId;
	private String activePatientsOnly;
	private String matchField;
	private String matchPhrase;
	private String pageIndex;
	private String maxPageSize;
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	public String getMasterToken() {
		return masterToken;
	}
	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public String getServiceLineId() {
		return serviceLineId;
	}
	public void setServiceLineId(String serviceLineId) {
		this.serviceLineId = serviceLineId;
	}
	public String getActivePatientsOnly() {
		return activePatientsOnly;
	}
	public void setActivePatientsOnly(String activePatientsOnly) {
		this.activePatientsOnly = activePatientsOnly;
	}
	public String getMatchField() {
		return matchField;
	}
	public void setMatchField(String matchField) {
		this.matchField = matchField;
	}
	public String getMatchPhrase() {
		return matchPhrase;
	}
	public void setMatchPhrase(String matchPhrase) {
		this.matchPhrase = matchPhrase;
	}
	public String getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(String pageIndex) {
		this.pageIndex = pageIndex;
	}
	public String getMaxPageSize() {
		return maxPageSize;
	}
	public void setMaxPageSize(String maxPageSize) {
		this.maxPageSize = maxPageSize;
	}
	@Override
	public String toString() {
		return "IHealPatientSearchReq [privateKey=" + privateKey
				+ ", masterToken=" + masterToken + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", locationId=" + locationId
				+ ", serviceLineId=" + serviceLineId + ", activePatientsOnly="
				+ activePatientsOnly + ", matchField=" + matchField
				+ ", matchPhrase=" + matchPhrase + ", pageIndex=" + pageIndex
				+ ", maxPageSize=" + maxPageSize + "]";
	}

}
