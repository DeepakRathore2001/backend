package com.healogics.rtrv.dto;

public class RetrieveMembersDetails {

	private Long retrieveMemberId;
	private String bluebookCode;
	private String territory;
	private String facilityId;
	private String awdDocSpecialist;
	private String awdDocClerk;
	private String npwtDocSpecialist;
	private String npwtDocClerk;
	private String ctpDocSpecialist;
	private String ctpDocClerk;
	private int active;
	private String awdDocSpecialistUsername;
	private String awdDocClerkUsername;
	private String npwtDocSpecialistUsername;
	private String npwtDocClerkUsername;
	private String ctpDocSpecialistUsername;
	private String ctpDocClerkUsername;
	private String opsSpecialist;
	private String market;
	private String division;
	private String iHealConfiguration;

	public String getOpsSpecialist() {
		return opsSpecialist;
	}
	public void setOpsSpecialist(String opsSpecialist) {
		this.opsSpecialist = opsSpecialist;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getiHealConfiguration() {
		return iHealConfiguration;
	}
	public void setiHealConfiguration(String iHealConfiguration) {
		this.iHealConfiguration = iHealConfiguration;
	}
	public String getTerritory() {
		return territory;
	}
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getNpwtDocSpecialist() {
		return npwtDocSpecialist;
	}
	public void setNpwtDocSpecialist(String npwtDocSpecialist) {
		this.npwtDocSpecialist = npwtDocSpecialist;
	}
	public String getNpwtDocClerk() {
		return npwtDocClerk;
	}
	public void setNpwtDocClerk(String npwtDocClerk) {
		this.npwtDocClerk = npwtDocClerk;
	}
	public String getCtpDocSpecialist() {
		return ctpDocSpecialist;
	}
	public void setCtpDocSpecialist(String ctpDocSpecialist) {
		this.ctpDocSpecialist = ctpDocSpecialist;
	}
	public String getCtpDocClerk() {
		return ctpDocClerk;
	}
	public void setCtpDocClerk(String ctpDocClerk) {
		this.ctpDocClerk = ctpDocClerk;
	}
	public String getNpwtDocSpecialistUsername() {
		return npwtDocSpecialistUsername;
	}
	public void setNpwtDocSpecialistUsername(String npwtDocSpecialistUsername) {
		this.npwtDocSpecialistUsername = npwtDocSpecialistUsername;
	}
	public String getNpwtDocClerkUsername() {
		return npwtDocClerkUsername;
	}
	public void setNpwtDocClerkUsername(String npwtDocClerkUsername) {
		this.npwtDocClerkUsername = npwtDocClerkUsername;
	}
	public String getCtpDocSpecialistUsername() {
		return ctpDocSpecialistUsername;
	}
	public void setCtpDocSpecialistUsername(String ctpDocSpecialistUsername) {
		this.ctpDocSpecialistUsername = ctpDocSpecialistUsername;
	}
	public String getCtpDocClerkUsername() {
		return ctpDocClerkUsername;
	}
	public void setCtpDocClerkUsername(String ctpDocClerkUsername) {
		this.ctpDocClerkUsername = ctpDocClerkUsername;
	}
	public Long getRetrieveMemberId() {
		return retrieveMemberId;
	}
	public void setRetrieveMemberId(Long retrieveMemberId) {
		this.retrieveMemberId = retrieveMemberId;
	}
	public String getBluebookCode() {
		return bluebookCode;
	}
	public void setBluebookCode(String bluebookCode) {
		this.bluebookCode = bluebookCode;
	}
	public String getAwdDocSpecialist() {
		return awdDocSpecialist;
	}
	public void setAwdDocSpecialist(String awdDocSpecialist) {
		this.awdDocSpecialist = awdDocSpecialist;
	}
	public String getAwdDocClerk() {
		return awdDocClerk;
	}
	public void setAwdDocClerk(String awdDocClerk) {
		this.awdDocClerk = awdDocClerk;
	}
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
	public String getAwdDocSpecialistUsername() {
		return awdDocSpecialistUsername;
	}
	public void setAwdDocSpecialistUsername(String awdDocSpecialistUsername) {
		this.awdDocSpecialistUsername = awdDocSpecialistUsername;
	}
	public String getAwdDocClerkUsername() {
		return awdDocClerkUsername;
	}
	public void setAwdDocClerkUsername(String awdDocClerkUsername) {
		this.awdDocClerkUsername = awdDocClerkUsername;
	}
	@Override
	public String toString() {
		return "RetrieveMembersDetails [retrieveMemberId=" + retrieveMemberId
				+ ", bluebookCode=" + bluebookCode + ", territory=" + territory
				+ ", facilityId=" + facilityId + ", awdDocSpecialist="
				+ awdDocSpecialist + ", awdDocClerk=" + awdDocClerk
				+ ", npwtDocSpecialist=" + npwtDocSpecialist + ", npwtDocClerk="
				+ npwtDocClerk + ", ctpDocSpecialist=" + ctpDocSpecialist
				+ ", ctpDocClerk=" + ctpDocClerk + ", active=" + active
				+ ", awdDocSpecialistUsername=" + awdDocSpecialistUsername
				+ ", awdDocClerkUsername=" + awdDocClerkUsername
				+ ", npwtDocSpecialistUsername=" + npwtDocSpecialistUsername
				+ ", npwtDocClerkUsername=" + npwtDocClerkUsername
				+ ", ctpDocSpecialistUsername=" + ctpDocSpecialistUsername
				+ ", ctpDocClerkUsername=" + ctpDocClerkUsername
				+ ", opsSpecialist=" + opsSpecialist + ", market=" + market
				+ ", division=" + division + ", iHealConfiguration="
				+ iHealConfiguration + "]";
	}

}
