package com.healogics.rtrv.dto;

import java.util.Date;
import java.sql.Timestamp;

public class DocumentNameObj {
	private Long bhcMedRecId;
	private Long bhcInvOrderNo;
	private String documentType;
	private Long documentId;
	private String bluebookId;
	private int facilityId;
	private String facilityName;
	private String patientFirstName;
	private String patientLastName;
	private Date bhcShipDate;
	private Long bhcPatientAcctNo;
	private String bhcPatientInv;
	private Date dateDocSent;
	private Date visitDate;
	private Timestamp createdTimestamp;
	private Timestamp lastUpdatedTimestamp;
	private String createdUsername;
	private String lastUpdatedByUsername;
	private Long createdUserId;
	private Long lastUpdatedByUserId;
	private String createdUserFullname;
	private String lastUpdatedByUserFullname;

	public Long getBhcMedRecId() {
		return bhcMedRecId;
	}
	public void setBhcMedRecId(Long bhcMedRecId) {
		this.bhcMedRecId = bhcMedRecId;
	}
	public Long getBhcInvOrderNo() {
		return bhcInvOrderNo;
	}
	public void setBhcInvOrderNo(Long bhcInvOrderNo) {
		this.bhcInvOrderNo = bhcInvOrderNo;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public Long getDocumentId() {
		return documentId;
	}
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}
	public String getBluebookId() {
		return bluebookId;
	}
	public void setBluebookId(String bluebookId) {
		this.bluebookId = bluebookId;
	}
	public int getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public Date getBhcShipDate() {
		return bhcShipDate;
	}
	public void setBhcShipDate(Date bhcShipDate) {
		this.bhcShipDate = bhcShipDate;
	}
	public Long getBhcPatientAcctNo() {
		return bhcPatientAcctNo;
	}
	public void setBhcPatientAcctNo(Long bhcPatientAcctNo) {
		this.bhcPatientAcctNo = bhcPatientAcctNo;
	}
	public String getBhcPatientInv() {
		return bhcPatientInv;
	}
	public void setBhcPatientInv(String bhcPatientInv) {
		this.bhcPatientInv = bhcPatientInv;
	}
	public Date getDateDocSent() {
		return dateDocSent;
	}
	public void setDateDocSent(Date dateDocSent) {
		this.dateDocSent = dateDocSent;
	}
	public Date getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public String getCreatedUsername() {
		return createdUsername;
	}
	public void setCreatedUsername(String createdUsername) {
		this.createdUsername = createdUsername;
	}
	public String getLastUpdatedByUsername() {
		return lastUpdatedByUsername;
	}
	public void setLastUpdatedByUsername(String lastUpdatedByUsername) {
		this.lastUpdatedByUsername = lastUpdatedByUsername;
	}
	public Long getCreatedUserId() {
		return createdUserId;
	}
	public void setCreatedUserId(Long createdUserId) {
		this.createdUserId = createdUserId;
	}
	public Long getLastUpdatedByUserId() {
		return lastUpdatedByUserId;
	}
	public void setLastUpdatedByUserId(Long lastUpdatedByUserId) {
		this.lastUpdatedByUserId = lastUpdatedByUserId;
	}
	public String getCreatedUserFullname() {
		return createdUserFullname;
	}
	public void setCreatedUserFullname(String createdUserFullname) {
		this.createdUserFullname = createdUserFullname;
	}
	public String getLastUpdatedByUserFullname() {
		return lastUpdatedByUserFullname;
	}
	public void setLastUpdatedByUserFullname(String lastUpdatedByUserFullname) {
		this.lastUpdatedByUserFullname = lastUpdatedByUserFullname;
	}
	@Override
	public String toString() {
		return "DocumentNameObj [bhcMedRecId=" + bhcMedRecId + ", bhcInvOrderNo=" + bhcInvOrderNo + ", documentType="
				+ documentType + ", documentId=" + documentId + ", bluebookId=" + bluebookId + ", facilityId="
				+ facilityId + ", facilityName=" + facilityName + ", patientFirstName=" + patientFirstName
				+ ", patientLastName=" + patientLastName + ", bhcShipDate=" + bhcShipDate + ", bhcPatientAcctNo="
				+ bhcPatientAcctNo + ", bhcPatientInv=" + bhcPatientInv + ", dateDocSent=" + dateDocSent
				+ ", visitDate=" + visitDate + ", createdTimestamp=" + createdTimestamp + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", createdUsername=" + createdUsername + ", lastUpdatedByUsername="
				+ lastUpdatedByUsername + ", createdUserId=" + createdUserId + ", lastUpdatedByUserId="
				+ lastUpdatedByUserId + ", createdUserFullname=" + createdUserFullname + ", lastUpdatedByUserFullname="
				+ lastUpdatedByUserFullname + "]";
	}
}
