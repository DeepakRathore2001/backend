package com.healogics.rtrv.dto;

public class WoundQOrderNotificationReq {
	
	private String orderToken;
	private Integer patientId;
	private Integer vendorId;
	private Integer facilityId;
	private Integer orderDisplayNumber;
	
	public String getOrderToken() {
		return orderToken;
	}
	public void setOrderToken(String orderToken) {
		this.orderToken = orderToken;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public Integer getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}
	public Integer getOrderDisplayNumber() {
		return orderDisplayNumber;
	}
	public void setOrderDisplayNumber(Integer orderDisplayNumber) {
		this.orderDisplayNumber = orderDisplayNumber;
	}
	@Override
	public String toString() {
		return "WoundQOrderNotificationReq [orderToken=" + orderToken + ", patientId=" + patientId + ", vendorId="
				+ vendorId + ", facilityId=" + facilityId + ", orderDisplayNumber=" + orderDisplayNumber + "]";
	}
	
	

}
