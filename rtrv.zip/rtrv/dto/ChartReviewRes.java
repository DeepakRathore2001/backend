package com.healogics.rtrv.dto;

public class ChartReviewRes {

	private String responseCode;
	private String responseMessage;
	private ChartReviewDetails chartReviewDetails;
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public ChartReviewDetails getChartReviewDetails() {
		return chartReviewDetails;
	}
	public void setChartReviewDetails(ChartReviewDetails chartReviewDetails) {
		this.chartReviewDetails = chartReviewDetails;
	}
	@Override
	public String toString() {
		return "ChartReviewRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage
				+ ", chartReviewDetails=" + chartReviewDetails + "]";
	}

}
