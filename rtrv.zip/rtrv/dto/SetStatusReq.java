package com.healogics.rtrv.dto;

public class SetStatusReq {

	private String medRecId;
	private String bhcInvoiceId;
	private String status;
	private String statusUpdatedUserId;
	private String statusUpdatedUserFullname;
	private String statusUpdatedUsername;
	private String lastUpdatedUserId;
	private String lastUpdatedUserFullname;
	private String lastUpdatedUsername;

	public String getStatusUpdatedUserId() {
		return statusUpdatedUserId;
	}
	public void setStatusUpdatedUserId(String statusUpdatedUserId) {
		this.statusUpdatedUserId = statusUpdatedUserId;
	}
	public String getStatusUpdatedUserFullname() {
		return statusUpdatedUserFullname;
	}
	public void setStatusUpdatedUserFullname(String statusUpdatedUserFullname) {
		this.statusUpdatedUserFullname = statusUpdatedUserFullname;
	}
	public String getStatusUpdatedUsername() {
		return statusUpdatedUsername;
	}
	public void setStatusUpdatedUsername(String statusUpdatedUsername) {
		this.statusUpdatedUsername = statusUpdatedUsername;
	}
	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}
	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}
	public String getLastUpdatedUserFullname() {
		return lastUpdatedUserFullname;
	}
	public void setLastUpdatedUserFullname(String lastUpdatedUserFullname) {
		this.lastUpdatedUserFullname = lastUpdatedUserFullname;
	}
	public String getLastUpdatedUsername() {
		return lastUpdatedUsername;
	}
	public void setLastUpdatedUsername(String lastUpdatedUsername) {
		this.lastUpdatedUsername = lastUpdatedUsername;
	}
	public String getMedRecId() {
		return medRecId;
	}
	public void setMedRecId(String medRecId) {
		this.medRecId = medRecId;
	}
	public String getBhcInvoiceId() {
		return bhcInvoiceId;
	}
	public void setBhcInvoiceId(String bhcInvoiceId) {
		this.bhcInvoiceId = bhcInvoiceId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "SetStatusReq [medRecId=" + medRecId + ", bhcInvoiceId="
				+ bhcInvoiceId + ", status=" + status + ", statusUpdatedUserId="
				+ statusUpdatedUserId + ", statusUpdatedUserFullname="
				+ statusUpdatedUserFullname + ", statusUpdatedUsername="
				+ statusUpdatedUsername + ", lastUpdatedUserId="
				+ lastUpdatedUserId + ", lastUpdatedUserFullname="
				+ lastUpdatedUserFullname + ", lastUpdatedUsername="
				+ lastUpdatedUsername + "]";
	}

}
