package com.healogics.rtrv.dto;

public class MedRecListReq {

	private String privateKey;
	private String masterToken;
	private String userId;
	private String facilityId;
	private int patientId;

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "MedRecListReq [privateKey=" + privateKey + ", masterToken=" + masterToken + ", userId=" + userId
				+ ", facilityId=" + facilityId + ", patientId=" + patientId + "]";
	}

}
