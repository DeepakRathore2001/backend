package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;

public class IHealPatientSearchRes implements Serializable {

	private static final long serialVersionUID = 1L;
	private String recordCount;
	private String pageIndex;
	private String maxPageSize;
	private List<IHealPatientObj> patients;
	private String errorCode;
	private String errorMessage;
	private List<NHWarningDetails> warnings;
	public String getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}
	public String getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(String pageIndex) {
		this.pageIndex = pageIndex;
	}
	public String getMaxPageSize() {
		return maxPageSize;
	}
	public void setMaxPageSize(String maxPageSize) {
		this.maxPageSize = maxPageSize;
	}
	public List<IHealPatientObj> getPatients() {
		return patients;
	}
	public void setPatients(List<IHealPatientObj> patients) {
		this.patients = patients;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<NHWarningDetails> getWarnings() {
		return warnings;
	}
	public void setWarnings(List<NHWarningDetails> warnings) {
		this.warnings = warnings;
	}
	@Override
	public String toString() {
		return "IHealPatientSearchRes [recordCount=" + recordCount
				+ ", pageIndex=" + pageIndex + ", maxPageSize=" + maxPageSize
				+ ", patients=" + patients + ", errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + ", warnings=" + warnings
				+ "]";
	}
}
