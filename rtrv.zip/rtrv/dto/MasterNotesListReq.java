package com.healogics.rtrv.dto;

public class MasterNotesListReq {
	private String serviceLine;
	private String requestId;
	private int index;

	public String getServiceLine() {
		return serviceLine;
	}
	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	@Override
	public String toString() {
		return "MasterNotesListReq [serviceLine=" + serviceLine + ", requestId="
				+ requestId + ", index=" + index + "]";
	}
}
