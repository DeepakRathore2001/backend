package com.healogics.rtrv.dto;

import java.io.Serializable;
import java.util.List;

public class IHealUser implements Serializable {

	private static final long serialVersionUID = 1L;
	private String privateKey;
	private String masterToken;
	private String userId;
	private List<String> facilitySettings;

	public List<String> getFacilitySettings() {
		return facilitySettings;
	}

	public void setFacilitySettings(List<String> facilitySettings) {
		this.facilitySettings = facilitySettings;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMasterToken() {
		return masterToken;
	}

	public void setMasterToken(String masterToken) {
		this.masterToken = masterToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "IHealUser [privateKey=" + privateKey + ", masterToken="
				+ masterToken + ", userId=" + userId + ", facilitySettings="
				+ facilitySettings + "]";
	}

}
