package com.healogics.rtrv.dto;

public class VisitDocumentObj {

	private int documentEntityId;
	private int versionId;
	private String documentType;
	private int facilityId;
	private int patientId;
	private int visitId;
	private String visitDateTime;
	private String addedDateTime;
	private boolean signatureRequirementMet;

	public boolean isSignatureRequirementMet() {
		return signatureRequirementMet;
	}

	public void setSignatureRequirementMet(boolean signatureRequirementMet) {
		this.signatureRequirementMet = signatureRequirementMet;
	}

	public int getDocumentEntityId() {
		return documentEntityId;
	}

	public void setDocumentEntityId(int documentEntityId) {
		this.documentEntityId = documentEntityId;
	}

	public int getVersionId() {
		return versionId;
	}

	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public int getVisitId() {
		return visitId;
	}

	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}

	public String getVisitDateTime() {
		return visitDateTime;
	}

	public void setVisitDateTime(String visitDateTime) {
		this.visitDateTime = visitDateTime;
	}

	public String getAddedDateTime() {
		return addedDateTime;
	}

	public void setAddedDateTime(String addedDateTime) {
		this.addedDateTime = addedDateTime;
	}

	@Override
	public String toString() {
		return "VisitDocumentObj [documentEntityId=" + documentEntityId
				+ ", versionId=" + versionId + ", documentType=" + documentType
				+ ", facilityId=" + facilityId + ", patientId=" + patientId
				+ ", visitId=" + visitId + ", visitDateTime=" + visitDateTime
				+ ", addedDateTime=" + addedDateTime
				+ ", signatureRequirementMet=" + signatureRequirementMet + "]";
	}
}
