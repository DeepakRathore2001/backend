package com.healogics.rtrv.dto;

import java.util.List;

public class NotesAttempt {
	private String attemptCategory;
	private List<String> attemptType;

	public String getAttemptCategory() {
		return attemptCategory;
	}
	public void setAttemptCategory(String attemptCategory) {
		this.attemptCategory = attemptCategory;
	}
	public List<String> getAttemptType() {
		return attemptType;
	}
	public void setAttemptType(List<String> attemptType) {
		this.attemptType = attemptType;
	}
	@Override
	public String toString() {
		return "NotesAttemptDetails [attemptCategory=" + attemptCategory + ", attemptType=" + attemptType + "]";
	}
}
