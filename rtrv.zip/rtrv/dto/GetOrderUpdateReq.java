package com.healogics.rtrv.dto;

public class GetOrderUpdateReq {
	private int vendorId;
	private String vendorRequestId;
	private String vendorStatus;
	private String secondaryStatus;
	private String coverageSummary;
	private String missingElements;
	private String statusChangeNotes;
	
	private String patientFullName;
	private String patientUserId;
	private String retrieveStatus;
	
	private String statusDetail;
	
	public String getStatusDetail() {
		return statusDetail;
	}
	public void setStatusDetail(String statusDetail) {
		this.statusDetail = statusDetail;
	}
	public int getVendorId() {
		return vendorId;
	}
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	public String getSecondaryStatus() {
		return secondaryStatus;
	}
	public void setSecondaryStatus(String secondaryStatus) {
		this.secondaryStatus = secondaryStatus;
	}
	public String getCoverageSummary() {
		return coverageSummary;
	}
	public void setCoverageSummary(String coverageSummary) {
		this.coverageSummary = coverageSummary;
	}
	public String getMissingElements() {
		return missingElements;
	}
	public void setMissingElements(String missingElements) {
		this.missingElements = missingElements;
	}
	public String getStatusChangeNotes() {
		return statusChangeNotes;
	}
	public void setStatusChangeNotes(String statusChangeNotes) {
		this.statusChangeNotes = statusChangeNotes;
	}
	public String getPatientFullName() {
		return patientFullName;
	}
	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}
	public String getPatientUserId() {
		return patientUserId;
	}
	public void setPatientUserId(String patientUserId) {
		this.patientUserId = patientUserId;
	}
	public String getVendorRequestId() {
		return vendorRequestId;
	}
	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}
	public String getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	@Override
	public String toString() {
		return "GetOrderUpdateReq [vendorId=" + vendorId + ", vendorRequestId=" + vendorRequestId + ", vendorStatus="
				+ vendorStatus + ", secondaryStatus=" + secondaryStatus + ", coverageSummary=" + coverageSummary
				+ ", missingElements=" + missingElements + ", statusChangeNotes=" + statusChangeNotes
				+ ", patientFullName=" + patientFullName + ", patientUserId=" + patientUserId + ", retrieveStatus="
				+ retrieveStatus + "]";
	}

}
