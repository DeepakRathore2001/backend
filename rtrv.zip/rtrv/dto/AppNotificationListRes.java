package com.healogics.rtrv.dto;

import java.util.List;

public class AppNotificationListRes {
	private String responseCode;
	private String responseMessage;
	private List<RTRVAppNotifications> appNotifications;

	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<RTRVAppNotifications> getAppNotifications() {
		return appNotifications;
	}
	public void setAppNotifications(List<RTRVAppNotifications> appNotifications) {
		this.appNotifications = appNotifications;
	}
	@Override
	public String toString() {
		return "AppNotificationListRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage
				+ ", appNotifications=" + appNotifications + "]";
	}
}
