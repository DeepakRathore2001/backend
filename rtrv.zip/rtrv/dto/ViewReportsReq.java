package com.healogics.rtrv.dto;

public class ViewReportsReq {

	private String filters;
	private String filterOptions;
	private String retrieveStatus;
	private String insuranceType;
	private String docsLastSentStartDate;
	private String docsLastSentEndDate;
	private String bhcShipStartDate;
	private String bhcShipEndDate;
	private String bhcOrderReceivedStartDate;
	private String bhcOrderReceivedEndDate;
	private String docsFirstSentStartDate;
	private String docsFirstSentEndDate;
	private String noOfFilesSent;
	private int index;

	private int order;
	private String sortBy;

	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getDocsFirstSentStartDate() {
		return docsFirstSentStartDate;
	}
	public void setDocsFirstSentStartDate(String docsFirstSentStartDate) {
		this.docsFirstSentStartDate = docsFirstSentStartDate;
	}
	public String getDocsFirstSentEndDate() {
		return docsFirstSentEndDate;
	}
	public void setDocsFirstSentEndDate(String docsFirstSentEndDate) {
		this.docsFirstSentEndDate = docsFirstSentEndDate;
	}

	public String getNoOfFilesSent() {
		return noOfFilesSent;
	}
	public void setNoOfFilesSent(String noOfFilesSent) {
		this.noOfFilesSent = noOfFilesSent;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getFilters() {
		return filters;
	}
	public void setFilters(String filters) {
		this.filters = filters;
	}
	public String getDocsLastSentStartDate() {
		return docsLastSentStartDate;
	}
	public void setDocsLastSentStartDate(String docsLastSentStartDate) {
		this.docsLastSentStartDate = docsLastSentStartDate;
	}
	public String getDocsLastSentEndDate() {
		return docsLastSentEndDate;
	}
	public void setDocsLastSentEndDate(String docsLastSentEndDate) {
		this.docsLastSentEndDate = docsLastSentEndDate;
	}
	public String getBhcShipStartDate() {
		return bhcShipStartDate;
	}
	public void setBhcShipStartDate(String bhcShipStartDate) {
		this.bhcShipStartDate = bhcShipStartDate;
	}
	public String getBhcShipEndDate() {
		return bhcShipEndDate;
	}
	public void setBhcShipEndDate(String bhcShipEndDate) {
		this.bhcShipEndDate = bhcShipEndDate;
	}
	public String getBhcOrderReceivedStartDate() {
		return bhcOrderReceivedStartDate;
	}
	public void setBhcOrderReceivedStartDate(String bhcOrderReceivedStartDate) {
		this.bhcOrderReceivedStartDate = bhcOrderReceivedStartDate;
	}
	public String getBhcOrderReceivedEndDate() {
		return bhcOrderReceivedEndDate;
	}
	public void setBhcOrderReceivedEndDate(String bhcOrderReceivedEndDate) {
		this.bhcOrderReceivedEndDate = bhcOrderReceivedEndDate;
	}
	
	public String getRetrieveStatus() {
		return retrieveStatus;
	}
	public void setRetrieveStatus(String retrieveStatus) {
		this.retrieveStatus = retrieveStatus;
	}
	public String getInsuranceType() {
		return insuranceType;
	}
	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}


	public String getFilterOptions() {
		return filterOptions;
	}
	public void setFilterOptions(String filterOptions) {
		this.filterOptions = filterOptions;
	}
	@Override
	public String toString() {
		return "ViewReportsReq [filters=" + filters + ", filterOptions=" + filterOptions + ", retrieveStatus="
				+ retrieveStatus + ", insuranceType=" + insuranceType + ", docsLastSentStartDate="
				+ docsLastSentStartDate + ", docsLastSentEndDate=" + docsLastSentEndDate + ", bhcShipStartDate="
				+ bhcShipStartDate + ", bhcShipEndDate=" + bhcShipEndDate + ", bhcOrderReceivedStartDate="
				+ bhcOrderReceivedStartDate + ", bhcOrderReceivedEndDate=" + bhcOrderReceivedEndDate
				+ ", docsFirstSentStartDate=" + docsFirstSentStartDate + ", docsFirstSentEndDate="
				+ docsFirstSentEndDate + ", noOfFilesSent=" + noOfFilesSent + ", index=" + index + ", order=" + order
				+ ", sortBy=" + sortBy + "]";
	}

}
