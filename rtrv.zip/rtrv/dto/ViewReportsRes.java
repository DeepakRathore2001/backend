package com.healogics.rtrv.dto;

import java.util.List;

public class ViewReportsRes {

	private String responseCode;
	private String responseMessage;
	private List<ViewReportsDetails> reports;
	private int currentIndex;
	private int nextIndex;
	private double totalPage;
	private Long totalCount;
	private boolean isExhausted;

	public int getCurrentIndex() {
		return currentIndex;
	}
	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	public int getNextIndex() {
		return nextIndex;
	}
	public void setNextIndex(int nextIndex) {
		this.nextIndex = nextIndex;
	}
	public double getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(double totalPage) {
		this.totalPage = totalPage;
	}
	public Long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}
	public boolean isExhausted() {
		return isExhausted;
	}
	public void setExhausted(boolean isExhausted) {
		this.isExhausted = isExhausted;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<ViewReportsDetails> getReports() {
		return reports;
	}
	public void setReports(List<ViewReportsDetails> reports) {
		this.reports = reports;
	}
	@Override
	public String toString() {
		return "ViewReportsRes [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", reports="
				+ reports + ", currentIndex=" + currentIndex + ", nextIndex="
				+ nextIndex + ", totalPage=" + totalPage + ", totalCount="
				+ totalCount + ", isExhausted=" + isExhausted + "]";
	}

}
