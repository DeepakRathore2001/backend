package com.healogics.rtrv.dto;

public class IHealDocument {
	private String docEntityId;
	private int visitId;
	private int versionId;
	private String docType;
	private String docName;
	private String docDate;
	private String visitDate;
	private String documentUUId;
	private String documentStatusId;
	private String documentStatus;
	private int isSubmitted;

	public int getIsSubmitted() {
		return isSubmitted;
	}
	public void setIsSubmitted(int isSubmitted) {
		this.isSubmitted = isSubmitted;
	}
	public int getVersionId() {
		return versionId;
	}
	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}
	public String getDocumentStatusId() {
		return documentStatusId;
	}
	public void setDocumentStatusId(String documentStatusId) {
		this.documentStatusId = documentStatusId;
	}
	public String getDocumentStatus() {
		return documentStatus;
	}
	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}
	public String getDocumentUUId() {
		return documentUUId;
	}
	public void setDocumentUUId(String documentUUId) {
		this.documentUUId = documentUUId;
	}
	public String getVisitDate() {
		return visitDate;
	}
	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}
	public int getVisitId() {
		return visitId;
	}
	public void setVisitId(int visitId) {
		this.visitId = visitId;
	}
	public String getDocEntityId() {
		return docEntityId;
	}
	public void setDocEntityId(String docEntityId) {
		this.docEntityId = docEntityId;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
	@Override
	public String toString() {
		return "IHealDocument [docEntityId=" + docEntityId + ", visitId="
				+ visitId + ", versionId=" + versionId + ", docType=" + docType
				+ ", docName=" + docName + ", docDate=" + docDate
				+ ", visitDate=" + visitDate + ", documentUUId=" + documentUUId
				+ ", documentStatusId=" + documentStatusId + ", documentStatus="
				+ documentStatus + ", isSubmitted=" + isSubmitted + "]";
	}

}
