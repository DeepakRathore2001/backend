package com.healogics.rtrv.dto;

import java.util.List;

public class SolvemtumErrorDetails {
	private int errorCode;
	private List<String> errorMessages;
	private String domain;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public List<String> getErrorMessages() {
		return errorMessages;
	}

	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "SolvemtumErrorDetails [errorCode=" + errorCode + ", errorMessages=" + errorMessages + ", domain="
				+ domain + "]";
	}
}
