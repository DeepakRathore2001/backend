package com.healogics.rtrv.dto;

public class WoundQOrderInsuranceObj {

	private String insuranceName;
	private Long insuranceId;
	private String policyNumber;
	private int sequence;

	public String getInsuranceName() {
		return insuranceName;
	}

	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}

	public Long getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(Long insuranceId) {
		this.insuranceId = insuranceId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	@Override
	public String toString() {
		return "WoundQOrderInsuranceObj [insuranceName=" + insuranceName + ", insuranceId=" + insuranceId
				+ ", policyNumber=" + policyNumber + ", sequence=" + sequence + "]";
	}

}
