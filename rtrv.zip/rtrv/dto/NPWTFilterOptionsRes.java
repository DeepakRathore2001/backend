package com.healogics.rtrv.dto;

public class NPWTFilterOptionsRes extends APIResponse {

	private NPWTFilterOptions filterOptions;

	public NPWTFilterOptions getFilterOptions() {
		return filterOptions;
	}

	public void setFilterOptions(NPWTFilterOptions filterOptions) {
		this.filterOptions = filterOptions;
	}

	@Override
	public String toString() {
		return "NPWTFilterOptionsRes [filterOptions=" + filterOptions + "]";
	}

}
