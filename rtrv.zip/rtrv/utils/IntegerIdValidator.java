package com.healogics.rtrv.utils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class IntegerIdValidator implements ConstraintValidator<ValidIntegerId, Integer>{
	
	private String fieldName;
	
	@Override
	public void initialize(ValidIntegerId constraint) {
		this.fieldName = constraint.fieldName();
	}
	
	@Override
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
		if(value == null) {
			return false;
		}
		String valueAsString = value.toString();
		boolean isValid = valueAsString.matches("\\d+");
		if(!isValid) {
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Invalid "+fieldName+""
					+ ": Must be numeric without special characters").addConstraintViolation();
		}
		return isValid;		
	}

}
