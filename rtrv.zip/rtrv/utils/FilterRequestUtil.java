package com.healogics.rtrv.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilterRequestUtil {

	public static List<String> getListFromDelimitedStr(String delimStr) {
		if (null != delimStr && !delimStr.isEmpty()) {
			return Arrays.asList(delimStr.split("#"));
		} else {
			return new ArrayList<>();
		}
	}
}
