package com.healogics.rtrv.utils;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Constraint(validatedBy = IntegerIdValidator.class)
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidIntegerId {

	String message() default "Invalid ID: must be numeric without special characters.";
	String fieldName();
	Class<?>[] groups() default{};
	Class<? extends Payload>[] payload() default{};
}
