package com.healogics.rtrv.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.Property;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.constants.BuildConstants;
import com.healogics.rtrv.entity.HeadlessBuild;
import com.healogics.rtrv.utils.AboutPopupUtil;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

@Service
@Component
public class AboutPopupUtil {

	private static final Logger logger = LoggerFactory
			.getLogger(AboutPopupUtil.class);

	public Properties readBuildProperties() {
		Properties prop = new Properties();
		try (FileReader reader = new FileReader(
				BuildConstants.BUILD_PROP_FILE_PATH)) {

			prop.load(reader);

			return prop;
		} catch (FileNotFoundException e) {
			logger.debug(String.format("FileNotFoundException occured - %s",
					e.getMessage()));
		} catch (IOException e) {
			logger.debug(
					String.format("IOException occured - %s", e.getMessage()));
		}
		return prop;
	}
	public Map<String, String> readGitProperties() {
		Map<String, String> gitPropMap = new HashMap<>();

		Properties prop = new Properties();

		try (FileReader reader = new FileReader(
				BuildConstants.GIT_PROP_FILE_PATH)) {
			// Read JSON file
			prop.load(reader);
			JSONObject gitProperties = Property.toJSONObject(prop);
			String version = (String) gitProperties.get("git.closest.tag.name");

			if (version.split("_").length > 1) {
				version = version.split("_")[1];
			}

			gitPropMap.put(BuildConstants.GIT_PROP_REVISION,
					(String) gitProperties.get("git.commit.id"));
			gitPropMap.put(BuildConstants.GIT_PROP_USERID,
					(String) gitProperties.get("git.commit.user.name"));
		} catch (FileNotFoundException e) {
			logger.debug(String.format("FileNotFoundException occured - %s",
					e.getMessage()));
		} catch (IOException e) {
			logger.debug(
					String.format("IOException occured - %s", e.getMessage()));
		} catch (JSONException e) {
			logger.debug(String.format("JSONException occured - %s",
					e.getMessage()));
		}
		return gitPropMap;
	}

	public void saveBuildInDynamo(Map<String, String> gitPropMap,
			Properties buildProp) {
		try {
			Region region = Region.US_EAST_1;

			DynamoDbClient ddb = DynamoDbClient.builder().region(region)
					.credentialsProvider(StaticCredentialsProvider
							.create(AwsBasicCredentials.create(
									buildProp.getProperty(
											BuildConstants.AWS_ACCESSKEY),
									buildProp.getProperty(
											BuildConstants.AWS_SECRETKEY))))
					.build();

			if (ddb == null) {
				logger.debug("Unable to connect to AWS DynamoDB!"
						+ " Please check Region and SECRECT_ID and KEY");
				System.exit(1);
			}

			DynamoDbEnhancedClient enhancedClient = DynamoDbEnhancedClient
					.builder().dynamoDbClient(ddb).build();
			if (enhancedClient == null) {
				logger.debug("Unable to connect to AWS DynamoDB Client!");
				System.exit(1);
			}

			DynamoDbTable<HeadlessBuild> mappedTable = enhancedClient.table(
					BuildConstants.DYNAMO_TABLE_NAME,
					TableSchema.fromClass(HeadlessBuild.class));
			if (mappedTable == null) {
				logger.debug("Unable to connect to AWS DynamoDB Table"
						+ " - app_build_version");
				System.exit(1);
			}

			logger.debug("Successfully Connected to Dynamodb Table"
					+ " - app_build_version");

			// Save build details to dynamoDB table
			saveBuildDetailsInDynamo(mappedTable, gitPropMap, buildProp);

			// To close Dynamodb connection after completing the operation
			ddb.close();
		} catch (Exception e) {
			logger.debug(
					String.format("Exception occured : %s", e.getMessage()));
			System.exit(1);
		}
	}

	public void saveBuildDetailsInDynamo(
			DynamoDbTable<HeadlessBuild> mappedTable,
			Map<String, String> gitPropMap, Properties buildProp) {
		try {

			HeadlessBuild bd = new HeadlessBuild();
			bd.setEnvironment(buildProp
					.getProperty(BuildConstants.BUILD_APP_ENVIRONMENT));
			bd.setAppName(buildProp.getProperty(BuildConstants.BUILD_APP_NAME));
			bd.setComponent(
					buildProp.getProperty(BuildConstants.BUILD_APP_COMPONENT));
			bd.setBuildVersion(
					buildProp.getProperty(BuildConstants.BUILD_APP_VERSION));
			bd.setAppVersion(gitPropMap.get(BuildConstants.GIT_PROP_REVISION));
			bd.setAppPlatform(
					buildProp.getProperty(BuildConstants.BUILD_APP_PLATFORM));
			bd.setLastUpdatedBy(gitPropMap.get(BuildConstants.GIT_PROP_USERID));
			String currentDate = CommonUtils
					.getCurrentDate(BuildConstants.TIMESTAMP_FORMAT);
			bd.setLastUpdatedTime(currentDate);
			bd.setPk(buildProp.getProperty(BuildConstants.BUILD_APP_NAME) + "#"
					+ buildProp
							.getProperty(BuildConstants.BUILD_APP_ENVIRONMENT)
					+ "#" + buildProp
							.getProperty(BuildConstants.BUILD_APP_COMPONENT));
			//bd.setSk(currentDate);
			bd.setSk(buildProp.getProperty(BuildConstants.BUILD_APP_NAME) + "#"
					+ buildProp
							.getProperty(BuildConstants.BUILD_APP_ENVIRONMENT)
					+ "#" + buildProp
							.getProperty(BuildConstants.BUILD_APP_COMPONENT));
			
			System.out.println("bd: " +bd);
			
			PutItemEnhancedRequest<HeadlessBuild> enReq = PutItemEnhancedRequest
					.builder(HeadlessBuild.class).item(bd).build();
			mappedTable.putItem(enReq);
		} catch (Exception e) {
			logger.error(String.format(
					"Exception occured while saving"
							+ " Build Details to dynamoDB table: %s",
					e.getMessage()));
			System.exit(1);
		}

		logger.info("Application Version : "
				+ buildProp.getProperty(BuildConstants.BUILD_APP_VERSION));
		logger.info("Build Version : "
				+ gitPropMap.get(BuildConstants.GIT_PROP_REVISION));
		logger.info(
				"Application and Build version are successfully saved into Database");
	}

}
