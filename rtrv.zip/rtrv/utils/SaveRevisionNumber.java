package com.healogics.rtrv.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Properties;

public class SaveRevisionNumber {
    private static Logger logger = LoggerFactory.getLogger(SaveRevisionNumber.class);


    public static void main(String[] args) {
       AboutPopupUtil aboutPopupUtil = new AboutPopupUtil();
        Properties buildProp = aboutPopupUtil.readBuildProperties();

        if (buildProp.isEmpty()) {
            logger.debug("Build properties are empty!");
            System.exit(1);
        }

        Map<String, String> gitPropMap = aboutPopupUtil.readGitProperties();

        if (gitPropMap.isEmpty()) {
            logger.debug("Git properties are empty!");
            System.exit(1);
        }

        //Save build details to dynamo
        aboutPopupUtil.saveBuildInDynamo(gitPropMap, buildProp);
    	//readS3Buckets();
    }
}
