package com.healogics.rtrv.utils;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

public class CryptoServer {

	 private final int keySize;
	    private final int iterationCount;
	    private final Cipher cipher;

	    private static CryptoServer instance = null;
	    private static String utf = "UTF-8";

	    private CryptoServer(int keySize, int iterationCount) {
	        this.keySize = keySize;
	        this.iterationCount = iterationCount;
	        try {
	            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
	        }
	        catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
	            throw fail(e);
	        }
	    }

	    public static CryptoServer getKey(int keySize, int iterationCount){
	        if (instance == null)
	            instance = new CryptoServer(keySize,iterationCount);
	        return instance;
	    }

	    public String encrypt(String salt, String passphrase, String plaintext) {
	        try {
	            SecretKey key = generateKey(salt, passphrase);
	            byte[] encrypted = doFinal(Cipher.ENCRYPT_MODE, key, plaintext.getBytes(utf));
	            return base64(encrypted);
	        }
	        catch (UnsupportedEncodingException e) {
	            throw fail(e);
	        }
	    }

	    public String decrypt(String salt, String passphrase, String ciphertext) {
	        try {
	            SecretKey key = generateKey(salt, passphrase);
	            byte[] decrypted = doFinal(Cipher.DECRYPT_MODE, key, base64decode(ciphertext.getBytes(utf)));
	            return new String(decrypted, utf);
	        }
	        catch (UnsupportedEncodingException e) {
	            throw fail(e);
	        }
	    }

	    private byte[] doFinal(int encryptMode, SecretKey key, byte[] bytes) throws UnsupportedEncodingException {
	        try {
	            byte[] iV = {1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1};
	            IvParameterSpec ivspec = new IvParameterSpec(iV);

	            cipher.init(encryptMode, key, ivspec);
	            return cipher.doFinal(bytes);
	        }
	        catch (InvalidKeyException | InvalidAlgorithmParameterException
	               | IllegalBlockSizeException | BadPaddingException e) {
	            throw fail(e);
	        }
	    }

	    private SecretKey generateKey(String salt, String passphrase) throws UnsupportedEncodingException {
	        try {
	            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
	            KeySpec spec = new PBEKeySpec(passphrase.toCharArray(), (salt.getBytes(utf)),
	                    iterationCount, keySize);
	            return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
	        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
	            throw fail(e);
	        }
	    }

	    public static String random(int length) {
	        byte[] salt = new byte[length];
	        new SecureRandom().nextBytes(salt);
	        return hex(salt);
	    }

	    public static String base64(byte[] bytes) {
	        return Base64.encodeBase64String(bytes);
	    }

	    public static byte[] base64(String str) {
	        return Base64.decodeBase64(str);
	    }

	    public static byte[] base64decode(byte[] bytes) {
	        return Base64.decodeBase64(bytes);
	    }

	    public static String hex(byte[] bytes) {
	        return Hex.encodeHexString(bytes);
	    }

	    public static byte[] hex(String str) {
	        try {
	            return Hex.decodeHex(str.toCharArray());
	        }
	        catch (DecoderException e) {
	            throw new IllegalStateException(e);
	        }
	    }

	    private IllegalStateException fail(Exception e) {
	        return new IllegalStateException(e);
	    }
	
}
