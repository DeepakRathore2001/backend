package com.healogics.rtrv.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.healogics.rtrv.constants.CryptoConstants;
import com.healogics.rtrv.constants.UtilConstants;

public class CommonUtils {

	private CommonUtils() {
	}

	public static String getformattedDate() {
		String dateFormat = UtilConstants.TIMESTAMP_FORMAT_WITH_T;
		String formattedDate;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.ENGLISH);
		formattedDate = sdf.format(timestamp);
		return formattedDate;
	}

	public static Map<String, Object> getMessageHeader(String action, String timeStamp) {
		Map<String, Object> messageHeader = new HashMap<>();
		messageHeader.put(UtilConstants.TIMESTAMP, timeStamp);
		messageHeader.put(UtilConstants.ACTION, action);
		return messageHeader;
	}

	public static String getTargetDateFormat(String sourceDateformat, String targetDateFormat, String date)
			throws Exception {
		if (date == null || date.isEmpty()) {
			return date;
		}

		DateFormat originalFormat = new SimpleDateFormat(sourceDateformat);
		DateFormat targetFormat = new SimpleDateFormat(targetDateFormat);
		Date fdate;
		try {
			fdate = originalFormat.parse(date);
		} catch (ParseException excp) {
			throw new Exception(excp.getMessage());
		}
		return targetFormat.format(fdate);
	}
	
	public static String formatDate(String sourceDateformat, 
			Date date)
			throws Exception {
		if (date == null) {
			return "";
		}
		
		DateFormat targetFormat = new SimpleDateFormat(sourceDateformat);
		return targetFormat.format(date);

	}

	public static Map<String, Object> getResponseObject(String action, String statusCode, String responseCode,
			String responseDesc) {
		String formattedDate = getformattedDate();
		Map<String, Object> response = new HashMap<>();
		response.put("timestamp", formattedDate);
		response.put("action", action);
		response.put("statuscode", statusCode);
		response.put("responseCode", responseCode);
		response.put("responseDesc", responseDesc);
		return response;
	}

	public static Map<Integer, String> getMonth() {
		Map<Integer, String> monthMap = new HashMap<>();

		monthMap.put(1, "Jan");
		monthMap.put(2, "Feb");
		monthMap.put(3, "Mar");
		monthMap.put(4, "Apr");
		monthMap.put(5, "May");
		monthMap.put(6, "Jun");
		monthMap.put(7, "Jul");
		monthMap.put(8, "Aug");
		monthMap.put(9, "Sep");
		monthMap.put(10, "Oct");
		monthMap.put(11, "Nov");
		monthMap.put(12, "Dec");

		return monthMap;
	}

	public static String getEncryptedString(String plainText) {
		return CryptoServer.getKey(CryptoConstants.AES_KEY_SIZE, CryptoConstants.AES_ITERATION_COUNT)
				.encrypt(CryptoConstants.AES_SALT, CryptoConstants.AES_PASPHRASE, plainText);
	}

	public static String getDecryptedString(String encryptedText) {
		return CryptoServer.getKey(CryptoConstants.AES_KEY_SIZE, CryptoConstants.AES_ITERATION_COUNT)
				.decrypt(CryptoConstants.AES_SALT, CryptoConstants.AES_PASPHRASE, encryptedText);
	}

	public static String getCurrentDate(String dateformat) {
		Date today = new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(today);
		SimpleDateFormat sdf = new SimpleDateFormat(dateformat, Locale.ENGLISH);
		return sdf.format(cal.getTime());
	}
	
	public static Date getDateObj(String dateformat, String dateStr) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(dateformat, Locale.ENGLISH);
		Date dateObj = null;
		try {
			dateObj = sdf.parse(dateStr);
		} catch (ParseException e) {
			throw new Exception(e.getMessage());
		}
		return dateObj;
	}
	
	public static String formatLocalDate(LocalDate date) throws Exception {
		String dateObj = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		try {
			dateObj = date.format(formatter);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return dateObj;
	}
	
	public static Date formatStringToDate(String date) throws Exception {
		Date dateObj = null;
		Date finalDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			dateObj = dateFormat.parse(date);
			String dateString = dateFormat1.format(dateObj);
			finalDate = dateFormat1.parse(dateString);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return finalDate;
	}
	
	public static LocalDate formatStringToLocalDate(String date) throws Exception {
		LocalDate dateObj = null;
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		try {
			LocalDate date1 = LocalDate.parse(date, formatter);
			String formatDateString = date1.format(format);
			dateObj = LocalDate.parse(formatDateString);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return dateObj;
	}

	public static void main(String[] args) {
		//System.out.println("getEncryptedString : username " + getEncryptedString("uma_uat"));
		//System.out.println("getEncryptedString : password " + getEncryptedString("HealJan2023!!"));
		
		
		
		try {
			System.out.println("getCurrentDate : " +CommonUtils.getDateObj("yyyy-MM-dd", 
					CommonUtils.getCurrentDate("yyyy-MM-dd")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
