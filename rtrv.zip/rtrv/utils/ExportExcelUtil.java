package com.healogics.rtrv.utils;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.dto.AWDData;
import com.healogics.rtrv.dto.CTPData;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.HistoryTimelineDocStatus;
import com.healogics.rtrv.dto.HistoryUserNotes;
import com.healogics.rtrv.dto.ICD10Data;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.NPWTReportData;
import com.healogics.rtrv.dto.PrimaryInsuranceMaster;
import com.healogics.rtrv.dto.RetrieveMembersDetails;
import com.healogics.rtrv.dto.SecondaryInsuranceMaster;
import com.healogics.rtrv.dto.TaggedUser;
import com.healogics.rtrv.dto.TertiaryInsuranceMaster;
import com.healogics.rtrv.dto.UniformData;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.dto.ViewReportsDetails;
import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentStore;
import com.healogics.rtrv.entity.DocumentationHistory2;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.entity.PatientMedicalRecords;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.entity.UserNotes2;

public class ExportExcelUtil {

	private static final Logger log = LoggerFactory.getLogger(ExportExcelUtil.class);

	public static String generateDashboardExcel(DashboardReq req, List<AWDData> awdRecords) throws IOException {
		log.info("Inside Generate Excel method..................");

		String sheetName = "" + req.getServiceLine() + "_dashboard";

		String[] columnName;

		for (AWDData awd : awdRecords) {
			log.debug("Before calculate age ");
			if (awd.getFirstReceived() != null) {
				awd.setAge(calculateAge(awd.getFirstReceived()));
			} else {
				awd.setAge(null);
			}
			log.debug("After calculate age ");
		}

		if (req.getSortBy().equalsIgnoreCase("age")) {
			log.debug("Sort by age ");
			Comparator<AWDData> comparator = (o1, o2) -> {
				Integer age1 = parseAge(o1.getAge());
				Integer age2 = parseAge(o2.getAge());

				int result = 0;
				if (age1 != null && age2 != null) {
					result = Integer.compare(age1, age2);
				} else if (age1 != null) {
					result = 1;
				} else if (age2 != null) {
					result = -1;
				}

				if (req.getOrder() == 1) {
					result = -result;
				}
				return result;
			};
			Collections.sort(awdRecords, comparator);

		}

		columnName = req.getExcelColumns().split("%");

		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			Row headerRow = sheet.createRow(0);

			CellStyle headerStyle = workbook.createCellStyle();
			headerStyle.setAlignment(HorizontalAlignment.CENTER);
			headerStyle.setBorderTop(BorderStyle.MEDIUM);
			headerStyle.setBorderBottom(BorderStyle.MEDIUM);
			headerStyle.setBorderLeft(BorderStyle.MEDIUM);
			headerStyle.setBorderRight(BorderStyle.MEDIUM);

			Font dataHeaderFont = workbook.createFont();
			dataHeaderFont.setBold(true);
			dataHeaderFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			dataHeaderFont.setFontHeightInPoints((short) 11);
			headerStyle.setFont(dataHeaderFont);

			CellStyle dataStyle = workbook.createCellStyle();
			dataStyle.setAlignment(HorizontalAlignment.LEFT);
			dataStyle.setBorderTop(BorderStyle.MEDIUM);
			dataStyle.setBorderBottom(BorderStyle.MEDIUM);
			dataStyle.setBorderLeft(BorderStyle.MEDIUM);
			dataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font cellFont = workbook.createFont();
			cellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			cellFont.setFontHeightInPoints((short) 11);
			dataStyle.setFont(cellFont);

			CellStyle emptyDataStyle = workbook.createCellStyle();
			emptyDataStyle.setAlignment(HorizontalAlignment.CENTER);
			emptyDataStyle.setBorderTop(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderBottom(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderLeft(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font emptyCellFont = workbook.createFont();
			emptyCellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			emptyCellFont.setFontHeightInPoints((short) 11);
			emptyDataStyle.setFont(emptyCellFont);

			for (int i = 0; i < columnName.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columnName[i]);
				cell.setCellStyle(headerStyle);
			}
			int rowNum = 1;

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

			log.info("Inside Generate Excel method 22....................");
			for (AWDData data : awdRecords) {
				int columnId = 0;
				Row row = sheet.createRow(rowNum++);
				// log.debug("inside loop....................");

				for (String column : columnName) {
					switch (column) {
					case "BBC": {
						Cell bbc = row.createCell(columnId++);
						if (data.getBbc() != null && !data.getBbc().isEmpty()) {
							bbc.setCellValue(data.getBbc());
							bbc.setCellStyle(dataStyle);
						} else {
							bbc.setCellValue(" - ");
							bbc.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor": {
						Cell vendor = row.createCell(columnId++);
						if (data.getVendor() != null && !data.getVendor().isEmpty()) {
							vendor.setCellValue(data.getVendor().replace(",", " "));
							vendor.setCellStyle(dataStyle);
						} else {
							vendor.setCellValue(" - ");
							vendor.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Med Rec ID": {

						Cell medRecId = row.createCell(columnId++);
						if (data.getBhcMedRecId() != 0) {
							medRecId.setCellValue(data.getBhcMedRecId());
							medRecId.setCellStyle(dataStyle);
						} else {
							medRecId.setCellValue(" - ");
							medRecId.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Order #": {
						Cell bhcInvoiceId = row.createCell(columnId++);
						if (data.getBhcInvoiceOrderId() != null && !data.getBhcInvoiceOrderId().isEmpty()) {
							bhcInvoiceId.setCellValue(data.getBhcInvoiceOrderId());
							bhcInvoiceId.setCellStyle(dataStyle);
						} else {
							bhcInvoiceId.setCellValue(" - ");
							bhcInvoiceId.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Age": {
						Cell age = row.createCell(columnId++);
						if (data.getAge() != null && !data.getAge().isEmpty()) {
							age.setCellValue(data.getAge());
							age.setCellStyle(dataStyle);
						} else {
							age.setCellValue(" - ");
							age.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Patient Name": {
						Cell patientName = row.createCell(columnId++);
						if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
							patientName.setCellValue(data.getPatientName().replace(",", " "));
							patientName.setCellStyle(dataStyle);
						} else {
							patientName.setCellValue(" - ");
							patientName.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Patient DOB": {
						Cell patientDOB = row.createCell(columnId++);
						if (data.getPatientDOB() != null) {
							patientDOB.setCellValue(data.getPatientDOB());
							patientDOB.setCellStyle(dataStyle);
						} else {
							patientDOB.setCellValue(" - ");
							patientDOB.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Assigned To": {
						Cell assignedTo = row.createCell(columnId++);
						if (data.getAssignedTo() != null && !data.getAssignedTo().isEmpty()) {
							assignedTo.setCellValue(data.getAssignedTo().replace(",", " "));
							assignedTo.setCellStyle(dataStyle);
						} else {
							assignedTo.setCellValue(" - ");
							assignedTo.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Last Team Update": {
						Cell lastTeamUpdatedDate = row.createCell(columnId++);
						if (data.getLastTeamUpdated() != null) {

							Calendar calendar = Calendar.getInstance();
							calendar.setTime(data.getLastTeamUpdated());

							calendar.add(Calendar.MINUTE, req.getOffsetMinutes());

							Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

							String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
							lastTeamUpdatedDate.setCellValue(formatlLastTeamUpdatedDate);
							lastTeamUpdatedDate.setCellStyle(dataStyle);
						} else {
							lastTeamUpdatedDate.setCellValue(" - ");
							lastTeamUpdatedDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Response Date": {
						Cell shipDate = row.createCell(columnId++);
						if (data.getBhcLastUpdateDate() != null) {

							String formatShipDate = dateFormat.format(data.getBhcLastUpdateDate());
							shipDate.setCellValue(formatShipDate);
							shipDate.setCellStyle(dataStyle);
						} else {
							shipDate.setCellValue(" - ");
							shipDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Order Source": {
						Cell bhcOrderSource = row.createCell(columnId++);
						if (data.getBhcOrderSource() != null && !data.getBhcOrderSource().isEmpty()) {
							bhcOrderSource.setCellValue(data.getBhcOrderSource().replace(",", " "));
							bhcOrderSource.setCellStyle(dataStyle);
						} else {
							bhcOrderSource.setCellValue(" - ");
							bhcOrderSource.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "i-heal Config": {
						Cell iHealConfiguration = row.createCell(columnId++);
						if (data.getiHealConfiguration() != null && !data.getiHealConfiguration().isEmpty()) {
							iHealConfiguration.setCellValue(data.getiHealConfiguration());
							iHealConfiguration.setCellStyle(dataStyle);
						} else {
							iHealConfiguration.setCellValue(" - ");
							iHealConfiguration.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Follow-up Date": {
						Cell followupDate = row.createCell(columnId++);
						if (data.getFollowupDate() != null) {

							String formatFollowupDate = dateFormat.format(data.getFollowupDate());
							followupDate.setCellValue(formatFollowupDate);
							followupDate.setCellStyle(dataStyle);
						} else {
							followupDate.setCellValue(" - ");
							followupDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Retrieve Status": {
						Cell statusCell = row.createCell(columnId++);
						if (data.getStatus() != null && !data.getStatus().isEmpty()) {
							statusCell.setCellValue(data.getStatus().replace(",", " "));
							CellStyle statusCellStyle = createStatusCellStyle(workbook, data.getStatus());
							statusCell.setCellStyle(statusCellStyle);
						} else {
							statusCell.setCellValue(" - ");
							statusCell.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Status": {
						Cell bhcDocStatus = row.createCell(columnId++);
						if (data.getBhcDocStatus() != null && !data.getBhcDocStatus().isEmpty()) {
							bhcDocStatus.setCellValue(data.getBhcDocStatus().replace(",", " "));
							bhcDocStatus.setCellStyle(dataStyle);
						} else {
							bhcDocStatus.setCellValue(" - ");
							bhcDocStatus.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Notes": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getBhcMissingDocNotes() != null && !data.getBhcMissingDocNotes().isEmpty()) {
							bhcMissingDocNotes.setCellValue(data.getBhcMissingDocNotes().replace(",", " "));
							bhcMissingDocNotes.setCellStyle(dataStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Insurance": {
						Cell insuranceType = row.createCell(columnId++);
						if (data.getInsuranceType() != null && !data.getInsuranceType().isEmpty()) {
							insuranceType.setCellValue(data.getInsuranceType().replace(",", " "));
							insuranceType.setCellStyle(dataStyle);
						} else {
							insuranceType.setCellValue(" - ");
							insuranceType.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Vendor Patient #": {
						Cell bhcAcctId = row.createCell(columnId++);
						if (data.getBhcPatientAcctId() != null && !data.getBhcPatientAcctId().isEmpty()) {
							bhcAcctId.setCellValue(data.getBhcPatientAcctId().replace(",", " "));
							bhcAcctId.setCellStyle(dataStyle);
						} else {
							bhcAcctId.setCellValue(" - ");
							bhcAcctId.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Provider": {
						Cell providerName = row.createCell(columnId++);
						if (data.getProviderName() != null && !data.getProviderName().isEmpty()) {
							providerName.setCellValue(data.getProviderName().replace(",", " "));
							providerName.setCellStyle(dataStyle);
						} else {
							providerName.setCellValue(" - ");
							providerName.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Vendor Order Date": {
						Cell shipDate = row.createCell(columnId++);
						if (data.getBhcShipDate() != null) {

							String formatShipDate = dateFormat.format(data.getBhcShipDate());
							shipDate.setCellValue(formatShipDate);
							shipDate.setCellStyle(dataStyle);
						} else {
							shipDate.setCellValue(" - ");
							shipDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					}
				}

			}
			log.debug("After loop....................");

			for (int i = 0; i < columnName.length; i++) {
				int maxContentWidth = 0;
				for (int j = 0; j <= sheet.getLastRowNum(); j++) {
					Row row = sheet.getRow(j);
					if (row != null) {
						Cell cell = row.getCell(i);
						if (cell != null) {
							int contentWidth;
							if (cell.getCellType() == CellType.STRING) {
								contentWidth = (cell.getStringCellValue().length() + 2) * 256; // Adding
																								// some
																								// padding
							} else if (cell.getCellType() == CellType.NUMERIC) {
								contentWidth = (String.valueOf(cell.getNumericCellValue()).length() + 2) * 256;
							} else {
								contentWidth = 0; // Handle other cell types as
													// needed
							}

							if (contentWidth > maxContentWidth) {
								maxContentWidth = contentWidth;
							}
						}
					}
				}
				// Set a reasonable maximum width, e.g., 8000 (adjust as needed)
				sheet.setColumnWidth(i, Math.min(maxContentWidth, 8000));
			}

			log.debug("After autoSizeColumn Loop.................");
			sheet.setAutoFilter(
					new CellRangeAddress(sheet.getFirstRowNum(), sheet.getFirstRowNum(), 0, columnName.length - 1));
			workbook.write(output);
			workbook.close();
			log.debug("workbook close....................");
			byte[] byteArray = output.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(byteArray);
			return base64Str;

		} catch (IOException e) {
			log.error("Exception occured at excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}

	}

	private static Integer parseAge(String age) {
		Integer totalDays = 0;
		if (age == null || age.isEmpty()) {
			return null;
		}
		if (age.equalsIgnoreCase("0")) {
			return totalDays;
		}
		Pattern pattern = Pattern.compile("(?:(\\d+) years)? ?(?:(\\d+) days)? ");
		Matcher matcher = pattern.matcher(age);
		if (matcher.matches()) {
			String years = matcher.group(1);
			String days = matcher.group(2);

			if (years != null) {
				totalDays += Integer.parseInt(years) * 365;
			}
			if (days != null) {
				totalDays += Integer.parseInt(days);
			}

		}
		return totalDays;
	}

	private static String calculateAge(Date firstReceivedDate) {
		Instant recordAddedInstant = firstReceivedDate.toInstant();
		Instant currentInsant = Instant.now();
		String age = null;
		if (firstReceivedDate != null) {

			if (Duration.between(recordAddedInstant, currentInsant).toHours() < 24) {
				return age = "0";
			}

			LocalDate recordAddedLocalDate = recordAddedInstant.atZone(ZoneId.systemDefault()).toLocalDate();

			long totalDays = ChronoUnit.DAYS.between(recordAddedLocalDate, LocalDate.now());
			age = totalDays + " days";
			/*
			 * long years = totalDays / 365;
			 * 
			 * long remainingDays = totalDays % 365; if (years == 0) { age = remainingDays +
			 * " days "; } else { age = years + " years " + remainingDays + " days "; }
			 */
		}
		return age;
	}

	private static CellStyle createStatusCellStyle(XSSFWorkbook workbook, String status) {

		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		if ("New".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.LIME.getIndex());
		} else if ("Exhausted".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.RED.getIndex());
		} else if ("Closed".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
		} else if ("Returned".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.SKY_BLUE.getIndex());
		} else if ("Submitted".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.BLACK.getIndex());
		} else if ("Completed".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.GREEN.getIndex());
		} else if ("MedAdv".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.DARK_BLUE.getIndex());
		} else if ("Med Adv Pending".equalsIgnoreCase(status)) {
			font.setColor(IndexedColors.PLUM.getIndex());
		} else {
			font.setColor(IndexedColors.GOLD.getIndex());
		}

		style.setAlignment(HorizontalAlignment.LEFT);
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM);

		font.setFontHeightInPoints((short) 11);
		style.setFont(font);

		return style;
	}

	private static CellStyle createHeaderStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM);

		Font font = workbook.createFont();
		font.setBold(true);
		font.setColor(IndexedColors.BLACK.getIndex());
		font.setFontHeightInPoints((short) 11);
		style.setFont(font);

		return style;
	}

	private static CellStyle createDataStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.LEFT);
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM);

		Font cellFont = workbook.createFont();
		cellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		cellFont.setFontHeightInPoints((short) 11);
		style.setFont(cellFont);

		return style;
	}

	private static CellStyle createEmptyDataStyle(XSSFWorkbook workbook) {
		CellStyle style = workbook.createCellStyle();
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setBorderTop(BorderStyle.MEDIUM);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setBorderLeft(BorderStyle.MEDIUM);
		style.setBorderRight(BorderStyle.MEDIUM);

		Font emptyCellFont = workbook.createFont();
		emptyCellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
		emptyCellFont.setFontHeightInPoints((short) 11);
		style.setFont(emptyCellFont);

		return style;
	}

	public static String generateReportsExcel(List<ViewReportsDetails> reports) {
		log.info("Inside Generate Excel method....................");

		String sheetName = "Reports";

		String[] columnName;

		columnName = new String[] { "BBC", "Order Source", "Invoice #", "Medical Record ID", "Patient Acct #",
				"First Missing Doc Date", "Last Missing doc Date", "BHC Received Date", "BHC Ship Date",
				"Insurance Type", "Documents first sent", "Documents last sent", "# Days ≬ MDD & DLSD",
				"Last Retrieve Status", "# of Files Sent" };

		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			Row headerRow = sheet.createRow(0);

			CellStyle headerStyle = createHeaderStyle(workbook);
			CellStyle dataStyle = createDataStyle(workbook);
			CellStyle emptyDataStyle = createEmptyDataStyle(workbook);

			for (int i = 0; i < columnName.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columnName[i]);
				cell.setCellStyle(headerStyle);
			}
			int rowNum = 1;

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			/*
			 * SimpleDateFormat timeFormat = new SimpleDateFormat( "MM/dd/yyyy hh:mm a");
			 */

			log.info("Inside Generate Excel method....................");
			for (ViewReportsDetails data : reports) {

				int columnId = 0;
				Row row = sheet.createRow(rowNum++);

				createCell(row, columnId++, data.getBbc(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getBhcOrderSource(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getBhcInvoiceOrderId(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getBhcMedicalRecordId(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getBhcPatientAcctId(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getFirstReceived(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getLastReceived(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getBhcOrderReceivedDate(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getBhcShipDate(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getInsuranceCategory(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getDocsFirstSent(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getDocsLastSent(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getDateDifference(), dataStyle, emptyDataStyle);

				Cell statusCell = row.createCell(columnId++);
				if (data.getStatus() != null && !data.getStatus().isEmpty()) {
					statusCell.setCellValue(data.getStatus());
					CellStyle statusCellStyle = createStatusCellStyle(workbook, data.getStatus());
					statusCell.setCellStyle(statusCellStyle);
				} else {
					statusCell.setCellValue(" - ");
					statusCell.setCellStyle(emptyDataStyle);
				}

				createCell(row, columnId++, data.getNoFilesSent(), dataStyle, emptyDataStyle);

			}

			for (int i = 0; i < columnName.length; i++) {
				int maxContentWidth = 0;
				for (int j = 0; j <= sheet.getLastRowNum(); j++) {
					Row row = sheet.getRow(j);
					if (row != null) {
						Cell cell = row.getCell(i);
						if (cell != null) {
							int contentWidth;
							if (cell.getCellType() == CellType.STRING) {
								contentWidth = (cell.getStringCellValue().length() + 2) * 256; // Adding
																								// some
																								// padding
							} else if (cell.getCellType() == CellType.NUMERIC) {
								contentWidth = (String.valueOf(cell.getNumericCellValue()).length() + 2) * 256;
							} else {
								contentWidth = 0; // Handle other cell types as
													// needed
							}

							if (contentWidth > maxContentWidth) {
								maxContentWidth = contentWidth;
							}
						}
					}
				}
				// Set a reasonable maximum width, e.g., 8000 (adjust as needed)
				sheet.setColumnWidth(i, Math.min(maxContentWidth, 8000));
			}

			sheet.setAutoFilter(CellRangeAddress.valueOf("A1:O1"));
			workbook.write(output);
			workbook.close();

			byte[] byteArray = output.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(byteArray);
			return base64Str;

		} catch (IOException e) {
			log.error("Exception occured at excel file:  {}", e.getMessage());
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}

	private static void createCell(Row row, int column, Object value, CellStyle dataStyle, CellStyle emptyDataStyle) {
		createCell(row, column, value, dataStyle, emptyDataStyle, null);
	}

	private static void createCell(Row row, int column, Object value, CellStyle dataStyle, CellStyle emptyDataStyle,
			DateFormat dateFormat) {
		Cell cell = row.createCell(column);
		if (value != null) {
			if (value instanceof String) {
				String valueString = (String) value;
				if (!valueString.isEmpty()) {
					cell.setCellValue(valueString);
					cell.setCellStyle(dataStyle);
				} else {
					cell.setCellValue(" - ");
					cell.setCellStyle(emptyDataStyle);
				}
			} else if (value instanceof Number) {
				cell.setCellValue(((Number) value).doubleValue());
				cell.setCellStyle(dataStyle);
			} else if (value instanceof Date) {
				cell.setCellValue(dateFormat.format((Date) value));
				cell.setCellStyle(dataStyle);
			} else {
				cell.setCellValue(value.toString());
				cell.setCellStyle(dataStyle);
			}

		} else {
			cell.setCellValue(" - ");
			cell.setCellStyle(emptyDataStyle);
		}
	}

	public static String generateMasterDashboardExcel(MasterCTPDashboardReq req, List<CTPData> ctpRecords) {

		log.info("Inside Generate Excel method..................");

		String sheetName = "" + req.getServiceLine() + "_dashboard";

		String[] columnName;

		for (CTPData ctp : ctpRecords) {
			log.debug("Before calculate age ");
			if (ctp.getFirstReceived() != null) {
				ctp.setAge(calculateMasterAge(ctp.getFirstReceived()));
			} else {
				ctp.setAge(null);
			}
			log.debug("After calculate age ");
		}

		if (req.getSortBy().equalsIgnoreCase("age")) {
			log.debug("Sort by age ");
			Comparator<CTPData> comparator = (o1, o2) -> {
				Integer age1 = parseAge(o1.getAge());
				Integer age2 = parseAge(o2.getAge());

				int result = 0;
				if (age1 != null && age2 != null) {
					result = Integer.compare(age1, age2);
				} else if (age1 != null) {
					result = 1;
				} else if (age2 != null) {
					result = -1;
				}

				if (req.getOrder() == 0) {
					result = -result;
				}
				return result;
			};
			Collections.sort(ctpRecords, comparator);

		}

		columnName = req.getExcelColumns().split("%");

		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			Row headerRow = sheet.createRow(0);

			CellStyle headerStyle = workbook.createCellStyle();
			headerStyle.setAlignment(HorizontalAlignment.CENTER);
			headerStyle.setBorderTop(BorderStyle.MEDIUM);
			headerStyle.setBorderBottom(BorderStyle.MEDIUM);
			headerStyle.setBorderLeft(BorderStyle.MEDIUM);
			headerStyle.setBorderRight(BorderStyle.MEDIUM);

			Font dataHeaderFont = workbook.createFont();
			dataHeaderFont.setBold(true);
			dataHeaderFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			dataHeaderFont.setFontHeightInPoints((short) 11);
			headerStyle.setFont(dataHeaderFont);

			CellStyle dataStyle = workbook.createCellStyle();
			dataStyle.setAlignment(HorizontalAlignment.LEFT);
			dataStyle.setBorderTop(BorderStyle.MEDIUM);
			dataStyle.setBorderBottom(BorderStyle.MEDIUM);
			dataStyle.setBorderLeft(BorderStyle.MEDIUM);
			dataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font cellFont = workbook.createFont();
			cellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			cellFont.setFontHeightInPoints((short) 11);
			dataStyle.setFont(cellFont);

			CellStyle emptyDataStyle = workbook.createCellStyle();
			emptyDataStyle.setAlignment(HorizontalAlignment.CENTER);
			emptyDataStyle.setBorderTop(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderBottom(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderLeft(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font emptyCellFont = workbook.createFont();
			emptyCellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			emptyCellFont.setFontHeightInPoints((short) 11);
			emptyDataStyle.setFont(emptyCellFont);

			for (int i = 0; i < columnName.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columnName[i]);
				cell.setCellStyle(headerStyle);
			}
			int rowNum = 1;

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

			log.info("Inside Generate Excel method 22....................");
			for (CTPData data : ctpRecords) {
				int columnId = 0;
				Row row = sheet.createRow(rowNum++);
				// log.debug("inside loop....................");

				for (String column : columnName) {
					switch (column) {
					case "BBC": {
						Cell bbc = row.createCell(columnId++);
						if (data.getBbc() != null && !data.getBbc().isEmpty()) {
							bbc.setCellValue(data.getBbc().replace(",", " "));
							bbc.setCellStyle(dataStyle);
						} else {
							bbc.setCellValue(" - ");
							bbc.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor": {
						Cell vendor = row.createCell(columnId++);
						if (data.getVendor() != null && !data.getVendor().isEmpty()) {
							vendor.setCellValue(data.getVendor().replace(",", " "));
							vendor.setCellStyle(dataStyle);
						} else {
							vendor.setCellValue(" - ");
							vendor.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Order #": {

						Cell medRecId = row.createCell(columnId++);
						if (data.getOrderId() != null && !data.getOrderId().isEmpty()) {
							medRecId.setCellValue(data.getOrderId().replace(",", " "));
							medRecId.setCellStyle(dataStyle);
						} else {
							medRecId.setCellValue(" - ");
							medRecId.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Med Rec ID": {
						Cell medRecId = row.createCell(columnId++);
						medRecId.setCellValue(" - ");
						medRecId.setCellStyle(emptyDataStyle);
						break;
					}

					case "Age": {
						Cell age = row.createCell(columnId++);
						if (data.getAge() != null && !data.getAge().isEmpty()) {
							age.setCellValue(data.getAge().replace(",", " "));
							age.setCellStyle(dataStyle);
						} else {
							age.setCellValue(" - ");
							age.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Patient Name": {
						Cell patientName = row.createCell(columnId++);
						if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
							patientName.setCellValue(data.getPatientName().replace(",", " "));
							patientName.setCellStyle(dataStyle);
						} else {
							patientName.setCellValue(" - ");
							patientName.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Patient DOB": {
						Cell patientDOB = row.createCell(columnId++);
						if (data.getPatientDOB() != null) {
							String formatFollowupDate = dateFormat.format(data.getPatientDOB());
							patientDOB.setCellValue(formatFollowupDate);
							patientDOB.setCellStyle(dataStyle);
						} else {
							patientDOB.setCellValue(" - ");
							patientDOB.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Assigned To": {
						Cell assignedTo = row.createCell(columnId++);
						if (data.getAssignedTo() != null && !data.getAssignedTo().isEmpty()) {
							assignedTo.setCellValue(data.getAssignedTo().replace(",", " "));
							assignedTo.setCellStyle(dataStyle);
						} else {
							assignedTo.setCellValue(" - ");
							assignedTo.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Response Date": {
						Cell followupDate = row.createCell(columnId++);
						followupDate.setCellValue(" - ");
						followupDate.setCellStyle(emptyDataStyle);
						break;
					}

					case "Provider": {
						Cell followupDate = row.createCell(columnId++);
						followupDate.setCellValue(" - ");
						followupDate.setCellStyle(emptyDataStyle);
						break;
					}

					case "Vendor Notes": {
						Cell followupDate = row.createCell(columnId++);
						followupDate.setCellValue(" - ");
						followupDate.setCellStyle(emptyDataStyle);
						break;
					}

					case "Vendor Patient #": {
						Cell followupDate = row.createCell(columnId++);
						followupDate.setCellValue(" - ");
						followupDate.setCellStyle(emptyDataStyle);
						break;
					}

					case "Vendor Order Date": {
						Cell followupDate = row.createCell(columnId++);
						followupDate.setCellValue(" - ");
						followupDate.setCellStyle(emptyDataStyle);
						break;
					}

					case "Last Team Update": {
						Cell lastTeamUpdatedDate = row.createCell(columnId++);
						if (data.getLastTeamUpdated() != null) {

							Calendar calendar = Calendar.getInstance();
							calendar.setTime(data.getLastTeamUpdated());

							calendar.add(Calendar.MINUTE, req.getOffsetMinutes());

							Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

							String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
							lastTeamUpdatedDate.setCellValue(formatlLastTeamUpdatedDate);
							lastTeamUpdatedDate.setCellStyle(dataStyle);
						} else {
							lastTeamUpdatedDate.setCellValue(" - ");
							lastTeamUpdatedDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Order Source": {
						Cell bhcOrderSource = row.createCell(columnId++);
						if (data.getOrderSource() != null && !data.getOrderSource().isEmpty()) {
							bhcOrderSource.setCellValue(data.getOrderSource().replace(",", " "));
							bhcOrderSource.setCellStyle(dataStyle);
						} else {
							bhcOrderSource.setCellValue(" - ");
							bhcOrderSource.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "i-heal Config": {
						Cell iHealConfiguration = row.createCell(columnId++);
						if (data.getiHealConfiguration() != null && !data.getiHealConfiguration().isEmpty()) {
							iHealConfiguration.setCellValue(data.getiHealConfiguration().replace(",", " "));
							iHealConfiguration.setCellStyle(dataStyle);
						} else {
							iHealConfiguration.setCellValue(" - ");
							iHealConfiguration.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Follow-up Date": {
						Cell followupDate = row.createCell(columnId++);
						if (data.getFollowupDate() != null) {

							String formatFollowupDate = dateFormat.format(data.getFollowupDate());
							followupDate.setCellValue(formatFollowupDate);
							followupDate.setCellStyle(dataStyle);
						} else {
							followupDate.setCellValue(" - ");
							followupDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Retrieve Status": {
						Cell statusCell = row.createCell(columnId++);
						if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
							statusCell.setCellValue(data.getRetrieveStatus().replace(",", " "));
							CellStyle statusCellStyle = createStatusCellStyle(workbook, data.getRetrieveStatus());
							statusCell.setCellStyle(statusCellStyle);
						} else {
							statusCell.setCellValue(" - ");
							statusCell.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Status": {
						Cell bhcDocStatus = row.createCell(columnId++);
						if (data.getCurrentStatus() != null && !data.getCurrentStatus().isEmpty()) {
							/*
							 * bhcDocStatus .setCellValue(data.getCurrentStatus()); CellStyle
							 * statusCellStyle = createStatusCellStyle( workbook, data.getCurrentStatus());
							 */
							bhcDocStatus.setCellValue(data.getCurrentStatus().replace(",", " "));
							bhcDocStatus.setCellStyle(dataStyle);
						} else {
							bhcDocStatus.setCellValue(" - ");
							bhcDocStatus.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Insurance": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getPrimaryInsuranceCompany() != null && !data.getPrimaryInsuranceCompany().isEmpty()) {
							bhcMissingDocNotes.setCellValue(data.getPrimaryInsuranceCompany().replace(",", " "));
							bhcMissingDocNotes.setCellStyle(dataStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					}
				}
			}

			log.debug("After loop....................");

			for (int i = 0; i < columnName.length; i++) {
				int maxContentWidth = 0;
				for (int j = 0; j <= sheet.getLastRowNum(); j++) {
					Row row = sheet.getRow(j);
					if (row != null) {
						Cell cell = row.getCell(i);
						if (cell != null) {
							int contentWidth;
							if (cell.getCellType() == CellType.STRING) {
								contentWidth = (cell.getStringCellValue().length() + 2) * 256; // Adding
																								// some
																								// padding
							} else if (cell.getCellType() == CellType.NUMERIC) {
								contentWidth = (String.valueOf(cell.getNumericCellValue()).length() + 2) * 256;
							} else {
								contentWidth = 0; // Handle other cell types as
													// needed
							}

							if (contentWidth > maxContentWidth) {
								maxContentWidth = contentWidth;
							}
						}
					}
				}
				// Set a reasonable maximum width, e.g., 8000 (adjust as needed)
				sheet.setColumnWidth(i, Math.min(maxContentWidth, 8000));
			}

			log.debug("After autoSizeColumn Loop.................");
			sheet.setAutoFilter(
					new CellRangeAddress(sheet.getFirstRowNum(), sheet.getFirstRowNum(), 0, columnName.length - 1));
			workbook.write(output);
			workbook.close();
			log.debug("workbook close....................");
			byte[] byteArray = output.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(byteArray);
			return base64Str;

		} catch (IOException e) {
			log.error("Exception occured at excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}

	}

	private static String calculateMasterAge(Timestamp firstReceived) {
		Instant recordAddedInstant = firstReceived.toInstant();
		Instant currentInsant = Instant.now();
		String age = null;
		if (firstReceived != null) {

			if (Duration.between(recordAddedInstant, currentInsant).toHours() < 24) {
				return age = "0";
			}

			LocalDate recordAddedLocalDate = recordAddedInstant.atZone(ZoneId.systemDefault()).toLocalDate();

			long totalDays = ChronoUnit.DAYS.between(recordAddedLocalDate, LocalDate.now());
			age = totalDays + " days";
		}
		return age;
	}

	public static String generateUniformDashboardExcel(MasterCTPDashboardReq dashboardReq, List<UniformData> records) {

		log.info("Inside Generate Excel method..................");

		String sheetName = "" + dashboardReq.getServiceLine() + "_dashboard";

		String[] columnName;

		for (UniformData ctp : records) {
			log.debug("Before calculate age ");
			if (ctp.getReceivedDate() != null) {
				ctp.setAge(calculateAge(ctp.getReceivedDate()));
			} else {
				ctp.setAge(null);
			}
			log.debug("After calculate age ");
		}

		if (dashboardReq.getSortBy().equalsIgnoreCase("age")) {
			log.debug("Sort by age ");
			Comparator<UniformData> comparator = (o1, o2) -> {
				Integer age1 = parseAge(o1.getAge());
				Integer age2 = parseAge(o2.getAge());

				int result = 0;
				if (age1 != null && age2 != null) {
					result = Integer.compare(age1, age2);
				} else if (age1 != null) {
					result = 1;
				} else if (age2 != null) {
					result = -1;
				}

				if (dashboardReq.getOrder() == 1) {
					result = -result;
				}
				return result;
			};
			Collections.sort(records, comparator);

		}

		columnName = dashboardReq.getExcelColumns().split("%");

		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			Row headerRow = sheet.createRow(0);

			CellStyle headerStyle = workbook.createCellStyle();
			headerStyle.setAlignment(HorizontalAlignment.CENTER);
			headerStyle.setBorderTop(BorderStyle.MEDIUM);
			headerStyle.setBorderBottom(BorderStyle.MEDIUM);
			headerStyle.setBorderLeft(BorderStyle.MEDIUM);
			headerStyle.setBorderRight(BorderStyle.MEDIUM);

			Font dataHeaderFont = workbook.createFont();
			dataHeaderFont.setBold(true);
			dataHeaderFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			dataHeaderFont.setFontHeightInPoints((short) 11);
			headerStyle.setFont(dataHeaderFont);

			CellStyle dataStyle = workbook.createCellStyle();
			dataStyle.setAlignment(HorizontalAlignment.LEFT);
			dataStyle.setBorderTop(BorderStyle.MEDIUM);
			dataStyle.setBorderBottom(BorderStyle.MEDIUM);
			dataStyle.setBorderLeft(BorderStyle.MEDIUM);
			dataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font cellFont = workbook.createFont();
			cellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			cellFont.setFontHeightInPoints((short) 11);
			dataStyle.setFont(cellFont);

			CellStyle emptyDataStyle = workbook.createCellStyle();
			emptyDataStyle.setAlignment(HorizontalAlignment.CENTER);
			emptyDataStyle.setBorderTop(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderBottom(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderLeft(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font emptyCellFont = workbook.createFont();
			emptyCellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			emptyCellFont.setFontHeightInPoints((short) 11);
			emptyDataStyle.setFont(emptyCellFont);

			for (int i = 0; i < columnName.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columnName[i]);
				cell.setCellStyle(headerStyle);
			}
			int rowNum = 1;

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

			log.info("Inside Generate Excel method 22....................");
			for (UniformData data : records) {
				int columnId = 0;
				Row row = sheet.createRow(rowNum++);
				// log.debug("inside loop....................");

				for (String column : columnName) {
					switch (column) {
					case "BBC": {
						Cell bbc = row.createCell(columnId++);
						if (data.getBbc() != null && !data.getBbc().isEmpty()) {
							bbc.setCellValue(data.getBbc().replace(",", " "));
							bbc.setCellStyle(dataStyle);
						} else {
							bbc.setCellValue(" - ");
							bbc.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Order #": {
						Cell vendor = row.createCell(columnId++);
						if (data.getVendorOrderNo() != null && !data.getVendorOrderNo().isEmpty()) {
							vendor.setCellValue(data.getVendorOrderNo().replace(",", " "));
							vendor.setCellStyle(dataStyle);
						} else {
							vendor.setCellValue(" - ");
							vendor.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor": {
						Cell medRecId = row.createCell(columnId++);
						if (data.getVendor() != null && !data.getVendor().isEmpty()) {
							medRecId.setCellValue(data.getVendor().replace(",", " "));
							medRecId.setCellStyle(dataStyle);
						} else {
							medRecId.setCellValue(" - ");
							medRecId.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Med Rec ID": {
						Cell age = row.createCell(columnId++);
						age.setCellValue(" - ");
						age.setCellStyle(emptyDataStyle);
						break;
					}
					case "Age": {
						Cell age = row.createCell(columnId++);
						if (data.getAge() != null) {
							age.setCellValue(data.getAge());
							age.setCellStyle(dataStyle);
						} else {
							age.setCellValue(" - ");
							age.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Patient Name": {
						Cell assignedTo = row.createCell(columnId++);
						if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
							assignedTo.setCellValue(data.getPatientName().replace(",", " "));
							assignedTo.setCellStyle(dataStyle);
						} else {
							assignedTo.setCellValue(" - ");
							assignedTo.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Patient DOB": {
						Cell followupDate = row.createCell(columnId++);
						if (data.getPatientDOB() != null) {
							String formatFollowupDate = dateFormat.format(data.getPatientDOB());
							followupDate.setCellValue(formatFollowupDate);
							followupDate.setCellStyle(dataStyle);
						} else {
							followupDate.setCellValue(" - ");
							followupDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Assigned To": {
						Cell bhcOrderSource = row.createCell(columnId++);
						if (data.getAssignedTo() != null && !data.getAssignedTo().isEmpty()) {
							bhcOrderSource.setCellValue(data.getAssignedTo().replace(",", " "));
							bhcOrderSource.setCellStyle(dataStyle);
						} else {
							bhcOrderSource.setCellValue(" - ");
							bhcOrderSource.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Last Team Update": {
						Cell lastTeamUpdatedDate = row.createCell(columnId++);
						if (data.getLastTeamUpdated() != null) {

							Calendar calendar = Calendar.getInstance();
							calendar.setTime(data.getLastTeamUpdated());

							calendar.add(Calendar.MINUTE, dashboardReq.getOffsetMinutes());

							Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

							String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
							lastTeamUpdatedDate.setCellValue(formatlLastTeamUpdatedDate);
							lastTeamUpdatedDate.setCellStyle(dataStyle);
						} else {
							lastTeamUpdatedDate.setCellValue(" - ");
							lastTeamUpdatedDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Response Date": {
						Cell followupDate = row.createCell(columnId++);
						if (data.getResponseDate() != null) {
							String formatFollowupDate = dateFormat.format(data.getResponseDate());
							followupDate.setCellValue(formatFollowupDate);
							followupDate.setCellStyle(dataStyle);
						} else {
							followupDate.setCellValue(" - ");
							followupDate.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Order Source": {
						Cell statusCell = row.createCell(columnId++);
						if (data.getBhcOrderSource() != null && !data.getBhcOrderSource().isEmpty()) {
							statusCell.setCellValue(data.getBhcOrderSource().replace(",", " "));
							statusCell.setCellStyle(dataStyle);
						} else {
							statusCell.setCellValue(" - ");
							statusCell.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "i-heal Config": {
						Cell bhcDocStatus = row.createCell(columnId++);
						if (data.getiHealConfiguration() != null && !data.getiHealConfiguration().isEmpty()) {
							bhcDocStatus.setCellValue(data.getiHealConfiguration());
							bhcDocStatus.setCellStyle(dataStyle);
						} else {
							bhcDocStatus.setCellValue(" - ");
							bhcDocStatus.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "FollowUp Date": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getFollowupDate() != null) {
							bhcMissingDocNotes.setCellValue(dateFormat.format(data.getFollowupDate()));
							bhcMissingDocNotes.setCellStyle(dataStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Status": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
							bhcMissingDocNotes.setCellValue(data.getVendorStatus().replace(",", " "));
							bhcMissingDocNotes.setCellStyle(dataStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Retrieve Status": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
							bhcMissingDocNotes.setCellValue(data.getRetrieveStatus().replace(",", " "));
							CellStyle statusCellStyle = createStatusCellStyle(workbook, data.getRetrieveStatus());
							bhcMissingDocNotes.setCellStyle(statusCellStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Insurance": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getInsurance() != null && !data.getInsurance().isEmpty()) {
							bhcMissingDocNotes.setCellValue(data.getInsurance().replace(",", " "));
							bhcMissingDocNotes.setCellStyle(dataStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Provider": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						bhcMissingDocNotes.setCellValue(" - ");
						bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						break;
					}
					case "Vendor Patient #": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						bhcMissingDocNotes.setCellValue(" - ");
						bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						break;
					}
					case "Vendor Order Date": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						if (data.getVendorOrderDate() != null) {
							bhcMissingDocNotes.setCellValue(dateFormat.format(data.getVendorOrderDate()));
							bhcMissingDocNotes.setCellStyle(dataStyle);
						} else {
							bhcMissingDocNotes.setCellValue(" - ");
							bhcMissingDocNotes.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Vendor Notes": {
						Cell bhcMissingDocNotes = row.createCell(columnId++);
						bhcMissingDocNotes.setCellValue(" - ");
						bhcMissingDocNotes.setCellStyle(emptyDataStyle);

						break;
					}
					}
				}
			}

			log.debug("After loop....................");

			for (int i = 0; i < columnName.length; i++) {
				int maxContentWidth = 0;
				for (int j = 0; j <= sheet.getLastRowNum(); j++) {
					Row row = sheet.getRow(j);
					if (row != null) {
						Cell cell = row.getCell(i);
						if (cell != null) {
							int contentWidth;
							if (cell.getCellType() == CellType.STRING) {
								contentWidth = (cell.getStringCellValue().length() + 2) * 256; // Adding
																								// some
																								// padding
							} else if (cell.getCellType() == CellType.NUMERIC) {
								contentWidth = (String.valueOf(cell.getNumericCellValue()).length() + 2) * 256;
							} else {
								contentWidth = 0; // Handle other cell types as
													// needed
							}

							if (contentWidth > maxContentWidth) {
								maxContentWidth = contentWidth;
							}
						}
					}
				}
				// Set a reasonable maximum width, e.g., 8000 (adjust as needed)
				sheet.setColumnWidth(i, Math.min(maxContentWidth, 8000));
			}

			log.debug("After autoSizeColumn Loop.................");
			sheet.setAutoFilter(
					new CellRangeAddress(sheet.getFirstRowNum(), sheet.getFirstRowNum(), 0, columnName.length - 1));
			workbook.write(output);
			workbook.close();
			log.debug("workbook close....................");
			byte[] byteArray = output.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(byteArray);
			return base64Str;

		} catch (IOException e) {
			log.error("Exception occured at excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}

	public static String generateCenterAssignmentsReportExcel(List<RetrieveMembersDetails> rows) {
		log.info("Inside Generate Excel method..................");

		String sheetName = "Center Assignmant Report";

		String[] columnName;

		columnName = new String[] { "Division", "Market", "Territory", "BBC", "i-heal config", "AWD Clerk",
				"AWD Specialist", "NPWT Clerk", "NPWT Specialist", "CTP Clerk", "CTP Specialist",
				"Operations Specialist" };

		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			Row headerRow = sheet.createRow(0);

			CellStyle headerStyle = workbook.createCellStyle();
			headerStyle.setAlignment(HorizontalAlignment.CENTER);
			headerStyle.setBorderTop(BorderStyle.MEDIUM);
			headerStyle.setBorderBottom(BorderStyle.MEDIUM);
			headerStyle.setBorderLeft(BorderStyle.MEDIUM);
			headerStyle.setBorderRight(BorderStyle.MEDIUM);

			Font dataHeaderFont = workbook.createFont();
			dataHeaderFont.setBold(true);
			dataHeaderFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			dataHeaderFont.setFontHeightInPoints((short) 11);
			headerStyle.setFont(dataHeaderFont);

			CellStyle dataStyle = workbook.createCellStyle();
			dataStyle.setAlignment(HorizontalAlignment.LEFT);
			dataStyle.setVerticalAlignment(VerticalAlignment.CENTER);
			dataStyle.setBorderTop(BorderStyle.MEDIUM);
			dataStyle.setBorderBottom(BorderStyle.MEDIUM);
			dataStyle.setBorderLeft(BorderStyle.MEDIUM);
			dataStyle.setBorderRight(BorderStyle.MEDIUM);
			dataStyle.setWrapText(true);

			Font cellFont = workbook.createFont();
			cellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			cellFont.setFontHeightInPoints((short) 11);
			dataStyle.setFont(cellFont);

			CellStyle emptyDataStyle = workbook.createCellStyle();
			emptyDataStyle.setAlignment(HorizontalAlignment.CENTER);
			emptyDataStyle.setVerticalAlignment(VerticalAlignment.CENTER);
			emptyDataStyle.setBorderTop(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderBottom(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderLeft(BorderStyle.MEDIUM);
			emptyDataStyle.setBorderRight(BorderStyle.MEDIUM);

			Font emptyCellFont = workbook.createFont();
			emptyCellFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			emptyCellFont.setFontHeightInPoints((short) 11);
			emptyDataStyle.setFont(emptyCellFont);

			for (int i = 0; i < columnName.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columnName[i]);
				cell.setCellStyle(headerStyle);
			}
			int rowNum = 1;

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

			log.info("Inside Generate Excel method 22....................");
			// int sno = 1;
			for (RetrieveMembersDetails data : rows) {
				int columnId = 0;
				Row row = sheet.createRow(rowNum++);
				// log.debug("inside loop....................");

				for (String column : columnName) {
					switch (column) {
					case "Division": {
						Cell division = row.createCell(columnId++);
						if (data.getDivision() != null && !data.getDivision().isEmpty()) {
							division.setCellValue(data.getDivision().replace(",", " "));
							division.setCellStyle(dataStyle);
						} else {
							division.setCellValue(" - ");
							division.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Market": {
						Cell market = row.createCell(columnId++);
						if (data.getMarket() != null && !data.getMarket().isEmpty()) {
							market.setCellValue(data.getMarket().replace(",", " "));
							market.setCellStyle(dataStyle);
						} else {
							market.setCellValue(" - ");
							market.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "Territory": {
						Cell territory = row.createCell(columnId++);
						if (data.getTerritory() != null && !data.getTerritory().isEmpty()) {
							territory.setCellValue(data.getTerritory().replace(",", " "));
							territory.setCellStyle(dataStyle);
						} else {
							territory.setCellValue(" - ");
							territory.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "BBC": {
						Cell bbc = row.createCell(columnId++);
						if (data.getBluebookCode() != null && !data.getBluebookCode().isEmpty()) {
							bbc.setCellValue(data.getBluebookCode().replace(",", " "));
							bbc.setCellStyle(dataStyle);
						} else {
							bbc.setCellValue(" - ");
							bbc.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "i-heal config": {
						Cell ihealConfig = row.createCell(columnId++);
						if (data.getiHealConfiguration() != null && !data.getiHealConfiguration().isEmpty()) {
							ihealConfig.setCellValue(data.getiHealConfiguration().replace(",", " "));
							ihealConfig.setCellStyle(dataStyle);
						} else {
							ihealConfig.setCellValue(" - ");
							ihealConfig.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "AWD Clerk": {
						Cell awdClerk = row.createCell(columnId++);
						if (data.getAwdDocClerk() != null && !data.getAwdDocClerk().isEmpty()) {
							awdClerk.setCellValue(data.getAwdDocClerk().replace(",", " "));
							awdClerk.setCellStyle(dataStyle);
						} else {
							awdClerk.setCellValue(" - ");
							awdClerk.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "AWD Specialist": {
						Cell awdSpecialist = row.createCell(columnId++);
						if (data.getAwdDocSpecialist() != null && !data.getAwdDocSpecialist().isEmpty()) {
							awdSpecialist.setCellValue(data.getAwdDocSpecialist().replace(",", " "));
							awdSpecialist.setCellStyle(dataStyle);
						} else {
							awdSpecialist.setCellValue(" - ");
							awdSpecialist.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "NPWT Clerk": {
						Cell npwtCleark = row.createCell(columnId++);
						if (data.getNpwtDocClerk() != null && !data.getNpwtDocClerk().isEmpty()) {
							npwtCleark.setCellValue(data.getNpwtDocClerk().replace(",", " "));
							npwtCleark.setCellStyle(dataStyle);
						} else {
							npwtCleark.setCellValue(" - ");
							npwtCleark.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "NPWT Specialist": {
						Cell npwtSpecialist = row.createCell(columnId++);
						if (data.getNpwtDocSpecialist() != null && !data.getNpwtDocSpecialist().isEmpty()) {
							npwtSpecialist.setCellValue(data.getNpwtDocSpecialist().replace(",", " "));
							npwtSpecialist.setCellStyle(dataStyle);
						} else {
							npwtSpecialist.setCellValue(" - ");
							npwtSpecialist.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "CTP Clerk": {
						Cell ctpCleark = row.createCell(columnId++);
						if (data.getCtpDocClerk() != null && !data.getCtpDocClerk().isEmpty()) {
							ctpCleark.setCellValue(data.getCtpDocClerk().replace(",", " "));
							ctpCleark.setCellStyle(dataStyle);
						} else {
							ctpCleark.setCellValue(" - ");
							ctpCleark.setCellStyle(emptyDataStyle);
						}
						break;
					}
					case "CTP Specialist": {
						Cell ctpSpecialist = row.createCell(columnId++);
						if (data.getCtpDocSpecialist() != null && !data.getCtpDocSpecialist().isEmpty()) {
							ctpSpecialist.setCellValue(data.getCtpDocSpecialist().replace(",", " "));
							ctpSpecialist.setCellStyle(dataStyle);
						} else {
							ctpSpecialist.setCellValue(" - ");
							ctpSpecialist.setCellStyle(emptyDataStyle);
						}
						break;
					}

					case "Operations Specialist": {
						Cell operationSpl = row.createCell(columnId++);
						if (data.getOpsSpecialist() != null && !data.getOpsSpecialist().isEmpty()) {
							operationSpl.setCellValue(data.getOpsSpecialist().replace(",", " "));
							operationSpl.setCellStyle(dataStyle);
						} else {
							operationSpl.setCellValue(" - ");
							operationSpl.setCellStyle(emptyDataStyle);
						}
						break;
					}

					}
				}
			}

			log.debug("After loop....................");

			for (int i = 0; i < columnName.length; i++) {
				int maxContentWidth = 0;
				for (int j = 0; j <= sheet.getLastRowNum(); j++) {
					Row row = sheet.getRow(j);
					if (row != null) {
						Cell cell = row.getCell(i);
						if (cell != null) {
							int contentWidth;
							if (cell.getCellType() == CellType.STRING) {
								contentWidth = (cell.getStringCellValue().length() + 2) * 256; // Adding
																								// some
																								// padding
							} else if (cell.getCellType() == CellType.NUMERIC) {
								contentWidth = (String.valueOf(cell.getNumericCellValue()).length() + 2) * 256;
							} else {
								contentWidth = 0; // Handle other cell types as
													// needed
							}

							if (contentWidth > maxContentWidth) {
								maxContentWidth = contentWidth;
							}
						}
					}
				}
				// Set a reasonable maximum width, e.g., 8000 (adjust as needed)
				sheet.setColumnWidth(i, Math.min(maxContentWidth, 8000));
			}

			log.debug("After autoSizeColumn Loop.................");
			sheet.setAutoFilter(
					new CellRangeAddress(sheet.getFirstRowNum(), sheet.getFirstRowNum(), 0, columnName.length - 1));
			workbook.write(output);
			workbook.close();
			log.debug("workbook close....................");
			byte[] byteArray = output.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(byteArray);
			return base64Str;

		} catch (IOException e) {
			log.error("Exception occured at excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}

	}

	public static String generateUniformReportsExcel(List<NPWTReportData> reports) {
		log.info("Inside Generate Excel method....................");

		String sheetName = "Reports";

		String[] columnName;

		columnName = new String[] { "BBC", "HL WQ Order #", "RO #", "Patient Name", "First Received Date",
				"Documents first sent", "Documents last sent", "Vendor Status", "Retrieve Status", "# of files sent" };

		try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream();) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			Row headerRow = sheet.createRow(0);

			CellStyle headerStyle = createHeaderStyle(workbook);
			CellStyle dataStyle = createDataStyle(workbook);
			CellStyle emptyDataStyle = createEmptyDataStyle(workbook);

			for (int i = 0; i < columnName.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columnName[i]);
				cell.setCellStyle(headerStyle);
			}
			int rowNum = 1;

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			/*
			 * SimpleDateFormat timeFormat = new SimpleDateFormat( "MM/dd/yyyy hh:mm a");
			 */

			log.info("Inside Generate Excel method....................");
			for (NPWTReportData data : reports) {

				int columnId = 0;
				Row row = sheet.createRow(rowNum++);

				createCell(row, columnId++, data.getBBC(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getHlWqOrderNo(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getRoNo(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getPatientName(), dataStyle, emptyDataStyle);

				createCell(row, columnId++, data.getFirstReceivedDate(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getDocumentsFirstSent(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getDocumentsLastSent(), dataStyle, emptyDataStyle, dateFormat);

				createCell(row, columnId++, data.getVendorStatus(), dataStyle, emptyDataStyle);

				Cell statusCell = row.createCell(columnId++);
				if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
					statusCell.setCellValue(data.getRetrieveStatus());
					CellStyle statusCellStyle = createStatusCellStyle(workbook, data.getRetrieveStatus());
					statusCell.setCellStyle(statusCellStyle);
				} else {
					statusCell.setCellValue(" - ");
					statusCell.setCellStyle(emptyDataStyle);
				}

				createCell(row, columnId++, data.getNoFilesSent(), dataStyle, emptyDataStyle, dateFormat);

			}

			for (int i = 0; i < columnName.length; i++) {
				int maxContentWidth = 0;
				for (int j = 0; j <= sheet.getLastRowNum(); j++) {
					Row row = sheet.getRow(j);
					if (row != null) {
						Cell cell = row.getCell(i);
						if (cell != null) {
							int contentWidth;
							if (cell.getCellType() == CellType.STRING) {
								contentWidth = (cell.getStringCellValue().length() + 2) * 256; // Adding
																								// some
																								// padding
							} else if (cell.getCellType() == CellType.NUMERIC) {
								contentWidth = (String.valueOf(cell.getNumericCellValue()).length() + 2) * 256;
							} else {
								contentWidth = 0; // Handle other cell types as
													// needed
							}

							if (contentWidth > maxContentWidth) {
								maxContentWidth = contentWidth;
							}
						}
					}
				}
				// Set a reasonable maximum width, e.g., 8000 (adjust as needed)
				sheet.setColumnWidth(i, Math.min(maxContentWidth, 8000));
			}

			sheet.setAutoFilter(CellRangeAddress.valueOf("A1:J1"));
			workbook.write(output);
			workbook.close();

			byte[] byteArray = output.toByteArray();
			String base64Str = Base64.getEncoder().encodeToString(byteArray);
			return base64Str;

		} catch (IOException e) {
			log.error("Exception occured at Uniform excel file:  {}", e.getMessage());
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}

	public static String generateAppNotificationsExcelNPWT(List<AppNotifications> appNotifications, String excelColumns,
			String excelName, String localPath) throws IOException {
		log.info("Generating App Notification CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (AppNotifications data : appNotifications) {
			log.debug("data.getNotificationId : " + data.getNotificationId());
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "Notification Id": {
					if (data.getNotificationId() != 0) {
						sb.append(data.getNotificationId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "User Id": {
					if (data.getUserId() != null) {
						sb.append(data.getUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Read Flag": {
					if (data.getReadFlag()) {
						sb.append(data.getReadFlag());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Notification Description": {
					if (data.getNotificationDescription() != null && !data.getNotificationDescription().isEmpty()) {
						String replacedStr = data.getNotificationDescription().replace(",", " ").replace("\n", " ")
								.replace("\r", " ");

						sb.append(replacedStr);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Notification Title": {
					if (data.getNotificationTitle() != null && !data.getNotificationTitle().isEmpty()) {
						sb.append(data.getNotificationTitle().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Created Timestamp": {
					if (data.getCreatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCreatedTimestamp());
						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());
						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Fullname": {
					if (data.getUserFullname() != null && !data.getUserFullname().isEmpty()) {
						sb.append(data.getUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Creator User Id": {
					if (data.getCreatorUserId() != null) {
						sb.append(data.getCreatorUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Creator User Fullname": {
					if (data.getCreatorUserFullname() != null && !data.getCreatorUserFullname().isEmpty()) {
						sb.append(data.getCreatorUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured : " + e.getMessage());
			log.error("Exception occured while generating App Notification excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import App Notification data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateDocumentStoreExcelNPWT(List<DocumentStore> docStoreListNPWT, String excelColumns,
			String excelName, String localPath) throws IOException {
		log.info("Generating Document Status CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}

		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (DocumentStore data : docStoreListNPWT) {
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Token": {
					if (data.getDocumentToken() != null && !data.getDocumentToken().isEmpty()) {
						sb.append(data.getDocumentToken());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Request Id": {
					if (data.getDocRequestId() != null && !data.getDocRequestId().isEmpty()) {
						sb.append(data.getDocRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Type": {
					if (data.getDocumentType() != null && !data.getDocumentType().isEmpty()) {
						sb.append(data.getDocumentType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Available": {
					if (data.getDocumentAvailable() != 0) {
						sb.append(data.getDocumentAvailable());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Visit Id": {
					if (data.getVisitId() != 0) {
						sb.append(data.getVisitId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Visit Date": {
					if (data.getVisitDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getVisitDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Type": {
					if (data.getFacilityType() != null && !data.getFacilityType().isEmpty()) {
						sb.append(data.getFacilityType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Config": {
					if (data.getIhealConfig() != null && !data.getIhealConfig().isEmpty()) {
						sb.append(data.getIhealConfig().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Id": {
					if (data.getVendorId() != 0) {
						sb.append(data.getVendorId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Vendor Name": {
					if (data.getVendorName() != null && !data.getVendorName().isEmpty()) {
						sb.append(data.getVendorName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Patient Name": {
					if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
						sb.append(data.getPatientName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Document Request Status": {
					if (data.getIhealDocRequestStatus() != null && !data.getIhealDocRequestStatus().isEmpty()) {
						sb.append(data.getIhealDocRequestStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Document Request Timestamp": {
					if (data.getIhealDocRequestTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getIhealDocRequestTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Download Status": {
					if (data.getDocDownloadStatus() != null && !data.getDocDownloadStatus().isEmpty()) {
						sb.append(data.getDocDownloadStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Download Timestamp": {
					if (data.getDocDownloadTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocDownloadTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Notification Status": {
					if (data.getDocNotificationStatus() != null && !data.getDocNotificationStatus().isEmpty()) {
						sb.append(data.getDocNotificationStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Notification Timestamp": {
					if (data.getDocNotificationTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocNotificationTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Document Get Status": {
					if (data.getVendorDocGetStatus() != null && !data.getVendorDocGetStatus().isEmpty()) {
						sb.append(data.getVendorDocGetStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Document Get Timestamp": {
					if (data.getVendorDocGetTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getVendorDocGetTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Sent Status": {
					if (data.getDocSentStatus() != null && !data.getDocSentStatus().isEmpty()) {
						sb.append(data.getDocSentStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Sent Timestamp": {
					if (data.getDocSentTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocSentTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Name": {
					if (data.getUserName() != null && !data.getUserName().isEmpty()) {
						sb.append(data.getUserName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Full Name": {
					if (data.getUserFullName() != null && !data.getUserFullName().isEmpty()) {
						sb.append(data.getUserFullName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Id": {
					if (data.getUserId() != 0) {
						sb.append(data.getUserId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Error Code": {
					if (data.getErrorCode() != null && !data.getErrorCode().isEmpty()) {
						sb.append(data.getErrorCode());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Error Message": {
					if (data.getErrorMessage() != null && !data.getErrorMessage().isEmpty()) {
						sb.append(data.getErrorMessage());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Store Id": {
					if (data.getStoreId() != 0) {
						sb.append(data.getStoreId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Document Status": {
					if (data.getDocumentStatus() != null && !data.getDocumentStatus().isEmpty()) {
						sb.append(data.getDocumentStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Content": {
					if (data.getDocumentContent() != null && !data.getDocumentContent().isEmpty()) {
						sb.append(data.getDocumentContent().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Service Line": {
					if (data.getServiceLine() != null && !data.getServiceLine().isEmpty()) {
						sb.append(data.getServiceLine());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Name": {
					if (data.getDocumentName() != null && !data.getDocumentName().isEmpty()) {
						sb.append(data.getDocumentName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Source": {
					if (data.getDocumentSource() != null && !data.getDocumentSource().isEmpty()) {
						sb.append(data.getDocumentSource().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Document Id": {
					if (data.getIhealDocumentId() != 0) {
						sb.append(data.getIhealDocumentId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Iheal Version Id": {
					if (data.getIhealVersionId() != 0) {
						sb.append(data.getIhealVersionId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Created Timestamp": {
					if (data.getCreatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCreatedTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Request Id": {
					if (data.getVendorRequestId() != null && !data.getVendorRequestId().isEmpty()) {
						sb.append(data.getVendorRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Status": {
					if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
						sb.append(data.getVendorStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient First Name": {
					if (data.getPatientFirstName() != null && !data.getPatientFirstName().isEmpty()) {
						sb.append(data.getPatientFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Last Name": {
					if (data.getPatientLastName() != null && !data.getPatientLastName().isEmpty()) {
						sb.append(data.getPatientLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Primary Insurance": {
					if (data.getPrimaryInsurance() != null && !data.getPrimaryInsurance().isEmpty()) {
						sb.append(data.getPrimaryInsurance().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Secondary Insurance": {
					if (data.getSecondaryInsurance() != null && !data.getSecondaryInsurance().isEmpty()) {
						sb.append(data.getSecondaryInsurance().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider First Name": {
					if (data.getProviderFirstName() != null && !data.getProviderFirstName().isEmpty()) {
						sb.append(data.getProviderFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider Last Name": {
					if (data.getProviderLastName() != null && !data.getProviderLastName().isEmpty()) {
						sb.append(data.getProviderLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Clinician First Name": {
					if (data.getClinicianFirstName() != null && !data.getClinicianFirstName().isEmpty()) {
						sb.append(data.getClinicianFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Clinician Last Name": {
					if (data.getClinicianLastName() != null && !data.getClinicianLastName().isEmpty()) {
						sb.append(data.getClinicianLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Response Date": {
					if (data.getResponseDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getResponseDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Referral No": {
					if (data.getVendorReferralNo() != null && !data.getVendorReferralNo().isEmpty()) {
						sb.append(data.getVendorReferralNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Need By Date": {
					if (data.getNeedByDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getNeedByDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Document Store excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Document Store data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateDocumentationHistoryExcelNPWT(List<DocumentationHistory2> docHistoryListNPWT,
			String excelColumns, String excelName, String localPath) throws IOException {
		log.info("Generating Documentation History CSV File.....");
		String fileName = "";

		// String sheetName = "DocumentationHistory";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (DocumentationHistory2 data : docHistoryListNPWT) {
			log.debug("data.getDocumentId() : " + data.getHistoryId());
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "History Id": {
					if (data.getHistoryId() != 0) {
						sb.append(data.getHistoryId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Notes": {
					if (data.getUserNotes() != null && !data.getUserNotes().isEmpty()) {
						sb.append(data.getUserNotes());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Retrieve Status": {
					if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
						sb.append(data.getRetrieveStatus());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Patient Name": {
					if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
						sb.append(data.getPatientName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient DOB": {
					if (data.getPatientDOB() != null) {
						String formatFollowupDate = dateFormat.format(data.getPatientDOB());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Object": {
					if (data.getDocumentObject() != null && !data.getDocumentObject().isEmpty()) {
						sb.append(data.getDocumentObject().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assigned To": {
					if (data.getAssignedTo() != null && !data.getAssignedTo().isEmpty()) {
						sb.append(data.getAssignedTo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Re Assigned To": {
					if (data.getReAssignedTo() != null && !data.getReAssignedTo().isEmpty()) {
						sb.append(data.getReAssignedTo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Status": {
					if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
						sb.append(data.getVendorStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Name": {
					if (data.getLastUpdatedUserName() != null && !data.getLastUpdatedUserName().isEmpty()) {
						sb.append(data.getLastUpdatedUserName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Full Name": {
					if (data.getLastUpdatedUserFullName() != null && !data.getLastUpdatedUserFullName().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != 0) {
						sb.append(data.getLastUpdatedUserId());
					} else {
						sb.append(0);
					}
					break;
				}
				}
			}

			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Documentation History excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Documentation History data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generatePrimaryKeyLookupExcelNPWT(List<PrimaryKeyLookup> pklList, String excelColumns,
			String excelName, String localPath) throws IOException {
		log.info("Generating Primary Key Look Up CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (PrimaryKeyLookup data : pklList) {
			log.debug("data.getRetrieveReqId() : " + data.getRetrieveReqId());
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "Retrieve Request Id": {
					if (data.getRetrieveReqId() != 0) {
						sb.append(data.getRetrieveReqId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Vendor Id": {
					if (data.getVendorId() != 0) {
						sb.append(data.getVendorId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Vendor Name": {
					if (data.getVendorName() != null && !data.getVendorName().isEmpty()) {
						sb.append(data.getVendorName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Service Line": {
					if (data.getServiceLine() != null && !data.getServiceLine().isEmpty()) {
						sb.append(data.getServiceLine().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "primary Key 1": {
					if (data.getPrimaryKey1() != null && !data.getPrimaryKey1().isEmpty()) {
						sb.append(data.getPrimaryKey1().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "primary Key 2": {
					if (data.getPrimaryKey2() != null && !data.getPrimaryKey2().isEmpty()) {
						sb.append(data.getPrimaryKey2().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "primary Key 3": {
					if (data.getPrimaryKey3() != null && !data.getPrimaryKey3().isEmpty()) {
						sb.append(data.getPrimaryKey3().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "primary Key 4": {
					if (data.getPrimaryKey4() != null && !data.getPrimaryKey4().isEmpty()) {
						sb.append(data.getPrimaryKey4().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Created Timestamp": {
					if (data.getCreatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCreatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Primary Look up excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Primary Look up data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateNPWTDashboardExcel(List<UniformDashboard> npwtDashboardList, String excelColumns,
			String excelName, String localPath, boolean isHistorical) throws IOException {
		log.info("Generating NPWT Dashboard CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (UniformDashboard data : npwtDashboardList) {
			log.debug("data.getRequestId : " + data.getRequestId());
			sb = new StringBuilder();
			for (String column : columnName) {
				log.debug("column : " + column);
				switch (column) {
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Order No": {
					if (data.getVendorOrderNo() != null && !data.getVendorOrderNo().isEmpty()) {
						sb.append(data.getVendorOrderNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Id": {
					if (data.getVendorId() != null && data.getVendorId() != 0) {
						sb.append(data.getVendorId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Vendor Name": {
					if (data.getVendorName() != null && !data.getVendorName().isEmpty()) {
						sb.append(data.getVendorName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Age": {
					if (data.getAge() != null && data.getAge() != 0) {
						sb.append(data.getAge());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != null && data.getPatientId() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Patient First Name": {
					if (data.getPatientFirstName() != null && !data.getPatientFirstName().isEmpty()) {
						sb.append(data.getPatientFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Last Name": {
					if (data.getPatientLastName() != null && !data.getPatientLastName().isEmpty()) {
						sb.append(data.getPatientLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient DOB": {
					if (data.getPatientDOB() != null) {
						String formatFollowupDate = dateFormat.format(data.getPatientDOB());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assigned To": {
					if (data.getAssignedTo() != null && !data.getAssignedTo().isEmpty()) {
						sb.append(data.getAssignedTo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assignee User Id": {
					if (data.getAssigneeUserId() != null && !data.getAssigneeUserId().isEmpty()) {
						sb.append(data.getAssigneeUserId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assignee User Name": {
					if (data.getAssigneeUsername() != null && !data.getAssigneeUsername().isEmpty()) {
						sb.append(data.getAssigneeUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Team Updated Timestamp": {
					if (data.getLastTeamUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastTeamUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Team Updated User Full Name": {
					if (data.getLastTeamUpdatedFullName() != null && !data.getLastTeamUpdatedFullName().isEmpty()) {
						sb.append(data.getLastTeamUpdatedFullName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Response Date": {
					if (data.getResponseDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getResponseDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Order Source": {
					if (data.getOrderSource() != null && !data.getOrderSource().isEmpty()) {
						sb.append(data.getOrderSource().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Config": {
					if (data.getIhealConfig() != null && !data.getIhealConfig().isEmpty()) {
						sb.append(data.getIhealConfig().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Followup Date": {
					if (data.getFollowupDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getFollowupDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Insurance": {
					if (data.getInsurance() != null && !data.getInsurance().isEmpty()) {
						sb.append(data.getInsurance().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
					
			
				}
				case "Primary Insurance": {
					if (data.getPrimaryInsurance() != null && !data.getPrimaryInsurance().isEmpty()) {
						sb.append(data.getPrimaryInsurance().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Order Date": {
					if (data.getVendorOrderDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getVendorOrderDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Retrieve Status": {
					if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
						sb.append(data.getRetrieveStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Status": {
					if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
						sb.append(data.getVendorStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Received Date": {
					if (data.getReceivedDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getReceivedDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "First Received": {
					if (data.getFirstReceived() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getFirstReceived());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated User Id": {
					if (data.getStatusUpdatedUserId() != null && !data.getStatusUpdatedUserId().isEmpty()) {
						sb.append(data.getStatusUpdatedUserId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated User Name": {
					if (data.getStatusUpdatedUsername() != null && !data.getStatusUpdatedUsername().isEmpty()) {
						sb.append(data.getStatusUpdatedUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated User Full Name": {
					if (data.getStatusUpdatedUserFullname() != null && !data.getStatusUpdatedUserFullname().isEmpty()) {
						sb.append(data.getStatusUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated Timestamp": {
					if (data.getStatusUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getStatusUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider Id": {
					if (data.getProviderId() != null && data.getProviderId() != 0) {
						sb.append(data.getProviderId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Provider First Name": {
					if (data.getProviderFirstName() != null && !data.getProviderFirstName().isEmpty()) {
						sb.append(data.getProviderFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider Last Name": {
					if (data.getProviderLastName() != null && !data.getProviderLastName().isEmpty()) {
						sb.append(data.getProviderLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Medical Record Number": {
					if (data.getMedicalRecordNumber() != null && !data.getMedicalRecordNumber().isEmpty()) {
						sb.append(data.getMedicalRecordNumber().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Patient No": {
					if (data.getVendorPatientNo() != null && !data.getVendorPatientNo().isEmpty()) {
						sb.append(data.getVendorPatientNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Notes": {
					if (data.getVendorNotes() != null && !data.getVendorNotes().isEmpty()) {
						sb.append(data.getVendorNotes().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Created Timestamp": {
					if (data.getCreatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCreatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "WoundQ Order No": {
					if (data.getWoundQOrderNo() != null && !data.getWoundQOrderNo().isEmpty()) {
						sb.append(data.getWoundQOrderNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Files Sent": {
					if (data.getFilesSent() != null && data.getFilesSent() != 0) {
						sb.append(data.getFilesSent());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Documents First Sent": {
					if (data.getDocumentsFirstSent() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocumentsFirstSent());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Documents Last Sent": {
					if (data.getDocumentsLastSent() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocumentsLastSent());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					break;
				}

				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		
		if (isHistorical) {
			fileName = excelName;
		} else {
			fileName = excelName + "_" + getCurrentDate() + ".csv";
		}
		
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating NPWT Dashboard excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import NPWT Dashboard data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generatePMRExcelNPWT(List<PatientMedicalRecords> pmrList, String excelColumns,
			String excelName, String localPath) throws IOException {
		log.info("Generating Patient Medical Records CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (PatientMedicalRecords data : pmrList) {
			log.debug("data.getDocumentId() : " + data.getDocumentId());
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "BHC Medical Record Id": {
					if (data.getBhcMedicalRecordId() != 0) {
						sb.append(data.getBhcMedicalRecordId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "BHC Invoice Order No": {
					if (data.getBhcInvoiceOrderNo() > 0) {
						sb.append(data.getBhcInvoiceOrderNo());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Document Id": {
					if (data.getDocumentId() != null && !data.getDocumentId().isEmpty()) {
						sb.append(data.getDocumentId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Name": {
					if (data.getDocumentName() != null && !data.getDocumentName().isEmpty()) {
						sb.append(data.getDocumentName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Fullname": {
					if (data.getLastUpdatedUserFullname() != null && !data.getLastUpdatedUserFullname().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != null) {
						sb.append(data.getLastUpdatedUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Document Type": {
					if (data.getDocumentType() != null && !data.getDocumentType().isEmpty()) {
						sb.append(data.getDocumentType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Is Submitted": {
					sb.append(data.getIsSubmitted());
					sb.append("|");
					break;
				}

				case "Documentation History Note Id": {
					if (data.getDocumentationHistoryNoteId() != null
							&& !data.getDocumentationHistoryNoteId().isEmpty()) {
						sb.append(data.getDocumentationHistoryNoteId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Patient Medical Records excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Patient Medical Records data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateUserNotesExcelNPWT(List<UserNotes2> userNotesListNPWT, String excelColumns,
			String excelName, String localPath) throws IOException {
		log.info("Generating User Notes CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (UserNotes2 data : userNotesListNPWT) {
			log.debug("data.getNoteId() : " + data.getNoteId());
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "BHC Invoice Order No": {
					if (data.getBhcInvoiceOrderNo() != 0) {
						sb.append(data.getBhcInvoiceOrderNo());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}

				case "Attempt Category": {
					if (data.getAttemptCategory() != null && !data.getAttemptCategory().isEmpty()) {
						sb.append(data.getAttemptCategory().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}

				case "Note Id": {
					if (data.getNoteId() != null && !data.getNoteId().isEmpty()) {
						sb.append(data.getNoteId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Attempt Type": {
					if (data.getAttemptType() != null && !data.getAttemptType().isEmpty()) {
						sb.append(data.getAttemptType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Followup Date": {
					if (data.getFollowupDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getFollowupDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Addendum Sent": {
					sb.append(data.getAddendumSent());
					sb.append("|");
					break;
				}
				case "Description": {
					if (data.getDescription() != null && !data.getDescription().isEmpty()) {
						sb.append(data.getDescription().replace(",", " ").replace("\n", " ").replace("\r", " ")
								.replace("|", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Patient Full Name": {
					if (data.getPatientFullname() != null && !data.getPatientFullname().isEmpty()) {
						sb.append(data.getPatientFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Username": {
					if (data.getLastUpdatedUsername() != null && !data.getLastUpdatedUsername().isEmpty()) {
						sb.append(data.getLastUpdatedUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Full Name": {
					if (data.getLastUpdatedUserFullname() != null && !data.getLastUpdatedUserFullname().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != null) {
						sb.append(data.getLastUpdatedUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Delete Flag": {
					sb.append(data.isDeleteFlag());
					sb.append("|");
					break;
				}
				case "Addendum Received": {
					sb.append(data.getAddendumReceived());
					sb.append("|");
					break;
				}
				case "Received RX": {
					sb.append(data.getReceivedRX());
					sb.append("|");
					break;
				}

				case "Patient Not Sees 30 Days": {
					sb.append(data.getPatientNotSeen30Days());
					sb.append("|");
					break;
				}
				case "Tagged Users": {
					if (data.getTaggedUsers() != null && !data.getTaggedUsers().isEmpty()) {
						TaggedUser taggedUser = new TaggedUser();
						ObjectMapper objectMapper = new ObjectMapper();

						try {
							taggedUser = objectMapper.readValue(data.getTaggedUsers(), new TypeReference<TaggedUser>() {
							});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing  TaggedUsers:  {}", e);
						}
						if (taggedUser != null && taggedUser.getUserFullName() != null
								&& !taggedUser.getUserFullName().isEmpty()) {

							if (taggedUser.getUserFullName().contains(",")) {
								String formattedDesc = taggedUser.getUserFullName().replace(",", " ");
								sb.append(formattedDesc);
							} else {
								sb.append(taggedUser.getUserFullName());
							}
						} else {
							sb.append("NULL");
						}

					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Contact Method": {
					if (data.getContactMethod() != null && !data.getContactMethod().isEmpty()) {
						sb.append(data.getContactMethod().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}

			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating User Notes excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import User Notes data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

//
	private static String getCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
		LocalDate localDate = LocalDate.now();
		String currentDate = dtf.format(localDate);
		log.debug("current date: " + currentDate);

		return currentDate;
	}

	public static String generateAppNotificationsExcelCTP(List<MasterAppNotification> appNotifications,
			String excelColumns, String excelName, String localPath, boolean isHistorical) {
		log.info("Generating App Notification CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (MasterAppNotification data : appNotifications) {
			log.debug("data.getNotificationId : " + data.getNotificationId());
			sb = new StringBuilder();
			for (String column : columnName) {
				switch (column) {
				case "Notification Id": {
					if (data.getNotificationId() != null && data.getNotificationId().intValue() != 0) {
						sb.append(data.getNotificationId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "User Id": {
					if (data.getUserId() != null) {
						sb.append(data.getUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Read Flag": {
					if (data.getReadFlag() != null && data.getReadFlag()) {
						sb.append(data.getReadFlag());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Notification Description": {
					if (data.getNotificationDescription() != null && !data.getNotificationDescription().isEmpty()) {
						String replacedStr = data.getNotificationDescription().replace(",", " ").replace("\n", " ")
								.replace("\r", " ");

						sb.append(replacedStr);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Notification Title": {
					if (data.getNotificationTitle() != null && !data.getNotificationTitle().isEmpty()) {
						sb.append(data.getNotificationTitle().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Created Timestamp": {
					if (data.getCreatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCreatedTimestamp());
						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());
						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Full Name": {
					if (data.getUserFullname() != null && !data.getUserFullname().isEmpty()) {
						sb.append(data.getUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Creator User Id": {
					if (data.getCreatorUserId() != null) {
						sb.append(data.getCreatorUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Creator User Full Name": {
					if (data.getCreatorUserFullname() != null && !data.getCreatorUserFullname().isEmpty()) {
						sb.append(data.getCreatorUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);
		
		if (isHistorical) {
			fileName = excelName;
		} else {
			fileName = excelName + "_" + getCurrentDate() + ".csv";
		}
		
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured : " + e.getMessage());
			log.error("Exception occured while generating App Notification excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import App Notification data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateDocumentStoreExcel(List<DocumentStore> documentStoreListCTP,
			String excelColumns,
			String excelName, String localPath, boolean isHistorical) {
		log.info("Generating Document Status CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}

		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (DocumentStore data : documentStoreListCTP) {
			sb = new StringBuilder();
			for (String column : columnName) {
				log.debug("column: " + column);
				switch (column) {
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Token": {
					if (data.getDocumentToken() != null && !data.getDocumentToken().isEmpty()) {
						sb.append(data.getDocumentToken().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Request Id": {
					if (data.getDocRequestId() != null && !data.getDocRequestId().isEmpty()) {
						sb.append(data.getDocRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Type": {
					if (data.getDocumentType() != null && !data.getDocumentType().isEmpty()) {
						sb.append(data.getDocumentType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Available": {
					if (data.getDocumentAvailable() != 0) {
						sb.append(data.getDocumentAvailable());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Visit Id": {
					if (data.getVisitId() != null && data.getVisitId().intValue() != 0) {
						sb.append(data.getVisitId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Visit Date": {
					if (data.getVisitDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getVisitDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Type": {
					if (data.getFacilityType() != null && !data.getFacilityType().isEmpty()) {
						sb.append(data.getFacilityType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Config": {
					if (data.getIhealConfig() != null && !data.getIhealConfig().isEmpty()) {
						sb.append(data.getIhealConfig().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Id": {
					if (data.getVendorId() != 0) {
						sb.append(data.getVendorId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Vendor Name": {
					if (data.getVendorName() != null && !data.getVendorName().isEmpty()) {
						sb.append(data.getVendorName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Patient Name": {
					if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
						sb.append(data.getPatientName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Document Request Status": {
					if (data.getIhealDocRequestStatus() != null && !data.getIhealDocRequestStatus().isEmpty()) {
						sb.append(data.getIhealDocRequestStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Document Request Timestamp": {
					if (data.getIhealDocRequestTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getIhealDocRequestTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Download Status": {
					if (data.getDocDownloadStatus() != null && !data.getDocDownloadStatus().isEmpty()) {
						sb.append(data.getDocDownloadStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Download Timestamp": {
					if (data.getDocDownloadTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocDownloadTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Notification Status": {
					if (data.getDocNotificationStatus() != null && !data.getDocNotificationStatus().isEmpty()) {
						sb.append(data.getDocNotificationStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Notification Timestamp": {
					if (data.getDocNotificationTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocNotificationTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Document Get Status": {
					if (data.getVendorDocGetStatus() != null && !data.getVendorDocGetStatus().isEmpty()) {
						sb.append(data.getVendorDocGetStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Document Get Timestamp": {
					if (data.getVendorDocGetTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getVendorDocGetTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Sent Status": {
					if (data.getDocSentStatus() != null && !data.getDocSentStatus().isEmpty()) {
						sb.append(data.getDocSentStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Sent Timestamp": {
					if (data.getDocSentTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getDocSentTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Name": {
					if (data.getUserName() != null && !data.getUserName().isEmpty()) {
						sb.append(data.getUserName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Full Name": {
					if (data.getUserFullName() != null && !data.getUserFullName().isEmpty()) {
						sb.append(data.getUserFullName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Id": {
					if (data.getUserId() != null && data.getUserId() != 0) {
						sb.append(data.getUserId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Error Code": {
					if (data.getErrorCode() != null && !data.getErrorCode().isEmpty()) {
						sb.append(data.getErrorCode().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Error Message": {
					if (data.getErrorMessage() != null && !data.getErrorMessage().isEmpty()) {
						sb.append(data.getErrorMessage().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Store Id": {
					if (data.getStoreId() != 0) {
						sb.append(data.getStoreId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Document Status": {
					if (data.getDocumentStatus() != null && !data.getDocumentStatus().isEmpty()) {
						sb.append(data.getDocumentStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Content": {
					if (data.getDocumentContent() != null && !data.getDocumentContent().isEmpty()) {
						sb.append(data.getDocumentContent().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Service Line": {
					if (data.getServiceLine() != null && !data.getServiceLine().isEmpty()) {
						sb.append(data.getServiceLine().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Name": {
					if (data.getDocumentName() != null && !data.getDocumentName().isEmpty()) {
						sb.append(data.getDocumentName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Source": {
					if (data.getDocumentSource() != null && !data.getDocumentSource().isEmpty()) {
						sb.append(data.getDocumentSource().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Iheal Document Id": {
					if (data.getIhealDocumentId() != null && data.getIhealDocumentId() != 0) {
						sb.append(data.getIhealDocumentId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Iheal Version Id": {
					if (data.getIhealVersionId() != null && data.getIhealVersionId() != 0) {
						sb.append(data.getIhealVersionId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Created Timestamp": {
					if (data.getCreatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCreatedTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Request Id": {
					if (data.getVendorRequestId() != null && !data.getVendorRequestId().isEmpty()) {
						sb.append(data.getVendorRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Status": {
					if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
						sb.append(data.getVendorStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient First Name": {
					if (data.getPatientFirstName() != null && !data.getPatientFirstName().isEmpty()) {
						sb.append(data.getPatientFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Last Name": {
					if (data.getPatientLastName() != null && !data.getPatientLastName().isEmpty()) {
						sb.append(data.getPatientLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Primary Insurance": {
					if (data.getPrimaryInsurance() != null && !data.getPrimaryInsurance().isEmpty()) {
						sb.append(data.getPrimaryInsurance().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Secondary Insurance": {
					if (data.getSecondaryInsurance() != null && !data.getSecondaryInsurance().isEmpty()) {
						sb.append(data.getSecondaryInsurance().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider First Name": {
					if (data.getProviderFirstName() != null && !data.getProviderFirstName().isEmpty()) {
						sb.append(data.getProviderFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider Last Name": {
					if (data.getProviderLastName() != null && !data.getProviderLastName().isEmpty()) {
						sb.append(data.getProviderLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Clinician First Name": {
					if (data.getClinicianFirstName() != null && !data.getClinicianFirstName().isEmpty()) {
						sb.append(data.getClinicianFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Clinician Last Name": {
					if (data.getClinicianLastName() != null && !data.getClinicianLastName().isEmpty()) {
						sb.append(data.getClinicianLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Response Date": {
					if (data.getResponseDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getResponseDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Referral No": {
					if (data.getVendorReferralNo() != null && !data.getVendorReferralNo().isEmpty()) {
						sb.append(data.getVendorReferralNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Need By Date": {
					if (data.getNeedByDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getNeedByDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		if (isHistorical) {
			fileName = excelName;
		} else {
			fileName = excelName + "_" + getCurrentDate() + ".csv";
		}
		
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Document Store excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Document Store data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateDocumentationHistoryExcel(List<DocumentationHistory2> docHistoryListCTP,
			String excelColumns, String excelName, String localPath, boolean isHistorical) {
		log.info("Generating Documentation History CSV File.....");
		String fileName = "";

		// String sheetName = "DocumentationHistory";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (DocumentationHistory2 data : docHistoryListCTP) {
			log.debug("data.getDocumentId() : " + data.getHistoryId());
			sb = new StringBuilder();
			for (String column : columnName) {
				log.debug("column : " + column);
				switch (column) {
				case "History Id": {
					if (data.getHistoryId() != null && data.getHistoryId() != 0) {
						sb.append(data.getHistoryId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "User Notes": {
					if (data.getUserNotes() != null && !data.getUserNotes().isEmpty()) {

						HistoryUserNotes userNotes = new HistoryUserNotes();
						ObjectMapper objectMapper = new ObjectMapper();

						try {
							userNotes = objectMapper.readValue(data.getUserNotes(),
									new TypeReference<HistoryUserNotes>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing HistoryUserNotes:  {}", e);
						}

						if (userNotes != null && userNotes.getDescription() != null
								&& !userNotes.getDescription().isEmpty()) {

							if (userNotes.getDescription().contains("#")) {
								String formattedDesc = userNotes.getDescription().replace("#", " ");
								sb.append(formattedDesc);
							} else {
								sb.append(userNotes.getDescription());
							}
						} else {
							sb.append("NULL");
						}
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Retrieve Status": {
					if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
						sb.append(data.getRetrieveStatus());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != null && data.getPatientId().intValue() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Patient Name": {
					if (data.getPatientName() != null && !data.getPatientName().isEmpty()) {
						sb.append(data.getPatientName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient DOB": {
					if (data.getPatientDOB() != null) {
						String formatFollowupDate = dateFormat.format(data.getPatientDOB());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != null && data.getFacilityId().intValue() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Object": {
					if (data.getDocumentObject() != null && !data.getDocumentObject().isEmpty()) {

						ObjectMapper objectMapper = new ObjectMapper();
						List<HistoryTimelineDocStatus> docStatusList = new ArrayList<>();

						try {
							docStatusList = objectMapper.readValue(data.getDocumentObject(),
									new TypeReference<List<HistoryTimelineDocStatus>>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing HistoryTimelineDocStatus:  {}", e);
						}

						if (docStatusList != null && docStatusList.size() > 0) {
							StringBuilder doc = new StringBuilder();

							for (HistoryTimelineDocStatus docStatus : docStatusList) {
								doc.append(docStatus.getDocumentName());
								doc.append(" ");
							}
							sb.append(doc.toString());
						} else {
							sb.append("NULL");
						}

					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assigned To": {
					if (data.getAssignedTo() != null && !data.getAssignedTo().isEmpty()) {
						sb.append(data.getAssignedTo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Reassigned To": {
					if (data.getReAssignedTo() != null && !data.getReAssignedTo().isEmpty()) {
						sb.append(data.getReAssignedTo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Status": {
					if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
						ObjectMapper objectMapper = new ObjectMapper();
						VendorStatus vendorStatus = new VendorStatus();
						try {
							vendorStatus = objectMapper.readValue(data.getVendorStatus(),
									new TypeReference<VendorStatus>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing VendorStatus:  {}", e);
						}

						if (vendorStatus != null && vendorStatus.getCurrentStatus() != null
								&& !vendorStatus.getCurrentStatus().isEmpty()) {

							sb.append(vendorStatus.getCurrentStatus().replace(",", " "));
						} else {
							sb.append("NULL");
						}
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Name": {
					if (data.getLastUpdatedUserName() != null && !data.getLastUpdatedUserName().isEmpty()) {
						sb.append(data.getLastUpdatedUserName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Fullname": {
					if (data.getLastUpdatedUserFullName() != null && !data.getLastUpdatedUserFullName().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != null && data.getLastUpdatedUserId().intValue() != 0) {
						sb.append(data.getLastUpdatedUserId());
					} else {
						sb.append(0);
					}
					break;
				}
				}
			}

			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);
		
		if (isHistorical) {
			fileName = excelName;
		} else {
			fileName = excelName + "_" + getCurrentDate() + ".csv";
		}
		
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Documentation History excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Documentation History data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generatePMRExcelCTP(List<PatientMedicalRecords> pmrList, String excelColumns, String excelName,
			String localPath) {
		log.info("Generating Patient Medical Records CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		log.info("Inside Generate Excel method 22....................");
		for (PatientMedicalRecords data : pmrList) {
			log.debug("data.getDocumentId() : " + data.getDocumentId());
			sb = new StringBuilder();
			for (String column : columnName) {
				log.debug("column: " + column);
				switch (column) {
				case "BHC Medical Record Id": {
					if (data.getBhcMedicalRecordId() != 0) {
						sb.append(data.getBhcMedicalRecordId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "BHC Invoice Order No": {
					if (data.getBhcInvoiceOrderNo() > 0) {
						sb.append(data.getBhcInvoiceOrderNo());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Document Id": {
					if (data.getDocumentId() != null && !data.getDocumentId().isEmpty()) {
						sb.append(data.getDocumentId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Document Name": {
					if (data.getDocumentName() != null && !data.getDocumentName().isEmpty()) {
						sb.append(data.getDocumentName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Fullname": {
					if (data.getLastUpdatedUserFullname() != null && !data.getLastUpdatedUserFullname().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != null) {
						sb.append(data.getLastUpdatedUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Document Type": {
					if (data.getDocumentType() != null && !data.getDocumentType().isEmpty()) {
						sb.append(data.getDocumentType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Is Submitted": {
					sb.append(data.getIsSubmitted());
					sb.append("|");
					break;
				}

				case "Documentation History Note Id": {
					if (data.getDocumentationHistoryNoteId() != null
							&& !data.getDocumentationHistoryNoteId().isEmpty()) {
						sb.append(data.getDocumentationHistoryNoteId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		fileName = excelName + "_" + getCurrentDate() + ".csv";
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating Patient Medical Records excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import Patient Medical Records data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

//
	public static String generateUserNotesExcel(List<UserNotes2> userNotesListCTP, String excelColumns,
			String excelName, String localPath, boolean isHistorical) {
		log.info("Generating User Notes CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (UserNotes2 data : userNotesListCTP) {
			log.debug("data.getNoteId() : " + data.getNoteId());
			sb = new StringBuilder();
			for (String column : columnName) {
				log.debug("column: " + column);
				switch (column) {
				case "Request Id": {
					if (data.getRequestId() != null && !data.getRequestId().isEmpty()) {
						sb.append(data.getRequestId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "BHC Invoice Order No": {
					if (data.getBhcInvoiceOrderNo() != null && data.getBhcInvoiceOrderNo() != 0) {
						sb.append(data.getBhcInvoiceOrderNo());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}

				case "Attempt Category": {
					if (data.getAttemptCategory() != null && !data.getAttemptCategory().isEmpty()) {
						sb.append(data.getAttemptCategory());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}

				case "Note Id": {
					if (data.getNoteId() != null && !data.getNoteId().isEmpty()) {
						sb.append(data.getNoteId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Attempt Type": {
					if (data.getAttemptType() != null && !data.getAttemptType().isEmpty()) {
						sb.append(data.getAttemptType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Followup Date": {
					if (data.getFollowupDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getFollowupDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Addendum Sent": {
					if (data.getAddendumSent() != null) {
						sb.append(data.getAddendumSent());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Description": {
					if (data.getDescription() != null && !data.getDescription().isEmpty()) {
						sb.append(data.getDescription().replace(",", " ").replace("\n", " ").replace("\r", " ")
								.replace("|", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Id": {
					if (data.getPatientId() != null && data.getPatientId() != 0) {
						sb.append(data.getPatientId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Patient Full Name": {
					if (data.getPatientFullname() != null && !data.getPatientFullname().isEmpty()) {
						sb.append(data.getPatientFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Username": {
					if (data.getLastUpdatedUsername() != null && !data.getLastUpdatedUsername().isEmpty()) {
						sb.append(data.getLastUpdatedUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Full Name": {
					if (data.getLastUpdatedUserFullname() != null && !data.getLastUpdatedUserFullname().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != null) {
						sb.append(data.getLastUpdatedUserId());
					} else {
						sb.append("0");
					}
					sb.append("|");
					break;
				}
				case "Delete Flag": {
					sb.append(data.isDeleteFlag());
					sb.append("|");
					break;
				}
				case "Addendum Received": {
					sb.append(data.getAddendumReceived());
					sb.append("|");
					break;
				}
				case "Received RX": {
					sb.append(data.getReceivedRX());
					sb.append("|");
					break;
				}

				case "Patient Not Sees 30 Days": {
					sb.append(data.getPatientNotSeen30Days());
					sb.append("|");
					break;
				}
				case "Tagged Users": {

					if (data.getTaggedUsers() != null && !data.getTaggedUsers().isEmpty()) {
						TaggedUser taggedUser = new TaggedUser();
						ObjectMapper objectMapper = new ObjectMapper();

						try {
							taggedUser = objectMapper.readValue(data.getTaggedUsers(), new TypeReference<TaggedUser>() {
							});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing  TaggedUsers:  {}", e);
						}
						if (taggedUser != null && taggedUser.getUserFullName() != null
								&& !taggedUser.getUserFullName().isEmpty()) {

							if (taggedUser.getUserFullName().contains(",")) {
								String formattedDesc = taggedUser.getUserFullName().replace(",", " ");
								sb.append(formattedDesc);
							} else {
								sb.append(taggedUser.getUserFullName());
							}
						} else {
							sb.append("NULL");
						}

					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Contact Method": {
					if (data.getContactMethod() != null && !data.getContactMethod().isEmpty()) {
						sb.append(data.getContactMethod().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					break;
				}
				}
			}

			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);
		
		if (isHistorical) {
			fileName = excelName;
		} else {
			fileName = excelName + "_" + getCurrentDate() + ".csv";
		}
		
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating User Notes excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import User Notes data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

	public static String generateCTPDashboardExcel(List<CTPDashboard> ctpDashboardList, String excelColumns,
			String excelName, String localPath, boolean isHistorical) {
		log.info("Generating CTP Dashboard CSV File.....");
		String fileName = "";

		String[] columnName = excelColumns.split("%");

		ArrayList<String> lines = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < columnName.length; i++) {
			sb.append(columnName[i]);
			sb.append("|");
		}
		// Remove last | symbol
		String colunms = sb.substring(0, sb.length() - 1);
		// log.debug("colunms : " +colunms);

		sb = new StringBuilder();
		sb.append(colunms);
		sb.append("\n");
		lines.add(sb.toString());

		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (CTPDashboard data : ctpDashboardList) {
			log.debug("data.getRequestId : " + data.getOrderId());
			sb = new StringBuilder();
			for (String column : columnName) {
				log.debug("column: " + column);
				switch (column) {
				case "Request Id": {
					if (data.getOrderId() != null && !data.getOrderId().isEmpty()) {
						sb.append(data.getOrderId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Id": {
					if (data.getFacilityId() != null && data.getFacilityId().intValue() != 0) {
						sb.append(data.getFacilityId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Bluebook Id": {
					if (data.getBluebookId() != null && !data.getBluebookId().isEmpty()) {
						sb.append(data.getBluebookId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Name": {
					if (data.getFacilityName() != null && !data.getFacilityName().isEmpty()) {
						sb.append(data.getFacilityName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Referral No": {
					if (data.getVendorReferralNo() != null && !data.getVendorReferralNo().isEmpty()) {
						sb.append(data.getVendorReferralNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Healogics Order No": {
					if (data.getHealogicsOrderNo() != null && !data.getHealogicsOrderNo().isEmpty()) {
						sb.append(data.getHealogicsOrderNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Healogics Patient Id": {
					if (data.getHealogicsPatientId() != null) {
						sb.append(data.getHealogicsPatientId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Healogics Patient MRN": {
					if (data.getHealogicsPatientMRN() != null && !data.getHealogicsPatientMRN().isEmpty()) {
						sb.append(data.getHealogicsPatientMRN().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Id": {
					if (data.getVendorId() != null && data.getVendorId() != 0) {
						sb.append(data.getVendorId());
					} else {
						sb.append(0);
					}
					sb.append("|");
					break;
				}
				case "Vendor Name": {
					if (data.getVendorName() != null && !data.getVendorName().isEmpty()) {
						sb.append(data.getVendorName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Order Source": {
					if (data.getOrderSource() != null && !data.getOrderSource().isEmpty()) {
						sb.append(data.getOrderSource().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient First Name": {
					if (data.getPatientFirstName() != null && !data.getPatientFirstName().isEmpty()) {
						sb.append(data.getPatientFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Last Name": {
					if (data.getPatientLastName() != null && !data.getPatientLastName().isEmpty()) {
						sb.append(data.getPatientLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient Full Name": {
					if (data.getPatientFullname() != null && !data.getPatientFullname().isEmpty()) {
						sb.append(data.getPatientFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Patient DOB": {
					if (data.getPatientDOB() != null) {
						String formatFollowupDate = dateFormat.format(data.getPatientDOB());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}

				case "Physician First Name": {
					if (data.getPhysicianFirstName() != null && !data.getPhysicianFirstName().isEmpty()) {
						sb.append(data.getPhysicianFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Physician Last Name": {
					if (data.getPhysicianLastName() != null && !data.getPhysicianLastName().isEmpty()) {
						sb.append(data.getPhysicianLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Case Manager First Name": {
					if (data.getCaseManagerFirstName() != null && !data.getCaseManagerFirstName().isEmpty()) {
						sb.append(data.getCaseManagerFirstName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Case Manager Last Name": {
					if (data.getCaseManagerLastName() != null && !data.getCaseManagerLastName().isEmpty()) {
						sb.append(data.getCaseManagerLastName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Vendor Status": {
					if (data.getVendorStatus() != null && !data.getVendorStatus().isEmpty()) {
						sb.append(data.getVendorStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Received Date": {
					if (data.getReceivedDate() != null) {
						String formatFollowupDate = dateFormat.format(data.getReceivedDate());
						sb.append(formatFollowupDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Waiting Docs Sec Status": {
					if (data.getWaitingDocsSecStatus() != null && !data.getWaitingDocsSecStatus().isEmpty()) {
						sb.append(data.getWaitingDocsSecStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Pend Prior Auth Date": {
					if (data.getPendPriorAuthDate() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getPendPriorAuthDate());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Pend Prior Auth Waiting": {
					if (data.getPendPriorAuthWaiting() != null && !data.getPendPriorAuthWaiting().isEmpty()) {
						sb.append(data.getPendPriorAuthWaiting().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Under Appeal Date": {
					if (data.getUnderAppealDate() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getUnderAppealDate());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Under Appeal Status": {
					if (data.getUnderAppealStatus() != null && !data.getUnderAppealStatus().isEmpty()) {
						sb.append(data.getUnderAppealStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "FollowUp Date": {
					if (data.getFollowupDate() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getFollowupDate());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Missing Elements": {
					if (data.getMissingElements() != null && !data.getMissingElements().isEmpty()) {
						sb.append(data.getMissingElements().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Special Instructions": {
					if (data.getSpecialInstructions() != null && !data.getSpecialInstructions().isEmpty()) {
						sb.append(data.getSpecialInstructions().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Primary Insurance": {
					if (data.getPrimaryInsurance() != null && !data.getPrimaryInsurance().isEmpty()) {

						PrimaryInsuranceMaster primaryIns = new PrimaryInsuranceMaster();
						ObjectMapper objectMapper = new ObjectMapper();

						try {
							primaryIns = objectMapper.readValue(data.getPrimaryInsurance(),
									new TypeReference<PrimaryInsuranceMaster>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing Primary Insurance:  {}", e);
						}

						if (primaryIns != null && primaryIns.getPrimaryInsName() != null
								&& !primaryIns.getPrimaryInsName().isEmpty()) {
							sb.append(primaryIns.getPrimaryInsName());
						} else {
							sb.append("NULL");
						}
					} else {
						sb.append("NULL");
					}

					sb.append("|");
					break;
				}
				case "Primary Insurance Company": {
					if (data.getPrimaryInsuranceCompany() != null && !data.getPrimaryInsuranceCompany().isEmpty()) {
						sb.append(data.getPrimaryInsuranceCompany().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Secondary Insurance": {
					if (data.getSencondaryInsurance() != null && !data.getSencondaryInsurance().isEmpty()) {

						SecondaryInsuranceMaster secondaryIns = new SecondaryInsuranceMaster();
						ObjectMapper objectMapper = new ObjectMapper();

						try {
							secondaryIns = objectMapper.readValue(data.getSencondaryInsurance(),
									new TypeReference<SecondaryInsuranceMaster>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing Secondary Insurance:  {}", e);
						}

						if (secondaryIns != null && secondaryIns.getSecondaryInsName() != null
								&& !secondaryIns.getSecondaryInsName().isEmpty()) {
							sb.append(secondaryIns.getSecondaryInsName());
						} else {
							sb.append("NULL");
						}
					} else {
						sb.append("NULL");
					}

					sb.append("|");
					break;
				}
				case "Tertiary Insurance": {
					if (data.getTertiaryInsurance() != null && !data.getTertiaryInsurance().isEmpty()) {

						TertiaryInsuranceMaster tertiaryIns = new TertiaryInsuranceMaster();
						ObjectMapper objectMapper = new ObjectMapper();

						try {
							tertiaryIns = objectMapper.readValue(data.getTertiaryInsurance(),
									new TypeReference<TertiaryInsuranceMaster>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing Tertiary Insurance:  {}", e);
						}

						if (tertiaryIns != null && tertiaryIns.getTertiaryInsName() != null
								&& !tertiaryIns.getTertiaryInsName().isEmpty()) {
							sb.append(tertiaryIns.getTertiaryInsName());
						} else {
							sb.append("NULL");
						}
					} else {
						sb.append("NULL");
					}

					sb.append("|");
					break;
				}
				case "HCPC": {
					if (data.getHcpc() != null && !data.getHcpc().isEmpty()) {
						sb.append(data.getHcpc().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Product SKU": {
					if (data.getProductSKU() != null && !data.getProductSKU().isEmpty()) {
						sb.append(data.getProductSKU().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Product Name": {
					if (data.getProductName() != null && !data.getProductName().isEmpty()) {
						sb.append(data.getProductName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "No App Approved": {
					if (data.getNoAppApproved() != null && !data.getNoAppApproved().isEmpty()) {
						sb.append(data.getNoAppApproved().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "No Units Approved": {
					if (data.getNoUnitsApproved() != null && !data.getNoUnitsApproved().isEmpty()) {
						sb.append(data.getNoUnitsApproved().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Approval TimeFrame": {
					if (data.getApprovelTimeframe() != null && !data.getApprovelTimeframe().isEmpty()) {
						sb.append(data.getApprovelTimeframe().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "ICD10 Codes": {
				    if (data != null && data.getIcd10Codes() != null && !data.getIcd10Codes().isEmpty()) {
				        ICD10Data icd10Data;
				        ObjectMapper objectMapper = new ObjectMapper();

				        try {
				            // Assuming `data.getIcd10Codes()` fetches a JSON string representation of ICD10Data
				            icd10Data = objectMapper.readValue(data.getIcd10Codes(), new TypeReference<ICD10Data>() {});
				            
				            if (icd10Data != null) {
				                sb.append(icd10Data.getCode().replace(",", " "));
				                if (icd10Data.getName() != null && !icd10Data.getName().isEmpty()) {
				                    sb.append(" - ").append(icd10Data.getName().replace(",", " "));
				                }
				            } else {
				                sb.append("NULL");
				            }
				        } catch (JsonProcessingException e) {
				            log.error("Exception while processing ICD10 Codes: {}", e.getMessage(), e);
				            sb.append("NULL");
				        }
				    } else {
				        sb.append("NULL");
				    }

				    sb.append("|");
				    break;
				}

				case "Place Of Service": {
					if (data.getPlaceOfService() != null && !data.getPlaceOfService().isEmpty()) {
						sb.append(data.getPlaceOfService().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Wound Id": {
					if (data.getWoundId() != null && !data.getWoundId().isEmpty()) {
						sb.append(data.getWoundId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Completed Date": {
					if (data.getCompletedDate() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getCompletedDate());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Completed Status": {
					if (data.getCompletedStatus() != null && !data.getCompletedStatus().isEmpty()) {
						sb.append(data.getCompletedStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Coverage Summary": {
					if (data.getCoverageSummary() != null && !data.getCoverageSummary().isEmpty()) {
						sb.append(data.getCoverageSummary().replaceAll("\\r?\\n", " ")
                                						   .replaceAll("\\s+", " ")
                                						   .replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Insert Timestamp": {
					if (data.getInsertTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getInsertTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Sales Rep Manager": {
					if (data.getSalesRepManager() != null && !data.getSalesRepManager().isEmpty()) {
						sb.append(data.getSalesRepManager().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Regional Director": {
					if (data.getReginalDirector() != null && !data.getReginalDirector().isEmpty()) {
						sb.append(data.getReginalDirector().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "SGP": {
					if (data.getSgp() != null && !data.getSgp().isEmpty()) {
						sb.append(data.getSgp().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "SGP Date": {
					if (data.getSgpDate() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getSgpDate());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "SGP CPT Code": {
					if (data.getSgpCPTCode() != null && !data.getSgpCPTCode().isEmpty()) {
						sb.append(data.getSgpCPTCode().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated Timestamp": {
					if (data.getLastUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Name": {
					if (data.getLastIpdatedUsername() != null && !data.getLastIpdatedUsername().isEmpty()) {
						sb.append(data.getLastIpdatedUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Full Name": {
					if (data.getLastUpdatedUserFullname() != null && !data.getLastUpdatedUserFullname().isEmpty()) {
						sb.append(data.getLastUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Updated User Id": {
					if (data.getLastUpdatedUserId() != null && !data.getLastUpdatedUserId().isEmpty()) {
						sb.append(data.getLastUpdatedUserId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Facility Type": {
					if (data.getFacilityType() != null && !data.getFacilityType().isEmpty()) {
						sb.append(data.getFacilityType().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assignee Full Name": {
					if (data.getAssigneeFullname() != null && !data.getAssigneeFullname().isEmpty()) {
						sb.append(data.getAssigneeFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assignee User Name": {
					if (data.getAssigneeUsername() != null && !data.getAssigneeUsername().isEmpty()) {
						sb.append(data.getAssigneeUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Assignee User Id": {
					if (data.getAssigneeUserId() != null && !data.getAssigneeUserId().isEmpty()) {
						sb.append(data.getAssigneeUserId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Retrieve Status": {
					if (data.getRetrieveStatus() != null && !data.getRetrieveStatus().isEmpty()) {
						sb.append(data.getRetrieveStatus().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated Timestamp": {
					if (data.getStatusUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getStatusUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Provider Name": {
					if (data.getProviderName() != null && !data.getProviderName().isEmpty()) {
						sb.append(data.getProviderName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Received": {
					if (data.getLastReceived() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastReceived());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Actioned": {
					if (data.getLastActioned() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastActioned());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "WoundQ Order No": {
					if (data.getWoundqOrderNo() != null && !data.getWoundqOrderNo().isEmpty()) {
						sb.append(data.getWoundqOrderNo().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Files Sent": {
					if (data.getFilesSent() != null && data.getFilesSent().intValue() != 0) {
						sb.append(data.getFilesSent());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "First Received": {
					if (data.getFirstReceived() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getFirstReceived());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last File Updated": {
					if (data.getLastFileUpdated() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastFileUpdated());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "No Of Updates": {
					if (data.getNoOfUpdates() != null && data.getNoOfUpdates().intValue() != 0) {
						sb.append(data.getNoOfUpdates());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Team Updated Timestamp": {
					if (data.getLastTeamUpdatedTimestamp() != null) {
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(data.getLastTeamUpdatedTimestamp());

						// calendar.add(Calendar.MINUTE,req.getOffsetMinutes());

						Timestamp updatedTimestamp = new Timestamp(calendar.getTimeInMillis());

						String formatlLastTeamUpdatedDate = timeFormat.format(updatedTimestamp);
						sb.append(formatlLastTeamUpdatedDate);
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Last Team Updated User Full Name": {
					if (data.getLastTeamUpdatedUserFullname() != null
							&& !data.getLastTeamUpdatedUserFullname().isEmpty()) {
						sb.append(data.getLastTeamUpdatedUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated User Full Name": {
					if (data.getStatusUpdatedUserFullName() != null && !data.getStatusUpdatedUserFullName().isEmpty()) {
						sb.append(data.getStatusUpdatedUserFullName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated User Id": {
					if (data.getStatusUpdatedUserId() != null && !data.getStatusUpdatedUserId().isEmpty()) {
						sb.append(data.getStatusUpdatedUserId().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Updated User Name": {
					if (data.getStatusUpdatedUserName() != null && !data.getStatusUpdatedUserName().isEmpty()) {
						sb.append(data.getStatusUpdatedUserName().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Status Change Notes": {
					if (data.getStatusChangeNotes() != null && !data.getStatusChangeNotes().isEmpty()) {
						sb.append(data.getStatusChangeNotes().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Secondary Status": {
					if (data.getSecondaryStatus() != null && !data.getSecondaryStatus().isEmpty()) {
						sb.append(data.getStatusChangeNotes().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Addendum": {
					if (data.getAddendum() != null && data.getAddendum() != 0) {
						sb.append(data.getAddendum());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Addendum User Full Name": {
					if (data.getAddendumUserFullname() != null && !data.getAddendumUserFullname().isEmpty()) {
						sb.append(data.getAddendumUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Addendum User Id": {
					if (data.getAddendumUserId() != null && data.getAddendumUserId().intValue() != 0) {
						sb.append(data.getAddendumUserId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Addendum User Name": {
					if (data.getAddendumUsername() != null && !data.getAddendumUsername().isEmpty()) {
						sb.append(data.getAddendumUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Record Modify": {
					if (data.getRecordModify() != null && data.getRecordModify().intValue() != 0) {
						sb.append(data.getRecordModify());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Record Modify User Full Name": {
					if (data.getRecordModifyUserFullname() != null && !data.getRecordModifyUserFullname().isEmpty()) {
						sb.append(data.getRecordModifyUserFullname().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Record Modify User Id": {
					if (data.getRecordModifyUserId() != null && data.getRecordModifyUserId().intValue() != 0) {
						sb.append(data.getRecordModifyUserId());
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}
				case "Record Modify User Name": {
					if (data.getRecordModifyUsername() != null && !data.getRecordModifyUsername().isEmpty()) {
						sb.append(data.getRecordModifyUsername().replace(",", " "));
					} else {
						sb.append("NULL");
					}
					sb.append("|");
					break;
				}

				}
			}
			sb.append("\n");
			lines.add(sb.toString());
		}

		File currDir = new File(localPath);
		String path = currDir.getAbsolutePath();
		log.debug("path : " + path);

		if (isHistorical) {
			fileName = excelName;
		} else {
			fileName = excelName + "_" + getCurrentDate() + ".csv";
		}
		
		log.debug("fileName: " + fileName);

		String fileLocation = path + "/" + fileName;
		log.debug("fileLocation: " + fileLocation);

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation))) {
			Iterator<String> linesIterator = lines.iterator();
			while (linesIterator.hasNext())
				bw.write(linesIterator.next());
		} catch (IOException e) {
			log.error("Exception occured while generating NPWT Dashboard excel file: {}", e.getMessage());
			throw new RuntimeException("fail to import NPWT Dashboard data to Excel file: " + e.getMessage());
		}

		return fileName;
	}

}