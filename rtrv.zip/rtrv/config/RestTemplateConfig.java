package com.healogics.rtrv.config;

import java.io.IOException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

	private final HttpHostsConfiguration httpHostConfiguration;
	
	@Autowired
	public RestTemplateConfig(HttpHostsConfiguration httpHostConfiguration) {
		this.httpHostConfiguration = httpHostConfiguration;
	}
	
   /* @Bean
    public RestTemplate restTemplate() throws KeyManagementException,
            NoSuchAlgorithmException, KeyStoreException,
            CertificateException, IOException {

        SSLContext sslContext = new SSLContextBuilder()
                .loadTrustMaterial(new URL("classpath:keystore.p12"), "healogics".toCharArray())
                .build();
        SSLConnectionSocketFactory sslConFactory = new SSLConnectionSocketFactory(sslContext);

        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConFactory).build();
        
        ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        return new RestTemplate(requestFactory);

    }*/
    
    @Bean
	public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
		PoolingHttpClientConnectionManager result = new PoolingHttpClientConnectionManager();
		result.setMaxTotal(this.httpHostConfiguration.getMaxTotal());
		// Default max per route is used in case it's not set for a specific route
		result.setDefaultMaxPerRoute(this.httpHostConfiguration.getDefaultMaxPerRoute());
		
		// and / or
		/*if (CollectionUtils.isNotEmpty(this.httpHostConfiguration.getMaxPerRoutes())) {
			for (HttpHostConfiguration httpHostConfig : this.httpHostConfiguration.getMaxPerRoutes()) {
				HttpHost host = new HttpHost(httpHostConfig.getHost(), httpHostConfig.getPort(), 
						httpHostConfig.getScheme());
				// Max per route for a specific host route
				result.setMaxPerRoute(new HttpRoute(host), httpHostConfig.getMaxPerRoute());
			}
		}*/
		
		return result;
	}

	@Bean
	public RequestConfig requestConfig() {
		RequestConfig result = RequestConfig.custom()
			.setConnectionRequestTimeout(this.httpHostConfiguration.getTimeOut())
			.setConnectTimeout(this.httpHostConfiguration.getTimeOut())
			.setSocketTimeout(this.httpHostConfiguration.getTimeOut())
			.build();
		return result;
	}

	@Bean(name = "httpClient1")
	public CloseableHttpClient httpClient1(
			PoolingHttpClientConnectionManager poolingHttpClientConnectionManager,
			RequestConfig requestConfig) throws KeyManagementException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {
		
		SSLContext sslContext = new SSLContextBuilder()
                .loadTrustMaterial(new URL("classpath:keystore.p12"), "healogics".toCharArray())
                .build();
        SSLConnectionSocketFactory sslConFactory = new SSLConnectionSocketFactory(sslContext);

        //CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConFactory).build();
        
		CloseableHttpClient result = HttpClients.custom().setSSLSocketFactory(sslConFactory)
			.setConnectionManager(poolingHttpClientConnectionManager)
			.setDefaultRequestConfig(requestConfig)
			.build();
		return result;
	}
	
	@Bean(name = "httpClient2")
	public CloseableHttpClient httpClient2(
			PoolingHttpClientConnectionManager poolingHttpClientConnectionManager,
			RequestConfig requestConfig) throws KeyManagementException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {
		
		SSLContext sslContext = new SSLContextBuilder()
                .loadTrustMaterial(new URL("classpath:keystore_npwt.p12"), "solventum".toCharArray())
                .build();
        SSLConnectionSocketFactory sslConFactory = new SSLConnectionSocketFactory(sslContext);

        //CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConFactory).build();
        
		CloseableHttpClient result = HttpClients.custom().setSSLSocketFactory(sslConFactory)
			.setConnectionManager(poolingHttpClientConnectionManager)
			.setDefaultRequestConfig(requestConfig)
			.build();
		return result;
	}

	@Bean(name = "httpTemplate1")
	public RestTemplate restTemplate1(@Qualifier("httpClient1") HttpClient httpClient1) {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient1);
		return new RestTemplate(requestFactory);
	}
	
	@Bean(name = "httpTemplate2")
	public RestTemplate restTemplate2(@Qualifier("httpClient2") HttpClient httpClient2) {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient2);
		return new RestTemplate(requestFactory);
	}
}
