package com.healogics.rtrv.config;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class SpringInterceptorFilter implements HandlerInterceptor {

	private static Logger logger = LoggerFactory.getLogger(SpringInterceptorFilter.class);

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) {

		String requestId = generateRequestId();
		MDC.put("requestId", requestId);

		String sessionId = request.getSession().getId();
		MDC.put("sessionId", sessionId);

		String userId = getUserId(request);
		MDC.put("userId", userId);

		String method = request.getMethod();
		MDC.put("method", method);

		String path = getPath(request);
		MDC.put("path", path);
		
		logger.info(" ******* ---------------------------------------------------- *******");
		logger.info("Request [{}] recieved from user [{}] . Method: {}, Path: {}",
				requestId, userId, method, path);
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler, ModelAndView modelAndView) {
		MDC.clear();
	}

	public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
			Object handler, Exception ex) {
		logger.info("Completed request: {} {} ",request.getRequestURI(), request.getMethod());
		logger.info(" ******* ---------------------------------------------------- *******");
	}

	private String getPath(HttpServletRequest request) {

		if (request.getRequestURI() == null) {
			return "";
		}

		String[] reqPathSeg = request.getRequestURI().split("/");
		return reqPathSeg[reqPathSeg.length - 1];
	}

	private String generateRequestId() {
		return UUID.randomUUID().toString();
	}

	private String getUserId(HttpServletRequest request) {

		/*
		 * Authentication authenticate =
		 * SecurityContextHolder.getContext().getAuthentication();
		 * logger.info("Authentication Name: "+authenticate.getName()); if
		 * (authenticate != null &&
		 * !authenticate.getName().equals("anonymousUser")) { return
		 * authenticate.getName(); } else { return "*****"; }
		 */

		if (request.getAttribute("userId") == null) {
			return "*****";
		}
		String userId = request.getAttribute("userId").toString();
		if (userId != null && !userId.equals("anonymousUser")) {
			return userId;
		}
		return "*****";
	}

}
