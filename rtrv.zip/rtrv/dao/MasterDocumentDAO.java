package com.healogics.rtrv.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.exception.CustomException;

public interface MasterDocumentDAO {

	MasterDocumentStore getDocumentContent(String documentRequestId,
			String documentToken) throws CustomException;
	public List<MasterDocumentStore> getAttachments(String orderId)
			throws CustomException;
	public boolean saveDocumentContent(MasterSubmitChartReq req,
			MasterDocumentStore doc, boolean isManual);
	public boolean saveDocNotificationStatus(MasterSubmitChartReq req,
			MasterDocumentStore doc);
	public boolean saveGetDocumentStatus(String docToken, String docGetStatus,
			Timestamp docGetTimestamp, String docSentStatus, Timestamp docSentTimestamp);

}
