package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.entity.DocumentationHistory;
import com.healogics.rtrv.exception.CustomException;

public interface HistoryStatusDAO {
	public List<DocumentationHistory> getStatusHistory(int bhcMedRecId, int bhcInvoiceId, int index)
			throws CustomException;

	public Long getTotalCount(int bhcMedRecId, int bhcInvoiceId) throws CustomException;

	public DocumentStatus getDocumentStatusByHistory(String documentId) throws CustomException;

}
