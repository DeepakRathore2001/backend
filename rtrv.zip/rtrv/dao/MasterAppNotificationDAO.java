package com.healogics.rtrv.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.rtrv.dto.MasterAppNotificaionReq;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.exception.CustomException;

public interface MasterAppNotificationDAO {
	public Boolean saveNoteNotifications(SaveMasterNotesReq req)
			throws CustomException;
	
	public List<MasterAppNotification> getAppNotification(Long userId,
			Timestamp clearNotificationTimestamp, String last30DaysDate)
			throws CustomException;
	
	public Long updateNotifications(MasterAppNotificaionReq req)
			throws CustomException;

	public Boolean saveAssigneeNotifications(MasterSaveChartReq req) throws CustomException;

	public Boolean saveBatchAssignedNotifications(int size, MasterCTPDashboardReq req)
			throws CustomException;
	
	public Long getAppNotificationCount(String userId)
			throws CustomException;
}
