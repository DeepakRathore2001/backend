package com.healogics.rtrv.dao;

public interface MasterRetrieveDAO {
	public boolean isValidUser(String userName, String password);
}
