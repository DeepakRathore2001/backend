package com.healogics.rtrv.dao;

import java.util.List;
import java.util.Map;

import com.healogics.rtrv.dto.AWDData;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.FilterOptions;
import com.healogics.rtrv.dto.MedicalRecodInvoiceDetails;
import com.healogics.rtrv.dto.SetStatusReq;
import com.healogics.rtrv.dto.SetStatusRes;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.entity.AWDDashboard;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.exception.CustomException;

public interface DashboardDAO {
	public List<AWDDashboard> getAllAWDRecords(boolean isExcel, DashboardReq req,
			int offset, String taskType,
			String assignee, Boolean isSuperUser) throws CustomException;

	public Long getAWDNewTaskCount() throws CustomException;

	public Long getTotalCount(int offset, String taskType,
			String assignee, DashboardReq req, Boolean isSuperUser) throws CustomException;

	public FilterOptions getFilterOptions(DashboardReq req) throws CustomException;

	public Map<String, Object> getFileredAWDList(boolean isExcel,
			DashboardReq req, int index, String taskType,
			String assignee, Boolean isSuperUser) throws CustomException;

	public List<MedicalRecodInvoiceDetails> getAllInvoiceDetails(int bhcMedicalRecordId) throws CustomException;

	public SetStatusRes setStatus(SetStatusReq req) throws CustomException;

	public UpdateAssignedToRes updatedAssigneedTo(DashboardReq req, List<AWDData> awdRecords) throws CustomException;

	public List<UserFacilities> getUserFacilities(String userId, String username) throws CustomException;
	
	public FacilityDetails getFacilityDetails(String bbc) throws CustomException;

	public Boolean getRetrieveUser(String userId, String username) throws CustomException;

	public FacilityDetails getFacilityDetailsForDetailsCTP(Integer facilityId) throws CustomException;
}
