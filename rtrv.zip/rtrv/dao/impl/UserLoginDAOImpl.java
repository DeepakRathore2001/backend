package com.healogics.rtrv.dao.impl;

import java.net.InetAddress;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.UserLoginDAO;
import com.healogics.rtrv.dto.IHealDocument;
import com.healogics.rtrv.dto.IhealUserRes;
import com.healogics.rtrv.dto.LoginUser;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.entity.UserLogin;

@Repository
@TransactionManager1
public class UserLoginDAOImpl implements UserLoginDAO {
	private final Logger log = LoggerFactory.getLogger(UserLoginDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public UserLoginDAOImpl(@Qualifier("SessionFactory1")SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveUserLogin(LoginUser loginUser) {
		Session session = this.sessionFactory.getCurrentSession();
		DateTimeFormatter timeFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

		try {
			UserLogin userLogin = new UserLogin();
			userLogin.setCreatedTimestamp(LocalDateTime.now());
			userLogin.setDeviceId(loginUser.getDeviceId());
			userLogin.setDeviceIP(loginUser.getDeviceIp());
			userLogin.setDeviceType(loginUser.getDeviceType());
			userLogin.setEmailId(loginUser.getEmailId());
			userLogin.setEmployedBy(loginUser.getEmployedBy());
			userLogin.setErrorCode(loginUser.getErrorCode());
			userLogin.setErrorMessage(loginUser.getErrorMessage());
			userLogin.setFacilityId(0);

			if (loginUser.getLastLoginTimestamp() != null) {
				String lastLoginTime = loginUser.getLastLoginTimestamp();
				String finalLastTime = lastLoginTime.replaceAll("\\.\\d{2,3}$",
						"");
				LocalDateTime lastLogin = LocalDateTime.parse(finalLastTime,
						timeFormat);
				userLogin.setLastLoginTimestamp(lastLogin);
			}

			userLogin.setLoginStatus(loginUser.getLoginStatus());
			userLogin.setServerIP((InetAddress.getLocalHost() == null)
					? ""
					: InetAddress.getLocalHost().getHostAddress());
			userLogin.setUserFullName(loginUser.getUserFullname());
			userLogin.setUserId(loginUser.getUserId());
			userLogin.setUsername(loginUser.getUsername());
			userLogin.setUserRole(loginUser.getUserRole());

			log.debug("userLogin : {}", userLogin);

			session.save(userLogin);
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
		}
	}

	@Override
	public void saveRetrieveUserLogin(IhealUserRes user) {
		Session session = this.sessionFactory.getCurrentSession();
		RetrieveUsers record = null;

		try {
			String hql = "FROM RetrieveUsers a where a.userId="
					+ user.getUserId();

			record = (RetrieveUsers) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetch RetrieveUsers : {}",
					e.getMessage());
		}

		try {
			if (record != null) {
				String hql = "UPDATE RetrieveUsers r SET r.username=:username,"
						+ "r.userFullName=:userFullName, r.emailId=:emailId,"
						+ "r.lastLoggedInTimestamp=:lastLoggedInTimestamp "
						+ "where r.userId=:userId";

				Query query = session.createQuery(hql);

				query.setParameter("username", user.getUserName());
				query.setParameter("userFullName",
						user.getLastName() + ", " + user.getFirstName());
				query.setParameter("emailId", user.getEmail());
				query.setParameter("lastLoggedInTimestamp",
						new Timestamp(System.currentTimeMillis()));
				query.setParameter("userId", Long.valueOf(user.getUserId()));

				query.executeUpdate();
				
			} else {
				record = new RetrieveUsers();
				record.setUsername(user.getUserName());
				record.setUserId(Long.valueOf(user.getUserId()));
				record.setUserFullName(
						user.getLastName() + ", " + user.getFirstName());
				record.setEmailId(user.getEmail());
				record.setLastLoggedInTimestamp(
						new Timestamp(System.currentTimeMillis()));
				record.setRetrieveRole("User");
				record.setIsSuperUser(false);
				
				session.save(record);
				
			}
			log.debug("Updated user in RetrieveUsers Table: {}",user);
		} catch (Exception e) {
			log.error("Exception occured :  {}", e.getMessage());
		}
	}

	@Override
	public int saveUserFacilities(String userId,
			List<UserFacilities> facilities) {
		Session session = this.sessionFactory.getCurrentSession();
		int rows = 0;
		try {
			if (userId != null && !userId.isEmpty() && facilities != null
					&& !facilities.isEmpty()) {

				String userFac = null;
				try {
					userFac = new ObjectMapper().writeValueAsString(facilities);
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception:   {}", e);
				}

				String hql = "UPDATE RetrieveUsers r SET r.facilities=:facilities "
						+ "where r.userId=:userId";

				Query query = session.createQuery(hql);

				query.setParameter("facilities", userFac);
				query.setParameter("userId", Long.valueOf(userId));

				rows = query.executeUpdate();
				log.debug("Updated user facilities in DB for the userId:  {}",userId);
			}
		} catch (Exception e) {
			log.error("Exception occured while saving user facilities:  {}",
					e.getMessage());
		}
		return rows;
	}
}
