package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.ClickStreamDAO;
import com.healogics.rtrv.dto.ClickStreamReq;
import com.healogics.rtrv.entity.ClickStream;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class ClickStreamDAOImpl implements ClickStreamDAO {
	private final Logger log = LoggerFactory.getLogger(ClickStreamDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public ClickStreamDAOImpl(@Qualifier("SessionFactory1") SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveClickStreamData(ClickStreamReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			ClickStream stream = new ClickStream();
			stream.setBluebookId(req.getBluebookId());
			stream.setCreatedTimestamp(currentTime);
			stream.setFacilityId(req.getFacilityId());
			stream.setModuleDescription(req.getModuleDescription());
			stream.setModuleName(req.getModuleName());
			stream.setServiceLine(req.getServiceLine());
			stream.setUserFullname(req.getUserFullname());
			stream.setUserId(req.getUserId());
			stream.setUsername(req.getUsername());
			stream.setVendor(req.getVendor());
			stream.setBhcMedicalRecordId(req.getBhcMedRecId());
			stream.setBhcInvoiceOrderId(req.getBhcInvOrderId());

			session.save(stream);

		} catch (Exception e) {
			log.error("Exception occured while saving clickstream data: {}" , e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

}
