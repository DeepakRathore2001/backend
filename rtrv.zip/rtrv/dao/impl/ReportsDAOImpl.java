package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.ReportsDAO;
import com.healogics.rtrv.dto.AWDFilterOptions;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.NPWTFilterOptions;
import com.healogics.rtrv.dto.NPWTReportReq;
import com.healogics.rtrv.dto.ViewReportsReq;
import com.healogics.rtrv.entity.NPWTReport;
import com.healogics.rtrv.entity.Reports;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.FilterRequestUtil;

@Repository
@TransactionManager1
public class ReportsDAOImpl implements ReportsDAO {

	private final Logger log = LoggerFactory.getLogger(ReportsDAOImpl.class);

	private final SessionFactory sessionFactory1;

	@Autowired
	public ReportsDAOImpl(@Qualifier("SessionFactory1")SessionFactory sessionFactory1) {
		this.sessionFactory1 = sessionFactory1;
	}

	@Override
	public Map<String, Object> viewReports(ViewReportsReq req, boolean isExcel)
			throws CustomException {
		Session session = this.sessionFactory1.getCurrentSession();
		List<Reports> reportsDetailsList = new ArrayList<>();

		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		log.debug("ViewReportsReq:   {}" , req);
		try {
			Date startDate = null;
			Date endDate = null;
			
			List<String> filters = FilterRequestUtil
					.getListFromDelimitedStr(req.getFilters());
			
			if (filters.contains("documentsFirstSent") && req.getDocsFirstSentStartDate() != null && req.getDocsFirstSentEndDate() != null
					&& !req.getDocsFirstSentStartDate().isEmpty()
					&& !req.getDocsFirstSentEndDate().isEmpty()) {
				startDate = dateFormat.parse(req.getDocsFirstSentStartDate());
				endDate = dateFormat.parse(req.getDocsFirstSentEndDate());
			} else {
				LocalDate currentDate = LocalDate.now();
				LocalDate startDateLocal = currentDate.minusYears(1);
				LocalDate endDateLocal = currentDate;
				
				startDate = Date.from(startDateLocal.atStartOfDay(ZoneId.systemDefault()).toInstant());
				endDate = Date.from(endDateLocal.atStartOfDay(ZoneId.systemDefault()).toInstant());
			}
			
			log.debug("DocsFirstSentStartDate startDate:   " + startDate);
			log.debug("DocsFirstSentEndDate endDate:   " +  endDate);
			
			
			String hql = "FROM Reports r WHERE 1 = 1 ";
			
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				log.debug("filters:   {}" , req.getFilters());
				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					hql += " AND ";
					switch (filterReq) {
					 case "insuranceType":
	                        List<String> insuranceTypeList = FilterRequestUtil.getListFromDelimitedStr(req.getInsuranceType());
	                        hql += " r.insuranceCategory IN :insuranceCategory ";
	                        parameters.put("insuranceCategory", insuranceTypeList);
	                        break;
	                    case "retrieveStatus":
	                        List<String> retrieveStatusList = FilterRequestUtil.getListFromDelimitedStr(req.getRetrieveStatus());
	                        hql += " r.status IN :status ";
	                        parameters.put("status", retrieveStatusList);
	                        break;
						
						case "filesSent" : {
							if(req.getNoOfFilesSent() != null && req.getNoOfFilesSent().equalsIgnoreCase("0")) {
							hql += " (r.noFilesSent < 1 OR r.noFilesSent IS NULL) ";
							} else {
								hql += " r.noFilesSent >= 1 ";
							}

						}
							break;
						
						case "bhcOrderReceivedDate" : {
							hql += " r.bhcOrderReceivedDate BETWEEN "
									+ " :bhcOrderReceivedStartDate AND :bhcOrderReceivedEndDate ";
							parameters.put("bhcOrderReceivedStartDate",
									dateFormat.parse(req
											.getBhcOrderReceivedStartDate()));
							parameters.put("bhcOrderReceivedEndDate", dateFormat
									.parse(req.getBhcOrderReceivedEndDate()));
						}
							break;
						case "bhcShipDate" : {
							hql += " r.bhcShipDate BETWEEN "
									+ " :bhcShipStartDate AND :bhcShipEndDate ";
							parameters.put("bhcShipStartDate", dateFormat
									.parse(req.getBhcShipStartDate()));
							parameters.put("bhcShipEndDate",
									dateFormat.parse(req.getBhcShipEndDate()));

						}
							break;
						case "documentsLastSent" : {
							hql += " r.docsLastSent BETWEEN "
									+ " :docsLastSentStartDate AND :docsLastSentEndDate ";
							parameters.put("docsLastSentStartDate", dateFormat
									.parse(req.getDocsLastSentStartDate()));
							parameters.put("docsLastSentEndDate", dateFormat
									.parse(req.getDocsLastSentEndDate()));

						}
							break;
						case "documentsFirstSent" : {
							hql += " r.docsFirstSent BETWEEN "
									+ " :docsFirstSentStartDate AND :docsFirstSentEndDate ";
							parameters.put("docsFirstSentStartDate", startDate);
							parameters.put("docsFirstSentEndDate", endDate);

						}
							break;
						
						default :
							break;
					}
				}
				
				// apply sorting here
				if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

					hql = sortList(req, hql);

				} else {
					hql += " order by r.bhcOrderReceivedDate asc";
				}
				
				log.debug("View Reports Filter query:   {}" , hql);
				
				if (isExcel) {
					// int count;
					reportsDetailsList = session.createQuery(hql)
							.setProperties(parameters).list();
					listCount.put("Count", reportsDetailsList.size());
					listCount.put("data", reportsDetailsList);
				} else {
					reportsDetailsList = session.createQuery(hql)
							.setProperties(parameters)
							.setFirstResult(req.getIndex())
							.setMaxResults(PAGE_SIZE).list();

					int count;
					List<Reports> allReportsDetailsList = session
							.createQuery(hql).setProperties(parameters)
							.setFirstResult(req.getIndex()).list();

					count = allReportsDetailsList.size() + req.getIndex();

					listCount.put("Count", count);
					listCount.put("data", reportsDetailsList);
					log.debug("Reports List Size:   {} " , count);
				}
			} else {
				hql += " AND r.noFilesSent >= 1 AND r.docsFirstSent BETWEEN "
						+ " :docsFirstSentStartDate AND :docsFirstSentEndDate ";
				parameters.put("docsFirstSentStartDate", startDate);
				parameters.put("docsFirstSentEndDate", endDate);
				
				// apply sorting here
				if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

					hql = sortList(req, hql);

				} else {
					hql += " order by r.bhcOrderReceivedDate asc";
				}
				
				if (isExcel) {
					// int count;
					reportsDetailsList = session.createQuery(hql).setProperties(parameters).list();
					listCount.put("Count", reportsDetailsList.size());
					listCount.put("data", reportsDetailsList);
				} else {
					int count;
					log.debug("View Reports without FIlter query:   {}" , hql);
					reportsDetailsList = session.createQuery(hql)
							.setProperties(parameters)
							.setFirstResult(req.getIndex())
							.setMaxResults(PAGE_SIZE).list();

					List<Reports> allReportsDetailsList = session
							.createQuery(hql)
							.setProperties(parameters)
							.setFirstResult(req.getIndex())
							.list();

					count = allReportsDetailsList.size() + req.getIndex();
					listCount.put("Count", count);
					listCount.put("data", reportsDetailsList);
					log.debug("reports List Size:    {}" , count);
				}
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching view reports details list:  {}"
							, e.getMessage());
			throw new CustomException(e.getMessage());
		}

		return listCount;
	}
	
	private String sortList(ViewReportsReq req, String hql) {
		String sortBy = "";
		if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
			sortBy = getFilterColumnName(req.getSortBy());
		}
		hql += " ORDER BY " + sortBy + "";	
		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	private String getFilterColumnName(String sortBy) {
		String column = "";
		switch (sortBy) {
		case "insuranceType":
			column = "insuranceCategory";
			break;
		case "retrieveStatus":
			column = "status";
			break;
		case "bhcShipDate":
			column = "bhcShipDate";
			break;
		case "docsFirstSent":
			column = "docsFirstSent";
			break;
		case "bhcOrderReceivedDate":
			column = "bhcOrderReceivedDate";
			break;
		case "docsLastSent":
			column = "docsLastSent";
			break;
		default:
			break;
		}
		return column;
	}

	@Override
	public AWDFilterOptions awdReportFilterOptions(ViewReportsReq req) throws CustomException {
		 Session session = this.sessionFactory1.getCurrentSession();
		    AWDFilterOptions filterOptions = new AWDFilterOptions();
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		    
		    try {
		        String query = " WHERE 1 = 1 ";
		        String filterColumn = req.getFilterOptions();

		        Map<String, Object> parameters = new HashMap<>();

		     // Set all filters in where clause
		        if (req.getFilters() != null && !req.getFilters().isEmpty()) {
		            log.debug("filters:   {}", req.getFilters());
		            List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

		            for (String filterReq : filterList) {
		                query += " AND ";

		                switch (filterReq) {
		                    case "insuranceType":
		                        List<String> insuranceTypeList = FilterRequestUtil.getListFromDelimitedStr(req.getInsuranceType());
		                        query += " r.insuranceCategory IN :insuranceCategory ";
		                        parameters.put("insuranceCategory", insuranceTypeList);
		                        break;
		                    case "retrieveStatus":
		                        List<String> retrieveStatusList = FilterRequestUtil.getListFromDelimitedStr(req.getRetrieveStatus());
		                        query += " r.status IN :status ";
		                        parameters.put("status", retrieveStatusList);
		                        break;
		                    case "filesSent":
		                        if (req.getNoOfFilesSent() != null && req.getNoOfFilesSent().equalsIgnoreCase("0")) {
		                            query += " (r.noFilesSent < 1 OR r.noFilesSent IS NULL) ";
		                        } else {
		                            query += " r.noFilesSent >= 1 ";
		                        }
		                        break;
		                    case "bhcOrderReceivedDate":
		                        query += " r.bhcOrderReceivedDate BETWEEN :bhcOrderReceivedStartDate AND :bhcOrderReceivedEndDate ";
		                        parameters.put("bhcOrderReceivedStartDate", dateFormat.parse(req.getBhcOrderReceivedStartDate()));
		                        parameters.put("bhcOrderReceivedEndDate", dateFormat.parse(req.getBhcOrderReceivedEndDate()));
		                        break;
		                    case "bhcShipDate":
		                        query += " r.bhcShipDate BETWEEN :bhcShipStartDate AND :bhcShipEndDate ";
		                        parameters.put("bhcShipStartDate", dateFormat.parse(req.getBhcShipStartDate()));
		                        parameters.put("bhcShipEndDate", dateFormat.parse(req.getBhcShipEndDate()));
		                        break;
		                    case "documentsLastSent":
		                        query += " r.docsLastSent BETWEEN :docsLastSentStartDate AND :docsLastSentEndDate ";
		                        parameters.put("docsLastSentStartDate", dateFormat.parse(req.getDocsLastSentStartDate()));
		                        parameters.put("docsLastSentEndDate", dateFormat.parse(req.getDocsLastSentEndDate()));
		                        break;
		                    case "documentsFirstSent":
		                        query += " r.docsFirstSent BETWEEN :docsFirstSentStartDate AND :docsFirstSentEndDate ";
		                        parameters.put("docsFirstSentStartDate", dateFormat.parse(req.getDocsFirstSentStartDate()));
		                        parameters.put("docsFirstSentEndDate", dateFormat.parse(req.getDocsFirstSentEndDate()));
		                        break;
		                    default:
		                        break;
		                }
		            }
		        }

		        log.debug("query :  {}", query);
		     
		        if (req.getFilterOptions().equalsIgnoreCase("insuranceType")) {
		            filterColumn = "insuranceCategory";
		        } else if (req.getFilterOptions().equalsIgnoreCase("retrieveStatus")) {
		            filterColumn = "status";
		        }

		        String hql = "SELECT DISTINCT " + filterColumn + " FROM Reports r" + query + " ORDER BY " + filterColumn + " asc";
		        
		        
		        List<String> distinctValues = session.createQuery(hql)
		                .setProperties(parameters).getResultList();
		        filterOptions.setFilterOptions(distinctValues);
		        filterOptions.getFilterOptions().removeIf(element -> element == null || (element != null && element.isEmpty()));

		    } catch (Exception e) {
		        log.error("Exception occurred while fetching filter options : {}", e.getMessage());
		        e.printStackTrace();
		        throw new CustomException(e.getMessage());
		    }
		    return filterOptions;
		
			
	}

}

