package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.entity.UserNotification;
import com.healogics.rtrv.exception.CustomException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.SystemNotificationDAO;
import com.healogics.rtrv.dto.SystemNotificationListReq;
import com.healogics.rtrv.dto.SystemNotificationWSAReq;
import com.healogics.rtrv.dto.UserNotificationReq;
import com.healogics.rtrv.entity.SystemNotification;

@Repository
@TransactionManager1
public class SystemNotificationDAOImpl implements SystemNotificationDAO {

	private final Logger log = LoggerFactory
			.getLogger(SystemNotificationDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public SystemNotificationDAOImpl(@Qualifier("SessionFactory1")SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public String saveSystemNotifications(
			SystemNotificationWSAReq systemNotificationReq) throws CustomException {
		String notificationId = null;
		try {
			Session session = this.sessionFactory.getCurrentSession();

			SimpleDateFormat timeFormat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			Date parsedEndDate = timeFormat
					.parse(systemNotificationReq.getEndTime());
			Date parsedStartDate = timeFormat
					.parse(systemNotificationReq.getStartTime());

			Timestamp endTimestamp = new Timestamp(parsedEndDate.getTime());
			Timestamp startTimestamp = new Timestamp(parsedStartDate.getTime());
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			notificationId = systemNotificationReq.getNotificationId();
			if (notificationId == null || notificationId.isEmpty()) {
				//for (String lines : systemNotificationReq.getServiceLine()) {
					SystemNotification systemNotification = new SystemNotification();
					notificationId = UUID.randomUUID().toString();
					systemNotification.setNotificationId(notificationId);
					String attachments = null;
					try {
						attachments = new ObjectMapper()
								.writeValueAsString(systemNotificationReq.getServiceLine());
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:   {}", e);
					}
					systemNotification.setServiceLine(attachments);
					systemNotification.setCreatedTimestamp(currentTime);
					systemNotification.setCreatedUserFullname(
							systemNotificationReq.getCreatedUserFullname());
					systemNotification.setCreatedUsername(
							systemNotificationReq.getCreatedUsername());
					systemNotification.setDescription(
							systemNotificationReq.getDescription());
					systemNotification.setEndDate(dateFormat
							.parse(systemNotificationReq.getEndDate()));
					systemNotification.setEndTimestamp(endTimestamp);
					systemNotification
							.setHyperlink(systemNotificationReq.getHyperlink());
					systemNotification.setLastUpdatedTimestamp(currentTime);
					systemNotification.setLastUpdatedUserFullname(
							systemNotificationReq.getLastUpdatedUserFullname());
					systemNotification.setLastUpdatedUsername(
							systemNotificationReq.getLastUpdatedUsername());

					Boolean status = systemNotificationReq
							.isNotificationStatus();
					if (status == true) {
						if (!currentTime.before(startTimestamp)
								|| !currentTime.after(endTimestamp)) {
							status = true;
						} else {
							status = false;
						}
					}

					systemNotification.setNotificationStatus(status);
					systemNotification.setStartDate(dateFormat
							.parse(systemNotificationReq.getStartDate()));
					systemNotification.setStartTimestamp(startTimestamp);
					systemNotification
							.setTitle(systemNotificationReq.getTitle());

					session.save(systemNotification);
			//	}

			} else {
				if (systemNotificationReq.isNotificationStatus() == true) {
					Boolean status = systemNotificationReq
							.isNotificationStatus();
					if (!currentTime.before(startTimestamp)
							|| !currentTime.after(endTimestamp)) {
						status = true;
					} else {
						status = false;
					}
					log.debug("currentTime:   {}" , currentTime);
					log.debug("startTimestamp:   {}" , startTimestamp);
					log.debug("endTimestamp:   {}" , startTimestamp);
					log.debug("status:   {}" , status);
					
					String attachments = null;
					try {
						attachments = new ObjectMapper()
								.writeValueAsString(systemNotificationReq.getServiceLine());
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:   {}", e);
					}
					
				//	for (String lines : systemNotificationReq.getServiceLine()) {
						String hql = "UPDATE SystemNotification SET serviceLine = :serviceLine, "
								+ " description = :description,"
								+ " endDate = :endDate, "
								+ " startDate = :startDate, "
								+ " startTimestamp = :startTimestamp, "
								+ " endTimestamp = :endTimestamp,"
								+ " hyperlink = :hyperlink, "
								+ " lastUpdatedUsername = :lastUpdatedUsername, "
								+ " lastUpdatedTimestamp = :lastUpdatedTimestamp, "
								+ " title = :title, "
								+ " lastUpdatedUserFullname = :lastUpdatedUserFullname, "
								+ " notificationStatus = :notificationStatus "
								+ " WHERE notificationId = :notificationId";

						session.createQuery(hql)
								.setParameter("serviceLine", attachments)
								.setParameter("description",
										systemNotificationReq.getDescription())
								.setParameter("endDate",
										dateFormat.parse(systemNotificationReq
												.getEndDate()))
								.setParameter("startDate",
										dateFormat.parse(systemNotificationReq
												.getStartDate()))
								.setParameter("startTimestamp", startTimestamp)
								.setParameter("endTimestamp", endTimestamp)
								.setParameter("hyperlink",
										systemNotificationReq.getHyperlink())
								.setParameter("lastUpdatedUsername",
										systemNotificationReq
												.getLastUpdatedUsername())
								.setParameter("lastUpdatedTimestamp",
										currentTime)
								.setParameter("title",
										systemNotificationReq.getTitle())
								.setParameter("lastUpdatedUserFullname",
										systemNotificationReq
												.getLastUpdatedUserFullname())
								.setParameter("notificationStatus", status)
								.setParameter("notificationId",
										systemNotificationReq
												.getNotificationId())
								.executeUpdate();
					//}

				} else {
					String hql = "UPDATE SystemNotification SET "
							+ " lastUpdatedUsername = :lastUpdatedUsername, "
							+ " lastUpdatedTimestamp = :lastUpdatedTimestamp, "
							+ " lastUpdatedUserFullname = :lastUpdatedUserFullname, "
							+ " notificationStatus = :notificationStatus "
							+ " WHERE notificationId = :notificationId ";
					session.createQuery(hql)
							.setParameter("lastUpdatedUsername",
									systemNotificationReq
											.getLastUpdatedUsername())
							.setParameter("lastUpdatedTimestamp", currentTime)
							.setParameter("lastUpdatedUserFullname",
									systemNotificationReq
											.getLastUpdatedUserFullname())
							.setParameter("notificationStatus",
									systemNotificationReq
											.isNotificationStatus())
							.setParameter("notificationId",
									systemNotificationReq.getNotificationId())
							.executeUpdate();
				}
			}

		} catch (Exception e) {
			log.error("Exception occured while saving system notifications:   {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return notificationId;
	}

	@Override
	public List<SystemNotification> getSystemNotifications(
			SystemNotificationListReq req) throws CustomException {
		List<SystemNotification> systemNotification = new ArrayList<>();
		List<SystemNotification> systemFinalNotification = new ArrayList<>();
		try {
			Session session = this.sessionFactory.getCurrentSession();
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
		//	String serviceLineHql = "FROM SystemNotification n WHERE n.serviceLine = :serviceLine "
			String serviceLineHql = "FROM SystemNotification n WHERE JSON_CONTAINS(serviceLine, :serviceLine,'$') =1 "
					+ " AND n.startTimestamp <= :currentTime "
					+ " AND n.endTimestamp >= :currentTime "
					+ " AND n.notificationStatus = :status ";

			log.debug("currentTime:   {}" , currentTime);
			systemNotification = session.createQuery(serviceLineHql)
					.setParameter("serviceLine", "\""+req.getServiceLine()+"\"")
					.setParameter("currentTime", currentTime)
					.setParameter("status", true).list();
			log.debug("systemNotification:   {}" , systemNotification.toString());
			if (systemNotification != null) {

				for (SystemNotification notification : systemNotification) {
					String userHql = "FROM UserNotification n WHERE n.notificationId = :notificationId "
							+ " AND n.userId = :userId "
							+ " AND n.isDismissed = :isDismissed ";

					UserNotification userNoti = session
							.createQuery(userHql, UserNotification.class)
							.setParameter("notificationId",
									notification.getNotificationId())
							.setParameter("userId",
									Integer.parseInt(req.getUserId()))
							.setParameter("isDismissed", true).setMaxResults(1)
							.uniqueResult();
					log.debug("userNoti:   {}" , userNoti);
					if (userNoti == null) {
						systemFinalNotification.add(notification);
					}

				}
				log.debug("systemNotification after user selection:   {}"
						, systemFinalNotification.toString());
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching system notifications: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}

		return systemFinalNotification;
	}

	@Override
	public void updateNotifications(SystemNotificationWSAReq systemWSAReq)
			throws CustomException {

	}
	
	@Override
	public void deleteNotifications(List<String> notificationIdList) throws CustomException {
		try {
			Session session = this.sessionFactory.getCurrentSession();
			
			for (String notificationId : notificationIdList) {
				String deleteHql = "DELETE from SystemNotification "
						+ " WHERE notificationId = :notificationId ";
		
				session.createQuery(deleteHql)
						.setParameter("notificationId",
								notificationId)
						.executeUpdate();
			}
		} catch (Exception e) {
			log.error("Exception occured while deleting system notifications:  {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	@Override
	public void saveUserNotifications(UserNotificationReq userNotificationReq)
			throws CustomException {
		try {
			Session session = this.sessionFactory.getCurrentSession();
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			List<UUID> notificationUUID = new ArrayList<>();

			for (String uuid : userNotificationReq.getNotificationId()) {
				notificationUUID.add(UUID.fromString(uuid));
			}

			for (UUID notId : notificationUUID) {
				UserNotification userNotification = new UserNotification();
				userNotification.setNotificationId(notId.toString());
				userNotification.setUserId(
						Integer.parseInt(userNotificationReq.getUserId()));
				userNotification.setLastUpdatedUserFullname(
						userNotificationReq.getLastUpdatedUserFullname());
				userNotification.setLastUpdatedTimestamp(currentTime);
				userNotification.setIsDismissed(true);
				userNotification.setLastUpdatedUsername(
						userNotificationReq.getLastUpdatedUsername());

				session.save(userNotification);
			}
			log.debug("User Notification saved successfully:    ");

		} catch (Exception e) {
			log.error("Exception occured while saving user notifications:   {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

}
