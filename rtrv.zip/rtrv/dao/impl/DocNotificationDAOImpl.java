package com.healogics.rtrv.dao.impl;

import java.time.LocalDateTime;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.DocNotificationDAO;
import com.healogics.rtrv.dto.DocumentNotificationReq;

@Repository
@TransactionManager1
public class DocNotificationDAOImpl implements DocNotificationDAO {
	private final Logger log = LoggerFactory.getLogger(DocNotificationDAOImpl.class);
	
	private final SessionFactory sessionFactory;

	@Autowired
	public DocNotificationDAOImpl(@Qualifier("SessionFactory1") SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public boolean saveDocNotification(DocumentNotificationReq req) {
		Session session = this.sessionFactory.getCurrentSession();
		boolean status = false;
		try {
			
			log.info("Saving document status in db..");
			
			//Need to fetch record based on clientstate
			String hql = "UPDATE DocumentStatus r SET r.docNotificationStatus=:docNotificationStatus,"
					+ " r.lastUpdatedTimestamp = :lastUpdatedTimestamp,"
					+ " r.lastUpdatedUsername = :lastUpdatedUsername,"
					+ " r.lastUpdatedUserId = :lastUpdatedUserId,"
					+ " r.docNotificationTimestamp = :docNotificationTimestamp"
					+ " where r.clientState = :clientState";
			
			Query query = session.createQuery(hql);
			
			query.setParameter("docNotificationStatus", "Success");
			query.setParameter("lastUpdatedTimestamp",
					LocalDateTime.now());
			query.setParameter("lastUpdatedUsername", "DocNotification Service");
			query.setParameter("lastUpdatedUserId", 0L);
			query.setParameter("docNotificationTimestamp",
					LocalDateTime.now());
			
			query.setParameter("clientState", req.getClientState());
			
			query.executeUpdate();
			
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
		}
		
		return status;
	}
}
