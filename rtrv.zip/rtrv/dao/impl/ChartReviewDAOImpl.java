package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORMESSAGE;
import static com.healogics.rtrv.constants.DAOConstants.NOTES_SIZE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.bo.AppNotificationBO;
import com.healogics.rtrv.bo.Impl.DocumentService;
import com.healogics.rtrv.bo.Impl.PDFService;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.ChartReviewDAO;
import com.healogics.rtrv.dao.HistoryStatusDAO;
import com.healogics.rtrv.dto.AttachmentDetails;
import com.healogics.rtrv.dto.ChartReviewDetails;
import com.healogics.rtrv.dto.ChartReviewInvoiceList;
import com.healogics.rtrv.dto.ChartReviewReq;
import com.healogics.rtrv.dto.DocServiceReq;
import com.healogics.rtrv.dto.FileUploadReq;
import com.healogics.rtrv.dto.IHealCustomScanUploadRes;
import com.healogics.rtrv.dto.IHealDocument;
import com.healogics.rtrv.dto.IHealFileGetRes;
import com.healogics.rtrv.dto.IHealPatientSearchReq;
import com.healogics.rtrv.dto.IHealPatientSearchRes;
import com.healogics.rtrv.dto.ManualAttachment;
import com.healogics.rtrv.dto.ModifyRecordReq;
import com.healogics.rtrv.dto.PatientSearchReq;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.SubmitRequest;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.entity.AWDDashboard;
import com.healogics.rtrv.entity.BHCNotes;
import com.healogics.rtrv.entity.DocumentNotificationStatus;
import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.entity.DocumentationHistory;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.entity.PatientMedicalRecords;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.entity.UserNotes;
import com.healogics.rtrv.enumeration.DocumentationViewName;
import com.healogics.rtrv.enumeration.JobSavePdfFileName;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;

@Repository
@TransactionManager1
public class ChartReviewDAOImpl implements ChartReviewDAO {

	private final Logger log = LoggerFactory
			.getLogger(ChartReviewDAOImpl.class);

	private final Environment env;
	private final RestTemplate restTemplate;
	private final SessionFactory sessionFactory;
	private final DocumentService docService;
	private final AppNotificationBO appNotificationBO;
	private final PDFService pdfService;
    private final HistoryStatusDAO historyStatusDAO;
	
	@Autowired
	public ChartReviewDAOImpl(Environment env, @Qualifier("httpTemplate1") RestTemplate restTemplate,
			@Qualifier("SessionFactory1") SessionFactory sessionFactory,
			DocumentService docService,
			AppNotificationBO appNotificationBO, PDFService pdfService, HistoryStatusDAO historyStatusDAO) {
		this.env = env;
		this.restTemplate = restTemplate;
		this.sessionFactory = sessionFactory;
		this.docService = docService;
		this.appNotificationBO = appNotificationBO;
		this.pdfService = pdfService;
		this.historyStatusDAO = historyStatusDAO;
	}

	private Map<String, Long> counters = new HashMap<>();
	
	private static AtomicBoolean notificationSent = new AtomicBoolean(false);
	
	public static AtomicBoolean getNotificationSend() {
		return notificationSent;
	}

	@Override
	public ChartReviewDetails getchartDetails(ChartReviewReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		ChartReviewDetails chartReviewDetails = new ChartReviewDetails();
		try {
			String awdHql = "FROM AWDDashboard a WHERE a.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND a.bhcInvoiceOrderId = :bhcInvoiceOrderId";

			AWDDashboard awdData = session
					.createQuery(awdHql, AWDDashboard.class)
					.setParameter("bhcMedicalRecordId",
							Integer.parseInt(req.getMedRecId()))
					.setParameter("bhcInvoiceOrderId",
							Integer.parseInt(req.getBhcInvoiceOrderId()))
					.setMaxResults(1).uniqueResult();

			log.debug("awdDashboard:  {}" , awdData);

			if (awdData != null) {
				chartReviewDetails.setBbc(awdData.getBbc());
				chartReviewDetails
						.setBhcInvoiceOrderNo(awdData.getBhcInvoiceOrderId());
				String facilityHql = "FROM FacilityDetails WHERE bluebookId = :bbc "
						+ " AND active = :active ";
				FacilityDetails facilityDetails = session
						.createQuery(facilityHql, FacilityDetails.class)
						.setParameter("bbc", awdData.getBbc())
						.setParameter("active", 1)
						.uniqueResult();

				if (facilityDetails != null) {
					chartReviewDetails
							.setFacilityId(facilityDetails.getFacilityId());
					chartReviewDetails.setMarket(facilityDetails.getMarket());
					chartReviewDetails
							.setDivision(facilityDetails.getDivision());
					chartReviewDetails
							.setTerritory(facilityDetails.getTerritory());
					chartReviewDetails.setFacilityPhone(
							facilityDetails.getCenterPhone() + "");
					chartReviewDetails.setFacilityFax(
							facilityDetails.getCenterFax() + "");
				}

				if (awdData.getBbc() != null && !awdData.getBbc().isEmpty()) {
					RetrieveMembers rtrvMember = getTeamMemberByBBC(
							awdData.getBbc());

					if (rtrvMember != null) {
						chartReviewDetails.setAwdDocSpecialist(
								rtrvMember.getAwdDocSpecialist());
						chartReviewDetails
								.setAwdDocClerk(rtrvMember.getAwdDocClerk());
						chartReviewDetails.setOpsSpecialist(rtrvMember.getOperationsSpecialist());
					}
				}

				chartReviewDetails
						.setBhcMedRecId(awdData.getBhcMedicalRecordId());
				chartReviewDetails.setFacilityName(awdData.getFacilityName());
				chartReviewDetails.setiHealConfiguration(awdData.getFacilityType());
				chartReviewDetails.setiHealConfiguration(
						(awdData.getFacilityType() != null) ? awdData.getFacilityType() : "-");
				
				chartReviewDetails.setBhcReferralId(awdData.getBhcReferralId());
				chartReviewDetails
						.setBhcOrderSource(awdData.getBhcOrderSource());
				chartReviewDetails.setBhcOrderReceivedDate(
						awdData.getBhcOrderReceivedDate());
				chartReviewDetails.setPatientName(awdData.getPatientLastName()
						+ ", " + awdData.getPatientFirstName());

				chartReviewDetails
						.setPatientFirstName(awdData.getPatientFirstName());
				chartReviewDetails
						.setPatientLastName(awdData.getPatientLastName());

				chartReviewDetails.setPatientDOB(awdData.getPatientDOB());
				chartReviewDetails
						.setHealogicsPatientId(awdData.getHealogicsPatientId());
				chartReviewDetails.setHealogicsPatientMRN(
						awdData.getHealogicsPatientMRN());
				chartReviewDetails
						.setBhcPatientAcctId(awdData.getBhcPatientAcctId());
				chartReviewDetails
						.setInsuranceCategory(awdData.getBhcPrimaryInsurance());
				chartReviewDetails.setPrimaryInsurance(
						awdData.getBhcPrimaryInsuranceReceived());
				chartReviewDetails.setProviderName(awdData.getProviderLastName()
						+ ", " + awdData.getProviderFirstName());

				String invoiceHql = "SELECT a.bhcInvoiceOrderId, a.invoiceBalanceDue FROM AWDDashboard a "
						+ " WHERE a.bhcMedicalRecordId = :bhcMedicalRecordId "
						+ " ORDER BY a.bhcInvoiceOrderId DESC";

				List<Object[]> invoiceOrderIds = session
						.createQuery(invoiceHql, Object[].class)
						.setParameter("bhcMedicalRecordId",
								Integer.parseInt(req.getMedRecId()))
						.getResultList();

				List<ChartReviewInvoiceList> invoiceList = new ArrayList<>();
				ChartReviewInvoiceList invoice = null;

				for (Object[] result : invoiceOrderIds) {

					invoice = new ChartReviewInvoiceList();

					invoice.setBhcInvoiceOrderId((int) result[0]);

					String invoiceAmount = "";

					if (result[1] == null) {
						invoiceAmount = "$0.00";
					} else {
						String invoiceStr = (String) result[1];

						if (invoiceStr.contains("-")) {
							// Negative value
							log.info("Received invoiceStr  : {}" , invoiceStr);
							invoiceStr = invoiceStr.replace("-", "");

							invoiceAmount = "($" + invoiceStr + ")";
							log.info("invoiceAmount after conversion  : {}"
									, invoiceStr);
						} else {
							invoiceAmount = "$" + invoiceStr;
						}
					}

					invoice.setAmount(invoiceAmount);

					invoiceList.add(invoice);
				}

				chartReviewDetails.setBhcInvoiceOrderId(invoiceList);
				chartReviewDetails.setAssignedTo(awdData.getAssigneeFullName());
				chartReviewDetails.setAssignedToUsername(awdData.getAssignee());
				chartReviewDetails.setStatus(awdData.getStatus());
				chartReviewDetails.setVendor("Byram");
				chartReviewDetails.setAge(awdData.getAge());
				chartReviewDetails
						.setLastUpdatedDate(awdData.getLastUpdatedDate());
				chartReviewDetails.setBhcMedicalRecAddedDate(
						awdData.getMedicalRecordAddedDate());

				chartReviewDetails
						.setDocTeamAnalyst(awdData.getAssigneeFullName());
				chartReviewDetails.setDocTeamClerk(awdData.getDocTeamClerk());
				chartReviewDetails.setWqOrderId(awdData.getHealogicsOrderId());
				chartReviewDetails.setBhcShipDate(awdData.getBhcShipDate());
				chartReviewDetails.setFirstReceived(awdData.getFirstReceived());
				chartReviewDetails.setLastUpdated(awdData.getLastUpdatedDate());
				chartReviewDetails.setLastReceived(awdData.getLastReceived());
				chartReviewDetails
						.setLastFileUploaded(awdData.getLastFileUploaded());
				chartReviewDetails.setFilesSent(awdData.getFilesSent());
				chartReviewDetails.setNoOfUpdates(awdData.getNoOfUpdates());
				chartReviewDetails.setFollowupDate(awdData.getFollowupDate());
				chartReviewDetails.setLastActioned(awdData.getLastActioned());
				chartReviewDetails
						.setBhcDocumentType(awdData.getBhcDocumentType());
				chartReviewDetails
						.setBhcDocumentStatus(awdData.getBhcDocumentStatus());
				chartReviewDetails
						.setBhcMissingDocType(awdData.getBhcMissingDocType());
				chartReviewDetails
						.setBhcMissingDocuments(awdData.getBhcMissingDoc());
				chartReviewDetails
						.setBhcMissingDocNotes(awdData.getBhcMissingDocNotes());

				chartReviewDetails
						.setAddendumReceived(awdData.getAddendumReceived());
				chartReviewDetails.setReceivedRx(awdData.getRxReceived());
				chartReviewDetails
						.setPatientNotSeen30Days(awdData.getPatientNotSeen30());

				// Addendum & Record Modification
				chartReviewDetails.setAddendum(awdData.getAddendum());
				chartReviewDetails
						.setAddendumAddedByUserId(awdData.getAddendumUserId());
				chartReviewDetails.setAddendumAddedByUserName(
						awdData.getAddendumUsername());
				chartReviewDetails.setAddendumAddedByUserFullName(
						awdData.getAddendumUserFullname());
// n
				// Record Modification
				chartReviewDetails.setRecordModify(awdData.getRecordModify());
				chartReviewDetails.setRecordModifedByUserId(
						awdData.getRecordModifyUserId());
				chartReviewDetails.setRecordModifiedByUserName(
						awdData.getRecordModifyUsername());
				chartReviewDetails.setRecordModifiedByUserFullName(
						awdData.getRecordModifyUserFullname());

				if (awdData.getAttachments() != null) {
					List<IHealDocument> newList = new ArrayList<>();
					List<IHealDocument> finalList = new ArrayList<>();
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						newList = objectMapper.readValue(
								awdData.getAttachments(),
								new TypeReference<List<IHealDocument>>() {
								});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}" , e);
					}

					for (IHealDocument doc : newList) {
						DocumentStatus status = new DocumentStatus();

						String hql = "FROM DocumentStatus d WHERE d.documentationHistoryNoteId = :documentationHistoryNoteId";

						status = session.createQuery(hql, DocumentStatus.class)
								.setParameter("documentationHistoryNoteId",
										doc.getDocumentStatusId())
								.setMaxResults(1).uniqueResult();
						if (status != null) {
							doc.setDocumentStatus(status.getDocUploadStatus());
						}
						if (!doc.getDocEntityId().equalsIgnoreCase("0")) {
							finalList.add(doc);
						}
					}

					chartReviewDetails.setiHealAttachments(finalList);
				} else {
					chartReviewDetails.setiHealAttachments(
							new ArrayList<>());
				}

			}

			log.debug("medRecId:  {}" , req.getMedRecId());
			log.debug("bhcInvoiceOrderId:   {}", req.getBhcInvoiceOrderId());

			String hql = "FROM PatientMedicalRecords pmr WHERE pmr.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ "AND pmr.bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";
			List<AttachmentDetails> manualAttachmentList = new ArrayList<>();
			List<AttachmentDetails> docReceivedFromByramList = new ArrayList<>();

			List<PatientMedicalRecords> manualAttachment = session
					.createQuery(hql)
					.setParameter("bhcMedicalRecordId",
							Integer.parseInt(req.getMedRecId()))
					.setParameter("bhcInvoiceOrderNo",
							Integer.parseInt(req.getBhcInvoiceOrderId()))
					.list();

			if (manualAttachment != null) {

				for (PatientMedicalRecords requestAttach : manualAttachment) {

					AttachmentDetails manualAttach = new AttachmentDetails();
					manualAttach.setDocEntityId(requestAttach.getDocumentId());
					manualAttach.setDocName(requestAttach.getDocumentName());
					manualAttach.setGroupName(requestAttach.getDocumentType());
					String[] forTime = requestAttach.getLastUpdatedTimestamp()
							.toString().split(" ");
					manualAttach.setAddedDate(forTime[0]);
					manualAttach.setTestDesc(requestAttach.getDocumentName());
					manualAttach.setIsSubmitted(requestAttach.getIsSubmitted());

					if (requestAttach.getDocumentType()
							.equalsIgnoreCase("MED_REC")
							|| requestAttach.getDocumentType()
									.equalsIgnoreCase("RX")) {
						manualAttach.setManually(false);
						docReceivedFromByramList.add(manualAttach);
					} else {
						manualAttach.setManually(true);
						manualAttachmentList.add(manualAttach);
					}

					DocumentStatus status = new DocumentStatus();

					String docHql = "FROM DocumentStatus d WHERE d.documentationHistoryNoteId = :documentationHistoryNoteId";

					status = session.createQuery(docHql, DocumentStatus.class)
							.setParameter("documentationHistoryNoteId",
									requestAttach
											.getDocumentationHistoryNoteId())
							.setMaxResults(1).uniqueResult();
					if (status != null) {
						manualAttach
								.setDocumentStatus(status.getDocUploadStatus());
					}

				}
				chartReviewDetails.setManualAttachments(manualAttachmentList);
				chartReviewDetails
						.setDocReceivedFromByram(docReceivedFromByramList);
			}

			String byramHql = "FROM BHCNotes b WHERE b.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ "AND b.bhcInvoiceOrderId = :bhcInvoiceOrderId";

			BHCNotes byramNotesData = session
					.createQuery(byramHql, BHCNotes.class)
					.setParameter("bhcMedicalRecordId",
							Long.valueOf(req.getMedRecId()))
					.setParameter("bhcInvoiceOrderId",
							Long.valueOf(req.getBhcInvoiceOrderId()))
					.setMaxResults(1).uniqueResult();

			if (byramNotesData != null && byramNotesData.getNoteId() != null
					&& byramNotesData.getBhcMedicalRecordId() != null) {
				chartReviewDetails.setNoteId(byramNotesData.getNoteId());
				chartReviewDetails
						.setBhcDocumentType(awdData.getBhcDocumentType());
				chartReviewDetails.setBhcDocumentStatus(
						byramNotesData.getBhcDocumentStatus());
				chartReviewDetails.setBhcMissingDocType(
						byramNotesData.getBhcMissingDocType());
				chartReviewDetails.setBhcMissingDocuments(
						byramNotesData.getBhcMissingDocuments());
				chartReviewDetails.setBhcMissingDocNotes(
						byramNotesData.getBhcMissingDocNotes());

				// Need to discuss with Praveen
				/*
				 * chartReviewDetails.setAddendumReceived(
				 * byramNotesData.getAddendumReceived()); chartReviewDetails
				 * .setReceivedRx(byramNotesData.getReceivedRx());
				 * chartReviewDetails.setPatientNotSeen30Days(
				 * byramNotesData.getPatientNotSeen30Days());
				 */
			}
			log.debug("Chart Review Details:    {}" , chartReviewDetails);

		} catch (Exception e) {
			log.error("Exception occured while fetching all records:  {}"
					,e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return chartReviewDetails;
	}

	@Override
	public RetrieveMembers getTeamMemberByBBC(String bbc) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		RetrieveMembers retrieveMember = null;
		try {
			String hql = "FROM RetrieveMembers where bluebookCode = :bluebookCode"
					+ " AND active = 1";
			log.debug("rtrvHQL: {}",hql);
			retrieveMember = session.createQuery(hql, RetrieveMembers.class)
					.setParameter("bluebookCode", bbc).uniqueResult();
			log.debug("Retrieve Member: {}",retrieveMember.toString());
			
		} catch (Exception e) {
			log.error("Exception occured in getTeamMemberByBBC : {}"
					, e.getMessage());
			//throw new CustomException(e.getMessage());
		}
		return retrieveMember;
	}

	@Override
	public void saveRequest(SaveRequest saveReq) {
		Session session = this.sessionFactory.getCurrentSession();
		try {

			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			String attachments = null;
			try {
				attachments = new ObjectMapper()
						.writeValueAsString(saveReq.getiHealAttachments());
			} catch (JsonProcessingException e) {
				log.error("Json Procession exception:   {}", e);
			}

			if (saveReq.getAssigneeChanged() == 1) {
				String assignedToHql = "UPDATE AWDDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
						+ " lastUpdatedUserFullName = :lastUpdatedUserFullName,"
						+ " lastUpdatedUserName = :lastUpdatedUsername, "
						+ " lastUpdatedDateTime = :lastUpdatedDateTime, "
						+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname,"
						+ " lastTeamUpdated = :lastTeamUpdated,"
						+ " assignee = :assignee, "
						+ " assigneeFullName = :assigneeFullName, "
						+ " reassignedTo = :reassignedTo, "
						+ " lastActioned = :lastActioned, "
						+ " attachments = :attachments "
						+ " WHERE bhcMedicalRecordId = :medRecId AND"
						+ " bhcInvoiceOrderId = :bhcInvoiceId ";

				// Saving details
				 session.createQuery(assignedToHql)
						.setParameter("lastUpdatedUserId",
								Long.valueOf(saveReq.getLastUpdatedUserId()))
						.setParameter("lastUpdatedUserFullName",
								saveReq.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername",
								saveReq.getLastUpdatedUserName())
						.setParameter("lastTeamUpdatedUserFullname",
								saveReq.getLastUpdatedUserFullName())
						.setParameter("lastTeamUpdated", currentTime)
						.setParameter("lastActioned", currentTime)
						.setParameter("lastUpdatedDateTime", currentTime)
						.setParameter("assignee", saveReq.getAssigneeUserName())
						.setParameter("assigneeFullName",
								saveReq.getAssigneeFullName())
						.setParameter("reassignedTo",
								saveReq.getAssigneeChanged())
						.setParameter("attachments", attachments)
						.setParameter("medRecId",
								saveReq.getBhcMedicalRecordId())
						.setParameter("bhcInvoiceId",
								saveReq.getBhcInvoiceOrderId())
						.executeUpdate();
				 
				 //saving notifications
				 appNotificationBO
						.saveAssignedNotifications(saveReq);

			} else {
				String hql = "UPDATE AWDDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
						+ " lastUpdatedUserFullName = :lastUpdatedUserFullName,"
						+ " lastUpdatedUserName = :lastUpdatedUsername, "
						+ " lastUpdatedDateTime = :lastUpdatedDateTime, "
						+ " assignee = :assignee, "
						+ " assigneeFullName = :assigneeFullName, "
						+ " lastActioned = :lastActioned, "
						+ " attachments = :attachments "
						+ " WHERE bhcMedicalRecordId = :medRecId AND"
						+ " bhcInvoiceOrderId = :bhcInvoiceId ";

				// Saving details
				 session.createQuery(hql)
						.setParameter("lastUpdatedUserId",
								Long.valueOf(saveReq.getLastUpdatedUserId()))
						.setParameter("lastUpdatedUserFullName",
								saveReq.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername",
								saveReq.getLastUpdatedUserName())
						.setParameter("lastActioned", currentTime)
						.setParameter("lastUpdatedDateTime", currentTime)
						.setParameter("assignee", saveReq.getAssigneeUserName())
						.setParameter("assigneeFullName",
								saveReq.getAssigneeFullName())
						.setParameter("attachments", attachments)
						.setParameter("medRecId",
								saveReq.getBhcMedicalRecordId())
						.setParameter("bhcInvoiceId",
								saveReq.getBhcInvoiceOrderId())
						.executeUpdate();
			}

			// Saving Manual attachments
			if (saveReq.getManualAttachments() != null
					&& !saveReq.getManualAttachments().isEmpty()) {

				for (ManualAttachment attach : saveReq.getManualAttachments()) {
					session = this.sessionFactory.getCurrentSession();

					log.debug("attach.isNewFile() : {}", attach.isNewFile());
					log.debug("attach.isDeleted() : {}", attach.isDeleted());

					if (attach.isNewFile()) {
						log.debug("isNewFile..:");

						PatientMedicalRecords pmr = new PatientMedicalRecords();
						pmr.setDocumentId(UUID.randomUUID().toString());
						pmr.setBhcMedicalRecordId(
								saveReq.getBhcMedicalRecordId());
						pmr.setBhcInvoiceOrderNo(
								saveReq.getBhcInvoiceOrderId());

						pmr.setDocumentName(attach.getDocumentName());
						pmr.setDocumentContent(attach.getDocumentContent());
						pmr.setDocumentType(attach.getDocumentType());
						pmr.setLastUpdatedTimestamp(currentTime);
						pmr.setLastUpdatedUserFullname(
								saveReq.getLastUpdatedUserFullName());
						pmr.setLastUpdatedUserId(
								Long.valueOf(saveReq.getLastUpdatedUserId()));
						pmr.setLastUpdatedUsername(
								saveReq.getLastUpdatedUserName());
						
						if(attach.getDocumentType().equalsIgnoreCase("Medical Record Request")) {
							pmr.setIsSubmitted(1);
						} else {
							pmr.setIsSubmitted(0);
						}

						log.debug("pmr: {}", pmr);

						session.save(pmr);

					} else if (attach.isDeleted()) {
						// remove file from db

						String deleteHql = "DELETE from PatientMedicalRecords "
								+ " WHERE bhcMedicalRecordId = :medRecId AND"
								+ " bhcInvoiceOrderNo = :bhcInvoiceId AND"
								+ " documentId = :documentId";

						session.createQuery(deleteHql)
								.setParameter("medRecId",
										saveReq.getBhcMedicalRecordId())
								.setParameter("bhcInvoiceId",
										saveReq.getBhcInvoiceOrderId())
								.setParameter("documentId",
										attach.getDocumentId())
								.executeUpdate();
					}
				}
			}

			String rowNoteIdHQL = "SELECT MAX(noteId) from DocumentationHistory ";

			Integer id = (Integer) session.createQuery(rowNoteIdHQL)
					.uniqueResult();
			id = id + 1;

			// Updating Documentation History Table
			if (saveReq.getAssigneeChanged() == 1) {
				log.debug("updating documentation history table.............");

				String documentId = UUID.randomUUID().toString();

				String bhcHql = "SELECT a.status, a.bhcDocumentStatus "
						+ " FROM AWDDashboard a "
						+ " WHERE a.bhcMedicalRecordId = :bhcMedicalRecordId "
						+ " AND a.bhcInvoiceOrderId = :bhcInvoiceOrderId";

				List<Object[]> medRecInvIds = session
						.createQuery(bhcHql, Object[].class)
						.setParameter("bhcMedicalRecordId",
								saveReq.getBhcMedicalRecordId())
						.setParameter("bhcInvoiceOrderId",
								saveReq.getBhcInvoiceOrderId())
						.getResultList();

				for (Object[] result : medRecInvIds) {
					String retrieveStatus = (String) result[0];
					String bhcDocStatus = (String) result[1];

					DocumentationHistory docHistory = new DocumentationHistory();
					docHistory.setNoteId(id);
					docHistory.setDocumentId(documentId);
					docHistory.setBhcMedicalRecordId(
							saveReq.getBhcMedicalRecordId());
					docHistory.setBhcInvoiceOrderNo(
							saveReq.getBhcInvoiceOrderId());
					docHistory.setBhcDocumentStatus(bhcDocStatus);
					docHistory.setBhcMissingDocNotes("");
					docHistory.setBhcMissingDocType("");
					docHistory.setRetrieveStatus(retrieveStatus);
					docHistory.setLastUpdatedTimestamp(
							new Timestamp(System.currentTimeMillis()));
					docHistory.setAssignedTo(saveReq.getAssigneeFullName());
					docHistory.setLastUpdatedUserFullname(
							saveReq.getLastUpdatedUserFullName());
					docHistory.setLastUpdatedUserId(
							Long.valueOf(saveReq.getLastUpdatedUserId()));
					docHistory.setLastUpdatedUsername(
							saveReq.getLastUpdatedUserName());

					session.save(docHistory);

				}
			}

			/*
			 * if(saveReq.getAssigneeChanged() == 1) {
			 * log.debug("Updating AppNotifications Table.........");
			 * AppNotifications appNotifications = new AppNotifications();
			 * appNotifications.setReadFlag(false);
			 * appNotifications.setCreatedTimestamp(currentTime);
			 * appNotifications.setLastUpdatedTimestamp(currentTime);
			 * appNotifications.setUserFullname(userFullname); }
			 */

		} catch (Exception e) {
			log.error("Exception occured while saving request : {}"
					,e.getMessage());
		}
	}

	@Override
	public boolean submitRecord(SubmitRequest req) {
		log.info("Submiting documents to bhc_Medical_Record_Id :   {}"
				, req.getBhcMedicalRecordId());
		log.info("bhc_inv_order_id:  {}", req.getBhcInvoiceOrderId());
		
		boolean status = false;
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		log.debug("submitReq:   {}", req);
		try {
			ChartReviewDAOImpl.getNotificationSend().set(false);
			// Inserting/Updating DocumentNotificationStatus Table row
			String notHql = "From DocumentNotificationStatus "
					+ "WHERE bhcMedicalRecordId = :bhcMedicalRecordId"
					+ " AND bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";
			DocumentNotificationStatus object = session.createQuery(notHql, 
					DocumentNotificationStatus.class)
					.setParameter("bhcMedicalRecordId", new Long(req.getBhcMedicalRecordId()))
					.setParameter("bhcInvoiceOrderNo", new Long(
							req.getBhcInvoiceOrderId())).setMaxResults(1)
					.uniqueResult();
			log.debug("DocumentNotificationStatus object:  {}", object);

			if (object != null) {
				object.setNotificationSent(0);
				object.setLastUpdateTimestamp(currentTime);
				log.debug("object:  {} ", object);
				session.update(object);
			} else {
				DocumentNotificationStatus obj = new DocumentNotificationStatus();
				obj.setBhcInvoiceOrderNo(new Long(req.getBhcInvoiceOrderId()));
				obj.setBhcMedicalRecordId(new Long(req.getBhcMedicalRecordId()));
				obj.setDocumentDetails(null);
				obj.setLastUpdateTimestamp(currentTime);
				obj.setNotificationSent(0);
				log.debug("obj:   {}", obj);
				session.save(obj);
			}

			// Saving Manual attachments before submit
			if (req.getManualAttachments() != null
					&& !req.getManualAttachments().isEmpty()) {

				log.debug("req.getManualAttachments().size : {}",
						req.getManualAttachments().size());

				for (ManualAttachment attach : req.getManualAttachments()) {
					session = this.sessionFactory.getCurrentSession();

					log.debug("attach.isNewFile() : {}", attach.isNewFile());
					log.debug("attach.isDeleted() : {}", attach.isDeleted());

					if (attach.isNewFile()) {
						log.debug("isNewFile..");

						PatientMedicalRecords pmr = new PatientMedicalRecords();
						pmr.setDocumentId(UUID.randomUUID().toString());
						pmr.setBhcMedicalRecordId(req.getBhcMedicalRecordId());
						pmr.setBhcInvoiceOrderNo(req.getBhcInvoiceOrderId());

						pmr.setDocumentName(attach.getDocumentName());
						pmr.setDocumentContent(attach.getDocumentContent());
						pmr.setDocumentType(attach.getDocumentType());
						pmr.setLastUpdatedTimestamp(currentTime);
						pmr.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
						pmr.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
						pmr.setLastUpdatedUsername(req.getLastUpdatedUserName());
						if(attach.getDocumentType().equalsIgnoreCase("Medical Record Request")) {
							pmr.setIsSubmitted(1);
						} else {
							pmr.setIsSubmitted(0);
						}
						log.debug("Saving manual attachment to DB..  {}", pmr);

						session.save(pmr);
						log.debug("Saved..");

					} else if (attach.isDeleted()) {
						// remove file from db

						log.debug("Deleting manual attachment from DB..");

						String deleteHql = "DELETE from PatientMedicalRecords "
								+ " WHERE bhcMedicalRecordId = :medRecId AND"
								+ " bhcInvoiceOrderNo = :bhcInvoiceId AND"
								+ " documentId = :documentId";

						session.createQuery(deleteHql).setParameter("medRecId",
								req.getBhcMedicalRecordId())
								.setParameter("bhcInvoiceId", req.getBhcInvoiceOrderId())
								.setParameter("documentId", attach.getDocumentId()).executeUpdate();
					}
				}
			}

			// getting attachment object
			List<IHealDocument> iHealAttachments = req.getiHealAttachments();
			// List<IHealDocument> finalAttachments = new ArrayList<>();

			if (iHealAttachments != null) {
				log.info("iHealAttachments initial size: {}", iHealAttachments.size());
			}

			List<String> documentTypeList = new ArrayList<>();
			// Not fetching Medical Record Request Doc Type since we do not need to Sent to Byram
			String[] documentType = { "Wound Assessment", "Progress Note"
					, "Procedure Note", "Provider Orders", "Other",
					"Multi-Wound Chart"};
			documentTypeList.addAll(Arrays.asList(documentType));
			// Read data from patient medical record and upload to iHeal
			// CustomScans
			String pmrHql = "FROM PatientMedicalRecords pmr "
					+ "WHERE pmr.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ "AND pmr.bhcInvoiceOrderNo = :bhcInvoiceOrderNo "
					+ "AND documentType IN :documentType "
					+ " AND isSubmitted = :isSubmitted ";
			// List<AttachmentDetails> manualAttachmentList = new ArrayList<>();

			List<PatientMedicalRecords> manualAttachment = session.createQuery(pmrHql)
					.setParameter("bhcMedicalRecordId", req.getBhcMedicalRecordId())
					.setParameter("bhcInvoiceOrderNo", req.getBhcInvoiceOrderId())
					.setParameter("isSubmitted", 0)
					.setParameter("documentType", documentTypeList).list();

			if (manualAttachment != null) {

				log.info("manualAttachment size:   {}", manualAttachment.size());

				for (PatientMedicalRecords requestAttach : manualAttachment) {
					if (requestAttach.getDocumentType().equalsIgnoreCase("Other")) {
						FileUploadReq uploadReq = new FileUploadReq();
						uploadReq.setFacilityId(req.getFacilityId());
						uploadReq.setFileContent(requestAttach.getDocumentContent());
						uploadReq.setFileName(requestAttach.getDocumentType() + " - "
								+ requestAttach.getDocumentName());
						uploadReq.setMasterToken(req.getMasterToken());
						uploadReq.setPatientId(req.getPatientId());
						uploadReq.setUserId(Integer.parseInt(req.getLastUpdatedUserId()));

						IHealCustomScanUploadRes res = docService.uploadFileToIheal(uploadReq);

						if (res.getErrorCode() != null && res.getErrorCode().equalsIgnoreCase("0")) {

							IHealDocument doc = new IHealDocument();

							if (res.getScan() != null
									&& res.getScan().getDocument() != null) {
								doc.setDocEntityId(res.getScan().getDocument()
										.getDocumentEntityId() + "");
								doc.setVisitId(res.getScan().getDocument().getVisitId());
								doc.setVisitDate(res.getScan().getDocument().getVisitDateTime());
								doc.setVersionId(res.getScan().getDocument().getVersionId());
							} else {
								doc.setDocEntityId("0");
								doc.setVisitId(0);
								doc.setVisitDate("");
								doc.setVersionId(0);
							}
							doc.setDocName(requestAttach.getDocumentName());
							doc.setDocDate(CommonUtils.getCurrentDate("yyyy-MM-dd"));
							doc.setDocType("CustomScans");

							// Need to set its enabled or not

							log.debug("doc :   {}", doc);
							iHealAttachments.add(doc);

							log.debug("Manual attachment successfully uploaded to iHeal..");
							log.debug("Deleting attachment from DB PatientMedicalRecords.");

							String deleteHql = "DELETE from PatientMedicalRecords "
									+ " WHERE bhcMedicalRecordId = :medRecId AND"
									+ " bhcInvoiceOrderNo = :bhcInvoiceId AND" 
									+ " documentId = :documentId";

							session.createQuery(deleteHql)
									.setParameter("medRecId", req.getBhcMedicalRecordId())
									.setParameter("bhcInvoiceId", req.getBhcInvoiceOrderId())
									.setParameter("documentId", 
											requestAttach.getDocumentId()).executeUpdate();

							log.debug("Deleted from PatientMedicalRecords table");

						} else {
							// Failed. dont remove document from PMR table
							log.debug("Manual attachment failed to Upload to iHeal..");
							log.debug("Error details :   {}", res.getErrorMessage());
						}
					} else {
						IHealDocument doc = new IHealDocument();

						doc.setDocEntityId("0");
						doc.setVisitId(0);
						doc.setVisitDate("");
						doc.setVersionId(0);
						doc.setDocumentUUId(requestAttach.getDocumentId());
						doc.setDocName(requestAttach.getDocumentName());
						doc.setDocDate(CommonUtils.getCurrentDate("yyyy-MM-dd"));
						doc.setDocType(requestAttach.getDocumentType());

						// Need to set its enabled or not

						log.debug("doc :   {}", doc);
						iHealAttachments.add(doc);
					}
				}
			}

			// clear iHeal Attachment and add all including manual attachment

			req.setiHealAttachments(null);
			req.setiHealAttachments(iHealAttachments);

			log.info("Final iHealAttachments size: {}", req.getiHealAttachments().size());

			// Call iHeal DocViewPDFRequest API
			List<IHealDocument> finalDocList = req.getiHealAttachments();

			log.debug("finalDocList Size:   {}", finalDocList);
			if (finalDocList != null) {

				String rowNoteIdHQL = "SELECT MAX(noteId) from DocumentationHistory ";

				Integer id = (Integer) session.createQuery(rowNoteIdHQL).uniqueResult();
				id = id + 1;
				log.debug("id.........................{}   ", id);
				
				String docHql = "From AWDDashboard "
						+ "WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND "
						+ " bhcInvoiceOrderId = :bhcInvoiceOrderId AND active = 1";
				AWDDashboard dashboard = session.createQuery(docHql,
							AWDDashboard.class)
						.setParameter("bhcMedicalRecordId", req.getBhcMedicalRecordId())
						.setParameter("bhcInvoiceOrderId", req.getBhcInvoiceOrderId()).uniqueResult();
				String bhcDocStatus = "";
				String bhcMissingDocNotes = "";
				String bhcMissingDocType = "";
				
				if (dashboard != null) {
					bhcDocStatus = dashboard.getBhcDocumentStatus();
					bhcMissingDocNotes = dashboard.getBhcMissingDocNotes();
					bhcMissingDocType = dashboard.getBhcMissingDocType();
				}
				
				for (IHealDocument iHealDoc : finalDocList) {
					if (iHealDoc.getIsSubmitted() == 0) {
						String documentId = UUID.randomUUID().toString();

						iHealDoc.setDocumentStatusId(documentId);

						Long currentCounter = counters.getOrDefault(
								req.getBhcInvoiceOrderId() + "_"
										+ getFileTypeForS3(iHealDoc.getDocType()), 0L);
						Long nextCounter = currentCounter + 1L;

						counters.put(req.getBhcInvoiceOrderId() + "_"
								+ getFileTypeForS3(iHealDoc.getDocType()),
								nextCounter);

						String fileName = req.getBluebookId() + "_" + req.getFacilityName() + "_"
								+ req.getPatientFirstName() + "_" + req.getPatientLastName() + "_"
								+ CommonUtils.formatDate("MMddyyyy",
										CommonUtils.getDateObj("MM/dd/yyyy", req.getBhcShipDate()))
								+ "_" + req.getBhcPatientAccountNo() + "_" + req.getBhcPatientInv() + "_"
								+ CommonUtils.getCurrentDate("MMddyyyy") + "_" + getFileTypeForS3(iHealDoc.getDocType())
								+ "_" + nextCounter + ".pdf";
						
						log.info("filename ###: {}" ,fileName);
						
						fileName = removeSpecialCharacters(fileName);
						
						log.info("filename after removed Special Chars ###: {}" ,fileName);

						DocumentationHistory docHistory = new DocumentationHistory();
						docHistory.setDocumentId(documentId);
						docHistory.setBhcMedicalRecordId(req.getBhcMedicalRecordId());
						docHistory.setBhcInvoiceOrderNo(req.getBhcInvoiceOrderId());
						docHistory.setBhcDocumentStatus(bhcDocStatus);
						docHistory.setBhcMissingDocNotes(fileName);
						docHistory.setBhcMissingDocType("Document(s) sent to vendor:");
						docHistory.setRetrieveStatus("Submitted");
						docHistory.setNoteId(id);
						docHistory.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
						docHistory.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
						docHistory.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));

						session.save(docHistory);

						log.debug("documentationHistoryId  {}", id);

						log.info("Doc type: {}", iHealDoc.getDocType());

						String UUIDStr = UUID.randomUUID().toString();
						log.info("UUIDStr: {}", UUIDStr);

						DocumentStatus record = new DocumentStatus();
						record.setBhcMedRecId(Long.valueOf(req.getBhcMedicalRecordId()));
						record.setBhcInvOrderNo(Long.valueOf(req.getBhcInvoiceOrderId()));

						record.setClientState(UUIDStr);

						record.setFacilityId(req.getFacilityId());
						record.setBluebookId(req.getBluebookId());
						record.setPatientId(Long.valueOf(req.getPatientId()));
						record.setVisitId(Long.valueOf(iHealDoc.getVisitId()));
						record.setMasterToken(req.getMasterToken());

						record.setDocumentType(iHealDoc.getDocType());

						record.setLastUpdatedTimestamp(LocalDateTime.now());
						record.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
						record.setLastUpdatedUsername(req.getLastUpdatedUserName());

						record.setDocPdfRequestTimestamp(LocalDateTime.now());
						record.setDocSubmittedByUserId(Long.valueOf(req.getLastUpdatedUserId()));
						record.setDocSubmittedByUsername(req.getLastUpdatedUserName());
						record.setDocSubmittedByUserFullname(req.getLastUpdatedUserFullName());

						record.setFacilityName(req.getFacilityName());
						record.setFacilityId(req.getFacilityId());
						record.setPatientFirstName(req.getPatientFirstName());
						record.setPatientLastName(req.getPatientLastName());
						record.setBhcShipDate(CommonUtils.getDateObj("MM/dd/yyyy", req.getBhcShipDate()));
						record.setBhcPatientAcctNo(req.getBhcPatientAccountNo());
						record.setBhcPatientInv(req.getBhcPatientInv());

						// Document Upload Status
						record.setDocUploadStatus("In Progress");
						record.setDocumentationHistoryNoteId(documentId);

						String dateStr = CommonUtils.getCurrentDate("yyyy-MM-dd");
						Date currentDate = CommonUtils.getDateObj("yyyy-MM-dd", dateStr);

						log.info("currentDate : {}", currentDate);

						record.setVisitDate(currentDate);

						Date docLastSent = CommonUtils.getDateObj("yyyy-MM-dd",
								CommonUtils.getCurrentDate("yyyy-MM-dd"));

						record.setDateDocSent(docLastSent);

						if (iHealDoc.getDocType() != null
								&& iHealDoc.getDocType().equalsIgnoreCase("CustomScans")) {
							DocServiceReq docServiceReq = new DocServiceReq();
							docServiceReq.setMasterToken(req.getMasterToken());
							docServiceReq.setFacilityId(req.getFacilityId());
							docServiceReq.setPatientId(req.getPatientId());
							docServiceReq.setUserId(Integer.parseInt(req.getLastUpdatedUserId()));
							docServiceReq.setDocEntityId(iHealDoc.getDocEntityId() + "");

							IHealFileGetRes fileGetRes = docService.getCustomScanContent(docServiceReq);

							if (fileGetRes.getErrorCode() != null && fileGetRes.getErrorCode().equalsIgnoreCase("0")) {
								// Success
								record.setDocReqStatus("Success");
								session.save(record);
								// save data in history timeline table and fetch
								// note_id;

								pdfService.uploadCustomScansToS3(UUIDStr, fileGetRes.getImageStream(),
										req.getBluebookId(), iHealDoc.getDocType(), req, documentId);
								iHealDoc.setIsSubmitted(1);

							} else {
								// Error
								record.setDocReqStatus("Failed - " + fileGetRes.getErrorMessage());
								record.setDocUploadStatus("Failed");
								record.setErrorMessage(fileGetRes.getErrorMessage());
								session.save(record);
								
								// Send Failed DocumentNotification
								int dnsStatus = getDocumentNotificationStatus(req);
								log.debug("dnsStatus:   {}", dnsStatus);
								if (dnsStatus == 0) {
									appNotificationBO.sendFailedDocNotification(req.getBhcMedicalRecordId(),
											req.getBhcInvoiceOrderId(), documentId, req.getLastUpdatedUserId(),
											req.getLastUpdatedUserName(), req.getLastUpdatedUserFullName());
								}
								iHealDoc.setIsSubmitted(0);
							}

						} else if (iHealDoc.getDocType() != null
								&& iHealDoc.getDocType().equalsIgnoreCase("WoundAssessments")
								|| iHealDoc.getDocType() != null
										&& iHealDoc.getDocType().equalsIgnoreCase("Debridements")
								|| iHealDoc.getDocType() != null
										&& iHealDoc.getDocType().equalsIgnoreCase("ProviderOrders")
								|| iHealDoc.getDocType() != null
										&& iHealDoc.getDocType().equalsIgnoreCase("ProgressNotes")) {
							// WoundAssessments, ProgressNotes, Debridements and
							// ProviderOrders

							DocServiceReq docServiceReq = new DocServiceReq();
							docServiceReq.setMasterToken(req.getMasterToken());
							docServiceReq.setFacilityId(req.getFacilityId());
							docServiceReq.setPatientId(req.getPatientId());
							docServiceReq.setUserId(Integer.parseInt(req.getLastUpdatedUserId()));
							docServiceReq.setDocEntityId(iHealDoc.getDocEntityId() + "");

							record.setGetPDFRequestTimestamp(LocalDateTime.now());
							// IHealDocumentViewPDFGetRes pdfRes =
							// docService.sendDocumentViewPDFGet(docServiceReq);

							session.save(record);
							
							int uploadStatus = pdfService.uploadIHealAttachments(UUIDStr, docServiceReq, req.getBluebookId(),
									iHealDoc.getDocType(), req, documentId);
						
							iHealDoc.setIsSubmitted(uploadStatus);

							/*
							 * if (pdfRes != null && pdfRes.getErrorCode()
							 * .equalsIgnoreCase("0")) { // success
							 * log.debug("DocumentViewPDFGet Success..");
							 * //record.setIhealJobId(viewRes.getJobId() + "");
							 * //record.setPdfFileName(viewRes.getPdfFilename())
							 * ; //record.setDocReqStatus("Success"); // save
							 * document id of history timeline record to //
							 * documentstatus table
							 * 
							 * record.setDocumentationHistoryNoteId(documentId);
							 * session.save(record);
							 * 
							 * pdfService.uploadIHealAttachments(UUIDStr,
							 * pdfRes.getPdfBytes(), req.getBluebookId(),
							 * iHealDoc.getDocType(), req, documentId); } else {
							 * // failed
							 * log.debug("DocumentViewPDFGet Failed..");
							 * record.setDocReqStatus( "Failed - " +
							 * pdfRes.getErrorMessage());
							 * record.setDocUploadStatus("Failed");
							 * record.setErrorMessage(pdfRes.getErrorMessage());
							 * session.save(record);
							 * 
							 * // Send Failed DocumentNotification int dnsStatus
							 * = getDocumentNotificationStatus( req);
							 * log.debug("dnsStatus:   {}",dnsStatus); if
							 * (dnsStatus == 0) { appNotificationBO
							 * .sendFailedDocNotification(
							 * req.getBhcMedicalRecordId(),
							 * req.getBhcInvoiceOrderId(), documentId,
							 * req.getLastUpdatedUserId(),
							 * req.getLastUpdatedUserName(),
							 * req.getLastUpdatedUserFullName()); }
							 * 
							 * }
							 */
						} else {

							String hql = "FROM PatientMedicalRecords pmr WHERE pmr.bhcMedicalRecordId = :bhcMedicalRecordId "
									+ "AND pmr.bhcInvoiceOrderNo = :bhcInvoiceOrderNo "
									+ "AND pmr.documentId = :documentId ";

							PatientMedicalRecords manuallyAttach = session.createQuery(hql, PatientMedicalRecords.class)
									.setParameter("bhcMedicalRecordId", req.getBhcMedicalRecordId())
									.setParameter("bhcInvoiceOrderNo", req.getBhcInvoiceOrderId())
									.setParameter("documentId", iHealDoc.getDocumentUUId()).uniqueResult();
							log.debug("manuallYAttach HQL Param: {}", iHealDoc.getDocumentUUId());
							log.debug("manuallyAttach:   {}", manuallyAttach);
							if (manuallyAttach != null) {
								log.debug("in Submit Manual Doc Type Else part.....{}", manuallyAttach);

								record.setDocReqStatus("Success");
								session.save(record);
								// save data in history timeline table and fetch
								// note_id;

								int uploadStatus = pdfService.uploadCustomScansToS3(UUIDStr,
										manuallyAttach.getDocumentContent(), req.getBluebookId(),
										manuallyAttach.getDocumentType(), req, documentId);
								if (uploadStatus == 1) {
									manuallyAttach.setDocumentationHistoryNoteId(documentId);
									manuallyAttach.setIsSubmitted(1);
									session.update(manuallyAttach);
								} else {
									manuallyAttach.setDocumentationHistoryNoteId(documentId);
									manuallyAttach.setIsSubmitted(0);
									session.update(manuallyAttach);
								}

							} else {
								// Error
								record.setDocReqStatus("Failed Manual Attachment Submit");
								record.setDocUploadStatus("Failed");
								record.setErrorMessage(null);
								session.save(record);

								// Send Failed DocumentNotification
								int dnsStatus = getDocumentNotificationStatus(req);
								log.debug("dnsStatus:   {}", dnsStatus);
								if (dnsStatus == 0) {
									appNotificationBO.sendFailedDocNotification(req.getBhcMedicalRecordId(),
											req.getBhcInvoiceOrderId(), documentId, req.getLastUpdatedUserId(),
											req.getLastUpdatedUserName(), req.getLastUpdatedUserFullName());
								}

							}

						}
						log.debug("Saving DocViewPDFRequest status in document_status table..");
					}
				}
				
				//Retrieve Status is 'MedAdv' and submitting the files
				//Set status to 'Completed'
				if (req.getCurrentStatus() != null
						&& req.getCurrentStatus().equalsIgnoreCase("MedAdv")) {

					id = (Integer) session.createQuery(rowNoteIdHQL).uniqueResult();
					id = id + 1;
					log.debug("id.........................{}   ", id);

					DocumentationHistory docHistory = new DocumentationHistory();
					docHistory.setDocumentId(UUID.randomUUID().toString());
					docHistory.setBhcMedicalRecordId(req.getBhcMedicalRecordId());
					docHistory.setBhcInvoiceOrderNo(req.getBhcInvoiceOrderId());
					docHistory.setBhcDocumentStatus(bhcDocStatus);
					docHistory.setBhcMissingDocNotes(bhcMissingDocNotes);
					docHistory.setBhcMissingDocType(bhcMissingDocType);
					docHistory.setRetrieveStatus("Completed");
					docHistory.setNoteId(id);
					docHistory.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
					docHistory.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
					docHistory.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));

					session.save(docHistory);
				}
				
			} else {
				// Capture Submitted status in History, when user submitted
				// without any attachment
		/*		String rowNoteIdHQL = "SELECT MAX(noteId) from DocumentationHistory ";
			int	id = (Integer) session.createQuery(rowNoteIdHQL).uniqueResult();
				id = id + 1;
				log.debug("id.........................{}   ", id);
				DocumentationHistory docHistory = new DocumentationHistory();
				docHistory.setDocumentId(UUID.randomUUID().toString());
				docHistory.setBhcMedicalRecordId(req.getBhcMedicalRecordId());
				docHistory.setBhcInvoiceOrderNo(req.getBhcInvoiceOrderId());
				docHistory.setBhcDocumentStatus(null);
				docHistory.setBhcMissingDocNotes("No documents sent to vendor");
				docHistory.setBhcMissingDocType("submitted to vendor");
				docHistory.setRetrieveStatus("Submitted");
				docHistory.setNoteId(id);
				docHistory.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
				docHistory.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
				docHistory.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));

				session.save(docHistory);    */
			}

			int filesSentCount = (finalDocList == null) ? 0
					: finalDocList.size();
			
			log.debug("Before getting notes count..");

			/*
			 * count number of updates in notes table
			 */
			Long noOfUpdates = getNotesCount(
					Integer.toString(req.getBhcMedicalRecordId()),
					Integer.toString(req.getBhcInvoiceOrderId()));
			
			log.debug("After getting notes count..");
			
			log.debug("Before getting docsFirstSent..");
			
			// if 0 first time / 1 not first time
			Date docsFirstSent = getSubmittedTimesFromDocumentStatus(req);
			
			log.debug("After getting docsFirstSent..");

			// finally update AWD Dashboard table
			String hql = "UPDATE AWDDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
					+ " lastUpdatedUserFullName = :lastUpdatedUserFullName,"
					+ " lastUpdatedUserName = :lastUpdatedUsername, "
					+ " lastUpdatedDateTime = :lastUpdatedDateTime, "
					+ " lastActioned = :lastActioned, "
					+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname,"
					+ " lastTeamUpdated = :lastTeamUpdated,"
					+ " status = :status, "
					+ " statusUpdatedDateTime = :statusUpdatedDateTime, "
					+ " statusUpdatedUserFullName = :statusUpdatedUserFullName, "
					+ " statusUpdatedUserId = :statusUpdatedUserId, "
					+ " statusUpdatedUserName = :statusUpdatedUserName, "
					+ " assignee = :assignee, "
					+ " assigneeFullName = :assigneeFullName, "
					+ " attachments = :attachments, "
					+ " lastFileUploaded = :lastFileUploaded, "
					+ " filesSent = :filesSent, "
					+ " docsFirstSent = :docsFirstSent,"
					+ " noOfUpdates = :noOfUpdates, "
					+ " reassignedTo = :reassignedTo "
					+ " WHERE bhcMedicalRecordId = :medRecId AND"
					+ " bhcInvoiceOrderId = :bhcInvoiceId ";

			String attachments = null;
			try {
				attachments = new ObjectMapper()
						.writeValueAsString(finalDocList);
			} catch (JsonProcessingException e) {
				log.error("Json Procession exception:  {}", e);
			}

			String retrieveStatus = "Submitted";
			if (req.getCurrentStatus() != null
					&& req.getCurrentStatus().equalsIgnoreCase("MedAdv")) {
				retrieveStatus = "Completed";
			}
			
			log.debug("Before updating AWDDashboard...");
			
			// Saving details
			 session.createQuery(hql)
					.setParameter("lastUpdatedUserId",
							Long.valueOf(req.getLastUpdatedUserId()))
					.setParameter("lastUpdatedUserFullName",
							req.getLastUpdatedUserFullName())
					.setParameter("lastUpdatedUsername",
							req.getLastUpdatedUserName())
					.setParameter("lastActioned", currentTime)
					.setParameter("lastTeamUpdatedUserFullname",
							req.getLastTeamUpdatedUserFullname())
					.setParameter("lastTeamUpdated", currentTime)
					.setParameter("lastUpdatedDateTime", currentTime)
					.setParameter("status", retrieveStatus)
					.setParameter("statusUpdatedDateTime", currentTime)
					.setParameter("statusUpdatedUserFullName",
							req.getLastUpdatedUserFullName())
					.setParameter("statusUpdatedUserId",
							Long.valueOf(req.getLastUpdatedUserId()))
					.setParameter("statusUpdatedUserName",
							req.getLastUpdatedUserName())
					.setParameter("assignee", req.getAssigneeUserName())
					.setParameter("assigneeFullName", req.getAssigneeFullName())
					.setParameter("attachments", attachments)
					.setParameter("lastFileUploaded", currentTime)
					.setParameter("filesSent", Long.valueOf(filesSentCount))
					.setParameter("noOfUpdates", noOfUpdates)
					.setParameter("reassignedTo", 0)
					.setParameter("docsFirstSent", docsFirstSent)
					.setParameter("medRecId", req.getBhcMedicalRecordId())
					.setParameter("bhcInvoiceId", req.getBhcInvoiceOrderId())
					.executeUpdate();
			 
			 log.debug("After updating AWDDashboard...");

			status = true;

		} catch (Exception e) {
			log.error("Exception occured while saving request :  {}"
					, e.getMessage());
		}
		log.debug("counters before clear: " +counters.size());
		counters.clear();
		log.debug("counters after clear: " +counters.size());
		return status;
	}
	
	
	private Date getSubmittedTimesFromDocumentStatus(SubmitRequest req) {
		Date docsFirstSent = new Date();
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentStatus> documentStatus = null;
		try {
			String awdHql = "FROM DocumentStatus d WHERE d.bhcMedRecId = :bhcMedRecId AND"
					+ " d.bhcInvOrderNo = :bhcInvOrderNo order by d.lastUpdatedTimestamp";

			documentStatus = session.createQuery(awdHql)
					.setParameter("bhcMedRecId", Long.valueOf(req.getBhcMedicalRecordId()))
					.setParameter("bhcInvOrderNo", Long.valueOf(req.getBhcInvoiceOrderId()))
					.list();
			
			if(documentStatus != null && !documentStatus.isEmpty()) {
				Instant instant = documentStatus.get(0).getLastUpdatedTimestamp().toInstant(ZoneOffset.UTC);
				docsFirstSent = Date.from(instant);
			}

		} catch (Exception e) {
			log.error("Exception occured in getSubmittedTimesFromDocumentStatus: {}"
					, e.getMessage());
		}
		return docsFirstSent;
	}
	

	private int getDocumentNotificationStatus(SubmitRequest req) {
		// DocumentNotificationStatus Table Update
		int status = 0;
		Session session = this.sessionFactory.getCurrentSession();

		try {
			String hql = "From DocumentNotificationStatus WHERE bhcMedicalRecordId = :bhcMedicalRecordId"
					+ " AND bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";
			DocumentNotificationStatus dns = session
					.createQuery(hql, DocumentNotificationStatus.class)
					.setParameter("bhcMedicalRecordId",
							new Long(req.getBhcMedicalRecordId()))
					.setParameter("bhcInvoiceOrderNo",
							new Long(req.getBhcInvoiceOrderId()))
					.setMaxResults(1).uniqueResult();
			log.debug("DocumentNotificationStatus object:  {}" , dns);
			if (dns != null) {
				if (dns.getNotificationSent() == 1) {
					status = 1;
				}
			}
		} catch (Exception e) {
			log.error(
					"Exception occured while updating document notification status : {} "
							, e.getMessage());
		}
		return status;
	}

	private String getJobSavePDFFileName(String doctype) {
		String jobName = "";

		switch (doctype) {
			case "ProviderOrders" :
				jobName = JobSavePdfFileName.PROVIDERORDER.value();
				break;
			case "ProgressNotes" :
				jobName = JobSavePdfFileName.PROGRESSNOTE.value();
				break;
			case "Debridements" :
				jobName = JobSavePdfFileName.DEBRIDEMENT.value();
				break;
			case "WoundAssessments" :
				jobName = JobSavePdfFileName.WOUNDASSESSMENT.value();
				break;
			default :
				break;
		}
		return jobName;
	}

	private String getDocViewName(String doctype) {
		String jobName = "";

		switch (doctype) {
			case "ProviderOrders" :
				jobName = DocumentationViewName.PROVIDERORDER.value();
				break;
			case "ProgressNotes" :
				jobName = DocumentationViewName.PROGRESSNOTE.value();
				break;
			case "Debridements" :
				jobName = DocumentationViewName.DEBRIDEMENT.value();
				break;
			case "WoundAssessments" :
				jobName = DocumentationViewName.WOUNDASSESSMENT.value();
				break;
			default :
				break;
		}
		return jobName;
	}

	@Override
	public boolean modifyRecord(ModifyRecordReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			if (req.getAddendum() == 1) {

				String hql = "UPDATE AWDDashboard SET "
						+ " lastActioned = :lastActioned, "
						+ " addendum = :addendum, "
						+ " addendumUserId = :addendumUserId, "
						+ " addendumUsername = :addendumUsername, "
						+ " addendumUserFullname = :addendumUserFullname "
						+ " WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND "
						+ " bhcInvoiceOrderId = :bhcInvoiceOrderId";

				 session.createQuery(hql)
						.setParameter("lastActioned", currentTime)
						.setParameter("addendum", req.getAddendum())
						.setParameter("addendumUserId",
								req.getLastUpdatedUserId())
						.setParameter("addendumUsername",
								req.getLastUpdatedUsername())
						.setParameter("addendumUserFullname",
								req.getLastUpdatedUserFullname())
						.setParameter("bhcMedicalRecordId",
								Integer.parseInt(req.getBhcMedicalRecordId()))
						.setParameter("bhcInvoiceOrderId",
								Integer.parseInt(req.getBhcInvoiceOrderNo()))
						.executeUpdate();

			} else if (req.getRecordModify() == 1) {

				String hql = "UPDATE AWDDashboard SET "
						+ " lastActioned = :lastActioned, "
						+ " recordModify = :recordModify, "
						+ " recordModifyUserId = :recordModifyUserId, "
						+ " recordModifyUsername = :recordModifyUsername, "
						+ " recordModifyUserFullname = :recordModifyUserFullname "
						+ " WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND "
						+ " bhcInvoiceOrderId = :bhcInvoiceOrderId";

				session.createQuery(hql)
						.setParameter("lastActioned", currentTime)
						.setParameter("recordModify", req.getRecordModify())
						.setParameter("recordModifyUserId",
								req.getLastUpdatedUserId())
						.setParameter("recordModifyUsername",
								req.getLastUpdatedUsername())
						.setParameter("recordModifyUserFullname",
								req.getLastUpdatedUserFullname())
						.setParameter("bhcMedicalRecordId",
								Integer.parseInt(req.getBhcMedicalRecordId()))
						.setParameter("bhcInvoiceOrderId",
								Integer.parseInt(req.getBhcInvoiceOrderNo()))
						.executeUpdate();
			}

			String rowNoteIdHQL = "SELECT MAX(noteId) from DocumentationHistory ";

			Integer id = (Integer) session.createQuery(rowNoteIdHQL)
					.uniqueResult();
			id = id + 1;

			log.debug("updating documentation history table.............");

			String documentId = UUID.randomUUID().toString();

			String bhcHql = "SELECT a.status, a.bhcDocumentStatus "
					+ " FROM AWDDashboard a "
					+ " WHERE a.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND a.bhcInvoiceOrderId = :bhcInvoiceOrderId";

			List<Object[]> medRecInvIds = session
					.createQuery(bhcHql, Object[].class)
					.setParameter("bhcMedicalRecordId",
							Integer.parseInt(req.getBhcMedicalRecordId()))
					.setParameter("bhcInvoiceOrderId",
							Integer.parseInt(req.getBhcInvoiceOrderNo()))
					.getResultList();

			for (Object[] result : medRecInvIds) {
				String retrieveStatus = (String) result[0];
				String bhcDocStatus = (String) result[1];

				DocumentationHistory docHistory = new DocumentationHistory();
				docHistory.setNoteId(id);
				docHistory.setDocumentId(documentId);
				docHistory.setBhcMedicalRecordId(
						Integer.parseInt(req.getBhcMedicalRecordId()));
				docHistory.setBhcInvoiceOrderNo(
						Integer.parseInt(req.getBhcInvoiceOrderNo()));
				docHistory.setBhcDocumentStatus(bhcDocStatus);
				docHistory.setBhcMissingDocNotes("");
				docHistory.setBhcMissingDocType("");
				docHistory.setRetrieveStatus(retrieveStatus);
				docHistory.setLastUpdatedTimestamp(
						new Timestamp(System.currentTimeMillis()));
				docHistory.setLastUpdatedUserFullname(
						req.getLastUpdatedUserFullname());
				docHistory.setLastUpdatedUserId(req.getLastUpdatedUserId());
				docHistory.setLastUpdatedUsername(req.getLastUpdatedUsername());

				if (req.getAddendum() == 1) {
					docHistory.setAddendum(req.getAddendum());

				} else if (req.getRecordModify() == 1) {
					docHistory.setRecordModify(req.getRecordModify());

				}

				session.save(docHistory);
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while modify record: {}" , e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return true;
	}

	@Override
	public void saveNotes(SaveNotesReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			Date followupDate = null;
			SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

			UserNotes userNotes = new UserNotes();
			//String description = new String(req.getDescription().getBytes("UTF-8"),"UTF-8");
			UUID noteId = UUID.randomUUID();
			req.setNotesId(noteId.toString());

			userNotes.setNoteId(noteId.toString());
			userNotes.setBhcMedicalRecordId(
					Long.valueOf(req.getBhcMedicalRecordId()));
			userNotes.setBhcInvoiceOrderNo(
					Long.valueOf(req.getBhcInvoiceOrderNo()));
			userNotes.setAttemptCategory(req.getAttemptCategory());
			userNotes.setAttemptType(req.getAttemptType());
			userNotes.setContactMethod(req.getContactMethod());

			if (req.getFollowupDate() != null
					&& !req.getFollowupDate().isEmpty()) {
				userNotes.setFollowupDate(format.parse(req.getFollowupDate()));
				followupDate = format.parse(req.getFollowupDate());
			} else {
				userNotes.setFollowupDate(null);
			}

			userNotes.setAddendumSent(req.getAddendumSent());
			userNotes.setAddendumReceived(req.getAddendumReceived());
			userNotes.setReceivedRX(req.getReceivedRX());
			userNotes.setRXSent(req.getIsRXSent());
			userNotes.setPatientNotSeen30Days(req.getPatientNotSeen30Days());
			userNotes.setDescription(req.getDescription());
			userNotes.setPatientId(Long.valueOf(req.getPatientId()));
			userNotes.setBluebookId(req.getBluebookId());
			userNotes.setFacilityId(
					Integer.parseInt(req.getBhcMedicalRecordId()));
			userNotes.setPatientFullname(req.getPatientFullname());
			userNotes.setLastUpdatedUsername(req.getLastUpdatedUsername());
			userNotes.setLastUpdatedUserId(
					Long.valueOf(req.getLastUpdatedUserId()));
			userNotes.setLastUpdatedTimestamp(currentTime);
			userNotes.setDeleteFlag(false);
			userNotes.setLastUpdatedUserFullname(
					req.getLastUpdatedUserFullname());

			if (req.getAddendum() == 0 || req.getRecordModify() == 1) {

				String status = "Working_" + req.getAttemptCategory();
				
				//Keep Same status if record is in MedAdv
				if (req.getCurrentStatus().equalsIgnoreCase("MedAdv")) {
					status = "MedAdv";
				}

				if (req.getAttemptType() != null
						&& req.getAttemptType().equalsIgnoreCase("Exhausted")) {
					
					if (req.getCurrentStatus().equalsIgnoreCase("MedAdv")) {
						status = "Completed";
					} else {
						status = "Exhausted";
					}
				}
				
				String hql = "UPDATE AWDDashboard SET lastTeamUpdated = :lastTeamUpdated, "
						+ " lastActioned = :lastActioned, "
						+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
						+ " followupDate = :followupDate, "
						+ " status = :status, "
						+ " statusUpdatedDateTime = :statusUpdatedDateTime, "
						+ " statusUpdatedUserFullName = :statusUpdatedUserFullName, "
						+ " statusUpdatedUserId = :statusUpdatedUserId, "
						+ " statusUpdatedUserName = :statusUpdatedUserName, "
						+ " lastUpdatedDateTime = :lastUpdatedDateTime "
						+ " WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND "
						+ " bhcInvoiceOrderId = :bhcInvoiceOrderId";

				 session.createQuery(hql)
				 		.setParameter("lastUpdatedDateTime", currentTime)
						.setParameter("lastTeamUpdated", currentTime)
						.setParameter("lastTeamUpdatedUserFullname",
								req.getLastTeamUpdatedUserFullname())
						.setParameter("lastActioned", currentTime)
						.setParameter("followupDate", followupDate)
						.setParameter("status", status)
						.setParameter("statusUpdatedDateTime", currentTime)
						.setParameter("statusUpdatedUserFullName",
								req.getLastUpdatedUserFullname())
						.setParameter("statusUpdatedUserId",
								Long.valueOf(req.getLastUpdatedUserId()))
						.setParameter("statusUpdatedUserName",
								req.getLastUpdatedUsername())
						.setParameter("bhcMedicalRecordId",
								Integer.parseInt(req.getBhcMedicalRecordId()))
						.setParameter("bhcInvoiceOrderId",
								Integer.parseInt(req.getBhcInvoiceOrderNo()))
						.executeUpdate();
				log.debug("Notes hql:   {}",session.createQuery(hql).toString());
			} else {
				String hql = "UPDATE AWDDashboard SET lastTeamUpdated = :lastTeamUpdated, "
						+ " lastActioned = :lastActioned, "
						+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
						+ " followupDate = :followupDate, "
						+ " lastUpdatedDateTime = :lastUpdatedDateTime "
						+ " WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND "
						+ " bhcInvoiceOrderId = :bhcInvoiceOrderId";

				 session.createQuery(hql)
				 		.setParameter("lastUpdatedDateTime", currentTime)
						.setParameter("lastTeamUpdated", currentTime)
						.setParameter("lastTeamUpdatedUserFullname",
								req.getLastTeamUpdatedUserFullname())
						.setParameter("lastActioned", currentTime)
						.setParameter("followupDate", followupDate)
						.setParameter("bhcMedicalRecordId",
								Integer.parseInt(req.getBhcMedicalRecordId()))
						.setParameter("bhcInvoiceOrderId",
								Integer.parseInt(req.getBhcInvoiceOrderNo()))
						.executeUpdate();
				log.debug("Notes hql:   {}", session.createQuery(hql).toString());
			}

			/*
			 * else if (req.getAddendum() == 1) {
			 * 
			 * String hql =
			 * "UPDATE AWDDashboard SET lastTeamUpdated = :lastTeamUpdated, " +
			 * " lastActioned = :lastActioned, " +
			 * " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, " +
			 * " followupDate = :followupDate " +
			 * " WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND " +
			 * " bhcInvoiceOrderId = :bhcInvoiceOrderId";
			 * 
			 * int rowChanges = session.createQuery(hql)
			 * .setParameter("lastTeamUpdated", currentTime)
			 * .setParameter("lastTeamUpdatedUserFullname",
			 * req.getLastTeamUpdatedUserFullname())
			 * .setParameter("lastActioned", currentTime)
			 * .setParameter("followupDate", followupDate)
			 * .setParameter("bhcMedicalRecordId",
			 * Integer.parseInt(req.getBhcMedicalRecordId()))
			 * .setParameter("bhcInvoiceOrderId",
			 * Integer.parseInt(req.getBhcInvoiceOrderNo())) .executeUpdate(); }
			 */

			log.debug(
					"Updated lastTeamUpdated in AWDDashboard and Saving User Notes..............");
			
			session.save(userNotes);

			if (req.getAddendum() == 0 || req.getRecordModify() == 1) {
				// Exhausted
				if (req.getAttemptCategory() != null
						&& !req.getAttemptCategory().isEmpty()
						&& req.getAttemptType() != null
						&& !req.getAttemptType().isEmpty()
						&& req.getAttemptType().equalsIgnoreCase("Exhausted")) {

					if (req.getCurrentStatus().equalsIgnoreCase("MedAdv")) {
						
						updateStatusInHistory(
								Integer.parseInt(req.getBhcMedicalRecordId()),
								Integer.parseInt(req.getBhcInvoiceOrderNo()),
								"Exhausted", req);
						
						updateStatusInHistory(
								Integer.parseInt(req.getBhcMedicalRecordId()),
								Integer.parseInt(req.getBhcInvoiceOrderNo()),
								"Completed", req);
					} else {
						updateStatusInHistory(
								Integer.parseInt(req.getBhcMedicalRecordId()),
								Integer.parseInt(req.getBhcInvoiceOrderNo()),
								"Exhausted", req);
					}
					

				} else if (req.getAttemptCategory() != null
						&& req.getAttemptType() != null
						&& !req.getAttemptType()
								.equalsIgnoreCase("Exhausted")) {

					String status = "Working_" + req.getAttemptCategory();
					
					//Keep Same status if record is in MedAdv
					if (req.getCurrentStatus().equalsIgnoreCase("MedAdv")) {
						status = "MedAdv";
					}
					
					// Other than Exhausted
					updateStatusInHistory(
							Integer.parseInt(req.getBhcMedicalRecordId()),
							Integer.parseInt(req.getBhcInvoiceOrderNo()),
							status, req);
				}
			}

			if (req.getUserTaggedInNotes() != null
					&& req.getUserTaggedInNotes() == true) {
				 appNotificationBO.saveAppNotifications(req);
			}
			
		} catch (Exception e) {
			log.error(
					"Exception occured while saving notes:  {}" , e.getMessage());
			throw new CustomException(e.getMessage());
		}

	}

	@Override
	public List<UserNotes> getNotesList(ChartReviewReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<UserNotes> list = new ArrayList<>();
		try {
			String hql = "FROM UserNotes n WHERE n.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND n.bhcInvoiceOrderNo = :bhcInvoiceOrderNo order by lastUpdatedTimestamp desc";

			list = session.createQuery(hql)
					.setParameter("bhcMedicalRecordId",
							Long.valueOf(req.getMedRecId()))
					.setParameter("bhcInvoiceOrderNo",
							Long.valueOf(req.getBhcInvoiceOrderId()))
					.setFirstResult(req.getIndex()).setMaxResults(NOTES_SIZE)
					.list();

		} catch (Exception e) {
			log.error("Exception occured while fetching notes:  {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return list;
	}

	@Override
	public List<RetrieveUsers> getUserRolesList(boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<RetrieveUsers> list = new ArrayList<>();
		try {
			String hql = " FROM RetrieveUsers r WHERE r.isSuperUser = :isSuperUser "
					+ " order by r.userFullName asc";
			
			list = session.createQuery(hql).setParameter("isSuperUser", isSuperUser).list();

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching UserRolesList DAO Impl:  {}"
							,e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return list;
	}

	@Override
	public Long getNotesCount(String bhcMedRecId, String bhcInvOrderNo)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;

		try {
			String hql = "SELECT count(*) FROM UserNotes n"
					+ " WHERE n.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND n.bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";

			taskCount = (Long) session.createQuery(hql)
					.setParameter("bhcMedicalRecordId",
							Long.valueOf(bhcMedRecId))
					.setParameter("bhcInvoiceOrderNo",
							Long.valueOf(bhcInvOrderNo))
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching new notes count: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return taskCount;
	}

	@Override
	public UserNotes getNoteById(String noteId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		UserNotes note = new UserNotes();
		try {
			String hql = "FROM UserNotes n WHERE n.noteId = :noteId ";

			note = session.createQuery(hql, UserNotes.class)
					.setParameter("noteId", noteId).uniqueResult();

		} catch (Exception e) {
			log.error("Exception occured while fetching notes: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return note;
	}

	private boolean updateStatusInHistory(int bhcMedicalRecordId,
			int bhcInvoiceOrderId, String statusChanged, SaveNotesReq req)
			throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "SELECT a.bhcMissingDocNotes, a.bhcMissingDocType, a.bhcDocumentStatus"
					+ " FROM AWDDashboard a "
					+ " WHERE a.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND a.bhcInvoiceOrderId = :bhcInvoiceOrderId";

			List<Object[]> medRecInvIds = session
					.createQuery(hql, Object[].class)
					.setParameter("bhcMedicalRecordId", bhcMedicalRecordId)
					.setParameter("bhcInvoiceOrderId", bhcInvoiceOrderId)
					.getResultList();

			for (Object[] result : medRecInvIds) {
				saveDocumentHistory(bhcMedicalRecordId, bhcInvoiceOrderId,
						(String) result[0], (String) result[1],
						(String) result[2], statusChanged, req);
			}
		} catch (Exception e) {
			log.error("Exception occured : {}" , e.getMessage());
			throw new Exception(e.getMessage());
		}
		return true;
	}

	public void saveDocumentHistory(int bhcMedicalRecordId,
			int bhcInvoiceOrderNo, String bhcMissingDocNotes,
			String bhcMissingDocType, String bhcDocumentStatus,
			String retrieveStatus, SaveNotesReq req) throws Exception {

		Session session = this.sessionFactory.getCurrentSession();
		try {

			String rowNoteIdHQL = "SELECT MAX(noteId) from DocumentationHistory ";

			Integer id = (Integer) session.createQuery(rowNoteIdHQL)
					.uniqueResult();
			id = id + 1;

			String documentId = UUID.randomUUID().toString();
			DocumentationHistory docHistory = new DocumentationHistory();
			docHistory.setNoteId(id);
			docHistory.setDocumentId(documentId);
			docHistory.setBhcMedicalRecordId(bhcMedicalRecordId);
			docHistory.setBhcInvoiceOrderNo(bhcInvoiceOrderNo);
			docHistory.setBhcDocumentStatus(bhcDocumentStatus);
			docHistory.setBhcMissingDocNotes(bhcMissingDocNotes);
			docHistory.setBhcMissingDocType(bhcMissingDocType);
			docHistory.setRetrieveStatus(retrieveStatus);
			docHistory.setLastUpdatedTimestamp(
					new Timestamp(System.currentTimeMillis()));
			docHistory.setLastUpdatedUserFullname(
					req.getLastUpdatedUserFullname());
			docHistory.setLastUpdatedUserId(
					Long.valueOf(req.getLastUpdatedUserId()));
			//docHistory.setUserNotes(req.getDescription());
			docHistory.setUserNotes("Added a note");

			session.save(docHistory);
		} catch (Exception e) {
			log.error("Exception occured : {}" , e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

	@Override
	public IHealPatientSearchRes getPatientObj(PatientSearchReq req) {
		IHealPatientSearchRes ihealPatientSearchRes = null;
		IHealPatientSearchReq searchReq = new IHealPatientSearchReq();
		searchReq.setUserId(req.getUserId());
		searchReq.setMasterToken(req.getMasterToken());
		searchReq.setPrivateKey(env.getProperty(BOConstants.IHEAL_PRIVATEKEY));
		searchReq.setFacilityId(req.getFacilityId());
		searchReq.setLocationId(req.getLocationId());
		searchReq.setMatchField(req.getSearchType());
		searchReq.setMatchPhrase(req.getSearchValue());
		searchReq.setPageIndex(req.getPageIndex());
		searchReq.setMaxPageSize(env.getProperty(BOConstants.IHEAL_PATIENT_SEARCH_MAXPAGESIZE));

		searchReq.setServiceLineId("");
		searchReq.setActivePatientsOnly("false");
		String url = env.getProperty(BOConstants.IHEAL_PATIENT_SEARCH_URL);

		try {
			log.info("IHeal Patient Search URL post started");
			HttpEntity<Object> request = new HttpEntity<>(searchReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealPatientSearchRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealPatientSearchRes.class);
			log.info("IHeal Patient Search URL post Completed");
			log.debug("iHeal Patient Search Response : {}",
					sresponse.getBody());
			ihealPatientSearchRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in IHealPatientSearch - ",
					e);
			ihealPatientSearchRes = new IHealPatientSearchRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealPatientSearchRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealPatientSearchRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in IHealPatientSearch: ",
					e);
			ihealPatientSearchRes = new IHealPatientSearchRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealPatientSearchRes.setErrorCode(errorResponse.get(ERRORCODE));
			ihealPatientSearchRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealPatientSearchRes;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	@Override
	public int updatePatientDetails(UpdatePatientDetailsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		int rowChanges = 0;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
		//	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

			// Updating AWDDashboard Table
			String hql = "UPDATE AWDDashboard SET healogicsPatientId = :patientId, "
					+ " healogicsPatientMRN = :patientMRN, "
					+ " patientFirstName = :patientFirstName, "
					+ " patientLastName = :patientLastName, "
					+ " patientDOB = :patientDOB, "
					+ " patientLinked = :patientLinked, "
					+ " patientLinkUsername = :patientLinkUsername, "
					+ " patientLinkUserId = :patientLinkUserId, "
					+ " patientLinkUserFullname = :patientLinkUserFullname, "
					+ " patientLinkTimestamp = :patientLinkTimestamp "
					+ " WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND "
					+ " bhcInvoiceOrderId = :bhcInvoiceOrderId";

			rowChanges = session.createQuery(hql)
					.setParameter("patientId",
							Integer.parseInt(req.getPatientId()))
					.setParameter("patientMRN", req.getPatientMRN())
					.setParameter("patientFirstName", req.getPatientFirstName())
					.setParameter("patientLastName", req.getPatientLastName())
					.setParameter("patientDOB",
							CommonUtils.formatStringToLocalDate(req.getPatientDOB()))
					.setParameter("bhcMedicalRecordId",
							Integer.parseInt(req.getBhcMedicalRecordId()))
					.setParameter("bhcInvoiceOrderId",
							Integer.parseInt(req.getBhcInvoiceOrderId()))
					.setParameter("patientLinked", req.getPatientLinked())
					.setParameter("patientLinkUsername",
							req.getPatientLinkUsername())
					.setParameter("patientLinkUserId",
							Long.valueOf(req.getPatientLinkUserId()))
					.setParameter("patientLinkUserFullname",
							req.getPatientLinkUserFullname())
					.setParameter("patientLinkTimestamp", currentTime)
					.executeUpdate();

		} catch (Exception e) {
			log.error("Exception occured while updating patient details in DB: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return rowChanges;
	}

	private String getFileTypeForS3(String doctype) {
		String fileType = "";
		switch (doctype) {
			case "ProviderOrders" :
				fileType = "ProviderOrder";
				break;
			case "WoundAssessments" :
				fileType = "Assessment";
				break;
			case "ProgressNotes" :
				fileType = "ProgressNote";
				break;
			case "Debridements" :
				fileType = "ProcedureNote";
				break;
			case "CustomScans" :
				fileType = "CustomScans";
				break;
			// Manual Attach Doc Type
			case "Provider Orders" :
				fileType = "ProviderOrder";
				break;
			case "Wound Assessment" :
				fileType = "Assessment";
				break;
			case "Progress Note" :
				fileType = "ProgressNote";
				break;
			case "Procedure Note" :
				fileType = "ProcedureNote";
				break;
			case "Multi-Wound Chart" :
				fileType = "Assessment";
				break;
			default :
				break;
		}
		return fileType;
	}
	
	private String removeSpecialCharacters(String fileName) {
		try {
			if (fileName != null && !fileName.trim().isEmpty()) {
				return fileName.replaceAll("[<>:\"/\\\\|?* ]", "");
			}
		} catch (Exception e) {
			System.out.println("An error occurred in removeSpecialCharacters: " + e.getMessage());
		}
		return fileName;
	}

}