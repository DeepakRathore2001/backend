package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.PDFDAO;
import com.healogics.rtrv.dto.DocumentNameObj;
import com.healogics.rtrv.entity.DocumentName;
import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class PDFDAOImpl implements PDFDAO {
	private final Logger log = LoggerFactory.getLogger(PDFDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public PDFDAOImpl(@Qualifier("SessionFactory1")SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public DocumentStatus getDocumentDetails(String clientState) {
		Session session = this.sessionFactory.getCurrentSession();
		DocumentStatus documentStatus = null;
		try {
			String awdHql = "FROM DocumentStatus d WHERE d.clientState = :clientState";

			documentStatus = session.createQuery(awdHql, DocumentStatus.class)
					.setParameter("clientState", clientState).setMaxResults(1)
					.uniqueResult();

		} catch (Exception e) {
			log.error("Exception occured in getDocumentDetails: {}",
					e.getMessage());
		}
		return documentStatus;
	}

	@Override
	public boolean saveDocPDFGetStatus(String clientState, String docStatus) {
		Session session = this.sessionFactory.getCurrentSession();
		boolean status = false;
		try {
			String hql = "UPDATE DocumentStatus r SET r.docPDFGetStatus=:docPDFGetStatus,"
					+ " r.lastUpdatedTimestamp = :lastUpdatedTimestamp,"
					+ " r.docUploadStatus = :docUploadStatus, "
					+ " r.lastUpdatedUsername = :lastUpdatedUsername,"
					+ " r.lastUpdatedUserId = :lastUpdatedUserId,"
					+ " r.docPdfGetTimestamp = :docPdfGetTimestamp,"
					+ " r.getPDFResponseTimestamp = :getPDFResponseTimestamp,"
					+ " r.sendToByramStatus = :sendToByramStatus,"
					+ " r.sendToS3Timestamp = :sendToS3Timestamp"
					+ " where r.clientState = :clientState";

			Query query = session.createQuery(hql);

			query.setParameter("docPDFGetStatus", docStatus);
			query.setParameter("lastUpdatedTimestamp", LocalDateTime.now());
			query.setParameter("lastUpdatedUsername", "DocPDFGet Service");
			query.setParameter("lastUpdatedUserId", 0L);
			query.setParameter("docUploadStatus", docStatus);
			query.setParameter("docPdfGetTimestamp", LocalDateTime.now());
			query.setParameter("getPDFResponseTimestamp", LocalDateTime.now());
			query.setParameter("sendToByramStatus", docStatus);
			query.setParameter("sendToS3Timestamp", LocalDateTime.now());

			query.setParameter("clientState", clientState);

			query.executeUpdate();

		} catch (Exception e) {
			log.error("Exception occured while saveDocPDFGetStatus: {}",
					e.getMessage());
		}

		return status;
	}

	@Override
	public boolean saveSendToS3Status(String clientState, String s3Status)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		boolean status = false;
		try {
			String hql = "UPDATE DocumentStatus r SET r.sendToByramStatus=:sendToByramStatus,"
					+ " r.lastUpdatedTimestamp = :lastUpdatedTimestamp,"
					+ " r.lastUpdatedUsername = :lastUpdatedUsername,"
					+ " r.lastUpdatedUserId = :lastUpdatedUserId,"
					+ " r.docUploadStatus = :docUploadStatus, "
					+ " r.sendToS3Timestamp = :sendToS3Timestamp"
					+ " where r.clientState = :clientState";

			Query query = session.createQuery(hql);

			query.setParameter("sendToByramStatus", s3Status);
			query.setParameter("lastUpdatedTimestamp", LocalDateTime.now());
			query.setParameter("lastUpdatedUsername", "UploadtoS3 Service");
			query.setParameter("lastUpdatedUserId", 0L);
			query.setParameter("docUploadStatus", s3Status);
			query.setParameter("sendToS3Timestamp", LocalDateTime.now());

			query.setParameter("clientState", clientState);

			query.executeUpdate();
			status = true;
			log.debug("save sendToS3Status in DB...........................");
		} catch (Exception e) {
			log.error("Exception occured while saveSendToS3Status: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}

		return status;
	}

	@Override
	public Long getDocumentId(Long bhcMedRecId, Long bhcInvOrderNo,
			String docType, Date visitDate) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<Long> documentIdList = new ArrayList<>();
		try {
			String hql = "SELECT a.documentId" + " FROM DocumentName a "
					+ " WHERE a.bhcMedRecId = :bhcMedRecId "
					+ " AND a.bhcInvOrderNo = :bhcInvOrderNo"
					+ " AND a.documentType = :documentType"
					+ " AND a.visitDate = :visitDate"
					+ " order by lastUpdatedTimestamp desc";

			documentIdList = session.createQuery(hql)
					.setParameter("bhcMedRecId", bhcMedRecId)
					.setParameter("bhcInvOrderNo", bhcInvOrderNo)
					.setParameter("documentType", docType)
					.setParameter("visitDate", visitDate).list();

		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return ((documentIdList != null && documentIdList.size() > 0)
				? documentIdList.get(0)
				: 0L);
	}

	@Override
	public Long getCustomScansDocumentId(Long bhcMedRecId, Long bhcInvOrderNo,
			String docType) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long documentId = 0L;
		try {
			String hql = "SELECT a.documentId" + " FROM DocumentName a "
					+ " WHERE a.bhcMedRecId = :bhcMedRecId "
					+ " AND a.bhcInvOrderNo = :bhcInvOrderNo"
					+ " AND a.documentType = :documentType"
					+ " order by lastUpdatedTimestamp desc";

			documentId = session.createQuery(hql, Long.class)
					.setParameter("bhcMedRecId", bhcMedRecId)
					.setParameter("bhcInvOrderNo", bhcInvOrderNo)
					.setParameter("documentType", docType).getSingleResult();

		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return documentId;
	}

	@Override
	public boolean saveDocumentId(DocumentNameObj doc, boolean firstTime)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			DocumentName docNameObj = new DocumentName();
			docNameObj.setBhcMedRecId(doc.getBhcMedRecId());
			docNameObj.setBhcInvOrderNo(doc.getBhcInvOrderNo());
			docNameObj.setDocumentType(doc.getDocumentType());
			docNameObj.setVisitDate(doc.getVisitDate());
			docNameObj.setDocumentId(doc.getDocumentId());

			docNameObj.setBhcPatientAcctNo(doc.getBhcPatientAcctNo());
			docNameObj.setBhcPatientInv(doc.getBhcPatientInv());
			docNameObj.setBhcShipDate(doc.getBhcShipDate());
			docNameObj.setBluebookId(doc.getBluebookId());
			docNameObj.setDateDocSent(doc.getDateDocSent());
			docNameObj.setFacilityId(doc.getFacilityId());
			docNameObj.setFacilityName(doc.getFacilityName());

			if (firstTime) {
				docNameObj.setCreatedTimestamp(
						new Timestamp(System.currentTimeMillis()));
				docNameObj.setCreatedUserFullname(doc.getCreatedUserFullname());
				docNameObj.setCreatedUserId(doc.getCreatedUserId());
				docNameObj.setCreatedUsername(doc.getCreatedUsername());
				docNameObj.setLastUpdatedByUserFullname(
						doc.getLastUpdatedByUserFullname());
				docNameObj.setLastUpdatedByUserId(doc.getLastUpdatedByUserId());
				docNameObj.setLastUpdatedByUsername(
						doc.getLastUpdatedByUsername());
				docNameObj.setLastUpdatedTimestamp(
						new Timestamp(System.currentTimeMillis()));
			} else {
				docNameObj.setLastUpdatedByUserFullname(
						doc.getLastUpdatedByUserFullname());
				docNameObj.setLastUpdatedByUserId(doc.getLastUpdatedByUserId());
				docNameObj.setLastUpdatedByUsername(
						doc.getLastUpdatedByUsername());
				docNameObj.setLastUpdatedTimestamp(
						new Timestamp(System.currentTimeMillis()));
			}

			docNameObj.setPatientFirstName(doc.getPatientFirstName());
			docNameObj.setPatientLastName(doc.getPatientLastName());

			log.info("docNameObj in saveDocumentId : {}", docNameObj);
			session.save(docNameObj);

		} catch (Exception e) {
			log.error("Exception occured in saveDocumentId: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return true;
	}

	/*
	 * @Override public void saveDocumentationHistory(Long bhcMedRecId, Long
	 * bhcInvoiceOrderNo, String filename, String documentUUID) throws Exception
	 * { Session session = this.sessionFactory.getCurrentSession(); try { Long
	 * bhcMedicalRecordId = new Long(bhcMedRecId); Long bhcInvoiceOrderId = new
	 * Long(bhcInvoiceOrderNo); log.debug("documentationNoteId............");
	 * log.debug("inside documentation history PDFDAOImpl"); String docHql =
	 * "From AWDDashboard WHERE bhcMedicalRecordId = :bhcMedicalRecordId AND " +
	 * " bhcInvoiceOrderId = :bhcInvoiceOrderId"; AWDDashboard dashboard =
	 * session .createQuery(docHql, AWDDashboard.class)
	 * .setParameter("bhcMedicalRecordId", bhcMedicalRecordId.intValue())
	 * .setParameter("bhcInvoiceOrderId", bhcInvoiceOrderId.intValue())
	 * .uniqueResult(); String bhcDocStatus = ""; if (dashboard != null) {
	 * bhcDocStatus = dashboard.getBhcDocumentStatus(); }
	 * log.debug("bhcDOcStatus:   " + bhcDocStatus); String docHQL =
	 * "FROM DocumentationHistory WHERE documentId = :documentUUID";
	 * DocumentationHistory history = session .createQuery(docHQL,
	 * DocumentationHistory.class) .setParameter("documentUUID",
	 * documentUUID).uniqueResult();
	 * 
	 * String bhcMissingDocNotes = ""; if (history != null) { bhcMissingDocNotes
	 * = history.getBhcMissingDocNotes(); } log.debug("bhcMissingDocNotes:  " +
	 * bhcMissingDocNotes); if (bhcMissingDocNotes.isEmpty()) { filename =
	 * bhcMissingDocNotes + filename; } else { filename = bhcMissingDocNotes +
	 * "#" + filename; }
	 * 
	 * log.debug("inside documentation history PDFDAOImpl2 and filename..." +
	 * filename); String hql =
	 * "UPDATE DocumentationHistory set bhcMissingDocNotes = :filename, " +
	 * " lastUpdatedTimestamp = :lastUpdatedTimestamp, " +
	 * " bhcDocumentStatus = :bhcDocumentStatus " +
	 * " WHERE documentId = :documentUUID "; int rowChanges =
	 * session.createQuery(hql) .setParameter("lastUpdatedTimestamp", new
	 * Timestamp(System.currentTimeMillis())) .setParameter("bhcDocumentStatus",
	 * bhcDocStatus) .setParameter("filename", filename)
	 * .setParameter("documentUUID", documentUUID).executeUpdate();
	 * 
	 * log.debug( "Updated Documentation History>.............." + filename); }
	 * catch (Exception e) {
	 * log.error("Exception occured in saveDocumentationHistory: " +
	 * e.getMessage()); throw new Exception(e.getMessage()); }
	 * 
	 * }
	 */
}
