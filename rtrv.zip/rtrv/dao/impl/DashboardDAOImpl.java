package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.bo.AppNotificationBO;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.DashboardDAO;
import com.healogics.rtrv.dto.AWDData;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.FilterOptions;
import com.healogics.rtrv.dto.MedicalRecodInvoiceDetails;
import com.healogics.rtrv.dto.SetStatusReq;
import com.healogics.rtrv.dto.SetStatusRes;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.entity.AWDDashboard;
import com.healogics.rtrv.entity.DocumentationHistory;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;
import com.healogics.rtrv.utils.FilterRequestUtil;

@Repository
@TransactionManager1
public class DashboardDAOImpl implements DashboardDAO {
	private final Logger log = LoggerFactory.getLogger(DashboardDAOImpl.class);

	private final AppNotificationBO appNotificationBO;

	private final SessionFactory sessionFactory;

	@Autowired
	public DashboardDAOImpl(AppNotificationBO appNotificationBO,
			@Qualifier("SessionFactory1") SessionFactory sessionFactory) {
		this.appNotificationBO = appNotificationBO;
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<AWDDashboard> getAllAWDRecords(boolean isExcel,
			DashboardReq req, int offset, String taskType, String assignee, Boolean isSuperUser)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<AWDDashboard> awdDashboard = new ArrayList<>();

		try {
			String hql = "FROM AWDDashboard a WHERE 1 = 1";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.status NOT IN ('Submitted','Exhausted','Completed','Closed') ";
			}
			
			
			if(!isSuperUser) {
				hql += " AND a.bbc NOT IN ('X2 - UAT','x2W360','x-Clin Op Demo') ";
			} 

			if (taskType != null && taskType.equalsIgnoreCase("NEW")) {
				hql += " AND a.status ='NEW'";

			} else if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				
				hql += " AND active = 1";

				hql += " AND a.assignee ='" + req.getUsername() + "'"
						+ " AND ((a.status = 'MedAdv')"
						+ " OR (a.status != 'MedAdv' AND a.bhcDocumentStatus NOT IN ('API - RECEIVED', 'RECEIVED','API - PROGRESS NOTES RECEIVED', 'PENDING ADDITIONAL REVIEW')  "
						+ " AND ((a.bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '9')  "
						+ " OR (a.bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '21') "
						+ " OR (a.bhcPrimaryInsurance = 'Medicare' AND a.bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
						+ " OR (a.bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED'))))"
						+ " OR (a.status = 'MedAdv' AND a.bhcDocumentStatus IN ('API - RECEIVED', 'RECEIVED','API - PENDING', 'PENDING ADDITIONAL REVIEW')))";
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by a.bbc asc";
			}

			log.info("query : {}", hql.toString());

			if (isExcel) {
				awdDashboard = session.createQuery(hql).list();
			} else {
				awdDashboard = session.createQuery(hql).setFirstResult(offset)
						.setMaxResults(PAGE_SIZE).list();
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return awdDashboard;
	}

	private String sortList(DashboardReq req, String hql) {

		if (req.getSortBy().equalsIgnoreCase("assignedTo")) {
			hql += " order by a.assigneeFullName ";

		} else if (req.getSortBy().equalsIgnoreCase("vendor")) {
			return hql;

		} else if (req.getSortBy().equalsIgnoreCase("iHealConfiguration")) {
			// String[] patientArr = req.getSortBy().split(", ");
			// String patientLastName = patientArr[0];
			hql += " order by a.facilityType ";

		} else if (req.getSortBy().equalsIgnoreCase("patientName")) {
			// String[] patientArr = req.getSortBy().split(", ");
			// String patientLastName = patientArr[0];
			hql += " order by a.patientFullname ";

		} else if (req.getSortBy().equalsIgnoreCase("providerName")) {
			hql += " order by a.providerFullname ";

		} else if (req.getSortBy().equalsIgnoreCase("bhcMedRecId")) {

			hql += " order by a.bhcMedicalRecordId ";

		} else if (req.getSortBy().equalsIgnoreCase("age")) {

			hql += " order by a.firstReceived ";

		} else if (req.getSortBy().equalsIgnoreCase("bhcDocStatus")) {

			hql += " order by a.bhcDocumentStatus ";

		} else if (req.getSortBy().equalsIgnoreCase("insuranceType")) {

			hql += " order by a.bhcPrimaryInsurance ";

		}else if (req.getSortBy().equalsIgnoreCase("bhcLastUpdateDate")) {

			hql += " order by a.bhcLastUpdated ";

		} else {
			hql += " order by a." + req.getSortBy() + "";

		}
		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public Long getAWDNewTaskCount() throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;

		try {
			String hql = "SELECT count(*) FROM AWDDashboard a WHERE 1 = 1"
					+ " AND a.status='NEW'";

			taskCount = (Long) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching new task count: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return taskCount;
	}

	@Override
	public Long getTotalCount(int offset, String taskType, String assignee,
			DashboardReq req, Boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;

		try {
			String hql = "SELECT count(*) FROM AWDDashboard a WHERE 1 = 1";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.status NOT IN ('Submitted','Exhausted','Completed','Closed') ";
			}
			
		
				if(!isSuperUser) {
					hql += " AND a.bbc NOT IN ('X2 - UAT','x2W360','x-Clin Op Demo') ";
				}

			if (taskType != null && taskType.equalsIgnoreCase("NEW")) {
				hql += " AND a.status ='NEW'";

			} else if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				/*
				 * hql += " AND a.assignee ='" + assignee + "'" +
				 * " AND a.bhcDocumentStatus != 'API - RECEIVED' " +
				 * " AND a.bhcDocumentStatus != 'RECEIVED' " +
				 * " AND a.bhcDocumentStatus != 'API - PROGRESS NOTES RECEIVED' "
				 * + " AND a.bhcDocumentStatus != 'PENDING ADDITIONAL REVIEW'" +
				 * " AND ((a.bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '9')  "
				 * +
				 * " OR (a.bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '21') "
				 * +
				 * " OR (a.bhcPrimaryInsurance = 'Medicare' AND a.bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
				 * +
				 * " OR (a.bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED')))"
				 * ;
				 */
				
				hql += " AND active = 1";

				hql += " AND a.assignee ='" + req.getUsername() + "'"
						+ " AND ((a.status = 'MedAdv')"
						+ " OR (a.status != 'MedAdv' AND a.bhcDocumentStatus NOT IN ('API - RECEIVED', 'RECEIVED','API - PROGRESS NOTES RECEIVED', 'PENDING ADDITIONAL REVIEW')  "
						+ " AND ((a.bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '9')  "
						+ " OR (a.bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '21') "
						+ " OR (a.bhcPrimaryInsurance = 'Medicare' AND a.bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
						+ " OR (a.bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED'))))"
						+ " OR (a.status = 'MedAdv' AND a.bhcDocumentStatus IN ('API - RECEIVED', 'RECEIVED','API - PENDING', 'PENDING ADDITIONAL REVIEW')))";
			}

			totalCount = (Long) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching total count : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public FilterOptions getFilterOptions(DashboardReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		FilterOptions filterOptions = new FilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		List<String> optionList = new ArrayList<>();
		try {
			//Fetching User Role
			Boolean isSuperUser = getRetrieveUser(req.getUserId(), req.getUsername());
			
			// Fetching user facilities from DB
			List<UserFacilities> facilities = getUserFacilities(req.getUserId(), req.getUsername());
			List<String> userBBC = new ArrayList<>();
			if(facilities != null && !facilities.isEmpty()) {
				for(UserFacilities fac : facilities) {
					if(!isSuperUser) {
						if(!fac.getFacilityId().equalsIgnoreCase("2636") &&
								!fac.getFacilityId().equalsIgnoreCase("3196")) {
						userBBC.add(fac.getFacilityBluebookId());
						}
					} else {
						userBBC.add(fac.getFacilityBluebookId());
					}
				}
			}
			if(userBBC.isEmpty()) {
				userBBC.add("Test");
			}   
			String query = " WHERE 1 = 1 AND bbc IN :userBBC ";
			String filterColumn = req.getFilterOptions();

			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {
				/*
				 * query += " AND assignee ='" + req.getUsername() + "'" +
				 * " AND bhcDocumentStatus != 'API - RECEIVED' " +
				 * " AND bhcDocumentStatus != 'RECEIVED' " +
				 * " AND bhcDocumentStatus != 'API - PROGRESS NOTES RECEIVED'" +
				 * " AND bhcDocumentStatus != 'PENDING ADDITIONAL REVIEW'" +
				 * " AND ((bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), medicalRecordAddedDate) >= '9')  "
				 * +
				 * " OR (bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), medicalRecordAddedDate) >= '21') "
				 * +
				 * " OR (bhcPrimaryInsurance = 'Medicare' AND bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
				 * +
				 * " OR (bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED')))"
				 * ;
				 */
				
				query = "WHERE 1 = 1 AND bbc IN :userBBC AND active = 1";

				query += " AND assignee ='" + req.getUsername() + "'"						
			        	+ " AND ((status = 'MedAdv') "
						+ " OR (status != 'MedAdv' AND bhcDocumentStatus NOT IN ('API - RECEIVED', 'RECEIVED','API - PROGRESS NOTES RECEIVED', 'PENDING ADDITIONAL REVIEW')  "
						+ " AND ((bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), medicalRecordAddedDate) >= '9')  "
						+ " OR (bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), medicalRecordAddedDate) >= '21') "
						+ " OR (bhcPrimaryInsurance = 'Medicare' AND bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
						+ " OR (bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED'))))"
						+ " OR (status = 'MedAdv' AND bhcDocumentStatus IN ('API - RECEIVED', 'RECEIVED','API - PENDING', 'PENDING ADDITIONAL REVIEW')))";
			}

			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcList = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							query += " bbc IN :bbc ";
							parameters.put("bbc", bbcList);
						}
							break;
						case "bhcReferralId" : {
							List<String> bhcReferralIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcReferralId());
							query += " bhcReferralId IN :bhcReferralId ";
							parameters.put("bhcReferralId", bhcReferralIdList);
						}
							break;

						case "bhcDocStatus" : {
							List<String> bhcDocStatusList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcDocStatus());
							query += " bhcDocumentStatus IN :bhcDocumentStatus ";
							parameters.put("bhcDocumentStatus",
									bhcDocStatusList);
						}
							break;

						case "bhcMissingDocNotes" : {
							List<String> bhcMissingDocNotesList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcMissingDocNotes());
							query += " bhcMissingDocNotes IN :bhcMissingDocNotes ";
							parameters.put("bhcMissingDocNotes",
									bhcMissingDocNotesList);
						}
							break;

						case "insuranceType" : {
							List<String> insuranceTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getInsuranceType());
							query += " bhcPrimaryInsurance IN :bhcPrimaryInsurance ";
							parameters.put("bhcPrimaryInsurance",
									insuranceTypeList);
						}
							break;

						case "vendor" : {
							query += " 1 = 1 ";
						}
							break;

						case "bhcInvoiceOrderId" : {
							List<String> bhcInvoiceOrderIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcInvoiceOrderId());
							List<Integer> intInvoiceList = new ArrayList<>();
							for (String s : bhcInvoiceOrderIdList) {
								intInvoiceList.add(Integer.valueOf(s));
							}
							query += " bhcInvoiceOrderId IN :bhcInvoiceOrderId ";
							parameters.put("bhcInvoiceOrderId", intInvoiceList);
						}
							break;

						case "bhcMedRecId" : {
							List<String> bhcMedicalRecordIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcMedRecId());
							List<Integer> intMedicalList = new ArrayList<>();
							for (String s : bhcMedicalRecordIdList) {
								intMedicalList.add(Integer.valueOf(s));
							}
							query += " bhcMedicalRecordId IN :bhcMedicalRecordId ";
							// log.debug("bhcMedRecId HQL: " + query);
							parameters.put("bhcMedicalRecordId",
									intMedicalList);
						}
							break;

						case "age" : {
							// hql += " 1 = 1 ";

							query += " firstReceived BETWEEN :firstReceivedStartDate AND :firstReceivedEndDate ";
							parameters.put("firstReceivedStartDate", dateFormat
									.parse(req.getFirstReceivedStartDate()));
							parameters.put("firstReceivedEndDate", dateFormat
									.parse(req.getFirstReceivedEndDate()));
						}
							break;

						case "assignedTo" : {
							// if (!req.getTaskType().equalsIgnoreCase("MY")) {
							List<String> assignedToList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getAssignedTo());
							query += " assigneeFullName IN :assignedTo ";
							parameters.put("assignedTo", assignedToList);
							// }
						}
							break;

						case "bhcOrderSource" : {
							List<String> bhcOrderSourceList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcOrderSource());
							query += " bhcOrderSource IN :bhcOrderSource ";
							parameters.put("bhcOrderSource",
									bhcOrderSourceList);
						}
							break;

						case "iHealConfiguration" : {
							// query += " 1 = 1 ";
							List<String> facTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getiHealConfiguration());
							query += " facilityType IN :facilityType ";
							parameters.put("facilityType", facTypeList);
						}
							break;

						case "status" : {
							List<String> statusList = FilterRequestUtil
									.getListFromDelimitedStr(req.getStatus());
							query += " status IN :status ";
							parameters.put("status", statusList);
						}
							break;

						case "patientName" : {
							List<String> patientNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getPatientName());

							String[] patientArr = null;
							List<String> patientFirstNames = new ArrayList<>();
							List<String> patientLastNames = new ArrayList<>();

							for (String patient : patientNameList) {
								patientArr = patient.split(", ");

								if (patientArr.length >= 2) {
									patientLastNames.add(patientArr[0].trim());
									patientFirstNames.add(patientArr[1].trim());
								}
							}

							query += " patientLastName IN :patientLastNames  AND patientFirstName IN :patientFirstNames";
							parameters.put("patientLastNames",
									patientLastNames);
							parameters.put("patientFirstNames",
									patientFirstNames);
						}
							break;

						case "patientDOB" : {
							query += " patientDOB = :patientDOB";
							parameters.put("patientDOB",
									CommonUtils.formatStringToLocalDate(
											req.getPatientDOB()));
						}
							break;

						case "followupDate" : {
							query += " followupDate BETWEEN :followupStartDate AND :followupEndDate ";
							parameters.put("followupStartDate", dateFormat
									.parse(req.getFollowupStartDate()));
							parameters.put("followupEndDate",
									dateFormat.parse(req.getFollowupEndDate()));
						}
							break;

						case "bhcOrderReceivedDate" : {
							query += " bhcOrderReceivedDate BETWEEN :bhcOrderReceivedStartDate AND :bhcOrderReceivedEndDate ";
							parameters.put("bhcOrderReceivedStartDate",
									dateFormat.parse(req
											.getBhcOrderReceivedStartDate()));
							parameters.put("bhcOrderReceivedEndDate", dateFormat
									.parse(req.getBhcOrderReceivedEndDate()));
						}
							break;

						case "lastTeamUpdated" : {

							if (req.getCustomDates()) {
								log.debug("isCustomDate should be true : {}",
										req.getCustomDates());
								query += " lastTeamUpdated BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate ";
								log.debug("lastTeamUpdated:  " + query);
								parameters.put("lastTeamUpdatedStartDate",
										dateFormat.parse(req
												.getLastTeamUpdatedStartDate()));
								parameters.put("lastTeamUpdatedEndDate",
										dateFormat.parse(req
												.getLastTeamUpdatedEndDate()));

							} else {
								log.debug("isCustomDate should be false : {}",
										req.getCustomDates());
								String[] dateFilter = req.getDateFilters()
										.split("#");
								boolean firstFilter = true;
								for (String filter : dateFilter) {
									if (firstFilter) {
										firstFilter = false;
										query += " ( ";
									} else {
										query += " OR ";
									}

									if (filter.equalsIgnoreCase("today")
											&& req.getTodayMinDate() != null
											&& !req.getTodayMinDate().isEmpty()
											&& req.getTodayMaxDate() != null
											&& !req.getTodayMaxDate()
													.isEmpty()) {
										query += " (lastTeamUpdated >= :todayMinDate AND lastTeamUpdated <= :todayMaxDate )";
										parameters.put("todayMinDate",
												dateFormat.parse(
														req.getTodayMinDate()));
										parameters.put("todayMaxDate",
												dateFormat.parse(
														req.getTodayMaxDate()));
									}
									if (filter.equalsIgnoreCase("yesterday")
											&& req.getYesterdayMinDate() != null
											&& !req.getYesterdayMinDate()
													.isEmpty()
											&& req.getYesterdayMaxDate() != null
											&& !req.getYesterdayMaxDate()
													.isEmpty()) {
										query += " (lastTeamUpdated >= :yesterdayMinDate AND lastTeamUpdated <= :yesterdayMaxDate)";
										parameters.put("yesterdayMinDate",
												dateFormat.parse(req
														.getYesterdayMinDate()));
										parameters.put("yesterdayMaxDate",
												dateFormat.parse(req
														.getYesterdayMaxDate()));
									}
									if (filter.equalsIgnoreCase("thisWeek")
											&& req.getThisWeekMinDate() != null
											&& !req.getThisWeekMinDate()
													.isEmpty()
											&& req.getThisWeekMaxDate() != null
											&& !req.getThisWeekMaxDate()
													.isEmpty()) {
										query += " (lastTeamUpdated >= :thisWeekMinDate AND lastTeamUpdated <= :thisWeekMaxDate)";
										parameters.put("thisWeekMinDate",
												dateFormat.parse(req
														.getThisWeekMinDate()));
										parameters.put("thisWeekMaxDate",
												dateFormat.parse(req
														.getThisWeekMaxDate()));
									}
									if (filter.equalsIgnoreCase("lastWeek")
											&& req.getLastWeekMinDate() != null
											&& !req.getLastWeekMinDate()
													.isEmpty()
											&& req.getLastWeekMaxDate() != null
											&& !req.getLastWeekMaxDate()
													.isEmpty()) {
										query += " (lastTeamUpdated >= :lastWeekMinDate AND lastTeamUpdated <= :lastWeekMaxDate)";
										parameters.put("lastWeekMinDate",
												dateFormat.parse(req
														.getLastWeekMinDate()));
										parameters.put("lastWeekMaxDate",
												dateFormat.parse(req
														.getLastWeekMaxDate()));
									}

								}
								query += " ) ";
								log.debug("lastTeamUpdated:  {} ", query);
							}

						}
							break;

						case "bhcPatientAcctId" : {
							List<String> bhcPatientAcctIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcPatientAcctId());
							List<Integer> intAcctList = new ArrayList<>();
							for (String s : bhcPatientAcctIdList) {
								intAcctList.add(Integer.valueOf(s));
							}
							query += " bhcPatientAcctId IN :bhcPatientAcctId ";
							parameters.put("bhcPatientAcctId", intAcctList);
						}
							break;

						case "providerName" : {
							List<String> providerFullnameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getProviderName());
							query += " providerFullname IN :providerFullname ";
							parameters.put("providerFullname",
									providerFullnameList);
						}
							break;

						case "bhcShipDate" : {
							query += " bhcShipDate BETWEEN :bhcShipStartDate AND :bhcShipEndDate ";
							parameters.put("bhcShipStartDate", dateFormat
									.parse(req.getBhcShipStartDate()));
							parameters.put("bhcShipEndDate",
									dateFormat.parse(req.getBhcShipEndDate()));
						}
							break;
						case "bhcLastUpdateDate" : {
							query += " bhcLastUpdated BETWEEN :bhcLastStartDate AND :bhcLastEndDate ";
							parameters.put("bhcLastStartDate", dateFormat
									.parse(req.getBhcLastUpdateStartDate()));
							parameters.put("bhcLastEndDate",
									dateFormat.parse(req.getBhcLastUpdateEndDate()));
						}
							break;

						default :
							break;
					}
				}
			}

			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			if (req.getFilterOptions().equalsIgnoreCase("assignedTo")) {
				filterColumn = "assigneeFullName";
			}
			if (req.getFilterOptions().equalsIgnoreCase("providerName")) {
				filterColumn = "providerFullname";
			}
			if (req.getFilterOptions().equalsIgnoreCase("bhcDocStatus")) {
				filterColumn = "bhcDocumentStatus";
			}
			if (req.getFilterOptions().equalsIgnoreCase("insuranceType")) {
				filterColumn = "bhcPrimaryInsurance";
			}
			if (req.getFilterOptions().equalsIgnoreCase("iHealConfiguration")) {
				filterColumn = "facilityType";
			}

			if (req.getFilterOptions().equalsIgnoreCase("vendor")) {
				if (req.getIsDataEmpty() == null) {
					optionList.add(0, "Byram");
				} else if (req.getIsDataEmpty() == true) {
					optionList.add(0, null);
				} else if (req.getIsDataEmpty() == false) {
					optionList.add(0, "Byram");
				}

				filterOptions.setOptions(optionList);
				filterOptions.getOptions().removeIf(element -> element == null);
			} else if (req.getFilterOptions().equalsIgnoreCase("age")) {

				String dateHql = "SELECT MIN(firstReceived),"
						+ " MAX(firstReceived) FROM AWDDashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinFirstReceivedDate((Date) object[0]);
				filterOptions.setMaxFirstReceivedDate((Date) object[1]);

			} /*
				 * else if (req.getFilterOptions()
				 * .equalsIgnoreCase("iHealConfiguration")) { if
				 * (req.getIsDataEmpty() == null) { optionList.add(0, "EMR"); }
				 * else if (req.getIsDataEmpty() == true) { optionList.add(0,
				 * null); } else if (req.getIsDataEmpty() == false) {
				 * optionList.add(0, "EMR"); }
				 * filterOptions.setOptions(optionList);
				 * filterOptions.getOptions().removeIf(element -> element ==
				 * null);
				 * 
				 * }
				 */ else if (req.getFilterOptions()
					.equalsIgnoreCase("bhcInvoiceOrderId")) {
				hql = "SELECT DISTINCT CAST(bhcInvoiceOrderId as string) FROM AWDDashboard "
						+ query + " ORDER BY bhcInvoiceOrderId asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);

			} else if (req.getFilterOptions().equalsIgnoreCase("bhcMedRecId")) {
				hql = "SELECT DISTINCT CAST(bhcMedicalRecordId as string) FROM AWDDashboard "
						+ query + " ORDER BY bhcMedicalRecordId asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);

			} else if (req.getFilterOptions()
					.equalsIgnoreCase("bhcPatientAcctId")) {
				hql = "SELECT DISTINCT CAST(bhcPatientAcctId as string) FROM AWDDashboard "
						+ query + " ORDER BY bhcPatientAcctId asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);

			} else if (req.getFilterOptions().equalsIgnoreCase("patientName")) {
				hql = "SELECT DISTINCT CONCAT(patientLastName,', ',patientFirstName) FROM AWDDashboard "
						+ query + " ORDER BY patientFullname asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);

			} else if (req.getFilterOptions()
					.equalsIgnoreCase("lastTeamUpdated")) {
				String dateHql = "SELECT MIN(lastTeamUpdated), MAX(lastTeamUpdated) FROM AWDDashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinLastTeamUpdatedDate((Date) object[0]);
				filterOptions.setMaxLastTeamUpdatedDate((Date) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("bhcLastUpdateDate")) {
				String dateHql = "SELECT MIN(bhcLastUpdated), MAX(bhcLastUpdated) FROM AWDDashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinBhcLastUpdateDate((Date) object[0]);
				filterOptions.setMaxBhclastUpdateDate((Date) object[1]);

			} else if (req.getFilterOptions().equalsIgnoreCase("bhcShipDate")) {
				String dateHql = "SELECT MIN(bhcShipDate), MAX(bhcShipDate) FROM AWDDashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinBhcShipDate((Date) object[0]);
				filterOptions.setMaxBhcShipDate((Date) object[1]);

			} /*
				 * else if (req.getFilterOptions()
				 * .equalsIgnoreCase("bhcOrderReceivedDate")) { String dateHql =
				 * "SELECT MIN(bhcOrderReceivedDate), MAX(bhcOrderReceivedDate) FROM AWDDashboard "
				 * + query + ""; log.debug("dateHql:  {}" , dateHql); Object[]
				 * object = (Object[]) session.createQuery(dateHql)
				 * .setProperties(parameters).uniqueResult();
				 * 
				 * filterOptions.setMinBhcOrderReceivedDate((Date) object[0]);
				 * filterOptions.setMaxBhcOrderReceivedDate((Date) object[1]); }
				 */ else if (req.getFilterOptions()
					.equalsIgnoreCase("followupDate")) {
				String dateHql = "SELECT MIN(followupDate), MAX(followupDate) FROM AWDDashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinFollowupDate((Date) object[0]);
				filterOptions.setMaxFollowupDate((Date) object[1]);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM AWDDashboard "
						+ query + " ORDER BY " + filterColumn + " asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null
						|| (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching filter options : {}",
					e.getMessage());
			e.printStackTrace();
			throw new CustomException(e.getMessage());
		}
		return filterOptions;
	}

	@Override
	public Map<String, Object> getFileredAWDList(boolean isExcel,
			DashboardReq req, int offset, String taskType, String assignee, Boolean isSuperUser)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<AWDDashboard> awdDashboard = new ArrayList<>();
		List<AWDDashboard> allAWDList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String hql = "FROM AWDDashboard a WHERE 1 = 1 ";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.status NOT IN ('Submitted','Exhausted','Completed','Closed') ";
			}

			if(!isSuperUser) {
				hql += " AND a.bbc NOT IN ('X2 - UAT','x2W360','x-Clin Op Demo') ";
			} 
			
			if (req.getTaskType() != null
					&& req.getTaskType().equalsIgnoreCase("MY")) {

				/*
				 * hql += " AND assignee ='" + req.getUsername() + "'" +
				 * " AND a.bhcDocumentStatus NOT IN ('API - RECEIVED', 'RECEIVED','API - PROGRESS NOTES RECEIVED', 'PENDING ADDITIONAL REVIEW')  "
				 * +
				 * " AND ((a.bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '9')  "
				 * +
				 * " OR (a.bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '21') "
				 * +
				 * " OR (a.bhcPrimaryInsurance = 'Medicare' AND a.bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
				 * +
				 * " OR (a.bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED')))"
				 * ;
				 */
				
				hql += " AND active = 1";

				hql += " AND a.assignee ='" + req.getUsername() + "'"
						+ " AND ((a.status = 'MedAdv')"
						+ " OR (a.status != 'MedAdv' AND a.bhcDocumentStatus NOT IN ('API - RECEIVED', 'RECEIVED','API - PROGRESS NOTES RECEIVED', 'PENDING ADDITIONAL REVIEW')  "
						+ " AND ((a.bhcDocumentStatus = 'API - PENDING' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '9')  "
						+ " OR (a.bhcDocumentStatus = 'MISSING VALID RX' AND DATEDIFF(CURRENT_DATE(), a.medicalRecordAddedDate) >= '21') "
						+ " OR (a.bhcPrimaryInsurance = 'Medicare' AND a.bhcDocumentStatus = 'API – PARTIALLY RECEIVED') "
						+ " OR (a.bhcDocumentStatus NOT IN ('API - PENDING','MISSING VALID RX','API – PARTIALLY RECEIVED'))))"
						+ " OR (a.status = 'MedAdv' AND a.bhcDocumentStatus IN ('API - RECEIVED', 'RECEIVED','API - PENDING', 'PENDING ADDITIONAL REVIEW')))";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil
						.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
						case "bbc" : {
							List<String> bbcList = FilterRequestUtil
									.getListFromDelimitedStr(req.getBbc());
							hql += " (a.bbc IN :bbc) ";
							parameters.put("bbc", bbcList);
						}
							break;
						case "bhcReferralId" : {
							List<String> bhcReferralIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcReferralId());
							hql += " a.bhcReferralId IN :bhcReferralId ";
							parameters.put("bhcReferralId", bhcReferralIdList);
						}
							break;

						case "vendor" : {
							hql += " 1 = 1 ";
						}
							break;

						case "bhcInvoiceOrderId" : {
							List<String> bhcInvoiceOrderIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcInvoiceOrderId());
							List<Integer> intInvoiceList = new ArrayList<>();
							for (String s : bhcInvoiceOrderIdList) {
								intInvoiceList.add(Integer.valueOf(s));
							}
							hql += " (a.bhcInvoiceOrderId IN :bhcInvoiceOrderId) ";
							parameters.put("bhcInvoiceOrderId", intInvoiceList);
						}
							break;

						case "bhcMedRecId" : {
							List<String> bhcMedicalRecordIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcMedRecId());
							List<Integer> intMedicalList = new ArrayList<>();
							for (String s : bhcMedicalRecordIdList) {
								intMedicalList.add(Integer.valueOf(s));
							}
							hql += " (a.bhcMedicalRecordId IN :bhcMedicalRecordId) ";
							log.debug("bhcMedRecId HQL:  {}", hql);
							parameters.put("bhcMedicalRecordId",
									intMedicalList);
						}
							break;

						case "age" : {
							hql += " (a.firstReceived BETWEEN :firstReceivedStartDate AND :firstReceivedEndDate) ";
							parameters.put("firstReceivedStartDate", dateFormat
									.parse(req.getFirstReceivedStartDate()));
							parameters.put("firstReceivedEndDate", dateFormat
									.parse(req.getFirstReceivedEndDate()));
						}
							break;

						case "assignedTo" : {
							if (!taskType.equalsIgnoreCase("MY")) {
								List<String> assignedToList = FilterRequestUtil
										.getListFromDelimitedStr(
												req.getAssignedTo());
								hql += " (a.assigneeFullName IN :assignedTo) ";
								parameters.put("assignedTo", assignedToList);
							} else {
								hql += " 1 = 1 ";
							}
						}
							break;

						case "bhcOrderSource" : {
							List<String> bhcOrderSourceList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcOrderSource());
							hql += " (a.bhcOrderSource IN :bhcOrderSource) ";
							parameters.put("bhcOrderSource",
									bhcOrderSourceList);
						}
							break;

						case "bhcDocStatus" : {
							List<String> bhcDocStatusList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcDocStatus());
							hql += " (a.bhcDocumentStatus IN :bhcDocumentStatus) ";
							parameters.put("bhcDocumentStatus",
									bhcDocStatusList);
						}
							break;

						case "bhcMissingDocNotes" : {
							List<String> bhcMissingDocNotesList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcMissingDocNotes());
							hql += " (a.bhcMissingDocNotes IN :bhcMissingDocNotes) ";
							parameters.put("bhcMissingDocNotes",
									bhcMissingDocNotesList);
						}
							break;

						case "insuranceType" : {
							List<String> insuranceTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getInsuranceType());
							List<String> processedList = insuranceTypeList
									.stream().map(s -> (s.isEmpty()) ? "''" : s)
									.collect(Collectors.toList());
							hql += " (a.bhcPrimaryInsurance IN :bhcPrimaryInsurance) ";
							parameters.put("bhcPrimaryInsurance",
									processedList);
						}
							break;

						case "iHealConfiguration" : {
							// hql += " 1 = 1 ";
							List<String> facTypeList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getiHealConfiguration());
							hql += " (a.facilityType IN :facilityType) ";
							parameters.put("facilityType", facTypeList);
						}
							break;

						case "status" : {
							List<String> statusList = FilterRequestUtil
									.getListFromDelimitedStr(req.getStatus());
							hql += " a.status IN :status ";
							parameters.put("status", statusList);
						}
							break;

						case "patientName" : {
							List<String> patientNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getPatientName());

							String[] patientArr = null;
							List<String> patientFirstNames = new ArrayList<>();
							List<String> patientLastNames = new ArrayList<>();

							for (String patient : patientNameList) {
								patientArr = patient.split(", ");

								if (patientArr.length >= 2) {
									patientLastNames.add(patientArr[0].trim());
									patientFirstNames.add(patientArr[1].trim());
								}
							}

							hql += " a.patientLastName IN :patientLastNames  AND a.patientFirstName IN :patientFirstNames";
							parameters.put("patientLastNames",
									patientLastNames);
							parameters.put("patientFirstNames",
									patientFirstNames);
						}
							break;

						case "patientDOB" : {
							hql += " a.patientDOB = :patientDOB";
							parameters.put("patientDOB",
									CommonUtils.formatStringToLocalDate(
											req.getPatientDOB()));
						}
							break;

						case "bhcOrderReceivedDate" : {
							hql += " a.bhcOrderReceivedDate BETWEEN :bhcOrderReceivedStartDate AND :bhcOrderReceivedEndDate ";
							parameters.put("bhcOrderReceivedStartDate",
									dateFormat.parse(req
											.getBhcOrderReceivedStartDate()));
							parameters.put("bhcOrderReceivedEndDate", dateFormat
									.parse(req.getBhcOrderReceivedEndDate()));
						}
							break;

						case "followupDate" : {
							hql += " a.followupDate BETWEEN :followupStartDate AND :followupEndDate ";
							parameters.put("followupStartDate", dateFormat
									.parse(req.getFollowupStartDate()));
							parameters.put("followupEndDate",
									dateFormat.parse(req.getFollowupEndDate()));
						}
							break;

						case "lastTeamUpdated" : {

							if (req.getCustomDates()) {
								log.debug("isCustomDate should be true : {}",
										req.getCustomDates());
								hql += " a.lastTeamUpdated BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate ";
								log.debug("lastTeamUpdated:  {}", hql);
								parameters.put("lastTeamUpdatedStartDate",
										dateFormat.parse(req
												.getLastTeamUpdatedStartDate()));
								parameters.put("lastTeamUpdatedEndDate",
										dateFormat.parse(req
												.getLastTeamUpdatedEndDate()));

							} else {
								log.debug("isCustomDate should be false : {}",
										req.getCustomDates());
								String[] dateFilter = req.getDateFilters()
										.split("#");
								boolean firstFilter = true;
								for (String filter : dateFilter) {
									if (firstFilter) {
										firstFilter = false;
										hql += " ( ";
									} else {
										hql += " OR ";
									}

									if (filter.equalsIgnoreCase("today")
											&& req.getTodayMinDate() != null
											&& !req.getTodayMinDate().isEmpty()
											&& req.getTodayMaxDate() != null
											&& !req.getTodayMaxDate()
													.isEmpty()) {
										hql += " (a.lastTeamUpdated >= :todayMinDate AND a.lastTeamUpdated <= :todayMaxDate )";
										parameters.put("todayMinDate",
												dateFormat.parse(
														req.getTodayMinDate()));
										parameters.put("todayMaxDate",
												dateFormat.parse(
														req.getTodayMaxDate()));
									}
									if (filter.equalsIgnoreCase("yesterday")
											&& req.getYesterdayMinDate() != null
											&& !req.getYesterdayMinDate()
													.isEmpty()
											&& req.getYesterdayMaxDate() != null
											&& !req.getYesterdayMaxDate()
													.isEmpty()) {
										hql += " (a.lastTeamUpdated >= :yesterdayMinDate AND a.lastTeamUpdated <= :yesterdayMaxDate)";
										parameters.put("yesterdayMinDate",
												dateFormat.parse(req
														.getYesterdayMinDate()));
										parameters.put("yesterdayMaxDate",
												dateFormat.parse(req
														.getYesterdayMaxDate()));
									}
									if (filter.equalsIgnoreCase("thisWeek")
											&& req.getThisWeekMinDate() != null
											&& !req.getThisWeekMinDate()
													.isEmpty()
											&& req.getThisWeekMaxDate() != null
											&& !req.getThisWeekMaxDate()
													.isEmpty()) {
										hql += " (a.lastTeamUpdated >= :thisWeekMinDate AND a.lastTeamUpdated <= :thisWeekMaxDate)";
										parameters.put("thisWeekMinDate",
												dateFormat.parse(req
														.getThisWeekMinDate()));
										parameters.put("thisWeekMaxDate",
												dateFormat.parse(req
														.getThisWeekMaxDate()));
									}
									if (filter.equalsIgnoreCase("lastWeek")
											&& req.getLastWeekMinDate() != null
											&& !req.getLastWeekMinDate()
													.isEmpty()
											&& req.getLastWeekMaxDate() != null
											&& !req.getLastWeekMaxDate()
													.isEmpty()) {
										hql += " (a.lastTeamUpdated >= :lastWeekMinDate AND a.lastTeamUpdated <= :lastWeekMaxDate)";
										parameters.put("lastWeekMinDate",
												dateFormat.parse(req
														.getLastWeekMinDate()));
										parameters.put("lastWeekMaxDate",
												dateFormat.parse(req
														.getLastWeekMaxDate()));
									}

								}
								hql += " ) ";
								log.debug("lastTeamUpdated: " + hql);
							}

						}
							break;

						case "bhcPatientAcctId" : {
							List<String> bhcPatientAcctIdList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getBhcPatientAcctId());
							List<Integer> intAcctList = new ArrayList<>();
							for (String s : bhcPatientAcctIdList) {
								intAcctList.add(Integer.valueOf(s));
							}
							hql += " a.bhcPatientAcctId IN :bhcPatientAcctId ";
							parameters.put("bhcPatientAcctId", intAcctList);
						}
							break;

						case "providerName" : {
							List<String> providerNameList = FilterRequestUtil
									.getListFromDelimitedStr(
											req.getProviderName());
							hql += " a.providerFullname IN :providerFullname ";
							parameters.put("providerFullname",
									providerNameList);
						}
							break;

						case "bhcShipDate" : {
							hql += " (a.bhcShipDate BETWEEN :bhcShipStartDate AND :bhcShipEndDate) ";
							parameters.put("bhcShipStartDate", dateFormat
									.parse(req.getBhcShipStartDate()));
							parameters.put("bhcShipEndDate",
									dateFormat.parse(req.getBhcShipEndDate()));
						}
							break;
						case "bhcLastUpdateDate" : {
							hql += " (a.bhcLastUpdated BETWEEN :bhcLastStartDate AND :bhcLastEndDate) ";
							parameters.put("bhcLastStartDate", new SimpleDateFormat(
									"yyyy-MM-dd").parseObject(req.getBhcLastUpdateStartDate()));
							parameters.put("bhcLastEndDate",
									new SimpleDateFormat(
											"yyyy-MM-dd").parseObject(req.getBhcLastUpdateEndDate()));
						}
							break;

						default :
							break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by a.bbc asc";
			}

			log.info("query : {}", hql);

			if (isExcel) {
				awdDashboard = session.createQuery(hql)
						.setProperties(parameters).list();
				listCount.put("Count", awdDashboard.size());
				listCount.put("data", awdDashboard);
			} else {
				int count;
				awdDashboard = session.createQuery(hql).setFirstResult(offset)
						.setProperties(parameters).setMaxResults(PAGE_SIZE)
						.list();

				allAWDList = session.createQuery(hql).setFirstResult(offset)
						.setProperties(parameters).list();

				count = allAWDList.size() + offset;

				listCount.put("Count", count);
				listCount.put("data", awdDashboard);
				log.debug("awdDashboard List Size:   {} ", count);
				log.debug("awdDashboard List data:   {} ", awdDashboard);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<MedicalRecodInvoiceDetails> getAllInvoiceDetails(int medRecId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<MedicalRecodInvoiceDetails> recordList = new ArrayList<>();

		MedicalRecodInvoiceDetails invoiceRecords = null;
		try {
			String hql = "SELECT bhcMedicalRecordId, bhcInvoiceOrderId,"
					+ " invoiceBalanceDue FROM AWDDashboard a"
					+ " where a.bhcMedicalRecordId=" + medRecId;

			List<Object[]> results = session.createQuery(hql, Object[].class)
					.getResultList();

			for (Object[] result : results) {
				invoiceRecords = new MedicalRecodInvoiceDetails();

				invoiceRecords.setBhcMedRecId((int) result[0]);
				invoiceRecords.setBhcInvoiceOrderId((int) result[1]);
				invoiceRecords.setInvoiceAmount((String) result[2]);

				recordList.add(invoiceRecords);
			}

		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return recordList;
	}

	@Override
	public SetStatusRes setStatus(SetStatusReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		SetStatusRes res = new SetStatusRes();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			String hql = "UPDATE AWDDashboard SET status = :status, "
					+ " statusUpdatedUserId = :statusUpdatedUserId,"
					+ " statusUpdatedUserFullName = :statusUpdatedUserFullname,"
					+ " statusUpdatedUserName = :statusUpdatedUsername,"
					+ " lastUpdatedUserId= :lastUpdatedUserId, "
					+ " lastUpdatedUserFullName = :lastUpdatedUserFullname,"
					+ " lastUpdatedUserName = :lastUpdatedUsername, "
					+ " statusUpdatedDateTime = :statusUpdatedDateTime, "
					+ " lastUpdatedDateTime = :lastUpdatedDateTime, "
					+ " lastUpdatedDate = :lastUpdatedDate, "
					+ " lastTeamUpdated = :lastTeamUpdated "
					+ " WHERE bhcMedicalRecordId = :medRecId AND"
					+ " bhcInvoiceOrderId = :bhcInvoiceId ";
			int rowsChanges = session.createQuery(hql)
					.setParameter("status", req.getStatus())
					.setParameter("statusUpdatedUserId",
							Long.valueOf(req.getStatusUpdatedUserId()))
					.setParameter("statusUpdatedUserFullname",
							req.getStatusUpdatedUserFullname())
					.setParameter("statusUpdatedUsername",
							req.getStatusUpdatedUsername())
					.setParameter("lastUpdatedUserId",
							Long.valueOf(req.getLastUpdatedUserId()))
					.setParameter("lastUpdatedUserFullname",
							req.getLastUpdatedUserFullname())
					.setParameter("lastUpdatedUsername",
							req.getLastUpdatedUsername())
					.setParameter("lastUpdatedDate", new Date())
					.setParameter("statusUpdatedDateTime", currentTime)
					.setParameter("lastUpdatedDateTime", currentTime)
					.setParameter("lastTeamUpdated", currentTime)
					.setParameter("medRecId",
							Integer.parseInt(req.getMedRecId()))
					.setParameter("bhcInvoiceId",
							Integer.parseInt(req.getBhcInvoiceId()))
					.executeUpdate();
			if (req.getMedRecId() != null && rowsChanges > 0) {
				res.setResponseCode("0");
				res.setResponseDesc(DAOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(DAOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return res;
	}

	@Override
	public UpdateAssignedToRes updatedAssigneedTo(DashboardReq req,
			List<AWDData> awdData) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		UpdateAssignedToRes res = new UpdateAssignedToRes();
		try {

			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			if (req.getBatchAssigneeFullName() != null
					&& !req.getBatchAssigneeFullName().isEmpty()) {

				for (AWDData record : awdData) {

					String assignedToHql = "UPDATE AWDDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
							+ " lastUpdatedUserFullName = :lastUpdatedUserFullName, "
							+ " lastUpdatedUserName = :lastUpdatedUsername, "
							+ " lastUpdatedDateTime = :lastUpdatedDateTime, "
							//+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
							//+ " lastTeamUpdated = :lastTeamUpdated, "
							+ " assignee = :assignee, "
							+ " assigneeFullName = :assigneeFullName, "
							+ " reassignedTo = :reassignedTo, "
							+ " lastActioned = :lastActioned "
							+ " WHERE bhcInvoiceOrderId = :bhcInvoiceId AND"
							+ " bhcMedicalRecordId = :medRecId ";

					// Saving details
					session.createQuery(assignedToHql)
							.setParameter("lastUpdatedUserId",
									Long.valueOf(req.getLastUpdatedUserId()))
							.setParameter("lastUpdatedUserFullName",
									req.getLastUpdatedUserFullName())
							.setParameter("lastUpdatedUsername",
									req.getLastUpdatedUserName())
							/*.setParameter("lastTeamUpdatedUserFullname",
									req.getLastUpdatedUserFullName())
							.setParameter("lastTeamUpdated", currentTime)*/
							.setParameter("lastActioned", currentTime)
							.setParameter("lastUpdatedDateTime", currentTime)
							.setParameter("assignee",
									req.getBatchAssigneeUserName())
							.setParameter("assigneeFullName",
									req.getBatchAssigneeFullName())
							.setParameter("reassignedTo",
									req.getBatchAssigneeChanged())
							.setParameter("bhcInvoiceId",
									Integer.parseInt(
											record.getBhcInvoiceOrderId()))
							.setParameter("medRecId", record.getBhcMedRecId())
							.executeUpdate();

					// Updating History Timeline
					log.debug(
							"updating documentation history table.  {}",record.getBhcInvoiceOrderId());
					String bhcHql = "SELECT a.status, a.bhcDocumentStatus "
							+ " FROM AWDDashboard a "
							+ " WHERE a.bhcInvoiceOrderId = :bhcInvoiceOrderId AND"
							+ " a.bhcMedicalRecordId = :medRecId ";

					Object[] result = session
							.createQuery(bhcHql, Object[].class)
							.setParameter("bhcInvoiceOrderId",
									Integer.parseInt(
											record.getBhcInvoiceOrderId()))
							.setParameter("medRecId", record.getBhcMedRecId())
							.uniqueResult();

					String rowNoteIdHQL = "SELECT MAX(noteId) from DocumentationHistory ";

					Integer id = (Integer) session.createQuery(rowNoteIdHQL)
							.uniqueResult();
					id = id + 1;

					String documentId = UUID.randomUUID().toString();

					String retrieveStatus = (String) result[0];
					String bhcDocStatus = (String) result[1];

					DocumentationHistory docHistory = new DocumentationHistory();
					docHistory.setNoteId(id);
					docHistory.setDocumentId(documentId);
					docHistory.setBhcMedicalRecordId(record.getBhcMedRecId());
					docHistory.setBhcInvoiceOrderNo(
							Integer.parseInt(record.getBhcInvoiceOrderId()));
					docHistory.setBhcDocumentStatus(bhcDocStatus);
					docHistory.setBhcMissingDocNotes("");
					docHistory.setBhcMissingDocType("");
					docHistory.setRetrieveStatus(retrieveStatus);
					docHistory.setLastUpdatedTimestamp(currentTime);
					docHistory.setAssignedTo(req.getBatchAssigneeFullName());
					docHistory.setLastUpdatedUserFullname(
							req.getLastUpdatedUserFullName());
					docHistory.setLastUpdatedUserId(
							Long.valueOf(req.getLastUpdatedUserId()));
					docHistory.setLastUpdatedUsername(
							req.getLastUpdatedUserName());

					session.save(docHistory);

				}
				// Saving APp Notifications
				appNotificationBO.saveBatchAssigned(awdData.size(), req);
			}

			res.setResponseCode("0");
			res.setResponseDesc(DAOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while saving batch assigned: {}",
					e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(DAOConstants.FAILED);
			throw new CustomException(e.getMessage());
		}
		return res;
	}

	@Override
	public List<UserFacilities> getUserFacilities(String userId,
			String username) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<UserFacilities> userFacilities = new ArrayList<>();
		RetrieveUsers record = null;
		try {
			String hql = "From RetrieveUsers r WHERE r.username=:username";
			record = (RetrieveUsers) session.createQuery(hql).setParameter("username", username).uniqueResult();
			if (record != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				try {
					userFacilities = objectMapper.readValue(
							record.getFacilities(),
							new TypeReference<List<UserFacilities>>() {
							});
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception:  {}", e);
				}
				log.debug("Get User Facilities Successful");
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching user facilities: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return userFacilities;
	}

	@Override
	public FacilityDetails getFacilityDetails(String bbc)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		FacilityDetails facilityDetails = new FacilityDetails();
		try {
			String facilityHql = "FROM FacilityDetails WHERE bluebookId = :bbc "
					+ " AND active = :active ";
			log.debug("facilityHql: {}",facilityHql);
			facilityDetails = session
					.createQuery(facilityHql, FacilityDetails.class)
					.setParameter("bbc", bbc)
					.setParameter("active", 1)
					.uniqueResult();
			log.debug("facilityDetails: {}",facilityDetails);
		} catch (Exception e) {
			log.error("Exception occured while fetching Facility Detaild: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return facilityDetails;
	}

	@Override
	public FacilityDetails getFacilityDetailsForDetailsCTP(Integer facilityId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		FacilityDetails facilityDetails = new FacilityDetails();
		try {
			String facilityHql = "FROM FacilityDetails WHERE facilityId = :facilityId "
					+ " AND active = :active ";
			log.debug("facilityHql: {}",facilityHql);
			facilityDetails = session
					.createQuery(facilityHql, FacilityDetails.class)
					.setParameter("facilityId", facilityId)
					.setParameter("active", 1)
					.uniqueResult();
			log.debug("facilityDetails: {}",facilityDetails);
		} catch (Exception e) {
			log.error("Exception occured while fetching Facility Detaild: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return facilityDetails;
	}
	
	@Override
	public Boolean getRetrieveUser(String userId, String username)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		RetrieveUsers record = null;
		Boolean isSuperUser = false;
		try {
			String hql = "From RetrieveUsers r WHERE r.username=:username";
			record = (RetrieveUsers) session.createQuery(hql).setParameter("username", username).uniqueResult();
			if(record != null) {
				isSuperUser = record.getIsSuperUser();
			}
			
		} catch (Exception e) {
			log.error("Exception occured while fetching User Role: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return isSuperUser;
	}

}
