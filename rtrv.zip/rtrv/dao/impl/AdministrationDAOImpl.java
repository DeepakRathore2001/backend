package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.AdministrationDAO;
import com.healogics.rtrv.dto.AdminDashboardReq;
import com.healogics.rtrv.dto.FilteredBBCResponse;
import com.healogics.rtrv.dto.UpdateCenteAssignmentReq;
import com.healogics.rtrv.dto.UpdateRetrieveUsersReq;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.FilterRequestUtil;

@Repository
@TransactionManager1
public class AdministrationDAOImpl implements AdministrationDAO {

	private final Logger log = LoggerFactory.getLogger(AdministrationDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public AdministrationDAOImpl(@Qualifier("SessionFactory1") SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public List<Object[]> getRetrieveMembersData(AdminDashboardReq req, int index) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> list = new ArrayList<>();
		try {
			String hql = "SELECT t1.active, t1.retrieveMemberId, t1.bluebookCode, t1.operationsSpecialist, "
					+ " t1.awdDocClerk, t1.awdDocClerkUsername, t1.awdDocSpecialist, t1.awdDocSpecialistUsername,"
					+ "   t1.npwtDocClerk, t1.npwtDocClerkUsername, t1.npwtDocAnalyst, t1.npwtDocAnalystUsername, "
					+ " t1.ctpClerk, t1.ctpClerkUsername, t1.ctpAnalyst, t1.ctpAnalystUsername, "
					+ "  t2.territory, t2.division, t2.market, t2.currentFacilityType "
					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId "
					+ " WHERE t1.active = 1 ";

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by t1.bluebookCode asc";
			}

			log.info("query : {}", hql);

			list = session.createQuery(hql, Object[].class).setFirstResult(index).setMaxResults(PAGE_SIZE).list();

		} catch (Exception e) {
			log.error("CustomException occured while fetching Retrieve Members List: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return list;
	}

	@Override
	public List<RetrieveUsers> getRetrieveUsersData(AdminDashboardReq req, int index) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<RetrieveUsers> list = new ArrayList<>();
		try {
			String hql = "FROM RetrieveUsers WHERE isSuperUser = :isSuperUser ";

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by userFullName asc";
			}

			log.info("query : {}", hql);

			list = session.createQuery(hql).setParameter("isSuperUser", req.getIsSuperUser()).setFirstResult(index)
					.setMaxResults(PAGE_SIZE).list();

		} catch (Exception e) {
			log.error("CustomException occured while fetching  Retrieve Users List: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return list;
	}

	@Override
	public FacilityDetails getTerritory(String bluebookCode) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		FacilityDetails facilityDetails = new FacilityDetails();
		try {
			String facilityHql = "FROM FacilityDetails WHERE bluebookId = :bbc";
			facilityDetails = session.createQuery(facilityHql, FacilityDetails.class).setParameter("bbc", bluebookCode)
					.setParameter("active", 1).uniqueResult();

		} catch (Exception e) {
			log.error("CustomException occured while fetching Facility Details: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return facilityDetails;
	}

	@Override
	public List<String> getRoleAssignmentFilterOptions(AdminDashboardReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> optionList = new ArrayList<>();
		try {
			String query = " WHERE isSuperUser = :isSuperUser ";
			String filterColumnString = getFilterColumnName(req.getFilterOptions());
			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					String filteString = getFilterColumnName(filterReq);
					query += " AND ";

					switch (filteString) {
					case "userFullName": {
						List<String> userFullNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssigneeFullname());
						query += " userFullName IN :userFullName ";
						parameters.put("userFullName", userFullNameList);
					}
						break;
					case "retrieveRole": {
						List<String> retrieveRoleLists = FilterRequestUtil.getListFromDelimitedStr(req.getRole());
						query += " retrieveRole IN :retrieveRole ";
						parameters.put("retrieveRole", retrieveRoleLists);
					}
						break;

					case "businessRole": {
						List<String> businessRoleLists = FilterRequestUtil
								.getListFromDelimitedStr(req.getBusinessRole());
						List<String> formattedList = new ArrayList<>();
						for (String role : businessRoleLists) {
							formattedList.add("%" + role + "%");
						}
						for (int i = 0; i < formattedList.size(); i++) {
							if (i == 0) {
								query += " (";
							}
							query += " businessRole LIKE :role" + i;
							if (i < formattedList.size() - 1) {
								query += " OR ";
							} else {
								query += ")";
							}
							// query += " JSON_CONTAINS(businessRole,'\""+businessRoleLists.get(i)+"\"')";
						}
						for (int i = 0; i < formattedList.size(); i++) {
							parameters.put("role" + i, formattedList.get(i));
						}
						// query += " businessRole IN :businessRole ";
						// parameters.put("businessRole", businessRoleLists);
					}
						break;

					case "emailId": {
						List<String> emailIdList = FilterRequestUtil.getListFromDelimitedStr(req.getEmail());
						query += " emailId IN :emailId ";
						parameters.put("emailId", emailIdList);
					}
						break;
					case "username": {
						List<String> usernameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssigneeUsername());
						query += " username IN :username ";
						parameters.put("username", usernameList);
					}
						break;
					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			if (filterColumnString.equalsIgnoreCase("businessRole")) {
				String hql = "FROM RetrieveUsers " + query
						+ " AND businessRole IS NOT NULL ORDER BY JSON_EXTRACT(businessRole, '$[0]') asc";
				List<RetrieveUsers> distinctValues = session.createQuery(hql)
						.setParameter("isSuperUser", req.getIsSuperUser()).setProperties(parameters).getResultList();
				List<String> roles = new ArrayList<>();
				for (RetrieveUsers users : distinctValues) {
					String rolesJson = users.getBusinessRole();
					if (rolesJson != null && !rolesJson.isEmpty()) {
						roles = new ObjectMapper().readValue(rolesJson, new TypeReference<List<String>>() {
						});
					}
				}
				List<String> listWithoutDuplicates = roles.stream().distinct().collect(Collectors.toList());
				optionList.addAll(listWithoutDuplicates);
				optionList.removeIf(element -> element == null || (element != null && element.isEmpty()));
			} else {

				String hql = "SELECT DISTINCT " + filterColumnString + " FROM RetrieveUsers " + query + " ORDER BY "
						+ filterColumnString + " asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("isSuperUser", req.getIsSuperUser())
						.setProperties(parameters).getResultList();
				optionList.addAll(distinctValues);
				optionList.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Role Admin Dashboard filter options : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return optionList;
	}

	private String sortList(AdminDashboardReq req, String hql) {

		if (getFilterColumnName(req.getSortBy()).equalsIgnoreCase("businessRole")) {
			hql += " ORDER BY COALESCE(JSON_EXTRACT(businessRole, '$[0]'),'')";
		} else {
			hql += " order by " + getFilterColumnName(req.getSortBy()) + "";
		}

		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}

		return hql;
	}

	@Override
	public Map<String, Object> getFilteredRetrieveMembers(AdminDashboardReq req, int index) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> list = new ArrayList<>();
		List<RetrieveMembers> allList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		try {

			String query = "SELECT t1.active, t1.retrieveMemberId, t1.bluebookCode, t1.operationsSpecialist, "
					+ " t1.awdDocClerk, t1.awdDocClerkUsername, t1.awdDocSpecialist, t1.awdDocSpecialistUsername,"
					+ " t1.npwtDocClerk, t1.npwtDocClerkUsername, t1.npwtDocAnalyst, t1.npwtDocAnalystUsername, "
					+ " t1.ctpClerk, t1.ctpClerkUsername, t1.ctpAnalyst, t1.ctpAnalystUsername, "
					+ "  t2.territory, t2.division, t2.market, t2.currentFacilityType "
					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId "
					+ " WHERE t1.active = 1 ";

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					String filteString = getFilterColumnName(filterReq);
					query += " AND ";

					switch (filteString) {
					case "t1.bluebookCode": {
						List<String> bluebookCodeList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " t1.bluebookCode IN :bluebookCode ";
						parameters.put("bluebookCode", bluebookCodeList);
					}
						break;
					case "t1.operationsSpecialist": {
						List<String> operationsSpecialistList = FilterRequestUtil
								.getListFromDelimitedStr(req.getOpsSpecialist());
						query += " t1.operationsSpecialist IN :operationsSpecialist ";
						parameters.put("operationsSpecialist", operationsSpecialistList);
					}
						break;
					case "t1.awdDocClerk": {
						List<String> awdDocClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getAwdClerk());
						query += " t1.awdDocClerk IN :awdDocClerk ";
						parameters.put("awdDocClerk", awdDocClerkList);
					}
						break;
					case "t1.awdDocSpecialist": {
						List<String> awdDocSpecialistList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAwdSpecialist());
						query += " t1.awdDocSpecialist IN :awdDocSpecialist ";
						parameters.put("awdDocSpecialist", awdDocSpecialistList);
					}
						break;
					case "t1.npwtDocClerk": {
						List<String> npwtDocClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getNpwtClerk());
						query += " t1.npwtDocClerk IN :npwtDocClerk ";
						parameters.put("npwtDocClerk", npwtDocClerkList);
					}
						break;
					case "t1.npwtDocAnalyst": {
						List<String> npwtDocAnalystList = FilterRequestUtil
								.getListFromDelimitedStr(req.getNpwtSpecialist());
						query += " t1.npwtDocAnalyst IN :npwtDocAnalyst ";
						parameters.put("npwtDocAnalyst", npwtDocAnalystList);
					}
						break;
					case "t1.ctpClerk": {
						List<String> ctpClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getCtpClerk());
						query += " t1.ctpClerk IN :ctpClerk ";
						parameters.put("ctpClerk", ctpClerkList);
					}
						break;
					case "t1.ctpAnalyst": {
						List<String> ctpAnalystList = FilterRequestUtil.getListFromDelimitedStr(req.getCtpSpecialist());
						query += " t1.ctpAnalyst IN :ctpAnalyst ";
						parameters.put("ctpAnalyst", ctpAnalystList);
					}
						break;
					case "t2.territory": {
						List<String> territoryList = FilterRequestUtil.getListFromDelimitedStr(req.getTerritory());
						query += " t2.territory IN :territory ";
						parameters.put("territory", territoryList);
					}
						break;
					case "t2.division": {
						List<String> divisionList = FilterRequestUtil.getListFromDelimitedStr(req.getDivision());
						query += " t2.division IN :division ";
						parameters.put("division", divisionList);
					}
						break;
					case "t2.market": {
						List<String> marketList = FilterRequestUtil.getListFromDelimitedStr(req.getMarket());
						query += " t2.market IN :market ";
						parameters.put("market", marketList);
					}
						break;
					case "t2.currentFacilityType": {
						List<String> currentFacilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getIhealConfig());
						query += " t2.currentFacilityType IN :currentFacilityType ";
						parameters.put("currentFacilityType", currentFacilityTypeList);
					}
						break;
					default:
						break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				query = sortList(req, query);

			} else {
				query += " order by t1.bluebookCode asc";
			}

			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			int count;
			list = session.createQuery(query, Object[].class).setFirstResult(index).setProperties(parameters)
					.setMaxResults(PAGE_SIZE).list();

			allList = session.createQuery(query).setFirstResult(index).setProperties(parameters).list();

			count = allList.size() + index;

			listCount.put("Count", count);
			listCount.put("data", list);
			log.debug("Retrieve Members List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching Filtered Retrieve Members records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return listCount;
	}

	@Override
	public Map<String, Object> getFilteredRetrieveUsers(AdminDashboardReq req, int index) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<RetrieveUsers> list = new ArrayList<>();
		List<RetrieveUsers> allList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		try {
			String query = "FROM RetrieveUsers WHERE isSuperUser = :isSuperUser ";

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					String filteString = getFilterColumnName(filterReq);
					query += " AND ";

					switch (filteString) {
					case "userFullName": {
						List<String> userFullNameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssigneeFullname());
						query += " userFullName IN :userFullName ";
						parameters.put("userFullName", userFullNameList);
					}
						break;
					case "retrieveRole": {
						List<String> retrieveRoleLists = FilterRequestUtil.getListFromDelimitedStr(req.getRole());
						query += " retrieveRole IN :retrieveRole ";
						parameters.put("retrieveRole", retrieveRoleLists);
					}
						break;
					case "businessRole": {
						List<String> businessRoleLists = FilterRequestUtil
								.getListFromDelimitedStr(req.getBusinessRole());
						List<String> formattedList = new ArrayList<>();
						for (String role : businessRoleLists) {
							formattedList.add("%" + role + "%");
						}
						for (int i = 0; i < formattedList.size(); i++) {
							if (i == 0) {
								query += " (";
							}
							query += " businessRole LIKE :role" + i;
							if (i < formattedList.size() - 1) {
								query += " OR ";
							} else {
								query += ")";
							}
							// query += " JSON_CONTAINS(businessRole,'\""+businessRoleLists.get(i)+"\"')";
						}
						for (int i = 0; i < formattedList.size(); i++) {
							parameters.put("role" + i, formattedList.get(i));
						}
						// query += " businessRole IN :businessRole ";
						// parameters.put("businessRole", businessRoleLists);
					}
						break;
					case "emailId": {
						List<String> emailIdList = FilterRequestUtil.getListFromDelimitedStr(req.getEmail());
						query += " emailId IN :emailId ";
						parameters.put("emailId", emailIdList);
					}
						break;
					case "username": {
						List<String> usernameList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAssigneeUsername());
						query += " username IN :username ";
						parameters.put("username", usernameList);
					}
						break;
					default:
						break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				query = sortList(req, query);

			} else {
				query += " order by userFullName asc";
			}

			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			int count;
			list = session.createQuery(query).setParameter("isSuperUser", req.getIsSuperUser()).setFirstResult(index)
					.setProperties(parameters).setMaxResults(PAGE_SIZE).list();

			allList = session.createQuery(query).setParameter("isSuperUser", req.getIsSuperUser()).setFirstResult(index)
					.setProperties(parameters).list();

			count = allList.size() + index;

			listCount.put("Count", count);
			listCount.put("data", list);
			log.debug("Retrieve Users List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching Filtered Retrieve Users records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return listCount;
	}

	@Override
	public Long totalRetrieveMembers() throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;
		try {
			String hql = "SELECT count(*) FROM RetrieveMembers WHERE active = 1";

			taskCount = (Long) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching RetrieveMembers count: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return taskCount;
	}

	@Override
	public Long totalRetrieveUsers(Boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;
		try {
			String hql = "SELECT count(*) FROM RetrieveUsers WHERE isSuperUser = :isSuperUser ";

			taskCount = (Long) session.createQuery(hql).setParameter("isSuperUser", isSuperUser).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching RetrieveUsers count: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return taskCount;
	}

	@Override
	public List<String> getCenterAssignmentFilterOptions(AdminDashboardReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<String> optionList = new ArrayList<>();
		try {
			String query = " WHERE t1.active = 1 ";
			String filterColumnString = getFilterColumnName(req.getFilterOptions());
			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					String filteString = getFilterColumnName(filterReq);
					query += " AND ";

					switch (filteString) {
					case "t1.bluebookCode": {
						List<String> bluebookCodeList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " t1.bluebookCode IN :bluebookCode ";
						parameters.put("bluebookCode", bluebookCodeList);
					}
						break;
					case "t1.operationsSpecialist": {
						List<String> operationsSpecialistList = FilterRequestUtil
								.getListFromDelimitedStr(req.getOpsSpecialist());
						query += " t1.operationsSpecialist IN :operationsSpecialist ";
						parameters.put("operationsSpecialist", operationsSpecialistList);
					}
						break;
					case "t1.awdDocClerk": {
						List<String> awdDocClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getAwdClerk());
						query += " t1.awdDocClerk IN :awdDocClerk ";
						parameters.put("awdDocClerk", awdDocClerkList);
					}
						break;
					case "t1.awdDocSpecialist": {
						List<String> awdDocSpecialistList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAwdSpecialist());
						query += " t1.awdDocSpecialist IN :awdDocSpecialist ";
						parameters.put("awdDocSpecialist", awdDocSpecialistList);
					}
						break;
					case "t1.npwtDocClerk": {
						List<String> npwtDocClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getNpwtClerk());
						query += " t1.npwtDocClerk IN :npwtDocClerk ";
						parameters.put("npwtDocClerk", npwtDocClerkList);
					}
						break;
					case "t1.npwtDocAnalyst": {
						List<String> npwtDocAnalystList = FilterRequestUtil
								.getListFromDelimitedStr(req.getNpwtSpecialist());
						query += " t1.npwtDocAnalyst IN :npwtDocAnalyst ";
						parameters.put("npwtDocAnalyst", npwtDocAnalystList);
					}
						break;
					case "t1.ctpClerk": {
						List<String> ctpClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getCtpClerk());
						query += " t1.ctpClerk IN :ctpClerk ";
						parameters.put("ctpClerk", ctpClerkList);
					}
						break;
					case "t1.ctpAnalyst": {
						List<String> ctpAnalystList = FilterRequestUtil.getListFromDelimitedStr(req.getCtpSpecialist());
						query += " t1.ctpAnalyst IN :ctpAnalyst ";
						parameters.put("ctpAnalyst", ctpAnalystList);
					}
						break;
					case "t2.territory": {
						List<String> territoryList = FilterRequestUtil.getListFromDelimitedStr(req.getTerritory());
						query += " t2.territory IN :territory ";
						parameters.put("territory", territoryList);
					}
						break;
					case "t2.division": {
						List<String> divisionList = FilterRequestUtil.getListFromDelimitedStr(req.getDivision());
						query += " t2.division IN :division ";
						parameters.put("division", divisionList);
					}
						break;
					case "t2.market": {
						List<String> marketList = FilterRequestUtil.getListFromDelimitedStr(req.getMarket());
						query += " t2.market IN :market ";
						parameters.put("market", marketList);
					}
						break;
					case "t2.currentFacilityType": {
						List<String> currentFacilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getIhealConfig());
						query += " t2.currentFacilityType IN :currentFacilityType ";
						parameters.put("currentFacilityType", currentFacilityTypeList);
					}
						break;
					default:
						break;
					}
				}
			}
			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "SELECT DISTINCT " + filterColumnString
					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId " + query
					+ " ORDER BY " + filterColumnString + " asc";
			List<String> distinctValues = session.createQuery(hql).setProperties(parameters).getResultList();
			optionList.addAll(distinctValues);
			optionList.removeIf(element -> element == null || (element != null && element.isEmpty()));

		} catch (Exception e) {
			log.error("Exception occured while fetching Center Admin Dashboard filter options : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return optionList;
	}

	private String getFilterColumnName(String parameter) {
		String column = "";
		switch (parameter) {
		// Center Retrieve Members Tables
		case "bbc":
			column = "t1.bluebookCode";
			break;
		case "opsSpecialist":
			column = "t1.operationsSpecialist";
			break;
		case "awdClerk":
			column = "t1.awdDocClerk";
			break;
		case "awdSpecialist":
			column = "t1.awdDocSpecialist";
			break;
		case "npwtClerk":
			column = "t1.npwtDocClerk";
			break;
		case "npwtSpecialist":
			column = "t1.npwtDocAnalyst";
			break;
		case "ctpClerk":
			column = "t1.ctpClerk";
			break;
		case "ctpSpecialist":
			column = "t1.ctpAnalyst";
			break;
		case "territory":
			column = "t2.territory";
			break;
		case "division":
			column = "t2.division";
			break;
		case "market":
			column = "t2.market";
			break;
		case "ihealConfig":
			column = "t2.currentFacilityType";
			break;
		// role assignment rable
		case "assigneeFullname":
			column = "userFullName";
			break;
		case "role":
			column = "retrieveRole";
			break;
		case "businessRole":
			column = "businessRole";
			break;
		case "email":
			column = "emailId";
			break;
		case "assigneeUsername":
			column = "username";
			break;
		default:
			break;
		}
		return column;
	}

	@Override
	public List<String> getCenterAssignmentPopupValues(String column) throws CustomException {
		List<String> valueList = new ArrayList<>();
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String col = getFilterColumnName(column);
			String hql = "SELECT DISTINCT " + col
					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId "
					+ " ORDER BY " + col + " asc";
			List<String> distinctValues = session.createQuery(hql).getResultList();
			valueList.addAll(distinctValues);
			valueList.removeIf(element -> element == null || (element != null && element.isEmpty()));

		} catch (Exception e) {
			log.error("Exception occured while fetching Center Assignments Popup Values : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return valueList;
	}

	public FilteredBBCResponse getCenterAssignmentDropDownValues(AdminDashboardReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		FilteredBBCResponse res = new FilteredBBCResponse();
		try {
			// log.info("Fetching default values for dropdowns");

			// Fetch default values
		List<String> ihealConfigValues = getCenterAssignmentPopupValues("ihealConfig");
			List<String> businessRoleValues = Arrays.asList("AWDDocClerk", "AWDDocSpecialist");

			List<String> divisionValues = getCenterAssignmentPopupValues("division");
			List<String> nameValues = getAssigneeNameFromUsersTable(req.getIsSuperUser());

			// Remove null or empty elements
			ihealConfigValues.removeIf(element -> element == null || element.isEmpty());
			businessRoleValues.removeIf(element -> element == null || element.isEmpty());
			divisionValues.removeIf(element -> element == null || element.isEmpty());
			nameValues.removeIf(element -> element == null || element.isEmpty());

		res.setIhealConfig(ihealConfigValues);
			res.setBusinessRole(businessRoleValues);
			res.setDivision(divisionValues);
			res.setName(nameValues);

			// log.debug("Default values set: ihealConfig={}, businessRole={}, division={},
			// names={}",
//	                  ihealConfigValues, businessRoleValues, divisionValues, nameValues);

			String query = "SELECT DISTINCT t1.bluebookCode FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId WHERE t1.active = 1";
			Map<String, Object> parameters = new HashMap<>();

			// Check if any dropdown value is selected
			if ((req.getDivision() != null && !req.getDivision().isEmpty())
					|| (req.getMarket() != null && !req.getMarket().isEmpty())
					|| (req.getTerritory() != null && !req.getTerritory().isEmpty())
					|| (req.getIhealConfig() != null && !req.getIhealConfig().isEmpty())) {

				// log.info("Applying filters based on dropdown selection");

				if (req.getDivision() != null && !req.getDivision().isEmpty()) {
					List<String> divisionList = FilterRequestUtil.getListFromDelimitedStr(req.getDivision());
					query += " AND t2.division IN :division";
					parameters.put("division", divisionList);
					List<String> markets = session.createQuery(
							"SELECT DISTINCT t2.market FROM FacilityDetails t2 WHERE t2.division IN :division",
							String.class).setParameter("division", divisionList).getResultList();
					markets.removeIf(element -> element == null || element.isEmpty());
					res.setMarket(markets);
					 log.debug("Division filter applied: division={}, markets={}", divisionList,
					 markets);
						List<String> ihealConfigList = session.createQuery(
								"SELECT DISTINCT t2.currentFacilityType FROM FacilityDetails t2 WHERE t2.division IN :division",
								String.class).setParameter("division", divisionList).getResultList();
						ihealConfigList.removeIf(element -> element == null || element.isEmpty());
						res.setIhealConfig(ihealConfigList);
					 
				}
				if (req.getMarket() != null && !req.getMarket().isEmpty()) {
					List<String> marketList = FilterRequestUtil.getListFromDelimitedStr(req.getMarket());
					query += " AND t2.market IN :market";
					parameters.put("market", marketList);
					List<String> territories = session.createQuery(
							"SELECT DISTINCT t2.territory FROM FacilityDetails t2 WHERE t2.market IN :market",
							String.class).setParameter("market", marketList).getResultList();
					territories.removeIf(element -> element == null || element.isEmpty());
					res.setTerritory(territories);
					 log.debug("Market filter applied: market={}, territories={}", marketList,
					 territories);
					 List<String> ihealConfigList = session.createQuery(
								"SELECT DISTINCT t2.currentFacilityType FROM FacilityDetails t2 WHERE t2.market IN :market",
								String.class).setParameter("market", marketList ).getResultList();
						ihealConfigList.removeIf(element -> element == null || element.isEmpty());
						res.setIhealConfig(ihealConfigList);
				}
				if (req.getTerritory() != null && !req.getTerritory().isEmpty()) {
					List<String> territoryList = FilterRequestUtil.getListFromDelimitedStr(req.getTerritory());
					query += " AND t2.territory IN :territory";
					parameters.put("territory", territoryList);
					List<String> ihealConfigList = session.createQuery(
							"SELECT DISTINCT t2.currentFacilityType FROM FacilityDetails t2 WHERE t2.territory IN :territory",
							String.class).setParameter("territory", territoryList).getResultList();
					ihealConfigList.removeIf(element -> element == null || element.isEmpty());
					res.setIhealConfig(ihealConfigList);
					
					log.debug("Territory filter applied: territory={}, IhealConfig={}", territoryList,ihealConfigList);
				}
				if (req.getIhealConfig() != null && !req.getIhealConfig().isEmpty()) {
					List<String> ihealConfigList = FilterRequestUtil.getListFromDelimitedStr(req.getIhealConfig());
					query += " AND t2.currentFacilityType IN :ihealConfig";
					parameters.put("ihealConfig", ihealConfigList);
					log.debug("ihealConfig filter applied: ihealConfig={}", ihealConfigList);
				}
			}

			query += " ORDER BY t1.bluebookCode ASC";
			List<String> bbcList = session.createQuery(query, String.class).setProperties(parameters).getResultList();
			bbcList.removeIf(element -> element == null || element.isEmpty());
			res.setBbc(bbcList);

			log.info("Filtered BBC data fetched successfully");
			log.debug("Filtered BBC data: {}", bbcList);

			res.setResponseCode("0");
			res.setResponseMessage("SUCCESS");
		} catch (Exception e) {
			log.error("Exception occurred while fetching filtered BBC data: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("FAILED");
			throw new CustomException(e.getMessage());
		}
		return res;
	}

//	@Override
//	public List<String> getCenterAssignmentDropDownValues(String column,AdminDashboardReq req)
//			throws CustomException {
//		List<String> valueList = new ArrayList<>();
//		Session session = this.sessionFactory.getCurrentSession();
//		String dropDown= req.getDropDown();
//		String query="";
//		
//		try {
//			if(column != null && !column.isEmpty()) {
//			String col = getDropDownFilterColumnName(column);
//			Map<String, Object> parameters = new HashMap<>();
//			if (column.equalsIgnoreCase("allbbc")) {
//				 query = "SELECT DISTINCT " + col
//						+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId"
//						+ " WHERE t1.active = 1 ";
//				
//			}else {
//		         query = "SELECT DISTINCT " + col
//					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId"
//					+ " WHERE t1.active = 1 ";
//			// set all filters in where clause			
//					if (req.getDivision() != null && !req.getDivision().isEmpty()) {
//						List<String> divisionList = FilterRequestUtil
//								.getListFromDelimitedStr(req.getDivision());
//						query += " AND t2.division IN :division ";
//						parameters.put("division", divisionList);
//					}
//					if (req.getTerritory() != null && !req.getTerritory().isEmpty()) {
//						List<String> territoryList = FilterRequestUtil
//								.getListFromDelimitedStr(
//										req.getTerritory());
//						query += " AND t2.territory IN :territory ";
//						parameters.put("territory", territoryList);
//					}
//					if (req.getMarket() != null && !req.getMarket().isEmpty()) {
//						List<String> marketList = FilterRequestUtil
//								.getListFromDelimitedStr(req.getMarket());
//						query += " AND t2.market IN :market ";
//						parameters.put("market", marketList);
//					}
//			}
//			log.debug("query :  {}", query);
//			log.debug("parameters:   {}", parameters);
//
//			String hql = query + " ORDER BY " + col + " asc";
//			log.debug("query :  {}", hql);
//			List<String> distinctValues = session.createQuery(hql)
//					.setProperties(parameters).getResultList();
//			valueList.addAll(distinctValues);
//			valueList.removeIf(element -> element == null
//					|| (element != null && element.isEmpty()));
//
//			}else {
//				valueList= new ArrayList<>();
//			}
//			} catch (Exception e) {
//			log.error(
//					"Exception occured while fetching Center Assignments Popup Values : {}",
//					e.getMessage());
//			throw new CustomException(e.getMessage());
//		}
//		return valueList;
//	}
//
//	
//	
//	private String getDropDownFilterColumnName(String parameter) {
//		String column = "";
//		switch (parameter.toLowerCase()) {
//			case "allbbc" :
//				column = "t1.bluebookCode";
//				break;
//			case "territory" :
//				column = "t1.bluebookCode";
//				break;
//			case "division" :
//				column = "t2.market";
//				break;
//			case "market" :
//				column ="t2.territory" ;
//				break;
//			default :
//				break;
//		}
//		return column;
//	}
//
//	
	@Override
	public List<String> getAssigneeNameFromUsersTable(Boolean isSuperUser) throws CustomException {
		List<String> valueList = new ArrayList<>();
		Session session = this.sessionFactory.getCurrentSession();
		try {

			String hql = "SELECT DISTINCT(userFullName) FROM RetrieveUsers WHERE retrieveRole != 'admin' "
					+ " AND isSuperUser = :isSuperUser " + " ORDER BY userFullName asc";
			List<String> distinctValues = session.createQuery(hql).setParameter("isSuperUser", isSuperUser)
					.getResultList();
			valueList.addAll(distinctValues);
			valueList.removeIf(element -> element == null || (element != null && element.isEmpty()));

		} catch (Exception e) {
			log.error("Exception occured while fetching userFullName Center Assignments Popup Values : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return valueList;
	}

	@Override
	public void updateRetrieveUsers(List<UpdateRetrieveUsersReq> userRoles) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			for (UpdateRetrieveUsersReq usersReq : userRoles) {
				StringBuilder hql = new StringBuilder("UPDATE RetrieveUsers SET ");
				boolean addComma = false;

				// Updating Retrieve Roles
				if (usersReq.getRole() != null && !usersReq.getRole().isEmpty()) {
					hql.append(" retrieveRole = :retrieveRole ");
					addComma = true;
				}

				// Updating Business Roles
				if (usersReq.getBusinessRole() != null && !usersReq.getBusinessRole().isEmpty()) {
					if (addComma)
						hql.append(", ");
					hql.append(" businessRole = :businessRole ");
				}

				hql.append(" where userId = :userId AND username = :username ");

				Query query = session.createQuery(hql.toString());

				// Setting Parameters
				if (usersReq.getRole() != null && !usersReq.getRole().isEmpty()) {
					query.setParameter("retrieveRole", usersReq.getRole());
				}

				if (usersReq.getBusinessRole() != null && !usersReq.getBusinessRole().isEmpty()) {
					String roles = null;
					try {
						roles = new ObjectMapper().writeValueAsString(usersReq.getBusinessRole());
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:   {}", e);
					}
					query.setParameter("businessRole", roles);
				}

				query.setParameter("userId", Long.valueOf(usersReq.getUserId()));
				query.setParameter("username", usersReq.getUsername());

				int rowsUpdated = query.executeUpdate();
				log.debug("Retrieve Users Row Updated: {} ", rowsUpdated);
			}

		} catch (Exception e) {
			log.error("Exception occured while Updating Retrieve Users Roles Values : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}

	}

	@Override
	public int updateRetrieveMembers(UpdateCenteAssignmentReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String assigneeUsername = "";
			Long assigneeUserId = 0L;

			// Fetching username and userId
			String hql = "SELECT username, userId FROM RetrieveUsers " + " WHERE userFullName = :userFullName";
			List<Object[]> resultObjects = session.createQuery(hql, Object[].class)
					.setParameter("userFullName", req.getName()).list();
			log.debug("resultObjects:   {}", resultObjects);
			if (resultObjects != null && !resultObjects.isEmpty()) {
				Object[] result = resultObjects.get(0);
				assigneeUsername = (String) result[0];
				assigneeUserId = (Long) result[1];
				log.debug("assigneeUsername: {}", assigneeUsername);
				log.debug("assigneeUserId: {}", assigneeUserId);
				log.debug("assigneeFullname: {}", req.getName());
			}
//			List<String> bbcList = new ArrayList<>();
//			for (Map.Entry<String, List<String>> entry : facilities.entrySet()) {
//				String columnName = entry.getKey();
//				List<String> values = entry.getValue();
//
//				String bbcHQL = "Select DISTINCT(bluebookId) FROM FacilityDetails WHERE ";
//
//				if (columnName.equalsIgnoreCase("division")) {
//					bbcHQL += " division IN :division ";
//					bbcList = session.createQuery(bbcHQL).setParameter("division", values).list();
//
//				} else if (columnName.equalsIgnoreCase("market")) {
//					bbcHQL += " market IN :market ";
//					bbcList = session.createQuery(bbcHQL).setParameter("market", values).list();
//
//				} else if (columnName.equalsIgnoreCase("territory")) {
//					bbcHQL += " territory IN :territory ";
//					bbcList = session.createQuery(bbcHQL).setParameter("territory", values).list();
//
//				} else if (columnName.equalsIgnoreCase("bbc")) {
//					bbcHQL += " bluebookId IN :bluebookId ";
//					bbcList = session.createQuery(bbcHQL).setParameter("bluebookId", values).list();
//
//				} else if (columnName.equalsIgnoreCase("ihealConfig")) {
//					bbcHQL += " currentFacilityType IN :currentFacilityType ";
//					bbcList = session.createQuery(bbcHQL).setParameter("currentFacilityType", values).list();
//				}
//
//			}

			// Finally Updating retrieve members table
//			for (String bbc : bbcList) {
//				String updateHQL = "UPDATE RetrieveMembers SET awdDocSpecialist = :awdDocSpecialist,"
//						+ " awdDocSpecialistUsername = :awdDocSpecialistUsername,"
//						+ " awdDocSpecialistUserId = :awdDocSpecialistUserId " + " WHERE bluebookCode = :bluebookCode ";
//
//				int rowChanges = session.createQuery(updateHQL).setParameter("awdDocSpecialist", assigneeName)
//						.setParameter("awdDocSpecialistUsername", assigneeUsername)
//						.setParameter("awdDocSpecialistUserId", assigneeUserId).setParameter("bluebookCode", bbc)
//						.executeUpdate();
//			}

			  // Start building the dynamic HQL query for updating multiple columns
	        StringBuilder updateHQL = new StringBuilder("UPDATE RetrieveMembers SET ");

	        // Dynamically append each business role column to the SET clause
	        for (int i = 0; i < req.getBusinessRoles().size(); i++) {
	        String role =	parseRoles(req.getBusinessRoles().get(i));
	       
	            updateHQL.append(role).append(" = :assigneeName, ");
	            updateHQL.append(role+"Username").append(" = :assigneeUsername, ");
	            updateHQL.append(role+"UserId").append(" = :assigneeUserId");
	            if (i < req.getBusinessRoles().size() - 1) {
	                updateHQL.append(", "); // Add comma between columns
	            }
	        }

	        // Add the WHERE clause to match the bluebookCode
	        updateHQL.append(" WHERE bluebookCode IN (:bluebookCode)");
	       

	        // Create the query using Hibernate
	        int rowChanges = session.createQuery(updateHQL.toString())
	                .setParameter("assigneeName", req.getName())
	                .setParameter("assigneeUsername", assigneeUsername)
	                .setParameter("assigneeUserId", assigneeUserId)
	                .setParameter("bluebookCode", req.getBbc())
	                .executeUpdate();
	        log.info("Updated rows: {}", rowChanges);
	        return rowChanges;
		} catch (Exception e) {
			log.error("Exception occured while Updating Retrieve Members Values : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}

	}
//
	public String parseRoles(String role) {
		 switch (role.toLowerCase()) {
	        case "awdanalyst":
	            return "awdDocSpecialist";
	        case "awdclerk": 
	            return "awdDocClerk";
	        case "npwtanalyst":
	            return "npwtDocAnalyst";
	        case "npwtclerk":
	            return "npwtDocClerk";
	        case "ctpanalyst":
	            return "ctpAnalyst";
	        case "ctpclerk":
	            return "ctpClerk";
	        case "operationsspecialist":
	            return "operationsSpecialist";
	        default:
	            log.warn("Unrecognized role: {}", role);
	            return ""; // Return an empty string for invalid roles
	    }
	}

	@Override
	public Map<String, Object> getFilteredRetrieveMemberstoExcel(AdminDashboardReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> list = new ArrayList<>();
		List<RetrieveMembers> allList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		try {

			String query = "SELECT t1.active, t1.retrieveMemberId, t1.bluebookCode, t1.operationsSpecialist, "
					+ " t1.awdDocClerk, t1.awdDocClerkUsername, t1.awdDocSpecialist, t1.awdDocSpecialistUsername,"
					+ " t1.npwtDocClerk, t1.npwtDocClerkUsername, t1.npwtDocAnalyst, t1.npwtDocAnalystUsername, "
					+ " t1.ctpClerk, t1.ctpClerkUsername, t1.ctpAnalyst, t1.ctpAnalystUsername, "
					+ "  t2.territory, t2.division, t2.market, t2.currentFacilityType "
					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId "
					+ " WHERE t1.active = 1 ";

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {
					String filteString = getFilterColumnName(filterReq);
					query += " AND ";

					switch (filteString) {
					case "t1.bluebookCode": {
						List<String> bluebookCodeList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " t1.bluebookCode IN :bluebookCode ";
						parameters.put("bluebookCode", bluebookCodeList);
					}
						break;
					case "t1.operationsSpecialist": {
						List<String> operationsSpecialistList = FilterRequestUtil
								.getListFromDelimitedStr(req.getOpsSpecialist());
						query += " t1.operationsSpecialist IN :operationsSpecialist ";
						parameters.put("operationsSpecialist", operationsSpecialistList);
					}
						break;
					case "t1.awdDocClerk": {
						List<String> awdDocClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getAwdClerk());
						query += " t1.awdDocClerk IN :awdDocClerk ";
						parameters.put("awdDocClerk", awdDocClerkList);
					}
						break;
					case "t1.awdDocSpecialist": {
						List<String> awdDocSpecialistList = FilterRequestUtil
								.getListFromDelimitedStr(req.getAwdSpecialist());
						query += " t1.awdDocSpecialist IN :awdDocSpecialist ";
						parameters.put("awdDocSpecialist", awdDocSpecialistList);
					}
						break;
					case "t1.npwtDocClerk": {
						List<String> npwtDocClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getNpwtClerk());
						query += " t1.npwtDocClerk IN :npwtDocClerk ";
						parameters.put("npwtDocClerk", npwtDocClerkList);
					}
						break;
					case "t1.npwtDocAnalyst": {
						List<String> npwtDocAnalystList = FilterRequestUtil
								.getListFromDelimitedStr(req.getNpwtSpecialist());
						query += " t1.npwtDocAnalyst IN :npwtDocAnalyst ";
						parameters.put("npwtDocAnalyst", npwtDocAnalystList);
					}
						break;
					case "t1.ctpClerk": {
						List<String> ctpClerkList = FilterRequestUtil.getListFromDelimitedStr(req.getCtpClerk());
						query += " t1.ctpClerk IN :ctpClerk ";
						parameters.put("ctpClerk", ctpClerkList);
					}
						break;
					case "t1.ctpAnalyst": {
						List<String> ctpAnalystList = FilterRequestUtil.getListFromDelimitedStr(req.getCtpSpecialist());
						query += " t1.ctpAnalyst IN :ctpAnalyst ";
						parameters.put("ctpAnalyst", ctpAnalystList);
					}
						break;
					case "t2.territory": {
						List<String> territoryList = FilterRequestUtil.getListFromDelimitedStr(req.getTerritory());
						query += " t2.territory IN :territory ";
						parameters.put("territory", territoryList);
					}
						break;
					case "t2.division": {
						List<String> divisionList = FilterRequestUtil.getListFromDelimitedStr(req.getDivision());
						query += " t2.division IN :division ";
						parameters.put("division", divisionList);
					}
						break;
					case "t2.market": {
						List<String> marketList = FilterRequestUtil.getListFromDelimitedStr(req.getMarket());
						query += " t2.market IN :market ";
						parameters.put("market", marketList);
					}
						break;
					case "t2.currentFacilityType": {
						List<String> currentFacilityTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getIhealConfig());
						query += " t2.currentFacilityType IN :currentFacilityType ";
						parameters.put("currentFacilityType", currentFacilityTypeList);
					}
						break;
					default:
						break;
					}
				}
			}
			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				query = sortList(req, query);

			} else {
				query += " order by t1.bluebookCode asc";
			}

			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			int count;
			list = session.createQuery(query, Object[].class).setProperties(parameters).list();

			allList = session.createQuery(query).setProperties(parameters).list();

			count = allList.size();

			listCount.put("Count", count);
			listCount.put("data", list);
			log.debug("Retrieve Members List Size:   {} ", count);

		} catch (Exception e) {
			log.error("Exception occured while fetching Filtered Retrieve Members records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return listCount;
	}

	@Override
	public List<Object[]> getRetrieveMembersDatatoExcel(AdminDashboardReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<Object[]> list = new ArrayList<>();
		try {
			String hql = "SELECT t1.active, t1.retrieveMemberId, t1.bluebookCode, t1.operationsSpecialist, "
					+ " t1.awdDocClerk, t1.awdDocClerkUsername, t1.awdDocSpecialist, t1.awdDocSpecialistUsername,"
					+ "   t1.npwtDocClerk, t1.npwtDocClerkUsername, t1.npwtDocAnalyst, t1.npwtDocAnalystUsername, "
					+ " t1.ctpClerk, t1.ctpClerkUsername, t1.ctpAnalyst, t1.ctpAnalystUsername, "
					+ "  t2.territory, t2.division, t2.market, t2.currentFacilityType "
					+ " FROM RetrieveMembers t1 JOIN FacilityDetails t2 ON t1.bluebookCode = t2.bluebookId "
					+ " WHERE t1.active = 1 ";

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by t1.bluebookCode asc";
			}

			log.info("query : {}", hql);

			list = session.createQuery(hql, Object[].class).list();

		} catch (Exception e) {
			log.error("CustomException occured while fetching Retrieve Members List: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return list;
	}

}
