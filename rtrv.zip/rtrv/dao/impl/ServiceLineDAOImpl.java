package com.healogics.rtrv.dao.impl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.ServiceLineDAO;
import com.healogics.rtrv.dto.SaveServiceLineReq;
import com.healogics.rtrv.dto.SaveServiceLineRes;
import com.healogics.rtrv.entity.UserPreference;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class ServiceLineDAOImpl implements ServiceLineDAO {

	private final Logger log = LoggerFactory
			.getLogger(ServiceLineDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public ServiceLineDAOImpl(@Qualifier("SessionFactory1")SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public SaveServiceLineRes saveServiceLine(SaveServiceLineReq req)
			throws CustomException {
		log.debug("Save Service Line Req:  {}" , req);

		DateTimeFormatter timeFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime currTime = LocalDateTime.now(ZoneOffset.UTC);
		String originalTime = currTime.atZone(ZoneOffset.UTC)
				.format(timeFormat);
		LocalDateTime currentTime = LocalDateTime.parse(originalTime,
				timeFormat);

		SaveServiceLineRes res = new SaveServiceLineRes();
		Session session = this.sessionFactory.getCurrentSession();
		UserPreference userPreference = new UserPreference();
		try {
			UserPreference userPref = session
					.createQuery("FROM UserPreference WHERE userId = :userId",
							UserPreference.class)
					.setParameter("userId", req.getUserId()).setMaxResults(1)
					.uniqueResult();
			log.debug("userPref:   {}",userPref);
			if (userPref != null) {
				log.debug("userPref != null:   {}",userPref);
				if (req.getServiceLineCode() != null
						&& !req.getServiceLineCode().isEmpty()) {
					userPref.setServiceLineCode(req.getServiceLineCode());
				} else {
					userPref.setServiceLineCode(null);
				}
				
				if (req.getServiceLineDesc() != null
						&& !req.getServiceLineDesc().isEmpty()) {
					userPref.setServiceLineDesc(req.getServiceLineDesc());
				} else {
					userPref.setServiceLineDesc(null);
				}
				
				if (req.getAwdDashboard() != null
						&& !req.getAwdDashboard().isEmpty()) {
					userPreference.setAwdDashboard(req.getAwdDashboard());
				} else {
					userPreference.setAwdDashboard(null);
				}  
			
				if (req.getCtpDashboard() != null
						&& !req.getCtpDashboard().isEmpty()) {
					userPref.setCtpDashboard(req.getCtpDashboard());
				} else {
					userPref.setCtpDashboard(null);
				}
				
				if (req.getLastUpdatedBy() != null
						&& !req.getLastUpdatedBy().isEmpty()) {
					userPref.setLastUpdatedBy(req.getLastUpdatedBy());
				} else {
					userPref.setLastUpdatedBy(null);
				}

				userPref.setLastUpdatedTimestamp(currentTime);

				if (req.getNpwtDashboard() != null
						&& !req.getNpwtDashboard().isEmpty()) {
					userPref.setNpwtDashboard(req.getNpwtDashboard());
				} else {
					userPref.setNpwtDashboard(null);
				}
				userPreference.setAvatarColor(req.getColorCodes());
				session.update(userPref);
			} else {
				log.debug("userPref else:   {}",userPref);
				if (req.getUserId() != null) {
					userPreference.setUserId(req.getUserId());
				} else {
					userPreference.setUserId(null);
				}
				if (req.getAwdDashboard() != null
						&& !req.getAwdDashboard().isEmpty()) {
					userPreference.setAwdDashboard(req.getAwdDashboard());
				} else {
					userPreference.setAwdDashboard(null);
				}  
				if (req.getBluebookId() != null
						&& !req.getBluebookId().isEmpty()) {
					userPreference.setBluebookId(req.getBluebookId());
				} else {
					userPreference.setBluebookId(null);
				}
				if (req.getCreatedBy() != null
						&& !req.getCreatedBy().isEmpty()) {
					userPreference.setCreatedBy(req.getCreatedBy());
				} else {
					userPreference.setCreatedBy(null);
				}
				userPreference.setCreatedTimestamp(currentTime);
				if (req.getCtpDashboard() != null
						&& !req.getCtpDashboard().isEmpty()) {
					userPreference.setCtpDashboard(req.getCtpDashboard());
				} else {
					userPreference.setCtpDashboard(null);
				}
				if (req.getFacilityId() != null) {
					userPreference.setFacilityId(req.getFacilityId());
				} else {
					userPreference.setFacilityId(null);
				}
				if (req.getLastUpdatedBy() != null
						&& !req.getLastUpdatedBy().isEmpty()) {
					userPreference.setLastUpdatedBy(req.getLastUpdatedBy());
				} else {
					userPreference.setLastUpdatedBy(null);
				}
				userPreference.setLastUpdatedTimestamp(currentTime);
				if (req.getNpwtDashboard() != null
						&& !req.getNpwtDashboard().isEmpty()) {
					userPreference.setNpwtDashboard(req.getNpwtDashboard());
				} else {
					userPreference.setNpwtDashboard(null);
				}
				if (req.getServiceLineCode() != null
						&& !req.getServiceLineCode().isEmpty()) {
					userPreference.setServiceLineCode(req.getServiceLineCode());
				} else {
					userPreference.setServiceLineCode(null);
				}
				if (req.getServiceLineDesc() != null
						&& !req.getServiceLineDesc().isEmpty()) {
					userPreference.setServiceLineDesc(req.getServiceLineDesc());
				} else {
					userPreference.setServiceLineDesc(null);
				}
				if (req.getUserFullname() != null
						&& !req.getUserFullname().isEmpty()) {
					userPreference.setUserFullname(req.getUserFullname());
				} else {
					userPreference.setUserFullname(null);
				}
				if (req.getUsername() != null && !req.getUsername().isEmpty()) {
					userPreference.setUsername(req.getUsername());
				} else {
					userPreference.setUsername(null);
				}
				userPreference.setAvatarColor(req.getColorCodes());
				session.save(userPreference);
			}

			log.info("User Preference:  {}" , userPreference);

			res.setResponseCode("0");
			res.setResponseDesc(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occurred: {}" , e);
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
			throw new CustomException(e.getMessage());
		}
		return res;
	}

	@Override
	public SaveServiceLineRes updateUserColorCodes(SaveServiceLineReq req)
			throws CustomException {
		log.debug("Save Service Line Req Update Color Codes:  {}" , req);

		DateTimeFormatter timeFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime currTime = LocalDateTime.now(ZoneOffset.UTC);
		String originalTime = currTime.atZone(ZoneOffset.UTC)
				.format(timeFormat);
		LocalDateTime currentTime = LocalDateTime.parse(originalTime,
				timeFormat);

		SaveServiceLineRes res = new SaveServiceLineRes();
		Session session = this.sessionFactory.getCurrentSession();

		try {
			UserPreference userPref = session
					.createQuery("FROM UserPreference WHERE userId = :userId",
							UserPreference.class)
					.setParameter("userId", req.getUserId()).setMaxResults(1)
					.uniqueResult();

			if (userPref != null && req.getColorCodes() != null) {
				userPref.setAvatarColor(req.getColorCodes());
				userPref.setLastUpdatedTimestamp(currentTime);
				userPref.setLastUpdatedBy(req.getLastUpdatedBy());
				session.update(userPref);
			}

			res.setResponseCode("0");
			res.setResponseDesc(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occurred: {}" , e);
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
			throw new CustomException(e.getMessage());
		}
		return res;
	}

}
