package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.DataExtractorDAO2;
import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentStore;
import com.healogics.rtrv.entity.DocumentationHistory2;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.entity.UserNotes2;

@Component
@Service
@Repository
@TransactionManager2
public class DataExtractorDAO2Impl implements DataExtractorDAO2{
	
	private final Logger log = LoggerFactory.getLogger(DataExtractorDAO2Impl.class);

	@Autowired
	@Qualifier("SessionFactory2")
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	@Override
	public List<AppNotifications> extractAppNotificationDataNPWT(
			Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<AppNotifications> appNotificationData = new ArrayList<>();
		try {
			String hql = "FROM AppNotifications a"
					+ " WHERE a.createdTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			appNotificationData = (List<AppNotifications>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractAppNotificationData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return appNotificationData;
	}
	
	@Override
	public List<AppNotifications> extractAppNotificationDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<AppNotifications> appNotificationData = new ArrayList<>();
		try {
			String hql = "FROM AppNotifications a"
					+ " WHERE a.createdTimestamp >= :dataExtractorTimestamp"
					+ " AND a.createdTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			appNotificationData = (List<AppNotifications>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractAppNotificationData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return appNotificationData;
	}
	
	
	@Override
	public List<DocumentStore> extractDocumentStoreDataNPWT(
			Timestamp docStoreExtractorTimestampNPWT) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentStore> docStoreDataNPWT = new ArrayList<>();
		try {
			String hql = "FROM DocumentStore a"
					+ " WHERE a.docSentTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			docStoreDataNPWT = (List<DocumentStore>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", docStoreExtractorTimestampNPWT)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocumentStoreDataNPWT: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docStoreDataNPWT;
	}
	
	@Override
	public List<DocumentStore> extractDocumentStoreDataNPWTHistorical(
			Timestamp docStoreExtractorTimestampNPWT, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentStore> docStoreDataNPWT = new ArrayList<>();
		try {
			String hql = "FROM DocumentStore a"
					+ " WHERE a.docSentTimestamp >= :dataExtractorTimestamp"
					+ " AND a.docSentTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			docStoreDataNPWT = (List<DocumentStore>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", docStoreExtractorTimestampNPWT)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocumentStoreDataNPWTHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docStoreDataNPWT;
	}
	
	@Override
	public List<DocumentationHistory2> extractDocHistoryDataNPWT(
			Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentationHistory2> docHistoryListNPWT = new ArrayList<>();
		try {
			String hql = "FROM DocumentationHistory2 a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			docHistoryListNPWT = (List<DocumentationHistory2>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocHistoryData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docHistoryListNPWT;
	}
	
	@Override
	public List<DocumentationHistory2> extractDocHistoryDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentationHistory2> docHistoryListNPWT = new ArrayList<>();
		try {
			String hql = "FROM DocumentationHistory2 a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
					+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			docHistoryListNPWT = (List<DocumentationHistory2>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocHistoryData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docHistoryListNPWT;
	}
	
	@Override
	public List<UniformDashboard> extractNPWTDashboardData(
			Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<UniformDashboard> npwtDashboardList = new ArrayList<>();
		try {
			String hql = "FROM UniformDashboard a"
					+ " WHERE a.lastTeamUpdatedTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			npwtDashboardList = (List<UniformDashboard>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractNPWTDashboardData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return npwtDashboardList;
	}
	
	@Override
	public List<UniformDashboard> extractNPWTDashboardDataHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<UniformDashboard> npwtDashboardList = new ArrayList<>();
		try {
			String hql = "FROM UniformDashboard a"
					+ " WHERE a.lastTeamUpdatedTimestamp >= :dataExtractorTimestamp"
					+ " AND a.lastTeamUpdatedTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			npwtDashboardList = (List<UniformDashboard>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractNPWTDashboardDataHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return npwtDashboardList;
	}
	
	@Override
	public List<PrimaryKeyLookup> extractPrimaryKeyLookupDataNPWT(
			Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<PrimaryKeyLookup> primaryKeyLookupListNPWT = new ArrayList<>();
		try {
			String hql = "FROM PrimaryKeyLookup a"
					+ " WHERE a.createdTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			primaryKeyLookupListNPWT = (List<PrimaryKeyLookup>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractPrimaryKeyLookupDataNPWT: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return primaryKeyLookupListNPWT;
	}
	
	@Override
	public List<PrimaryKeyLookup> extractPrimaryKeyLookupDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<PrimaryKeyLookup> primaryKeyLookupListNPWT = new ArrayList<>();
		try {
			String hql = "FROM PrimaryKeyLookup a"
					+ " WHERE a.createdTimestamp >= :dataExtractorTimestamp"
					+ " AND a.createdTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			primaryKeyLookupListNPWT = (List<PrimaryKeyLookup>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractPrimaryKeyLookupDataNPWTHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return primaryKeyLookupListNPWT;
	}
	
	@Override
	public List<UserNotes2> extractUserNotesDataNPWT(
			Timestamp dataExtractorTimestamp)  throws Exception{
		Session session = this.sessionFactory.getCurrentSession();
		List<UserNotes2> userNotesListNPWT = new ArrayList<>();
		try {
			String hql = "FROM UserNotes2 a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			userNotesListNPWT = (List<UserNotes2>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractUserNotesData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return userNotesListNPWT;
	}
	
	@Override
	public List<UserNotes2> extractUserNotesDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp)  throws Exception{
		Session session = this.sessionFactory.getCurrentSession();
		List<UserNotes2> userNotesListNPWT = new ArrayList<>();
		try {
			String hql = "FROM UserNotes2 a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
					+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			userNotesListNPWT = (List<UserNotes2>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("dataExtractorTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractUserNotesDataNPWTHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return userNotesListNPWT;
	}

	@Override
	public List<MasterAppNotification> extractAppNotificationData(Timestamp dataExtractorTimestamp)
			throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterAppNotification> appNotificationData = new ArrayList<>();
		try {
			String hql = "FROM MasterAppNotification a"
					+ " WHERE a.createdTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			appNotificationData = (List<MasterAppNotification>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractAppNotificationData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return appNotificationData;
	}
	
	@Override
	public List<MasterAppNotification> extractAppNotificationDataCTPHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp)
			throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterAppNotification> appNotificationData = new ArrayList<>();
		try {
			String hql = "FROM MasterAppNotification a"
					+ " WHERE a.createdTimestamp >= :dataExtractorTimestamp"
					+ " AND a.createdTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			appNotificationData = (List<MasterAppNotification>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractAppNotificationDataCTPHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return appNotificationData;
	}

	@Override
	public List<DocumentStore> extractDocumentStoreData(Timestamp docStoreExtractorTimestampCTP) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentStore> docStoreDataCTP = new ArrayList<>();
		try {
			String hql = "FROM DocumentStore a"
					+ " WHERE a.docSentTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			docStoreDataCTP = (List<DocumentStore>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", docStoreExtractorTimestampCTP)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocumentStoreDataCTP: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docStoreDataCTP;
	}
	
	@Override
	public List<DocumentStore> extractDocumentStoreDataCTPHistorical(
			Timestamp docStoreExtractorTimestampCTP, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentStore> docStoreDataCTP = new ArrayList<>();
		try {
			String hql = "FROM DocumentStore a"
					+ " WHERE a.docSentTimestamp >= :dataExtractorTimestamp"
					+ " AND a.docSentTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			docStoreDataCTP = (List<DocumentStore>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", docStoreExtractorTimestampCTP)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocumentStoreDataCTPHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docStoreDataCTP;
	}

	@Override
	public List<DocumentationHistory2> extractDocHistoryData(
			Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentationHistory2> docHistoryListCTP = new ArrayList<>();
		try {
			String hql = "FROM DocumentationHistory2 a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";

			log.debug("hql : " + hql);

			docHistoryListCTP = (List<DocumentationHistory2>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp).getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocHistoryData: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		return docHistoryListCTP;
	}
	
	@Override
	public List<DocumentationHistory2> extractDocHistoryDataCTPHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp)
			throws Exception {
			Session session = this.sessionFactory.getCurrentSession();
			List<DocumentationHistory2> docHistoryListCTP = new ArrayList<>();
			try {
				String hql = "FROM DocumentationHistory2 a"
						+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
						+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
				
				log.debug("hql : " +hql);
				
				docHistoryListCTP = (List<DocumentationHistory2>) session.createQuery(hql)
						.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
						.setParameter("endTimestamp", endTimestamp)
						.getResultList();
			} catch (Exception e) {
				log.error("Exception occured in extractDocHistoryDataCTPHistorical: " +e.getMessage());
				throw new Exception(e.getMessage());
			}
			return docHistoryListCTP;
		}

	@Override
	public List<UserNotes2> extractUserNotesData(Timestamp dataExtractorTimestamp) throws Exception {
			Session session = this.sessionFactory.getCurrentSession();
			List<UserNotes2> userNotesListNPWT = new ArrayList<>();
			try {
				String hql = "FROM UserNotes2 a"
						+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";
				
				log.debug("hql : " +hql);
				
				userNotesListNPWT = (List<UserNotes2>) session.createQuery(hql)
						.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
						.getResultList();
			} catch (Exception e) {
				log.error("Exception occured in extractUserNotesData: " +e.getMessage());
				throw new Exception(e.getMessage());
			}
			return userNotesListNPWT;
		}
	
	@Override
	public List<UserNotes2> extractUserNotesDataCTPHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
			Session session = this.sessionFactory.getCurrentSession();
			List<UserNotes2> userNotesListNPWT = new ArrayList<>();
			try {
				String hql = "FROM UserNotes2 a"
						+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
						+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
				
				log.debug("hql : " +hql);
				
				userNotesListNPWT = (List<UserNotes2>) session.createQuery(hql)
						.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
						.setParameter("endTimestamp", endTimestamp)
						.getResultList();
			} catch (Exception e) {
				log.error("Exception occured in extractUserNotesDataCTPHistorical: " +e.getMessage());
				throw new Exception(e.getMessage());
			}
			return userNotesListNPWT;
		}

	@Override
	public List<CTPDashboard> extractCTPDashboardData(Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<CTPDashboard> ctpDashboardList = new ArrayList<>();
		try {
			String hql = "FROM CTPDashboard a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			ctpDashboardList = (List<CTPDashboard>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractCTPDashboardData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return ctpDashboardList;
	}

	@Override
	public List<CTPDashboard> extractCTPDashboardDataHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<CTPDashboard> ctpDashboardList = new ArrayList<>();
		try {
			String hql = "FROM CTPDashboard a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
					+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			ctpDashboardList = (List<CTPDashboard>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractCTPDashboardDataHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return ctpDashboardList;
	}

}
