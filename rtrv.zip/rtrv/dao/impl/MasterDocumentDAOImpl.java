package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.MasterDocumentDAO;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager2
public class MasterDocumentDAOImpl implements MasterDocumentDAO {

	private final Logger log = LoggerFactory.getLogger(MasterDocumentDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public MasterDocumentDAOImpl(@Qualifier("SessionFactory2") SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public MasterDocumentStore getDocumentContent(String documentRequestId,
			String documentToken) throws CustomException {
		MasterDocumentStore documentStoreObj = null;
		Session session = this.sessionFactory.getCurrentSession();
		try {
			log.debug("documentRequestId:   {}", documentRequestId);
			log.debug("documentToken:  {}", documentToken);

			String hql = "FROM MasterDocumentStore WHERE docRequestId = :docRequestId "
					+ " AND documentToken = :documentToken ";
			
			documentStoreObj = session.createQuery(hql, MasterDocumentStore.class)
					.setParameter("docRequestId", documentRequestId)
					.setParameter("documentToken", documentToken)
					.uniqueResult();
			
		} catch (Exception e) {
			log.error("Exception occured while Getting Document Content: " +e.getMessage());
		}
		return documentStoreObj;
	}
	
	@Override
	public List<MasterDocumentStore> getAttachments(String orderId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterDocumentStore> stores = new ArrayList<MasterDocumentStore>();
		try {
			String hql = "FROM MasterDocumentStore where orderId = :orderId ";
			stores = session.createQuery(hql).setParameter("orderId", orderId)
					.list();
			log.debug("Store: {}", stores.size());
		} catch (Exception e) {
			log.error("Exception occured while Fetching Documents : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return stores;
	}
	
	@Override
	public boolean saveDocumentContent(MasterSubmitChartReq req,
			MasterDocumentStore doc, boolean isManual) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			if (isManual) {
				//update document status here
				String hql = "UPDATE MasterDocumentStore SET lastUpdatedUserId = :lastUpdatedUserId, "
						+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
						+ " lastUpdatedUsername = :lastUpdatedUsername, "
						+ " documentStatus = :documentStatus, "
						+ " documentAvailable = :documentAvailable "
						+ " WHERE documentToken = :documentToken "
						+ " AND orderId = :orderId";
				
				log.debug("hql : " +hql);
				
				String orderId = "";
				if (req.getServiceLine().equalsIgnoreCase("CTP")) {
					orderId = req.getOrderId();
				} else {
					orderId = req.getRequestId();
				}
				
				log.debug("orderId : " +orderId);

				// Saving details
				session.createQuery(hql)
						.setParameter("lastUpdatedUserId", Long.valueOf(req.getLastUpdatedUserId()))
						.setParameter("lastUpdatedUserFullName", req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername", req.getLastUpdatedUserName())
						.setParameter("documentStatus", doc.getDocumentStatus())
						.setParameter("documentAvailable", doc.getDocumentAvailable())
						.setParameter("documentToken", doc.getDocumentToken())
						.setParameter("orderId", orderId)
						.executeUpdate();

			} else {
				String hql = "UPDATE MasterDocumentStore SET lastUpdatedUserId = :lastUpdatedUserId, "
						+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
						+ " lastUpdatedUsername = :lastUpdatedUsername, "
						+ " documentContent = :documentContent, "
						+ " documentStatus = :documentStatus, "
						+ " documentAvailable = :documentAvailable, "
						+ " ihealDocRequestStatus =:ihealDocRequestStatus, "
						+ " ihealDocRequestTimestamp =:ihealDocRequestTimestamp, "
						+ " docDownloadStatus =:docDownloadStatus, "
						+ " errorCode =:errorCode, "
						+ " errorMessage =:errorMessage, "
						+ " docDownloadTimestamp =:docDownloadTimestamp "
						+ " WHERE documentToken = :documentToken "
						+ " AND orderId = :orderId";
				
				log.debug("hql : " +hql);
				
				String orderId = "";
				if (req.getServiceLine().equalsIgnoreCase("CTP")) {
					orderId = req.getOrderId();
				} else {
					orderId = req.getRequestId();
				}
				
				log.debug("orderId : " +orderId);

				// Saving details
				session.createQuery(hql).setParameter("lastUpdatedUserId",
							Long.valueOf(req.getLastUpdatedUserId()))
						.setParameter("lastUpdatedUserFullName", req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername", req.getLastUpdatedUserName())
						.setParameter("documentContent", doc.getDocumentContent())
						.setParameter("documentStatus", doc.getDocumentStatus())
						.setParameter("documentAvailable", doc.getDocumentAvailable())
						.setParameter("ihealDocRequestStatus", doc.getIhealDocRequestStatus())
						.setParameter("ihealDocRequestTimestamp", doc.getIhealDocRequestTimestamp())
						.setParameter("docDownloadStatus", doc.getDocDownloadStatus())
						.setParameter("errorCode", doc.getErrorCode())
						.setParameter("errorMessage", doc.getErrorMessage())
						.setParameter("docDownloadTimestamp", doc.getDocDownloadTimestamp())
						.setParameter("documentToken", doc.getDocumentToken())
						.setParameter("orderId", orderId)
						.executeUpdate();
			}
		} catch (Exception e) {
			log.error("Exception occured while saving document content:  {}", e.getMessage());
		}
		return true;
	}
	
	@Override
	public boolean saveDocNotificationStatus(MasterSubmitChartReq req,
			MasterDocumentStore doc) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "UPDATE MasterDocumentStore SET lastUpdatedUserId = :lastUpdatedUserId, "
					+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
					+ " lastUpdatedUsername = :lastUpdatedUsername, "
					+ " docNotificationStatus = :docNotificationStatus, "
					+ " docNotificationTimestamp = :docNotificationTimestamp "
					+ " WHERE documentToken = :documentToken "
					+ " AND orderId = :orderId";
					
			log.debug("hql : " +hql);
			
			String orderId = "";
			if (req.getServiceLine().equalsIgnoreCase("CTP")) {
				orderId = req.getOrderId();
			} else {
				orderId = req.getRequestId();
			}
			
			log.debug("orderId : " +orderId);
			
			// Saving details
			session.createQuery(hql).setParameter("lastUpdatedUserId", Long.valueOf(req.getLastUpdatedUserId()))
					.setParameter("lastUpdatedUserFullName", req.getLastUpdatedUserFullName())
					.setParameter("lastUpdatedUsername", req.getLastUpdatedUserName())
					.setParameter("docNotificationStatus", doc.getDocNotificationStatus())
					.setParameter("docNotificationTimestamp", doc.getDocNotificationTimestamp())
					.setParameter("documentToken", doc.getDocumentToken())
					.setParameter("orderId", orderId)
					.executeUpdate();
			
			
		} catch (Exception e) {
			log.error("Exception occured while saving document content:  {}", e.getMessage());
		}
		return true;
	}
	
	@Override
	public boolean saveGetDocumentStatus(String docToken, String docGetStatus,
			Timestamp docGetTimestamp, String docSentStatus, Timestamp docSentTimestamp) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "UPDATE MasterDocumentStore SET vendorDocGetStatus = :vendorDocGetStatus, "
					+ " vendorDocGetTimestamp = :vendorDocGetTimestamp, "
					+ " docSentStatus = :docSentStatus, "
					+ " docSentTimestamp = :docSentTimestamp "
					+ " WHERE documentToken = :documentToken ";
			
			log.debug("hql : " +hql);

			// Saving details
			session.createQuery(hql)
					.setParameter("vendorDocGetStatus", docGetStatus)
					.setParameter("vendorDocGetTimestamp", docGetTimestamp)
					.setParameter("docSentStatus", docSentStatus)
					.setParameter("docSentTimestamp", docSentTimestamp)
					.setParameter("documentToken", docToken)
					.executeUpdate();
			
		} catch (Exception e) {
			log.error("Exception occured while saving document content:  {}", e.getMessage());
		}
		return true;
	}	
}