package com.healogics.rtrv.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.MasterRetrieveDAO;
import com.healogics.rtrv.entity.VendorAuthDetails;

@Repository
@TransactionManager2
public class MasterRetrieveDAOImpl implements MasterRetrieveDAO {
	private final Logger log = LoggerFactory
			.getLogger(MasterChartReviewDAOImpl.class);

	private final SessionFactory sessionFactory;
	
	public MasterRetrieveDAOImpl(
			@Qualifier("SessionFactory2") SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public boolean isValidUser(String userName, String password) {
		Session session = this.sessionFactory.getCurrentSession();
		boolean isValidUser = false;
		try {
			VendorAuthDetails authDetails = session
					.createQuery("FROM VendorAuthDetails WHERE userName = :userName"
							+ " AND password = :password",
							VendorAuthDetails.class)
					.setParameter("userName", userName)
					.setParameter("password", password)
					.setMaxResults(1).uniqueResult();
			
			if (authDetails != null) {
				isValidUser = true;
			}
		} catch (Exception e) {
			log.debug("Exception occured in isValidUser: {}",
					e.getMessage());
		}
		return isValidUser;
	}
}
