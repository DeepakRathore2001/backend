package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORMESSAGE;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.DocumentsDAO;
import com.healogics.rtrv.dto.AttachmentDetails;
import com.healogics.rtrv.dto.DocumentsListReq;
import com.healogics.rtrv.dto.IHealCustomScanListGetRes;
import com.healogics.rtrv.dto.IHealCustomScanListReq;
import com.healogics.rtrv.dto.IHealDebridementRes;
import com.healogics.rtrv.dto.IHealDocumentsListGetRes;
import com.healogics.rtrv.dto.IHealFileGetReq;
import com.healogics.rtrv.dto.IHealFileGetRes;
import com.healogics.rtrv.dto.IHealProgressNotesListGetRes;
import com.healogics.rtrv.dto.IHealWoundAssessmentListGetResponse;
import com.healogics.rtrv.dto.IHealWoundListGetRes;
import com.healogics.rtrv.dto.ViewAttachmentReq;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.entity.PatientMedicalRecords;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class DocumentsDAOImpl implements DocumentsDAO {

	private final Logger log = LoggerFactory.getLogger(DocumentsDAOImpl.class);

	private final SessionFactory sessionFactory;

	private final Environment env;

	private final RestTemplate restTemplate;

	@Autowired
	public DocumentsDAOImpl(@Qualifier("SessionFactory1") SessionFactory sessionFactory,
			Environment env,
			@Qualifier("httpTemplate1") RestTemplate restTemplate) {
		this.sessionFactory = sessionFactory;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	@Override
	public IHealCustomScanListGetRes getCustomScanList(DocumentsListReq req) {

		IHealCustomScanListGetRes customScanListRes = null;

		String url = env.getProperty(BOConstants.IHEAL_CUSTOMSCAN_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());

		try {
			log.info("IHeal CustomScanListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealCustomScanListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealCustomScanListGetRes.class);
			log.info("IHeal CustomScanListGet URL post Completed ");
			log.debug("iHeal CustomScanListGet Response : {}",
					sresponse.getBody());
			customScanListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in CustomScanListGet API - ",
					e);
			customScanListRes = new IHealCustomScanListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			customScanListRes.setErrorCode(errorResponse.get(ERRORCODE));
			customScanListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in CustomScanListGet API: ",
					e);
			customScanListRes = new IHealCustomScanListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			customScanListRes.setErrorCode(errorResponse.get(ERRORCODE));
			customScanListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return customScanListRes;

	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	@Override
	public IHealDocumentsListGetRes getProviderOrderList(DocumentsListReq req) {
		IHealDocumentsListGetRes providerOrderListRes = null;

		String url = env.getProperty(BOConstants.IHEAL_PROVIDERORDER_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());

		try {
			log.info("IHeal ProviderOrderListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealDocumentsListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealDocumentsListGetRes.class);
			log.info("IHeal ProviderOrderListGet URL post Completed ");
			log.debug("iHeal ProviderOrderListGet Response : {}",
					sresponse.getBody());
			providerOrderListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in ProviderOrderListGet API - ",
					e);
			providerOrderListRes = new IHealDocumentsListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			providerOrderListRes.setErrorCode(errorResponse.get(ERRORCODE));
			providerOrderListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in ProviderOrderListGet API: ",
					e);
			providerOrderListRes = new IHealDocumentsListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			providerOrderListRes.setErrorCode(errorResponse.get(ERRORCODE));
			providerOrderListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return providerOrderListRes;
	}

	@Override
	public IHealProgressNotesListGetRes getProgressNotesList(
			DocumentsListReq req) {
		IHealProgressNotesListGetRes progressNotesListRes = null;

		String url = env.getProperty(BOConstants.IHEAL_PROGRESSNOTES_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq.setCurrentAdmissionOnly(false);

		try {
			log.info("IHeal ProgressNotesListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealProgressNotesListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealProgressNotesListGetRes.class);
			log.info("IHeal ProgressNotesListGet URL post Completed ");
			log.debug("iHeal ProgressNotesListGet Response : {}",
					sresponse.getBody());
			progressNotesListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in ProgressNotesListGet API - ",
					e);
			progressNotesListRes = new IHealProgressNotesListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			progressNotesListRes.setErrorCode(errorResponse.get(ERRORCODE));
			progressNotesListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in ProgressNotesListGet API: ",
					e);
			progressNotesListRes = new IHealProgressNotesListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			progressNotesListRes.setErrorCode(errorResponse.get(ERRORCODE));
			progressNotesListRes
					.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return progressNotesListRes;
	}

	@Override
	public IHealWoundListGetRes getWoundList(DocumentsListReq req) {
		IHealWoundListGetRes res = null;

		String url = env.getProperty(BOConstants.IHEAL_WOUND_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq.setActiveOnly("false");
		
		try {
			log.info("IHeal WoundList URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealWoundListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealWoundListGetRes.class);
			log.info("IHeal WoundList URL post Completed ");
			log.debug("iHeal WoundList Response : {}", sresponse.getBody());
			res = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in WoundList API - ",
					e);
			res = new IHealWoundListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in WoundList API: ", e);
			res = new IHealWoundListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return res;
	}

	@Override
	public IHealDebridementRes getDebridementsList(DocumentsListReq req,
			int id) {
		IHealDebridementRes res = null;
	/*	String startDateString = "";
		String endDateString = "";
		if (req.getStartDate() != null && req.getEndDate() != null
				&& !req.getStartDate().isEmpty()
				&& !req.getEndDate().isEmpty()) {
			startDateString = req.getStartDate();
			endDateString = req.getEndDate();
		} else if (req.getBhcOrderReceivedDate() != null
				&& !req.getBhcOrderReceivedDate().isEmpty()) {
			LocalDate orderDate = LocalDate.parse(req.getBhcOrderReceivedDate(),
					DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			LocalDate startDate = orderDate.plusDays(0);
			LocalDate endDate = orderDate.plusDays(180);
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("yyyy-MM-dd");
			startDateString = startDate.format(formatter);
			endDateString = endDate.format(formatter);
		} else {
			startDateString = "";
			endDateString = "";
		}
		log.debug("Debridements startDateString:   " + startDateString);
		log.debug("Debridements endDateString:   " + endDateString);   */
		String url = env.getProperty(BOConstants.IHEAL_DEBRIDEMENTS_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq
				.setConditionDocumentEntityId(req.getWoundDocumentEntityId());

		try {
			log.info("IHeal DebridementsList URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealDebridementRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealDebridementRes.class);
			log.info("IHeal DebridementsList URL post Completed ");
			log.debug("iHeal DebridementsList Response : {}",
					sresponse.getBody());
			res = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in DebridementsList API - ",
					e);
			res = new IHealDebridementRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in DebridementsList API: ",
					e);
			res = new IHealDebridementRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return res;
	}

	@Override
	public IHealWoundAssessmentListGetResponse getWoundAssessmentList(
			int entity, DocumentsListReq req) {
		IHealWoundAssessmentListGetResponse res = null;

		String startDateString = "";
		String endDateString = "";
		
		if (req.getStartDate() != null && req.getEndDate() != null
				&& !req.getStartDate().isEmpty()
				&& !req.getEndDate().isEmpty()) {
			startDateString = req.getStartDate();
			endDateString = req.getEndDate();
		} else {
			LocalDate currentDate = LocalDate.now();
			LocalDate startDate = currentDate.minusDays(365);
			LocalDate endDate = currentDate;
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("yyyy-MM-dd");
			startDateString = startDate.format(formatter);
			endDateString = endDate.format(formatter);
		}
		
		log.debug("WoundAssessmentList startDateString:   " + startDateString);
		log.debug("WoundAssessmentList endDateString:   " + endDateString);

		String url = env
				.getProperty(BOConstants.IHEAL_WOUND_ASSESSMENT_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		// customScanReq.setWoundDocumentEntityId(entity + "");
		customScanReq.setWoundDocumentEntityId(req.getWoundDocumentEntityId());
		customScanReq.setStartDate(startDateString);
		customScanReq.setEndDate(endDateString);

		try {
			log.info("IHeal WoundAssessmentList URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealWoundAssessmentListGetResponse> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealWoundAssessmentListGetResponse.class);
			log.info("IHeal WoundAssessmentList URL post Completed ");
			log.debug("iHeal WoundAssessmentList Response : {}",
					sresponse.getBody());
			res = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in WoundAssessmentList API - ",
					e);
			res = new IHealWoundAssessmentListGetResponse();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in WoundAssessmentList API: ",
					e);
			res = new IHealWoundAssessmentListGetResponse();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setErrorCode(errorResponse.get(ERRORCODE));
			res.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return res;
	}

	@Override
	public List<AttachmentDetails> getManualAttachmentList(DocumentsListReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();

		List<AttachmentDetails> manualAttachmentList = new ArrayList<>();

		try {

			log.debug("medRecId:  {}", req.getMedRecId());
			log.debug("bhcInvoiceOrderId:   {}", req.getBhcInvoiceOrderId());

			String hql = "FROM PatientMedicalRecords pmr WHERE pmr.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ "AND pmr.bhcInvoiceOrderNo = :bhcInvoiceOrderNo";

			List<PatientMedicalRecords> manualAttachment = session
					.createQuery(hql)
					.setParameter("bhcMedicalRecordId",
							Integer.parseInt(req.getMedRecId()))
					.setParameter("bhcInvoiceOrderNo",
							Integer.parseInt(req.getBhcInvoiceOrderId()))
					.list();

			if (manualAttachment != null) {

				for (PatientMedicalRecords requestAttach : manualAttachment) {
					AttachmentDetails manualAttach = new AttachmentDetails();
					manualAttach.setDocEntityId(requestAttach.getDocumentId());
					manualAttach.setDocName(requestAttach.getDocumentName());
					manualAttach.setGroupName("");
					String[] forTime = requestAttach.getLastUpdatedTimestamp()
							.toString().split(" ");
					manualAttach.setAddedDate(forTime[0]);
					manualAttach.setTestDesc(requestAttach.getDocumentName());
					manualAttach.setManually(true);
					manualAttachmentList.add(manualAttach);
				}
			}
		} catch (Exception e) {
			log.info("Exception occured in getManualAttachment: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return manualAttachmentList;
	}

	@Override
	public ViewAttachmentRes viewIHealAttachment(ViewAttachmentReq req) {
		IHealFileGetRes fileGetRes = null;
		String url = env.getProperty(BOConstants.IHEAL_FILE_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealFileGetReq fileGetReq = new IHealFileGetReq();
		fileGetReq.setPrivateKey(privateKey);
		fileGetReq.setEventDateTime("");
		fileGetReq.setFacilityId(Integer.parseInt(req.getFacilityId()));
		fileGetReq.setPatientId(Integer.parseInt(req.getPatientId()));
		fileGetReq.setUserId(Integer.parseInt(req.getUserId()));
		fileGetReq.setMasterToken(req.getMasterToken());
		fileGetReq.setDocumentEntityId(req.getDocumentEntityId());

		if (req.getiHealFileType().equalsIgnoreCase("customscans")) {
			fileGetReq.setType("CustomScans");
		} else if(req.getiHealFileType().equalsIgnoreCase("testresults")) {
			fileGetReq.setType("TestResults");
		}

		try {
			log.info("IHeal FileGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(fileGetReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealFileGetRes> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request, IHealFileGetRes.class);
			log.info("IHeal FileGet URL post Completed ");
			// log.debug("iHeal FileGet Response : {}", sresponse.getBody());
			fileGetRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in FileGet API - ", e);
			fileGetRes = new IHealFileGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in FileGet API: ", e);
			fileGetRes = new IHealFileGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (Exception e) {
			log.error("Exception occurred in FileGet API: ", e);
			fileGetRes = new IHealFileGetRes();
			/*
			 * HashMap<String, String> errorResponse = extractResponse(
			 * e.getResponseBodyAsString());
			 */
			fileGetRes.setErrorCode("500");
			fileGetRes.setErrorMessage(e.getMessage());
		}

		ViewAttachmentRes res = new ViewAttachmentRes();

		if (fileGetRes != null && fileGetRes.getErrorCode() != null
				&& fileGetRes.getErrorCode().equalsIgnoreCase("0")) {
			fileGetRes.getImageMimeType();
			res.setMimeType(fileGetRes.getImageMimeType());
			res.setDocumentStream(fileGetRes.getImageStream());
			res.setResponseCode("0");
			res.setResponseDesc(DAOConstants.SUCCESS);

		} else if (fileGetRes != null && fileGetRes.getErrorCode() != null
				&& !fileGetRes.getErrorCode().equalsIgnoreCase("0")) {
			res.setResponseCode(fileGetRes.getErrorCode());
			res.setResponseDesc(DAOConstants.FAILED);

		} else {
			res.setResponseCode("1");
			res.setResponseDesc("Invalid response");
		}

		return res;
	}

	@Override
	public ViewAttachmentRes viewManualAttachment(ViewAttachmentReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();

		ViewAttachmentRes res = new ViewAttachmentRes();

		try {

			log.debug("documentId:   {}", req.getDocumentId());
			log.debug("medRecId:  {}", req.getMedRecId());
			log.debug("bhcInvoiceOrderId:   {}", req.getBhcInvoiceOrderId());

			String hql = "FROM PatientMedicalRecords pmr WHERE pmr.documentId = :documentId "
					+ " AND pmr.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND pmr.bhcInvoiceOrderNo = :bhcInvoiceOrderNo";

			PatientMedicalRecords manualAttachment = session
					.createQuery(hql, PatientMedicalRecords.class)
					.setParameter("documentId", req.getDocumentId())
					.setParameter("bhcMedicalRecordId",
							Integer.parseInt(req.getMedRecId()))
					.setParameter("bhcInvoiceOrderNo",
							Integer.parseInt(req.getBhcInvoiceOrderId()))
					.setMaxResults(1).uniqueResult();
			// log.debug("manualAttachment: "+manualAttachment);
			if (manualAttachment != null) {
				res.setDocumentStream(manualAttachment.getDocumentContent());
				int lastIndex = manualAttachment.getDocumentName()
						.lastIndexOf('.');
				if (lastIndex != -1 && lastIndex < manualAttachment
						.getDocumentName().length() - 1) {
					res.setMimeType(manualAttachment.getDocumentName()
							.substring(lastIndex + 1));
					log.debug("mimeType:   {}", manualAttachment
							.getDocumentName().substring(lastIndex + 1));
				}

				res.setResponseCode("0");
				res.setResponseDesc(DAOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(DAOConstants.FAILED);
				res.setDocumentStream(null);
				res.setMimeType(null);
			}
		} catch (Exception e) {
			log.info("Exception occured in getManualAttachment:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return res;
	}

}
