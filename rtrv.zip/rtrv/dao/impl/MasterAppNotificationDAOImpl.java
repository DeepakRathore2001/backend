package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.MasterAppNotificationDAO;
import com.healogics.rtrv.dto.MasterAppNotificaionReq;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.TaggedUser;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager2
public class MasterAppNotificationDAOImpl implements MasterAppNotificationDAO {

	private final Logger log = LoggerFactory.getLogger(AppNotificationDAOImpl.class);

	private final Environment env;

	private final SessionFactory sessionFactory;

	@Autowired
	public MasterAppNotificationDAOImpl(Environment env,
			@Qualifier("SessionFactory2") SessionFactory sf) {
		this.env = env;
		this.sessionFactory = sf;
	}

	@Override
	public Long getAppNotificationCount(String userId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long count = 0L;
		try {
			// last 30 days data only
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_MONTH, -30);
			Date last30DaysDate = calendar.getTime();
			Timestamp last30DaysTimestamp = new Timestamp(last30DaysDate.getTime());
			log.info("last30DaysTimestamp :  {}", last30DaysTimestamp);
			
			String hql = "SELECT count(*) FROM MasterAppNotification WHERE userId = :userId"
					+ " AND createdTimestamp > :createdTimestamp "
					+ " AND readFlag = false";

			count = (Long) session.createQuery(hql)
					.setParameter("userId", Long.valueOf(userId))
					.setParameter("createdTimestamp", last30DaysTimestamp)
					.uniqueResult();
			
		} catch (Exception e) {
			log.error(
					"CustomException occured at count APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return count;
	}
	
	@Override
	public Boolean saveNoteNotifications(SaveMasterNotesReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getTaggedUsers() != null && !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("requestId=");
				sb.append(req.getRequestId());

				sb.append("&notesId=");
				sb.append(req.getNoteId());

				sb.append("&sl=");
				if (req.getServiceLine().equalsIgnoreCase("CTP")) {
					sb.append("CTP");
				} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
					sb.append("NPWT");
				} else {
					log.debug("No ServiceLine found");
				}

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (TaggedUser users : req.getTaggedUsers()) {
					MasterAppNotification appNotifications = new MasterAppNotification();
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications.setCreatorUserFullname(
							req.getLastUpdatedUserFullname());
					appNotifications.setCreatorUserId(
							Long.valueOf(req.getLastUpdatedUserId()));
					appNotifications.setCreatorUsername(
							req.getLastUpdatedUsername());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications.setUserFullname(users.getUserFullName());
					appNotifications.setUserId(users.getUserId());
					appNotifications.setUsername(users.getUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					appNotifications.setNotificationTitle("TAGGED");
					appNotifications.setNotificationDescription(
							req.getDescription());
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error("CustomException occured at Saving Note APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}

	@Override
	public Long updateNotifications(MasterAppNotificaionReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long count = 1L;

		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			
			if (req.getClearedFlag()) {
				String hql = "UPDATE MasterAppNotification SET "
						+ " readFlag = :readFlag, "
						+ " lastUpdatedTimestamp = :lastUpdatedTimestamp "
						+ " WHERE userId = :userId ";

				session.createQuery(hql).setParameter("readFlag", true)
						.setParameter("lastUpdatedTimestamp", currentTime)
						.setParameter("userId", Long.valueOf(req.getUserId()))
						.executeUpdate();

			} else if (req.getReadFlag()) {
				for (String id : req.getNotificationId()) {
					String hql = "UPDATE MasterAppNotification SET "
							+ " readFlag = :readFlag, "
							+ " lastUpdatedTimestamp = :lastUpdatedTimestamp "
							+ " WHERE notificationId = :notificationId "
							+ " AND userId = :userId ";
					
					session.createQuery(hql).setParameter("readFlag", true)
							.setParameter("lastUpdatedTimestamp", currentTime)
							.setParameter("notificationId", Long.valueOf(id))
							.setParameter("userId", Long.valueOf(req.getUserId()))
							.executeUpdate();
				}
				count = 0L;
				log.debug("Updated Notifications.............");
			}

		} catch (Exception e) {
			log.error("CustomException occured at Updating APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return count;
	}

	@Override
	public List<MasterAppNotification> getAppNotification(Long userId,
			Timestamp clearNotificationTimestamp,
			String last30DaysDate) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterAppNotification> notifications = new ArrayList<>();
		try {
			String hql = "";
			if (clearNotificationTimestamp != null) {
				hql = "FROM MasterAppNotification n WHERE n.userId="+ userId
						+ " AND n.createdTimestamp > '" + clearNotificationTimestamp
						+ "' AND n.createdTimestamp > '" + last30DaysDate + "'"
						+ " order by createdTimestamp desc";
			} else {
				hql = "FROM MasterAppNotification n WHERE n.userId=" + userId
						+ " AND n.createdTimestamp > '" + last30DaysDate + "'"
						+ " order by createdTimestamp desc";
			}
			// use createSQLQuery when we try SQL methods in query
			notifications = session.createQuery(hql).list();
		} catch (Exception e) {
			log.error("CustomException occured while fetching all records: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return notifications;
	}

	@Override
	public Boolean saveAssigneeNotifications(MasterSaveChartReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getAssigneeFullName() != null && !req.getAssigneeFullName().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("requestId=");
				if (req.getServiceLine().equalsIgnoreCase("CTP")) {
					sb.append(req.getOrderId());
				} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
					sb.append(req.getRequestId());
				} else {
					log.debug("No ServiceLine found");
				}
				//sb.append(req.getOrderId());

				sb.append("&sl=");
				
				if (req.getServiceLine().equalsIgnoreCase("CTP")) {
					sb.append("CTP");
				} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
					sb.append("NPWT");
				} else {
					log.debug("No ServiceLine found");
				}

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);

				log.debug("reqURL : after encode - {}", reqURL.toString());

				MasterAppNotification appNotifications = new MasterAppNotification();
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications.setCreatorUserFullname(
							req.getLastUpdatedUserFullName());
					appNotifications.setCreatorUserId(
							Long.valueOf(req.getLastUpdatedUserId()));
					appNotifications.setCreatorUsername(
							req.getLastUpdatedUserName());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications.setUserFullname(req.getAssigneeFullName());
					appNotifications.setUserId(Long.valueOf(req.getAssigneeUserId()));
					appNotifications.setUsername(req.getAssigneeUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					appNotifications.setNotificationTitle("ASSIGNED");
					appNotifications.setNotificationDescription("");
					session.save(appNotifications);
					
					status = true;
				log.debug("Saved Assignee Notification.....................");
			}
		} catch (Exception e) {
			log.error("CustomException occured at Saving Assigned APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}
	
	@Override
	public Boolean saveBatchAssignedNotifications(int size, MasterCTPDashboardReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getBatchAssigneeChanged() == 1) {

				MasterAppNotification appNotifications = new MasterAppNotification();
				appNotifications.setReadFlag(false);
				appNotifications.setLastUpdatedTimestamp(currentTime);
				appNotifications.setCreatorUserFullname(
						req.getLastUpdatedUserFullName());
				appNotifications.setCreatorUserId(
						Long.valueOf(req.getLastUpdatedUserId()));
				appNotifications
						.setCreatorUsername(req.getLastUpdatedUserName());
				appNotifications.setHyperlink("");
				appNotifications
						.setUserFullname(req.getBatchAssigneeFullName());
				appNotifications
						.setUserId(new Long(req.getBatchAssigneeUserId()));
				appNotifications.setUsername(req.getBatchAssigneeUserName());
				appNotifications.setCreatedTimestamp(currentTime);
				appNotifications.setNotificationTitle("BULKASSIGNED");
				appNotifications.setNotificationDescription(size + "");
				session.save(appNotifications);
				status = true;
				log.debug("Saved Batch Assigned Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"CustomException occured at Saving Batch Assigned APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}
}
