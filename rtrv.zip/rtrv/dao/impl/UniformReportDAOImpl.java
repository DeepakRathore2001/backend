package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.UniformReportDAO;
import com.healogics.rtrv.dto.NPWTFilterOptions;
import com.healogics.rtrv.dto.NPWTReportReq;
import com.healogics.rtrv.dto.ViewReportsReq;
import com.healogics.rtrv.entity.NPWTReport;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.FilterRequestUtil;

@Repository
@TransactionManager2
public class UniformReportDAOImpl implements UniformReportDAO {

	private final Logger log = LoggerFactory.getLogger(ReportsDAOImpl.class);

	private final SessionFactory sessionFactory2;

	@Autowired
	public UniformReportDAOImpl(@Qualifier("SessionFactory2") SessionFactory sessionFactory2) {
		this.sessionFactory2 = sessionFactory2;
	}

	private String sortList(ViewReportsReq req, String hql) {
		String sortBy = "";
		if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
			sortBy = getFilterColumnName(req.getSortBy());
		}
		hql += " ORDER BY " + sortBy + "";
		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	private String getFilterColumnName(String sortBy) {
		String column = "";
		switch (sortBy) {
		case "bhcShipDate":
			column = "bhcShipDate";
			break;
		case "docsFirstSent":
			column = "docsFirstSent";
			break;
		case "bhcOrderReceivedDate":
			column = "bhcOrderReceivedDate";
			break;
		case "docsLastSent":
			column = "docsLastSent";
			break;
		default:
			break;
		}
		return column;
	}

	@Override
	public List<NPWTReport> generateAllNPWTReport(NPWTReportReq req, int index, boolean isExcel)
			throws CustomException {
		Session session = this.sessionFactory2.getCurrentSession();
		List<NPWTReport> npwtReport = new ArrayList<>();
		try {
			String hql = "FROM NPWTReport r WHERE 1 = 1 ";

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortList(req, hql);
			} else {
				hql += " order by bluebookCode asc";
			}

			log.info("query : {}", hql);
			if (isExcel) {
				npwtReport = session.createQuery(hql).list();
			} else {
				npwtReport = session.createQuery(hql).setFirstResult(index).setMaxResults(PAGE_SIZE).list();
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching all NPWT records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return npwtReport;
	}

	private String sortList(NPWTReportReq req, String hql) {
		String sortBy = req.getSortBy();
		String order = (req.getOrder() == 0) ? "desc" : "asc";

		switch (sortBy.toLowerCase()) {
		case "roNo":
			hql += " order by roNo " + order;
			break;
		case "bbc":
			hql += " order by bluebookCode " + order;
			break;
		case "hlWqOrderNo":
			hql += " order by hlWqOrderNo " + order;
			break;
		case "patientName":
			hql += " order by LOWER(patientName) " + order;
			break;
		case "firstReceivedDate":
			hql += " order by firstReceivedDate " + order;
			break;
		case "documentsFirstSent":
			hql += " order by documentsFirstSent " + order;
			break;
		case "documentsLastSent":
			hql += " order by documentsLastSent " + order;
			break;
		case "vendorStatus":
			hql += " order by vendorStatus " + order;
			break;
		case "retrieveStatus":
			hql += " order by retrieveStatus " + order;
			break;
		case "filesSent":
			hql += " order by filesSent " + order;
			break;
		default:
			hql += " order by LOWER(" + sortBy + ") " + order;
			break;
		}

		return hql;
	}

	@Override
	public Long getTotalCount(int index, NPWTReportReq req) throws CustomException {
		Session session = this.sessionFactory2.getCurrentSession();
		Long totalCount = 0L;

		try {
			String hql = "SELECT count(*) FROM NPWTReport r WHERE 1 = 1 ";

			totalCount = (Long) session.createQuery(hql).uniqueResult();

		} catch (Exception e) {
			log.error("Exception occured while fetching NPWT Dashboard total count : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public Map<String, Object> generateNPWTReport(NPWTReportReq req, int index, boolean isExcel)
			throws CustomException {
		Session session = this.sessionFactory2.getCurrentSession();
		List<NPWTReport> reports = new ArrayList<>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();

		log.debug("ViewReportsReq:   {}", req);

		try {

			String hql = "FROM NPWTReport a WHERE 1 = 1 ";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";

					switch (filterReq) {
					case "roNo": {
						List<Long> roNo = req.getRoNo();
						hql += " a.roNo IN :roNo ";
						parameters.put("roNo", roNo);
					}
						break;
					case "bbc": {
						List<String> bbc = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.bluebookCode IN :bbc ";
						parameters.put("bbc", bbc);
					}
						break;
					case "hlWqOrderNo": {
						List<Long> hlWqOrderNo = req.getHlWqOrderNo();
						hql += " a.hlWqOrderNo IN :hlWqOrderNo ";
						parameters.put("hlWqOrderNo", hlWqOrderNo);
					}
						break;
					case "patientName": {
						List<String> patientName = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						hql += " a.patientName IN :patientName ";
						parameters.put("patientName", patientName);
					}
						break;
					case "firstReceivedDate": {
						hql += " a.firstReceivedDate BETWEEN :firstReceivedStartDate AND :firstReceivedEndDate ";
						parameters.put("firstReceivedStartDate", dateFormat.parse(req.getFirstReceivedStartDate()));
						parameters.put("firstReceivedEndDate", dateFormat.parse(req.getFirstReceivedEndDate()));
					}
						break;

					case "documentsFirstSent": {
						hql += " a.documentsFirstSent BETWEEN :documentsFirstSentStartDate AND :documentsFirstSentEndDate ";
						parameters.put("documentsFirstSentStartDate",
								dateFormat.parse(req.getDocsFirstSentStartDate()));
						parameters.put("documentsFirstSentEndDate", dateFormat.parse(req.getDocsFirstSentEndDate()));
					}
						break;
					case "documentsLastSent": {
						hql += " a.documentsLastSent BETWEEN :documentsLastSentStartDate AND :documentsLastSentEndDate ";
						parameters.put("documentsLastSentStartDate", dateFormat.parse(req.getDocsLastSentStartDate()));
						parameters.put("documentsLastSentEndDate", dateFormat.parse(req.getDocsLastSentEndDate()));
					}
						break;

					case "vendorStatus": {
						List<String> vendorStatus = FilterRequestUtil.getListFromDelimitedStr(req.getVendorStatus());
//						log.debug("vendorstatusList : " + vendorStatus);

						List<String> updatedList = new ArrayList<>();
						if (vendorStatus != null && !vendorStatus.isEmpty()) {
							for (String status : vendorStatus) {
								if (getSolventumStatus(5, status).equals("FullMRRequest")) {
									updatedList.add(getSolventumStatus(5, status));
									updatedList.add("Full MR Request");
								} else if (getSolventumStatus(5, status).equals("Pending3rdPartyVerification")) {
									updatedList.add(getSolventumStatus(5, status));
									updatedList.add("Pending 3rd Party Verification");
								} else if (getSolventumStatus(5, status).equals("AdditionalDocumentationRequired")) {
									updatedList.add(getSolventumStatus(5, status));
									updatedList.add("Additional Documentation Required");
								} else {
									updatedList.add(getSolventumStatus(5, status));
								}
							}
						}

//						log.debug("updatedList : " + updatedList);
// new 
						hql += " a.vendorStatus IN :vendorStatus ";
						parameters.put("vendorStatus", updatedList);
					}
						break;
					case "retrieveStatus": {
						List<String> retrieveStatus = FilterRequestUtil
								.getListFromDelimitedStr(req.getRetrieveStatus());
						hql += " a.retrieveStatus IN :retrieveStatus ";
						parameters.put("retrieveStatus", retrieveStatus);
					}
						break;
//						case "filesSent" : {
//						    List<String> numOfFilesSentStr = FilterRequestUtil.getListFromDelimitedStr(req.getNoOfFilesSent());
//						    List<Integer> numOfFilesSent = new ArrayList<>();
//						    for (String s : numOfFilesSentStr) {
//						        try {
//						            numOfFilesSent.add(Integer.parseInt(s));
//						        } catch (NumberFormatException e) {
//						            log.error("Invalid number format for numOfFilesSent: {}", s);
//						        }
//						    }
//						    hql += " a.numOfFilesSent IN :numOfFilesSent ";
//						    parameters.put("numOfFilesSent", numOfFilesSent);
//						}
//						break;
					case "filesSent": {
						List<String> numOfFilesSentStr = FilterRequestUtil
								.getListFromDelimitedStr(req.getNoOfFilesSent());
						List<Integer> filesSent = new ArrayList<>();
						for (String s : numOfFilesSentStr) {
							try {
								filesSent.add(Integer.parseInt(s));
							} catch (NumberFormatException e) {
								log.error("Invalid number format for numOfFilesSent: {}", s);
							}
						}

						if (filesSent.contains(0)) {
							hql += " a.filesSent = 0";
						} else if (filesSent.contains(1)) {
							hql += " a.filesSent >= 1";
						} else {
							hql += " a.filesSent IN :filesSent";
							parameters.put("filesSent", filesSent);
						}
					}
						break;

					default:
						break;
					}
				}
			}

			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by bluebookCode asc";
			}

			log.debug("View Reports Filter query:   {}", hql);
			if (isExcel) {
				reports = session.createQuery(hql).setProperties(parameters).list();

				int count = reports.size() + index;

				listCount.put("Count", count);
				listCount.put("data", reports);
				log.debug("npwt Report List Size:   {} ", count);
				log.debug("npwt Report List:   {} ", reports);
			} else {
				reports = session.createQuery(hql).setFirstResult(index).setProperties(parameters).list();

				int count = reports.size() + index;

				listCount.put("Count", count);
				listCount.put("data", reports);
				log.debug("npwt Report List Size:   {} ", count);
				log.debug("npwt Report List:   {} ", reports);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching view reports details list:  {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}

		return listCount;
	}

	@Override
	public NPWTFilterOptions npwtReportFilterOptions(NPWTReportReq req) throws CustomException {
		Session session = sessionFactory2.getCurrentSession();
		NPWTFilterOptions filterOptions = new NPWTFilterOptions();
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
			StringBuilder baseQuery = new StringBuilder("SELECT DISTINCT ");
			String filterColumn = null;
			if ("roNo".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.roNo");
				filterColumn = "r.roNo";
			} else if ("bbc".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.bluebookCode");
				filterColumn = "r.bluebookCode";
			} else if ("hlWqOrderNo".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.hlWqOrderNo");
				filterColumn = "r.hlWqOrderNo";
			} else if ("patientName".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.patientName");
				filterColumn = "r.patientName";
			} else if ("vendorStatus".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.vendorStatus");
				filterColumn = "r.vendorStatus";
			} else if ("retrieveStatus".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.retrieveStatus");
				filterColumn = "r.retrieveStatus";
			} else if ("filesSent".equalsIgnoreCase(req.getFilterOptions())) {
				baseQuery.append("r.filesSent");
				filterColumn = "r.filesSent";
			} else {
				throw new CustomException("Unsupported filter option: " + req.getFilterOptions());
			}

			baseQuery.append(" FROM NPWTReport r WHERE 1=1 ");
			Map<String, Object> parameters = new HashMap<>();
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());
				for (String filterReq : filterList) {
					baseQuery.append(" AND ");
					switch (filterReq) {
					case "roNo":
						List<Long> roNoList = req.getRoNo();
						if (roNoList != null && !roNoList.isEmpty()) {
							baseQuery.append("r.roNo IN :roNoList");
							parameters.put("roNoList", roNoList);
						}
						break;
					case "bbc":
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						if (bbcList != null && !bbcList.isEmpty()) {
							baseQuery.append("r.bluebookCode IN :bbcList");
							parameters.put("bbcList", bbcList);
						}
						break;
					case "hlWqOrderNo":
						List<Long> hlWqOrderList = req.getHlWqOrderNo();
						if (hlWqOrderList != null && !hlWqOrderList.isEmpty()) {
							baseQuery.append("r.hlWqOrderNo IN :hlWqOrderList");
							parameters.put("hlWqOrderList", hlWqOrderList);
						}
						break;
					case "patientName":
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());
						if (patientNameList != null && !patientNameList.isEmpty()) {
							baseQuery.append("r.patientName IN :patientNameList");
							parameters.put("patientNameList", patientNameList);
						}
						break;
					case "vendorStatus":
						List<String> vendorStatusList = FilterRequestUtil
								.getListFromDelimitedStr(req.getVendorStatus());
						if (vendorStatusList != null && !vendorStatusList.isEmpty()) {
							baseQuery.append("r.vendorStatus IN :vendorStatusList");
							parameters.put("vendorStatusList", vendorStatusList);
						}
						break;
					case "firstReceivedDate": {
						// hql += " a.firstReceivedDate BETWEEN :firstReceivedStartDate AND
						// :firstReceivedEndDate ";
						baseQuery.append(
								" r.firstReceivedDate BETWEEN :firstReceivedStartDate AND :firstReceivedEndDate ");
						parameters.put("firstReceivedStartDate", dateFormat.parse(req.getFirstReceivedStartDate()));
						parameters.put("firstReceivedEndDate", dateFormat.parse(req.getFirstReceivedEndDate()));
					}
						break;

					case "documentsFirstSent": {
						// hql += " a.documentsFirstSent BETWEEN :documentsFirstSentStartDate AND
						// :documentsFirstSentEndDate ";
						baseQuery.append(
								" r.documentsFirstSent BETWEEN :documentsFirstSentStartDate AND :documentsFirstSentEndDate ");
						parameters.put("documentsFirstSentStartDate",
								dateFormat.parse(req.getDocsFirstSentStartDate()));
						parameters.put("documentsFirstSentEndDate", dateFormat.parse(req.getDocsFirstSentEndDate()));
					}
						break;
					case "documentsLastSent": {
						// hql += " a.documentsLastSent BETWEEN :documentsLastSentStartDate AND
						// :documentsLastSentEndDate ";
						baseQuery.append(
								" r.documentsLastSent BETWEEN :documentsLastSentStartDate AND :documentsLastSentEndDate ");
						parameters.put("documentsLastSentStartDate", dateFormat.parse(req.getDocsLastSentStartDate()));
						parameters.put("documentsLastSentEndDate", dateFormat.parse(req.getDocsLastSentEndDate()));
					}
						break;
					case "retrieveStatus":
						List<String> retrieveStatusList = FilterRequestUtil
								.getListFromDelimitedStr(req.getRetrieveStatus());
						if (retrieveStatusList != null && !retrieveStatusList.isEmpty()) {
							baseQuery.append("r.retrieveStatus IN :retrieveStatusList");
							parameters.put("retrieveStatusList", retrieveStatusList);
						}
						break;
					case "filesSent": {
						List<String> numOfFilesSentStr = FilterRequestUtil
								.getListFromDelimitedStr(req.getNoOfFilesSent());
						List<Integer> filesSent = new ArrayList<>();
						for (String s : numOfFilesSentStr) {
							try {
								filesSent.add(Integer.parseInt(s));
							} catch (NumberFormatException e) {
								log.error("Invalid number format for numOfFilesSent: {}", s);
							}
						}

						if (filesSent.contains(0)) {
							baseQuery.append("r.filesSent = 0");
						} else if (filesSent.contains(1)) {
							baseQuery.append("r.filesSent >= 1");
						} else {
							baseQuery.append("r.filesSent IN :filesSent");
							parameters.put("filesSent", filesSent);
						}
					}
						break;
					default:
						break;
					}
				}
			}

			baseQuery.append(" ORDER BY LOWER(").append(filterColumn).append(") ASC");
			Query query = session.createQuery(baseQuery.toString());
			log.info("Generated Query: {}", baseQuery);

			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				if (entry.getValue() instanceof List) {
					query.setParameter(entry.getKey(), (List<?>) entry.getValue());
				} else {
					query.setParameter(entry.getKey(), entry.getValue());
				}
			}

			List<?> results = query.getResultList();

			Set<Object> distinctValues = new TreeSet<>();
			if ("roNo".equalsIgnoreCase(req.getFilterOptions())) {
				for (Object result : results) {
					if (result instanceof Long) {
						distinctValues.add(result);
					}
				}
			} else if ("hlWqOrderNo".equalsIgnoreCase(req.getFilterOptions())) {
				for (Object result : results) {
					if (result instanceof Long) {
						distinctValues.add(result);
					}
				}
			} else if ("filesSent".equalsIgnoreCase(req.getFilterOptions())) {
				for (Object result : results) {
					if (result instanceof Integer) {
						distinctValues.add(result);
					}
				}
			} else {
				for (Object result : results) {
					if (result instanceof String) {
						distinctValues.add(result);
					}
				}
			}

			filterOptions.setOptions(new ArrayList<>(distinctValues));
		} catch (Exception e) {
			log.error("Error occurred while fetching filter options: {}", e.getMessage());
			throw new CustomException("Error fetching filter options: " + e.getMessage(), e);
		}
		return filterOptions;
	}

	private String getSolventumStatus(Integer vendorId, String orderStatus) {
		String vendorStatus = orderStatus;

		if (vendorId == 5) {
			switch (orderStatus) {
			case DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_FULL_MR_REQUEST;
			}
				break;

			case DAOConstants.VENDOR_ORDER_RELEASE_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_1_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_1;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_2_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_2;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_3_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_3;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_4_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_4;
			}
				break;

			case DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED: {
				vendorStatus = DAOConstants.SOLVENTUM_ADDITIONAL_DOC_REQUIRED;
			}
				break;

			default:
				break;
			}
		}
		return vendorStatus;
	}
}
