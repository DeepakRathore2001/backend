package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.AppNotificationDAO;
import com.healogics.rtrv.dto.AppNotificaionsReq;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.UsersInNotes;
import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.entity.DocumentNotificationStatus;
import com.healogics.rtrv.entity.UserPreference;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class AppNotificationDAOImpl implements AppNotificationDAO {

	private final Logger log = LoggerFactory
			.getLogger(AppNotificationDAOImpl.class);

	private final Environment env;

	private final SessionFactory sessionFactory;

	@Autowired
	public AppNotificationDAOImpl(Environment env, 
			@Qualifier("SessionFactory1") SessionFactory sf) {
		this.env = env;
		this.sessionFactory = sf;
	}

	@Override
	public List<AppNotifications> getCount(AppNotificaionsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();

		List<AppNotifications> notificationsList = new ArrayList<>();
		try {
			// last 30 days data only
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_MONTH, -30);
			Date last30DaysDate = calendar.getTime();
			Timestamp last30DaysTimestamp = new Timestamp(last30DaysDate.getTime());
			log.info("last30DaysTimestamp :  {}", last30DaysTimestamp);
			
			String hql = "FROM AppNotifications WHERE userId = :userId"
					+ " AND createdTimestamp > :createdTimestamp ";

			notificationsList = session.createQuery(hql)
					.setParameter("userId", Long.valueOf(req.getUserId()))
					.setParameter("createdTimestamp", last30DaysTimestamp)
					.list();

		} catch (Exception e) {
			log.error(
					"CustomException occured at count APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return notificationsList;
	}
	@Override
	public Boolean saveNoteNotifications(SaveNotesReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getTaggedUsers() != null
					&& !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("medRedId=");
				sb.append(req.getBhcMedicalRecordId());

				sb.append("&invOrderId=");
				sb.append(req.getBhcInvoiceOrderNo());

				sb.append("&notesId=");
				sb.append(req.getNotesId());

				sb.append("&sl=");
				sb.append("AWD");

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				// reqURL.append("&src=email");

				log.debug("reqURL : after encode - {}", reqURL.toString());

				for (UsersInNotes users : req.getTaggedUsers()) {
					AppNotifications appNotifications = new AppNotifications();
					// appNotifications.setNotificationId(1L);
					appNotifications.setReadFlag(false);
					appNotifications.setLastUpdatedTimestamp(currentTime);
					appNotifications.setCreatorUserFullname(
							req.getLastTeamUpdatedUserFullname());
					appNotifications.setCreatorUserId(
							Long.valueOf(req.getLastUpdatedUserId()));
					appNotifications
							.setCreatorUsername(req.getLastUpdatedUsername());
					appNotifications.setHyperlink(reqURL.toString());
					appNotifications.setUserFullname(users.getUserFullName());
					appNotifications.setUserId(users.getUserId());
					appNotifications.setUsername(users.getUserName());
					appNotifications.setCreatedTimestamp(currentTime);
					appNotifications.setNotificationTitle("TAGGED");
					appNotifications
							.setNotificationDescription(req.getDescription());
					session.save(appNotifications);
					status = true;
				}
				log.debug("Saved Tagged Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"CustomException occured at Saving Note APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}

	@Override
	public Boolean saveAssignedNotifications(SaveRequest req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getAssigneeChanged() == 1) {

				StringBuilder sb = new StringBuilder();
				sb.append("medRedId=");
				sb.append(req.getBhcMedicalRecordId());

				sb.append("&invOrderId=");
				sb.append(req.getBhcInvoiceOrderId());

				sb.append("&sl=");
				sb.append("AWD");

				String encodedURL = Base64.getUrlEncoder()
						.encodeToString(sb.toString().getBytes());

				log.debug("reqURL : before encode - {}", sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);

				log.debug("reqURL : after encode - {}", reqURL.toString());

				AppNotifications appNotifications = new AppNotifications();
				appNotifications.setReadFlag(false);
				appNotifications.setLastUpdatedTimestamp(currentTime);
				appNotifications.setCreatorUserFullname(
						req.getLastUpdatedUserFullName());
				appNotifications.setCreatorUserId(
						Long.valueOf(req.getLastUpdatedUserId()));
				appNotifications
						.setCreatorUsername(req.getLastUpdatedUserName());
				appNotifications.setHyperlink(reqURL.toString());
				appNotifications.setUserFullname(req.getAssigneeFullName());
				appNotifications.setUserId(new Long(req.getAssigneeUserId()));
				appNotifications.setUsername(req.getAssigneeUserName());
				appNotifications.setCreatedTimestamp(currentTime);
				appNotifications.setNotificationTitle("ASSIGNED");
				appNotifications.setNotificationDescription("");
				session.save(appNotifications);
				status = true;
				log.debug("Saved Assigned Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"CustomException occured at Saving Assigned APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}

	@Override
	public Long updateNotifications(AppNotificaionsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long count = 1L;
		UserPreference userPreference = new UserPreference();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getClearedFlag()) {
				UserPreference userPref = session
						.createQuery(
								"FROM UserPreference WHERE userId = :userId",
								UserPreference.class)
						.setParameter("userId", Long.valueOf(req.getUserId()))
						.setMaxResults(1).uniqueResult();
				if (userPref != null) {
					userPref.setClearNotificationTimestamp(currentTime);
					session.update(userPref);
				} else {
					userPreference.setUserId(Long.valueOf(req.getUserId()));
					userPreference.setClearNotificationTimestamp(currentTime);
					session.update(userPreference);
				}
				Long userId = Long.valueOf(req.getUserId());
				String hql = "UPDATE AppNotifications SET "
						+ " readFlag = :readFlag, "
						+ " lastUpdatedTimestamp = :lastUpdatedTimestamp "
						+ " WHERE " + " userId = :userId ";
				session.createQuery(hql).setParameter("readFlag", true)
						.setParameter("lastUpdatedTimestamp", currentTime)
						.setParameter("userId", userId).executeUpdate();

			} else if (req.getReadFlag()) {
				for (String id : req.getNotificationId()) {
					Long notificationId = Long.valueOf(id);
					Long userId = Long.valueOf(req.getUserId());
					String hql = "UPDATE AppNotifications SET "
							+ " readFlag = :readFlag, "
							+ " lastUpdatedTimestamp = :lastUpdatedTimestamp "
							+ " WHERE notificationId = :notificationId "
							+ " AND userId = :userId ";
					session.createQuery(hql).setParameter("readFlag", true)
							.setParameter("lastUpdatedTimestamp", currentTime)
							.setParameter("notificationId", notificationId)
							.setParameter("userId", userId).executeUpdate();
				}
				count = 0L;
				log.debug("Updated Notifications.............");
			}

		} catch (Exception e) {
			log.error(
					"CustomException occured at Updating APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return count;
	}

	@Override
	public List<AppNotifications> getAppNotification(Long userId,
			Timestamp clearNotificationTimestamp, String last30DaysDate)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<AppNotifications> notifications = new ArrayList<>();

		try {
			String hql = "";
			if (clearNotificationTimestamp != null) {
				hql = "FROM AppNotifications n WHERE n.userId=" + userId
						+ " AND n.createdTimestamp > '"
						+ clearNotificationTimestamp
						+ "' AND n.createdTimestamp > '" + last30DaysDate + "'"
						+ " order by createdTimestamp desc";
			} else {
				hql = "FROM AppNotifications n WHERE n.userId=" + userId
						+ " AND n.createdTimestamp > '" + last30DaysDate + "'"
						+ " order by createdTimestamp desc";
			}

			// use createSQLQuery when we try SQL methods in query
			notifications = session.createQuery(hql).list();
		} catch (Exception e) {
			log.error(
					"CustomException occured while fetching all records: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return notifications;
	}

	@Override
	public Boolean saveBatchAssignedNotifications(int size, DashboardReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			if (req.getBatchAssigneeChanged() == 1) {
				/*
				 * StringBuilder sb = new StringBuilder();
				 * sb.append("medRedId="); sb.append(record.getBhcMedRecId());
				 * 
				 * sb.append("&invOrderId=");
				 * sb.append(record.getBhcInvoiceOrderId());
				 * 
				 * sb.append("&sl="); sb.append("AWD");
				 * 
				 * String encodedURL = Base64.getUrlEncoder()
				 * .encodeToString(sb.toString().getBytes());
				 * 
				 * log.debug("reqURL : before encode - " + sb.toString());
				 * 
				 * // form URL StringBuilder reqURL = new StringBuilder();
				 * reqURL.append(env.getProperty("app.url"));
				 * reqURL.append("/?req="); reqURL.append(encodedURL); //
				 * reqURL.append("&src=email");
				 * 
				 * log.debug("reqURL : after encode - " + reqURL.toString());
				 */

				AppNotifications appNotifications = new AppNotifications();
				appNotifications.setReadFlag(false);
				appNotifications.setLastUpdatedTimestamp(currentTime);
				appNotifications.setCreatorUserFullname(
						req.getLastUpdatedUserFullName());
				appNotifications.setCreatorUserId(
						Long.valueOf(req.getLastUpdatedUserId()));
				appNotifications
						.setCreatorUsername(req.getLastUpdatedUserName());
				appNotifications.setHyperlink("");
				appNotifications
						.setUserFullname(req.getBatchAssigneeFullName());
				appNotifications
						.setUserId(new Long(req.getBatchAssigneeUserId()));
				appNotifications.setUsername(req.getBatchAssigneeUserName());
				appNotifications.setCreatedTimestamp(currentTime);
				appNotifications.setNotificationTitle("BULKASSIGNED");
				appNotifications.setNotificationDescription(size + "");
				session.save(appNotifications);
				status = true;
				log.debug("Saved Batch Assigned Users.....................");
			}
		} catch (Exception e) {
			log.error(
					"CustomException occured at Saving Batch Assigned APP notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}

	@Override
	public Boolean sendFailedDocumentNotification(int bhcMedicalRecordId,
			int bhcInvoiceOrderId, String documentId, String userId,
			String username, String userFullname)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Boolean status = false;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			StringBuilder sb = new StringBuilder();
			sb.append("medRedId=");
			sb.append(bhcMedicalRecordId);

			sb.append("&invOrderId=");
			sb.append(bhcInvoiceOrderId);

			sb.append("&historyTimelineId=");
			sb.append(documentId);

			sb.append("&sl=");
			sb.append("AWD");

			String encodedURL = Base64.getUrlEncoder()
					.encodeToString(sb.toString().getBytes());

			log.debug("reqURL : before encode - {}", sb.toString());

			// form URL
			StringBuilder reqURL = new StringBuilder();
			reqURL.append(env.getProperty("app.url"));
			reqURL.append("/?req=");
			reqURL.append(encodedURL);
			// reqURL.append("&src=email");

			log.debug("reqURL : after encode - {}", reqURL.toString());

			AppNotifications appNotifications = new AppNotifications();

			appNotifications.setReadFlag(false);
			appNotifications.setLastUpdatedTimestamp(currentTime);
			appNotifications.setCreatorUserFullname(userFullname);
			appNotifications.setCreatorUserId(Long.valueOf(userId));
			appNotifications.setCreatorUsername(username);
			appNotifications.setHyperlink(reqURL.toString());
			appNotifications.setUserFullname(userFullname);
			appNotifications.setUserId(Long.valueOf(userId));
			appNotifications.setUsername(username);
			appNotifications.setCreatedTimestamp(currentTime);
			appNotifications.setNotificationTitle("FAILEDDOCS");
			appNotifications.setNotificationDescription(
					"One or more documents have failed to send");
			session.save(appNotifications);
			status = true;
			log.debug("Send Failed Document Notification.....................");

			// Update DocumentNotificationStatus Row
			String notHql = "From DocumentNotificationStatus WHERE bhcMedicalRecordId = :bhcMedicalRecordId"
					+ " AND bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";
			DocumentNotificationStatus object = session
					.createQuery(notHql, DocumentNotificationStatus.class)
					.setParameter("bhcMedicalRecordId",
							new Long(bhcMedicalRecordId))
					.setParameter("bhcInvoiceOrderNo",
							new Long(bhcInvoiceOrderId))
					.setMaxResults(1).uniqueResult();
			log.debug("DocumentNotificationStatus object in DAOIMpl:  {}",
					object);
			if (object != null) {
				object.setNotificationSent(1);
				object.setLastUpdateTimestamp(currentTime);
				log.debug("object  :     {}", object);
				session.update(object);
			}
			log.debug("Update DocumentNotification Status........ ");

		} catch (Exception e) {
			log.error(
					"CustomException occured at Saving Failed Document notifications: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}
}
