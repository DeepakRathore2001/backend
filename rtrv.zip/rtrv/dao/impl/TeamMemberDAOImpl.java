package com.healogics.rtrv.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.TeamMemberDAO;
import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class TeamMemberDAOImpl implements TeamMemberDAO {
	private final Logger log = LoggerFactory.getLogger(TeamMemberDAOImpl.class);
	
	private final SessionFactory sessionFactory;

	@Autowired
	public TeamMemberDAOImpl(@Qualifier("SessionFactory1")SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

    @Override
    public List<RetrieveMembers> getActiveTeamMebers() throws CustomException {
    	Session session = this.sessionFactory.getCurrentSession();
    	List<RetrieveMembers> teamMembers = new ArrayList<>();
    	try {
    		String hql = "FROM RetrieveMembers r where r.active = 1";
    		
    		teamMembers = session.createQuery(hql).list();
    		
    	} catch (Exception e) {
    		log.error("Exception occured in getActiveTeamMebers: {}" ,e.getMessage());
    		throw new CustomException(e.getMessage());
    	}
    	
    	return teamMembers;
    }
}
