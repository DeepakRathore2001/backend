package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.BOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.BOConstants.ERRORMESSAGE;
import static com.healogics.rtrv.constants.DAOConstants.MASTER_NOTES_SIZE;

import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_NEW_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_PENDING_AUTH_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_UNDER_APPEAL_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_RETURNED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_COMPLETED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_CANCELED_STATUS;

import static com.healogics.rtrv.constants.BOConstants.NEW_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.RETURNED_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.UNDER_APPEAL_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.PENDING_AUTH_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.COMPLETED_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.CANCELED_STATUS_TEXT;


import java.net.Inet4Address;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.dto.EDocument;
import com.healogics.rtrv.dto.GetOrderUpdateReq;
import com.healogics.rtrv.dto.HistoryTimelineDocStatus;
import com.healogics.rtrv.dto.HistoryUserNotes;
import com.healogics.rtrv.dto.ICD10Data;
import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.ChartReviewDAO;
import com.healogics.rtrv.dao.DashboardDAO;
import com.healogics.rtrv.dao.MasterAppNotificationDAO;
import com.healogics.rtrv.dao.MasterChartReviewDAO;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dto.MasterChartDetailsObj;
import com.healogics.rtrv.dto.MasterChartDetailsReq;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.dto.MasterModifyRecordReq;
import com.healogics.rtrv.dto.MasterSaveAttachmentObj;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.dto.OrderInfoUpdateReq;
import com.healogics.rtrv.dto.OrderInfoUpdateRes;
import com.healogics.rtrv.dto.PrimaryInsuranceMaster;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.SecondaryInsuranceMaster;
import com.healogics.rtrv.dto.TertiaryInsuranceMaster;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.dto.VendorWoundDetails;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentRequest;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.entity.MasterChartDetails;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.entity.MasterUserNotes;
import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;

@Repository
@TransactionManager2
public class MasterChartReviewDAOImpl implements MasterChartReviewDAO {
	private final Logger log = LoggerFactory
			.getLogger(MasterChartReviewDAOImpl.class);

	private final SessionFactory sessionFactory;
	private final ChartReviewDAO chartReviewDAO;
	private final DashboardDAO dashboardDAO;
	private final MasterHistoryTimelineDAO historyTimelineDAO;
	private final Environment env;
	private final RestTemplate restTemplate;
	private final MasterAppNotificationDAO appNotificationDAO;

	public MasterChartReviewDAOImpl(
			@Qualifier("SessionFactory2") SessionFactory sessionFactory,
			ChartReviewDAO chartReviewDAO, DashboardDAO dashboardDAO,
			MasterHistoryTimelineDAO historyTimelineDAO, Environment env,
			@Qualifier("httpTemplate1") RestTemplate restTemplate,
			MasterAppNotificationDAO appNotificationDAO) {
		this.sessionFactory = sessionFactory;
		this.chartReviewDAO = chartReviewDAO;
		this.dashboardDAO = dashboardDAO;
		this.historyTimelineDAO = historyTimelineDAO;
		this.env = env;
		this.restTemplate = restTemplate;
		this.appNotificationDAO = appNotificationDAO;
	}

	@Override
	public SaveMasterNotesReq saveMasterNotes(SaveMasterNotesReq req)
			throws CustomException {
		String noteId = "";
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		Date followupDate = null;
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		try {
			log.info("SaveMasterNotesReq - req : "+req);
			
			MasterUserNotes userNotes = new MasterUserNotes();

			userNotes.setRequestId(req.getRequestId());
			noteId = UUID.randomUUID().toString();
			userNotes.setNoteId(noteId);
			req.setNoteId(noteId);
			userNotes.setBhcInvoiceOrderNo(req.getBhcInvoiceOrderNo());
			userNotes.setAttemptCategory(req.getAttemptCategory());
			userNotes.setAttemptType(req.getAttemptType());
			userNotes.setContactMethod(req.getContactMethod());
			userNotes.setContact(req.getContact());

			if (req.getFollowupDate() != null
					&& !req.getFollowupDate().isEmpty()) {
				userNotes.setFollowupDate(format.parse(req.getFollowupDate()));
			} else {
				userNotes.setFollowupDate(null);
			}

			followupDate = userNotes.getFollowupDate();

			userNotes.setAddendumSent(req.getAddendumSent());
			userNotes.setAddendumReceived(req.getAddendumReceived());
			userNotes.setReceivedRX(req.getReceivedRX());
			userNotes.setPatientNotSeen30Days(req.getPatientNotSeen30Days());
			userNotes.setDescription(req.getDescription());
			userNotes.setPatientId(req.getPatientId());
			userNotes.setBluebookId(req.getBluebookId());
			userNotes.setFacilityId(req.getFacilityId());
			userNotes.setPatientFullname(req.getPatientFullname());
			userNotes.setLastUpdatedUsername(req.getLastUpdatedUsername());
			userNotes.setLastUpdatedUserId(
					Long.valueOf(req.getLastUpdatedUserId()));
			userNotes.setLastUpdatedTimestamp(
					new Timestamp(System.currentTimeMillis()));
			userNotes.setDeleteFlag(false);
			userNotes.setLastUpdatedUserFullname(
					req.getLastUpdatedUserFullname());

			String taggedUsers = null;
			try {
				taggedUsers = new ObjectMapper()
						.writeValueAsString(req.getTaggedUsers());
			} catch (JsonProcessingException e) {
				log.error("Json Procession exception:   {}", e);
			}
			userNotes.setTaggedUsers(taggedUsers);

			session.save(userNotes);

			if (req.getServiceLine().equalsIgnoreCase("CTP")) {
				String retrieveStatus = "";
				
				if (req.getAddendum() == 0 || req.getRecordModify() == 1) {

					if (req.getAttemptCategory() != null
							&& req.getAttemptCategory().equalsIgnoreCase("General")) {
						retrieveStatus = "Working_General";

						if (req.getAttemptType() != null
								&& req.getAttemptType().equalsIgnoreCase("Exhausted")) {
							retrieveStatus = "Exhausted";
						}

					} else if (req.getAttemptCategory() != null
							&& req.getAttemptCategory().equalsIgnoreCase("Vendor")) {
						retrieveStatus = "Working_Vendor";
						
						if (req.getAttemptType() != null
								&& req.getAttemptType().equalsIgnoreCase("Exhausted")) {
							retrieveStatus = "Exhausted";
						}

					} else if (req.getAttemptCategory() != null
							&& req.getAttemptCategory().equalsIgnoreCase("Center")) {
						retrieveStatus = "Working_Center";
					}

					req.setStatus(retrieveStatus);

					String hql = "UPDATE CTPDashboard SET" + " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
							+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
							+ " lastActioned = :lastActioned, " + " followupDate = :followupDate, "
							+ " retrieveStatus = :retrieveStatus, "
							+ " statusUpdatedTimestamp = :statusUpdatedTimestamp, "
							+ " statusUpdatedUserFullName = :statusUpdatedUserFullName, "
							+ " statusUpdatedUserId = :statusUpdatedUserId, "
							+ " statusUpdatedUserName = :statusUpdatedUserName " + " WHERE orderId = :orderId";

					session.createQuery(hql).setParameter("lastTeamUpdatedTimestamp", currentTime)
							.setParameter("lastTeamUpdatedUserFullname", req.getLastUpdatedUserFullname())
							.setParameter("lastActioned", currentTime).setParameter("followupDate", followupDate)
							.setParameter("retrieveStatus", retrieveStatus)
							.setParameter("statusUpdatedTimestamp", currentTime)
							.setParameter("statusUpdatedUserFullName", req.getLastUpdatedUserFullname())
							.setParameter("statusUpdatedUserId", req.getLastUpdatedUserId())
							.setParameter("statusUpdatedUserName", req.getLastUpdatedUsername())
							.setParameter("orderId", req.getRequestId() + "").executeUpdate();
				} else {
					String hql = "UPDATE CTPDashboard SET" + " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
							+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
							+ " lastActioned = :lastActioned, " + " followupDate = :followupDate "
							+ " WHERE orderId = :orderId";

					session.createQuery(hql).setParameter("lastTeamUpdatedTimestamp", currentTime)
							.setParameter("lastTeamUpdatedUserFullname", req.getLastUpdatedUserFullname())
							.setParameter("lastActioned", currentTime).setParameter("followupDate", followupDate)
							.setParameter("orderId", req.getRequestId() + "").executeUpdate();
				}

				// Send update to kerecis
				/*
				 * if(retrieveStatus != null && !retrieveStatus.isEmpty()) {
				 * OrderInfoUpdateReq infoReq = new OrderInfoUpdateReq();
				 * infoReq.setRetrieveStatus(retrieveStatus);
				 * infoReq.setOrderDisplayNumber(req.getOrderId().intValue());
				 * sendOrderInformation(infoReq); }
				 */

				// Make entry in History timeline
				String ctpHql = "FROM CTPDashboard a WHERE a.orderId = :orderId ";

				log.debug("ctpHQL: {}", ctpHql.toString(), req.getRequestId());
				CTPDashboard ctpData = session
						.createQuery(ctpHql, CTPDashboard.class)
						.setParameter("orderId", req.getRequestId()+"").setMaxResults(1)
						.uniqueResult();

				log.debug("ctpDashboard:  {}", ctpData);
				
				if (req.getAddendum() == 0 || req.getRecordModify() == 1) {

					Integer historyId = historyTimelineDAO.getHistoryId();

					MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
					historyTimeline.setRequestId(req.getRequestId());
					historyTimeline.setHistoryId(historyId + 1);
					historyTimeline.setBluebookId(req.getBluebookId());
					historyTimeline
							.setFacilityId(Long.valueOf(req.getFacilityId()));
					historyTimeline.setLastUpdatedUserFullname(
							req.getLastUpdatedUserFullname());
					historyTimeline.setLastUpdatedUserId(
							Long.valueOf(req.getLastUpdatedUserId()));
					historyTimeline
							.setLastUpdatedUsername(req.getLastUpdatedUsername());
					historyTimeline.setPatientId(req.getPatientId());
					historyTimeline.setPatientName(req.getPatientFullname());
					historyTimeline.setRetrieveStatus(retrieveStatus);

					VendorStatus vendorStatus = new VendorStatus();
					vendorStatus.setCurrentStatus(ctpData.getVendorStatus());
					historyTimeline.setVendorStatus(vendorStatus);
					
					HistoryUserNotes userNotesObj = new HistoryUserNotes();
					userNotesObj.setDescription(req.getStatusUpdatedUserFullName()
							+ "# Added a note");

					historyTimeline.setUserNotes(userNotesObj);

					historyTimelineDAO.saveHistoryTimeline(historyTimeline);
				}

				// Send InApp Notification if any users are tagged on notes
				if (req.getTaggedUsers() != null && req.getTaggedUsers().size() > 0) {
					appNotificationDAO.saveNoteNotifications(req);
				}	
			} else if (req.getServiceLine().equalsIgnoreCase("NPWT")){
					String retrieveStatus = "";

				if (req.getAddendum() == 0 || req.getRecordModify() == 1) {
					if (req.getAttemptCategory() != null
							&& req.getAttemptCategory().equalsIgnoreCase("General")) {
						retrieveStatus = "Working_General";

						if (req.getAttemptType() != null
								&& (req.getAttemptType().equalsIgnoreCase("Exhausted"))) {
							retrieveStatus = "Exhausted";
						}

					} else if (req.getAttemptCategory() != null
							&& req.getAttemptCategory().equalsIgnoreCase("Vendor")) {
						retrieveStatus = "Working_Vendor";
						
						if (req.getAttemptType() != null
								&& (req.getAttemptType().equalsIgnoreCase("Exhausted"))) {
							retrieveStatus = "Exhausted";
						}

					} else if (req.getAttemptCategory() != null
							&& req.getAttemptCategory().equalsIgnoreCase("Center")) {
						retrieveStatus = "Working_Center";
					}

					req.setStatus(retrieveStatus);
					
					if (req.getAttemptCategory() != null
							&& req.getAttemptType().equalsIgnoreCase("Exhausted")) {
						retrieveStatus = "Exhausted";
					}
					req.setStatus(retrieveStatus);

					String hql = "UPDATE UniformDashboard SET"
							+ " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
							+ " lastTeamUpdatedFullName = :lastTeamUpdatedUserFullname, "
							+ " followupDate = :followupDate, " + " retrieveStatus = :retrieveStatus, "
							+ " statusUpdatedTimestamp = :statusUpdatedTimestamp, "
							+ " statusUpdatedUserFullname = :statusUpdatedUserFullname, "
							+ " statusUpdatedUserId = :statusUpdatedUserId, "
							+ " statusUpdatedUsername = :statusUpdatedUsername " + " WHERE requestId = :requestId";

					session.createQuery(hql).setParameter("lastTeamUpdatedTimestamp", currentTime)
							.setParameter("lastTeamUpdatedUserFullname", req.getLastUpdatedUserFullname())
							// .setParameter("lastActioned", currentTime)
							.setParameter("followupDate", followupDate).setParameter("retrieveStatus", retrieveStatus)
							.setParameter("statusUpdatedTimestamp", currentTime)
							.setParameter("statusUpdatedUserFullname", req.getLastUpdatedUserFullname())
							.setParameter("statusUpdatedUserId", req.getLastUpdatedUserId())
							.setParameter("statusUpdatedUsername", req.getLastUpdatedUsername())
							.setParameter("requestId", req.getRequestId() + "").executeUpdate();
				} else {
					String hql = "UPDATE UniformDashboard SET"
							+ " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
							+ " lastTeamUpdatedFullName = :lastTeamUpdatedUserFullname, "
							// + " lastActioned = :lastActioned, "
							+ " followupDate = :followupDate " + " WHERE requestId = :requestId";

					session.createQuery(hql).setParameter("lastTeamUpdatedTimestamp", currentTime)
							.setParameter("lastTeamUpdatedUserFullname", req.getLastUpdatedUserFullname())
							// .setParameter("lastActioned", currentTime)
							.setParameter("followupDate", followupDate)
							.setParameter("requestId", req.getRequestId() + "").executeUpdate();
				}

				// Send update to kerecis

				// if(retrieveStatus != null && !retrieveStatus.isEmpty()) {
				// OrderInfoUpdateReq infoReq = new OrderInfoUpdateReq();
				// infoReq.setRetrieveStatus(retrieveStatus);
				// infoReq.setOrderDisplayNumber(req.getOrderId().intValue());
				// sendOrderInformation(infoReq); }

				// Make entry in History timeline
				String npwtHql = "FROM UniformDashboard a WHERE a.requestId = :requestId ";

				log.debug("npwtHql: {}", npwtHql.toString(), req.getRequestId());
				UniformDashboard npwtData = session.createQuery(npwtHql, UniformDashboard.class)
						.setParameter("requestId", req.getRequestId() + "")
						.setMaxResults(1).uniqueResult();

				log.debug("UniformDashboard:  {}", npwtData);

				if (req.getAddendum() == 0 || req.getRecordModify() == 1) {

					// Make entry in History timeline
					Integer historyId = historyTimelineDAO.getHistoryId();

					MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
					historyTimeline.setRequestId(req.getRequestId());
					historyTimeline.setHistoryId(historyId + 1);
					historyTimeline.setBluebookId(req.getBluebookId());
					historyTimeline.setFacilityId(Long.valueOf(req.getFacilityId()));
					historyTimeline.setLastUpdatedUserFullname(req.getLastUpdatedUserFullname());
					historyTimeline.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
					historyTimeline.setLastUpdatedUsername(req.getLastUpdatedUsername());
					historyTimeline.setPatientId(req.getPatientId());
					historyTimeline.setPatientName(req.getPatientFullname());
					historyTimeline.setRetrieveStatus(retrieveStatus);

					VendorStatus vendorStatus = new VendorStatus();
					vendorStatus.setCurrentStatus(npwtData.getVendorStatus());
					historyTimeline.setVendorStatus(vendorStatus);

					HistoryUserNotes userNotesObj = new HistoryUserNotes();
					if (retrieveStatus.equalsIgnoreCase("Exhausted")) {
						userNotesObj.setDescription("Chart is exhausted");
					} else {
						userNotesObj.setDescription(
								req.getStatusUpdatedUserFullName() + "# Added a note");
					}

					historyTimeline.setUserNotes(userNotesObj);
					historyTimelineDAO.saveHistoryTimeline(historyTimeline);
				}

				// Send InApp Notification if any users are tagged on notes
				if (req.getTaggedUsers() != null && req.getTaggedUsers().size() > 0) {
					appNotificationDAO.saveNoteNotifications(req);
				}	
			}
			
		} catch (Exception e) {
			log.error("Exception occured while saving notes:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}

		return req;
	}

	@Override
	public List<MasterUserNotes> getMasterNotesList(String requestId, int index, String serviceLine)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterUserNotes> notesList = new ArrayList<>();
		try {
			
			String hql = "FROM MasterUserNotes n WHERE n.requestId = :requestId"
					+ " order by lastUpdatedTimestamp desc";

			if(serviceLine.equalsIgnoreCase("CTP")) {
				notesList = (List<MasterUserNotes>) session.createQuery(hql)
						.setParameter("requestId", requestId)
						.setFirstResult(index).setMaxResults(MASTER_NOTES_SIZE - 5)
						.list();
			} else if (serviceLine.equalsIgnoreCase("NPWT")) {
				notesList = (List<MasterUserNotes>) session.createQuery(hql)
						.setParameter("requestId", requestId)
						.setFirstResult(index).setMaxResults(MASTER_NOTES_SIZE - 5)
						.list();
			}
			

		} catch (Exception e) {
			log.error("Exception occured while fetching notes:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return notesList;
	}

	@Override
	public Long getNotesCount(String requestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;

		try {
			String hql = "SELECT count(*) FROM MasterUserNotes n WHERE n.requestId = :requestId";

			taskCount = (Long) session.createQuery(hql)
					.setParameter("requestId", requestId)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching notes count: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return taskCount;
	}
	
	@Override
	public MasterUserNotes getNoteById(String noteId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		MasterUserNotes note = new MasterUserNotes();
		try {
			String hql = "FROM MasterUserNotes n WHERE n.noteId = :noteId ";

			note = session.createQuery(hql, MasterUserNotes.class)
					.setParameter("noteId", noteId).uniqueResult();

		} catch (Exception e) {
			log.error("Exception occured while fetching notes: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return note;
	}

	@Override
	public MasterChartDetailsObj getUniformChartDetails(
			MasterChartDetailsReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		MasterChartDetailsObj chartReviewDetails = new MasterChartDetailsObj();
		try {
			String ctpHql = "FROM UniformDashboard a WHERE a.requestId = :requestId ";

			log.debug("ctpHQL: {}", ctpHql.toString(), req.getRequestId());

			UniformDashboard uniformData = session.createQuery(
					ctpHql, UniformDashboard.class)
						.setParameter("requestId", req.getRequestId())
						.setMaxResults(1).uniqueResult();
			
			String chartHQL = "FROM MasterChartDetails a WHERE a.orderId = :orderId ";

			log.debug("chartHQL: {}", chartHQL.toString(), req.getRequestId());

			MasterChartDetails chartData = session.createQuery(
					chartHQL, MasterChartDetails.class)
						.setParameter("orderId", req.getRequestId())
						.setMaxResults(1).uniqueResult();
			
			log.debug("uniformData:  {}", uniformData);
			log.debug("chartData:  {}", chartData);

			if (uniformData != null && chartData != null) {
				chartReviewDetails.setBbc(uniformData.getBluebookId());
				chartReviewDetails.setRequestId(uniformData.getRequestId());
		
				FacilityDetails facilityDetails = dashboardDAO.getFacilityDetails(
						uniformData.getBluebookId());
				log.debug("Getting FacilityDetails: {}", facilityDetails);
				
				if (facilityDetails != null) {
					chartReviewDetails.setFacilityName(facilityDetails.getFacilityName());
					chartReviewDetails.setFacilityId(facilityDetails.getFacilityId() + "");
					chartReviewDetails.setMarket(facilityDetails.getMarket());
					chartReviewDetails.setDivision(facilityDetails.getDivision());
					chartReviewDetails.setTerritory(facilityDetails.getTerritory());
					chartReviewDetails.setiHealConfiguration(facilityDetails.getCurrentFacilityType());
					chartReviewDetails.setFacilityFax(facilityDetails.getCenterFax() + "");
					chartReviewDetails.setFacilityPhone(facilityDetails.getCenterPhone() + "");
				}

				if (uniformData.getBluebookId() != null
						&& !uniformData.getBluebookId().isEmpty()) {
					RetrieveMembers rtrvMember = chartReviewDAO
							.getTeamMemberByBBC(uniformData.getBluebookId());
					log.debug("Getting RTRV Members: {}", rtrvMember);
					
					if (rtrvMember != null) {
						chartReviewDetails.setDocTeamAnalyst(rtrvMember.getNpwtDocAnalyst());
						chartReviewDetails.setDocTeamClerk(rtrvMember.getNpwtDocClerk());
						chartReviewDetails.setOpsSpecialist(rtrvMember.getOperationsSpecialist());
					}
				}

				chartReviewDetails.setVendorId(uniformData.getVendorId() + "");
				chartReviewDetails.setVendorName(chartData.getVendorName());
				chartReviewDetails.setCurrentStatus(
						getVendorStatus(uniformData.getVendorId(),uniformData.getVendorStatus()));

				chartReviewDetails.setAssignedTo(uniformData.getAssignedTo());
				chartReviewDetails.setAssignedToUsername(uniformData.getAssigneeUsername());
				chartReviewDetails.setAssigneeUserId(uniformData.getAssigneeUserId());
				chartReviewDetails.setPatientName(chartData.getPatientLastName() + ", " 
							+ chartData.getPatientFirstName());

				chartReviewDetails.setPatientFirstName(chartData.getPatientFirstName());
				chartReviewDetails.setPatientLastName(chartData.getPatientLastName());

				chartReviewDetails.setPatientDOB(chartData.getPatientDOB());
				chartReviewDetails.setHealogicsPatientId(chartData.getHealogicsPatientId());
				chartReviewDetails.setHealogicsPatientMRN(chartData.getHealogicsPatientMRN());

				chartReviewDetails.setLastIpdatedUsername(chartData.getLastUpdatedUsername());
				chartReviewDetails.setLastUpdatedDate(chartData.getLastUpdatedTimestamp());
				chartReviewDetails.setLastUpdatedUserFullname(chartData.getLastUpdatedUserFullname());
				chartReviewDetails.setLastUpdatedUserId(chartData.getLastUpdatedUserId());

				chartReviewDetails.setOrderSource(chartData.getOrderSource());
				chartReviewDetails.setReceivedDate(chartData.getReceivedDate());

				// Need to check age calculation
				chartReviewDetails.setAgeDate(chartData.getFirstReceived());
				chartReviewDetails.setFollowupDate(uniformData.getFollowupDate());

				// Primary Insurance JSON
				PrimaryInsuranceMaster primaryInsuranceMaster = new PrimaryInsuranceMaster();
				
				if (chartData.getPrimaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						primaryInsuranceMaster = objectMapper.readValue(
								chartData.getPrimaryInsurance(),
							new TypeReference<PrimaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setPrimaryInsurance(primaryInsuranceMaster);
				} else {
					chartReviewDetails.setPrimaryInsurance(null);
				}

				// Secondary Insurance JSON
				SecondaryInsuranceMaster secondaryInsuranceMaster = new SecondaryInsuranceMaster();
				if (chartData.getSencondaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						secondaryInsuranceMaster = objectMapper.readValue(
								chartData.getSencondaryInsurance(),
							new TypeReference<SecondaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setSecondaryInsurance(secondaryInsuranceMaster);
				} else {
					chartReviewDetails.setSecondaryInsurance(null);
				}

				
				chartReviewDetails.setWoundId(chartData.getWoundId());

				chartReviewDetails.setCaseManagerName(chartData.getCaseManagerLastName()+", "+chartData.getCaseManagerFirstName());
				chartReviewDetails.setProviderName(chartData.getProviderName());
				chartReviewDetails.setLastReceived(chartData.getLastReceived());
				chartReviewDetails.setLastActioned(chartData.getLastActioned());
				if(chartData.getWoundqOrderNo() != null && !chartData.getWoundqOrderNo().isEmpty()) {
					chartReviewDetails.setWqOrderId(Integer.parseInt(chartData.getWoundqOrderNo()));
				} else {
					chartReviewDetails.setWqOrderId(null);
				}
				chartReviewDetails.setLastFileUpdated(chartData.getLastFileUpdated());
				chartReviewDetails.setLastUpdatedDate(chartData.getLastUpdatedTimestamp());
				chartReviewDetails.setFirstReceived(chartData.getFirstReceived());
				chartReviewDetails.setLastFileUpdated(chartData.getLastFileUpdated());
				
				chartReviewDetails.setFilesSent((chartData.getFilesSent() != null)
						? (chartData.getFilesSent() + "") : "");
				
				chartReviewDetails.setNoOfUpdates(getNotesCount(req.getRequestId())  + "");
				chartReviewDetails.setRetrieveStatus(uniformData.getRetrieveStatus());

				// Need to check, no column
				chartReviewDetails.setSecondaryStatus(chartData.getSecondaryStatus());
				
				//Need to add columns
				chartReviewDetails.setOrderNo(chartData.getRentalOrderNo());
				chartReviewDetails.setVendorReferralNo(chartData.getVendorReferralNo());
				
				chartReviewDetails.setCsrName(chartData.getCsrName());
				chartReviewDetails.setCsrPhone(chartData.getCsrPhone());
				chartReviewDetails.setCsrEmail(chartData.getCsrEmail());
				
				DocumentRequest docReq = getRequestedDocsByRtrvId(req.getRequestId());
				
				List<EDocument> eDocs = new ArrayList<>();
				
				if (docReq != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						eDocs = objectMapper.readValue(
								docReq.getDocuments(),
								new TypeReference<List<EDocument>>() {
								});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
				}
				
				List<String> requestedDocs = new ArrayList<>();
				
				if (eDocs != null && eDocs.size() > 0) {
					for (EDocument eDoc : eDocs) {
						String reason = "";
						if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
							reason = eDoc.getReason();
						}
						
						String dateRange = "";
						if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
							dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
									+ formatDate(eDoc.getEndDate()) + ")";
						}
						
						if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
							dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
						}
						
						if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
							dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
						}
						
						if (!reason.isEmpty() && !dateRange.isEmpty()) {
							requestedDocs.add(eDoc.getDocumentType() + " - " + reason + dateRange);
						} else if (!reason.isEmpty()) {
							requestedDocs.add(eDoc.getDocumentType() + " - " + reason);
						} else {
							requestedDocs.add(eDoc.getDocumentType());
						}
					}
				}
				
				chartReviewDetails.setRequestedDocs(requestedDocs);
				chartReviewDetails.setNotes(chartData.getStatusChangeNotes());
			}
			
		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Uniform Chart Details:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return chartReviewDetails;
	}
	
	private String formatDate(Date inputDate) {
		if (inputDate == null) {
			return "";
		}
		
		try {
			DateFormat targetFormat = new SimpleDateFormat("MM/dd/yyyy");
			return targetFormat.format(inputDate);
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
		}
		return "";
	}
	
	@Override
	public MasterChartDetailsObj getchartDetails(MasterChartDetailsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		MasterChartDetailsObj chartReviewDetails = new MasterChartDetailsObj();
		try {
			String ctpHql = "FROM CTPDashboard a WHERE a.orderId = :orderId ";

			log.debug("ctpHQL: {}", ctpHql.toString(), req.getOrderId());

			CTPDashboard ctpData = session.createQuery(
					ctpHql, CTPDashboard.class)
						.setParameter("orderId", req.getOrderId())
						.setMaxResults(1).uniqueResult();

			log.debug("ctpDashboard:  {}", ctpData);

			if (ctpData != null) {
				chartReviewDetails.setBbc(ctpData.getBluebookId());
				chartReviewDetails.setOrderId(ctpData.getOrderId());
				chartReviewDetails.setFacilityName(ctpData.getFacilityName());
				chartReviewDetails.setiHealConfiguration(ctpData.getFacilityType());

				FacilityDetails facilityDetails = dashboardDAO.getFacilityDetails(
						ctpData.getBluebookId());
				log.debug("Getting FacilityDetails: {}", facilityDetails);
				
				if (facilityDetails != null) {
					chartReviewDetails.setFacilityName(facilityDetails.getFacilityName());
					chartReviewDetails.setFacilityId(facilityDetails.getFacilityId() + "");
					chartReviewDetails.setMarket(facilityDetails.getMarket());
					chartReviewDetails.setDivision(facilityDetails.getDivision());
					chartReviewDetails.setTerritory(facilityDetails.getTerritory());
					chartReviewDetails.setFacilityPhone(facilityDetails.getCenterPhone() + "");
					chartReviewDetails.setiHealConfiguration(facilityDetails.getCurrentFacilityType());
					chartReviewDetails.setFacilityFax(facilityDetails.getCenterFax() + "");
				}

				if (ctpData.getBluebookId() != null
						&& !ctpData.getBluebookId().isEmpty()) {
					RetrieveMembers rtrvMember = chartReviewDAO
							.getTeamMemberByBBC(ctpData.getBluebookId());
					log.debug("Getting RTRV Members: {}", rtrvMember);
					
					if (rtrvMember != null) {
						chartReviewDetails.setDocTeamAnalyst(rtrvMember.getCtpAnalyst());
						chartReviewDetails.setDocTeamClerk(rtrvMember.getCtpClerk());
						chartReviewDetails.setOpsSpecialist(rtrvMember.getOperationsSpecialist());
					}
				}

				chartReviewDetails.setVendorId(ctpData.getVendorId() + "");
				chartReviewDetails.setCurrentStatus(ctpData.getVendorStatus());
				chartReviewDetails.setCompletedStatus(ctpData.getCompletedStatus());

				chartReviewDetails.setAssignedTo(ctpData.getAssigneeFullname());
				chartReviewDetails.setAssignedToUsername(ctpData.getAssigneeUsername());
				chartReviewDetails.setAssigneeUserId(ctpData.getAssigneeUserId());
				chartReviewDetails.setPatientName(ctpData.getPatientLastName() + ", " 
							+ ctpData.getPatientFirstName());

				chartReviewDetails.setPatientFirstName(ctpData.getPatientFirstName());
				chartReviewDetails.setPatientLastName(ctpData.getPatientLastName());

				chartReviewDetails.setPatientDOB(ctpData.getPatientDOB());
				chartReviewDetails.setHealogicsPatientId(ctpData.getHealogicsPatientId());
				chartReviewDetails.setHealogicsPatientMRN(ctpData.getHealogicsPatientMRN());

				chartReviewDetails.setPlaceOfService(ctpData.getPlaceOfService());
				chartReviewDetails.setLastIpdatedUsername(ctpData.getLastIpdatedUsername());
				chartReviewDetails.setLastUpdatedDate(ctpData.getLastUpdatedTimestamp());
				chartReviewDetails.setLastUpdatedUserFullname(ctpData.getLastUpdatedUserFullname());
				chartReviewDetails.setLastUpdatedUserId(ctpData.getLastUpdatedUserId());

				chartReviewDetails.setPendPriorAuthWaiting(ctpData.getPendPriorAuthWaiting());
				chartReviewDetails.setUnderAppealStatus(ctpData.getUnderAppealStatus());
				chartReviewDetails.setOrderSource(ctpData.getOrderSource());
				chartReviewDetails.setReceivedDate(ctpData.getReceivedDate());

				// Need to check age calculation
				chartReviewDetails.setAgeDate(ctpData.getReceivedDate());
				chartReviewDetails.setFollowupDate(ctpData.getFollowupDate());
				chartReviewDetails.setPendPriorAuthDate(ctpData.getPendPriorAuthDate());
				chartReviewDetails.setUnderAppealDate(ctpData.getUnderAppealDate());

				chartReviewDetails.setHcpc(ctpData.getHcpc());
				chartReviewDetails.setProductSKU(ctpData.getProductSKU());
				chartReviewDetails.setProductName(ctpData.getProductName());

				// Primary Insurance JSON
				PrimaryInsuranceMaster primaryInsuranceMaster = new PrimaryInsuranceMaster();
				
				if (ctpData.getPrimaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						primaryInsuranceMaster = objectMapper.readValue(
								ctpData.getPrimaryInsurance(),
							new TypeReference<PrimaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setPrimaryInsurance(primaryInsuranceMaster);
				} else {
					chartReviewDetails.setPrimaryInsurance(null);
				}

				// Secondary Insurance JSON
				SecondaryInsuranceMaster secondaryInsuranceMaster = new SecondaryInsuranceMaster();
				if (ctpData.getSencondaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						secondaryInsuranceMaster = objectMapper.readValue(
								ctpData.getSencondaryInsurance(),
							new TypeReference<SecondaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setSecondaryInsurance(secondaryInsuranceMaster);
				} else {
					chartReviewDetails.setSecondaryInsurance(null);
				}

				// Tertiary Insurance JSON
				TertiaryInsuranceMaster tertiaryInsuranceMaster = new TertiaryInsuranceMaster();
				if (ctpData.getTertiaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						tertiaryInsuranceMaster = objectMapper.readValue(
								ctpData.getTertiaryInsurance(),
							new TypeReference<TertiaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setTertiaryInsurance(tertiaryInsuranceMaster);
				} else {
					chartReviewDetails.setTertiaryInsurance(null);
				}

				chartReviewDetails.setNoAppApproved(ctpData.getNoAppApproved());
				chartReviewDetails.setNoUnitsApproved(ctpData.getNoUnitsApproved());
				chartReviewDetails.setApprovelTimeframe(ctpData.getApprovelTimeframe());
				chartReviewDetails.setCompletedDate(ctpData.getCompletedDate());
				chartReviewDetails.setCoverageSummary(ctpData.getCoverageSummary());

				// ICD 10 Codes
				String icd10DataJson = ctpData.getIcd10Codes();
				
				log.debug("icd10DataJson : " +icd10DataJson);
				
				List<ICD10Data> icd10DataList = Collections.emptyList();
				
				if (icd10DataJson != null && !icd10DataJson.isEmpty()) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						icd10DataList = objectMapper.readValue(
							icd10DataJson, new TypeReference<List<ICD10Data>>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Error parsing icd10 JSON: {}", e.getMessage());
					}
					chartReviewDetails.setIcd10Codes(icd10DataList);
				} else {
					chartReviewDetails.setIcd10Codes(null);
				}
				chartReviewDetails.setWoundId(ctpData.getWoundId());
				chartReviewDetails.setMissingElements(ctpData.getMissingElements());
				chartReviewDetails.setSpecialInstructions(ctpData.getSpecialInstructions());

				chartReviewDetails.setProviderName(ctpData.getProviderName());
				chartReviewDetails.setLastReceived(ctpData.getLastReceived());
				chartReviewDetails.setLastActioned(ctpData.getLastActioned());
				
				log.debug("ctpData.getWoundqOrderNo() : " +ctpData.getWoundqOrderNo());
				
				if (ctpData.getWoundqOrderNo() != null && !ctpData.getWoundqOrderNo().isEmpty()) {
					chartReviewDetails.setWqOrderId(Integer.parseInt(ctpData.getWoundqOrderNo()));
				} else {
					chartReviewDetails.setWqOrderId(null);
				}
				
				chartReviewDetails.setFirstReceived(ctpData.getFirstReceived());
				chartReviewDetails.setLastFileUpdated(ctpData.getLastFileUpdated());
				chartReviewDetails.setFilesSent((ctpData.getFilesSent() != null)
						? (ctpData.getFilesSent() + "") : "");
				chartReviewDetails.setNoOfUpdates(getNotesCount(req.getOrderId()) + "");
				chartReviewDetails.setRetrieveStatus(ctpData.getRetrieveStatus());

				chartReviewDetails.setSecondaryStatus(ctpData.getSecondaryStatus());
				chartReviewDetails.setStatusChangeNotes(ctpData.getStatusChangeNotes());
				
				List<VendorWoundDetails> woundProducts = Collections.emptyList();
				
				if (ctpData.getWoundProduct() != null && !ctpData.getWoundProduct().isEmpty()) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						woundProducts = objectMapper.readValue(
								ctpData.getWoundProduct(),
							new TypeReference<List<VendorWoundDetails>>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Error parsing VendorWoundDetails JSON: {}", e.getMessage());
					}
					chartReviewDetails.setWoundProducts(woundProducts);
				} else {
					chartReviewDetails.setWoundProducts(null);
				}
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Master Chart Details:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return chartReviewDetails;
	}
	
	//@Override
	public MasterChartDetailsObj getLifeNetChartDetails(MasterChartDetailsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		MasterChartDetailsObj chartReviewDetails = new MasterChartDetailsObj();
		try {
			String ctpHql = "FROM CTPDashboard a WHERE a.orderId = :orderId ";

			log.debug("ctpHQL: {}", ctpHql.toString(), req.getOrderId());

			CTPDashboard ctpData = session.createQuery(
					ctpHql, CTPDashboard.class)
						.setParameter("orderId", req.getOrderId())
						.setMaxResults(1).uniqueResult();

			log.debug("ctpDashboard:  {}", ctpData);

			if (ctpData != null) {
				chartReviewDetails.setBbc(ctpData.getBluebookId());
				chartReviewDetails.setOrderId(ctpData.getOrderId());
				chartReviewDetails.setFacilityName(ctpData.getFacilityName());
				//chartReviewDetails.setiHealConfiguration(ctpData.getFacilityType());
				
				/*chartReviewDetails.setFacilityName(ctpData.getFacilityName());
				chartReviewDetails.setFacilityId(ctpData.getFacilityId() + "");
				chartReviewDetails.setMarket("Healogics");
				chartReviewDetails.setDivision("Healogics");
				chartReviewDetails.setTerritory("Healogics");
				chartReviewDetails.setFacilityPhone(ctpData.getFacilityPhone());
				chartReviewDetails.setiHealConfiguration(ctpData.getFacilityType());
				chartReviewDetails.setFacilityFax(ctpData.getFacilityFax());*/
				
				FacilityDetails facilityDetails = dashboardDAO.getFacilityDetails(
						ctpData.getBluebookId());
				log.debug("Getting FacilityDetails: {}", facilityDetails);
				
				if (facilityDetails != null) {
					chartReviewDetails.setFacilityName(facilityDetails.getFacilityName());
					chartReviewDetails.setFacilityId(facilityDetails.getFacilityId() + "");
					chartReviewDetails.setMarket(facilityDetails.getMarket());
					chartReviewDetails.setDivision(facilityDetails.getDivision());
					chartReviewDetails.setTerritory(facilityDetails.getTerritory());
					chartReviewDetails.setFacilityPhone(facilityDetails.getCenterPhone() + "");
					chartReviewDetails.setiHealConfiguration(facilityDetails.getCurrentFacilityType());
					chartReviewDetails.setFacilityFax(facilityDetails.getCenterFax() + "");
				}

				if (ctpData.getBluebookId() != null
						&& !ctpData.getBluebookId().isEmpty()) {
					RetrieveMembers rtrvMember = chartReviewDAO
							.getTeamMemberByBBC(ctpData.getBluebookId());
					log.debug("Getting RTRV Members: {}", rtrvMember);
					
					if (rtrvMember != null) {
						chartReviewDetails.setDocTeamAnalyst(rtrvMember.getCtpAnalyst());
						chartReviewDetails.setDocTeamClerk(rtrvMember.getCtpClerk());
						chartReviewDetails.setOpsSpecialist(rtrvMember.getOperationsSpecialist());
					}
				}

				chartReviewDetails.setVendorId(ctpData.getVendorId() + "");
				chartReviewDetails.setCurrentStatus(ctpData.getVendorStatus());
				chartReviewDetails.setCompletedStatus(ctpData.getCompletedStatus());

				chartReviewDetails.setAssignedTo(ctpData.getAssigneeFullname());
				chartReviewDetails.setAssignedToUsername(ctpData.getAssigneeUsername());
				chartReviewDetails.setAssigneeUserId(ctpData.getAssigneeUserId());
				chartReviewDetails.setPatientName(ctpData.getPatientLastName() + ", " 
							+ ctpData.getPatientFirstName());

				chartReviewDetails.setPatientFirstName(ctpData.getPatientFirstName());
				chartReviewDetails.setPatientLastName(ctpData.getPatientLastName());

				chartReviewDetails.setPatientDOB(ctpData.getPatientDOB());
				chartReviewDetails.setHealogicsPatientId(ctpData.getHealogicsPatientId());
				chartReviewDetails.setHealogicsPatientMRN(ctpData.getHealogicsPatientMRN());

				chartReviewDetails.setPlaceOfService(ctpData.getPlaceOfService());
				chartReviewDetails.setLastIpdatedUsername(ctpData.getLastIpdatedUsername());
				chartReviewDetails.setLastUpdatedDate(ctpData.getLastUpdatedTimestamp());
				chartReviewDetails.setLastUpdatedUserFullname(ctpData.getLastUpdatedUserFullname());
				chartReviewDetails.setLastUpdatedUserId(ctpData.getLastUpdatedUserId());

				chartReviewDetails.setPendPriorAuthWaiting(ctpData.getPendPriorAuthWaiting());
				chartReviewDetails.setUnderAppealStatus(ctpData.getUnderAppealStatus());
				chartReviewDetails.setOrderSource(ctpData.getOrderSource());
				chartReviewDetails.setReceivedDate(ctpData.getReceivedDate());

				// Need to check age calculation
				chartReviewDetails.setAgeDate(ctpData.getReceivedDate());
				chartReviewDetails.setFollowupDate(ctpData.getFollowupDate());
				chartReviewDetails.setPendPriorAuthDate(ctpData.getPendPriorAuthDate());
				chartReviewDetails.setUnderAppealDate(ctpData.getUnderAppealDate());

				chartReviewDetails.setHcpc(ctpData.getHcpc());
				chartReviewDetails.setProductSKU(ctpData.getProductSKU());
				chartReviewDetails.setProductName(ctpData.getProductName());

				// Primary Insurance JSON
				PrimaryInsuranceMaster primaryInsuranceMaster = new PrimaryInsuranceMaster();
				
				if (ctpData.getPrimaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						primaryInsuranceMaster = objectMapper.readValue(
								ctpData.getPrimaryInsurance(),
							new TypeReference<PrimaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setPrimaryInsurance(primaryInsuranceMaster);
				} else {
					chartReviewDetails.setPrimaryInsurance(null);
				}

				// Secondary Insurance JSON
				SecondaryInsuranceMaster secondaryInsuranceMaster = new SecondaryInsuranceMaster();
				if (ctpData.getSencondaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						secondaryInsuranceMaster = objectMapper.readValue(
								ctpData.getSencondaryInsurance(),
							new TypeReference<SecondaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setSecondaryInsurance(secondaryInsuranceMaster);
				} else {
					chartReviewDetails.setSecondaryInsurance(null);
				}

				// Tertiary Insurance JSON
				TertiaryInsuranceMaster tertiaryInsuranceMaster = new TertiaryInsuranceMaster();
				if (ctpData.getTertiaryInsurance() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						tertiaryInsuranceMaster = objectMapper.readValue(
								ctpData.getTertiaryInsurance(),
							new TypeReference<TertiaryInsuranceMaster>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					chartReviewDetails.setTertiaryInsurance(tertiaryInsuranceMaster);
				} else {
					chartReviewDetails.setTertiaryInsurance(null);
				}

				chartReviewDetails.setNoAppApproved(ctpData.getNoAppApproved());
				chartReviewDetails.setNoUnitsApproved(ctpData.getNoUnitsApproved());
				chartReviewDetails.setApprovelTimeframe(ctpData.getApprovelTimeframe());
				chartReviewDetails.setCompletedDate(ctpData.getCompletedDate());
				chartReviewDetails.setCoverageSummary(ctpData.getCoverageSummary());

				// ICD 10 Codes
				String icd10DataJson = ctpData.getIcd10Codes();
				List<ICD10Data> icd10DataList = Collections.emptyList();
				
				if (icd10DataJson != null && !icd10DataJson.isEmpty()) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						icd10DataList = objectMapper.readValue(
							icd10DataJson, new TypeReference<List<ICD10Data>>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Error parsing icd10 JSON: {}", e.getMessage());
					}
					chartReviewDetails.setIcd10Codes(icd10DataList);
				} else {
					chartReviewDetails.setIcd10Codes(null);
				}
				chartReviewDetails.setWoundId(ctpData.getWoundId());
				chartReviewDetails.setMissingElements(ctpData.getMissingElements());
				chartReviewDetails.setSpecialInstructions(ctpData.getSpecialInstructions());

				chartReviewDetails.setProviderName(ctpData.getProviderName());
				chartReviewDetails.setLastReceived(ctpData.getLastReceived());
				chartReviewDetails.setLastActioned(ctpData.getLastActioned());
				
				if(ctpData.getWoundqOrderNo() != null && ctpData.getWoundqOrderNo().isEmpty()) {
					chartReviewDetails.setWqOrderId(Integer.parseInt(ctpData.getWoundqOrderNo()));
				}else {
					chartReviewDetails.setWqOrderId(null);	
				}
				
				chartReviewDetails.setFirstReceived(ctpData.getFirstReceived());
				chartReviewDetails.setLastFileUpdated(ctpData.getLastFileUpdated());
				chartReviewDetails.setFilesSent(ctpData.getFilesSent() + "");
				chartReviewDetails.setNoOfUpdates(getNotesCount(req.getOrderId()) + "");
				chartReviewDetails.setRetrieveStatus(ctpData.getRetrieveStatus());

				chartReviewDetails.setSecondaryStatus(ctpData.getSecondaryStatus());
				chartReviewDetails.setStatusChangeNotes(ctpData.getStatusChangeNotes());
				
			}

		} catch (Exception e) {
			log.error(
					"Exception occured while fetching Master Chart Details:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return chartReviewDetails;
	}


	@Override
	public void saveUniformChartDetails(MasterSaveChartReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			String dashboardHQL = " FROM UniformDashboard a "
					+ " WHERE a.requestId = :requestId ";

			UniformDashboard dashboard = session
					.createQuery(dashboardHQL, UniformDashboard.class)
					.setParameter("requestId", req.getRequestId())
					.uniqueResult();

			if (req.getAssigneeChanged() == 1) {
				String assignedToHql = "UPDATE UniformDashboard SET lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
						+ " lastTeamUpdatedFullName = :lastTeamUpdatedFullName, "
						+ " assigneeUsername = :assignee, "
						+ " assignedTo = :assigneeFullName, "
						+ " assigneeUserId = :assigneeUserId "
						+ " WHERE requestId = :requestId ";

				// Saving details
				session.createQuery(assignedToHql)
						.setParameter("lastTeamUpdatedTimestamp",currentTime)
						.setParameter("lastTeamUpdatedFullName",
								req.getLastUpdatedUserFullName())
						.setParameter("assignee", req.getAssigneeUserName())
						.setParameter("assigneeFullName",
								req.getAssigneeFullName())
						.setParameter("assigneeUserId", req.getAssigneeUserId())
						.setParameter("requestId", req.getRequestId())
						.executeUpdate();

				  //  Send InApp Notification when assigneed changed
					appNotificationDAO.saveAssigneeNotifications(req);

			} else if (req.getIsCompleted() == 1){
				String iscompletedhql = "UPDATE UniformDashboard SET "
						+ " lastTeamUpdatedFullName = :lastUpdatedUserFullName, "
						+ " lastTeamUpdatedTimestamp = :lastUpdatedDateTime, "
						+ " assigneeUsername = :assignee, "
						+ " assignedTo = :assigneeFullName, "
						+ " retrieveStatus = :retrieveStatus, "
						+ " assigneeUserId = :assigneeUserId "
						+ " WHERE requestId = :requestId ";

				// Saving details
				session.createQuery(iscompletedhql)
						.setParameter("lastUpdatedUserFullName",
								req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedDateTime",
								currentTime)
						.setParameter("assignee", req.getAssigneeUserName())
						.setParameter("assigneeFullName",
								req.getAssigneeFullName())
						.setParameter("assigneeUserId", req.getAssigneeUserId())
						.setParameter("retrieveStatus", BOConstants.RETRIEVE_COMPLETED_STATUS)
						.setParameter("requestId", req.getRequestId())
						.executeUpdate();
			} else {
				log.debug("enter inside the else block");
				String hql = "UPDATE UniformDashboard SET "
						+ " lastTeamUpdatedFullName = :lastUpdatedUserFullName, "
						+ " lastTeamUpdatedTimestamp = :lastUpdatedDateTime, "
						+ " assigneeUsername = :assignee, "
						+ " assignedTo = :assigneeFullName, "
						+ " assigneeUserId = :assigneeUserId "
						+ " WHERE requestId = :requestId ";

				// Saving details
				session.createQuery(hql)
						.setParameter("lastUpdatedUserFullName",
								req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedDateTime",
								currentTime)
						.setParameter("assignee", req.getAssigneeUserName())
						.setParameter("assigneeFullName",
								req.getAssigneeFullName())
						.setParameter("assigneeUserId", req.getAssigneeUserId())
						.setParameter("requestId", req.getRequestId())
						.executeUpdate();
			} 

			// Updating Documentation History Table
			log.debug("Updating documentation history table.............");

			// Saving Documents to Document Store
			log.debug("Saving attachments: {}", req.getDocuments().size());
			
			if (req.getDocuments() != null && !req.getDocuments().isEmpty()) {
				boolean isSuccess = saveDocuments(req);
			}

			 // Make entry in History timeline
			Integer historyId = historyTimelineDAO.getHistoryId();
			log.debug("historyId: {}", historyId);
			
			log.debug("dashboard : " +dashboard);

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(req.getRequestId());
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setBluebookId(dashboard.getBluebookId());

			historyTimeline.setLastUpdatedUserFullname(
					req.getLastUpdatedUserFullName());
			historyTimeline.setLastUpdatedUserId(
					Long.valueOf(req.getLastUpdatedUserId()));
			historyTimeline
					.setLastUpdatedUsername(req.getLastUpdatedUserName());
			historyTimeline.setPatientId(dashboard.getPatientId());
			historyTimeline.setPatientDOB(dashboard.getPatientDOB());
			historyTimeline.setPatientName(dashboard.getPatientFirstName()+" "+dashboard.getPatientLastName());
			historyTimeline.setAssignedTo(req.getAssigneeFullName());
			historyTimeline.setRetrieveStatus(dashboard.getRetrieveStatus());

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(getVendorStatus(dashboard.getVendorId(),
					dashboard.getVendorStatus()));
			historyTimeline.setVendorStatus(vendorStatus);

			if (req.getAssigneeChanged() == 1) {
				String[] nameStrings = req.getAssigneeFullName().split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				userNotesObj.setDescription("Reassigned to "
						+ nameStrings[1] + " " + nameStrings[0]);

				historyTimeline.setUserNotes(userNotesObj);

			} else {
				String[] nameStrings = req.getLastUpdatedUserFullName().split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				if (req.getIsCompleted() == 1) {
					userNotesObj.setDescription("Chart completed");
					historyTimeline.setRetrieveStatus(BOConstants.RETRIEVE_COMPLETED_STATUS);
				} else {
					userNotesObj.setDescription(nameStrings[1]
							+ " " + nameStrings[0] + "# saved a draft");
				}
				historyTimeline.setUserNotes(userNotesObj);
			}

			log.debug("historyTimeline: {}", historyTimeline);
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);

		} catch (Exception e) {
			log.error(
					"Exception occured while Saving Uniform Chart Details : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}
	
	@Override
	public void saveMasterChartDetails(MasterSaveChartReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			if (req.getOrderId() != null && !req.getOrderId().isEmpty()) {
				String dashboardHQL = " FROM CTPDashboard a "
						+ " WHERE a.orderId = :orderId ";

				CTPDashboard dashboard = session
						.createQuery(dashboardHQL, CTPDashboard.class)
						.setParameter("orderId", req.getOrderId())
						.uniqueResult();

				String chartHQL = "FROM MasterChartDetails where orderId = :orderId";
				MasterChartDetails masterChartDetails = session
						.createQuery(chartHQL, MasterChartDetails.class)
						.setParameter("orderId", req.getOrderId())
						.uniqueResult();
				log.debug("masterChartDetails: {}", masterChartDetails);

				if (masterChartDetails != null) {
					masterChartDetails.setBluebookId(dashboard.getBluebookId());
					masterChartDetails
							.setFollowupDate(dashboard.getFollowupDate());
					masterChartDetails.setVendorId(dashboard.getVendorId());
					masterChartDetails.setVendorName(dashboard.getVendorName());
					masterChartDetails
							.setOrderSource(dashboard.getOrderSource());
					masterChartDetails.setPatientFirstName(
							dashboard.getPatientFirstName());
					masterChartDetails
							.setPatientLastName(dashboard.getPatientLastName());
					masterChartDetails
							.setPatientFullname(dashboard.getPatientFullname());
					masterChartDetails.setLastUpdatedUsername(
							dashboard.getLastIpdatedUsername());
					masterChartDetails.setLastUpdatedTimestamp(currentTime);
					masterChartDetails.setLastUpdatedUserFullname(
							dashboard.getLastUpdatedUserFullname());
					masterChartDetails.setLastUpdatedUserId(
							dashboard.getLastUpdatedUserId());
					masterChartDetails
							.setRetrieveStatus(dashboard.getRetrieveStatus());
					masterChartDetails
							.setVendorStatus(dashboard.getVendorStatus());
					masterChartDetails
							.setReceivedDate(dashboard.getReceivedDate());

					masterChartDetails
							.setFacilityName(dashboard.getFacilityName());
					masterChartDetails.setFacilityId(dashboard.getFacilityId());

					masterChartDetails
							.setCompletedStatus(dashboard.getCompletedStatus());
					masterChartDetails.setPatientDOB(dashboard.getPatientDOB());
					masterChartDetails.setHealogicsPatientId(
							dashboard.getHealogicsPatientId());
					masterChartDetails.setHealogicsPatientMRN(
							dashboard.getHealogicsPatientMRN());

					masterChartDetails
							.setPlaceOfService(dashboard.getPlaceOfService());
					masterChartDetails.setPendPriorAuthWaiting(
							dashboard.getPendPriorAuthWaiting());
					masterChartDetails.setUnderAppealStatus(
							dashboard.getUnderAppealStatus());

					masterChartDetails.setPendPriorAuthDate(
							dashboard.getPendPriorAuthDate());
					masterChartDetails
							.setUnderAppealDate(dashboard.getUnderAppealDate());
					masterChartDetails.setHcpc(dashboard.getHcpc());
					masterChartDetails.setProductSKU(dashboard.getProductSKU());
					masterChartDetails
							.setProductName(dashboard.getProductName());

					// Primary Insurance JSON
					masterChartDetails.setPrimaryInsurance(
							dashboard.getPrimaryInsurance());
					masterChartDetails.setPrimaryInsuranceCompany(
							dashboard.getPrimaryInsuranceCompany());

					// Secondary Insurance JSON
					masterChartDetails.setSencondaryInsurance(
							dashboard.getSencondaryInsurance());

					// Tertiary Insurance JSON
					masterChartDetails.setTertiaryInsurance(
							dashboard.getTertiaryInsurance());

					// ICD 10 Codes
					masterChartDetails.setIcd10Codes(dashboard.getIcd10Codes());

					masterChartDetails
							.setNoAppApproved(dashboard.getNoAppApproved());
					masterChartDetails
							.setNoUnitsApproved(dashboard.getNoUnitsApproved());
					masterChartDetails.setApprovalTimeframe(
							dashboard.getApprovelTimeframe());
					masterChartDetails
							.setCompletedDate(dashboard.getCompletedDate());
					masterChartDetails
							.setCoverageSummary(dashboard.getCoverageSummary());

					masterChartDetails.setWoundId(dashboard.getWoundId());
					masterChartDetails
							.setMissingElements(dashboard.getMissingElements());
					masterChartDetails.setSpecialInstructions(
							dashboard.getSpecialInstructions());
					masterChartDetails
							.setProviderName(dashboard.getProviderName());
					masterChartDetails.setLastReceived(currentTime);
					masterChartDetails.setLastActioned(currentTime);
					masterChartDetails
							.setWoundqOrderNo(dashboard.getWoundqOrderNo());
					masterChartDetails.setFirstReceived(currentTime);
					masterChartDetails.setLastFileUpdated(currentTime);
					masterChartDetails.setFilesSent(dashboard.getFilesSent());
					masterChartDetails
							.setNoOfUpdates(dashboard.getNoOfUpdates());
					session.update(masterChartDetails);
				} else {
					masterChartDetails = new MasterChartDetails();
					masterChartDetails.setOrderId(dashboard.getOrderId());
					masterChartDetails.setBluebookId(dashboard.getBluebookId());
					masterChartDetails
							.setFollowupDate(dashboard.getFollowupDate());
					masterChartDetails.setVendorId(dashboard.getVendorId());
					masterChartDetails.setVendorName(dashboard.getVendorName());
					masterChartDetails
							.setOrderSource(dashboard.getOrderSource());
					masterChartDetails.setPatientFirstName(
							dashboard.getPatientFirstName());
					masterChartDetails
							.setPatientLastName(dashboard.getPatientLastName());
					masterChartDetails
							.setPatientFullname(dashboard.getPatientFullname());
					masterChartDetails.setLastUpdatedUsername(
							dashboard.getLastIpdatedUsername());
					masterChartDetails.setLastUpdatedTimestamp(currentTime);
					masterChartDetails.setLastUpdatedUserFullname(
							dashboard.getLastUpdatedUserFullname());
					masterChartDetails.setLastUpdatedUserId(
							dashboard.getLastUpdatedUserId());
					masterChartDetails
							.setRetrieveStatus(dashboard.getRetrieveStatus());
					masterChartDetails
							.setVendorStatus(dashboard.getVendorStatus());
					masterChartDetails
							.setReceivedDate(dashboard.getReceivedDate());

					masterChartDetails
							.setFacilityName(dashboard.getFacilityName());
					masterChartDetails.setFacilityId(dashboard.getFacilityId());

					masterChartDetails
							.setCompletedStatus(dashboard.getCompletedStatus());
					masterChartDetails.setPatientDOB(dashboard.getPatientDOB());
					masterChartDetails.setHealogicsPatientId(
							dashboard.getHealogicsPatientId());
					masterChartDetails.setHealogicsPatientMRN(
							dashboard.getHealogicsPatientMRN());

					masterChartDetails
							.setPlaceOfService(dashboard.getPlaceOfService());
					masterChartDetails.setPendPriorAuthWaiting(
							dashboard.getPendPriorAuthWaiting());
					masterChartDetails.setUnderAppealStatus(
							dashboard.getUnderAppealStatus());

					masterChartDetails.setPendPriorAuthDate(
							dashboard.getPendPriorAuthDate());
					masterChartDetails
							.setUnderAppealDate(dashboard.getUnderAppealDate());
					masterChartDetails.setHcpc(dashboard.getHcpc());
					masterChartDetails.setProductSKU(dashboard.getProductSKU());
					masterChartDetails
							.setProductName(dashboard.getProductName());

					// Primary Insurance JSON
					masterChartDetails.setPrimaryInsurance(
							dashboard.getPrimaryInsurance());
					masterChartDetails.setPrimaryInsuranceCompany(
							dashboard.getPrimaryInsuranceCompany());

					// Secondary Insurance JSON
					masterChartDetails.setSencondaryInsurance(
							dashboard.getSencondaryInsurance());

					// Tertiary Insurance JSON
					masterChartDetails.setTertiaryInsurance(
							dashboard.getTertiaryInsurance());

					// ICD 10 Codes
					masterChartDetails.setIcd10Codes(dashboard.getIcd10Codes());

					masterChartDetails
							.setNoAppApproved(dashboard.getNoAppApproved());
					masterChartDetails
							.setNoUnitsApproved(dashboard.getNoUnitsApproved());
					masterChartDetails.setApprovalTimeframe(
							dashboard.getApprovelTimeframe());
					masterChartDetails
							.setCompletedDate(dashboard.getCompletedDate());
					masterChartDetails
							.setCoverageSummary(dashboard.getCoverageSummary());

					masterChartDetails.setWoundId(dashboard.getWoundId());
					masterChartDetails
							.setMissingElements(dashboard.getMissingElements());
					masterChartDetails.setSpecialInstructions(
							dashboard.getSpecialInstructions());
					masterChartDetails
							.setProviderName(dashboard.getProviderName());
					masterChartDetails.setLastReceived(currentTime);
					masterChartDetails.setLastActioned(currentTime);
					masterChartDetails
							.setWoundqOrderNo(dashboard.getWoundqOrderNo());
					masterChartDetails.setFirstReceived(currentTime);
					masterChartDetails.setLastFileUpdated(currentTime);
					masterChartDetails.setFilesSent(dashboard.getFilesSent());
					masterChartDetails
							.setNoOfUpdates(dashboard.getNoOfUpdates());
					session.save(masterChartDetails);
				}
			}

			if (req.getAssigneeChanged() == 1) {
				String assignedToHql = "UPDATE CTPDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
						+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
						+ " lastIpdatedUsername = :lastUpdatedUsername, "
						+ " lastUpdatedTimestamp = :lastUpdatedDateTime, "
						+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
						+ " lastTeamUpdatedTimestamp = :lastTeamUpdated, "
						+ " assigneeUsername = :assignee, "
						+ " assigneeFullname = :assigneeFullName, "
						+ " assigneeUserId = :assigneeUserId, "
						+ " lastActioned = :lastActioned "
						+ " WHERE orderId = :orderId ";

				// Saving details
				session.createQuery(assignedToHql)
						.setParameter("lastUpdatedUserId",
								req.getLastUpdatedUserId())
						.setParameter("lastUpdatedUserFullName",
								req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername",
								req.getLastUpdatedUserName())
						.setParameter("lastTeamUpdatedUserFullname",
								req.getLastUpdatedUserFullName())
						.setParameter("lastTeamUpdated", currentTime)
						.setParameter("lastActioned", currentTime)
						.setParameter("lastUpdatedDateTime", currentTime)
						.setParameter("assignee", req.getAssigneeUserName())
						.setParameter("assigneeFullName",
								req.getAssigneeFullName())
						.setParameter("assigneeUserId", req.getAssigneeUserId())
						.setParameter("orderId", req.getOrderId())
						.executeUpdate();

				   // Send InApp Notification when assigneed changed
					appNotificationDAO.saveAssigneeNotifications(req);
					
		//Completed Action
			} else if (req.getIsCompleted() == 1){
				String iscompletedhql = "UPDATE CTPDashboard SET lastUpdatedUserId = :lastUpdatedUserId,"
						+ " lastUpdatedUserFullname = :lastUpdatedUserFullname, "
						+ " lastIpdatedUsername = :lastUpdatedUsername, "
						+ " lastUpdatedTimestamp = :lastUpdatedTimestamp, "
						//+ " assigneeUsername = :assignee, "
						//+ " assigneeFullname = :assigneeFullName, "
						+ " retrieveStatus = :retrieveStatus "
						//+ " assigneeUserId = :assigneeUserId "
						+ " WHERE orderId = :orderId "
						 + " AND vendorId = :vendorId ";

				session.createQuery(iscompletedhql)
				       .setParameter("lastUpdatedUserId",
						   req.getLastUpdatedUserId())
						.setParameter("lastUpdatedUserFullname",
								req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername",
								req.getLastUpdatedUserName())
						.setParameter("lastUpdatedTimestamp",
								currentTime)
						//.setParameter("assignee", req.getAssigneeUserName())
						//.setParameter("assigneeFullName",
								//req.getAssigneeFullName())
						//.setParameter("assigneeUserId", req.getAssigneeUserId())
						.setParameter("retrieveStatus", BOConstants.RETRIEVE_COMPLETED_STATUS)
						.setParameter("orderId", req.getOrderId())
						.setParameter("vendorId", req.getVendorId())
						.executeUpdate();
			} else {
				String hql = "UPDATE CTPDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
						+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
						+ " lastIpdatedUsername = :lastUpdatedUsername, "
						+ " lastUpdatedTimestamp = :lastUpdatedDateTime, "
						+ " assigneeUsername = :assignee, "
						+ " assigneeFullname = :assigneeFullName, "
						+ " assigneeUserId = :assigneeUserId, "
						+ " lastActioned = :lastActioned "
						+ " WHERE orderId = :orderId ";

				// Saving details
				session.createQuery(hql)
						.setParameter("lastUpdatedUserId",
								req.getLastUpdatedUserId())
						.setParameter("lastUpdatedUserFullName",
								req.getLastUpdatedUserFullName())
						.setParameter("lastUpdatedUsername",
								req.getLastUpdatedUserName())
						.setParameter("lastActioned", currentTime)
						.setParameter("lastUpdatedDateTime", currentTime)
						.setParameter("assignee", req.getAssigneeUserName())
						.setParameter("assigneeFullName",
								req.getAssigneeFullName())
						.setParameter("assigneeUserId", req.getAssigneeUserId())
						.setParameter("orderId", req.getOrderId())
						.executeUpdate();
			}

			// Updating Documentation History Table
			log.debug("Updating documentation history table.............");

			String historyHQL = " FROM CTPDashboard a "
					+ " WHERE a.orderId = :orderId ";

			CTPDashboard dashboard = session
					.createQuery(historyHQL, CTPDashboard.class)
					.setParameter("orderId", req.getOrderId()).uniqueResult();
			log.debug("dashboard: {}", dashboard);

			// Saving Documents to Document Store
			log.debug("Saving attachments: {}", req.getDocuments().size());
			
			if (req.getDocuments() != null && !req.getDocuments().isEmpty()) {
				boolean isSuccess = saveDocuments(req);
			}

			// Make entry in History timeline
			Integer historyId = historyTimelineDAO.getHistoryId();
			log.debug("historyId: {}", historyId);

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(req.getOrderId());
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setBluebookId(dashboard.getBluebookId());

			if (dashboard.getFacilityId() != null) {
				historyTimeline
						.setFacilityId(Long.valueOf(dashboard.getFacilityId()));
			}
			historyTimeline.setLastUpdatedUserFullname(
					req.getLastUpdatedUserFullName());
			historyTimeline.setLastUpdatedUserId(
					Long.valueOf(req.getLastUpdatedUserId()));
			historyTimeline
					.setLastUpdatedUsername(req.getLastUpdatedUserName());
			historyTimeline.setPatientId(
					Long.valueOf(dashboard.getHealogicsPatientId()));
			historyTimeline.setPatientDOB(dashboard.getPatientDOB());
			historyTimeline.setPatientName(dashboard.getPatientFullname());
			historyTimeline.setAssignedTo(req.getAssigneeFullName());
			historyTimeline.setRetrieveStatus(dashboard.getRetrieveStatus());

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(dashboard.getVendorStatus());
			historyTimeline.setVendorStatus(vendorStatus);

			if (req.getAssigneeChanged() == 1) {
				String[] nameStrings = req.getAssigneeFullName().split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				userNotesObj.setDescription("Reassigned to " + nameStrings[1]
						+ " " + nameStrings[0]);

				historyTimeline.setUserNotes(userNotesObj);

			} else {
				String[] nameStrings = req.getLastUpdatedUserFullName().split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				if(req.getIsCompleted() == 1){
					userNotesObj.setDescription("Chart completed");
				}else{
				userNotesObj.setDescription(nameStrings[1] + " "
						+ nameStrings[0] + "# saved a draft");
				}

				historyTimeline.setUserNotes(userNotesObj);
				historyTimeline.setRetrieveStatus(BOConstants.RETRIEVE_COMPLETED_STATUS);
			}

			log.debug("historyTimeline: {}", historyTimeline);
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);

		} catch (Exception e) {
			log.error(
					"Exception occured while Saving Master Chart Details : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	@Override
	public boolean saveDocuments(MasterSaveChartReq req) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		List<EDocument> eDocs = new ArrayList<>();
		boolean isSuccess = false;
		String requestId = "";
		
		if (req.getServiceLine().equalsIgnoreCase("CTP")) {
			requestId = req.getOrderId();
		} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
			requestId = req.getRequestId();
		}
		 
		try {
			if (req.getDocuments() != null && !req.getDocuments().isEmpty()) {
				String rowNoteIdHQL = "SELECT MAX(storeId) from MasterDocumentStore ";

				Integer id = (Integer) session.createQuery(rowNoteIdHQL)
						.uniqueResult();
				
				DocumentRequest documentRequest = null;
				
				if (req.getServiceLine().equalsIgnoreCase("CTP")) {
					String hqlString = " FROM DocumentRequest where requestId = :requestId ";
					documentRequest = session
							.createQuery(hqlString, DocumentRequest.class)
							.setParameter("requestId", requestId)
							.uniqueResult();
					
				} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
					String hqlString = " FROM DocumentRequest where requestId = :requestId"
							+ " order by createdTimestamp desc";
					documentRequest = session
							.createQuery(hqlString, DocumentRequest.class)
							.setParameter("requestId", requestId)
							.uniqueResult();
				}
				
				if (documentRequest != null && documentRequest.getDocuments() != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						eDocs = objectMapper.readValue(
								documentRequest.getDocuments(),
								new TypeReference<List<EDocument>>() {
								});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
				}

				for (MasterSaveAttachmentObj document : req.getDocuments()) {
					log.debug("-------------------------------------");
					log.debug("document : " +document);
					
					if (id != null) {
						id = id + 1;
					} else {
						id = 1;
					}
					log.debug("document.isNewFile() : {}",
							document.isNewFile());
					log.debug("document.isDeleted() : {}",
							document.isDeleted());

					String documentType = getFileTypeForS3(
							document.getDocumentType());
					log.debug("DocumentType: {}",documentType);

					if (document.isNewFile()) {
						MasterDocumentStore documentStore = new MasterDocumentStore();

						/*documentStore
								.setDocumentToken(UUID.randomUUID().toString());*/
						
						long tokenVal = System.nanoTime();
						log.info("tokenVal : " +tokenVal);
						
						documentStore.setDocumentToken(String.valueOf(tokenVal));
						
						documentStore.setOrderId(requestId);
						
						if (eDocs != null && !eDocs.isEmpty() && eDocs.size() > 0) {
							boolean isMatched = false;
							
							for (EDocument eDoc : eDocs) {
								if (eDoc.getDocumentType()
										.equalsIgnoreCase(documentType)) {
									documentStore.setDocRequestId(
											eDoc.getDocumentRequestId());
									isMatched = true;
									break;
								}
							}
							
							if (!isMatched) {
								if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
									for (EDocument eDoc : eDocs) {
										log.info("eDoc.getDocumentRequestId() : "
													+eDoc.getDocumentRequestId());
										documentStore.setDocRequestId(
												eDoc.getDocumentRequestId());
										isMatched = true;
										break;
									}
									
									//When user trying to attach document more than no of dod requested
									//It will fail with randomUUID
									//Need to add fix in UI to limit no doc uploading
									if (!isMatched) {
										documentStore.setDocRequestId(
												UUID.randomUUID().toString());
									}
									
								} else {
									documentStore.setDocRequestId(
											UUID.randomUUID().toString());
								}
							}
						} else {
							documentStore.setDocRequestId(
									UUID.randomUUID().toString());
						}
						
						documentStore.setDocumentType(documentType);
						documentStore.setDocumentAvailable(0);

						if (document.getDocumentSource().equalsIgnoreCase(
								"IHEAL") || !document.getIsManualDoc()) {
							documentStore.setIhealDocumentId(Long
									.valueOf(document.getDocumentEntityId()));
							
							if (document.getVersionId() != null
									&& !document.getVersionId().isEmpty()) {
								documentStore.setIhealVersionId(
										Long.valueOf(document.getVersionId()));
							}
						}

						documentStore.setDocumentContent(
								document.getDocumentContent());
						documentStore.setDocumentStatus("SAVED");
						documentStore
								.setDocumentName(document.getDocumentName());
						
						if (document.getIsManualDoc()) {
							documentStore.setDocumentSource("MANUAL");
							
							if (document.getDocumentName().endsWith(".png")
									|| document.getDocumentName().endsWith(".PNG")) {
								documentStore.setDocMimeType("image/png");
								
							} else if (document.getDocumentName().endsWith(".jpg")
									|| document.getDocumentName().endsWith(".jpeg")
									|| document.getDocumentName().endsWith(".JPG")
									|| document.getDocumentName().endsWith(".JPEG")) {
								documentStore.setDocMimeType("image/jpeg");
								
							} else if (document.getDocumentName().endsWith(".gif")
									|| document.getDocumentName().endsWith(".GIF")) {
								documentStore.setDocMimeType("image/gif");
								
							} else if (document.getDocumentName().endsWith(".bmp")
									|| document.getDocumentName().endsWith(".BMP")) {
								documentStore.setDocMimeType("image/bmp");

							} else {
								documentStore.setDocMimeType("application/pdf");
							}
							
						} else {
							documentStore.setDocumentSource("IHEAL");
							documentStore.setDocMimeType("application/pdf");
						}

						// need to check
						documentStore.setFacilityType("");
						documentStore.setIhealConfig("");
						documentStore.setServiceLine(req.getServiceLine());
						
						/*if (req.getServiceLine().equalsIgnoreCase("CTP")) {
							documentStore.setVendorName("Kerecis");
						} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
							documentStore.setVendorName("Solventum");
						}*/
						
						documentStore.setVendorName(req.getVendorName());

						if(documentRequest != null) {
							documentStore.setVisitId(documentRequest.getVisitId());
							documentStore
									.setVisitDate(documentRequest.getVisitDate());
	
							documentStore
									.setFacilityId(documentRequest.getFacilityId());
							documentStore
									.setBluebookId(documentRequest.getBluebookId());
							documentStore
									.setVendorId(documentRequest.getVendorId());
							documentStore
									.setPatientId(documentRequest.getPatientId());
							documentStore.setPatientName(
									documentRequest.getPatientName());
						}

						documentStore.setIhealDocRequestStatus(null);
						documentStore.setIhealDocRequestTimestamp(null);
						documentStore.setDocDownloadStatus(null);
						documentStore.setDocDownloadTimestamp(currentTime);
						documentStore.setDocNotificationStatus(null);
						documentStore.setDocNotificationTimestamp(null);
						documentStore.setVendorDocGetStatus(null);
						documentStore.setVendorDocGetTimestamp(null);
						documentStore.setDocSentStatus(null);
						documentStore.setDocSentTimestamp(null);

						documentStore.setLastUpdatedUsername(
								req.getLastUpdatedUserName());
						documentStore.setLastUpdatedUserFullname(
								req.getLastUpdatedUserFullName());
						documentStore.setLastUpdatedUserId(
								Long.valueOf(req.getLastUpdatedUserId()));

						documentStore.setErrorCode("0");
						documentStore.setErrorMessage("Success");

						documentStore.setStoreId(id);

						log.debug("Saving Document to DB: {}", documentStore);
						session.save(documentStore);

					} else if (document.isDeleted()) {
						log.debug("Deleting Document: {}", document);
						String deleteHql = "DELETE from MasterDocumentStore "
								+ " WHERE documentToken = :documentToken AND"
								+ " orderId = :orderId ";
						session.createQuery(deleteHql)
								.setParameter("documentToken",
										document.getDocumentToken())
								.setParameter("orderId", requestId)
								.executeUpdate();
					}
				}
			}
			isSuccess = true;
		} catch (Exception e) {
			log.error(
					"Exception occured while Saving Documents Chart Details : {}",
					e.getMessage());
			isSuccess = false;
			throw new CustomException(e.getMessage());
		}
		return isSuccess;
	}

	@Override
	public List<MasterDocumentStore> getAttachments(String orderId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterDocumentStore> stores = new ArrayList<MasterDocumentStore>();
		try {
			String hql = "FROM MasterDocumentStore where orderId = :orderId ";
			stores = session.createQuery(hql).setParameter("orderId", orderId)
					.list();
			log.debug("Store: {}", stores.size());
		} catch (Exception e) {
			log.error("Exception occured while Fetching Documents : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return stores;
	}

	private String getFileTypeForS3(String doctype) {
		String fileType = "";
		switch (doctype) {
			case "CustomScans" :
				fileType = "CUSTOM_SCANS";
				break;
			case "ProblemList" :
				fileType = "PROBLEM_LIST";
				break;
			case "Debridements" :
				fileType = "PROCEDURE_NOTES";
				break;
			case "ProgressNotes" :
				fileType = "PROGRESS_NOTES";
				break;
			case "WoundAssessments" :
				fileType = "WOUND_ASSESSMENT";
				break;
			case "HxROS" :
				fileType = "PATIENT_HISTORY";
				break;
			case "TestResults" :
				fileType = "TEST_RESULTS";
				break;
			case "LEAsmt" :
				fileType = "LOWER_EXTREMITY";
				break;
			case "ActivityDailyLiving" :
				fileType = "ACTIVITY_DAILY_LIVING";
				break;
			case "DischargeInstructions" :
				fileType = "DISCHARGE_SUMMARY";
				break;
			case "Orders" :
				fileType = "PROVIDER_ORDER";
				break;
			case "NutritionAssessment" :
				fileType = "NUTRITIONAL_ASSESSMENT";
				break;
			case "MedicalRecord" :
				fileType = "MEDICAL_RECONCILIATION";
				break;
			case "InsuranceCard" :
				fileType = "INSURANCE_CARD";
				break;
			case "OperativeReport" :
				fileType = "OPERATIVE_REPORT";
				break;
			default :
				fileType = doctype;
				break;
		}
		return fileType;
	}

	private OrderInfoUpdateRes sendOrderInformation(OrderInfoUpdateReq req) {
		OrderInfoUpdateRes res = null;
		String url = env
				.getProperty(BOConstants.KERECIS_SEND_ORDER_INFO_UPDATE_URL);

		OrderInfoUpdateReq orderReq = new OrderInfoUpdateReq();
		orderReq.setVendorId(req.getVendorId());

		try {
			log.info("Kerecis PostOrderInfoUpdate URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(orderReq,
					getHeaders());

			assert url != null;
			ResponseEntity<OrderInfoUpdateRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							OrderInfoUpdateRes.class);
			res = sresponse.getBody();
			log.debug("orderInfoRes : " + res);
		} catch (HttpClientErrorException e) {
			log.error(String.format(
					"HttpClientErrorException occurred in sendOrderInformation: %s",
					e));
			res = new OrderInfoUpdateRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setResponseCode(errorResponse.get(ERRORCODE));
			res.setResponseMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(String.format(
					"HttpStatusCodeException occurred in sendOrderInformation: %s",
					e));
			res = new OrderInfoUpdateRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setResponseCode(errorResponse.get(ERRORCODE));
			res.setResponseMessage(errorResponse.get(ERRORMESSAGE));
		}
		return res;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");

		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	@Override
	public CTPDashboard getDashboard(String orderId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		CTPDashboard dashboard = null;
		try {
			String historyHQL = " FROM CTPDashboard a " + " WHERE a.orderId = :orderId ";
	
			dashboard = session.createQuery(historyHQL, CTPDashboard.class)
					.setParameter("orderId", orderId).uniqueResult();
			log.debug("dashboard: {}", dashboard);
		} catch (Exception e) {
			log.error("Exception occured while getting CTP Dashboard Object : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return dashboard;
	}
	
	@Override
	public UniformDashboard getUniformDashboard(String retrieveReqId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		UniformDashboard uniformData = null;
		try {
			String hql = "FROM UniformDashboard a WHERE a.requestId = :requestId ";

			log.debug("hql: {}", hql.toString(), retrieveReqId);

			uniformData = session.createQuery(
					hql, UniformDashboard.class)
						.setParameter("requestId", retrieveReqId)
						.setMaxResults(1).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while getting CTP Dashboard Object : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return uniformData;
	}

	@Override
	public void updateSubmitStatus(MasterSubmitChartReq req, Long noOfUpdates, int filesSent) throws CustomException {
		
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			String hql = "UPDATE CTPDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
					+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
					+ " lastIpdatedUsername = :lastUpdatedUsername, "
					+ " lastUpdatedTimestamp = :lastUpdatedTimestamp, "
					+ " lastActioned = :lastActioned, "
					+ " retrieveStatus = :retrieveStatus "
					+ " WHERE orderId = :orderId ";

			// Saving details
			session.createQuery(hql).setParameter("lastUpdatedUserId", req.getLastUpdatedUserId())
					.setParameter("lastUpdatedUserFullName", req.getLastUpdatedUserFullName())
					.setParameter("lastUpdatedUsername", req.getLastUpdatedUserName())
					.setParameter("lastUpdatedTimestamp", currentTime)
					.setParameter("lastActioned", currentTime)
					.setParameter("retrieveStatus", "Submitted")
					.setParameter("orderId", req.getOrderId())
					.executeUpdate();
			
			String chartHql = "UPDATE MasterChartDetails SET lastUpdatedTimestamp = :lastUpdatedTimestamp, "
					+ " lastUpdatedUserFullname = :lastUpdatedUserFullname,"
					+ " lastFileUpdated = :lastFileUpdated, "
					+ " retrieveStatus = :retrieveStatus,"
					+ " filesSent =:filesSent"
					+ " WHERE orderId = :requestId ";

			session.createQuery(chartHql)
					.setParameter("lastUpdatedTimestamp",currentTime)
					.setParameter("lastUpdatedUserFullname",
							req.getLastUpdatedUserFullName())
					.setParameter("lastFileUpdated", currentTime)
					.setParameter("retrieveStatus", "Submitted")
					.setParameter("requestId", req.getOrderId())
					.setParameter("filesSent", filesSent)
					.executeUpdate();
			
		} catch (Exception e) {
			log.error("Exception occured while Submitting Master Chart Details : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}
	
	@Override
	public void updateNPWTSubmitStatus(MasterSubmitChartReq req, Long noOfUpdates, int filesSent) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			String assignedToHql = "UPDATE UniformDashboard SET lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
					+ " lastTeamUpdatedFullName = :lastTeamUpdatedFullName, "
					+ " retrieveStatus = :retrieveStatus"
					+ " WHERE requestId = :requestId ";

			session.createQuery(assignedToHql)
					.setParameter("lastTeamUpdatedTimestamp",currentTime)
					.setParameter("lastTeamUpdatedFullName",
							req.getLastUpdatedUserFullName())
					//RTRV-5774 fixes
					//.setParameter("retrieveStatus", "Submitted")
					.setParameter("retrieveStatus", "Completed")
					.setParameter("requestId", req.getRequestId())
					.executeUpdate();
			
			String chartHql = "UPDATE MasterChartDetails SET lastUpdatedTimestamp = :lastUpdatedTimestamp, "
					+ " lastUpdatedUserFullname = :lastUpdatedUserFullname,"
					+ " lastFileUpdated = :lastFileUpdated, "
					+ " retrieveStatus = :retrieveStatus,"
					+ " filesSent =:filesSent"
					+ " WHERE orderId = :requestId ";

			session.createQuery(chartHql)
					.setParameter("lastUpdatedTimestamp",currentTime)
					.setParameter("lastUpdatedUserFullname",
							req.getLastUpdatedUserFullName())
					.setParameter("lastFileUpdated", currentTime)
					.setParameter("retrieveStatus", "Submitted")
					.setParameter("requestId", req.getRequestId())
					.setParameter("filesSent", filesSent)
					.executeUpdate();
			
		} catch (Exception e) {
			log.error("Exception occured while Submitting Master Chart Details : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}
	
	private List<HistoryTimelineDocStatus> getDocumentDetails(String requestId) {
		List<HistoryTimelineDocStatus> docDetails = new ArrayList<>();
		try {
			List<MasterDocumentStore> documents = getAttachments(
					requestId);
			
			if (documents != null && !documents.isEmpty()) {
				for (MasterDocumentStore doc : documents) {
					HistoryTimelineDocStatus docStatus = new HistoryTimelineDocStatus();
					docStatus.setDocumentToken(doc.getDocumentToken());
					docStatus.setDocumentName(doc.getDocumentName());
					docStatus.setDocumentSource(doc.getDocumentSource());
					docStatus.setDocumentType(doc.getDocumentType());
					docStatus.setDocumentDownloadStatus(doc.getDocDownloadStatus());
					docStatus.setVendorDownloadStatus("Pending");
					
					docDetails.add(docStatus);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while generating documents: {}", e.getMessage());
		}
		return docDetails;
	}
	
	@Override
	public void updateOrderInformation(GetOrderUpdateReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			log.debug("Updating Request from Vendor: {}", req);

			log.debug("Updating CTPDashboard: ");

			String hql = "UPDATE CTPDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
					+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
					+ " lastIpdatedUsername = :lastUpdatedUsername, "
					+ " lastUpdatedTimestamp = :lastUpdatedTimestamp, "
					+ " lastActioned = :lastActioned, "
					+ " retrieveStatus = :retrieveStatus, "
					+ " vendorStatus = :vendorStatus "
					+ " WHERE orderId = :orderId ";

			// Saving details
			session.createQuery(hql).setParameter("lastUpdatedUserId", "0")
					.setParameter("lastUpdatedUserFullName", "Retrieve API")
					.setParameter("lastUpdatedUsername", "Retrieve API")
					.setParameter("lastUpdatedTimestamp", currentTime)
					.setParameter("lastActioned", currentTime)
					.setParameter("retrieveStatus", req.getRetrieveStatus())
					.setParameter("vendorStatus", req.getVendorStatus())
					.setParameter("orderId", req.getVendorRequestId())
					.executeUpdate();

			log.debug("Updated CTPDashboard: ");
			log.debug("Updating  Chart Details: ");
			String chartHQL = "UPDATE MasterChartDetails SET lastUpdatedUserId = :lastUpdatedUserId, "
					+ " lastUpdatedUserFullname = :lastUpdatedUserFullname, "
					+ " lastUpdatedUsername = :lastUpdatedUsername, "
					+ " lastUpdatedTimestamp = :lastUpdatedTimestamp, "
					+ " lastActioned = :lastActioned, "
					+ " retrieveStatus = :retrieveStatus, "
					+ " vendorStatus = :vendorStatus "
					+ " WHERE orderId = :orderId ";

			// Saving details
			session.createQuery(chartHQL).setParameter("lastUpdatedUserId", "0")
					.setParameter("lastUpdatedUserFullname", "Retrieve API")
					.setParameter("lastUpdatedUsername", "Retrieve API")
					.setParameter("lastUpdatedTimestamp", currentTime)
					.setParameter("lastActioned", currentTime)
					.setParameter("retrieveStatus", req.getRetrieveStatus())
					.setParameter("vendorStatus", req.getVendorStatus())
					.setParameter("orderId", req.getVendorRequestId())
					.executeUpdate();
			log.debug("Updated Chart Detais: ");

			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", req);
			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(req.getVendorRequestId());
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");
			historyTimeline.setRetrieveStatus(req.getRetrieveStatus());

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(req.getVendorStatus());

			historyTimeline.setVendorStatus(vendorStatus);

			String userNotes = "";

			if (req.getRetrieveStatus() != null
					&& !req.getRetrieveStatus().isEmpty()) {

				switch (req.getRetrieveStatus()) {
					case RETRIEVE_NEW_STATUS : {
						userNotes = NEW_STATUS_TEXT;
					}
						break;

					case RETRIEVE_UNDER_APPEAL_STATUS : {
						userNotes = UNDER_APPEAL_STATUS_TEXT;
					}
						break;

					case RETRIEVE_PENDING_AUTH_STATUS : {
						userNotes = PENDING_AUTH_STATUS_TEXT;
					}
						break;

					case RETRIEVE_RETURNED_STATUS : {
						userNotes = RETURNED_STATUS_TEXT;
					}
						break;
					case RETRIEVE_COMPLETED_STATUS : {
						userNotes = COMPLETED_STATUS_TEXT;
					}
						break;
					case RETRIEVE_CANCELED_STATUS : {
						userNotes = CANCELED_STATUS_TEXT;
					}
						break;
				}
			}

			HistoryUserNotes userNotesObj = new HistoryUserNotes();
			userNotesObj.setDescription(userNotes);

			historyTimeline.setUserNotes(userNotesObj);

			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			log.debug("Created History timeline: ");

		} catch (Exception e) {
			log.error(
					"Exception occured while Updating Order Information Received from Vendor : {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	@Override
	public boolean masterModifyRecord(MasterModifyRecordReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		String retrieveStatus = "";
		String vendorStatus = "";
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			log.debug("Updating record: {}", req);

			if(req.getServiceLine().equalsIgnoreCase("NPWT")) {
				log.debug("Updating record: {}", req);

				String bhcHql = " FROM UniformDashboard a "
						+ " WHERE a.requestId = :requestId ";

				UniformDashboard dashboard = session
						.createQuery(bhcHql, UniformDashboard.class)
						.setParameter("requestId", req.getOrderId()).uniqueResult();
				if (dashboard != null) {
					retrieveStatus = dashboard.getRetrieveStatus();
					vendorStatus = dashboard.getVendorStatus();
				}
				
			} else if (req.getServiceLine().equalsIgnoreCase("CTP")) {
				String bhcHql = " FROM CTPDashboard a "
						+ " WHERE a.orderId = :orderId ";

				CTPDashboard dashboard = session
						.createQuery(bhcHql, CTPDashboard.class)
						.setParameter("orderId", req.getOrderId()).uniqueResult();
				if (dashboard != null) {
					retrieveStatus = dashboard.getRetrieveStatus();
					vendorStatus = dashboard.getVendorStatus();
				}
				
			}
			
			log.debug("Fetched record: ");
			if (req.getAddendum() == 1) {
				
				String hql = "UPDATE MasterChartDetails SET "
						+ " lastActioned = :lastActioned, "
						+ " addendum = :addendum, "
						+ " addendumUserId = :addendumUserId, "
						+ " addendumUsername = :addendumUsername, "
						+ " addendumUserFullname = :addendumUserFullname "
						+ " WHERE orderId = :orderId ";
				
				session.createQuery(hql)
						.setParameter("lastActioned", currentTime)
						.setParameter("addendum", req.getAddendum())
						.setParameter("addendumUserId",
								req.getLastUpdatedUserId())
						.setParameter("addendumUsername",
								req.getLastUpdatedUsername())
						.setParameter("addendumUserFullname",
								req.getLastUpdatedUserFullname())
						.setParameter("orderId", req.getOrderId())
						.executeUpdate();
				log.debug("Updating record Addendum: {}", req);
			} else if (req.getRecordModify() == 1) {

				String hql = "UPDATE MasterChartDetails SET "
						+ " lastActioned = :lastActioned, "
						+ " recordModify = :recordModify, "
						+ " recordModifyUserId = :recordModifyUserId, "
						+ " recordModifyUsername = :recordModifyUsername, "
						+ " recordModifyUserFullname = :recordModifyUserFullname "
						+ " WHERE orderId = :orderId ";

				session.createQuery(hql)
						.setParameter("lastActioned", currentTime)
						.setParameter("recordModify", req.getRecordModify())
						.setParameter("recordModifyUserId",
								req.getLastUpdatedUserId())
						.setParameter("recordModifyUsername",
								req.getLastUpdatedUsername())
						.setParameter("recordModifyUserFullname",
								req.getLastUpdatedUserFullname())
						.setParameter("orderId", req.getOrderId())
						.executeUpdate();
				log.debug("Updating record RecordModify: {}", req);
			}

			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", req);
			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(req.getOrderId());
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setBluebookId(null);
			historyTimeline.setFacilityId(null);
			historyTimeline.setLastUpdatedUserFullname(
					req.getLastUpdatedUserFullname());
			historyTimeline.setLastUpdatedUserId(
					Long.valueOf(req.getLastUpdatedUserId()));
			historyTimeline
					.setLastUpdatedUsername(req.getLastUpdatedUsername());
			historyTimeline.setRetrieveStatus(retrieveStatus);

			VendorStatus vendorStatusObj = new VendorStatus();
			vendorStatusObj.setCurrentStatus(vendorStatus);

			historyTimeline.setVendorStatus(vendorStatusObj);
			
			if (req.getAddendum() == 1) {
				String[] nameStrings = req.getLastUpdatedUserFullname()
						.split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				userNotesObj.setDescription(nameStrings[1] + " "
						+ nameStrings[0] + "# Added an update");

				historyTimeline.setUserNotes(userNotesObj);

			} else if (req.getRecordModify() == 1) {
				String[] nameStrings = req.getLastUpdatedUserFullname()
						.split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				userNotesObj.setDescription(nameStrings[1] + " "
						+ nameStrings[0] + "# reopened the record");

				historyTimeline.setUserNotes(userNotesObj);
			}

			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			log.debug("Created History timeline: ");

		} catch (Exception e) {
			log.error("Exception occured while modifying Master record: {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return true;
	}

	@Override
	public ViewAttachmentRes viewManualAttachment(MasterChartDetailsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();

		ViewAttachmentRes res = new ViewAttachmentRes();

		try {

			log.debug("orderId:   {}", req.getOrderId());
			log.debug("documentToken:  {}", req.getDocumentToken());

			String hql = "FROM MasterDocumentStore "
					+ " WHERE orderId = :orderId AND documentToken = :documentToken";
			
			MasterDocumentStore manualAttachment = session
					.createQuery(hql, MasterDocumentStore.class)
					.setParameter("documentToken", req.getDocumentToken())
					.setParameter("orderId", req.getOrderId())
					.setMaxResults(1)
					.uniqueResult();

			if (manualAttachment != null) {
				res.setDocumentStream(manualAttachment.getDocumentContent());
				int lastIndex = manualAttachment.getDocumentName()
						.lastIndexOf('.');
				
				if (lastIndex != -1 && lastIndex < manualAttachment
						.getDocumentName().length() - 1) {
					res.setMimeType(manualAttachment.getDocumentName()
							.substring(lastIndex + 1));
					
					log.debug("mimeType:   {}", manualAttachment
							.getDocumentName().substring(lastIndex + 1));
				}

				res.setResponseCode("0");
				res.setResponseDesc(DAOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(DAOConstants.FAILED);
				res.setDocumentStream(null);
				res.setMimeType(null);
			}
		} catch (Exception e) {
			log.info("Exception occured in Get Manual Attachment Content:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return res;
	}

	@Override
	public CTPDashboard getRecordByRequestId(String requestId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		CTPDashboard ctpData = null;
		try {
			String ctpHql = "FROM CTPDashboard a WHERE a.orderId = :orderId ";

			log.debug("ctpHQL: {}", ctpHql.toString(), requestId);

			ctpData = session.createQuery(ctpHql, CTPDashboard.class)
					.setParameter("orderId", requestId).setMaxResults(1)
					.uniqueResult();

		} catch (Exception e) {
			log.error("Exception occured while fetching Master Record:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return ctpData;
	}
	
	@Override
	public DocumentRequest getRequestedDocsByRtrvId(String rtrvReqId)
			throws CustomException {
		
		Session session = this.sessionFactory.getCurrentSession();
		DocumentRequest documentRequest = null;
		try {
			
			String hqlString = " FROM DocumentRequest where requestId = :requestId"
					+ " order by createdTimestamp desc";
			
			log.debug("ctpHQL: {}", hqlString.toString());
			
			documentRequest = session
					.createQuery(hqlString, DocumentRequest.class)
					.setParameter("requestId", rtrvReqId)
					.uniqueResult();

		} catch (Exception e) {
			log.error("Exception occured in getRequestedDocsByRtrvId:  {}",
					e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return documentRequest;
	}
	
	private String getVendorStatus(Integer vendorId, String orderStatus) {
		String vendorStatus = orderStatus;
		
		if (vendorId == 5 || vendorId == 2) {
			switch (orderStatus) {
			case DAOConstants.SOLVENTUM_FULL_MR_REQUEST: {
				vendorStatus = DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER: {
				vendorStatus = DAOConstants.VENDOR_ORDER_RELEASE_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_1: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_1_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_SUB_CYCLE_2: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_2_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_3: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_3_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_4: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_4_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_ADDITIONAL_DOC_REQUIRED: {
				vendorStatus = DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED;
			}
				break;
				
			default:
				break;
			}
		}
		return vendorStatus;
	}
	
	@Override
	public int updatePatientDetails(UpdatePatientDetailsReq req)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		int rowChanges = 0;
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			 Date patientDOB = CommonUtils.formatStringToDate(req.getPatientDOB());
		//	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

			String hql = "UPDATE MasterChartDetails SET healogicsPatientId = :patientId, "
					+ " healogicsPatientMRN = :patientMRN, "
					+ " patientFirstName = :patientFirstName, "
					+ " patientLastName = :patientLastName, "
					+ " patientDOB = :patientDOB, "
					+ " patientLinked = :patientLinked, "
					+ " patientLinkUsername = :patientLinkUsername, "
					+ " patientLinkUserId = :patientLinkUserId, "
					+ " patientLinkUserFullname = :patientLinkUserFullname, "
					+ " patientLinkTimestamp = :patientLinkTimestamp "
					+ " WHERE orderId = :orderId";

			rowChanges = session.createQuery(hql)
					.setParameter("patientId",
							Integer.parseInt(req.getPatientId()))
					.setParameter("patientMRN", req.getPatientMRN())
					.setParameter("patientFirstName", req.getPatientFirstName())
					.setParameter("patientLastName", req.getPatientLastName())
					.setParameter("patientDOB",	patientDOB)
					.setParameter("orderId", req.getRequestId())
					.setParameter("patientLinked", req.getPatientLinked())
					.setParameter("patientLinkUsername",
							req.getPatientLinkUsername())
					.setParameter("patientLinkUserId",
							req.getPatientLinkUserId())
					.setParameter("patientLinkUserFullname",
							req.getPatientLinkUserFullname())
					.setParameter("patientLinkTimestamp", currentTime)
					.executeUpdate();

		} catch (Exception e) {
			log.error("Exception occured while updating patient details in DB: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return rowChanges;
	}

}
