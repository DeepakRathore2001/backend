package com.healogics.rtrv.dao.impl;

import java.time.LocalDateTime;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.MasterEmailDAO;
import com.healogics.rtrv.dto.Email;
import com.healogics.rtrv.entity.MasterEmailNotification;

@Repository
@TransactionManager2
public class MasterEmailDAOImpl implements MasterEmailDAO{

	private final Logger log = LoggerFactory.getLogger(MasterEmailDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public MasterEmailDAOImpl(@Qualifier("SessionFactory2")SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public boolean saveMailNotification(Email emailObj) {
		Session session = this.sessionFactory.getCurrentSession();
		boolean status = false;
		try {
			MasterEmailNotification email = new MasterEmailNotification();
			email.setVendorRequestId(emailObj.getVendorRequestId());
			email.setBluebookId(emailObj.getBluebookId());
			email.setCreatedTimestamp(LocalDateTime.now());
			email.setFacilityId(Long.valueOf(emailObj.getFacilityId()));
			email.setNoteCreatorUserFullname(emailObj.getNoteCreatorUserFullname());
			email.setNoteCreatorUserId(Long.valueOf(emailObj.getNoteCreatorUserId()));
			email.setNoteCreatorUsername(emailObj.getNoteCreatorUsername());
			email.setNoteId(emailObj.getNoteId());
			email.setPatientId(emailObj.getPatientId());
			email.setPatientName(emailObj.getPatientName());
			
			email.setTaggedUserFullname(emailObj.getTaggedUserFullname());
			email.setTaggedUserId(emailObj.getTaggedUserId());
			email.setTaggedUsername(emailObj.getTaggedUsername());
			email.setToEmailId(emailObj.getToEmailId());
			
			email.setNoteURL(emailObj.getNoteURL());
			email.setEmailSentTime(emailObj.getEmailSentTime());
			email.setEmailStatus(emailObj.getEmailStatus());
			email.setResponseCode(emailObj.getResponseCode());
			email.setResponseMessage(emailObj.getResponseMessage());
			
			session.save(email);
			status = true;
		} catch (Exception e) {
			log.error("Exception occured : {}" ,e.getMessage());
		}
		return status;
	}

}
