package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.DAOConstants.MASTER_HISTORY_TIMELINE_SIZE;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dto.HistoryTimelineDocStatus;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.entity.MasterDocumentationHistory;

@Repository
@TransactionManager2
public class MasterHistoryTimelineDAOImpl implements MasterHistoryTimelineDAO {
	private final Logger log = LoggerFactory.getLogger(MasterHistoryTimelineDAOImpl.class);

	private final SessionFactory sessionFactory;
	
	@Autowired
	public MasterHistoryTimelineDAOImpl(@Qualifier("SessionFactory2")
			SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public void saveHistoryTimeline(MasterHistoryTimeline historyBO) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			MasterDocumentationHistory docHistory = new MasterDocumentationHistory();
			docHistory.setRequestId(historyBO.getRequestId());
			docHistory.setHistoryId(historyBO.getHistoryId());
			docHistory.setBluebookId(historyBO.getBluebookId());
			docHistory.setFacilityId(historyBO.getFacilityId());
			docHistory.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
			docHistory.setLastUpdatedUserFullname(historyBO.getLastUpdatedUserFullname());
			docHistory.setLastUpdatedUserId(historyBO.getLastUpdatedUserId());
			docHistory.setLastUpdatedUsername(historyBO.getLastUpdatedUsername());
			docHistory.setRetrieveStatus(historyBO.getRetrieveStatus());
			
			String vendorStatus = null;
			if(historyBO.getVendorStatus() != null) {
				try {
					vendorStatus = new ObjectMapper()
							.writeValueAsString(historyBO.getVendorStatus());
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception: {}", e);
				}
			}
			
			docHistory.setVendorStatus(vendorStatus);
			
			docHistory.setPatientDOB(historyBO.getPatientDOB());
			docHistory.setPatientId(historyBO.getPatientId());
			docHistory.setPatientName(historyBO.getPatientName());
			docHistory.setAssignedTo(historyBO.getAssignedTo());
			
			String userNotes = null;
			if(historyBO.getUserNotes() != null) {
				try {
					userNotes = new ObjectMapper()
							.writeValueAsString(historyBO.getUserNotes());
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception: {}", e);
				}	
			}
			
			docHistory.setUserNotes(userNotes);
			
			String docStatusObj = null;
			if(historyBO.getDocStatusObj() != null) {
				try {
					docStatusObj = new ObjectMapper()
							.writeValueAsString(historyBO.getDocStatusObj());
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception: {}", e);
				}
			}
			
			docHistory.setDocumentObject(docStatusObj);
			
			session.save(docHistory);
		} catch (Exception e) {
			log.error("Exception occured in saveHistoryTimeline: {}" ,e.getMessage());
		}
	}
	
	@Override
	public Integer getHistoryId() {
		Session session = this.sessionFactory.getCurrentSession();
		Integer historyId = 0;
		try {
			String hql = "SELECT MAX(historyId) from MasterDocumentationHistory ";

			historyId = (Integer) session.createQuery(hql)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured : " +e.getMessage());
		}
		return historyId;
	}
	
	@Override
	public List<MasterDocumentationHistory> getOrderHistory(String orderId, int index) {
		Session session = this.sessionFactory.getCurrentSession();
		List<MasterDocumentationHistory> historyList = null;
		try {
			String hql = "FROM MasterDocumentationHistory where requestId = :requestId"
					+ " order by historyId desc";
			
			log.debug("hql: "+hql);

			historyList = (List<MasterDocumentationHistory>) session.createQuery(hql)
					.setFirstResult(index).setMaxResults(MASTER_HISTORY_TIMELINE_SIZE)
					.setParameter("requestId", orderId)
					.list();
		} catch (Exception e) {
			log.error("Exception occured in : getOrderHistory" +e.getMessage());
		}
		return historyList;
	}
	
	@Override
	public Long getHistoryCount(String orderId) {
		Session session = this.sessionFactory.getCurrentSession();
		Long historyCount = 0L;
		try {
			String hql = "SELECT count(*) FROM MasterDocumentationHistory"
					+ " where requestId = :requestId";
			
			log.debug("hql: "+hql);

			historyCount = (Long) session.createQuery(hql)
					.setParameter("requestId", orderId)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured : " +e.getMessage());
		}
		return historyCount;
	}
	
	@Override
	public MasterDocumentationHistory getHistoryTimelineById(int historyId) {
		Session session = this.sessionFactory.getCurrentSession();
		MasterDocumentationHistory history = null;
		try {
			String hql = "FROM MasterDocumentationHistory where historyId = :historyId";
			
			log.debug("hql: "+hql);

			history = (MasterDocumentationHistory) session.createQuery(hql)
					.setParameter("historyId", historyId)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured in getHistoryTimeline: {}", e.getMessage());
		}
		return history;
	}
	
	@Override
	public void updateHistoryTimeline(int historyId, List<HistoryTimelineDocStatus> docList) {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String docStatusObj = null;
			try {
				docStatusObj = new ObjectMapper()
						.writeValueAsString(docList);
			} catch (JsonProcessingException e) {
				log.error("Json Procession exception: {}", e);
			}
			
			String hql = "UPDATE MasterDocumentationHistory "
					+ " SET documentObject = :documentObject "
					+ " WHERE historyId = :historyId ";

			// Saving details
			session.createQuery(hql)
					.setParameter("documentObject", docStatusObj)
					.setParameter("historyId", historyId)
					.executeUpdate();
		}  catch (Exception e) {
			log.error("Exception occured in getHistoryTimeline: {}", e.getMessage());
		}
	} 
}
