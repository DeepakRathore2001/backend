package com.healogics.rtrv.dao.impl;

import static com.healogics.rtrv.constants.BOConstants.KERECIS_COMPLETED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.NEW_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.COMPLETED_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.REQUESTED_DOCUMENT_TEXT;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_COMPLETED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_NEW_STATUS;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.config.TransactionManager2;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.DashboardDAO;
import com.healogics.rtrv.dao.MasterAppNotificationDAO;
import com.healogics.rtrv.dao.MasterDashboardDAO;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dao.RetrievePrimaryKeyMapping;
import com.healogics.rtrv.dto.CTPData;
import com.healogics.rtrv.dto.CTPFilterOptions;
import com.healogics.rtrv.dto.DocsReq;
import com.healogics.rtrv.dto.EDocument;
import com.healogics.rtrv.dto.HistoryUserNotes;
import com.healogics.rtrv.dto.ICD10Data;
import com.healogics.rtrv.dto.ICDCodes;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.dto.OrderInfoObj;
import com.healogics.rtrv.dto.PrimaryInsuranceMaster;
import com.healogics.rtrv.dto.SecondaryInsuranceMaster;
import com.healogics.rtrv.dto.TertiaryInsuranceMaster;
import com.healogics.rtrv.dto.UniformData;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.dto.VendorProductDetails;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.dto.VendorWoundDetails;
import com.healogics.rtrv.dto.WoundQOrderDetails;
import com.healogics.rtrv.dto.WoundQOrderDetailsRes;
import com.healogics.rtrv.dto.WoundQOrderFacilityObj;
import com.healogics.rtrv.dto.WoundQOrderInsuranceObj;
import com.healogics.rtrv.dto.WoundQProduct;
import com.healogics.rtrv.dto.WoundQWoundDetails;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentLibrary;
import com.healogics.rtrv.entity.DocumentRequest;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.entity.MasterChartDetails;
import com.healogics.rtrv.entity.NotesAttemptType;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.PrimaryKeySetup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;
import com.healogics.rtrv.utils.FilterRequestUtil;

@Repository
@TransactionManager2
public class MasterDashboardDAOImpl implements MasterDashboardDAO {

	private final Logger log = LoggerFactory.getLogger(MasterDashboardDAOImpl.class);

	private final SessionFactory sessionFactory;
	private final DashboardDAO dashboardDAO;
	private final MasterHistoryTimelineDAO historyTimelineDAO;
	private final MasterAppNotificationDAO appNotificationDAO;

	@Autowired
	public MasterDashboardDAOImpl(@Qualifier("SessionFactory2") SessionFactory sessionFactory,
			DashboardDAO dashboardDAO, MasterHistoryTimelineDAO historyTimelineDAO,
			MasterAppNotificationDAO appNotificationDAO) {
		this.sessionFactory = sessionFactory;
		this.dashboardDAO = dashboardDAO;
		this.historyTimelineDAO = historyTimelineDAO;
		this.appNotificationDAO = appNotificationDAO;
	}

	@Override
	public List<CTPDashboard> getAllCTPRecords(boolean isExcel, MasterCTPDashboardReq req, int offset, String taskType,
			String assignee, Boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<CTPDashboard> ctpDashboard = new ArrayList<>();

		try {
			String hql = "FROM CTPDashboard a WHERE 1 = 1";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.retrieveStatus NOT IN ('Exhausted','Completed','Closed') ";
			}

			if (!isSuperUser) {
				hql += " AND a.bluebookId NOT IN ('x2 - UAT','x2W360','x-Clin Op Demo') ";
			}

			if (taskType != null && taskType.equalsIgnoreCase("NEW")) {
				hql += " AND a.retrieveStatus ='NEW'";

			} else if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.assigneeUsername ='" + req.getUsername() + "'";
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by a.receivedDate asc";
			}

			log.info("query : {}", hql.toString());

			if (isExcel) {
				ctpDashboard = session.createQuery(hql).list();
			} else {
				ctpDashboard = session.createQuery(hql).setFirstResult(offset).setMaxResults(PAGE_SIZE).list();
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching all CTP records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return ctpDashboard;
	}

	private String sortList(MasterCTPDashboardReq req, String hql) {
		String sortBy = "";
		if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
			sortBy = getFilterColumnName(req.getSortBy());
		}
		hql += " ORDER BY " + sortBy + "";
		if (req.getOrder() == 0) {
			hql += " desc";
		} else {
			hql += " asc";
		}
		return hql;
	}

	@Override
	public Long getTotalCount(int index, String taskType, String assignee, MasterCTPDashboardReq req,
			Boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;

		try {
			String hql = "SELECT count(*) FROM CTPDashboard a WHERE 1 = 1";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.retrieveStatus NOT IN ('Exhausted','Completed','Closed') ";
			}

			if (!isSuperUser) {
				hql += " AND a.bluebookId NOT IN ('x2 - UAT','x2W360','x-Clin Op Demo') ";
			}

			if (taskType != null && taskType.equalsIgnoreCase("NEW")) {
				hql += " AND a.retrieveStatus ='NEW'";

			} else if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.assigneeUsername ='" + req.getUsername() + "'";
			}

			totalCount = (Long) session.createQuery(hql).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching total CTP count : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public CTPFilterOptions getFilterOptions(MasterCTPDashboardReq req, Boolean isSuperUser, String serviceLine)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		CTPFilterOptions filterOptions = new CTPFilterOptions();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		List<String> optionList = new ArrayList<>();
		try {
			// Fetching user facilities from DB
			List<UserFacilities> facilities = dashboardDAO.getUserFacilities(req.getUserId(), req.getUsername());
			List<String> userBBC = new ArrayList<>();
			if (facilities != null && !facilities.isEmpty()) {
				for (UserFacilities fac : facilities) {
					if (!isSuperUser) {
						if (!fac.getFacilityId().equalsIgnoreCase("2636")
								&& !fac.getFacilityId().equalsIgnoreCase("3196")) {
							userBBC.add(fac.getFacilityBluebookId());
						}
					} else {
						userBBC.add(fac.getFacilityBluebookId());
					}

				}
			}
			if (userBBC.isEmpty()) {
				userBBC.add("Test");
			}

			String query = " WHERE 1 = 1 AND bluebookId IN :userBBC ";
			String filterColumn = req.getFilterOptions();

			if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				query += " AND assigneeUsername ='" + req.getUsername() + "'";

			}

			Map<String, Object> parameters = new HashMap<>();

			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";
					String filterCol = getFilterColumnName(filterReq);

					switch (filterCol) {
					case "bluebookId": {
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " bluebookId IN :bluebookId ";
						parameters.put("bluebookId", bbcList);
					}
						break;
					case "vendorName": {
						List<String> vendorList = FilterRequestUtil.getListFromDelimitedStr(req.getVendor());
						query += " vendorName IN :vendorName ";
						parameters.put("vendorName", vendorList);
					}
						break;

					case "orderId": {
						List<String> orderIdList = FilterRequestUtil.getListFromDelimitedStr(req.getOrderId());
						query += " orderId IN :orderId ";
						parameters.put("orderId", orderIdList);
					}
						break;

					case "firstReceived": {
						query += " firstReceived BETWEEN :receivedStartDate AND :receivedEndDate ";
						parameters.put("receivedStartDate", dateFormat.parse(req.getFirstReceivedStartDate()));
						parameters.put("receivedEndDate", dateFormat.parse(req.getFirstReceivedEndDate()));
					}
						break;

					case "patientDOB": {
						query += " patientDOB = :patientDOB";
						parameters.put("patientDOB", CommonUtils.formatStringToDate(req.getPatientDOB()));
					}
						break;
					case "patientFullname": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());

						String[] patientArr = null;
						List<String> patientFirstNames = new ArrayList<>();
						List<String> patientLastNames = new ArrayList<>();

						for (String patient : patientNameList) {
							patientArr = patient.split(", ");

							if (patientArr.length >= 2) {
								patientLastNames.add(patientArr[0].trim());
								patientFirstNames.add(patientArr[1].trim());
							}
						}

						query += " patientLastName IN :patientLastNames AND patientFirstName IN :patientFirstNames";
						parameters.put("patientLastNames", patientLastNames);
						parameters.put("patientFirstNames", patientFirstNames);
					}
						break;

					case "assigneeFullname": {
						List<String> assignedToList = FilterRequestUtil.getListFromDelimitedStr(req.getAssignedTo());
						query += " assigneeFullname IN :assignedTo ";
						parameters.put("assignedTo", assignedToList);
					}
						break;

					case "lastUpdatedTimestamp": {
						if (req.isCustomDates()) {
							log.debug("isCustomDate should be true : {}", req.isCustomDates());

							query += " lastUpdatedTimestamp BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate ";

							log.debug("lastTeamUpdated:  " + query);

							parameters.put("lastTeamUpdatedStartDate",
									dateFormat.parse(req.getLastTeamUpdatedStartDate()));
							parameters.put("lastTeamUpdatedEndDate", dateFormat.parse(req.getLastTeamUpdatedEndDate()));

						} else {
							log.debug("isCustomDate should be false : {}", req.isCustomDates());

							String[] dateFilter = req.getDateFilters().split("#");
							boolean firstFilter = true;
							for (String filter : dateFilter) {
								if (firstFilter) {
									firstFilter = false;
								} else {
									query += " OR ";
								}

								if (filter.equalsIgnoreCase("today") && req.getTodayMinDate() != null
										&& !req.getTodayMinDate().isEmpty() && req.getTodayMaxDate() != null
										&& !req.getTodayMaxDate().isEmpty()) {
									query += " (lastUpdatedTimestamp >= :todayMinDate AND lastUpdatedTimestamp <= :todayMaxDate )";

									parameters.put("todayMinDate", dateFormat.parse(req.getTodayMinDate()));
									parameters.put("todayMaxDate", dateFormat.parse(req.getTodayMaxDate()));
								}
								if (filter.equalsIgnoreCase("yesterday") && req.getYesterdayMinDate() != null
										&& !req.getYesterdayMinDate().isEmpty() && req.getYesterdayMaxDate() != null
										&& !req.getYesterdayMaxDate().isEmpty()) {
									query += " (lastUpdatedTimestamp >= :yesterdayMinDate AND lastUpdatedTimestamp <= :yesterdayMaxDate)";
									parameters.put("yesterdayMinDate", dateFormat.parse(req.getYesterdayMinDate()));
									parameters.put("yesterdayMaxDate", dateFormat.parse(req.getYesterdayMaxDate()));
								}
								if (filter.equalsIgnoreCase("thisWeek") && req.getThisWeekMinDate() != null
										&& !req.getThisWeekMinDate().isEmpty() && req.getThisWeekMaxDate() != null
										&& !req.getThisWeekMaxDate().isEmpty()) {
									query += " (lastUpdatedTimestamp >= :thisWeekMinDate AND lastUpdatedTimestamp <= :thisWeekMaxDate)";
									parameters.put("thisWeekMinDate", dateFormat.parse(req.getThisWeekMinDate()));
									parameters.put("thisWeekMaxDate", dateFormat.parse(req.getThisWeekMaxDate()));
								}
								if (filter.equalsIgnoreCase("lastWeek") && req.getLastWeekMinDate() != null
										&& !req.getLastWeekMinDate().isEmpty() && req.getLastWeekMaxDate() != null
										&& !req.getLastWeekMaxDate().isEmpty()) {
									query += " (lastUpdatedTimestamp >= :lastWeekMinDate AND lastUpdatedTimestamp <= :lastWeekMaxDate)";
									parameters.put("lastWeekMinDate", dateFormat.parse(req.getLastWeekMinDate()));
									parameters.put("lastWeekMaxDate", dateFormat.parse(req.getLastWeekMaxDate()));
								}
							}
							log.debug("lastUpdatedTimestamp:  {} ", query);
						}

					}
						break;

					case "orderSource": {
						List<String> orderSourceList = FilterRequestUtil.getListFromDelimitedStr(req.getOrderSource());
						query += " orderSource IN :orderSource ";
						parameters.put("orderSource", orderSourceList);
					}
						break;

					case "facilityType": {
						List<String> facTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getiHealConfiguration());
						query += " facilityType IN :facilityType ";
						parameters.put("facilityType", facTypeList);
					}
						break;

					case "retrieveStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getRetrieveStatus());
						query += " retrieveStatus IN :retrieveStatus ";
						parameters.put("retrieveStatus", statusList);
					}
						break;

					case "vendorStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getCurrentStatus());
						query += " vendorStatus IN :vendorStatus ";
						parameters.put("vendorStatus", statusList);
					}
						break;

					case "followupDate": {
						query += " followupDate BETWEEN :followupStartDate AND :followupEndDate ";
						parameters.put("followupStartDate", dateFormat.parse(req.getFollowupStartDate()));
						parameters.put("followupEndDate", dateFormat.parse(req.getFollowupEndDate()));
					}
						break;

					case "primaryInsuranceCompany": {
						List<String> insList = FilterRequestUtil
								.getListFromDelimitedStr(req.getPrimaryInsuranceCompany());
						query += " primaryInsuranceCompany IN :primaryIns ";
						parameters.put("primaryIns", insList);
					}
						break;

					default:
						break;
					}
				}
			}

			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			if (req.getFilterOptions() != null && !req.getFilterOptions().isEmpty()) {
				filterColumn = getFilterColumnName(req.getFilterOptions());
			}
			log.debug("filterColumn:  " + filterColumn);
			if (filterColumn.equalsIgnoreCase("firstReceived")) {

				String dateHql = "SELECT MIN(firstReceived)," + " MAX(firstReceived) FROM CTPDashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);

				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinFirstReceivedDate((Timestamp) object[0]);
				filterOptions.setMaxFirstReceivedDate((Timestamp) object[1]);

			} else if (filterColumn.equalsIgnoreCase("patientFullname")) {
				hql = "SELECT DISTINCT CONCAT(patientLastName,', ',patientFirstName) FROM CTPDashboard " + query
						+ " ORDER BY patientFullname asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);

			} else if (filterColumn.equalsIgnoreCase("lastUpdatedTimestamp")) {
				String dateHql = "SELECT MIN(lastUpdatedTimestamp), MAX(lastUpdatedTimestamp) FROM CTPDashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinLastTeamUpdatedDate((Date) object[0]);
				filterOptions.setMaxLastTeamUpdatedDate((Date) object[1]);

			} else if (filterColumn.equalsIgnoreCase("followupDate")) {
				String dateHql = "SELECT MIN(followupDate), MAX(followupDate) FROM CTPDashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinFollowupDate((Date) object[0]);
				filterOptions.setMaxFollowupDate((Date) object[1]);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM CTPDashboard " + query + " ORDER BY " + filterColumn
						+ " asc";
				List<String> distinctValues = session.createQuery(hql).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching CTP Dashboard filter options : {}", e.getMessage());
			e.printStackTrace();
			throw new CustomException(e.getMessage());
		}
		return filterOptions;
	}

	private String getFilterColumnName(String parameter) {
		String column = "";
		switch (parameter) {

		case "orderId":
			column = "orderId";
			break;
		case "bbc":
			column = "bluebookId";
			break;
		case "vendor":
			column = "vendorName";
			break;
		case "currentStatus":
			column = "vendorStatus";
			break;
		case "orderSource":
			column = "orderSource";
			break;
		case "followupDate":
			column = "followupDate";
			break;
		case "lastTeamUpdated":
			column = "lastUpdatedTimestamp";
			break;
		case "iHealConfiguration":
			column = "facilityType";
			break;
		case "assignedTo":
			column = "assigneeFullname";
			break;
		case "retrieveStatus":
			column = "retrieveStatus";
			break;
		case "age":
			column = "firstReceived";
			break;
		case "patientName":
			column = "patientFullname";
			break;
		case "patientDOB":
			column = "patientDOB";
			break;
		case "primaryInsuranceCompany":
			column = "primaryInsuranceCompany";
			break;
		default:
			break;
		}
		return column;
	}

	@Override
	public Map<String, Object> getFilteredCTPList(boolean isExcel, MasterCTPDashboardReq req, int index,
			String taskType, String assignee, Boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<CTPDashboard> ctpDashboard = new ArrayList<>();
		List<CTPDashboard> allCTPList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			String hql = "FROM CTPDashboard a WHERE 1 = 1 ";

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.retrieveStatus NOT IN ('Exhausted','Completed','Closed') ";
			}

			if (!isSuperUser) {
				hql += " AND a.bluebookId NOT IN ('x2 - UAT','x2W360','x-Clin Op Demo') ";
			}

			if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {

				hql += " AND a.assigneeUsername ='" + req.getUsername() + "'";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";
					String filterCol = getFilterColumnName(filterReq);
					switch (filterCol) {
					case "bluebookId": {
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.bluebookId IN :bluebookId ";
						parameters.put("bluebookId", bbcList);
					}
						break;
					case "vendorName": {
						List<String> vendorList = FilterRequestUtil.getListFromDelimitedStr(req.getVendor());
						hql += " a.vendorName IN :vendorName ";
						parameters.put("vendorName", vendorList);
					}
						break;

					case "orderId": {
						List<String> orderIdList = FilterRequestUtil.getListFromDelimitedStr(req.getOrderId());
						hql += " a.orderId IN :orderId ";
						parameters.put("orderId", orderIdList);
					}
						break;

					case "firstReceived": {
						hql += " a.firstReceived BETWEEN :receivedStartDate AND :receivedEndDate ";
						parameters.put("receivedStartDate", dateFormat.parse(req.getFirstReceivedStartDate()));
						parameters.put("receivedEndDate", dateFormat.parse(req.getFirstReceivedEndDate()));
					}
						break;

					case "patientDOB": {
						hql += " a.patientDOB = :patientDOB";
						parameters.put("patientDOB", CommonUtils.formatStringToDate(req.getPatientDOB()));
					}
						break;

					case "patientFullname": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());

						String[] patientArr = null;
						List<String> patientFirstNames = new ArrayList<>();
						List<String> patientLastNames = new ArrayList<>();

						for (String patient : patientNameList) {
							patientArr = patient.split(", ");

							if (patientArr.length >= 2) {
								patientLastNames.add(patientArr[0].trim());
								patientFirstNames.add(patientArr[1].trim());
							}
						}

						hql += " a.patientLastName IN :patientLastNames  AND a.patientFirstName IN :patientFirstNames";
						parameters.put("patientLastNames", patientLastNames);
						parameters.put("patientFirstNames", patientFirstNames);
					}
						break;

					case "assigneeFullname": {
						// if (!req.getTaskType().equalsIgnoreCase("MY")) {
						List<String> assignedToList = FilterRequestUtil.getListFromDelimitedStr(req.getAssignedTo());
						hql += " a.assigneeFullname IN :assignedTo ";
						parameters.put("assignedTo", assignedToList);
						// }
					}
						break;

					case "lastUpdatedTimestamp": {

						/*
						 * hql +=
						 * " a.lastUpdatedTimestamp BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate "
						 * ; log.debug("lastTeamUpdated:  " + hql);
						 * parameters.put("lastTeamUpdatedStartDate", dateFormat.parse(req
						 * .getLastTeamUpdatedStartDate())); parameters.put("lastTeamUpdatedEndDate",
						 * dateFormat.parse(req .getLastTeamUpdatedEndDate()));
						 */

						if (req.isCustomDates()) {
							log.debug("isCustomDate should be true : {}", req.isCustomDates());
							hql += "( a.lastUpdatedTimestamp BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate )";
							log.debug("lastTeamUpdated:  " + hql);
							parameters.put("lastTeamUpdatedStartDate",
									dateFormat.parse(req.getLastTeamUpdatedStartDate()));
							parameters.put("lastTeamUpdatedEndDate", dateFormat.parse(req.getLastTeamUpdatedEndDate()));

						} else {
							log.debug("isCustomDate should be false : {}", req.isCustomDates());
							String[] dateFilter = req.getDateFilters().split("#");
							boolean firstFilter = true;
							for (String filter : dateFilter) {
								if (firstFilter) {
									firstFilter = false;
									hql += "(";
								} else {
									hql += " OR ";
								}

								if (filter.equalsIgnoreCase("today") && req.getTodayMinDate() != null
										&& !req.getTodayMinDate().isEmpty() && req.getTodayMaxDate() != null
										&& !req.getTodayMaxDate().isEmpty()) {
									hql += " (a.lastUpdatedTimestamp >= :todayMinDate AND a.lastUpdatedTimestamp <= :todayMaxDate )";
									parameters.put("todayMinDate", dateFormat.parse(req.getTodayMinDate()));
									parameters.put("todayMaxDate", dateFormat.parse(req.getTodayMaxDate()));
								}
								if (filter.equalsIgnoreCase("yesterday") && req.getYesterdayMinDate() != null
										&& !req.getYesterdayMinDate().isEmpty() && req.getYesterdayMaxDate() != null
										&& !req.getYesterdayMaxDate().isEmpty()) {
									hql += " (a.lastUpdatedTimestamp >= :yesterdayMinDate AND a.lastUpdatedTimestamp <= :yesterdayMaxDate)";
									parameters.put("yesterdayMinDate", dateFormat.parse(req.getYesterdayMinDate()));
									parameters.put("yesterdayMaxDate", dateFormat.parse(req.getYesterdayMaxDate()));
								}
								if (filter.equalsIgnoreCase("thisWeek") && req.getThisWeekMinDate() != null
										&& !req.getThisWeekMinDate().isEmpty() && req.getThisWeekMaxDate() != null
										&& !req.getThisWeekMaxDate().isEmpty()) {
									hql += " (a.lastUpdatedTimestamp >= :thisWeekMinDate AND a.lastUpdatedTimestamp <= :thisWeekMaxDate)";
									parameters.put("thisWeekMinDate", dateFormat.parse(req.getThisWeekMinDate()));
									parameters.put("thisWeekMaxDate", dateFormat.parse(req.getThisWeekMaxDate()));
								}
								if (filter.equalsIgnoreCase("lastWeek") && req.getLastWeekMinDate() != null
										&& !req.getLastWeekMinDate().isEmpty() && req.getLastWeekMaxDate() != null
										&& !req.getLastWeekMaxDate().isEmpty()) {
									hql += " (a.lastUpdatedTimestamp >= :lastWeekMinDate AND a.lastUpdatedTimestamp <= :lastWeekMaxDate)";
									parameters.put("lastWeekMinDate", dateFormat.parse(req.getLastWeekMinDate()));
									parameters.put("lastWeekMaxDate", dateFormat.parse(req.getLastWeekMaxDate()));
								}

							}
							hql += ")";
							log.debug("lastUpdatedTimestamp:  {} ", hql);
						}

					}
						break;

					case "orderSource": {
						List<String> orderSourceList = FilterRequestUtil.getListFromDelimitedStr(req.getOrderSource());
						hql += " a.orderSource IN :orderSource ";
						parameters.put("orderSource", orderSourceList);
					}
						break;

					case "facilityType": {
						List<String> facTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getiHealConfiguration());
						hql += " a.facilityType IN :facilityType ";
						parameters.put("facilityType", facTypeList);
					}
						break;

					case "retrieveStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getRetrieveStatus());
						hql += " a.retrieveStatus IN :retrieveStatus ";
						parameters.put("retrieveStatus", statusList);
					}
						break;

					case "vendorStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getCurrentStatus());
						hql += " a.vendorStatus IN :vendorStatus ";
						parameters.put("vendorStatus", statusList);
					}
						break;

					case "followupDate": {
						hql += " a.followupDate BETWEEN :followupStartDate AND :followupEndDate ";
						parameters.put("followupStartDate", dateFormat.parse(req.getFollowupStartDate()));
						parameters.put("followupEndDate", dateFormat.parse(req.getFollowupEndDate()));
					}
						break;

					case "primaryInsuranceCompany": {
						List<String> insList = FilterRequestUtil
								.getListFromDelimitedStr(req.getPrimaryInsuranceCompany());
						hql += " a.primaryInsuranceCompany IN :primaryIns ";
						parameters.put("primaryIns", insList);
					}
						break;

					default:
						break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortList(req, hql);

			} else {
				hql += " order by a.receivedDate asc";
			}

			log.info("query : {}", hql);

			if (isExcel) {
				ctpDashboard = session.createQuery(hql).setProperties(parameters).list();
				listCount.put("Count", ctpDashboard.size());
				listCount.put("data", ctpDashboard);
			} else {
				int count;
				ctpDashboard = session.createQuery(hql).setFirstResult(index).setProperties(parameters)
						.setMaxResults(PAGE_SIZE).list();

				allCTPList = session.createQuery(hql).setFirstResult(index).setProperties(parameters).list();

				count = allCTPList.size() + index;

				listCount.put("Count", count);
				listCount.put("data", ctpDashboard);
				log.debug("ctpDashboard List Size:   {} ", count);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Filtered CTP Records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return listCount;
	}

	@Override
	public void saveRequestedDocs(DocsReq req, String rtrvRequestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			DocumentRequest docReq = new DocumentRequest();
			
			if (req.getVendorId() == 3) {
				docReq.setRequestId(req.getVendorRequestId());
				
			} else if (req.getVendorId() == 5
					|| req.getVendorId() == 2
					|| req.getVendorId() == 4) {
				docReq.setRequestId(rtrvRequestId);
			}
			docReq.setBluebookId(req.getFacilityBBC());
			docReq.setFacilityId(req.getFacilityId());
			docReq.setMedicalRecordNumber(req.getMedicalRecordNumber());
			docReq.setOrderSource(req.getOrderSource());
			docReq.setPatientFirstName(req.getPatientFirstName());
			docReq.setPatientId(Integer.parseInt(req.getPatientId()));
			docReq.setPatientLastName(req.getPatientLastName());
			docReq.setPatientName(req.getPatientLastName() + ", " + req.getPatientFirstName());
			docReq.setVendorCustomerNo(req.getVendorCustomerNumber());
			docReq.setVendorId(req.getVendorId());
			docReq.setVendorOrderNo(req.getVendorRequestId());
			docReq.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));

			if (req.getVisitDate() != null) {
				docReq.setVisitDate(new Timestamp(req.getVisitDate().getTime()));
			} else {
				docReq.setVisitDate(null);
			}

			docReq.setVisitId(req.getVisitId());
			docReq.setWoundqOrderToken(req.getOrderToken());
			docReq.setWoundqOrderNo(req.getOrderDisplayNumber() + "");

			ObjectMapper objectMapper = new ObjectMapper();

			String documents = null;
			try {
				documents = objectMapper.writeValueAsString(req.getDocuments());
			} catch (JsonProcessingException e) {
				log.error("Exception occured while getting documents JSON: " + e.getMessage());
			}
			docReq.setDocuments(documents);

			log.debug("Saving docReq : " + docReq);

			session.save(docReq);
		} catch (Exception e) {
			log.error("Exception occured while fetching Filtered CTP Records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	@Override
	public void saveOrderInfo(String vendorRequestId, OrderInfoObj orderInfoObj,
			DocsReq requestDocs, CTPDashboard ctpRecord, boolean isRecordExists)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());

		log.debug("Inside SaveOrderInfo Method: {}", vendorRequestId);
		log.debug("orderInfoObj : " + orderInfoObj);
		log.debug("requestDocs : " + requestDocs);
		try {

			if (ctpRecord == null) {
				ctpRecord = new CTPDashboard();
			}
			
			ctpRecord.setOrderId(orderInfoObj.getVendorRequestId());
			// ctpRecord.setBluebookId(orderInfoObj.getBbc());
			ctpRecord.setFacilityName(orderInfoObj.getFacilityName());
			ctpRecord.setBluebookId(requestDocs.getFacilityBBC());
			
			if (requestDocs.getVendorId() == 3) {
				ctpRecord.setVendorName("Kerecis");
			}

			FacilityDetails facilityDetails = dashboardDAO.getFacilityDetailsForDetailsCTP(
					requestDocs.getFacilityId());

			log.debug("Getting FacilityDetails: {}", facilityDetails);

			if (facilityDetails != null) {
				if (ctpRecord.getBluebookId() == null || ctpRecord.getBluebookId().isEmpty()) {
					ctpRecord.setBluebookId(facilityDetails.getBluebookId());
					ctpRecord.setFacilityName(facilityDetails.getFacilityName());
				}
				ctpRecord.setFacilityId(facilityDetails.getFacilityId());
				ctpRecord.setFacilityType(facilityDetails.getCurrentFacilityType());
			}

			// need to check

			// vendorReferralNo
			// vendorName //OrderInfo new Update
			// caseManagerFIrstName
			// caseManagerLastName
			// waitingDocSentStatus
			// pendPriorAuthDate
			// pendPriorAuthWaiting
			// underAppealDate
			// underAppealStatus
			// missingElements
			// productSKU
			// productName
			// noAppApproved
			// noUnitsApproved
			// approvelTimeframe
			// woundId
			// completedDate //OrderInfo new Update
			// completedStatus
			// regionalDirector
			// sgpCPTCode
			// providerName //OrderInfo new Update
			// woundqOrderNo //OrderInfo new Update
			// salesRepManager

			ctpRecord.setOrderSource(requestDocs.getOrderSource());
			ctpRecord.setVendorId(requestDocs.getVendorId());
			ctpRecord.setHealogicsOrderNo(orderInfoObj.getHlOrderNo());

			if (orderInfoObj.getHlPatientID() != null && !orderInfoObj.getHlPatientID().isEmpty()) {
				ctpRecord.setHealogicsPatientId(Integer.parseInt(orderInfoObj.getHlPatientID()));
			} else {
				ctpRecord.setHealogicsPatientId(0);
			}

			String patientFirstName = "";
			String patientLastName = "";

			if (requestDocs != null && requestDocs.getPatientFirstName() != null
					&& requestDocs.getPatientLastName() != null) {
				patientFirstName = requestDocs.getPatientFirstName();
				patientLastName = requestDocs.getPatientLastName();
			}

			/*
			 * if(patientFirstName != null && patientLastName != null &&
			 * patientFirstName.isEmpty() && patientLastName.isEmpty()) { if (
			 * orderInfoObj.getPatientName() != null) {
			 * log.debug("orderInfoObj.getPatientName() : "+orderInfoObj. getPatientName());
			 * 
			 * String[] patientName = orderInfoObj.getPatientName().split(" ");
			 * 
			 * if (patientName != null && patientName.length > 1) { patientFirstName =
			 * patientName[0]; patientLastName = patientName[1]; } else { patientFirstName =
			 * orderInfoObj.getPatientName(); patientLastName = ""; } } }
			 */

			ctpRecord.setPatientFirstName(patientFirstName);
			ctpRecord.setPatientLastName(patientLastName);
			ctpRecord.setPatientFullname(patientLastName + ", " + patientFirstName);

			if (orderInfoObj.getPatientDOB() != null && !orderInfoObj.getPatientDOB().isEmpty()) {
				ctpRecord.setPatientDOB(new SimpleDateFormat("yyyy-MM-dd").parse(orderInfoObj.getPatientDOB()));
			} else {
				ctpRecord.setPatientDOB(null);
			}
			ctpRecord.setHealogicsPatientMRN(requestDocs.getMedicalRecordNumber());

			String physicianFirstName = "";
			String physicianLastName = "";

			if (orderInfoObj.getPhysicianName() != null) {
				log.debug("orderInfoObj.getPhysicianName() : " + orderInfoObj.getPhysicianName());

				if (orderInfoObj.getPhysicianName().contains(",")) {
					String[] physicianName = orderInfoObj.getPhysicianName().split(", ");

					if (physicianName != null && physicianName.length > 1) {
						physicianFirstName = physicianName[1];
						physicianLastName = physicianName[0];
					} else {
						physicianFirstName = orderInfoObj.getPhysicianName();
						physicianLastName = "";
					}
				} else {
					String[] physicianName = orderInfoObj.getPhysicianName().split(" ");

					if (physicianName != null && physicianName.length > 1) {
						physicianFirstName = physicianName[0];
						physicianLastName = physicianName[1];
					} else {
						physicianFirstName = orderInfoObj.getPhysicianName();
						physicianLastName = "";
					}
				}
			}

			ctpRecord.setPhysicianFirstName(physicianFirstName);
			ctpRecord.setPhysicianLastName(physicianLastName);
			ctpRecord.setReceivedDate(new Date());

			if (orderInfoObj.getFollowupDate() != null
					&& !orderInfoObj.getFollowupDate().isEmpty()) {
				ctpRecord.setFollowupDate(new SimpleDateFormat("yyyy-MM-dd")
						.parse(orderInfoObj.getFollowupDate()));
			} else {
				ctpRecord.setFollowupDate(null);
			}
			ctpRecord.setHcpc(orderInfoObj.getHcpc());
			ctpRecord.setSpecialInstructions(orderInfoObj.getSpecialInstructions());
			ctpRecord.setPlaceOfService(orderInfoObj.getPlaceOfService());
			ctpRecord.setCoverageSummary(orderInfoObj.getCoverageSummary());
			ctpRecord.setInsertTimestamp(currentTime);
			ctpRecord.setFirstReceived(currentTime);
			ctpRecord.setSgp(orderInfoObj.getSgp());

			if (orderInfoObj.getSgpDate() != null && !orderInfoObj.getSgpDate().isEmpty()) {
				ctpRecord.setSgpDate(new SimpleDateFormat("yyyy-MM-dd").parse(orderInfoObj.getSgpDate()));
			} else {
				ctpRecord.setSgpDate(null);
			}

			ctpRecord.setLastUpdatedTimestamp(currentTime);
			ctpRecord.setLastTeamUpdatedTimestamp(currentTime);
			ctpRecord.setLastTeamUpdatedUserFullname("API, Retrieve");
			ctpRecord.setLastIpdatedUsername("Retrieve API");
			ctpRecord.setLastUpdatedUserFullname("API, Retrieve");
			ctpRecord.setStatusUpdatedTimestamp(currentTime);
			ctpRecord.setStatusUpdatedUserFullName("API, Retrieve");
			ctpRecord.setStatusUpdatedUserName("Retrieve API");
			ctpRecord.setVendorStatus(orderInfoObj.getVendorStatus());
			
			if (isRecordExists) {
				//Need set status based on vendorStatus
				
				if (orderInfoObj.getVendorStatus().equalsIgnoreCase(KERECIS_COMPLETED_STATUS)) {
					ctpRecord.setRetrieveStatus(RETRIEVE_COMPLETED_STATUS);
				}
			} else {
				if (orderInfoObj.getVendorStatus().equalsIgnoreCase(KERECIS_COMPLETED_STATUS)) {
					ctpRecord.setRetrieveStatus(RETRIEVE_COMPLETED_STATUS);
				} else {
					ctpRecord.setRetrieveStatus(RETRIEVE_NEW_STATUS);
				}
			}

			if (orderInfoObj.getIcd10Codes() != null && !orderInfoObj.getIcd10Codes().isEmpty()) {
				// need to check json
				ObjectMapper objectMapper = new ObjectMapper();
				String icd10String = null;
				try {
					icd10String = objectMapper.writeValueAsString(orderInfoObj.getIcd10Codes());
				} catch (JsonProcessingException e) {
					log.error("Exception occured  while getting primaryInsJson JSON: " + e.getMessage());
				}
				ctpRecord.setIcd10Codes(icd10String);
			} else {
				ctpRecord.setIcd10Codes(null);
			}

			// need to check salesRepManager is sales person

			PrimaryInsuranceMaster primaryInsJson = new PrimaryInsuranceMaster();

			primaryInsJson.setPrimaryInsName(orderInfoObj.getPrimaryInsuranceCompany());
			primaryInsJson.setPrimaryInsPolicyNo(orderInfoObj.getPrimaryInsurancePolicyNo());
			primaryInsJson.setPrimaryInsCompany(orderInfoObj.getPrimaryInsuranceCompany());
			primaryInsJson.setPrimaryInsMac(orderInfoObj.getPrimaryInsuranceMac());
			primaryInsJson.setPrimaryInsDeductible(orderInfoObj.getPrimaryInsuranceDeductible());
			primaryInsJson.setPrimaryInsDeducMet(orderInfoObj.getPrimaryInsuranceDeductibleMet());
			primaryInsJson.setPrimaryInsCopay(orderInfoObj.getPrimaryInsuranceCopay());
			primaryInsJson.setPrimaryInsCoinsurance(orderInfoObj.getPrimaryInsuranceCoInsurance());
			primaryInsJson.setPrimaryInsOOPMax(orderInfoObj.getPrimaryInsuranceOOPMax());
			primaryInsJson.setPrimaryInsOOPMet(orderInfoObj.getPrimaryInsuranceOOPMet());
			primaryInsJson.setPrimaryInsStatus(orderInfoObj.getPrimarInsuranceStatus());
			primaryInsJson.setPrimaryInsPercentCovered(orderInfoObj.getPrimaryInsurancePercentCovered());
			primaryInsJson.setPrimaryInsReasonNotCovered(orderInfoObj.getPrimaryInsuranceReasonNotCovered());
			primaryInsJson.setPrimaryInsReasonNA(orderInfoObj.getPrimaryInsuranceReasonNA());

			ObjectMapper objectMapper1 = new ObjectMapper();

			String primaryString = null;
			try {
				primaryString = objectMapper1.writeValueAsString(primaryInsJson);
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting primaryInsJson JSON: " + e.getMessage());
			}
			ctpRecord.setPrimaryInsurance(primaryString);

			ctpRecord.setPrimaryInsuranceCompany(orderInfoObj.getPrimaryInsuranceCompany());

			SecondaryInsuranceMaster secondaryInsJson = new SecondaryInsuranceMaster();
			secondaryInsJson.setSecondaryInsName(orderInfoObj.getSecondaryInsuranceCompany());
			secondaryInsJson.setSecondaryInsPolicyNo(orderInfoObj.getSecondaryInsurancePolicyNo());
			secondaryInsJson.setSecondaryInsCompany(orderInfoObj.getSecondaryInsuranceCompany());
			secondaryInsJson.setSecondaryInsMac(orderInfoObj.getSecondaryInsuranceMac());
			secondaryInsJson.setSecondaryInsDeductible(orderInfoObj.getSecondaryInsuranceDeductible());
			secondaryInsJson.setSecondaryInsDeducMet(orderInfoObj.getSecondaryInsuranceDeductibleMet());
			secondaryInsJson.setSecondaryInsCopay(orderInfoObj.getSecondaryInsuranceCopay());
			secondaryInsJson.setSecondaryInsCoinsurance(orderInfoObj.getSecondaryInsuranceCoInsurance());
			secondaryInsJson.setSecondaryInsOOPMax(orderInfoObj.getSecondaryInsuranceOOPMax());
			secondaryInsJson.setSecondaryInsOOPMet(orderInfoObj.getSecondaryInsuranceOOPMet());
			secondaryInsJson.setSecondaryInsStatus(orderInfoObj.getSecondaryInsuranceStatus());
			secondaryInsJson.setSecondaryInsPercentCovered(orderInfoObj.getSecondaryInsurancePercentCovered());
			secondaryInsJson.setSecondaryInsReasonNotCovered(orderInfoObj.getSecondaryInsuranceReasonNotCovered());
			secondaryInsJson.setSecondaryInsReasonNA(orderInfoObj.getSecondaryInsuranceReasonNA());

			ObjectMapper objectMapper2 = new ObjectMapper();

			String secondaryString = null;
			try {
				secondaryString = objectMapper2.writeValueAsString(secondaryInsJson);
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting secondaryInsJson JSON: " + e.getMessage());
			}
			ctpRecord.setSencondaryInsurance(secondaryString);

			TertiaryInsuranceMaster tertiaryInsJson = new TertiaryInsuranceMaster();
			tertiaryInsJson.setTertiaryInsName(orderInfoObj.getTertiaryInsuranceCompany());
			tertiaryInsJson.setTertiaryInsPolicyNo(orderInfoObj.getTertiaryInsurancePolicyNo());
			tertiaryInsJson.setTertiaryInsCompany(orderInfoObj.getTertiaryInsuranceCompany());
			tertiaryInsJson.setTertiaryInsMac(orderInfoObj.getTertiaryInsuranceMac());
			tertiaryInsJson.setTertiaryInsDeductible(orderInfoObj.getTertiaryInsuranceDeductible());
			tertiaryInsJson.setTertiaryInsDeducMet(orderInfoObj.getTertiaryInsuranceDeductibleMet());
			tertiaryInsJson.setTertiaryInsCopay(orderInfoObj.getTertiaryInsuranceCopay());
			tertiaryInsJson.setTertiaryInsCoinsurance(orderInfoObj.getTertiaryInsuranceCoInsurance());
			tertiaryInsJson.setTertiaryInsOOPMax(orderInfoObj.getTertiaryInsuranceOOPMax());
			tertiaryInsJson.setTertiaryInsOOPMet(orderInfoObj.getTertiaryInsuranceOOPMet());
			tertiaryInsJson.setTertiaryInsStatus(orderInfoObj.getTertiaryInsuranceStatus());
			tertiaryInsJson.setTertiaryInsPercentCovered(orderInfoObj.getTertiaryInsurancePercentCovered());
			tertiaryInsJson.setTertiaryInsReasonNotCovered(orderInfoObj.getTertiaryInsuranceReasonNotCovered());
			tertiaryInsJson.setTertiaryInsReasonNA(orderInfoObj.getTertiaryInsuranceReasonNA());

			ObjectMapper objectMapper3 = new ObjectMapper();

			String tertiaryString = null;
			try {
				tertiaryString = objectMapper3.writeValueAsString(tertiaryInsJson);
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting tertiaryInsJson JSON: " + e.getMessage());
			}
			ctpRecord.setTertiaryInsurance(tertiaryString);

			log.debug("Saving ctpRecord : " + ctpRecord);
			
			if (isRecordExists) {
				session.update(ctpRecord);
			} else {
				session.save(ctpRecord);
			}
			
			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", vendorRequestId);
			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(vendorRequestId);
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(orderInfoObj.getVendorStatus());
			vendorStatus.setCoverageSummary(orderInfoObj.getCoverageSummary());
			historyTimeline.setVendorStatus(vendorStatus);

			HistoryUserNotes userNotesObj = new HistoryUserNotes();
			
			if (isRecordExists) {
				if (orderInfoObj.getVendorStatus().equalsIgnoreCase(KERECIS_COMPLETED_STATUS)) {
					historyTimeline.setRetrieveStatus(RETRIEVE_COMPLETED_STATUS);
					userNotesObj.setDescription(COMPLETED_STATUS_TEXT);
				} else {
					historyTimeline.setRetrieveStatus(ctpRecord.getRetrieveStatus());
				}
			} else {
				if (orderInfoObj.getVendorStatus().equalsIgnoreCase(KERECIS_COMPLETED_STATUS)) {
					historyTimeline.setRetrieveStatus(RETRIEVE_COMPLETED_STATUS);
					userNotesObj.setDescription(COMPLETED_STATUS_TEXT);
				} else {
					historyTimeline.setRetrieveStatus(RETRIEVE_NEW_STATUS);
					userNotesObj.setDescription(NEW_STATUS_TEXT);
				}
			}

			historyTimeline.setUserNotes(userNotesObj);

			log.debug("Creating History timeline:  {}", historyTimeline);
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			log.debug("Created History timeline");

			// Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
			docReqTimeline.setRequestId(vendorRequestId);
			docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline.setLastUpdatedUserId(0L);
			docReqTimeline.setLastUpdatedUsername("Retrieve API");
			
			if (isRecordExists) {
				docReqTimeline.setRetrieveStatus(ctpRecord.getRetrieveStatus());
			} else {
				docReqTimeline.setRetrieveStatus("New");
			}

			VendorStatus vendorStatus1 = new VendorStatus();
			vendorStatus1.setCurrentStatus(orderInfoObj.getVendorStatus());
			vendorStatus1.setCoverageSummary(orderInfoObj.getCoverageSummary());

			List<String> reqDocs = new ArrayList<>();

			if (requestDocs.getDocuments() != null && !requestDocs.getDocuments().isEmpty()) {
				for (EDocument eDoc : requestDocs.getDocuments()) {
					reqDocs.add(eDoc.getDocumentType());
				}
				vendorStatus1.setRequestedDocs(reqDocs);
			}
			docReqTimeline.setVendorStatus(vendorStatus1);

			HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
			userNotesObj1.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline.setUserNotes(userNotesObj1);

			log.debug("Creating History timeline:  {}", docReqTimeline);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
			log.debug("Created History timeline");

		} catch (Exception e) {
			log.error("Exception occured while Updating OrderInfo in CTP_Dashboard Record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}

	}

	@Override
	public UpdateAssignedToRes updatedAssigneedTo(MasterCTPDashboardReq req, List<CTPData> records)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		UpdateAssignedToRes res = new UpdateAssignedToRes();
		try {

			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			if (req.getBatchAssigneeFullName() != null && !req.getBatchAssigneeFullName().isEmpty()) {

				for (CTPData record : records) {
					if (!record.getRetrieveStatus().equalsIgnoreCase("Submitted")
							&& !record.getRetrieveStatus().equalsIgnoreCase("Closed")
							&& !record.getRetrieveStatus().equalsIgnoreCase("Completed")) {

						String assignedToHql = "UPDATE CTPDashboard SET lastUpdatedUserId = :lastUpdatedUserId, "
								+ " lastUpdatedUserFullname = :lastUpdatedUserFullName, "
								+ " lastIpdatedUsername = :lastUpdatedUsername, "
								+ " lastUpdatedTimestamp = :lastUpdatedDateTime, "
								//+ " lastTeamUpdatedUserFullname = :lastTeamUpdatedUserFullname, "
								//+ " lastTeamUpdatedTimestamp = :lastTeamUpdated, "
								+ " assigneeUsername = :assignee, "
								+ " assigneeFullname = :assigneeFullName, "
								+ " lastActioned = :lastActioned "
								+ " WHERE orderId = :orderId ";

						// Saving details
						session.createQuery(assignedToHql).setParameter("lastUpdatedUserId", req.getLastUpdatedUserId())
								.setParameter("lastUpdatedUserFullName", req.getLastUpdatedUserFullName())
								.setParameter("lastUpdatedUsername", req.getLastUpdatedUserName())
								//.setParameter("lastTeamUpdatedUserFullname", req.getLastUpdatedUserFullName())
								//.setParameter("lastTeamUpdated", currentTime)
								.setParameter("lastActioned", currentTime)
								.setParameter("lastUpdatedDateTime", currentTime)
								.setParameter("assignee", req.getBatchAssigneeUserName())
								.setParameter("assigneeFullName", req.getBatchAssigneeFullName())
								.setParameter("orderId", record.getOrderId()).executeUpdate();

						log.debug("Updating documentation history table.............");

						// Make entry in History timeline
						Integer historyId = historyTimelineDAO.getHistoryId();
						log.debug("historyId: {}", historyId);

						MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
						historyTimeline.setRequestId(record.getOrderId() + "");
						historyTimeline.setHistoryId(historyId + 1);
						historyTimeline.setBluebookId(record.getBbc());
						historyTimeline.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
						historyTimeline.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
						historyTimeline.setLastUpdatedUsername(req.getLastUpdatedUserName());
						historyTimeline
								.setPatientName(record.getPatientLastName() + ", " + record.getPatientFirstName());
						historyTimeline.setAssignedTo(req.getBatchAssigneeFullName());
						historyTimeline.setRetrieveStatus(record.getRetrieveStatus());
						String[] nameStrings = req.getBatchAssigneeFullName().split(", ");

						VendorStatus vendorStatus = new VendorStatus();
						vendorStatus.setCurrentStatus(record.getCurrentStatus());
						historyTimeline.setVendorStatus(vendorStatus);

						HistoryUserNotes userNotesObj = new HistoryUserNotes();
						userNotesObj.setDescription("Reassigned to " + nameStrings[1] + " " + nameStrings[0]);

						historyTimeline.setUserNotes(userNotesObj);

						log.debug("historyTimeline: {}", historyTimeline);
						historyTimelineDAO.saveHistoryTimeline(historyTimeline);
					}
				}
				// Saving APp Notifications
				appNotificationDAO.saveBatchAssignedNotifications(records.size(), req);
				// Saving APp Notifications
				// appNotificationBO.saveBatchAssigned(awdData.size(), req);
			}

			res.setResponseCode("0");
			res.setResponseDesc(DAOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while Updating Master batch assigned: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(DAOConstants.FAILED);
			throw new CustomException(e.getMessage());
		}
		return res;
	}
//
	@Override
	public Long getUniformTotalCount(int index, String taskType, String assignee, MasterCTPDashboardReq req,
			Boolean isSuperUser) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long totalCount = 0L;
		HashMap<String, Object> parameters = new HashMap<String, Object>();
		List<Integer> vendorId = SwitchServiceLine(req.getServiceLine());
		try {
			String hql = "SELECT count(*) FROM UniformDashboard a WHERE a.vendorId IN :vendorId";
			parameters.put("vendorId", vendorId);

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.retrieveStatus NOT IN ('Exhausted','Completed','Canceled') ";
			}

			if (!isSuperUser) {
				hql += " AND a.bluebookId NOT IN ('x2 - UAT','x2W360','x-Clin Op Demo') ";
			}

			if (taskType != null && taskType.equalsIgnoreCase("NEW")) {
				hql += " AND a.retrieveStatus ='NEW'";

			} else if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.assigneeUsername ='" + req.getUsername() + "'";
			}

			totalCount = (Long) session.createQuery(hql).setProperties(parameters).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching total Uniform count : {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return totalCount;
	}

	@Override
	public List<UniformDashboard> getUniformRecords(boolean isExcel, MasterCTPDashboardReq req, int index,
			String taskType, String assignee, Boolean isSuperUser) throws CustomException {
		Map<String, Object> parameters = new HashMap<>();
		Session session = this.sessionFactory.getCurrentSession();
		List<UniformDashboard> dashboards = new ArrayList<>();
		List<Integer> vendorId = SwitchServiceLine(req.getServiceLine());
		try {
			String hql = "FROM UniformDashboard a WHERE a.vendorId IN :vendorId";
			parameters.put("vendorId", vendorId);

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.retrieveStatus NOT IN ('Exhausted','Completed','Canceled') ";
			}

			if (!isSuperUser) {
				hql += " AND a.bluebookId NOT IN ('x2 - UAT','x2W360','x-Clin Op Demo') ";
			}

			if (taskType != null && taskType.equalsIgnoreCase("NEW")) {
				hql += " AND a.retrieveStatus ='NEW'";

			} else if (taskType != null && taskType.equalsIgnoreCase("MY")) {
				hql += " AND a.assigneeUsername ='" + req.getUsername() + "'";
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
				hql = sortUniformList(req, hql);
			} else {
				hql += " order by a.receivedDate asc";
			}

			log.info("query : {}", hql.toString());
			if (isExcel) {
				dashboards = session.createQuery(hql, UniformDashboard.class).list();
			} else {
				dashboards = session.createQuery(hql, UniformDashboard.class).setFirstResult(index)
						.setProperties(parameters).setMaxResults(PAGE_SIZE).list();
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching all Uniform records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return dashboards;

	}

	private String sortUniformList(MasterCTPDashboardReq req, String hql) {
		String sortBy = "";
		if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {
			sortBy = getFilterUniformColumnName(req.getSortBy());
		}
		hql += " ORDER BY " + sortBy + "";
		if (req.getOrder() == 0) {
			hql += " DESC";
		} else {
			hql += " ASC";
		}
		if (req.getSortBy().equalsIgnoreCase("patientName")) {
			hql += ", patientFirstName ASC ";
		}
		return hql;
	}

	private String getFilterUniformColumnName(String sortBy) {
		String column = "";
		switch (sortBy) {

		case "requestId":
			column = "requestId";
			break;
		case "bbc":
			column = "bluebookId";
			break;
		case "vendorOrderNo":
			column = "vendorOrderNo";
			break;
		case "vendor":
			column = "vendorName";
			break;
		case "patientName":
			column = "patientLastName";
			break;
		case "patientDOB":
			column = "patientDOB";
			break;
		case "bhcOrderSource":
			column = "orderSource";
			break;
		case "responseDate":
			column = "responseDate";
			break;
		case "followupDate":
			column = "followupDate";
			break;
		case "vendorOrderDate":
			column = "vendorOrderDate";
			break;
		case "lastTeamUpdated":
			column = "lastTeamUpdatedTimestamp";
			break;
		case "iHealConfiguration":
			column = "ihealConfig";
			break;
		case "assignedTo":
			column = "assignedTo";
			break;
		case "retrieveStatus":
			column = "retrieveStatus";
			break;
		case "vendorStatus":
			column = "vendorStatus";
			break;
		case "age":
			column = "receivedDate";
			break;
		case "insurance":
			column = "primaryInsurance";
			break;
		case "primaryInsuranceCompany":
			column = "primaryInsuranceCompany";
			break;
		default:
			break;
		}
		return column;
	}

	@Override
	public CTPFilterOptions getUniformFilterOptions(MasterCTPDashboardReq req, Boolean isSuperUser, String serviceLine)
			throws CustomException {
	
		Session session = this.sessionFactory.getCurrentSession();
		CTPFilterOptions filterOptions = new CTPFilterOptions();
		List<Integer> vendorId= SwitchServiceLine(req.getServiceLine());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		try {
			// Fetching user facilities from DB
			List<UserFacilities> facilities = dashboardDAO.getUserFacilities(req.getUserId(), req.getUsername());

			List<String> userBBC = new ArrayList<>();

			if (facilities != null && !facilities.isEmpty()) {
				for (UserFacilities fac : facilities) {
					if (!isSuperUser) {
						if (!fac.getFacilityId().equalsIgnoreCase("2636")
								&& !fac.getFacilityId().equalsIgnoreCase("3196")) {
							userBBC.add(fac.getFacilityBluebookId().toLowerCase());
						}
					} else {
						userBBC.add(fac.getFacilityBluebookId().toLowerCase());
					}

				}
			}
			if (userBBC.isEmpty()) {
				userBBC.add("Test");
			}

			String query = " WHERE vendorId IN :vendorId AND lower(bluebookId) IN :userBBC ";
			

			if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {
				query += " AND assigneeUsername ='" + req.getUsername() + "'";

			}

			Map<String, Object> parameters = new HashMap<>();
			parameters.put("vendorId", vendorId);
			
			// set all filters in where clause
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					query += " AND ";
					String filterCol = getFilterUniformColumnName(filterReq);
					switch (filterCol) {
					case "bluebookId": {
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						query += " bluebookId IN :bluebookId ";
						parameters.put("bluebookId", bbcList);
					}
						break;
					case "vendorName": {
						List<String> vendorList = FilterRequestUtil.getListFromDelimitedStr(req.getVendor());
						query += " vendorName IN :vendorName ";
						parameters.put("vendorName", vendorList);
					}
						break;
					case "vendorOrderNo": {
						List<String> vendorList = FilterRequestUtil.getListFromDelimitedStr(req.getVendorOrderNo());
						query += " vendorOrderNo IN :vendorOrderNo ";
						parameters.put("vendorOrderNo", vendorList);
					}
						break;

					case "requestId": {
						List<String> orderIdList = FilterRequestUtil.getListFromDelimitedStr(req.getRequestId());
						query += " requestId IN :requestId ";
						parameters.put("requestId", orderIdList);
					}
						break;

					case "receivedDate": {
						query += " receivedDate BETWEEN :receivedStartDate AND :receivedEndDate ";
						parameters.put("receivedStartDate", dateFormat.parse(req.getFirstReceivedStartDate()));
						parameters.put("receivedEndDate", dateFormat.parse(req.getFirstReceivedEndDate()));
					}
						break;

					case "patientLastName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());

						String[] patientArr = null;
						List<String> patientFirstNames = new ArrayList<>();
						List<String> patientLastNames = new ArrayList<>();

						for (String patient : patientNameList) {
							patientArr = patient.split(", ");

							if (patientArr.length >= 2) {
								patientLastNames.add(patientArr[0].trim());
								patientFirstNames.add(patientArr[1].trim());
							}
						}

						query += " patientLastName IN :patientLastNames  AND patientFirstName IN :patientFirstNames";
						parameters.put("patientLastNames", patientLastNames);
						parameters.put("patientFirstNames", patientFirstNames);
					}
						break;

					case "assignedTo": {
						// if (!req.getTaskType().equalsIgnoreCase("MY")) {
						List<String> assignedToList = FilterRequestUtil.getListFromDelimitedStr(req.getAssignedTo());
						query += " assignedTo IN :assignedTo ";
						parameters.put("assignedTo", assignedToList);
						// }
					}
						break;

					case "lastTeamUpdatedTimestamp": {
						if (req.isCustomDates()) {
							log.debug("isCustomDate should be true : {}", req.isCustomDates());
							query += " lastTeamUpdatedTimestamp BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate ";
							log.debug("lastTeamUpdatedTimestamp:  " + query);
							parameters.put("lastTeamUpdatedStartDate",
									dateFormat.parse(req.getLastTeamUpdatedStartDate()));
							parameters.put("lastTeamUpdatedEndDate", dateFormat.parse(req.getLastTeamUpdatedEndDate()));

						} else {
							log.debug("isCustomDate should be false : {}", req.isCustomDates());
							String[] dateFilter = req.getDateFilters().split("#");
							boolean firstFilter = true;
							for (String filter : dateFilter) {
								if (firstFilter) {
									firstFilter = false;
								} else {
									query += " OR ";
								}

								if (filter.equalsIgnoreCase("today") && req.getTodayMinDate() != null
										&& !req.getTodayMinDate().isEmpty() && req.getTodayMaxDate() != null
										&& !req.getTodayMaxDate().isEmpty()) {
									query += " (lastTeamUpdatedTimestamp >= :todayMinDate AND lastTeamUpdatedTimestamp <= :todayMaxDate )";
									parameters.put("todayMinDate", dateFormat.parse(req.getTodayMinDate()));
									parameters.put("todayMaxDate", dateFormat.parse(req.getTodayMaxDate()));
								}
								if (filter.equalsIgnoreCase("yesterday") && req.getYesterdayMinDate() != null
										&& !req.getYesterdayMinDate().isEmpty() && req.getYesterdayMaxDate() != null
										&& !req.getYesterdayMaxDate().isEmpty()) {
									query += " (lastTeamUpdatedTimestamp >= :yesterdayMinDate AND lastTeamUpdatedTimestamp <= :yesterdayMaxDate)";
									parameters.put("yesterdayMinDate", dateFormat.parse(req.getYesterdayMinDate()));
									parameters.put("yesterdayMaxDate", dateFormat.parse(req.getYesterdayMaxDate()));
								}
								if (filter.equalsIgnoreCase("thisWeek") && req.getThisWeekMinDate() != null
										&& !req.getThisWeekMinDate().isEmpty() && req.getThisWeekMaxDate() != null
										&& !req.getThisWeekMaxDate().isEmpty()) {
									query += " (lastTeamUpdatedTimestamp >= :thisWeekMinDate AND lastTeamUpdatedTimestamp <= :thisWeekMaxDate)";
									parameters.put("thisWeekMinDate", dateFormat.parse(req.getThisWeekMinDate()));
									parameters.put("thisWeekMaxDate", dateFormat.parse(req.getThisWeekMaxDate()));
								}
								if (filter.equalsIgnoreCase("lastWeek") && req.getLastWeekMinDate() != null
										&& !req.getLastWeekMinDate().isEmpty() && req.getLastWeekMaxDate() != null
										&& !req.getLastWeekMaxDate().isEmpty()) {
									query += " (lastTeamUpdatedTimestamp >= :lastWeekMinDate AND lastTeamUpdatedTimestamp <= :lastWeekMaxDate)";
									parameters.put("lastWeekMinDate", dateFormat.parse(req.getLastWeekMinDate()));
									parameters.put("lastWeekMaxDate", dateFormat.parse(req.getLastWeekMaxDate()));
								}

							}
							log.debug("lastTeamUpdatedTimestamp:  {} ", query);
						}

					}
						break;

					case "orderSource": {
						List<String> orderSourceList = FilterRequestUtil
								.getListFromDelimitedStr(req.getBhcOrderSource());
						query += " orderSource IN :orderSource ";
						parameters.put("orderSource", orderSourceList);
					}
						break;

					case "ihealConfig": {
						List<String> facTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getiHealConfiguration());
						query += " ihealConfig IN :ihealConfig ";
						parameters.put("ihealConfig", facTypeList);
					}
						break;

					case "retrieveStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getRetrieveStatus());
						query += " retrieveStatus IN :retrieveStatus ";
						parameters.put("retrieveStatus", statusList);
					}
						break;

					case "vendorStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getVendorStatus());

						log.debug("statusList : " + statusList);

						query += " vendorStatus IN :vendorStatus ";

						List<String> updatedList = new ArrayList<>();
						if (statusList != null && !statusList.isEmpty()) {
							for (String status : statusList) {
								updatedList.add(getSolventumStatus(5, status));
							}
						}

						log.debug("updatedList : " + updatedList);

						parameters.put("vendorStatus", updatedList);
					}
						break;

					case "followupDate": {
						query += " followupDate BETWEEN :followupStartDate AND :followupEndDate ";
						parameters.put("followupStartDate", dateFormat.parse(req.getFollowupStartDate()));
						parameters.put("followupEndDate", dateFormat.parse(req.getFollowupEndDate()));
					}
						break;

					case "vendorOrderDate": {
						query += " vendorOrderDate BETWEEN :vendorStartDate AND :vendorEndDate ";
						parameters.put("vendorStartDate", dateFormat.parse(req.getVendorOrderStartDate()));
						parameters.put("vendorEndDate", dateFormat.parse(req.getVendorOrderEndDate()));
					}
						break;

					case "responseDate": {
						log.debug("ResponseStartDate: {}", req.getResponseStartDate());
						log.debug("ResponseEndDate: {}", req.getResponseEndDate());
						query += " responseDate BETWEEN :responseStartDate AND :responseEndDate ";
						parameters.put("responseStartDate", dateFormat.parse(req.getResponseStartDate()));
						parameters.put("responseEndDate", dateFormat.parse(req.getResponseEndDate()));
					}
						break;

					case "patientDOB": {
						query += " a.patientDOB = :patientDOB";
						parameters.put("patientDOB", CommonUtils.formatStringToDate(req.getPatientDOB()));
					}
						break;

					case "primaryInsurance": {
						List<String> insList = FilterRequestUtil.getListFromDelimitedStr(req.getInsurance());
						query += " primaryInsurance IN :primaryIns ";
						parameters.put("primaryIns", insList);
					}
						break;

					default:
						break;
					}
				}
			}

			log.debug("query :  {}", query);
			log.debug("parameters:   {}", parameters);

			String hql = "";
			String filterColumn = "";
			if (req.getFilterOptions() != null && !req.getFilterOptions().isEmpty()) {
				filterColumn = getFilterUniformColumnName(req.getFilterOptions());
			}

			log.debug("filterColumn:  " + filterColumn);

			if (filterColumn.equalsIgnoreCase("receivedDate")) {

				String dateHql = "SELECT MIN(receivedDate)," + " MAX(receivedDate) FROM UniformDashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);

				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinFirstReceivedDate((Timestamp) object[0]);
				filterOptions.setMaxFirstReceivedDate((Timestamp) object[1]);

			} else if (filterColumn.equalsIgnoreCase("patientLastName")) {
				hql = "SELECT DISTINCT CONCAT(patientLastName,', ',patientFirstName) FROM UniformDashboard " + query
						+ " ORDER BY patientLastName asc, patientFirstName asc";
				List<String> distinctValues = session.createQuery(hql, String.class).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions().removeIf(element -> element == null);

			} else if (filterColumn.equalsIgnoreCase("lastTeamUpdatedTimestamp")) {
				String dateHql = "SELECT MIN(lastTeamUpdatedTimestamp), MAX(lastTeamUpdatedTimestamp) FROM UniformDashboard "
						+ query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinLastTeamUpdatedDate((Timestamp) object[0]);
				filterOptions.setMaxLastTeamUpdatedDate((Timestamp) object[1]);

			} else if (filterColumn.equalsIgnoreCase("followupDate")) {
				String dateHql = "SELECT MIN(followupDate), MAX(followupDate) FROM UniformDashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinFollowupDate((Date) object[0]);
				filterOptions.setMaxFollowupDate((Date) object[1]);
			} else if (filterColumn.equalsIgnoreCase("responseDate")) {
				String dateHql = "SELECT MIN(responseDate), MAX(responseDate) FROM UniformDashboard " + query + "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinResponseDate((Date) object[0]);
				filterOptions.setMaxResponseDate((Date) object[1]);
			} else if (filterColumn.equalsIgnoreCase("vendorOrderDate")) {
				String dateHql = "SELECT MIN(vendorOrderDate), MAX(vendorOrderDate) FROM UniformDashboard " + query
						+ "";
				log.debug("dateHql:  {}", dateHql);
				Object[] object = (Object[]) session.createQuery(dateHql).setParameter("userBBC", userBBC)
						.setProperties(parameters).uniqueResult();

				filterOptions.setMinVendorOrderDate((Date) object[0]);
				filterOptions.setMaxVendorOrderDate((Date) object[1]);
			} else {
				hql = "SELECT DISTINCT " + filterColumn + " FROM UniformDashboard " + query + " ORDER BY "
						+ filterColumn + " asc";

				List<String> distinctValues = session.createQuery(hql, String.class).setParameter("userBBC", userBBC)
						.setProperties(parameters).getResultList();
				filterOptions.setOptions(distinctValues);
				filterOptions.getOptions()
						.removeIf(element -> element == null || (element != null && element.isEmpty()));
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Uniform Dashboard filter options : {}", e.getMessage());
			e.printStackTrace();
			throw new CustomException(e.getMessage());
		}
		return filterOptions;

	}

	@Override
	public Map<String, Object> getFilteredUniformList(boolean isExcel, MasterCTPDashboardReq req, int index,
			String taskType, String assignee, Boolean isSuperUser) throws CustomException {

		Session session = this.sessionFactory.getCurrentSession();
		List<UniformDashboard> ctpDashboard = new ArrayList<>();
		List<UniformDashboard> allCTPList = new ArrayList<>();
		Map<String, Object> parameters = new HashMap<>();
		Map<String, Object> listCount = new HashMap<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		List<Integer> vendorId = SwitchServiceLine(req.getServiceLine());
		try {
			String hql = "FROM UniformDashboard a WHERE a.vendorId IN :vendorId";
			parameters.put("vendorId", vendorId);

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				hql += "";
			} else {
				hql += " AND a.retrieveStatus NOT IN ('Exhausted','Completed','Canceled') ";
			}

			if (!isSuperUser) {
				hql += " AND a.bluebookId NOT IN ('x2 - UAT','x2W360','x-Clin Op Demo','X2 - UAT') ";
			}

			if (req.getTaskType() != null && req.getTaskType().equalsIgnoreCase("MY")) {

				hql += " AND a.assigneeUsername ='" + req.getUsername() + "'";
			}

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {

				List<String> filterList = FilterRequestUtil.getListFromDelimitedStr(req.getFilters());

				for (String filterReq : filterList) {

					hql += " AND ";
					String filterCol = getFilterUniformColumnName(filterReq);
					switch (filterCol) {
					case "bluebookId": {
						List<String> bbcList = FilterRequestUtil.getListFromDelimitedStr(req.getBbc());
						hql += " a.bluebookId IN :bluebookId ";
						parameters.put("bluebookId", bbcList);
					}
						break;
					case "vendorName": {
						List<String> vendorList = FilterRequestUtil.getListFromDelimitedStr(req.getVendor());
						hql += " a.vendorName IN :vendorName ";
						parameters.put("vendorName", vendorList);
					}
						break;
					case "vendorOrderNo": {
						List<String> vendorList = FilterRequestUtil.getListFromDelimitedStr(req.getVendorOrderNo());
						hql += " a.vendorOrderNo IN :vendorOrderNo ";
						parameters.put("vendorOrderNo", vendorList);
					}
						break;

					case "requestId": {
						List<String> orderIdList = FilterRequestUtil.getListFromDelimitedStr(req.getRequestId());
						hql += " a.requestId IN :requestId ";
						parameters.put("requestId", orderIdList);
					}
						break;

					case "receivedDate": {
						hql += " a.receivedDate BETWEEN :receivedStartDate AND :receivedEndDate ";
						parameters.put("receivedStartDate", dateFormat.parse(req.getFirstReceivedStartDate()));
						parameters.put("receivedEndDate", dateFormat.parse(req.getFirstReceivedEndDate()));
					}
						break;

					case "patientDOB": {
						hql += " a.patientDOB = :patientDOB";
						parameters.put("patientDOB", CommonUtils.formatStringToDate(req.getPatientDOB()));
					}
						break;

					case "patientLastName": {
						List<String> patientNameList = FilterRequestUtil.getListFromDelimitedStr(req.getPatientName());

						String[] patientArr = null;
						List<String> patientFirstNames = new ArrayList<>();
						List<String> patientLastNames = new ArrayList<>();

						for (String patient : patientNameList) {
							patientArr = patient.split(", ");

							if (patientArr.length >= 2) {
								patientLastNames.add(patientArr[0].trim());
								patientFirstNames.add(patientArr[1].trim());
							}
						}

						hql += " a.patientLastName IN :patientLastNames  AND a.patientFirstName IN :patientFirstNames";
						parameters.put("patientLastNames", patientLastNames);
						parameters.put("patientFirstNames", patientFirstNames);
					}
						break;

					case "assignedTo": {
						// if (!req.getTaskType().equalsIgnoreCase("MY")) {
						List<String> assignedToList = FilterRequestUtil.getListFromDelimitedStr(req.getAssignedTo());
						hql += " a.assignedTo IN :assignedTo ";
						parameters.put("assignedTo", assignedToList);
						// }
					}
						break;

					case "lastTeamUpdatedTimestamp": {
						if (req.isCustomDates()) {
							log.debug("isCustomDate should be true : {}", req.isCustomDates());
							hql += " a.lastTeamUpdatedTimestamp BETWEEN :lastTeamUpdatedStartDate AND :lastTeamUpdatedEndDate ";
							log.debug("lastTeamUpdatedTimestamp:  " + hql);
							parameters.put("lastTeamUpdatedStartDate",
									dateFormat.parse(req.getLastTeamUpdatedStartDate()));
							parameters.put("lastTeamUpdatedEndDate", dateFormat.parse(req.getLastTeamUpdatedEndDate()));

						} else {
							log.debug("isCustomDate should be false : {}", req.isCustomDates());
							String[] dateFilter = req.getDateFilters().split("#");
							boolean firstFilter = true;
							for (String filter : dateFilter) {
								if (firstFilter) {
									firstFilter = false;
								} else {
									hql += " OR ";
								}

								if (filter.equalsIgnoreCase("today") && req.getTodayMinDate() != null
										&& !req.getTodayMinDate().isEmpty() && req.getTodayMaxDate() != null
										&& !req.getTodayMaxDate().isEmpty()) {
									hql += " (a.lastTeamUpdatedTimestamp >= :todayMinDate AND a.lastTeamUpdatedTimestamp <= :todayMaxDate )";
									parameters.put("todayMinDate", dateFormat.parse(req.getTodayMinDate()));
									parameters.put("todayMaxDate", dateFormat.parse(req.getTodayMaxDate()));
								}
								if (filter.equalsIgnoreCase("yesterday") && req.getYesterdayMinDate() != null
										&& !req.getYesterdayMinDate().isEmpty() && req.getYesterdayMaxDate() != null
										&& !req.getYesterdayMaxDate().isEmpty()) {
									hql += " (a.lastTeamUpdatedTimestamp >= :yesterdayMinDate AND a.lastTeamUpdatedTimestamp <= :yesterdayMaxDate)";
									parameters.put("yesterdayMinDate", dateFormat.parse(req.getYesterdayMinDate()));
									parameters.put("yesterdayMaxDate", dateFormat.parse(req.getYesterdayMaxDate()));
								}
								if (filter.equalsIgnoreCase("thisWeek") && req.getThisWeekMinDate() != null
										&& !req.getThisWeekMinDate().isEmpty() && req.getThisWeekMaxDate() != null
										&& !req.getThisWeekMaxDate().isEmpty()) {
									hql += " (a.lastTeamUpdatedTimestamp >= :thisWeekMinDate AND a.lastTeamUpdatedTimestamp <= :thisWeekMaxDate)";
									parameters.put("thisWeekMinDate", dateFormat.parse(req.getThisWeekMinDate()));
									parameters.put("thisWeekMaxDate", dateFormat.parse(req.getThisWeekMaxDate()));
								}
								if (filter.equalsIgnoreCase("lastWeek") && req.getLastWeekMinDate() != null
										&& !req.getLastWeekMinDate().isEmpty() && req.getLastWeekMaxDate() != null
										&& !req.getLastWeekMaxDate().isEmpty()) {
									hql += " (a.lastTeamUpdatedTimestamp >= :lastWeekMinDate AND a.lastTeamUpdatedTimestamp <= :lastWeekMaxDate)";
									parameters.put("lastWeekMinDate", dateFormat.parse(req.getLastWeekMinDate()));
									parameters.put("lastWeekMaxDate", dateFormat.parse(req.getLastWeekMaxDate()));
								}

							}
							log.debug("lastTeamUpdatedTimestamp:  {} ", hql);
						}

					}
						break;

					case "orderSource": {
						List<String> orderSourceList = FilterRequestUtil
								.getListFromDelimitedStr(req.getBhcOrderSource());
						hql += " a.orderSource IN :orderSource ";
						parameters.put("orderSource", orderSourceList);
					}
						break;

					case "ihealConfig": {
						List<String> facTypeList = FilterRequestUtil
								.getListFromDelimitedStr(req.getiHealConfiguration());
						hql += " a.ihealConfig IN :ihealConfig ";
						parameters.put("ihealConfig", facTypeList);
					}
						break;

					case "retrieveStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getRetrieveStatus());
						hql += " a.retrieveStatus IN :retrieveStatus ";
						parameters.put("retrieveStatus", statusList);
					}
						break;

					case "vendorStatus": {
						List<String> statusList = FilterRequestUtil.getListFromDelimitedStr(req.getVendorStatus());

						log.debug("statusList : " + statusList);

						List<String> updatedList = new ArrayList<>();
						if (statusList != null && !statusList.isEmpty()) {
							for (String status : statusList) {
								updatedList.add(getSolventumStatus(5, status));
							}
						}

						log.debug("updatedList : " + updatedList);

						hql += " a.vendorStatus IN :vendorStatus ";
						parameters.put("vendorStatus", updatedList);
					}
						break;

					case "followupDate": {
						hql += " a.followupDate BETWEEN :followupStartDate AND :followupEndDate ";
						parameters.put("followupStartDate", dateFormat.parse(req.getFollowupStartDate()));
						parameters.put("followupEndDate", dateFormat.parse(req.getFollowupEndDate()));
					}
						break;

					case "vendorOrderDate": {
						hql += " a.vendorOrderDate BETWEEN :vendorStartDate AND :vendorEndDate ";
						parameters.put("vendorStartDate", dateFormat.parse(req.getVendorOrderStartDate()));
						parameters.put("vendorEndDate", dateFormat.parse(req.getVendorOrderEndDate()));
					}
						break;

					case "responseDate": {
						hql += " a.responseDate BETWEEN :responseStartDate AND :responseEndDate ";
						parameters.put("responseStartDate", dateFormat.parse(req.getResponseStartDate()));
						parameters.put("responseEndDate", dateFormat.parse(req.getResponseEndDate()));
					}
						break;

					case "primaryInsurance": {
						List<String> insList = FilterRequestUtil.getListFromDelimitedStr(req.getInsurance());
						hql += " a.primaryInsurance IN :primaryIns ";
						parameters.put("primaryIns", insList);
					}
						break;

					default:
						break;
					}
				}
			}

			// apply sorting here
			if (req.getSortBy() != null && !req.getSortBy().isEmpty()) {

				hql = sortUniformList(req, hql);

			} else {
				hql += " order by a.receivedDate asc";
			}

			log.info("query : {}", hql);

			if (isExcel) {
				ctpDashboard = session.createQuery(hql).setProperties(parameters).list();
				listCount.put("Count", ctpDashboard.size());
				listCount.put("data", ctpDashboard);
			} else {
				int count;
				ctpDashboard = session.createQuery(hql).setFirstResult(index).setProperties(parameters)
						.setMaxResults(PAGE_SIZE).list();

				allCTPList = session.createQuery(hql).setFirstResult(index).setProperties(parameters).list();
				log.debug("allCTPList....." + allCTPList);
				log.debug("allCTPList.size()....." + allCTPList.size());

				count = allCTPList.size() + index;

				listCount.put("Count", count);
				listCount.put("data", ctpDashboard);
				log.debug("UniformDashboard List Size:   {} ", count);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Filtered Uniform Records: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return listCount;

	}

	public List<Integer> SwitchServiceLine(String Serviceline) {
		List<Integer> vendorId = new ArrayList<>();
		switch (Serviceline) {
		case "NPWT": {
			vendorId.add(5);  //Solventum
			vendorId.add(2);	// Apria
		}
			break;
		case "LYMPHA": {
			vendorId.add(6);
		}
		default:
			break;
		}
		return vendorId;
	}

	@Override
	public PrimaryKeySetup fetchPrimaryKeyByVendorId(int vendorId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		PrimaryKeySetup keySetup = null;
		try {
			String hql = "FROM PrimaryKeySetup WHERE vendorId = :vendorId";

			keySetup = (PrimaryKeySetup) session.createQuery(hql).setParameter("vendorId", vendorId).uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching Primary key by vendor Id: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return keySetup;
	}

	@Override
	public PrimaryKeyLookup primaryKeyLookupByRtrvId(Long retrieveReqId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		PrimaryKeyLookup lookup = null;
		try {
			String hql = "FROM PrimaryKeyLookup WHERE retrieveReqId = :retrieveReqId";

			lookup = (PrimaryKeyLookup) session.createQuery(hql).setParameter("retrieveReqId", retrieveReqId)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching Primary key by Retrieve request Id: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return lookup;
	}

	@Override
	public PrimaryKeyLookup lookupPrimaryKey(RetrievePrimaryKeyMapping mapping,
			int vendorId, String vendorRequestId,
			String vendorStatus) throws CustomException {
		PrimaryKeyLookup primaryKeyLookup = null;
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "FROM PrimaryKeyLookup p WHERE 1 = 1";

			switch (vendorId) {
			case 5: {
				hql += " AND p.primaryKey1 = :vendorRequestId"
						+ " AND p.primaryKey2 = :vendorStatus";

				primaryKeyLookup = (PrimaryKeyLookup) session.createQuery(hql)
						.setParameter("vendorRequestId", vendorRequestId)
						.setParameter("vendorStatus", vendorStatus)
						.uniqueResult();
			}
				break;
			case 101: {
				hql += " AND p.primaryKey1 = :vendorRequestId";

				primaryKeyLookup = (PrimaryKeyLookup) session.createQuery(hql)
						.setParameter("vendorRequestId", vendorRequestId)
						.uniqueResult();
			}
				break;
			case 2: {
				hql += " AND p.primaryKey1 = :vendorRequestId"
						+ " AND p.primaryKey2 = :vendorStatus";

				primaryKeyLookup = (PrimaryKeyLookup) session.createQuery(hql)
						.setParameter("vendorRequestId", vendorRequestId)
						.setParameter("vendorStatus", vendorStatus)
						.uniqueResult();
			}
				break;
				
			case 4: {
				hql += " AND p.primaryKey1 = :vendorRequestId";

				primaryKeyLookup = (PrimaryKeyLookup) session.createQuery(hql)
						.setParameter("vendorRequestId", vendorRequestId)
						.uniqueResult();
			}
				break;

			default:
				break;
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Retrieve request Id: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return primaryKeyLookup;
	}

	@Override
	public Long generateRetrieveReqId(PrimaryKeyLookup lookup) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long retrieveReqId = 0L;
		try {
			session.save(lookup);

			retrieveReqId = lookup.getRetrieveReqId();
		} catch (Exception e) {
			log.error("Exception occured while generate Retrieve request Id: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return retrieveReqId;

	}

	@Override
	public List<NotesAttemptType> getAttemptTypeByServiceline(String serviceLine) throws CustomException {
		List<NotesAttemptType> attemptTypeList = null;
		Session session = this.sessionFactory.getCurrentSession();
		try {
			String hql = "FROM NotesAttemptType where serviceLine = :serviceLine";

			attemptTypeList = (List<NotesAttemptType>) session.createQuery(hql).setParameter("serviceLine", serviceLine)
					.list();

		} catch (Exception e) {
			log.error("Exception occured while getting attemptTypeByServiceline: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return attemptTypeList;
	}
//
	@Override
	public UpdateAssignedToRes updatedAssigneedToRecord(MasterCTPDashboardReq req, List<UniformData> records)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		UpdateAssignedToRes res = new UpdateAssignedToRes();
		try {

			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			if (req.getBatchAssigneeFullName() != null && !req.getBatchAssigneeFullName().isEmpty()) {

				for (UniformData record : records) {
					if (!record.getRetrieveStatus().equalsIgnoreCase("Submitted")
							&& !record.getRetrieveStatus().equalsIgnoreCase("Completed")) {

						String assignedToHql = "UPDATE UniformDashboard SET statusUpdatedUserId = :statusUpdatedUserId, "
								+ " statusUpdatedUserFullname = :statusUpdatedUserFullname, "
								+ " statusUpdatedUsername = :statusUpdatedUsername, "
								+ " statusUpdatedTimestamp = :statusUpdatedTimestamp, "
								//+ " lastTeamUpdatedFullName = :lastTeamUpdatedFullName, "
								//+ " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp, "
								+ " assigneeUsername = :assignee, "
								+ " assignedTo = :assigneeFullName "
								// + " lastActioned = :lastActioned "
								+ " WHERE requestId = :requestId ";
						// Saving details
						session.createQuery(assignedToHql)
								.setParameter("statusUpdatedUserId", req.getLastUpdatedUserId())
								.setParameter("statusUpdatedUserFullname", req.getLastUpdatedUserFullName())
								.setParameter("statusUpdatedUsername", req.getLastUpdatedUserName())
								//.setParameter("lastTeamUpdatedFullName", req.getLastUpdatedUserFullName())
								.setParameter("statusUpdatedTimestamp", currentTime)
								// .setParameter("lastActioned", currentTime)
								//.setParameter("lastTeamUpdatedTimestamp", currentTime)
								.setParameter("assignee", req.getBatchAssigneeUserName())
								.setParameter("assigneeFullName", req.getBatchAssigneeFullName())
								.setParameter("requestId", record.getRequestId()).executeUpdate();

						log.debug("Updating documentation history table.............");

						// Make entry in History timeline
						Integer historyId = historyTimelineDAO.getHistoryId();
						log.debug("historyId: {}", historyId);

						MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
						historyTimeline.setRequestId(record.getRequestId() + "");
						historyTimeline.setHistoryId(historyId + 1);
						historyTimeline.setBluebookId(record.getBbc());
						historyTimeline.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
						historyTimeline.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
						historyTimeline.setLastUpdatedUsername(req.getLastUpdatedUserName());
						// historyTimeline
						// .setPatientName(record.getPatientLastName() + ", " +
						// record.getPatientFirstName());
						historyTimeline.setPatientName(record.getPatientName());
						historyTimeline.setAssignedTo(req.getBatchAssigneeFullName());
						historyTimeline.setRetrieveStatus(record.getRetrieveStatus());
						String[] nameStrings = req.getBatchAssigneeFullName().split(", ");

						VendorStatus vendorStatus = new VendorStatus();
						vendorStatus.setCurrentStatus(record.getCurrentStatus());
						historyTimeline.setVendorStatus(vendorStatus);

						HistoryUserNotes userNotesObj = new HistoryUserNotes();
						userNotesObj.setDescription("Reassigned to " + nameStrings[1] + " " + nameStrings[0]);

						historyTimeline.setUserNotes(userNotesObj);

						log.debug("historyTimeline: {}", historyTimeline);
						historyTimelineDAO.saveHistoryTimeline(historyTimeline);
					}
				}
				// Saving APp Notifications
				appNotificationDAO.saveBatchAssignedNotifications(records.size(), req);
				// Saving APp Notifications
				// appNotificationBO.saveBatchAssigned(awdData.size(), req);
			}

			res.setResponseCode("0");
			res.setResponseDesc(DAOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while Updating Master batch assigned: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(DAOConstants.FAILED);
			throw new CustomException(e.getMessage());
		}
		return res;
	}

	@Override
	public void saveUniformDashboardRow(DocsReq req, String rtrvRequestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		log.debug("Inside saveUniformDashboardRow Docs Req Object: {}", req);
		log.debug("rtrvRequestId : " + rtrvRequestId);
		try {
			String vendorName = "";
			String retrieveStatus = "New";
			
			if (req.getVendorId() == 5) {
				vendorName = "Solventum";
				
			} else if (req.getVendorId() == 2) {
				vendorName = "Apria";

			} else if (req.getVendorId() == 4) {
				vendorName = "Lympha";
				
				if (req.getVendorStatus() != null
						&& !req.getVendorStatus().isEmpty()
						&& req.getVendorStatus().equalsIgnoreCase("ORDER_RECEIVED")) {
					retrieveStatus = "New";
				} else {
					retrieveStatus = "";
				}
			}

			UniformDashboard uniformObj = new UniformDashboard();

			uniformObj.setRequestId(rtrvRequestId);
			uniformObj.setBluebookId(req.getFacilityBBC());
			uniformObj.setVendorOrderNo(req.getVendorRequestId());
			uniformObj.setVendorId(req.getVendorId());
			uniformObj.setVendorName(vendorName);
			uniformObj.setVendorOrderDate(new Date());

			if (req.getPatientId() != null) {
				// Ignore patient id if orderSource as FAX and value is 99999
				if (req.getOrderSource() != null
						&& (req.getOrderSource().equalsIgnoreCase("FAX")
								|| req.getOrderSource().equalsIgnoreCase("TRANSITION"))
						&& req.getPatientId().startsWith("99999")) {
					uniformObj.setPatientId(0L);
				} else {
					uniformObj.setPatientId(Long.valueOf(req.getPatientId()));
				}
			} else {
				uniformObj.setPatientId(0L);
			}

			uniformObj.setPatientFirstName(req.getPatientFirstName());
			uniformObj.setPatientLastName(req.getPatientLastName());
			uniformObj.setProviderFirstName(req.getProviderFirstName());
			uniformObj.setProviderLastName(req.getProviderLastName());
			uniformObj.setMedicalRecordNumber(req.getMedicalRecordNumber());

			if (req.getResponseDate() != null && !req.getResponseDate().isEmpty()) {
				uniformObj.setResponseDate(new SimpleDateFormat("yyyy-MM-dd")
						.parse(req.getResponseDate()));
			} else {
				req.setResponseDate(null);
			}
			uniformObj.setFollowupDate(req.getNeedByDate());
			uniformObj.setOrderSource(req.getOrderSource());

			PrimaryInsuranceMaster primaryInsJson = new PrimaryInsuranceMaster();

			primaryInsJson.setPrimaryInsName(req.getPrimaryInsurance());

			ObjectMapper objectMapper1 = new ObjectMapper();

			String primaryString = null;
			try {
				primaryString = objectMapper1.writeValueAsString(primaryInsJson);
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting primaryInsJson JSON: " + e.getMessage());
			}
			uniformObj.setPrimaryInsurance(primaryString);

			uniformObj.setPrimaryInsurance(req.getPrimaryInsurance());
			uniformObj.setRetrieveStatus(retrieveStatus);
			uniformObj.setVendorStatus(req.getVendorStatus());
			uniformObj.setReceivedDate(new Date());
			uniformObj.setFirstReceived(currentTime);
			uniformObj.setStatusUpdatedTimestamp(currentTime);
			uniformObj.setStatusUpdatedUserFullname("API, Retrieve");
			uniformObj.setStatusUpdatedUserId("0");
			uniformObj.setStatusUpdatedUsername("Retrieve");

			uniformObj.setLastTeamUpdatedFullName("API, Retrieve");
			uniformObj.setLastTeamUpdatedTimestamp(currentTime);

			// Check
			uniformObj.setAge(0);
			uniformObj.setPatientDOB(req.getPatientDOB());
			FacilityDetails facilityDetails = dashboardDAO.getFacilityDetailsForDetailsCTP(
					req.getFacilityId());

			log.debug("Getting FacilityDetails: {}", facilityDetails);

			if (facilityDetails != null) {
				uniformObj.setIhealConfig(facilityDetails.getCurrentFacilityType());
			}

			session.save(uniformObj);

		} catch (Exception e) {
			log.error("Exception occured while Creating Uniform Dashboard Row: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}

	}

	@Override
	public void saveMasterChartDetailsRow(DocsReq req, String rtrvRequestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		log.debug("Inside saveMasterChartDetails Docs Req Object: {}", req);
		log.debug("rtrvRequestId : " + rtrvRequestId);
		try {
			String vendorName = "";
			String retrieveStatus = "New";
			
			if (req.getVendorId() == 5) {
				vendorName = "Solventum";
				
			} else if (req.getVendorId() == 2) {
				vendorName = "Apria";

			} else if (req.getVendorId() == 4) {
				vendorName = "Lympha";
				
				if (req.getVendorStatus() != null
						&& !req.getVendorStatus().isEmpty()
						&& req.getVendorStatus().equalsIgnoreCase("ORDER_RECEIVED")) {
					retrieveStatus = "New";
				} else {
					retrieveStatus = "";
				}
			}

			MasterChartDetails chartObj = new MasterChartDetails();

			chartObj.setOrderId(rtrvRequestId);
			chartObj.setFacilityId(req.getFacilityId());
			chartObj.setBluebookId(req.getFacilityBBC());
			chartObj.setFacilityName(req.getFacilityName());

			// chartObj.setHealogicsPatientId(Integer.parseInt(req.getPatientId()));

			if (req.getPatientId() != null) {
				// Ignore patient id if its 99999 on orderSource as FAX
				log.debug("req.getPatientId().startsWith(99999) :" + req.getPatientId().startsWith("99999"));
				log.debug("orderSource : " + req.getOrderSource());

				if (req.getOrderSource() != null
						&& (req.getOrderSource().equalsIgnoreCase("FAX")
								|| req.getOrderSource().equalsIgnoreCase("TRANSITION"))
						&& req.getPatientId().startsWith("99999")) {
					chartObj.setHealogicsPatientId(0);
				} else {
					chartObj.setHealogicsPatientId(Integer.parseInt(req.getPatientId()));
				}
			} else {
				chartObj.setHealogicsPatientId(0);
			}

			chartObj.setHealogicsPatientMRN(req.getMedicalRecordNumber());
			chartObj.setVendorId(req.getVendorId());
			chartObj.setVendorName(vendorName);
			chartObj.setOrderSource(req.getOrderSource());
			chartObj.setPatientFirstName(req.getPatientFirstName());
			chartObj.setPatientLastName(req.getPatientLastName());
			chartObj.setPatientFullname(req.getPatientLastName()
					+ ", " + req.getPatientFirstName());
			chartObj.setPatientDOB(req.getPatientDOB());
			chartObj.setReceivedDate(new Date());
			chartObj.setVendorStatus(req.getVendorStatus());
			chartObj.setSecondaryStatus(req.getSecondaryStatus());
			chartObj.setRetrieveStatus(retrieveStatus);
			chartObj.setWoundqOrderNo(
					(req.getOrderDisplayNumber() != null)
						? req.getOrderDisplayNumber().toString() : "");
			chartObj.setRentalOrderNo(req.getVendorRequestId());
			chartObj.setVendorReferralNo(req.getVendorReferralNumber());

			chartObj.setFollowupDate(req.getNeedByDate());

			PrimaryInsuranceMaster primaryInsJson = new PrimaryInsuranceMaster();

			primaryInsJson.setPrimaryInsName(req.getPrimaryInsurance());

			ObjectMapper objectMapper1 = new ObjectMapper();

			String primaryString = null;
			try {
				primaryString = objectMapper1.writeValueAsString(primaryInsJson);
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting primaryInsJson JSON: " + e.getMessage());
			}
			chartObj.setPrimaryInsurance(primaryString);

			chartObj.setPrimaryInsuranceCompany(req.getPrimaryInsurance());

			SecondaryInsuranceMaster secondaryInsJson = new SecondaryInsuranceMaster();
			secondaryInsJson.setSecondaryInsName(req.getSecondaryInsurance());

			ObjectMapper objectMapper2 = new ObjectMapper();

			String secondaryString = null;
			try {
				secondaryString = objectMapper2.writeValueAsString(secondaryInsJson);
			} catch (JsonProcessingException e) {
				log.error("Exception occured  while getting secondaryInsJson JSON: " + e.getMessage());
			}
			chartObj.setSencondaryInsurance(secondaryString);
			
			if (req.getProviderFirstName() != null && req.getProviderLastName() != null) {
				chartObj.setProviderName(req.getProviderLastName()
					+ ", " + req.getProviderFirstName());
			} else {
				chartObj.setProviderName("");
			}
			
			chartObj.setCaseManagerFirstName(req.getClinicianFirstName());
			chartObj.setCaseManagerLastName(req.getClinicianLastName());
			chartObj.setLastActioned(currentTime);
			chartObj.setLastUpdatedTimestamp(currentTime);
			chartObj.setStatusUpdatedTimestamp(currentTime);
			chartObj.setFirstReceived(currentTime);
			chartObj.setLastUpdatedUserId("0");
			chartObj.setStatusUpdatedUserId("0");
			chartObj.setLastUpdatedUsername("RetrieveAPI");
			chartObj.setStatusUpdatedUserName("RetrieveAPI");
			chartObj.setLastUpdatedUserFullname("API, Retrieve");
			chartObj.setStatusUpdatedUserFullName("API, Retrieve");

			session.save(chartObj);

		} catch (Exception e) {
			log.error("Exception occured while Creating MasterChartDetails Row: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	@Override
	public boolean getExistingUniformRecord(String rtrvRequestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("RTRV RequestId: {}", rtrvRequestId);
		boolean isPresent = false;
		try {

			String query = "FROM UniformDashboard where requestId = :requestId";
			log.debug("query: {}", query);
			UniformDashboard uniformDashboard = session.createQuery(query, UniformDashboard.class)
					.setParameter("requestId", rtrvRequestId).uniqueResult();
			log.debug("uniformDashboard: {}", uniformDashboard);
			if (uniformDashboard != null) {
				isPresent = true;
			}

		} catch (Exception e) {
			log.error("Exception occured while Fetching existing uniform Row: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return isPresent;
	}

	@Override
	public UniformDashboard getRetrieveRecordById(String rtrvRequestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("RTRV RequestId: {}", rtrvRequestId);
		UniformDashboard uniformDashboard = null;
		try {

			String query = "FROM UniformDashboard where requestId = :requestId";
			log.debug("query: {}", query);
			uniformDashboard = session.createQuery(query, UniformDashboard.class)
					.setParameter("requestId", rtrvRequestId).uniqueResult();
			log.debug("uniformDashboard: {}", uniformDashboard);

		} catch (Exception e) {
			log.error("Exception occured while Fetching retrieve record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return uniformDashboard;
	}

	@Override
	public boolean updateAllRTRVRecords(String roOrderNo) throws CustomException {
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("rentalOrderNo: {}", roOrderNo);
		boolean isSuccessfull = false;
		try {

			String updateQuery = "UPDATE UniformDashboard SET statusUpdatedUserId = :statusUpdatedUserId, "
					+ " statusUpdatedUserFullname = :statusUpdatedUserFullname, "
					+ " statusUpdatedUsername = :statusUpdatedUsername, "
					+ " statusUpdatedTimestamp = :statusUpdatedTimestamp, "
					+ " lastTeamUpdatedFullName = :lastTeamUpdatedFullName, "
					+ " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp," + " retrieveStatus =:retrieveStatus,"
					+ " vendorStatus =:vendorStatus " + " WHERE vendorOrderNo = :vendorOrderNo ";

			log.debug("updateQuery: {}", updateQuery);

			// Saving details
			session.createQuery(updateQuery).setParameter("statusUpdatedUserId", "0")
					.setParameter("statusUpdatedUserFullname", "API, Retrieve")
					.setParameter("statusUpdatedUsername", "API, Retrieve")
					.setParameter("lastTeamUpdatedFullName", "API, Retrieve")
					.setParameter("statusUpdatedTimestamp", currentTime)
					.setParameter("lastTeamUpdatedTimestamp", currentTime).setParameter("retrieveStatus", "Canceled")
					.setParameter("vendorStatus", "Canceled").setParameter("vendorOrderNo", roOrderNo).executeUpdate();

			log.debug("roOrderNo: {}", roOrderNo);
			isSuccessfull = true;

		} catch (Exception e) {
			log.error("Exception occured while updating retrieve record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return isSuccessfull;
	}

	@Override
	public boolean updateUniformDashboardByRtvId(String rtrvReqId, String retrieveStatus) throws CustomException {
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("rtrvReqId: {}", rtrvReqId);
		boolean isSuccessfull = false;
		try {

			String updateQuery = "UPDATE UniformDashboard SET statusUpdatedUserId = :statusUpdatedUserId, "
					+ " statusUpdatedUserFullname = :statusUpdatedUserFullname, "
					+ " statusUpdatedUsername = :statusUpdatedUsername, "
					+ " statusUpdatedTimestamp = :statusUpdatedTimestamp, "
					+ " lastTeamUpdatedFullName = :lastTeamUpdatedFullName, "
					+ " lastTeamUpdatedTimestamp = :lastTeamUpdatedTimestamp," + " retrieveStatus =:retrieveStatus"
					+ " WHERE requestId = :requestId ";

			log.debug("updateQuery: {}", updateQuery);

			// Saving details
			session.createQuery(updateQuery).setParameter("statusUpdatedUserId", "0")
					.setParameter("statusUpdatedUserFullname", "API, Retrieve")
					.setParameter("statusUpdatedUsername", "API, Retrieve")
					.setParameter("lastTeamUpdatedFullName", "API, Retrieve")
					.setParameter("statusUpdatedTimestamp", currentTime)
					.setParameter("lastTeamUpdatedTimestamp", currentTime)
					.setParameter("retrieveStatus", retrieveStatus)
					.setParameter("requestId", rtrvReqId)
					.executeUpdate();

			log.debug("rtrvReqId: {}", rtrvReqId);
			isSuccessfull = true;

		} catch (Exception e) {
			log.error("Exception occured while updating uniform dashboard record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return isSuccessfull;
	}

	@Override
	public List<String> fetchAllRTRVRecords(String roOrderNo) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("vendorOrderNo: {}", roOrderNo);
		List<String> rtrvRequestId = null;
		try {

			String query = "Select requestId FROM UniformDashboard where vendorOrderNo = :vendorOrderNo";
			log.debug("query: {}", query);
			rtrvRequestId = session.createQuery(query, String.class).setParameter("vendorOrderNo", roOrderNo).list();
			log.debug("rtrvRequestIds: {}", rtrvRequestId);

		} catch (Exception e) {
			log.error("Exception occured while Fetching all retrieve record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return rtrvRequestId;
	}

	@Override
	public boolean updateCSRDetailsInChartDetails(String rtvReqId, String csrName,
			String csrPhone, String csrEmail, String statusChangeNotes) {
		Session session = this.sessionFactory.getCurrentSession();
		boolean isSuccessfull = false;
		try {
			String updateQuery = "UPDATE MasterChartDetails SET csrName = :csrName, "
					+ " csrPhone = :csrPhone, "
					+ " csrEmail = :csrEmail, "
					+ " statusChangeNotes = :statusChangeNotes"
					+ " WHERE orderId = :orderId ";

			log.debug("updateQuery: {}", updateQuery);

			// Saving details
			session.createQuery(updateQuery).setParameter("csrName", csrName)
					.setParameter("csrPhone", csrPhone)
					.setParameter("csrEmail", csrEmail)
					.setParameter("statusChangeNotes", statusChangeNotes)
					.setParameter("orderId", rtvReqId).executeUpdate();

			log.debug("rtvReqId: {}", rtvReqId);
			isSuccessfull = true;

		} catch (Exception e) {
			log.error("Exception occured while updating CSR details in record: {}", e.getMessage());
		}
		return isSuccessfull;
	}

	private String getSolventumStatus(Integer vendorId, String orderStatus) {
		String vendorStatus = orderStatus;

		if (vendorId == 5) {
			switch (orderStatus) {
			case DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_FULL_MR_REQUEST;
			}
				break;

			case DAOConstants.VENDOR_ORDER_RELEASE_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_1_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_1;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_2_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_2;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_3_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_3;
			}
				break;

			case DAOConstants.VENDOR_SUB_CYCLE_4_STATUS: {
				vendorStatus = DAOConstants.SOLVENTUM_SUB_CYCLE_4;
			}
				break;

			case DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED: {
				vendorStatus = DAOConstants.SOLVENTUM_ADDITIONAL_DOC_REQUIRED;
			}
				break;

			default:
				break;
			}
		}
		return vendorStatus;
	}

	@Override
	public void saveDocumentRequest(DocumentRequest documentRequest) throws CustomException {
		Session session = sessionFactory.getCurrentSession();
        session.save(documentRequest);
	}
	
	@Override
	public CTPDashboard getCTPRecordById(String rtrvRequestId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("RTRV RequestId: {}", rtrvRequestId);
		CTPDashboard ctpDashboard = null;
		try {

			String query = "FROM CTPDashboard where orderId = :orderId";
			log.debug("query: {}", query);
			
			ctpDashboard = session.createQuery(query, CTPDashboard.class)
					.setParameter("orderId", rtrvRequestId).uniqueResult();
			
			log.debug("ctpDashboard: {}", ctpDashboard);

		} catch (Exception e) {
			log.error("Exception occured while Fetching retrieve CTP record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return ctpDashboard;
	}

	@Override
	public void saveWoundQOrderInfo(String rtrvRequestId, CTPDashboard ctpRecord,
			boolean isRecordExists, WoundQOrderDetailsRes woundQRes,
			DocumentRequest documentRequest, int vendorId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		
		log.debug("Inside saveWoundQOrderInfo Method: {}", rtrvRequestId);
		//log.debug("requestDocs : " + requestDocs);
		log.debug("woundQRes : " + woundQRes);
		
		try {
			if (ctpRecord == null) {
				ctpRecord = new CTPDashboard();
			}

			ctpRecord.setOrderId(rtrvRequestId);
			ctpRecord.setOrderSource("WoundQ");
			ctpRecord.setVendorId(vendorId);
			
			//vendorId 6 for LifeNet
			if (vendorId == 6) {
				ctpRecord.setVendorName("LifeNet");
			} else {
				ctpRecord.setVendorName("");
			}
			
			if (woundQRes.getPlaceOfService() != null) {
				ctpRecord.setPlaceOfService(woundQRes.getPlaceOfService());
			}
			
			WoundQOrderFacilityObj facilityDetails = woundQRes.getFacilityObject();

			if (facilityDetails != null) {
				log.debug("Getting FacilityDetails: {}", facilityDetails);
				ctpRecord.setBluebookId(facilityDetails.getFacilityBbc());
				ctpRecord.setFacilityName(facilityDetails.getFacilityName());
				ctpRecord.setFacilityId(facilityDetails.getFacilityId());
				ctpRecord.setFacilityType(facilityDetails.getFacilityConfiguration());
			}
			
			// ctpRecord.setHealogicsOrderNo(orderInfoObj.getHlOrderNo());

			String patientFirstName = "";
			String patientLastName = "";
			
			if (woundQRes.getPatient() != null) {
				log.debug("woundQRes.getPatient() : " +woundQRes.getPatient());
				
				patientFirstName = woundQRes.getPatient().getFirstName();
				patientLastName = woundQRes.getPatient().getLastName();

				ctpRecord.setPatientFirstName(patientFirstName);
				ctpRecord.setPatientLastName(patientLastName);
				ctpRecord.setPatientFullname(patientLastName + ", " + patientFirstName);

				ctpRecord.setHealogicsPatientMRN(woundQRes.getPatient().getPatientMrn());
				ctpRecord.setHealogicsPatientId(woundQRes.getPatient().getPatientId());

				if (woundQRes.getPatient().getDob() != null) {
					ctpRecord.setPatientDOB(woundQRes.getPatient().getDob());
				} else {
					ctpRecord.setPatientDOB(null);
				}
			}
			
			WoundQOrderDetails woundQOrder = woundQRes.getOrderDetails();
			
			if (woundQOrder != null) {
				ctpRecord.setWoundqOrderNo(
						(woundQOrder.getOrderDisplayNumber() != null)
							? woundQOrder.getOrderDisplayNumber().toString() : "");
				
				String caseMgrFullName = woundQOrder.getCaseManager();
				
				if (caseMgrFullName != null && !caseMgrFullName.isEmpty()) {
					// Split the name by comma and trim any leading/trailing
					// spaces
					String[] nameParts = caseMgrFullName.split(",");

					if (nameParts.length == 2) {
						String caseMgrFirstName = nameParts[0].trim();
						String caseMgrLastName = nameParts[1].trim();

						ctpRecord.setCaseManagerFirstName(caseMgrFirstName);
						ctpRecord.setCaseManagerLastName(caseMgrLastName);
					} else {
						ctpRecord.setCaseManagerFirstName("");
						ctpRecord.setCaseManagerLastName("");
					}
				} else {
					ctpRecord.setCaseManagerFirstName("");
					ctpRecord.setCaseManagerLastName("");
				}

				ctpRecord.setProviderName(
						(woundQOrder.getPhysician() != null)
							? woundQOrder.getPhysician().toString() : "");
				
				List<WoundQWoundDetails> wounds = woundQOrder.getWounds();
				
				List<VendorWoundDetails> vendorWoundList = new ArrayList<>();
				
				if (wounds != null && wounds.size() > 0) {
					
					for (WoundQWoundDetails wound : wounds) {
						VendorWoundDetails vendorWound = new VendorWoundDetails();
						vendorWound.setWoundNumber(wound.getWoundNumber());
						vendorWound.setWoundId(wound.getWoundId());
						
						List<VendorProductDetails> vendorProductList = new ArrayList<>();
						
						if (wound.getTreatments() != null && wound.getTreatments().size() > 0
								&& wound.getTreatments().get(0) != null) {
							
							List<WoundQProduct> products = wound.getTreatments().get(0).getProducts();
							
							if (products != null && products.size() > 0) {
								
								for (WoundQProduct product : products) {
									VendorProductDetails vendorProduct = new VendorProductDetails();
									vendorProduct.setHcpcCode(product.getHcpcsCode());
									vendorProduct.setProductName(product.getProductName());
									
									vendorProductList.add(vendorProduct);
								}
							}
						}
						
						vendorWound.setProducts(vendorProductList);
						vendorWoundList.add(vendorWound);
					}
					
					ObjectMapper objectMapper = new ObjectMapper();
					String vendorWoundStr = null;
					try {
						vendorWoundStr = objectMapper.writeValueAsString(vendorWoundList);
					} catch (JsonProcessingException e) {
						log.error("Exception occured  while getting vendor Wound: " + e.getMessage());
					}
					
					ctpRecord.setWoundProduct(vendorWoundStr);
				}
			}

			ctpRecord.setReceivedDate(new Date());
			ctpRecord.setFollowupDate(null);

			// if (orderInfoObj.getFollowupDate() != null &&
			// !orderInfoObj.getFollowupDate().isEmpty()) {
			// ctpRecord.setFollowupDate(new
			// SimpleDateFormat("yyyy-MM-dd").parse(orderInfoObj.getFollowupDate()));
			// } else {
			
			// }
			// ctpRecord.setHcpc(orderInfoObj.getHcpc());
			// ctpRecord.setSpecialInstructions(orderInfoObj.getSpecialInstructions());
			// ctpRecord.setPlaceOfService(orderInfoObj.getPlaceOfService());
			// ctpRecord.setCoverageSummary(orderInfoObj.getCoverageSummary());
			// 
			// ctpRecord.setSgp(orderInfoObj.getSgp());

			// if (orderInfoObj.getSgpDate() != null &&
			// !orderInfoObj.getSgpDate().isEmpty()) {
			// ctpRecord.setSgpDate(new
			// SimpleDateFormat("yyyy-MM-dd").parse(orderInfoObj.getSgpDate()));
			// } else {
			// ctpRecord.setSgpDate(null);
			// }

			ctpRecord.setInsertTimestamp(currentTime);
			ctpRecord.setFirstReceived(currentTime);
			ctpRecord.setLastActioned(currentTime);
			ctpRecord.setLastUpdatedTimestamp(currentTime);
			ctpRecord.setLastIpdatedUsername("Retrieve API");
			ctpRecord.setLastUpdatedUserFullname("API, Retrieve");
			ctpRecord.setStatusUpdatedTimestamp(currentTime);
			ctpRecord.setStatusUpdatedUserFullName("API, Retrieve");
			ctpRecord.setStatusUpdatedUserName("Retrieve API");
			ctpRecord.setLastTeamUpdatedTimestamp(currentTime);
			ctpRecord.setLastTeamUpdatedUserFullname("API, Retrieve");
			//RTRV-5681 fix
			ctpRecord.setVendorStatus("");

			if (isRecordExists) {
				//Need to handle status logic here
			} else {
				//LifeNet New Status
				ctpRecord.setRetrieveStatus(RETRIEVE_NEW_STATUS);
			}

			if (woundQRes.getPatient() != null
					&& woundQRes.getPatient().getIcdCodes() != null
					&& woundQRes.getPatient().getIcdCodes().size() > 0) {
				
				log.debug("woundQRes.getPatient().getIcdCodes() : "
						+ woundQRes.getPatient().getIcdCodes());
				
				List<ICD10Data> icd10DataList = new ArrayList<>();
				
				for (ICDCodes icdCode : woundQRes.getPatient().getIcdCodes()) {
					ICD10Data icd10Data = new ICD10Data();
					icd10Data.setCode(icdCode.getId());
					icd10Data.setName(icdCode.getDescription());
					icd10DataList.add(icd10Data);
				}
				
				log.debug("icd10DataList : " +icd10DataList);

				ObjectMapper objectMapper = new ObjectMapper();
				String icd10String = null;
				try {
					icd10String = objectMapper.writeValueAsString(icd10DataList);
				} catch (JsonProcessingException e) {
					log.error("Exception occured  while getting ICDCodes JSON: " + e.getMessage());
				}
				ctpRecord.setIcd10Codes(icd10String);
			}

			PrimaryInsuranceMaster primaryInsJson = new PrimaryInsuranceMaster();
			SecondaryInsuranceMaster secondaryInsJson = new SecondaryInsuranceMaster();
			TertiaryInsuranceMaster tertiaryInsJson = new TertiaryInsuranceMaster();

			if (woundQRes.getPatient() != null && woundQRes.getPatient().getInsurance() != null
					&& woundQRes.getPatient().getInsurance().size() > 0) {
				
				log.debug("woundQRes.getPatient().getInsurance() : "+woundQRes.getPatient().getInsurance());
				
				List<WoundQOrderInsuranceObj> insurnaceList = woundQRes.getPatient().getInsurance();

				for (WoundQOrderInsuranceObj insurance : insurnaceList) {
					log.debug("insurance : " +insurance);
					
					if (insurance == null) {
						continue;
					}

					if (insurance.getSequence() == 1) {
						primaryInsJson.setPrimaryInsName(insurance.getInsuranceName());
						primaryInsJson.setPrimaryInsPolicyNo(insurance.getPolicyNumber());
						ctpRecord.setPrimaryInsuranceCompany("");
						
					} else if (insurance.getSequence() == 2) {
						secondaryInsJson.setSecondaryInsName(insurance.getInsuranceName());
						secondaryInsJson.setSecondaryInsPolicyNo(insurance.getPolicyNumber());
						
					} else if (insurance.getSequence() == 3) {
						tertiaryInsJson.setTertiaryInsName(insurance.getInsuranceName());
						tertiaryInsJson.setTertiaryInsPolicyNo(insurance.getPolicyNumber());
					}
				}

				ObjectMapper objectMapper1 = new ObjectMapper();

				String primaryString = null;
				try {
					primaryString = objectMapper1.writeValueAsString(primaryInsJson);
				} catch (JsonProcessingException e) {
					log.error("Exception occured  while getting primaryInsJson JSON: " + e.getMessage());
				}
				ctpRecord.setPrimaryInsurance(primaryString);

				ObjectMapper objectMapper2 = new ObjectMapper();

				String secondaryString = null;
				try {
					secondaryString = objectMapper2.writeValueAsString(secondaryInsJson);
				} catch (JsonProcessingException e) {
					log.error("Exception occured  while getting secondaryInsJson JSON: " + e.getMessage());
				}
				ctpRecord.setSencondaryInsurance(secondaryString);
				
				ObjectMapper objectMapper3 = new ObjectMapper();

				String tertiaryString = null;
				try {
					tertiaryString = objectMapper3.writeValueAsString(tertiaryInsJson);
				} catch (JsonProcessingException e) {
					log.error("Exception occured  while getting tertiaryInsJson JSON: " + e.getMessage());
				}
				ctpRecord.setTertiaryInsurance(tertiaryString);
			}

			log.debug("Saving ctpRecord : " + ctpRecord);

			if (isRecordExists) {
				session.update(ctpRecord);
			} else {
				session.save(ctpRecord);
			}

			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", rtrvRequestId);
			Integer historyId = historyTimelineDAO.getHistoryId();
			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(rtrvRequestId);
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(woundQRes.getOrderStatus());
			// vendorStatus.setCoverageSummary(orderInfoObj.getCoverageSummary());
			historyTimeline.setVendorStatus(vendorStatus);

			HistoryUserNotes userNotesObj = new HistoryUserNotes();

			if (isRecordExists) {
				historyTimeline.setRetrieveStatus(ctpRecord.getRetrieveStatus());
			} else {
				historyTimeline.setRetrieveStatus(RETRIEVE_NEW_STATUS);
				userNotesObj.setDescription(NEW_STATUS_TEXT);
			}

			historyTimeline.setUserNotes(userNotesObj);

			log.debug("Creating History timeline:  {}", historyTimeline);
			
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			
			log.debug("Created History timeline");

			if (!isRecordExists) {
				// Making requested documents entry in history
				MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
				docReqTimeline.setRequestId(rtrvRequestId);
				docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
				docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
				docReqTimeline.setLastUpdatedUserId(0L);
				docReqTimeline.setLastUpdatedUsername("Retrieve API");
				docReqTimeline.setRetrieveStatus("New");
				VendorStatus vendorStatus1 = new VendorStatus();
				vendorStatus1.setCurrentStatus(woundQRes.getOrderStatus());
				// vendorStatus1.setCoverageSummary(requestDocs.getCoverageSummary());

				List<String> reqDocs = new ArrayList<>();

				if (documentRequest.getDocuments() != null
						&& !documentRequest.getDocuments().isEmpty()) {
					
					log.debug("documentRequest.getDocuments() : " +documentRequest.getDocuments());
					
					List<EDocument> eDocs = new ArrayList<>();
					
					if (documentRequest != null && documentRequest.getDocuments() != null) {
						ObjectMapper objectMapper = new ObjectMapper();
						try {
							eDocs = objectMapper.readValue(
								documentRequest.getDocuments(),
								new TypeReference<List<EDocument>>() {
							});
						} catch (JsonProcessingException e) {
							log.error("Json Procession exception:  {}", e);
						}
					}
					
					log.debug("eDocs : " +eDocs);
					
					//We need to convert string to object
					for (EDocument eDoc : eDocs) {
						reqDocs.add(eDoc.getDocumentType());
					}
					vendorStatus1.setRequestedDocs(reqDocs);
				}
				docReqTimeline.setVendorStatus(vendorStatus1);

				HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
				userNotesObj1.setDescription(REQUESTED_DOCUMENT_TEXT);
				docReqTimeline.setUserNotes(userNotesObj1);

				log.debug("Creating History timeline:  {}", docReqTimeline);
				historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
				log.debug("Created History timeline");
			}
			

		} catch (Exception e) {
			log.error("Exception occured while Updating OrderInfo in CTP_Dashboard Record: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}
	//
	@Override
	public DocumentLibrary getDocumentLibrary(Integer vendorId) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		log.debug("vendorId: {}", vendorId);
		DocumentLibrary docLibrary = null;
		try {

			String query = "FROM DocumentLibrary where vendorId = :vendorId";
			log.debug("query: {}", query);
			docLibrary = session.createQuery(query, DocumentLibrary.class)
					.setParameter("vendorId", vendorId).uniqueResult();
			
			log.debug("docLibrary: {}", docLibrary);

		} catch (Exception e) {
			log.error("Exception occured while Fetching Document Library: {}", e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return docLibrary;
	}
	
}