package com.healogics.rtrv.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Qualifier;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.DataExtractorDAO;
import com.healogics.rtrv.entity.JobsHeartBeat;
import com.healogics.rtrv.entity.PatientMedicalRecords;

@Component
@Service
@Repository
@TransactionManager1
public class DataExtractorDAOImpl implements DataExtractorDAO{
	
	private final Logger log = LoggerFactory.getLogger(DataExtractorDAOImpl.class);

	@Autowired
	@Qualifier("SessionFactory1")
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	@Override
	public JobsHeartBeat getJobDetailsNPWT(String jobName, String tableName) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		JobsHeartBeat jobDetails = null;
		try {
			String hql = "FROM JobsHeartBeat d WHERE d.jobName = :jobName"
					+ " AND d.tableName = :tableName"
					+ " order by endTime desc";
			
			log.debug("hql : " +hql);
			
			jobDetails = (JobsHeartBeat) session.createQuery(hql)
					.setParameter("jobName", jobName)
					.setParameter("tableName", tableName)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured in getJobDetails: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return jobDetails;
	}
	
	@Override
	public void updateJobStatus(JobsHeartBeat jobDetails) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			
			Query query = session.createQuery("UPDATE JobsHeartBeat a SET"
					+ " a.startTime = :startTime,"
					+ " a.endTime = :endTime,"
					+ " a.nextScheduledAt = :nextScheduledAt,"
					+ " a.durationMins = :durationMins,"
					+ " a.durationSecs = :durationSecs,"
					+ " a.durationMillisecs = :durationMillisecs,"
					+ " a.status = :status,"
					+ " a.errorMessage = :errorMessage"
					+ " WHERE a.jobName = :jobName AND a.tableName = :tableName");
			
			query.setParameter("startTime", jobDetails.getStartTime());
			query.setParameter("endTime", jobDetails.getEndTime());
			query.setParameter("nextScheduledAt", jobDetails.getNextScheduledAt());
			query.setParameter("durationMins", jobDetails.getDurationMins());
			query.setParameter("durationSecs", jobDetails.getDurationSecs());
			query.setParameter("durationMillisecs", jobDetails.getDurationMillisecs());
			query.setParameter("status", jobDetails.getStatus());
			query.setParameter("errorMessage", jobDetails.getErrorMessage());
			query.setParameter("jobName", jobDetails.getJobName());
			query.setParameter("tableName", jobDetails.getTableName());
			
			query.executeUpdate();
		} catch (Exception e) {
			log.error("Exception occured in updateJobStatus: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	@Override
	public List<PatientMedicalRecords> extractPMRDataNPWT(
			Timestamp dataExtractorTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<PatientMedicalRecords> pmrListNPWT = new ArrayList<>();
		try {
			String hql = "FROM PatientMedicalRecords a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";
			
			log.debug("hql : " +hql);
			
			pmrListNPWT = (List<PatientMedicalRecords>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractDocHistoryData: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return pmrListNPWT;
	}
	
	@Override
	public List<PatientMedicalRecords> extractPMRDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		List<PatientMedicalRecords> pmrListNPWT = new ArrayList<>();
		try {
			String hql = "FROM PatientMedicalRecords a"
					+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
					+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
			
			log.debug("hql : " +hql);
			
			pmrListNPWT = (List<PatientMedicalRecords>) session.createQuery(hql)
					.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
					.setParameter("endTimestamp", endTimestamp)
					.getResultList();
		} catch (Exception e) {
			log.error("Exception occured in extractPMRDataNPWTHistorical: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return pmrListNPWT;
	}

	@Override
	public JobsHeartBeat getJobDetails(String jobName, String tableName)
			throws Exception {
		Session session = this.sessionFactory.getCurrentSession();
		JobsHeartBeat jobDetails = null;
		try {
			String hql = "FROM JobsHeartBeat d WHERE d.jobName = :jobName"
					+ " AND d.tableName = :tableName"
					+ " order by endTime desc";
			
			log.debug("hql : " +hql);
			
			jobDetails = (JobsHeartBeat) session.createQuery(hql)
					.setParameter("jobName", jobName)
					.setParameter("tableName", tableName)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured in getJobDetails: " +e.getMessage());
			throw new Exception(e.getMessage());
		}
		return jobDetails;
	}

	@Override
	public List<PatientMedicalRecords> extractPMRData(Timestamp dataExtractorTimestamp) throws Exception {
			Session session = this.sessionFactory.getCurrentSession();
			List<PatientMedicalRecords> pmrListCTP = new ArrayList<>();
			try {
				String hql = "FROM PatientMedicalRecords a"
						+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp";
				
				log.debug("hql : " +hql);
				
				pmrListCTP = (List<PatientMedicalRecords>) session.createQuery(hql)
						.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
						.getResultList();
			} catch (Exception e) {
				log.error("Exception occured in extractDocHistoryData: " +e.getMessage());
				throw new Exception(e.getMessage());
			}
			return pmrListCTP;
		}
	
	@Override
	public List<PatientMedicalRecords> extractPMRDataCTPHistorical(Timestamp dataExtractorTimestamp,
			Timestamp endTimestamp) throws Exception {
			Session session = this.sessionFactory.getCurrentSession();
			List<PatientMedicalRecords> pmrListCTP = new ArrayList<>();
			try {
				String hql = "FROM PatientMedicalRecords a"
						+ " WHERE a.lastUpdatedTimestamp >= :dataExtractorTimestamp"
						+ " AND a.lastUpdatedTimestamp <= :endTimestamp";
				
				log.debug("hql : " +hql);
				
				pmrListCTP = (List<PatientMedicalRecords>) session.createQuery(hql)
						.setParameter("dataExtractorTimestamp", dataExtractorTimestamp)
						.setParameter("endTimestamp", endTimestamp)
						.getResultList();
			} catch (Exception e) {
				log.error("Exception occured in extractDocHistoryData: " +e.getMessage());
				throw new Exception(e.getMessage());
			}
			return pmrListCTP;
		}

	

}
