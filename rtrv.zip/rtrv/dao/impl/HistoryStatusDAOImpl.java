package com.healogics.rtrv.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.HistoryStatusDAO;
import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.entity.DocumentationHistory;
import com.healogics.rtrv.exception.CustomException;

@Repository
@TransactionManager1
public class HistoryStatusDAOImpl implements HistoryStatusDAO {
	private final Logger log = LoggerFactory
			.getLogger(HistoryStatusDAOImpl.class);

	private final SessionFactory sessionFactory;

	@Autowired
	public HistoryStatusDAOImpl(@Qualifier("SessionFactory1")
			SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<DocumentationHistory> getStatusHistory(int bhcMedRecId,
			int bhcInvoiceId, int page) throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		List<DocumentationHistory> history = new ArrayList<>();

		try {
			String hql = "FROM DocumentationHistory d WHERE d.bhcMedicalRecordId="
					+ bhcMedRecId + " AND d.bhcInvoiceOrderNo=" + bhcInvoiceId
					+ " order by lastUpdatedTimestamp desc";

			history = session.createQuery(hql).list();
		} catch (Exception e) {
			log.error("Exception occured while fetching all records: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return history;
	}

	@Override
	public Long getTotalCount(int bhcMedRecId, int bhcInvoiceId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		Long taskCount = 0L;

		try {
			String hql = "SELECT count(*) FROM DocumentationHistory n"
					+ " WHERE n.bhcMedicalRecordId = :bhcMedicalRecordId "
					+ " AND n.bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";

			taskCount = (Long) session.createQuery(hql)
					.setParameter("bhcMedicalRecordId", bhcMedRecId)
					.setParameter("bhcInvoiceOrderNo", bhcInvoiceId)
					.uniqueResult();
		} catch (Exception e) {
			log.error("Exception occured while fetching new notes count: {}"
					, e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return taskCount;
	}

	@Override
	public DocumentStatus getDocumentStatusByHistory(String documentId)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		DocumentStatus status = new DocumentStatus();
		try {
			String hql = "FROM DocumentStatus d WHERE d.documentationHistoryNoteId = :documentationHistoryNoteId";

			status = session.createQuery(hql, DocumentStatus.class)
					.setParameter("documentationHistoryNoteId", documentId).setMaxResults(1)
					.uniqueResult();
		}catch(Exception e) {
			log.error("Exception occured while fetching DocumentStatus by History: {}"
					,e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return status;
	}

	
}
