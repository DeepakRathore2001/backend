package com.healogics.rtrv.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.rtrv.entity.JobsHeartBeat;
import com.healogics.rtrv.entity.PatientMedicalRecords;

public interface DataExtractorDAO {

	JobsHeartBeat getJobDetailsNPWT(String appNotificationJobName, String appNotificationTableName) throws Exception;

	void updateJobStatus(JobsHeartBeat jobTable) throws Exception;

	List<PatientMedicalRecords> extractPMRDataNPWT(Timestamp pmrTimestampNPWT) throws Exception;

	JobsHeartBeat getJobDetails(String appNotificationJobName, String appNotificationTableName)throws Exception;

	List<PatientMedicalRecords> extractPMRData(Timestamp pmrTimestampCTP)throws Exception;
	
	public List<PatientMedicalRecords> extractPMRDataCTPHistorical(Timestamp dataExtractorTimestamp,
			Timestamp endTimestamp) throws Exception;
	
	public List<PatientMedicalRecords> extractPMRDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;

}
