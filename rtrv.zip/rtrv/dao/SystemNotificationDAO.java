package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.dto.SystemNotificationListReq;
import com.healogics.rtrv.dto.SystemNotificationWSAReq;
import com.healogics.rtrv.dto.UserNotificationReq;
import com.healogics.rtrv.entity.SystemNotification;
import com.healogics.rtrv.exception.CustomException;

public interface SystemNotificationDAO {

	String saveSystemNotifications(
			SystemNotificationWSAReq systemNotificationReq) throws CustomException;

	List<SystemNotification> getSystemNotifications(
			SystemNotificationListReq systemNotListReq) throws CustomException;

	void updateNotifications(SystemNotificationWSAReq systemWSAReq) throws CustomException;

	void saveUserNotifications(UserNotificationReq userNotificationReq) throws CustomException;
	
	public void deleteNotifications(List<String> notificationIdList) throws CustomException;

}
