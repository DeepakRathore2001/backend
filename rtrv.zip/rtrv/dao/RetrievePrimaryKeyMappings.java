package com.healogics.rtrv.dao;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RetrievePrimaryKeyMappings {
	@JsonProperty("PrimaryKeyMappings")
	private RetrievePrimaryKeyMapping primaryKeyMappings;

	public RetrievePrimaryKeyMapping getPrimaryKeyMappings() {
		return primaryKeyMappings;
	}

	public void setPrimaryKeyMappings(RetrievePrimaryKeyMapping primaryKeyMappings) {
		this.primaryKeyMappings = primaryKeyMappings;
	}

	@Override
	public String toString() {
		return "RetrievePrimaryKeyMappings [primaryKeyMappings=" + primaryKeyMappings + "]";
	}
}
