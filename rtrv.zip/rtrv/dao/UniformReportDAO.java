package com.healogics.rtrv.dao;

import java.util.List;
import java.util.Map;

import com.healogics.rtrv.dto.NPWTFilterOptions;
import com.healogics.rtrv.dto.NPWTReportReq;
import com.healogics.rtrv.entity.NPWTReport;
import com.healogics.rtrv.exception.CustomException;

public interface UniformReportDAO {
	public Map<String, Object> generateNPWTReport(NPWTReportReq req, int index, boolean isExcel)
			throws CustomException;

	public NPWTFilterOptions npwtReportFilterOptions(NPWTReportReq req) throws CustomException;

	public List<NPWTReport> generateAllNPWTReport(NPWTReportReq req, int index, boolean isExcel)
			throws CustomException;

	public Long getTotalCount(int index, NPWTReportReq req) throws CustomException;
}
