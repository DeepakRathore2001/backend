package com.healogics.rtrv.dao;

import com.healogics.rtrv.dto.Email;

public interface MailDAO {
	public boolean saveMailNotification(Email emailObj);
}
