package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.dto.IhealUserRes;
import com.healogics.rtrv.dto.LoginUser;
import com.healogics.rtrv.dto.UserFacilities;

public interface UserLoginDAO {
	public void saveUserLogin(LoginUser loginUser);
	public void saveRetrieveUserLogin(IhealUserRes user);
	public int saveUserFacilities(String userId, List<UserFacilities> facilities);
}
