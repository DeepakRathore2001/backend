package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.dto.ChartReviewDetails;
import com.healogics.rtrv.dto.ChartReviewReq;
import com.healogics.rtrv.dto.IHealPatientSearchRes;
import com.healogics.rtrv.dto.ModifyRecordReq;
import com.healogics.rtrv.dto.PatientSearchReq;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.SubmitRequest;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.entity.UserNotes;
import com.healogics.rtrv.exception.CustomException;

public interface ChartReviewDAO {
	public ChartReviewDetails getchartDetails(ChartReviewReq req) throws CustomException;
	public void saveRequest(SaveRequest saveReq);
	public boolean submitRecord(SubmitRequest req);
	public void saveNotes(SaveNotesReq req) throws CustomException;
	public List<UserNotes> getNotesList(ChartReviewReq req) throws CustomException;
	public List<RetrieveUsers> getUserRolesList(boolean isSuperUser) throws CustomException;
	public Long getNotesCount(String bhcMedRecId, String bhcInvOrderNo) throws CustomException;
	public UserNotes getNoteById(String noteId) throws CustomException;
	public IHealPatientSearchRes getPatientObj(PatientSearchReq patientSearchReq);
	public int updatePatientDetails(
			UpdatePatientDetailsReq req) throws CustomException;
	public RetrieveMembers getTeamMemberByBBC(String bbc) throws CustomException;
	public boolean modifyRecord(ModifyRecordReq req) throws CustomException;
}
