package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.exception.CustomException;

public interface TeamMemberDAO {
	public List<RetrieveMembers> getActiveTeamMebers() throws CustomException;
}
