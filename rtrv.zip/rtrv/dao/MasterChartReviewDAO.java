package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.dto.GetOrderUpdateReq;
import com.healogics.rtrv.dto.MasterChartDetailsObj;
import com.healogics.rtrv.dto.MasterChartDetailsReq;
import com.healogics.rtrv.dto.MasterModifyRecordReq;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentRequest;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.entity.MasterUserNotes;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.exception.CustomException;

public interface MasterChartReviewDAO {
	public SaveMasterNotesReq saveMasterNotes(SaveMasterNotesReq req) throws CustomException;

	public MasterChartDetailsObj getchartDetails(MasterChartDetailsReq req)
			throws CustomException;
	
	public List<MasterUserNotes> getMasterNotesList(String orderId, int index, String serviceLine)
			throws CustomException;
	
	void saveMasterChartDetails(MasterSaveChartReq req) throws CustomException;
	
	public Long getNotesCount(String orderId) throws CustomException;
	
	public void updateSubmitStatus(MasterSubmitChartReq req, Long noOfUpdates, int filesSent) throws CustomException;

	public void updateOrderInformation(GetOrderUpdateReq req) throws CustomException;

	public boolean masterModifyRecord(MasterModifyRecordReq req) throws CustomException;

	public List<MasterDocumentStore> getAttachments(String orderId) throws CustomException;

	public ViewAttachmentRes viewManualAttachment(MasterChartDetailsReq req) throws CustomException;
	
	public CTPDashboard getRecordByRequestId(String requestId)
			throws CustomException;
	
	public CTPDashboard getDashboard(String orderId) throws CustomException;
	
	public boolean saveDocuments(MasterSaveChartReq req) throws CustomException;
	
	public MasterUserNotes getNoteById(String noteId) throws CustomException;

	public void saveUniformChartDetails(MasterSaveChartReq req) throws CustomException;

	public MasterChartDetailsObj getUniformChartDetails(
			MasterChartDetailsReq req) throws CustomException;
	
	public UniformDashboard getUniformDashboard(String retrieveReqId)
			throws CustomException;
	
	public void updateNPWTSubmitStatus(MasterSubmitChartReq req,
			Long noOfUpdates, int filesSent) throws CustomException;
	
	public DocumentRequest getRequestedDocsByRtrvId(String rtrvReqId)
			throws CustomException;

	public int updatePatientDetails(UpdatePatientDetailsReq req) throws CustomException ;

}
