package com.healogics.rtrv.dao;

import java.util.List;
import java.util.Map;

import com.healogics.rtrv.dto.CTPData;
import com.healogics.rtrv.dto.CTPFilterOptions;
import com.healogics.rtrv.dto.DocsReq;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.OrderInfoObj;
import com.healogics.rtrv.dto.UniformData;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.WoundQOrderDetailsRes;
import com.healogics.rtrv.dto.WoundQOrderNotificationReq;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentLibrary;
import com.healogics.rtrv.entity.DocumentRequest;
import com.healogics.rtrv.entity.NotesAttemptType;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.PrimaryKeySetup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.exception.CustomException;

public interface MasterDashboardDAO {

	List<CTPDashboard> getAllCTPRecords(boolean isExcel, MasterCTPDashboardReq dashboardReq,
			int index, String taskType, String assignee, Boolean isSuperUser) throws CustomException;

	Long getTotalCount(int index, String taskType, String assignee,
			MasterCTPDashboardReq dashboardReq, Boolean isSuperUser) throws CustomException;

	CTPFilterOptions getFilterOptions(MasterCTPDashboardReq req, Boolean isSuperUser, String serviceLine) throws CustomException;

	Map<String, Object> getFilteredCTPList(boolean isExcel,
			MasterCTPDashboardReq dashboardReq, int index, String taskType,
			String assignee, Boolean isSuperUser) throws CustomException;
	
	public void saveRequestedDocs(DocsReq req, String rtrvRequestId) throws CustomException;

	UpdateAssignedToRes updatedAssigneedTo(MasterCTPDashboardReq req,
			List<CTPData> records) throws CustomException;

	void saveOrderInfo(String vendorRequestId, OrderInfoObj orderInfoObj, DocsReq req,
			 CTPDashboard ctpRecord, boolean isRecordExists) throws CustomException;

	Long getUniformTotalCount(int index, String taskType, String assignee, MasterCTPDashboardReq dashboardReq,
			Boolean isSuperUser) throws CustomException;

	List<UniformDashboard> getUniformRecords(boolean isExcel,
			MasterCTPDashboardReq dashboardReq, int index, String taskType, String assignee, Boolean isSuperUser) throws CustomException;
	
	public PrimaryKeySetup fetchPrimaryKeyByVendorId(int vendorId)
			throws CustomException;
	
	public PrimaryKeyLookup lookupPrimaryKey(RetrievePrimaryKeyMapping mapping,
			int vendorId, String vendorRequestId, String vendorStatus)
					throws CustomException;
	
	public Long generateRetrieveReqId(PrimaryKeyLookup lookup) throws CustomException;
	
	public List<NotesAttemptType> getAttemptTypeByServiceline(String serviceLine)
			 throws CustomException;

	Map<String, Object> getFilteredUniformList(boolean isExcel,
			MasterCTPDashboardReq dashboardReq, int index, String taskType,
			String assignee, Boolean isSuperUser) throws CustomException;

	CTPFilterOptions getUniformFilterOptions(MasterCTPDashboardReq req,
			Boolean isSuperUser, String serviceLine) throws CustomException;

	UpdateAssignedToRes updatedAssigneedToRecord(MasterCTPDashboardReq req, List<UniformData> records)throws CustomException;

	void saveUniformDashboardRow(DocsReq req, String rtrvRequestId) throws CustomException;

	void saveMasterChartDetailsRow(DocsReq req, String rtrvRequestId) throws CustomException;

	boolean getExistingUniformRecord(String rtrvRequestId) throws CustomException;
	
	public UniformDashboard getRetrieveRecordById(String rtrvRequestId)
			throws CustomException;
	
	public PrimaryKeyLookup primaryKeyLookupByRtrvId(Long retrieveReqId)
			throws CustomException;

	boolean updateAllRTRVRecords(String roOrderNo) throws CustomException;

	List<String> fetchAllRTRVRecords(String roOrderNo) throws CustomException;
	
	public boolean updateUniformDashboardByRtvId(
			String rtrvReqId, String retrieveStatus)
			throws CustomException;
	
	public boolean updateCSRDetailsInChartDetails(String rtvReqId, String csrName,
			String csrPhone, String csrEmail, String statusChangeNotes);

	void saveDocumentRequest(DocumentRequest documentRequest)throws CustomException;
	
	public CTPDashboard getCTPRecordById(String rtrvRequestId) throws CustomException;

	public void saveWoundQOrderInfo(String rtrvRequestId, CTPDashboard ctpRecord,
			boolean isRecordExists, WoundQOrderDetailsRes woundQRes,
			DocumentRequest documentRequest, int vendorId) throws CustomException;
	
	public DocumentLibrary getDocumentLibrary(Integer vendorId) throws CustomException;

}
