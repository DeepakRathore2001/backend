package com.healogics.rtrv.dao;

import java.util.List;
import java.util.Map;

import com.healogics.rtrv.dto.AdminDashboardReq;
import com.healogics.rtrv.dto.FilteredBBCResponse;
import com.healogics.rtrv.dto.UpdateCenteAssignmentReq;
import com.healogics.rtrv.dto.UpdateRetrieveUsersReq;
import com.healogics.rtrv.entity.FacilityDetails;
import com.healogics.rtrv.entity.RetrieveMembers;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.exception.CustomException;

public interface AdministrationDAO {

	public List<Object[]> getRetrieveMembersData(AdminDashboardReq req, int index) throws CustomException;

	public List<RetrieveUsers> getRetrieveUsersData(AdminDashboardReq req, int index) throws CustomException;

	public FacilityDetails getTerritory(String bluebookCode) throws CustomException;

	public List<String> getRoleAssignmentFilterOptions(AdminDashboardReq req) throws CustomException;

	public Map<String, Object> getFilteredRetrieveMembers(
			AdminDashboardReq req, int index) throws CustomException;

	public Map<String, Object> getFilteredRetrieveUsers(AdminDashboardReq req,
			int index) throws CustomException;

	public Long totalRetrieveUsers(Boolean isSuperUser) throws CustomException;

	public List<String> getCenterAssignmentFilterOptions(AdminDashboardReq req) throws CustomException;

	public Long totalRetrieveMembers() throws CustomException;

	public List<String> getCenterAssignmentPopupValues(String column) throws CustomException;

	public List<String> getAssigneeNameFromUsersTable(Boolean isSuperUser) throws CustomException;

	public void updateRetrieveUsers(List<UpdateRetrieveUsersReq> userRoles) throws CustomException;

	public int updateRetrieveMembers( UpdateCenteAssignmentReq req)  throws CustomException;

	public Map<String, Object> getFilteredRetrieveMemberstoExcel(AdminDashboardReq req)throws CustomException;

	public List<Object[]> getRetrieveMembersDatatoExcel(AdminDashboardReq req)throws CustomException;

	public  FilteredBBCResponse getCenterAssignmentDropDownValues(AdminDashboardReq req) throws CustomException;

}
