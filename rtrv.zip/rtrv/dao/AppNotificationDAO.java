package com.healogics.rtrv.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.rtrv.dto.AppNotificaionsReq;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.exception.CustomException;

public interface AppNotificationDAO {

	public List<AppNotifications> getCount(AppNotificaionsReq req) throws CustomException;

	public Boolean saveNoteNotifications(SaveNotesReq req) throws CustomException;

	public Boolean saveAssignedNotifications(SaveRequest saveReq) throws CustomException;

	public Long updateNotifications(AppNotificaionsReq req) throws CustomException;
	
	public List<AppNotifications> getAppNotification(Long userId,
			Timestamp clearNotificationTimestamp, String last30DaysDate) throws CustomException;

	public Boolean saveBatchAssignedNotifications(int size,
			DashboardReq req) throws CustomException;

	public Boolean sendFailedDocumentNotification(int bhcMedicalRecordId,
			int bhcInvoiceOrderId, String documentId, String userId, String username, String userFullname) throws CustomException;

}
