package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.dto.HistoryTimelineDocStatus;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.entity.MasterDocumentationHistory;

public interface MasterHistoryTimelineDAO {
	public Integer getHistoryId();
	public void saveHistoryTimeline(MasterHistoryTimeline historyBO);
	public List<MasterDocumentationHistory> getOrderHistory(String orderId, int index);
	public Long getHistoryCount(String orderId);
	public MasterDocumentationHistory getHistoryTimelineById(int historyId);
	public void updateHistoryTimeline(int historyId, List<HistoryTimelineDocStatus> docList);
}
