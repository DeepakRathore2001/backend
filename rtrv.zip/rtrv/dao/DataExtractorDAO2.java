package com.healogics.rtrv.dao;

import java.sql.Timestamp;
import java.util.List;

import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentStore;
import com.healogics.rtrv.entity.DocumentationHistory2;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.entity.UserNotes2;


public interface DataExtractorDAO2 {
	
	List<AppNotifications> extractAppNotificationDataNPWT(Timestamp appNotifyExtractorTimestamp) throws Exception;

	List<DocumentStore> extractDocumentStoreDataNPWT(Timestamp docStoreExtractorTimestampNPWT) throws Exception;

	List<DocumentationHistory2> extractDocHistoryDataNPWT(Timestamp docHistoryExtractorTimestampNPWT) throws Exception;

	List<UniformDashboard> extractNPWTDashboardData(Timestamp npwtDashboardTimestamp) throws Exception;

	List<PrimaryKeyLookup> extractPrimaryKeyLookupDataNPWT(Timestamp primaryKeyLookupExtractorTimestampNPWT) throws Exception;

	List<UserNotes2> extractUserNotesDataNPWT(Timestamp userNotesTimestampNPWT) throws Exception;

	List<MasterAppNotification> extractAppNotificationData(Timestamp appNotifyExtractorTimestamp)throws Exception;

	List<DocumentStore> extractDocumentStoreData(Timestamp docStoreExtractorTimestampCTP)throws Exception;

	List<DocumentationHistory2> extractDocHistoryData(Timestamp docHistoryExtractorTimestampCTP)throws Exception;

	List<UserNotes2> extractUserNotesData(Timestamp userNotesTimestampCTP)throws Exception;

	List<CTPDashboard> extractCTPDashboardData(Timestamp ctpDashboardTimestamp)throws Exception;
	
	public List<MasterAppNotification> extractAppNotificationDataCTPHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp)
			throws Exception;

	public List<DocumentStore> extractDocumentStoreDataCTPHistorical(
			Timestamp docStoreExtractorTimestampCTP, Timestamp endTimestamp) throws Exception;
	
	public List<DocumentationHistory2> extractDocHistoryDataCTPHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp)
			throws Exception;
	
	public List<CTPDashboard> extractCTPDashboardDataHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;
	
	public List<UserNotes2> extractUserNotesDataCTPHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;
	
	public List<AppNotifications> extractAppNotificationDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;
	
	public List<DocumentStore> extractDocumentStoreDataNPWTHistorical(
			Timestamp docStoreExtractorTimestampNPWT, Timestamp endTimestamp) throws Exception;
	
	public List<DocumentationHistory2> extractDocHistoryDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;
	
	public List<UniformDashboard> extractNPWTDashboardDataHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;
	
	public List<PrimaryKeyLookup> extractPrimaryKeyLookupDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp) throws Exception;
	
	public List<UserNotes2> extractUserNotesDataNPWTHistorical(
			Timestamp dataExtractorTimestamp, Timestamp endTimestamp)  throws Exception;

}
