package com.healogics.rtrv.dao;

import com.healogics.rtrv.dto.DocumentNotificationReq;

public interface DocNotificationDAO {
	public boolean saveDocNotification(DocumentNotificationReq req);

}
