package com.healogics.rtrv.dao;

import java.util.Map;

import com.healogics.rtrv.dto.AWDFilterOptions;

import com.healogics.rtrv.dto.ViewReportsReq;
import com.healogics.rtrv.exception.CustomException;

public interface ReportsDAO {

	public Map<String, Object> viewReports(ViewReportsReq req, boolean isExcel) throws CustomException;
	
	public AWDFilterOptions awdReportFilterOptions(ViewReportsReq req) throws CustomException;

}
