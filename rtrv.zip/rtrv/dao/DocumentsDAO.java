package com.healogics.rtrv.dao;

import java.util.List;

import com.healogics.rtrv.dto.AttachmentDetails;
import com.healogics.rtrv.dto.DocumentsListReq;
import com.healogics.rtrv.dto.IHealCustomScanListGetRes;
import com.healogics.rtrv.dto.IHealDebridementRes;
import com.healogics.rtrv.dto.IHealDocumentsListGetRes;
import com.healogics.rtrv.dto.IHealProgressNotesListGetRes;
import com.healogics.rtrv.dto.IHealWoundAssessmentListGetResponse;
import com.healogics.rtrv.dto.IHealWoundListGetRes;
import com.healogics.rtrv.dto.ViewAttachmentReq;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.exception.CustomException;

public interface DocumentsDAO {

	public IHealCustomScanListGetRes getCustomScanList(DocumentsListReq req);

	public IHealDocumentsListGetRes getProviderOrderList(DocumentsListReq req);

	public IHealProgressNotesListGetRes getProgressNotesList(DocumentsListReq req);

	public IHealWoundListGetRes getWoundList(DocumentsListReq req);

	public IHealDebridementRes getDebridementsList(DocumentsListReq req, int entity);

	public IHealWoundAssessmentListGetResponse getWoundAssessmentList(
			int entity, DocumentsListReq req);

	public List<AttachmentDetails> getManualAttachmentList(
			DocumentsListReq req) throws CustomException;

	public ViewAttachmentRes viewIHealAttachment(ViewAttachmentReq req);

	public ViewAttachmentRes viewManualAttachment(ViewAttachmentReq req) throws CustomException;

}
