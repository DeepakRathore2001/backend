package com.healogics.rtrv.dao;

import com.healogics.rtrv.dto.SaveServiceLineReq;
import com.healogics.rtrv.dto.SaveServiceLineRes;
import com.healogics.rtrv.exception.CustomException;

public interface ServiceLineDAO {

	public SaveServiceLineRes saveServiceLine(SaveServiceLineReq req) throws CustomException;

	public SaveServiceLineRes updateUserColorCodes(SaveServiceLineReq req) throws CustomException;

}
