package com.healogics.rtrv.dao;

public class RetrievePrimaryKeyMapping {
	private String vendorRequestId;
	private String vendorStatus;

	public String getVendorRequestId() {
		return vendorRequestId;
	}
	public void setVendorRequestId(String vendorRequestId) {
		this.vendorRequestId = vendorRequestId;
	}
	public String getVendorStatus() {
		return vendorStatus;
	}
	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}
	@Override
	public String toString() {
		return "RetrievePrimaryKeyMapping [vendorRequestId=" + vendorRequestId
				+ ", vendorStatus=" + vendorStatus + "]";
	}
}
