package com.healogics.rtrv.dao;

import java.util.Date;

import com.healogics.rtrv.dto.DocumentNameObj;
import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.exception.CustomException;

public interface PDFDAO {
	public DocumentStatus getDocumentDetails(String clientState);
	public boolean saveDocPDFGetStatus(String clientState, String docStatus);
	public boolean saveSendToS3Status(String clientState, String s3Status)
			throws CustomException;
	public Long getDocumentId(Long bhcMedRecId, Long bhcInvOrderNo,
			String docType, Date visitDate) throws CustomException;
	public boolean saveDocumentId(DocumentNameObj doc, boolean firstTime)
			throws CustomException;
	public Long getCustomScansDocumentId(Long bhcMedRecId, Long bhcInvOrderNo,
			String docType) throws CustomException;
	// public void saveDocumentationHistory(Long bhcMedRecId, Long
	// bhcInvOrderId,String fileName, String documentId) throws CustomException;
}
