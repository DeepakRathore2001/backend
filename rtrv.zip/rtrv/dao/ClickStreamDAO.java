package com.healogics.rtrv.dao;

import com.healogics.rtrv.dto.ClickStreamReq;
import com.healogics.rtrv.exception.CustomException;

public interface ClickStreamDAO {
	public void saveClickStreamData(ClickStreamReq req)
			throws CustomException;
}
