package com.healogics.rtrv.enumeration;

public enum DocumentationViewName {
	PROVIDERORDER((String) "AtHomeProviderOrder (Interface)"), 
	PROGRESSNOTE((String) "AtHomeProgressNote (Interface)"),
	WOUNDASSESSMENT((String) "AtHomeWoundAssessment (Interface)"),
	DEBRIDEMENT((String) "AtHomeDebridement (Interface)");
	
	private String viewName;

	private DocumentationViewName(String viewName) {

		this.viewName = viewName;
	}

	public String value() {

		return this.viewName;
	}

	public static DocumentationViewName getEnumByValue(String val) {

		for (DocumentationViewName e : DocumentationViewName.values()) {
			if (val == e.viewName)
				return e;
		}
		return null;
	}
}
