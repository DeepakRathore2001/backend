package com.healogics.rtrv.enumeration;

public enum JobSavePdfFileName {
	PROVIDERORDER((String) "retrieveProviderOrderPDF"),
	PROGRESSNOTE((String) "retrieveProgressNotePDF"),
	WOUNDASSESSMENT((String) "retrieveWoundAssessmentPDF"),
	DEBRIDEMENT((String) "retrieveDebridementPDF");

	private String jobSavePdfFileName;

	private JobSavePdfFileName(String jobSavePdfFileName) {

		this.jobSavePdfFileName = jobSavePdfFileName;
	}

	public String value() {

		return this.jobSavePdfFileName;
	}

	public static JobSavePdfFileName getEnumByValue(String val) {

		for (JobSavePdfFileName e : JobSavePdfFileName.values()) {
			if (val == e.jobSavePdfFileName)
				return e;
		}
		return null;
	}
}
