package com.healogics.rtrv.constants;

public class BOConstants {

	private BOConstants() {
	}

	public static final String FAILED = "Failed";
	public static final String SUCCESS = "Success";
	public static final String FAILED_RESPONSE_CODE = "1";
	public static final String SUCCESS_RESPONSE_CODE = "0";
	public static final String NOT_FOUND_RESPONSE_CODE = "2";
	public static final String IHEAL_HOST_NAME = "host_name";
	public static final String IHEAL_LOGIN_URL = "iheal.login.url";
	public static final String IHEAL_LOGIN_BY_TOKEN_URL = "iheal.login.by.token.url";
	public static final String IHEAL_INSTANCE_TOKEN_URL = "iheal.instance.token.url";
	public static final String DOCUMENT_BASE_URL = "iheal.doc.base.url";
	public static final String MED_REC_DOCUMENT_BASE_URL = "iheal.med.rec.doc.base.url";
	public static final String IHEAL_LOGOUT_URL = "iheal.logout.url";
	public static final String IHEAL_PRIVATEKEY = "iheal.privatekey";
	public static final String JWT_EXPIRATION_TIME = "jwt.expirationtime";
	public static final String JWT_REFRESHTOKEN_EXPIRATION_TIME = "jwt.refreshtoken.exp.time";
	public static final String JWT_SECRETKEY = "jwt.secretkey";
	public static final String ERRORCODE = "errorCode";
	public static final String PRIVATE_KEY = "privateKey";
	public static final String ERRORMESSAGE = "errorMessage";
	public static final String CHECK_ERROR_MESSAGE = "The Old password and New password cannot be the same";
	public static final String ERROR_PASS_FIELDNAME = "fieldName";
	public static final String LOGIN_ERROR_MESSAGE = "We are currently working to resolve a technical issue. Please contact the help desk at 1-866-412-3680 (option 1).";
	public static final String UNKNOWN_ERRORCODE = "15";
	public static final String INVALIDKEY_ERRORCODE = "2";
	public static final String INVALID_ERRORCODE = "14";
	public static final String IHEAL_TCCONFIGSERVICE_URL = "iheal.configserviceurl";
	public static final String IHEAL_V2_URL = "iheal.accepttermsandcondition";
	public static final String IHEAL_CUSTOMSCAN_LIST_URL = "iheal.customscan.list.url";
	public static final String IHEAL_PROVIDERORDER_LIST_URL = "iheal.providerorder.list.url";
	public static final String IHEAL_PROGRESSNOTES_LIST_URL = "iheal.progressnotes.list.url";
	public static final String IHEAL_DEBRIDEMENTS_LIST_URL = "iheal.debridements.list.url";
	public static final String IHEAL_WOUND_LIST_URL = "iheal.wound.list.url";
	public static final String IHEAL_WOUND_ASSESSMENT_LIST_URL = "iheal.wound.assessment.list.url";
	public static final String IHEAL_FILE_GET_URL = "iheal.file.get.url";
	public static final String IHEAL_DOC_VIEW_PDF_REQ_URL = "iheal.doc.view.pdf.req.url";
	public static final String IHEAL_DOC_VIEW_PDF_GET_URL = "iheal.doc.view.pdf.get.url";
	public static final String IHEAL_CUSTOMSCAN_UPLOAD_URL = "iheal.customscan.upload.url";
	public static final String IHEAL_PASSWORDSET_URL = "iheal.passwordset";
	public static final String IHEAL_USERFACILITYGET_URL = "iheal.userFacilityListGet";
	public static final String CLINOP_SAVENOTIFICATION = "clinop.savenotification";
	public static final String CLINOP_DELETENOTIFICATION = "clinop.deletenotification";
	public static final String CLINOP_MIGRATIONKEY = "clinop.migrationKey";
	public static final String MESSAGETYPE = "Notification";
	public static final String MESSAGETYPE_DT = "Downtime";
	public static final String APPLICATIONTYPE = "Clinical_Optimization";
	public static final String NOTIFICATIONFLAG = "Active";
	public static final String NOTIFICATIONOFFFLAG = "Inactive";

	public static final String INVALID_DATE_RANGE_EXCEPTION = "Invalid Date Range Selected";
	public static final String GET_PATIENT_COUNT = "ds.getpatientCount";
	public static final String LOOKUP_PATIENT_COUNT = "ds.lookupCount";
	public static final String PATIENT_SYNC = "ds.patientSync";
	public static final String STATUS = "status";
	public static final String MESSAGE = "message";
	public static final String VISIT_SYNC = "ds.visitSync";
	public static final String POL_SYNC = "ds.polSync";
	public static final String WOUND_SYNC = "ds.woundSync";
	public static final String DEBRIDEMENT_SYNC = "ds.debridementSync";
	public static final String WOUNDASSESSMENT_SYNC = "ds.woundAssessmentSync";

	public static final String APPLICATIONTYPE_PTR = "PTR";
	public static final String PTR_CREATE_NOTIFICATION = "ptr.createnotification.url";
	public static final String PTR_UPDATE_NOTIFICATION = "ptr.updatenotification.url";
	public static final String PTR_DELETE_NOTIFICATION = "ptr.deletenotification.url";
	public static final String PTR_INTEGRAION_KEY = "ptr.integrationKey";

	public static final String APP_ENV = "app.env";
	public static final int PAGE_SIZE = 20;
	public static final String PDF_CLIENT_STATE = "Retr1@ve@pp";

	public static final String IHEAL_PATIENT_SEARCH_URL = "iheal.patientsearch.url";

	public static final String IHEAL_PATIENT_SEARCH_MAXPAGESIZE = "iheal.patientsearch.maxpagesize";
	public static final String IHEAL_DOCUMENT_VIEW_PDF_GET_URL = "iheal.document.view.pdf.get.url";
	public static final String IHEAL_USERFACILITIES_URL = "iheal.userfacilities.url";
	public static final String IHEAL_MED_REC_VIEW_PDF_GET_URL = "iheal.med.rec.doc.view.pdf.get.url";

	public static final String UNKNOWN_ERROR = "Unknown Error!";

	public static final int MASTER_NOTES_SIZE = 10;
	public static final double MASTER_NOTES_SIZE_DOUBLE = 10.0;

	public static final int MASTER_HISTORY_TIMELINE_SIZE = 5;
	public static final double MASTER_HISTORY_TIMELINE_SIZE_DOUBLE = 5.0;
	
	public static final String IHEAL_TEST_RESULTS_LIST_URL = "iheal.testresults.list.url";
	public static final String IHEAL_VISIT_DOCUMENT_LIST_URL = "iheal.visit.document.list.url";
	public static final String IHEAL_VISIT_LIST_URL = "iheal.visit.list.url";
	public static final String IHEAL_PATIENT_LOAD_URL = "iheal.patient.load.url";
	
	public static final String KERECIS_WAITING_FOR_DOCUMENTS_STATUS = "Waiting on Documents";
	public static final String KERECIS_PENDING_PRIOR_AUTH_STATUS = "Pending Prior Authorization";
	public static final String KERECIS_UNDER_APPEAL_STATUS = "Under Appeal";
	public static final String KERECIS_COMPLETED_STATUS = "Complete";
	public static final String KERECIS_CANCELED_STATUS = "Canceled";
	public static final String KERECIS_RECEIVED_STATUS = "Received";
	public static final String KERECIS_POST_APPLN_APPEAL_STATUS = "POST APPLICATION APPEAL";
	public static final String KERECIS_PRE_APPLN_APPEAL_STATUS = "PRE APPLICATION APPEAL";
	public static final String KERECIS_BILLING_SUPPORT_STATUS = "BILLING SUPPORT";
	
	public static final String RETRIEVE_NEW_STATUS = "New";
	public static final String RETRIEVE_RETURNED_STATUS = "Returned";
	public static final String RETRIEVE_SUBMITTED_STATUS = "Submitted";
	public static final String RETRIEVE_COMPLETED_STATUS = "Completed";
	public static final String RETRIEVE_PENDING_AUTH_STATUS = "Pending Auth";
	public static final String RETRIEVE_UNDER_APPEAL_STATUS = "Under Appeal";
	public static final String RETRIEVE_CANCELED_STATUS = "Canceled";
	
	public static final String NEW_STATUS_TEXT = "New chart has been added";
	public static final String RETURNED_STATUS_TEXT = "Chart returned";
	public static final String COMPLETED_STATUS_TEXT = "Chart completed";
	public static final String CANCELED_STATUS_TEXT = "Chart canceled";
	public static final String PENDING_AUTH_STATUS_TEXT = "Chart pending prior authentication";
	public static final String UNDER_APPEAL_STATUS_TEXT = "Chart under appeal";
	public static final String REQUESTED_DOCUMENT_TEXT = "Received document request from vendor";
	public static final String ORDER_STATUS_UPDATED_TEXT = "Order status updated";
	public static final String STATUS_DETAILS_UPDATED_TEXT = "Delay Reasons received from vendor";
	
	public static final String KERECIS_BASE_URL = "kerecis.base.url";
	public static final String WOUNDQ_BASE_URL = "woundq.base.url";
	public static final String KERECIS_APP_KEY = "kerecis.app.key";
	public static final String KERECIS_APP_SECRECT = "kerecis.app.secret";
	public static final String KERECIS_DOCUMENT_URL = "/document";
	public static final String WOUNDQ_DOCUMENT_URL = "woundq.document.url";
	public static final String KERECIS_DOCUMENT_UPDATE_URL = "/document/update";
	public static final String KERECIS_HOST_NAME = "kerecis.host.name";
	public static final String WOUNDQ_HOST_NAME = "woundq.host.name";
	public static final String WOUNDQ_APP_KEY = "woundq.app.key";
	public static final String WOUNDQ_APP_SECRECT = "woundq.app.secret";
	public static final String WOUNDQ_VENDOR_ID = "woundq.vendor.id";
	
	public static final String KERECIS_ORDER_INFO_URL = "kerecis.order.info.url";
	public static final String KERECIS_SEND_ORDER_INFO_UPDATE_URL = "iheal.userfacilities.url";
	
	public static final String DOC_SUCCESSFUL = "Successful";
	public static final String DOC_PENDING = "Pending";
	public static final String DOC_FAILED = "Failed";
	
	public static final String SOLVENTUM_BASE_URL = "solventum.base.url";
	public static final String SOLVENTUM_APP_KEY = "solventum.app.key";
	public static final String SOLVENTUM_DOC_NOTIFIER_API_URL = "solventum.doc.dotifier.url";
	public static final String SOLVENTUM_HOST_NAME = "solventum.host.name";
	
	public static final String APRIA_AUTH_URL = "apria.auth.api.url";
	public static final String APRIA_GRANT_TYPE = "apria.grant.type";
	public static final String APRIA_CLIENT_ID = "apria.client.id";
	public static final String APRIA_CLIENT_SECRET = "apria.client.secret";
	public static final String APRIA_SCOPE = "apria.scope";
	public static final String APRIA_DOC_NOTIFIER_URL = "apria.doc.notifier.url";
	
	public static final String NOT_FOUND = "Not found";
	
	public static final int CTP_VENDOR_ID = 3;
	public static final int NPWT_VENDOR_ID = 5;
	public static final int APRIA_VENDOR_ID = 2;
	public static final String IHEAL_MED_REC_LIST_URL = "iheal.med.rec.list.url";
	
}
