package com.healogics.rtrv.constants;

public class UtilConstants {

	private UtilConstants() {

    }
    public static final String TIMESTAMP_FORMAT_WITH_T = "yyyy-MM-dd'T'HH:mm:ssZ";
    public static final String PROPERTIES_DELIMETER = ":";
    
    public static final String USER_NAME = "userName";
    public static final String USER_ID = "userId";
    public static final String FACILITY_ID = "facilityId";
    public static final String BLUEBOOK_ID = "bluebookId";
    public static final String LOCATION_ID = "locationID";
    public static final String PATIENT_ID = "patientId";
    public static final String DEVICE_TYPE = "deviceType";
    public static final String DEVICE_ID = "deviceId";
    public static final String TIMESTAMP = "timestamp";
	public static final String ACTION = "action";
	
}
