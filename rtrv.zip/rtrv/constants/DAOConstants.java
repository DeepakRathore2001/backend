package com.healogics.rtrv.constants;

public class DAOConstants {
	private DAOConstants() {
	}
	public static final String FAILED = "Failed";
	public static final String SUCCESS = "Success";
	public static final int PAGE_SIZE = 20;
	public static final double PAGE_SIZE_DOUBLE = 20.0;
	
	public static final int NOTES_SIZE = 5;
	public static final double NOTES_SIZE_DOUBLE = 5.0;
	
	public static final int HISTORY_TIMELINE_SIZE = 5;
	public static final double HISTORY_TIMELINE_SIZE_DOUBLE = 5.0;
	
	public static final String ERRORCODE = "errorCode";
	public static final String ERRORMESSAGE = "errorMessage";
	public static final String PDF_CLIENT_STATE = "Retr1@ve@pp";
	
	public static final int MASTER_NOTES_SIZE = 10;
	public static final double MASTER_NOTES_SIZE_DOUBLE = 10.0;
	
	public static final int MASTER_HISTORY_TIMELINE_SIZE = 5;
	public static final double MASTER_HISTORY_TIMELINE_SIZE_DOUBLE = 5.0;
	
	public static final String SOLVENTUM_FULL_MR_REQUEST = "FullMRRequest";
	public static final String SOLVENTUM_PENDING_3RD_PARTY_VER = "Pending3rdPartyVerification";
	public static final String SOLVENTUM_SUB_CYCLE_1 = "SubCycle-1";
	public static final String SOLVENTUM_SUB_CYCLE_2 = "SubCycle-2";
	public static final String SOLVENTUM_SUB_CYCLE_3 = "SubCycle-3";
	public static final String SOLVENTUM_SUB_CYCLE_4 = "SubCycle-4";
	public static final String SOLVENTUM_ADDITIONAL_DOC_REQUIRED = "AdditionalDocumentationRequired";
	
	public static final String VENDOR_CLAIM_SUBMISSION_STATUS = "Claim Submission";
	public static final String VENDOR_ORDER_RELEASE_STATUS = "Order Release";
	public static final String VENDOR_SUB_CYCLE_1_STATUS = "Sub Cycle-1";
	public static final String VENDOR_SUB_CYCLE_2_STATUS = "Sub Cycle-2";
	public static final String VENDOR_SUB_CYCLE_3_STATUS = "Sub Cycle-3";
	public static final String VENDOR_SUB_CYCLE_4_STATUS = "Sub Cycle-4";
	public static final String VENDOR_ADDITIONAL_DOC_REQUIRED = "Additional Documentation Required";
	
	public static final Integer SOLVENTUM_VENDOR_ID=5;
	public static final String RETRIVE_NEW_STATUS = "New";
	
	
}
