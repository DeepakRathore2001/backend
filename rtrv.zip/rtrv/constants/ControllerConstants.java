package com.healogics.rtrv.constants;

public final class ControllerConstants {
	
	private ControllerConstants() {
	}

	public static final String TIMESTAMP = "timestamp";
	public static final String ACTION = "action";
	public static final String SUCCESS_CODE = "200";
	public static final String SUCCESS_DESC = "Success";
	public static final String LOGIN = "login";
	public static final String API_RESPONSE = "apiresponse";
	public static final String MSG_HEADER = "messageheader";
	public static final String RESPONSE = "Response";
	public static final String INVALID_CREDENTIALS = "Invalid Credentials";
	
	public static final String ZERO_ERROR_CODE = "0";
	public static final String INVALID_PARAMETERS = "Invalid parameters";
	public static final String INVALID_PARAMETERS_CODE = "400";
	public static final String ERROR_CODE_NUMBER = "501";
	
	public static final String INTERNAL_SERVER_ERROR_CODE = "500";
		
	public static final String ACCEPT_TERMSANDCONDITIONS = "Accept TermsAndConditions";
	
	public static final String DASHBOARD = "Dashboard";
	public static final String NEW_TASK_COUNT = "New Task Count";
	public static final String SAVE_SERVICE_LINE = "Save Service Line";
	public static final String BUILD_DETAILS = "build_details";
	public static final String TEAM_MEMBER_LIST = "Active Team Members List";
	
	public static final String FILTER_OPTIONS = "Filter Options";
	public static final String FILTER_DASHBOARD = "Filter Dashboard";
	public static final String ADMIN_FILTER_DASHBOARD = "Admin Filter Dashboard";
	public static final String EXPORT_EXCEL = "Export Excel";
	public static final String CHART_REVIEW_DETAILS = "Chart Review Details";
	public static final String SET_STATUS = "Set Status";
	
	public static final String STATUS_TIMELINE = "Status Timeline";
	public static final String SAVE_REQUEST = "Save Request";
	public static final String SUBMIT_REQUEST = "Submit Request";
	public static final String SAVE_NOTES = "Save Notes";
	public static final String NOTES_LIST = "Notes List";
	public static final String NOTE_BY_ID = "Note By Id";
	public static final String USER_ROLES = "User Roles";
	
	public static final String IHEAL_TEST_RESULTS_LIST = "IHeal Test Results List";
	public static final String IHEAL_CUSTOM_SCAN_LIST = "IHeal Custom Scan List";
	public static final String IHEAL_PROVIDER_ORDER_LIST = "IHeal Provider Order List";
	public static final String IHEAL_PROGRESS_NOTES_LIST = "IHeal Progress Notes List";
	public static final String IHEAL_DEBRIDEMENTS_LIST = "IHeal Debridements List";
	public static final String IHEAL_WOUNDASSESSMENT_LIST = "IHeal Wound Assessment List";
	public static final String MANUAL_ATTACHMENT_LIST = "Manual Attachment List";
	public static final String WOUND_LIST = "Wound List";
	public static final String VIEW_ATTACHMENT = "View Attachment";
	public static final String VIEW_MANUAL_ATTACHMENT = "View Manual Attachment";
	public static final String DOC_NOTIFICATION_SERVICE = "Document Notification";
	public static final String PDF_CLIENT_STATE = "Retr1@ve@pp";
	public static final String VIEW_REPORTS = "View Reports";
	public static final String NOTIFICATION_CREATION = "Notification Creation";
	public static final String NOTIFICATION_LIST = "Notification List";
	public static final String NOTIFICATION_UPDATE = "Notification Update";
	public static final String NOTIFICATION_DELETE = "Notification Delete";
	public static final String USER_NOTIFICATION = "User Notification";
	public static final String PATIENT_SEARCH = "Patient Search";
	public static final String UPDATE_PATIENT_DETAILS = "Update Patient Details";
	
	public static final String UPDATE_ASSIGNED_TO = "Update Assigned To";
	public static final String APP_NOTIFICATION_COUNT = "App Notification Count";
	public static final String UPDATE_APP_NOTIFICATION = "Update App Notification";
	public static final String APP_NOTIFICATIONS = "App Notifications";
	public static final String ADMINISTRATION_RETRIEVE_MEMBERS = "ADMINISTRATION RETRIEVE MEMBERS";
	public static final String ADMINISTRATION_RETRIEVE_USERS = "ADMINISTRATION RETRIEVE USERS";
	
	public static final String MODIFY_RECORD = "Modify Record";
	public static final String MASTER_MODIFY_RECORD = "Master Modify Record";
	public static final String CLICK_STREAM = "ClickStream";
	public static final String GET_DOC_URL = "Get Document URL";
	
	public static final String GET_DOC_UPLOAD_STATUS = "Get Doc Upload Status";
	public static final String UPDATE_COLOR_CODES = "Update Color Codes";
	
	public static final String UPDATE_CENTER_ASSIGNMENT_VALUES = "Update Center Assignment Values";
	public static final String UPDATE_RETRIEVE_USERS_TABLE = "Update Retrieve Users Table";
	public static final String UPDATE_RETRIEVE_MEMBERS_TABLE = "Update Retrieve Members Table";
	
	//CTP
	public static final String AUTHENTICATE = "Authenticate";
	public static final String GET_ORDER = "GetOrder";
	public static final String REQUEST_EDOCS = "RequestEDocs";
	public static final String GET_ATTACHMENT_REQUEST = "GetAttachmentRequest";
	public static final String GET_DOCUMENT_CONTENT = "GetDocumentContent";
	public static final String GET_ORDER_INFORMATION_UPDATES = "Update Order Information";
	
	public static final String ORDER_STATUS = "Order Status";
	
	public static final String IHEAL_USER_FACILITY_LIST_GET = "IHeal User Facility List Get";
	
	public static final String CTP_DASHBOARD = "CTP Dashboard";
	public static final String UNIFORM_DASHBOARD = "Uniform Dashboard";
	public static final String SAVE_MASTER_CHART_DETAILS = "Save Master Chart Details";
	public static final String SAVE_MASTER_NOTES = "Save Master Notes";
	public static final String MASTER_CHART_DETAIS = "Master Chart Details";
	public static final String MASTER_NOTES_LIST = "Master Notes List";
	public static final String MASTER_HISTORY_LIST = "Master History List";
	public static final String SUBMIT_MASTER_CHART = "Submit Master Chart";
	
	public static final String UNKNOWN_ERROR = "Unknown Error!";
	
	public static final String MASTER_BATCH_ASSIGNED_TO = "Master Batch Assigned To";
	public static final String MASTER_NOTE_BY_ID = "Master Note By Id";
	public static final String MASTER_UPDATE_APP_NOTIFICATION = "Master Update App Notification";
	public static final String MASTER_APP_NOTIFICATIONS = "Master App Notifications";
	public static final String MASTER_APP_NOTIFICATIONS_STATUS = "Master App Notifications Status";
	
	public static final String IHEAL_VISIT_DOCUMENT_LIST = "IHeal Visit Document List";
	public static final String IHEAL_VISIT_LIST_GET = "IHeal Visit List Get";
	public static final String GET_SAVED_ATTACHMENTS = "Get Saved Attachments";
	public static final String VIEW_SAVED_ATTACHMENTS = "View Saved Attachments";
	
	public static final String NOTES_ATTEMPT_DETAILS = "Notes Attempt Details";
	
	public static final String NPWT_REPORT = "NPWT Report";
	public static final String NPWT_REPORT_EXCEL = "NPWT Report Excel";
	public static final String NPWT_REPORT_FILTER_OPTIONS = "NPWT Report Filter Options";
	public static final String IHEAL_MED_REC_LIST = "IHeal Med Rec List";
	
	public static final String AWD_REPORT_FILTER_OPTIONS = "AWD Report Filter Options";
}
