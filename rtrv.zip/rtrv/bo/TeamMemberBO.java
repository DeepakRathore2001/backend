package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.TeamMemberRes;
import com.healogics.rtrv.exception.CustomException;

public interface TeamMemberBO {
	public TeamMemberRes getActiveTeamMebers() throws CustomException;
}
