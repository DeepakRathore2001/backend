package com.healogics.rtrv.bo.Impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.ClickStreamBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.ClickStreamDAO;
import com.healogics.rtrv.dto.ClickStreamReq;
import com.healogics.rtrv.dto.ClickStreamRes;
import com.healogics.rtrv.exception.CustomException;

@Service
public class ClickStreamBOImpl implements ClickStreamBO {
	private final Logger log = LoggerFactory.getLogger(ClickStreamBOImpl.class);

	private final ClickStreamDAO clickStreamDAO;
	
	@Autowired
	public ClickStreamBOImpl(ClickStreamDAO clickStreamDAO) {
		this.clickStreamDAO = clickStreamDAO;
	}

	@Override
	public ClickStreamRes saveClickStreamData(ClickStreamReq req) throws CustomException {
		ClickStreamRes res = new ClickStreamRes();

		try {
			clickStreamDAO.saveClickStreamData(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while saving clickstream data: {}", e.getMessage());
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.FAILED);
			
			throw new CustomException(e.getMessage());
		}
		return res;
	}
}
