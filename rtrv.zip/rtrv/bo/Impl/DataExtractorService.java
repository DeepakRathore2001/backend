package com.healogics.rtrv.bo.Impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.dao.DataExtractorDAO;
import com.healogics.rtrv.dao.DataExtractorDAO2;
import com.healogics.rtrv.dto.DateRange;
import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentStore;
import com.healogics.rtrv.entity.DocumentationHistory2;
import com.healogics.rtrv.entity.JobsHeartBeat;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.entity.PatientMedicalRecords;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.entity.UserNotes2;
import com.healogics.rtrv.utils.ExportExcelUtil;

@Service
@Configurable
public class DataExtractorService {

	private final Logger log = LoggerFactory.getLogger(DataExtractorService.class);

	@Autowired
	private DataExtractorDAO dataExtractorDAO;

	@Autowired
	private DataExtractorDAO2 dataExtractorDAO2;

	@Autowired
	private AWSS3FileUploadService fileUploadService;

	@Value("${csv.dataextract.doc.local.file.path}")
	private String dataExtractLocalPath;

	@Value("${csv.dataextract.doc.upload.s3.location}")
	private String dataExtractUploadS3Location;

	@Value("${aws.data.extract.arn.name}")
	private String dataExtractDataSolutionsS3Loc;

	// AppNotification
	@Value("${appnotification.excel.columns}")
	private String appNotificationColumns;
	
	@Value("${appnotification.excel.name}")
	private String appNotificationExcelName;
	
	@Value("${appnotification.table.name}")
	private String appNotificationTableName;
	
	@Value("${appnotification.job.name}")
	private String appNotificationJobName;
	
	// DocumentStore
	@Value("${documentstore.excel.columns}")
	private String documentStoreColumns;
	
	@Value("${documentstore.excel.name}")
	private String documentStoreExcelName;
	
	@Value("${documentstore.job.name}")
	private String documentStoreJobName;
	
	@Value("${documentstore.table.name}")
	private String documentStoreTableName;

	// DocumentationHistory
	@Value("${documentationhistory.excel.columns}")
	private String documentationHistoryColumns;

	@Value("${documentationhistory.excel.name}")
	private String documentationHistoryExcelName;
	
	@Value("${documentationhistory.table.name}")
	private String documentationHistoryTableName;
	
	@Value("${documentationhistory.job.name}")
	private String documentationHistoryJobName;

	// PatientMedicalRecords
	@Value("${patientmedicalrecords.excel.columns}")
	private String patientMedicalRecordsColumns;
	
	@Value("${patientmedicalrecords.excel.name}")
	private String patientMedicalRecordsExcelName;
	
	@Value("${patientmedicalrecords.table.name}")
	private String patientMedicalRecordsTableName;
	
	@Value("${patientmedicalrecords.job.name}")
	private String patientMedicalRecordsJobName;

	// UserNotes
	@Value("${usernotes.excel.columns}")
	private String userNotesColumns;
	
	@Value("${usernotes.excel.name}")
	private String userNotesExcelName;
	
	@Value("${usernotes.table.name}")
	private String userNotesTableName;
	
	@Value("${usernotes.job.name}")
	private String userNotesJobName;

	// NPWT Dashboard
	@Value("${npwtdashboard.excel.columns}")
	private String npwtDashboardColumns;
	
	@Value("${npwtdashboard.table.name}")
	private String npwtDashboardTableName;

	@Value("${npwtdashboard.excel.name}")
	private String npwtDashboardExcelName;
	
	@Value("${npwtdashboard.job.name}")
	private String npwtDashboardJobName;
	
	// CTP Dashboard
	@Value("${ctpdashboard.excel.columns}")
	private String ctpDashboardColumns;
	
	@Value("${ctpdashboard.excel.name}")
	private String ctpDashboardExcelName;
	
	@Value("${ctpdashboard.table.name}")
	private String ctpDashboardTableName;
	
	@Value("${ctpdashboard.job.name}")
	private String ctpDashboardJobName;

	// PrimaryKeyLookUp
	@Value("${primarykeylookup.excel.columns}")
	private String primaryKeyLookUpColumns;

	@Value("${primarykeylookup.excel.name}")
	private String primaryKeyLookUpExcelName;

	@Value("${primarykeylookup.table.name}")
	private String primaryKeyLookUpTableName;

	@Value("${primarykeylookup.job.name}")
	private String primaryKeyLookUpJobName;

	@Scheduled(cron = "${dataextractor.run.interval}")
	public void runDataExtractor() {
		log.info("DataExtractor started...");
		
		extractTableData();
	}
	
	private void extractTableData() {
		log.info("Extractng AppNotification Data");
		Instant appNotifyStartTime = Instant.now();

		Timestamp appNotifyExtractorTimestamp = null;
		Date currentTime = new Date();

		// Read dataExtractorTimestamp from DB
		JobsHeartBeat appNotifTable = null;
		try {
			appNotifTable = dataExtractorDAO.getJobDetails(appNotificationJobName,
					appNotificationTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusCTP(appNotifTable, appNotificationTableName,
					appNotifyStartTime, false,
					e.getMessage(), currentTime);
		}

		if (appNotifTable != null) {
			appNotifyExtractorTimestamp = appNotifTable.getEndTime();
			appNotifTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("appNotifyExtractorTimestamp : " + appNotifyExtractorTimestamp);

		// First Get AppNotification data from Database table
		List<MasterAppNotification> appNotifications = null;
		try {
			appNotifications = dataExtractorDAO2.extractAppNotificationData(
					appNotifyExtractorTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());

			saveDataExportStatusCTP(appNotifTable, appNotificationTableName,
					appNotifyStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (appNotifications != null && appNotifications.size() > 0) {
			
			log.debug("appNotifications.size : " +appNotifications.size());
			
			// Generate AppNotification CSV/Excel
			String geneatedAppNotifyExcelFileName = "";
			try {
				geneatedAppNotifyExcelFileName = ExportExcelUtil.generateAppNotificationsExcelCTP(
						appNotifications, appNotificationColumns, appNotificationExcelName,
						dataExtractLocalPath, false);
			} catch (Exception e) {
				log.error("Eception occured while generating AppNotification Excel: " + e.getMessage());

				saveDataExportStatusCTP(appNotifTable, appNotificationTableName, appNotifyStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedAppNotifyExcelFileName : " + geneatedAppNotifyExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedAppNotifyExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + appNotificationExcelFileNameCTP) : "
						+ (dataExtractLocalPath + geneatedAppNotifyExcelFileName));

				// Upload Extracted AppNotification to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedAppNotifyExcelFileName),
							(dataExtractLocalPath + geneatedAppNotifyExcelFileName))) {

						// Delete generated AppNotifcation Excel file from local
						// server
						/*
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedAppNotifyExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedAppNotifyExcelFileName);
						 * log.info("deleted file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedAppNotifyExcelFileName));
						 */
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusCTP(appNotifTable, appNotificationTableName, appNotifyStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusCTP(appNotifTable, appNotificationTableName, appNotifyStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusCTP(appNotifTable, appNotificationTableName, appNotifyStartTime, true,
					"No New Records", currentTime);
		}

		log.info("AppNotification Data Extract completed...");
		log.debug("--------------------------------------------------");

		// DocumentStatus
		log.info("Extractng DocumentStore Data...");
		Instant docStoreStartTime = Instant.now();

		Timestamp docStoreExtractorTimestamp = null;
		currentTime = new Date();

		// Read dataExtractorTimestamp from DB
		JobsHeartBeat docStoreTable = null;
		try {
			docStoreTable = dataExtractorDAO.getJobDetails(documentStoreJobName,
					documentStoreTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusCTP(docStoreTable, documentStoreTableName, docStoreStartTime, false,
					e.getMessage(), currentTime);
		}

		if (docStoreTable != null) {
			docStoreExtractorTimestamp = docStoreTable.getEndTime();
			docStoreTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("docStoreExtractorTimestamp : " + docStoreExtractorTimestamp);

		// First Get Document Status data from Database table
		List<DocumentStore> documentStoreList = null;
		try {
			documentStoreList = dataExtractorDAO2.extractDocumentStoreData(docStoreExtractorTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching Document Store Data: " + e.getMessage());

			saveDataExportStatusCTP(docStoreTable, documentStoreTableName, docStoreStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (documentStoreList != null && documentStoreList.size() > 0) {
			
			log.debug("documentStoreList.size : " +documentStoreList.size());
			
			// Generate Document Status CSV/Excel
			String geneatedDocStoreExcelFileName = "";
			try {
				geneatedDocStoreExcelFileName = ExportExcelUtil.generateDocumentStoreExcel(
						documentStoreList,
						documentStoreColumns, documentStoreExcelName, dataExtractLocalPath, false);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusCTP(docStoreTable, documentStoreTableName, docStoreStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedDocStoreExcelFileName : " + geneatedDocStoreExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedDocStoreExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedDocStoreExcelFileName) : "
						+ (dataExtractLocalPath + geneatedDocStoreExcelFileName));

				// Upload Extracted Document Status Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedDocStoreExcelFileName),
							(dataExtractLocalPath + geneatedDocStoreExcelFileName))) {

						// Delete generated AppNotifcation Excel file from local
						// server
						/*
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedDocStatusExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedDocStatusExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedDocStatusExcelFileName));
						 */
					}
				} catch (Exception e) {
					log.error("Exception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusCTP(docStoreTable, documentStoreTableName, docStoreStartTime,
							false, ("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusCTP(docStoreTable, documentStoreTableName, docStoreStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusCTP(docStoreTable, documentStoreTableName, docStoreStartTime, true,
					"No New Records", currentTime);
		}

		log.info("Document Status Data Extract completed...");
		log.debug("--------------------------------------------------");

		log.info("Extractng Documentation History Data...");
		Instant docHistoryStartTime = Instant.now();

		Timestamp docHistoryExtractorTimestamp = null;
		currentTime = new Date();

		// Read docHistoryExtractorTimestamp from DB
		JobsHeartBeat docHistoryTable = null;
		try {
			docHistoryTable = dataExtractorDAO.getJobDetails(documentationHistoryJobName,
					documentationHistoryTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusCTP(docHistoryTable, documentationHistoryTableName, docHistoryStartTime,
					false, e.getMessage(), currentTime);
		}

		if (docHistoryTable != null) {
			docHistoryExtractorTimestamp = docHistoryTable.getEndTime();
			docHistoryTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("docHistoryExtractorTimestamp : " + docHistoryExtractorTimestamp);

		// First Get data from Database table
		List<DocumentationHistory2> docHistoryList = null;
		try {
			docHistoryList = dataExtractorDAO2.extractDocHistoryData(docHistoryExtractorTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching Documentation History Data: " + e.getMessage());

			saveDataExportStatusCTP(docHistoryTable, documentationHistoryTableName, docHistoryStartTime,
					false, ("Exception occured while fetching Documentation History Data" + e.getMessage()), currentTime);
		}

		if (docHistoryList != null && docHistoryList.size() > 0) {
			
			log.debug("docHistoryList.size : " +docHistoryList.size());
			
			// Generate CSV/Excel
			String geneatedDocHistoryExcelFileName = "";
			try {
				geneatedDocHistoryExcelFileName = ExportExcelUtil.generateDocumentationHistoryExcel(
						docHistoryList, documentationHistoryColumns, documentationHistoryExcelName,
						dataExtractLocalPath, false);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusCTP(docHistoryTable, documentationHistoryTableName,
						docHistoryStartTime, false, ("Exception occured while generating Export" + e.getMessage()),
						currentTime);
			}

			log.debug("geneatedDocHistoryExcelFileName : " + geneatedDocHistoryExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedDocHistoryExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedDocHistoryExcelFileName) : "
						+ (dataExtractLocalPath + geneatedDocHistoryExcelFileName));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedDocHistoryExcelFileName),
							(dataExtractLocalPath + geneatedDocHistoryExcelFileName))) {

						// Delete generated Excel file from local server
						/*
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 */
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusCTP(docHistoryTable, documentationHistoryTableName,
							docHistoryStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusCTP(docHistoryTable, documentationHistoryTableName, docHistoryStartTime,
					true, "", currentTime);
		} else {
			saveDataExportStatusCTP(docHistoryTable, documentationHistoryTableName, docHistoryStartTime,
					true, "No New Records", currentTime);
		}

		log.info("Documentation History Data Extract completed...");
		log.debug("--------------------------------------------------");

		// patientMedicalRecords
		/*log.info("Extractng Patient Medical Records Data...");
		Instant pmrStartTime = Instant.now();

		Timestamp pmrTimestamp = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat pmrTable = null;
		try {
			pmrTable = dataExtractorDAO.getJobDetails(patientMedicalRecordsJobName,
					patientMedicalRecordsTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusCTP(pmrTable, patientMedicalRecordsTableName, pmrStartTime, false,
					e.getMessage(), currentTime);
		}

		if (pmrTable != null) {
			pmrTimestamp = pmrTable.getEndTime();
			pmrTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("pmrTimestamp : " + pmrTimestamp);

		// First Get data from Database table
		List<PatientMedicalRecords> pmrList = null;
		try {
			pmrList = dataExtractorDAO.extractPMRData(pmrTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching Patient Medical Record Data: " + e.getMessage());

			saveDataExportStatusCTP(pmrTable, patientMedicalRecordsTableName, pmrStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (pmrList != null && pmrList.size() > 0) {
			
			log.debug("pmrList.size : " +pmrList.size());
			
			// Generate CSV/Excel
			String geneatedPMRExcelFileName = "";
			try {
				geneatedPMRExcelFileName = ExportExcelUtil.generatePMRExcelCTP(pmrList,
						patientMedicalRecordsColumns, patientMedicalRecordsExcelName, dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusCTP(pmrTable, patientMedicalRecordsTableName, pmrStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedPMRExcelFileName : " + geneatedPMRExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedPMRExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedPMRExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedPMRExcelFileName));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedPMRExcelFileName),
							(dataExtractLocalPath + geneatedPMRExcelFileName))) {

						// Delete generated Excel file from local server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath + geneatedPMRExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedPMRExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath + geneatedPMRExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusCTP(pmrTable, patientMedicalRecordsTableName, pmrStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusCTP(pmrTable, patientMedicalRecordsTableName, pmrStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(pmrTable, patientMedicalRecordsTableName, pmrStartTime, true,
					"No New Records", currentTime);
		}

		log.info("Patient Medical Records Data Extract completed...");
		log.debug("--------------------------------------------------");*/

		// CTP Dashboard
		log.info("Extractng CTP Dashboard Data...");
		Instant ctpDashboardStartTime = Instant.now();

		Timestamp ctpDashboardTimestamp = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat ctpDashboardTable = null;
		try {
			ctpDashboardTable = dataExtractorDAO.getJobDetails(
					ctpDashboardJobName, ctpDashboardTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusCTP(ctpDashboardTable, ctpDashboardTableName,
					ctpDashboardStartTime, false,
					e.getMessage(), currentTime);
		}

		if (ctpDashboardTable != null) {
			ctpDashboardTimestamp = ctpDashboardTable.getEndTime();
			ctpDashboardTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("ctpDashboardTimestamp : " + ctpDashboardTimestamp);

		// First Get data from Database table
		List<CTPDashboard > ctpDashboardList = null;
		try {
			ctpDashboardList = dataExtractorDAO2.extractCTPDashboardData(ctpDashboardTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching CTP Dashboard Data: " + e.getMessage());

			saveDataExportStatusCTP(ctpDashboardTable, ctpDashboardTableName, ctpDashboardStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (ctpDashboardList != null && ctpDashboardList.size() > 0) {
			
			log.debug("ctpDashboardList.size : " +ctpDashboardList.size());
			
			// Generate CSV/Excel
			String geneatedCTPDashboardExcelFileName = "";
			try {
				geneatedCTPDashboardExcelFileName = ExportExcelUtil.generateCTPDashboardExcel(ctpDashboardList,
						ctpDashboardColumns, ctpDashboardExcelName, dataExtractLocalPath, false);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusCTP(ctpDashboardTable, ctpDashboardTableName, ctpDashboardStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedCTPDashboardExcelFileName : " + geneatedCTPDashboardExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedCTPDashboardExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedCTPDashboardExcelFileName) : "
						+ (dataExtractLocalPath + geneatedCTPDashboardExcelFileName));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedCTPDashboardExcelFileName),
							(dataExtractLocalPath + geneatedCTPDashboardExcelFileName))) {

					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusCTP(ctpDashboardTable, ctpDashboardTableName, ctpDashboardStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}

			saveDataExportStatusCTP(ctpDashboardTable, ctpDashboardTableName, ctpDashboardStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusCTP(ctpDashboardTable, ctpDashboardTableName, ctpDashboardStartTime, true,
					"No New Records", currentTime);
		}

		log.info("CTP Dashboard Data Extract completed...");
		log.debug("-------------------------------------");

		// UserNotes
		log.info("Extracting User Notes Data...");
		Instant userNotesStartTime = Instant.now();

		Timestamp userNotesTimestamp = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat userNotesTable = null;
		try {
			userNotesTable = dataExtractorDAO.getJobDetails(userNotesJobName, userNotesTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusCTP(userNotesTable, userNotesTableName, userNotesStartTime, false,
					e.getMessage(), currentTime);
		}

		if (userNotesTable != null) {
			userNotesTimestamp = userNotesTable.getEndTime();
			userNotesTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("userNotesTimestamp : " + userNotesTimestamp);

		// First Get data from Database table
		List<UserNotes2> userNotesList = null;
		try {
			userNotesList = dataExtractorDAO2.extractUserNotesData(userNotesTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching User Notes Data: " + e.getMessage());

			saveDataExportStatusCTP(userNotesTable, userNotesTableName, userNotesStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (userNotesList != null && userNotesList.size() > 0) {
			log.debug("userNotesListCTP.size : " +userNotesList.size());
			
			// Generate CSV/Excel
			String geneatedUserNotesExcelFileName = "";
			try {
				geneatedUserNotesExcelFileName = ExportExcelUtil.generateUserNotesExcel(userNotesList,
						userNotesColumns, userNotesExcelName, dataExtractLocalPath, false);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusCTP(userNotesTable, userNotesTableName, userNotesStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedUserNotesExcelFileName : " + geneatedUserNotesExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedUserNotesExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedUserNotesExcelFileName) : "
						+ (dataExtractLocalPath + geneatedUserNotesExcelFileName));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedUserNotesExcelFileName),
							(dataExtractLocalPath + geneatedUserNotesExcelFileName))) {

						// Delete generated Excel file from local server
						/*
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedUserNotesExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedUserNotesExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedUserNotesExcelFileName));
						 */
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusCTP(userNotesTable, userNotesTableName, userNotesStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusCTP(userNotesTable, userNotesTableName, userNotesStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusCTP(userNotesTable, userNotesTableName, userNotesStartTime, true,
					"No New Records", currentTime);
		}

		log.info("User Notes Data Extract completed...");
		log.debug("-------------------------------------");
		
		// Uniform Dashboard
		log.info("Extractng NPWT Dashboard Data...");
		Instant npwtDashboardStartTime = Instant.now();

		Timestamp npwtDashboardTimestamp = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat npwtDashboardTable = null;
		try {
			npwtDashboardTable = dataExtractorDAO.getJobDetailsNPWT(npwtDashboardJobName, npwtDashboardTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
					e.getMessage(), currentTime);
		}

		if (npwtDashboardTable != null) {
			npwtDashboardTimestamp = npwtDashboardTable.getEndTime();
			npwtDashboardTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("npwtDashboardTimestamp : " + npwtDashboardTimestamp);

		// First Get data from Database table
		List<UniformDashboard> npwtDashboardList = null;
		try {
			npwtDashboardList = dataExtractorDAO2.extractNPWTDashboardData(npwtDashboardTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching NPWT Dashboard Data: " + e.getMessage());

			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (npwtDashboardList != null && npwtDashboardList.size() > 0) {
			// Generate CSV/Excel
			String geneatedNPWTDashboardExcelFileName = "";
			try {
				geneatedNPWTDashboardExcelFileName = ExportExcelUtil.generateNPWTDashboardExcel(npwtDashboardList,
						npwtDashboardColumns, npwtDashboardExcelName, dataExtractLocalPath, false);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedNPWTDashboardExcelFileName : " + geneatedNPWTDashboardExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedNPWTDashboardExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName) : "
						+ (dataExtractLocalPath + geneatedNPWTDashboardExcelFileName));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedNPWTDashboardExcelFileName),
							(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName))) {

						// Delete generated Excel file from local server
						/*
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedAWDDashboardExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedAWDDashboardExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedAWDDashboardExcelFileName));
						 */
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}

			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, true,
					"No New Records", currentTime);
		}

		log.info("NPWTDashboard Data Extract completed...");
		log.debug("-------------------------------------");

		// PrimaryKeyLookUp
		log.info("Extracting Primary Key Look Up  Data...");
		Instant primaryKeyLookupStartTimeNPWT = Instant.now();

		Timestamp primaryKeyLookupExtractorTimestampNPWT = null;
		currentTime = new Date();

		// Read docHistoryExtractorTimestamp from DB
		JobsHeartBeat primayKeyLookupTableNPWT = null;
		try {
			primayKeyLookupTableNPWT = dataExtractorDAO.getJobDetailsNPWT(primaryKeyLookUpJobName,
					primaryKeyLookUpTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, false, e.getMessage(), currentTime);
		}

		if (primayKeyLookupTableNPWT != null) {
			primaryKeyLookupExtractorTimestampNPWT = primayKeyLookupTableNPWT.getEndTime();
			primayKeyLookupTableNPWT.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("primaryKeyLookupExtractorTimestampNPWT : " + primaryKeyLookupExtractorTimestampNPWT);

		// First Get data from Database table
		List<PrimaryKeyLookup> primaryKeyLookupListNPWT = null;
		try {
			primaryKeyLookupListNPWT = dataExtractorDAO2
					.extractPrimaryKeyLookupDataNPWT(primaryKeyLookupExtractorTimestampNPWT);
		} catch (Exception e) {
			log.error("Exception occured while fetching Primary Key Look Up Data: " + e.getMessage());

			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, false, ("Exception occured while fetching Data" + e.getMessage()),
					currentTime);
		}

		if (primaryKeyLookupListNPWT != null && primaryKeyLookupListNPWT.size() > 0) {
			// Generate CSV/Excel
			String geneatedPrimaryKeyLookupExcelFileNameNPWT = "";
			try {
				geneatedPrimaryKeyLookupExcelFileNameNPWT = ExportExcelUtil.generatePrimaryKeyLookupExcelNPWT(
						primaryKeyLookupListNPWT, primaryKeyLookUpColumns, primaryKeyLookUpExcelName,
						dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
						primaryKeyLookupStartTimeNPWT, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedPrimaryKeyLookupExcelFileNameNPWT : " + geneatedPrimaryKeyLookupExcelFileNameNPWT);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedPrimaryKeyLookupExcelFileNameNPWT.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedPrimaryKeyLookupExcelFileNameNPWT),
							(dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT))) {

						// Delete generated Excel file from local server
						/*
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 */
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
							primaryKeyLookupStartTimeNPWT, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, true, "", currentTime);
		} else {
			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, true, "No New Records", currentTime);
		}

		log.info("Primary Key Look Up Data Extract completed...");
		log.debug("--------------------------------------------------");

	}
	
	/*private void executeNPWTDashboard() {
		log.info("Extractng AppNotification Data...");
		Instant appNotifyStartTime = Instant.now();

		Timestamp appNotifyExtractorTimestamp = null;
		Date currentTime = new Date();

		// Read dataExtractorTimestamp from DB
		JobsHeartBeat npwtAppNotifTable = null;
		try {
			npwtAppNotifTable = dataExtractorDAO.getJobDetailsNPWT(appNotificationJobNameNPWT,
					appNotificationTableNameNPWT);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(npwtAppNotifTable, appNotificationTableNameNPWT, appNotifyStartTime, false,
					e.getMessage(), currentTime);
		}

		if (npwtAppNotifTable != null) {
			appNotifyExtractorTimestamp = npwtAppNotifTable.getEndTime();
			npwtAppNotifTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("appNotifyExtractorTimestamp : " + appNotifyExtractorTimestamp);

		// First Get AppNotification data from Database table
		List<AppNotifications> appNotificationsNPWT = null;
		try {
			appNotificationsNPWT = dataExtractorDAO2.extractAppNotificationDataNPWT(appNotifyExtractorTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());

			saveDataExportStatusNPWT(npwtAppNotifTable, appNotificationTableNameNPWT, appNotifyStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (appNotificationsNPWT != null && appNotificationsNPWT.size() > 0) {
			// Generate AppNotification CSV/Excel
			String geneatedAppNotifyExcelFileNameNPWT = "";
			try {
				geneatedAppNotifyExcelFileNameNPWT = ExportExcelUtil.generateAppNotificationsExcelNPWT(
						appNotificationsNPWT, appNotificationColumnsNPWT, appNotificationExcelNameNPWT,
						dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Eception occured while generating AppNotification Excel: " + e.getMessage());

				saveDataExportStatusNPWT(npwtAppNotifTable, appNotificationTableNameNPWT, appNotifyStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedAppNotifyExcelFileName : " + geneatedAppNotifyExcelFileNameNPWT);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedAppNotifyExcelFileNameNPWT.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + appNotificationExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedAppNotifyExcelFileNameNPWT));

				// Upload Extracted AppNotification to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedAppNotifyExcelFileNameNPWT),
							(dataExtractLocalPath + geneatedAppNotifyExcelFileNameNPWT))) {

						// Delete generated AppNotifcation Excel file from local
						// server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedAppNotifyExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedAppNotifyExcelFileName);
						 * log.info("deleted file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedAppNotifyExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(npwtAppNotifTable, appNotificationTableNameNPWT, appNotifyStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(npwtAppNotifTable, appNotificationTableNameNPWT, appNotifyStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(npwtAppNotifTable, appNotificationTableNameNPWT, appNotifyStartTime, true,
					"No New Records", currentTime);
		}

		log.info("AppNotification Data Extract completed...");
		log.debug("--------------------------------------------------");

		// DocumentStatus
		log.info("Extractng DocumentStatus Data...");
		Instant docStoreStartTimeNPWT = Instant.now();

		Timestamp docStoreExtractorTimestampNPWT = null;
		currentTime = new Date();

		// Read dataExtractorTimestamp from DB
		JobsHeartBeat docStoreTableNPWT = null;
		try {
			docStoreTableNPWT = dataExtractorDAO.getJobDetailsNPWT(documentStoreJobNameNPWT,
					documentStoreTableNameNPWT);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(docStoreTableNPWT, documentStoreTableNameNPWT, docStoreStartTimeNPWT, false,
					e.getMessage(), currentTime);
		}

		if (docStoreTableNPWT != null) {
			docStoreExtractorTimestampNPWT = docStoreTableNPWT.getEndTime();
			docStoreTableNPWT.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("docStatusExtractorTimestampNPWT : " + docStoreExtractorTimestampNPWT);

		// First Get Document Status data from Database table
		List<DocumentStore> documentStoreListNPWT = null;
		try {
			documentStoreListNPWT = dataExtractorDAO2.extractDocumentStoreDataNPWT(docStoreExtractorTimestampNPWT);
		} catch (Exception e) {
			log.error("Exception occured while fetching Document Store Data: " + e.getMessage());

			saveDataExportStatusNPWT(docStoreTableNPWT, documentStoreTableNameNPWT, docStoreStartTimeNPWT, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (documentStoreListNPWT != null && documentStoreListNPWT.size() > 0) {
			// Generate Document Status CSV/Excel
			String geneatedDocStoreExcelFileName = "";
			try {
				geneatedDocStoreExcelFileName = ExportExcelUtil.generateDocumentStoreExcelNPWT(documentStoreListNPWT,
						documentStoreColumnsNPWT, documentStoreExcelNameNPWT, dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(docStoreTableNPWT, documentStoreTableNameNPWT, docStoreStartTimeNPWT, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedDocStoreExcelFileName : " + geneatedDocStoreExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedDocStoreExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedDocStoreExcelFileName) : "
						+ (dataExtractLocalPath + geneatedDocStoreExcelFileName));

				// Upload Extracted Document Status Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedDocStoreExcelFileName),
							(dataExtractLocalPath + geneatedDocStoreExcelFileName))) {

						// Delete generated AppNotifcation Excel file from local
						// server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedDocStatusExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedDocStatusExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedDocStatusExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Exception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(docStoreTableNPWT, documentStoreTableNameNPWT, docStoreStartTimeNPWT,
							false, ("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(docStoreTableNPWT, documentStoreTableNameNPWT, docStoreStartTimeNPWT, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(docStoreTableNPWT, documentStoreTableNameNPWT, docStoreStartTimeNPWT, true,
					"No New Records", currentTime);
		}

		log.info("Document Status Data Extract completed...");
		log.debug("--------------------------------------------------");

		log.info("Extractng Documentation History Data...");
		Instant docHistoryStartTimeNPWT = Instant.now();

		Timestamp docHistoryExtractorTimestampNPWT = null;
		currentTime = new Date();

		// Read docHistoryExtractorTimestamp from DB
		JobsHeartBeat docHistoryTableNPWT = null;
		try {
			docHistoryTableNPWT = dataExtractorDAO.getJobDetailsNPWT(documentationHistoryJobNameNPWT,
					documentationHistoryTableNameNPWT);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT, docHistoryStartTimeNPWT,
					false, e.getMessage(), currentTime);
		}

		if (docHistoryTableNPWT != null) {
			docHistoryExtractorTimestampNPWT = docHistoryTableNPWT.getEndTime();
			docHistoryTableNPWT.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("docHistoryExtractorTimestampNPWT : " + docHistoryExtractorTimestampNPWT);

		// First Get data from Database table
		List<DocumentationHistory2> docHistoryListNPWT = null;
		try {
			docHistoryListNPWT = dataExtractorDAO2.extractDocHistoryDataNPWT(docHistoryExtractorTimestampNPWT);
		} catch (Exception e) {
			log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());

			saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT, docHistoryStartTimeNPWT,
					false, ("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (docHistoryListNPWT != null && docHistoryListNPWT.size() > 0) {
			// Generate CSV/Excel
			String geneatedDocHistoryExcelFileNameNPWT = "";
			try {
				geneatedDocHistoryExcelFileNameNPWT = ExportExcelUtil.generateDocumentationHistoryExcelNPWT(
						docHistoryListNPWT, documentationHistoryColumnsNPWT, documentationHistoryExcelNameNPWT,
						dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT,
						docHistoryStartTimeNPWT, false, ("Exception occured while generating Export" + e.getMessage()),
						currentTime);
			}

			log.debug("geneatedDocHistoryExcelFileNameNPWT : " + geneatedDocHistoryExcelFileNameNPWT);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedDocHistoryExcelFileNameNPWT.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedDocHistoryExcelFileNameNPWT),
							(dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT))) {

						// Delete generated Excel file from local server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT,
							docHistoryStartTimeNPWT, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT, docHistoryStartTimeNPWT,
					true, "", currentTime);
		} else {
			saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT, docHistoryStartTimeNPWT,
					true, "No New Records", currentTime);
		}

		log.info("Documentation History Data Extract completed...");
		log.debug("--------------------------------------------------");

		// patientMedicalRecords
		log.info("Extractng Patient Medical Records Data...");
		Instant pmrStartTimeNPWT = Instant.now();

		Timestamp pmrTimestampNPWT = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat pmrTableNPWT = null;
		try {
			pmrTableNPWT = dataExtractorDAO.getJobDetailsNPWT(patientMedicalRecordsJobNameNPWT,
					patientMedicalRecordsTableNameNPWT);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(pmrTableNPWT, patientMedicalRecordsTableNameNPWT, pmrStartTimeNPWT, false,
					e.getMessage(), currentTime);
		}

		if (pmrTableNPWT != null) {
			pmrTimestampNPWT = pmrTableNPWT.getEndTime();
			pmrTableNPWT.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("pmrTimestamp : " + pmrTimestampNPWT);

		// First Get data from Database table
		List<PatientMedicalRecords> pmrListNPWT = null;
		try {
			pmrListNPWT = dataExtractorDAO.extractPMRDataNPWT(pmrTimestampNPWT);
		} catch (Exception e) {
			log.error("Exception occured while fetching Patient Medical Record Data: " + e.getMessage());

			saveDataExportStatusNPWT(pmrTableNPWT, patientMedicalRecordsTableNameNPWT, pmrStartTimeNPWT, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (pmrListNPWT != null && pmrListNPWT.size() > 0) {
			// Generate CSV/Excel
			String geneatedPMRExcelFileNameNPWT = "";
			try {
				geneatedPMRExcelFileNameNPWT = ExportExcelUtil.generatePMRExcelNPWT(pmrListNPWT,
						patientMedicalRecordsColumnsNPWT, patientMedicalRecordsExcelNameNPWT, dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(pmrTableNPWT, patientMedicalRecordsTableNameNPWT, pmrStartTimeNPWT, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedPMRExcelFileNameNPWT : " + geneatedPMRExcelFileNameNPWT);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedPMRExcelFileNameNPWT.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedPMRExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedPMRExcelFileNameNPWT));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedPMRExcelFileNameNPWT),
							(dataExtractLocalPath + geneatedPMRExcelFileNameNPWT))) {

						// Delete generated Excel file from local server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath + geneatedPMRExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedPMRExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath + geneatedPMRExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(pmrTableNPWT, patientMedicalRecordsTableNameNPWT, pmrStartTimeNPWT, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(pmrTableNPWT, patientMedicalRecordsTableNameNPWT, pmrStartTimeNPWT, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(pmrTableNPWT, patientMedicalRecordsTableNameNPWT, pmrStartTimeNPWT, true,
					"No New Records", currentTime);
		}

		log.info("Patient Medical Records Data Extract completed...");
		log.debug("--------------------------------------------------");

		// Uniform Dashboard
		log.info("Extractng NPWT Dashboard Data...");
		Instant npwtDashboardStartTime = Instant.now();

		Timestamp npwtDashboardTimestamp = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat npwtDashboardTable = null;
		try {
			npwtDashboardTable = dataExtractorDAO.getJobDetailsNPWT(npwtDashboardJobName, npwtDashboardTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
					e.getMessage(), currentTime);
		}

		if (npwtDashboardTable != null) {
			npwtDashboardTimestamp = npwtDashboardTable.getEndTime();
			npwtDashboardTable.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("npwtDashboardTimestamp : " + npwtDashboardTimestamp);

		// First Get data from Database table
		List<UniformDashboard> npwtDashboardList = null;
		try {
			npwtDashboardList = dataExtractorDAO2.extractNPWTDashboardData(npwtDashboardTimestamp);
		} catch (Exception e) {
			log.error("Exception occured while fetching NPWT Dashboard Data: " + e.getMessage());

			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (npwtDashboardList != null && npwtDashboardList.size() > 0) {
			// Generate CSV/Excel
			String geneatedNPWTDashboardExcelFileName = "";
			try {
				geneatedNPWTDashboardExcelFileName = ExportExcelUtil.generateNPWTDashboardExcel(npwtDashboardList,
						npwtDashboardColumns, npwtDashboardExcelName, dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedNPWTDashboardExcelFileName : " + geneatedNPWTDashboardExcelFileName);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedNPWTDashboardExcelFileName.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName) : "
						+ (dataExtractLocalPath + geneatedNPWTDashboardExcelFileName));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedNPWTDashboardExcelFileName),
							(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName))) {

						// Delete generated Excel file from local server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedAWDDashboardExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedAWDDashboardExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedAWDDashboardExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}

			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(npwtDashboardTable, npwtDashboardTableName, npwtDashboardStartTime, true,
					"No New Records", currentTime);
		}

		log.info("NPWTDashboard Data Extract completed...");
		log.debug("-------------------------------------");

		// PrimaryKeyLookUp
		log.info("Extracting Primary Key Look Up  Data...");
		Instant primaryKeyLookupStartTimeNPWT = Instant.now();

		Timestamp primaryKeyLookupExtractorTimestampNPWT = null;
		currentTime = new Date();

		// Read docHistoryExtractorTimestamp from DB
		JobsHeartBeat primayKeyLookupTableNPWT = null;
		try {
			primayKeyLookupTableNPWT = dataExtractorDAO.getJobDetailsNPWT(primaryKeyLookUpJobName,
					primaryKeyLookUpTableName);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, false, e.getMessage(), currentTime);
		}

		if (primayKeyLookupTableNPWT != null) {
			primaryKeyLookupExtractorTimestampNPWT = primayKeyLookupTableNPWT.getEndTime();
			primayKeyLookupTableNPWT.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("primaryKeyLookupExtractorTimestampNPWT : " + primaryKeyLookupExtractorTimestampNPWT);

		// First Get data from Database table
		List<PrimaryKeyLookup> primaryKeyLookupListNPWT = null;
		try {
			primaryKeyLookupListNPWT = dataExtractorDAO2
					.extractPrimaryKeyLookupDataNPWT(primaryKeyLookupExtractorTimestampNPWT);
		} catch (Exception e) {
			log.error("Exception occured while fetching Primary Key Look Up Data: " + e.getMessage());

			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, false, ("Exception occured while fetching Data" + e.getMessage()),
					currentTime);
		}

		if (primaryKeyLookupListNPWT != null && primaryKeyLookupListNPWT.size() > 0) {
			// Generate CSV/Excel
			String geneatedPrimaryKeyLookupExcelFileNameNPWT = "";
			try {
				geneatedPrimaryKeyLookupExcelFileNameNPWT = ExportExcelUtil.generatePrimaryKeyLookupExcelNPWT(
						primaryKeyLookupListNPWT, primaryKeyLookUpColumns, primaryKeyLookUpExcelName,
						dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
						primaryKeyLookupStartTimeNPWT, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedPrimaryKeyLookupExcelFileNameNPWT : " + geneatedPrimaryKeyLookupExcelFileNameNPWT);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedPrimaryKeyLookupExcelFileNameNPWT.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedPrimaryKeyLookupExcelFileNameNPWT),
							(dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT))) {

						// Delete generated Excel file from local server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedDocHistoryExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(docHistoryTableNPWT, documentationHistoryTableNameNPWT,
							docHistoryStartTimeNPWT, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, true, "", currentTime);
		} else {
			saveDataExportStatusNPWT(primayKeyLookupTableNPWT, primaryKeyLookUpTableName,
					primaryKeyLookupStartTimeNPWT, true, "No New Records", currentTime);
		}

		log.info("Primary Key Look Up Data Extract completed...");
		log.debug("--------------------------------------------------");

		// UserNotes
		log.info("Extracting User Notes Data...");
		Instant userNotesStartTimeNPWT = Instant.now();

		Timestamp userNotesTimestampNPWT = null;
		currentTime = new Date();

		// Read pmrTimestamp from DB
		JobsHeartBeat userNotesTableNPWT = null;
		try {
			userNotesTableNPWT = dataExtractorDAO.getJobDetailsNPWT(userNotesJobNameNPWT, userNotesTableNameNPWT);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage());

			saveDataExportStatusNPWT(userNotesTableNPWT, userNotesTableNameNPWT, userNotesStartTimeNPWT, false,
					e.getMessage(), currentTime);
		}

		if (userNotesTableNPWT != null) {
			userNotesTimestampNPWT = userNotesTableNPWT.getEndTime();
			userNotesTableNPWT.setStartTime(new Timestamp(System.currentTimeMillis()));
		}

		log.debug("userNotesTimestampNPWT : " + userNotesTimestampNPWT);

		// First Get data from Database table
		List<UserNotes2> userNotesListNPWT = null;
		try {
			userNotesListNPWT = dataExtractorDAO2.extractUserNotesDataNPWT(userNotesTimestampNPWT);
		} catch (Exception e) {
			log.error("Exception occured while fetching User Notes Data: " + e.getMessage());

			saveDataExportStatusNPWT(userNotesTableNPWT, userNotesTableNameNPWT, userNotesStartTimeNPWT, false,
					("Exception occured while fetching Data" + e.getMessage()), currentTime);
		}

		if (userNotesListNPWT != null && userNotesListNPWT.size() > 0) {
			// Generate CSV/Excel
			String geneatedUserNotesExcelFileNameNPWT = "";
			try {
				geneatedUserNotesExcelFileNameNPWT = ExportExcelUtil.generateUserNotesExcelNPWT(userNotesListNPWT,
						userNotesColumnsNPWT, userNotesExcelNameNPWT, dataExtractLocalPath);
			} catch (Exception e) {
				log.error("Exception occured: " + e.getMessage());

				saveDataExportStatusNPWT(userNotesTableNPWT, userNotesTableNameNPWT, userNotesStartTimeNPWT, false,
						("Exception occured while generating Export" + e.getMessage()), currentTime);
			}

			log.debug("geneatedUserNotesExcelFileNameNPWT : " + geneatedUserNotesExcelFileNameNPWT);

			// If Excel file generated
			// Upload Excel from server to AWS S3
			if (!geneatedUserNotesExcelFileNameNPWT.isEmpty()) {

				log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
				log.debug("(dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT) : "
						+ (dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT));

				// Upload Extracted Excel to AWS S3 bucket
				try {
					if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
							(dataExtractUploadS3Location + geneatedUserNotesExcelFileNameNPWT),
							(dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT))) {

						// Delete generated Excel file from local server
						
						 * log.info("Deleting file from path:"
						 * +(dataExtractLocalPath +
						 * geneatedUserNotesExcelFileName));
						 * deleteLocalFile(dataExtractLocalPath +
						 * geneatedUserNotesExcelFileName);
						 * log.info("deleted CSV file from path: "
						 * +(dataExtractLocalPath +
						 * geneatedUserNotesExcelFileName));
						 
					}
				} catch (Exception e) {
					log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

					saveDataExportStatusNPWT(userNotesTableNPWT, userNotesTableNameNPWT, userNotesStartTimeNPWT, false,
							("Exception occured while Exporting to AWS S3" + e.getMessage()), currentTime);
				}
			}
			saveDataExportStatusNPWT(userNotesTableNPWT, userNotesTableNameNPWT, userNotesStartTimeNPWT, true, "",
					currentTime);
		} else {
			saveDataExportStatusNPWT(userNotesTableNPWT, userNotesTableNameNPWT, userNotesStartTimeNPWT, true,
					"No New Records", currentTime);
		}

		log.info("User Notes Data Extract completed...");
		log.debug("-------------------------------------");

	}*/

	private void saveDataExportStatusNPWT(JobsHeartBeat jobTable, String tableName, Instant appNotifyStartTime,
			boolean isSuccess, String errorMessage, Date currentTime) {

		if (jobTable == null) {
			return;
		}

		jobTable.setEndTime(new Timestamp(System.currentTimeMillis()));

		Duration appNotifyDuration = Duration.between(appNotifyStartTime, Instant.now());
		Long appNotifyDurationInMilles = appNotifyDuration.toMillis();

		Long minutes = TimeUnit.MILLISECONDS.toMinutes(appNotifyDurationInMilles);
		Long seconds = TimeUnit.MILLISECONDS.toSeconds(appNotifyDurationInMilles);

		jobTable.setDurationMillisecs(appNotifyDurationInMilles.intValue());
		jobTable.setDurationMins(minutes.intValue());
		jobTable.setDurationSecs(seconds.intValue());

		log.info("tableName: " + tableName);
		log.info("Processing time in ms: " + appNotifyDurationInMilles);
		log.info("Processing time in seconds: " + seconds);
		log.info("Processing time in minutes: " + minutes);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(currentTime);
		calendar.add(Calendar.DATE, 1);
		Timestamp nextScheduledAt = new Timestamp(calendar.getTimeInMillis());
		log.info("nextScheduledAt: " + nextScheduledAt);

		jobTable.setNextScheduledAt(nextScheduledAt);

		if (isSuccess) {
			jobTable.setStatus("Success");
			jobTable.setErrorMessage("Success");
		} else {
			jobTable.setStatus("Failed");
			jobTable.setErrorMessage(errorMessage);
		}

		try {
			dataExtractorDAO.updateJobStatus(jobTable);
		} catch (Exception e) {
			log.error("Eception occured while updating Job status: " + e.getMessage());
		}
	}

	private void saveDataExportStatusCTP(JobsHeartBeat jobTable, String tableName, Instant appNotifyStartTime,
			boolean isSuccess, String errorMessage, Date currentTime) {

		if (jobTable == null) {
			return;
		}

		jobTable.setEndTime(new Timestamp(System.currentTimeMillis()));

		Duration appNotifyDuration = Duration.between(appNotifyStartTime, Instant.now());
		Long appNotifyDurationInMilles = appNotifyDuration.toMillis();

		Long minutes = TimeUnit.MILLISECONDS.toMinutes(appNotifyDurationInMilles);
		Long seconds = TimeUnit.MILLISECONDS.toSeconds(appNotifyDurationInMilles);

		jobTable.setDurationMillisecs(appNotifyDurationInMilles.intValue());
		jobTable.setDurationMins(minutes.intValue());
		jobTable.setDurationSecs(seconds.intValue());

		log.info("tableName: " + tableName);
		log.info("Processing time in ms: " + appNotifyDurationInMilles);
		log.info("Processing time in seconds: " + seconds);
		log.info("Processing time in minutes: " + minutes);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(currentTime);
		calendar.add(Calendar.DATE, 1);
		Timestamp nextScheduledAt = new Timestamp(calendar.getTimeInMillis());
		log.info("nextScheduledAt: " + nextScheduledAt);

		jobTable.setNextScheduledAt(nextScheduledAt);

		if (isSuccess) {
			jobTable.setStatus("Success");
			jobTable.setErrorMessage("Success");
		} else {
			jobTable.setStatus("Failed");
			jobTable.setErrorMessage(errorMessage);
		}

		try {
			dataExtractorDAO.updateJobStatus(jobTable);
		} catch (Exception e) {
			log.error("Eception occured while updating Job status: " + e.getMessage());
		}
	}
	
	private List<DateRange> getCTPDateRangeList() {
		List<DateRange> dateRangeList = new ArrayList<>();
		
		DateRange d4 = new DateRange();
		d4.setStartDate("2024-10-02 00:00:00");
		d4.setEndDate("2024-10-09 23:59:59");
		d4.setExcelDate("10092024");
		dateRangeList.add(d4);
		
		/*DateRange d41 = new DateRange();
		d41.setStartDate("2024-10-08 00:00:00");
		d41.setEndDate("2024-10-14 23:59:59");
		d41.setExcelDate("10142024_historical");
		dateRangeList.add(d41);
		
		DateRange d5 = new DateRange();
		d5.setStartDate("2024-10-15 00:00:00");
		d5.setEndDate("2024-10-21 23:59:59");
		d5.setExcelDate("10212024_historical");
		dateRangeList.add(d5);
		
		DateRange d51 = new DateRange();
		d51.setStartDate("2024-10-22 00:00:00");
		d51.setEndDate("2024-10-31 23:59:59");
		d51.setExcelDate("10312024_historical");
		dateRangeList.add(d51);
		
		DateRange d6 = new DateRange();
		d6.setStartDate("2024-11-01 00:00:00");
		d6.setEndDate("2024-11-07 23:59:59");
		d6.setExcelDate("11072024_historical");
		dateRangeList.add(d6);
		
		DateRange d61 = new DateRange();
		d61.setStartDate("2024-11-08 00:00:00");
		d61.setEndDate("2024-11-14 23:59:59");
		d61.setExcelDate("11142024_historical");
		dateRangeList.add(d61);
		
		DateRange d7 = new DateRange();
		d7.setStartDate("2024-11-15 00:00:00");
		d7.setEndDate("2024-11-21 23:59:59");
		d7.setExcelDate("11212024_historical");
		dateRangeList.add(d7);
		
		DateRange d71 = new DateRange();
		d71.setStartDate("2024-11-22 00:00:00");
		d71.setEndDate("2024-11-30 23:59:59");
		d71.setExcelDate("11302024_historical");
		dateRangeList.add(d71);
		
		DateRange d8 = new DateRange();
		d8.setStartDate("2024-12-01 00:00:00");
		d8.setEndDate("2024-12-07 23:59:59");
		d8.setExcelDate("12072024_historical");
		dateRangeList.add(d8);
		
		DateRange d81 = new DateRange();
		d81.setStartDate("2024-12-08 00:00:00");
		d81.setEndDate("2024-12-14 23:59:59");
		d81.setExcelDate("12142024_historical");
		dateRangeList.add(d81);
		
		DateRange d9 = new DateRange();
		d9.setStartDate("2024-12-15 00:00:00");
		d9.setEndDate("2024-12-21 23:59:59");
		d9.setExcelDate("12112024_historical");
		dateRangeList.add(d9);
		
		DateRange d91 = new DateRange();
		d91.setStartDate("2024-12-22 00:00:00");
		d91.setEndDate("2024-12-31 23:59:59");
		d91.setExcelDate("12312024_historical");
		dateRangeList.add(d91);
		
		DateRange d12 = new DateRange();
		d12.setStartDate("2025-01-01 00:00:00");
		d12.setEndDate("2025-01-07 23:59:59");
		d12.setExcelDate("01072025_historical");
		dateRangeList.add(d12);
		
		DateRange d121 = new DateRange();
		d121.setStartDate("2025-01-08 00:00:00");
		d121.setEndDate("2025-01-15 23:59:59");
		d121.setExcelDate("01152025_historical");
		dateRangeList.add(d121);
		
		DateRange d13 = new DateRange();
		d13.setStartDate("2025-01-16 00:00:00");
		d13.setEndDate("2025-01-21 23:59:59");
		d13.setExcelDate("01212025_historical");
		dateRangeList.add(d13);
		
		DateRange d14 = new DateRange();
		d14.setStartDate("2025-01-22 00:00:00");
		d14.setEndDate("2025-01-31 23:59:59");
		d14.setExcelDate("01312025_historical");
		dateRangeList.add(d14);
		
		DateRange d15 = new DateRange();
		d15.setStartDate("2025-02-01 00:00:00");
		d15.setEndDate("2025-02-07 23:59:59");
		d15.setExcelDate("02072025_historical");
		dateRangeList.add(d15);
		
		DateRange d16 = new DateRange();
		d16.setStartDate("2025-02-08 00:00:00");
		d16.setEndDate("2025-02-15 23:59:59");
		d16.setExcelDate("02152025_historical");
		dateRangeList.add(d16);
		
		DateRange d17 = new DateRange();
		d17.setStartDate("2025-02-16 00:00:00");
		d17.setEndDate("2025-02-21 23:59:59");
		d17.setExcelDate("02212025_historical");
		dateRangeList.add(d17);
		
		DateRange d18 = new DateRange();
		d18.setStartDate("2025-02-22 00:00:00");
		d18.setEndDate("2025-02-28 23:59:59");
		d18.setExcelDate("02282025_historical");
		dateRangeList.add(d18);*/
		
		return dateRangeList;
	}
	
	private List<DateRange> getNPWTDateRangeList() {
		List<DateRange> dateRangeList = new ArrayList<>();
		
		DateRange d9 = new DateRange();
		d9.setStartDate("2024-12-16 00:00:00");
		d9.setEndDate("2024-12-23 23:59:59");
		d9.setExcelDate("12232024");
		dateRangeList.add(d9);
		
		/*DateRange d91 = new DateRange();
		d91.setStartDate("2024-12-22 00:00:00");
		d91.setEndDate("2024-12-31 23:59:59");
		d91.setExcelDate("12312024_historical");
		dateRangeList.add(d91);
		
		DateRange d12 = new DateRange();
		d12.setStartDate("2025-01-01 00:00:00");
		d12.setEndDate("2025-01-07 23:59:59");
		d12.setExcelDate("01072025_historical");
		dateRangeList.add(d12);
		
		DateRange d121 = new DateRange();
		d121.setStartDate("2025-01-08 00:00:00");
		d121.setEndDate("2025-01-15 23:59:59");
		d121.setExcelDate("01152025_historical");
		dateRangeList.add(d121);
		
		DateRange d13 = new DateRange();
		d13.setStartDate("2025-01-16 00:00:00");
		d13.setEndDate("2025-01-21 23:59:59");
		d13.setExcelDate("01212025_historical");
		dateRangeList.add(d13);
		
		DateRange d14 = new DateRange();
		d14.setStartDate("2025-01-22 00:00:00");
		d14.setEndDate("2025-01-31 23:59:59");
		d14.setExcelDate("01312025_historical");
		dateRangeList.add(d14);
		
		DateRange d15 = new DateRange();
		d15.setStartDate("2025-02-01 00:00:00");
		d15.setEndDate("2025-02-07 23:59:59");
		d15.setExcelDate("02072025_historical");
		dateRangeList.add(d15);
		
		DateRange d16 = new DateRange();
		d16.setStartDate("2025-02-08 00:00:00");
		d16.setEndDate("2025-02-15 23:59:59");
		d16.setExcelDate("02152025_historical");
		dateRangeList.add(d16);
		
		DateRange d17 = new DateRange();
		d17.setStartDate("2025-02-16 00:00:00");
		d17.setEndDate("2025-02-21 23:59:59");
		d17.setExcelDate("02212025_historical");
		dateRangeList.add(d17);
		
		DateRange d18 = new DateRange();
		d18.setStartDate("2025-02-22 00:00:00");
		d18.setEndDate("2025-02-28 23:59:59");
		d18.setExcelDate("02282025_historical");
		dateRangeList.add(d18);*/
		
		return dateRangeList;
	}
	
	private Timestamp convertToTimestamp(String dateTime) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Timestamp timestamp = null;
		
		try { 
            // Parse the input string to a java.util.Date object 
            java.util.Date parsedDate = dateFormat.parse(dateTime);
            
            System.out.println("parsedDate : " +parsedDate);
            System.out.println("parsedDate.getTime : " +parsedDate.getTime());
  
            // Convert java.util.Date to java.sql.Timestamp 
            timestamp = new Timestamp(parsedDate.getTime());
            
            System.out.println("timestamp : " +timestamp);
		} catch (Exception e) {
			System.out.println("Exception occured : " +e.getMessage());
		}
		
		return timestamp;
	}
	
	public void runCTPHistoricalDataExtractor() {
		try {
			List<DateRange> dateRangeList = getCTPDateRangeList();
			
			log.debug("dateRangeList : " +dateRangeList);
			
			for (DateRange dr : dateRangeList) {
				log.debug("*****************************************");
				
				log.debug("getStartDate : " +dr.getStartDate());
				log.debug("getEndDate : " +dr.getEndDate());
				
				Timestamp startTimestamp = convertToTimestamp(dr.getStartDate());
				Timestamp endTimestamp = convertToTimestamp(dr.getEndDate());
				
				log.debug("startTimestamp : " + startTimestamp);
				log.debug("endTimestamp : " + endTimestamp);
				
				log.info("Extractng AppNotification Historical Data");

				// First Get AppNotification data from Database table
				List<MasterAppNotification> appNotificationsCTP = null;
				try {
					appNotificationsCTP = dataExtractorDAO2.extractAppNotificationDataCTPHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());
				}

				if (appNotificationsCTP != null && appNotificationsCTP.size() > 0) {
					
					log.debug("appNotificationsCTP.size : " +appNotificationsCTP.size());
					
					// Generate AppNotification CSV/Excel
					String geneatedAppNotifyExcelFileNameCTP = "";
					try {
						String excelFileName = appNotificationExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedAppNotifyExcelFileNameCTP = ExportExcelUtil.generateAppNotificationsExcelCTP(
								appNotificationsCTP, appNotificationColumns, excelFileName,
								dataExtractLocalPath, true);
					} catch (Exception e) {
						log.error("Eception occured while generating AppNotification Excel: " + e.getMessage());
					}

					log.debug("geneatedAppNotifyExcelFileName : " + geneatedAppNotifyExcelFileNameCTP);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedAppNotifyExcelFileNameCTP.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + appNotificationExcelFileNameCTP) : "
								+ (dataExtractLocalPath + geneatedAppNotifyExcelFileNameCTP));

						// Upload Extracted AppNotification to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedAppNotifyExcelFileNameCTP),
									(dataExtractLocalPath + geneatedAppNotifyExcelFileNameCTP))) {

								// Delete generated AppNotifcation Excel file from local
								// server
								/*
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedAppNotifyExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedAppNotifyExcelFileName);
								 * log.info("deleted file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedAppNotifyExcelFileName));
								 */
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("AppNotification Historical  Data Extract completed...");
				log.debug("--------------------------------------------------");

				// DocumentStore
				log.info("Extractng DocumentStore Historical Data...");

				// First Get Document Status data from Database table
				List<DocumentStore> documentStoreListCTP = null;
				try {
					documentStoreListCTP = dataExtractorDAO2.extractDocumentStoreDataCTPHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching Document Store Data: " + e.getMessage());
				}

				if (documentStoreListCTP != null && documentStoreListCTP.size() > 0) {
					
					log.debug("documentStoreListCTP.size : " +documentStoreListCTP.size());
					
					// Generate Document Status CSV/Excel
					String geneatedDocStoreExcelFileName = "";
					try {
						String excelFileName = documentStoreExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedDocStoreExcelFileName = ExportExcelUtil.generateDocumentStoreExcel(documentStoreListCTP,
								documentStoreColumns, excelFileName, dataExtractLocalPath, true);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedDocStoreExcelFileName : " + geneatedDocStoreExcelFileName);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedDocStoreExcelFileName.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedDocStoreExcelFileName) : "
								+ (dataExtractLocalPath + geneatedDocStoreExcelFileName));

						// Upload Extracted Document Status Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedDocStoreExcelFileName),
									(dataExtractLocalPath + geneatedDocStoreExcelFileName))) {

								// Delete generated AppNotifcation Excel file from local
								// server
								/*
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedDocStatusExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedDocStatusExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedDocStatusExcelFileName));
								 */
							}
						} catch (Exception e) {
							log.error("Exception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("Document Store Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				log.info("Extractng Documentation History Historical Data...");
				// First Get data from Database table
				List<DocumentationHistory2> docHistoryListCTP = null;
				try {
					docHistoryListCTP = dataExtractorDAO2.extractDocHistoryDataCTPHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());
				}

				if (docHistoryListCTP != null && docHistoryListCTP.size() > 0) {
					
					log.debug("docHistoryListCTP.size : " +docHistoryListCTP.size());
					
					// Generate CSV/Excel
					String geneatedDocHistoryExcelFileNameCTP = "";
					try {
						
						String excelFileName = documentationHistoryExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedDocHistoryExcelFileNameCTP = ExportExcelUtil.generateDocumentationHistoryExcel(
								docHistoryListCTP, documentationHistoryColumns, excelFileName,
								dataExtractLocalPath, true);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedDocHistoryExcelFileNameNPWT : " + geneatedDocHistoryExcelFileNameCTP);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedDocHistoryExcelFileNameCTP.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedDocHistoryExcelFileNameCTP));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedDocHistoryExcelFileNameCTP),
									(dataExtractLocalPath + geneatedDocHistoryExcelFileNameCTP))) {

								// Delete generated Excel file from local server
								/*
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName));
								 */
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

						}
					}
				}

				log.info("Documentation History Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				// UserNotes
				log.info("Extracting User Notes Historical Data...");

				// First Get data from Database table
				List<UserNotes2> userNotesListCTP = null;
				try {
					userNotesListCTP = dataExtractorDAO2.extractUserNotesDataCTPHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching User Notes Data: " + e.getMessage());
				}

				if (userNotesListCTP != null && userNotesListCTP.size() > 0) {
					log.debug("userNotesListCTP.size : " +userNotesListCTP.size());
					
					// Generate CSV/Excel
					String geneatedUserNotesExcelFileNameCTP = "";
					try {
						String excelFileName = userNotesExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedUserNotesExcelFileNameCTP = ExportExcelUtil.generateUserNotesExcel(userNotesListCTP,
								userNotesColumns, excelFileName, dataExtractLocalPath, true);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedUserNotesExcelFileNameCTP : " + geneatedUserNotesExcelFileNameCTP);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedUserNotesExcelFileNameCTP.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedUserNotesExcelFileNameCTP));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedUserNotesExcelFileNameCTP),
									(dataExtractLocalPath + geneatedUserNotesExcelFileNameCTP))) {

								// Delete generated Excel file from local server
								/*
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedUserNotesExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedUserNotesExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedUserNotesExcelFileName));
								 */
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("User Notes Historical Data Extract completed...");
				log.debug("-------------------------------------");
				
				// CTP Dashboard
				log.info("Extractng CTP Dashboard Historical Data...");

				// First Get data from Database table
				List<CTPDashboard > ctpDashboardList = null;
				try {
					ctpDashboardList = dataExtractorDAO2.extractCTPDashboardDataHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching CTP Dashboard Data: " + e.getMessage());
				}

				if (ctpDashboardList != null && ctpDashboardList.size() > 0) {
					
					log.debug("ctpDashboardList.size : " +ctpDashboardList.size());
					
					// Generate CSV/Excel
					String geneatedCTPDashboardExcelFileName = "";
					try {
						
						String excelFileName = ctpDashboardExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedCTPDashboardExcelFileName = ExportExcelUtil.generateCTPDashboardExcel(ctpDashboardList,
								ctpDashboardColumns, excelFileName, dataExtractLocalPath, true);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedCTPDashboardExcelFileName : " + geneatedCTPDashboardExcelFileName);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedCTPDashboardExcelFileName.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedCTPDashboardExcelFileName) : "
								+ (dataExtractLocalPath + geneatedCTPDashboardExcelFileName));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedCTPDashboardExcelFileName),
									(dataExtractLocalPath + geneatedCTPDashboardExcelFileName))) {

							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("CTP Dashboard Data Extract completed...");
				log.debug("-------------------------------------");

			}
		} catch (Exception e) {
			log.error("Exception occured in runCTPHistoricalDataExtractor: " +e.getMessage());
		}
	}
	
	/*public void runNPWTHistoricalDataExtractor() {
		try {
			List<DateRange> dateRangeList = getNPWTDateRangeList();
			
			log.debug("dateRangeList : " +dateRangeList);
			
			for (DateRange dr : dateRangeList) {
				log.debug("*****************************************");
				
				log.debug("getStartDate : " +dr.getStartDate());
				log.debug("getEndDate : " +dr.getEndDate());
				
				Timestamp startTimestamp = convertToTimestamp(dr.getStartDate());
				Timestamp endTimestamp = convertToTimestamp(dr.getEndDate());
				
				log.debug("startTimestamp : " + startTimestamp);
				log.debug("endTimestamp : " + endTimestamp);
				
				log.info("Extractng AppNotification Historical Data...");

				// First Get AppNotification data from Database table
				List<AppNotifications> appNotificationsNPWT = null;
				try {
					appNotificationsNPWT = dataExtractorDAO2.extractAppNotificationDataNPWTHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());
				}

				if (appNotificationsNPWT != null && appNotificationsNPWT.size() > 0) {
					// Generate AppNotification CSV/Excel
					String geneatedAppNotifyExcelFileNameNPWT = "";
					try {
						String excelFileName = appNotificationExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedAppNotifyExcelFileNameNPWT = ExportExcelUtil.generateAppNotificationsExcelNPWT(
								appNotificationsNPWT, appNotificationColumns, excelFileName,
								dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Eception occured while generating AppNotification Excel: " + e.getMessage());
					}

					log.debug("geneatedAppNotifyExcelFileName : " + geneatedAppNotifyExcelFileNameNPWT);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedAppNotifyExcelFileNameNPWT.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + appNotificationExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedAppNotifyExcelFileNameNPWT));

						// Upload Extracted AppNotification to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedAppNotifyExcelFileNameNPWT),
									(dataExtractLocalPath + geneatedAppNotifyExcelFileNameNPWT))) {

								// Delete generated AppNotifcation Excel file from local
								// server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedAppNotifyExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedAppNotifyExcelFileName);
								 * log.info("deleted file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedAppNotifyExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("AppNotification Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				// DocumentStatus
				log.info("Extractng DocumentStatus Historical Data...");

				// First Get Document Status data from Database table
				List<DocumentStore> documentStoreListNPWT = null;
				try {
					documentStoreListNPWT = dataExtractorDAO2.extractDocumentStoreDataNPWTHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching Document Store Data: " + e.getMessage());
				}

				if (documentStoreListNPWT != null && documentStoreListNPWT.size() > 0) {
					// Generate Document Status CSV/Excel
					String geneatedDocStoreExcelFileName = "";
					try {
						String excelFileName = documentStoreExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedDocStoreExcelFileName = ExportExcelUtil.generateDocumentStoreExcelNPWT(documentStoreListNPWT,
								documentStoreColumns, excelFileName, dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedDocStoreExcelFileName : " + geneatedDocStoreExcelFileName);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedDocStoreExcelFileName.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedDocStoreExcelFileName) : "
								+ (dataExtractLocalPath + geneatedDocStoreExcelFileName));

						// Upload Extracted Document Status Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedDocStoreExcelFileName),
									(dataExtractLocalPath + geneatedDocStoreExcelFileName))) {

								// Delete generated AppNotifcation Excel file from local
								// server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedDocStatusExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedDocStatusExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedDocStatusExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Exception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("Document Status Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				log.info("Extractng Documentation History Historical Data...");

				// First Get data from Database table
				List<DocumentationHistory2> docHistoryListNPWT = null;
				try {
					docHistoryListNPWT = dataExtractorDAO2.extractDocHistoryDataNPWTHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching AppNotification Data: " + e.getMessage());
				}

				if (docHistoryListNPWT != null && docHistoryListNPWT.size() > 0) {
					// Generate CSV/Excel
					String geneatedDocHistoryExcelFileNameNPWT = "";
					try {
						String excelFileName = documentationHistoryExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedDocHistoryExcelFileNameNPWT = ExportExcelUtil.generateDocumentationHistoryExcelNPWT(
								docHistoryListNPWT, documentationHistoryColumns, excelFileName,
								dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedDocHistoryExcelFileNameNPWT : " + geneatedDocHistoryExcelFileNameNPWT);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedDocHistoryExcelFileNameNPWT.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedDocHistoryExcelFileNameNPWT),
									(dataExtractLocalPath + geneatedDocHistoryExcelFileNameNPWT))) {

								// Delete generated Excel file from local server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("Documentation History Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				// patientMedicalRecords
				log.info("Extractng Patient Medical Records Historical Data...");

				// First Get data from Database table
				List<PatientMedicalRecords> pmrListNPWT = null;
				try {
					pmrListNPWT = dataExtractorDAO.extractPMRDataNPWTHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching Patient Medical Record Data: " + e.getMessage());
				}

				if (pmrListNPWT != null && pmrListNPWT.size() > 0) {
					// Generate CSV/Excel
					String geneatedPMRExcelFileNameNPWT = "";
					try {
						String excelFileName = patientMedicalRecordsExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedPMRExcelFileNameNPWT = ExportExcelUtil.generatePMRExcelNPWT(pmrListNPWT,
								patientMedicalRecordsColumns, excelFileName, dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedPMRExcelFileNameNPWT : " + geneatedPMRExcelFileNameNPWT);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedPMRExcelFileNameNPWT.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedPMRExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedPMRExcelFileNameNPWT));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedPMRExcelFileNameNPWT),
									(dataExtractLocalPath + geneatedPMRExcelFileNameNPWT))) {

								// Delete generated Excel file from local server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath + geneatedPMRExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedPMRExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath + geneatedPMRExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("Patient Medical Records Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				// Uniform Dashboard
				log.info("Extractng NPWT Dashboard Historical Data...");

				// First Get data from Database table
				List<UniformDashboard> npwtDashboardList = null;
				try {
					npwtDashboardList = dataExtractorDAO2.extractNPWTDashboardDataHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching NPWT Dashboard Data: " + e.getMessage());
				}

				if (npwtDashboardList != null && npwtDashboardList.size() > 0) {
					// Generate CSV/Excel
					String geneatedNPWTDashboardExcelFileName = "";
					try {
						String excelFileName = npwtDashboardExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedNPWTDashboardExcelFileName = ExportExcelUtil.generateNPWTDashboardExcel(npwtDashboardList,
								npwtDashboardColumns, excelFileName, dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedNPWTDashboardExcelFileName : " + geneatedNPWTDashboardExcelFileName);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedNPWTDashboardExcelFileName.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName) : "
								+ (dataExtractLocalPath + geneatedNPWTDashboardExcelFileName));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedNPWTDashboardExcelFileName),
									(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName))) {

								// Delete generated Excel file from local server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedAWDDashboardExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedAWDDashboardExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedAWDDashboardExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("NPWTDashboard Historical Data Extract completed...");
				log.debug("-------------------------------------");

				// PrimaryKeyLookUp
				log.info("Extracting Primary Key Look Up Historical Data...");

				// First Get data from Database table
				List<PrimaryKeyLookup> primaryKeyLookupListNPWT = null;
				try {
					primaryKeyLookupListNPWT = dataExtractorDAO2
							.extractPrimaryKeyLookupDataNPWTHistorical(startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching Primary Key Look Up Data: " + e.getMessage());
				}

				if (primaryKeyLookupListNPWT != null && primaryKeyLookupListNPWT.size() > 0) {
					// Generate CSV/Excel
					String geneatedPrimaryKeyLookupExcelFileNameNPWT = "";
					try {
						String excelFileName = primaryKeyLookUpExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedPrimaryKeyLookupExcelFileNameNPWT = ExportExcelUtil.generatePrimaryKeyLookupExcelNPWT(
								primaryKeyLookupListNPWT, primaryKeyLookUpColumns, excelFileName,
								dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedPrimaryKeyLookupExcelFileNameNPWT : " + geneatedPrimaryKeyLookupExcelFileNameNPWT);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedPrimaryKeyLookupExcelFileNameNPWT.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedPrimaryKeyLookupExcelFileNameNPWT),
									(dataExtractLocalPath + geneatedPrimaryKeyLookupExcelFileNameNPWT))) {

								// Delete generated Excel file from local server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedDocHistoryExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());

						}
					}
				}

				log.info("Primary Key Look Up Historical Data Extract completed...");
				log.debug("--------------------------------------------------");

				// UserNotes
				log.info("Extracting User Notes Historical Data...");

				// First Get data from Database table
				List<UserNotes2> userNotesListNPWT = null;
				try {
					userNotesListNPWT = dataExtractorDAO2.extractUserNotesDataNPWTHistorical(startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching User Notes Data: " + e.getMessage());
				}

				if (userNotesListNPWT != null && userNotesListNPWT.size() > 0) {
					// Generate CSV/Excel
					String geneatedUserNotesExcelFileNameNPWT = "";
					try {
						String excelFileName = userNotesExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedUserNotesExcelFileNameNPWT = ExportExcelUtil.generateUserNotesExcelNPWT(userNotesListNPWT,
								userNotesColumns, excelFileName, dataExtractLocalPath);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedUserNotesExcelFileNameNPWT : " + geneatedUserNotesExcelFileNameNPWT);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedUserNotesExcelFileNameNPWT.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT) : "
								+ (dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedUserNotesExcelFileNameNPWT),
									(dataExtractLocalPath + geneatedUserNotesExcelFileNameNPWT))) {

								// Delete generated Excel file from local server
								
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedUserNotesExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedUserNotesExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedUserNotesExcelFileName));
								 
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("User Notes Historical Data Extract completed...");
				log.debug("-------------------------------------");
			}
		} catch (Exception e) {
			log.error("Exception occured in runNPWTHistoricalDataExtractor: " +e.getMessage());
		}
	}*/
	
	public void runNPWTHistoricalExtractor() {
		try {
			List<DateRange> dateRangeList = getNPWTDateRangeList();
			
			log.debug("dateRangeList : " +dateRangeList);
			
			for (DateRange dr : dateRangeList) {
				log.debug("*****************************************");
				
				log.debug("getStartDate : " +dr.getStartDate());
				log.debug("getEndDate : " +dr.getEndDate());
				
				Timestamp startTimestamp = convertToTimestamp(dr.getStartDate());
				Timestamp endTimestamp = convertToTimestamp(dr.getEndDate());
				
				log.debug("startTimestamp : " + startTimestamp);
				log.debug("endTimestamp : " + endTimestamp);
				
				// Uniform Dashboard
				log.info("Extractng NPWT Dashboard Historical Data...");

				// First Get data from Database table
				List<UniformDashboard> npwtDashboardList = null;
				try {
					npwtDashboardList = dataExtractorDAO2.extractNPWTDashboardDataHistorical(
							startTimestamp, endTimestamp);
				} catch (Exception e) {
					log.error("Exception occured while fetching NPWT Dashboard Data: " + e.getMessage());
				}

				if (npwtDashboardList != null && npwtDashboardList.size() > 0) {
					// Generate CSV/Excel
					String geneatedNPWTDashboardExcelFileName = "";
					try {
						String excelFileName = npwtDashboardExcelName + "_historical_"
								+ dr.getExcelDate() + ".csv";
						
						geneatedNPWTDashboardExcelFileName = ExportExcelUtil.generateNPWTDashboardExcel(npwtDashboardList,
								npwtDashboardColumns, excelFileName, dataExtractLocalPath, true);
					} catch (Exception e) {
						log.error("Exception occured: " + e.getMessage());
					}

					log.debug("geneatedNPWTDashboardExcelFileName : " + geneatedNPWTDashboardExcelFileName);

					// If Excel file generated
					// Upload Excel from server to AWS S3
					if (!geneatedNPWTDashboardExcelFileName.isEmpty()) {

						log.debug("dataExtractDataSolutionsS3Loc : " + dataExtractDataSolutionsS3Loc);
						log.debug("(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName) : "
								+ (dataExtractLocalPath + geneatedNPWTDashboardExcelFileName));

						// Upload Extracted Excel to AWS S3 bucket
						try {
							if (fileUploadService.uploadFileToS3(dataExtractDataSolutionsS3Loc,
									(dataExtractUploadS3Location + geneatedNPWTDashboardExcelFileName),
									(dataExtractLocalPath + geneatedNPWTDashboardExcelFileName))) {

								// Delete generated Excel file from local server
								/*
								 * log.info("Deleting file from path:"
								 * +(dataExtractLocalPath +
								 * geneatedAWDDashboardExcelFileName));
								 * deleteLocalFile(dataExtractLocalPath +
								 * geneatedAWDDashboardExcelFileName);
								 * log.info("deleted CSV file from path: "
								 * +(dataExtractLocalPath +
								 * geneatedAWDDashboardExcelFileName));
								 */
							}
						} catch (Exception e) {
							log.error("Eception occured while Exporting to AWS S3: " + e.getMessage());
						}
					}
				}

				log.info("NPWTDashboard Historical Data Extract completed...");
				log.debug("-------------------------------------");
			}
		} catch (Exception e) {
			log.error("Exception occured in runNPWTHistoricalDataExtractor: " +e.getMessage());
		}
	}

}
