package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.BOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.BOConstants.ERRORMESSAGE;
import static com.healogics.rtrv.constants.BOConstants.NEW_STATUS_TEXT;
import static com.healogics.rtrv.constants.BOConstants.REQUESTED_DOCUMENT_TEXT;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE_DOUBLE;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.bo.MasterDashboardBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.DashboardDAO;
import com.healogics.rtrv.dao.MasterDashboardDAO;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dao.RetrievePrimaryKeyMappings;
import com.healogics.rtrv.dto.APIResponse;
import com.healogics.rtrv.dto.AttemptCategory;
import com.healogics.rtrv.dto.AttemptType;
import com.healogics.rtrv.dto.CTPDashboardRes;
import com.healogics.rtrv.dto.CTPData;
import com.healogics.rtrv.dto.CTPFilterOptions;
import com.healogics.rtrv.dto.CTPFilterOptionsRes;
import com.healogics.rtrv.dto.CTPOrderReq;
import com.healogics.rtrv.dto.CTPOrderRes;
import com.healogics.rtrv.dto.DocsReq;
import com.healogics.rtrv.dto.EDocument;
import com.healogics.rtrv.dto.HistoryUserNotes;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.dto.NotesAttemptDetails;
import com.healogics.rtrv.dto.OrderInfoObj;
import com.healogics.rtrv.dto.UniformDashboardRes;
import com.healogics.rtrv.dto.UniformData;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.dto.VendorDocumentTypes;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.dto.WoundQOrderDetailsRes;
import com.healogics.rtrv.dto.WoundQOrderNotificationReq;
import com.healogics.rtrv.dto.WoundQOrderNotificationRes;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.DocumentLibrary;
import com.healogics.rtrv.entity.DocumentRequest;
import com.healogics.rtrv.entity.NotesAttemptType;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.PrimaryKeySetup;
import com.healogics.rtrv.entity.UniformDashboard;
import com.healogics.rtrv.exception.CustomException;

@Service
public class MasterDashboardBOImpl implements MasterDashboardBO {
	private final Logger log = LoggerFactory.getLogger(MasterDashboardBOImpl.class);

	private final MasterDashboardDAO masterDashboardDAO;
	private final DashboardDAO dashboardDAO;
	private final RestTemplate restTemplate;
	private final Environment env;
	private final MasterHistoryTimelineDAO historyTimelineDAO;
	private final WoundQOrderDocService woundQOrderDocService;

	@Autowired
	public MasterDashboardBOImpl(MasterDashboardDAO masterDashboardDAO,
			DashboardDAO dashboardDAO, @Qualifier("httpTemplate1") RestTemplate restTemplate,
			Environment env,
			MasterHistoryTimelineDAO historyTimelineDAO, WoundQOrderDocService woundQOrderDocService) {
		this.masterDashboardDAO = masterDashboardDAO;
		this.dashboardDAO = dashboardDAO;
		this.restTemplate = restTemplate;
		this.env = env;
		this.historyTimelineDAO = historyTimelineDAO;
		this.woundQOrderDocService = woundQOrderDocService;
	}
//	
	@Override
	public CTPDashboardRes getCTPData(boolean isExcel, boolean isFilter,
			MasterCTPDashboardReq dashboardReq, int index, String taskType,
			String assignee) {
		CTPDashboardRes ctpDashboardRes = new CTPDashboardRes();
		List<CTPDashboard> ctpDashboard = new ArrayList<>();
		List<CTPData> ctpDataList = new ArrayList<>();
		try {
			
			//Fetching User Role
			Boolean isSuperUser = dashboardDAO
					.getRetrieveUser(dashboardReq.getUserId(), dashboardReq.getUsername());
			
			Long totalCount = 0L;
			boolean isExhausted = false;
			if (isFilter) {
				//Applying Filter List
				Map<String, Object> filterList = new HashMap<>();

				filterList = masterDashboardDAO.getFilteredCTPList(isExcel, dashboardReq, index,
						taskType, assignee, isSuperUser);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));

				ctpDashboard = (List<CTPDashboard>) filterList.get("data");   

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					ctpDashboardRes.setNextIndex(0);
				} else {
					ctpDashboardRes.setNextIndex(index + PAGE_SIZE);
				} 

			} else {
				totalCount = masterDashboardDAO.getTotalCount(index, taskType,
						assignee, dashboardReq, isSuperUser);
				ctpDashboard = masterDashboardDAO.getAllCTPRecords(isExcel, dashboardReq,
						index, taskType, assignee, isSuperUser);

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					ctpDashboardRes.setNextIndex(0);
				} else {
					ctpDashboardRes.setNextIndex(index + PAGE_SIZE);
				}  

			}

			//Fetching user facilities
			List<UserFacilities> facilities = dashboardDAO
					.getUserFacilities(dashboardReq.getUserId(), dashboardReq.getUsername());

			if (ctpDashboard != null) {
				// SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd
				// HH:mm:ss");

				for (CTPDashboard ctpRecord : ctpDashboard) {
					boolean matched = false;
					CTPData ctp = new CTPData();
					for (UserFacilities fac : facilities) {
						if (fac.getFacilityBluebookId()
								.equalsIgnoreCase(ctpRecord.getBluebookId())) {
							matched = true;
							break;
						}
					}
					if (matched) {
						log.debug("matched:  ", matched);
						ctp.setBbc(ctpRecord.getBluebookId());
						ctp.setOrderId(ctpRecord.getOrderId());
						ctp.setVendor(ctpRecord.getVendorName());
						ctp.setAge("0");
						ctp.setPatientFirstName(ctpRecord.getPatientFirstName());
						ctp.setPatientLastName(ctpRecord.getPatientLastName());
						ctp.setPatientName(ctpRecord.getPatientLastName()+", "+ctpRecord.getPatientFirstName());
						ctp.setPatientDOB(ctpRecord.getPatientDOB());
						ctp.setAssignedTo(ctpRecord.getAssigneeFullname());
						ctp.setLastTeamUpdated(ctpRecord.getLastTeamUpdatedTimestamp());
						ctp.setLastTeamUpdatedUserFullName(ctpRecord.getLastTeamUpdatedUserFullname());
						ctp.setOrderSource(ctpRecord.getOrderSource());
						ctp.setiHealConfiguration(ctpRecord.getFacilityType());
						ctp.setFollowupDate(ctpRecord.getFollowupDate());
						ctp.setRetrieveStatus(ctpRecord.getRetrieveStatus());
						ctp.setStatusUpdatedDateTime(ctpRecord.getStatusUpdatedTimestamp());
						ctp.setCurrentStatus(ctpRecord.getVendorStatus());
						ctp.setPrimaryInsuranceCompany(ctpRecord.getPrimaryInsuranceCompany());
						ctp.setReceivedDate(ctpRecord.getReceivedDate());
						ctp.setFirstReceived(ctpRecord.getFirstReceived());
						
						ctpDataList.add(ctp);

					} else {
						log.debug("not matched:  ", matched);
						ctp.setBbc(ctpRecord.getBluebookId());
						ctp.setOrderId(ctpRecord.getOrderId());
						ctp.setVendor(null);
						ctp.setPatientDOB(null);
						ctp.setAge(null);
						ctp.setPatientFirstName(null);
						ctp.setPatientLastName(null);
						ctp.setPatientName(null);
						ctp.setAssignedTo(null);
						ctp.setLastTeamUpdated(null);
						ctp.setLastTeamUpdatedUserFullName(null);
						ctp.setOrderSource(null);
						ctp.setiHealConfiguration(null);
						ctp.setFollowupDate(null);
						ctp.setRetrieveStatus(null);
						ctp.setStatusUpdatedDateTime(null);
						ctp.setCurrentStatus(null);
						ctp.setPrimaryInsuranceCompany(null);
						ctp.setReceivedDate(null);
						ctp.setFirstReceived(null);
						ctpDataList.add(ctp);
					}

				}

				ctpDashboardRes.setCurrentIndex(index);
				ctpDashboardRes.setTotalCount(totalCount);
				ctpDashboardRes
						.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				ctpDashboardRes.setExhausted(isExhausted); 

			} else {
				ctpDashboard = null;
			}
			log.debug("Next index: {}", (index + PAGE_SIZE));

			ctpDashboardRes.setResponseCode("0");
			ctpDashboardRes.setResponseMessage(BOConstants.SUCCESS);
			ctpDashboardRes.setRecords(ctpDataList);
			
		} catch (Exception e) {
			log.error("Exception occured while fetching CPT Data:  {}",
					e.getMessage());
			ctpDashboardRes.setResponseCode("1");
			ctpDashboardRes.setResponseMessage(BOConstants.FAILED);
			ctpDashboardRes.setRecords(new ArrayList<>());
			ctpDashboardRes.setNextIndex(index);
			ctpDashboardRes.setCurrentIndex(index);
			ctpDashboardRes.setTotalCount(0L);
			ctpDashboardRes.setTotalPage(0);
			ctpDashboardRes.setExhausted(false);
		}
		return ctpDashboardRes;
	}
	
	@Override
	public CTPFilterOptionsRes getCTPSearchFilterOptions(
			MasterCTPDashboardReq req) {
		CTPFilterOptionsRes res = new CTPFilterOptionsRes();
		try {
			//Fetching User Role
			Boolean isSuperUser = dashboardDAO.getRetrieveUser(
					req.getUserId(), req.getUsername());
			
			CTPFilterOptions options = new CTPFilterOptions();
			
			if (req.getServiceLine().equalsIgnoreCase("CTP")) {
				options = masterDashboardDAO.getFilterOptions(req, isSuperUser, req.getServiceLine());

			} else  {
				options = masterDashboardDAO.getUniformFilterOptions(req, isSuperUser, req.getServiceLine());
				
				log.info("req.getFilterOptions() : " +req.getFilterOptions());
				log.info("options - before : " +options);
				
				List<String> updatedList = new ArrayList<>();
				
				if (options.getOptions() != null && !options.getOptions().isEmpty()
						&& req.getFilterOptions().equalsIgnoreCase("vendorStatus")) {
					
					List<String> vendorStatusList = options.getOptions();
					
					for (String vendorStatus : vendorStatusList) {
						updatedList.add(getVendorStatus(5, vendorStatus));
					}
					
					options.setOptions(updatedList);
					
					log.info("options - after : " +options);
				}
			}
			
			log.debug("Filter Options Res: {}",options);
			if (options != null) {
				res.setFilterOptions(options);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching CTP Dashboard Filter Options:  {}",
					e.getMessage());
		}
		return res;
	}
	
	@Override
	public APIResponse saveRequestedDocs(DocsReq req) {
		APIResponse res = new APIResponse();
		log.debug("Saving request for Id: " +req.getVendorRequestId());

		try {
			if (req.getVendorId() == 3) {
				//Kerecis
				masterDashboardDAO.saveRequestedDocs(req, null);

				CTPOrderRes orderRes = getOrderInfo(req);

				if (orderRes != null && orderRes.getResponseCode() != null
						&& orderRes.getResponseCode().equalsIgnoreCase("0")) {

					// Update in DB
					log.debug("Updating Database with OrderInfo: {}",
							orderRes.getOrderInfoObj());
					
					CTPDashboard ctpDashboard = masterDashboardDAO.getCTPRecordById(
							req.getVendorRequestId());
					
					log.info("ctpDashboard : " +ctpDashboard);
					
					if (ctpDashboard != null) {
						masterDashboardDAO.saveOrderInfo(req.getVendorRequestId(),
								orderRes.getOrderInfoObj(), req, ctpDashboard, true);
					} else {
						masterDashboardDAO.saveOrderInfo(req.getVendorRequestId(),
								orderRes.getOrderInfoObj(), req, null, false);
					}

					res.setResponseCode("0");
					res.setResponseMessage("Document Request Received!");

				} else {
					res.setResponseCode("2");
					res.setResponseMessage(BOConstants.UNKNOWN_ERROR);
				}
			} else if (req.getVendorId() == 5) {
				// NPWT - Solventum
				Long retrieveReqId = fetchRetrieveRequestId(req);

				log.debug("retrieveReqId : " + retrieveReqId);
				String rtrvRequestId = retrieveReqId + "";
				
				masterDashboardDAO.saveRequestedDocs(req, rtrvRequestId);
				
				//Fetching existing record using rtrvRequestId
				UniformDashboard dashboard = masterDashboardDAO
						.getRetrieveRecordById(rtrvRequestId);
				
				if (dashboard != null) {
					String retrieveStatus = dashboard.getRetrieveStatus();
					
					if (retrieveStatus != null
							&& (retrieveStatus.equalsIgnoreCase("Submitted")
								|| retrieveStatus.equalsIgnoreCase("Completed")
								|| retrieveStatus.equalsIgnoreCase("Cancelled")
								|| retrieveStatus.equalsIgnoreCase("Returned"))) {
						retrieveStatus = "Returned";

						masterDashboardDAO.updateUniformDashboardByRtvId(
								rtrvRequestId, retrieveStatus);
						
						saveHistoryTimeLineForExisting(req, rtrvRequestId,
								BOConstants.RETRIEVE_RETURNED_STATUS,
								BOConstants.RETURNED_STATUS_TEXT);
					} else {
						saveHistoryTimeLineForExisting(req, rtrvRequestId,
								retrieveStatus,
								BOConstants.NEW_STATUS_TEXT);
					}
					
				} else {
					//Creating a row with RequestDocs in Uniform Dashboard
					masterDashboardDAO.saveUniformDashboardRow(req, rtrvRequestId);
					//Creating a row with RequestDocs in MasterChartDetails
					masterDashboardDAO.saveMasterChartDetailsRow(req, rtrvRequestId);
					saveHistoryTimeLineForNew(req, rtrvRequestId);
				}

				res.setResponseCode("0");
				res.setResponseMessage("Document Request Received!");
				
			} else if (req.getVendorId() == 2) {
				//Apria
				
				Long retrieveReqId = fetchRetrieveRequestId(req);

				log.debug("retrieveReqId : " + retrieveReqId);
				String rtrvRequestId = retrieveReqId + "";
				
				masterDashboardDAO.saveRequestedDocs(req, rtrvRequestId);
				
				//Fetching existing record using rtrvRequestId
				UniformDashboard dashboard = masterDashboardDAO
						.getRetrieveRecordById(rtrvRequestId);
				
				log.debug("dashboard : " +dashboard);
				
				if (dashboard != null) {
					String retrieveStatus = dashboard.getRetrieveStatus();
					
					if (retrieveStatus != null
							&& (retrieveStatus.equalsIgnoreCase("Submitted")
								|| retrieveStatus.equalsIgnoreCase("Completed")
								|| retrieveStatus.equalsIgnoreCase("Cancelled")
								|| retrieveStatus.equalsIgnoreCase("Returned"))) {
						retrieveStatus = "Returned";

						masterDashboardDAO.updateUniformDashboardByRtvId(
								rtrvRequestId, retrieveStatus);
						
						saveHistoryTimeLineForExisting(req, rtrvRequestId,
								BOConstants.RETRIEVE_RETURNED_STATUS,
								BOConstants.RETURNED_STATUS_TEXT);
					} else {
						saveHistoryTimeLineForExisting(req, rtrvRequestId,
								retrieveStatus,
								BOConstants.NEW_STATUS_TEXT);
					}
					
				} else {
					//Creating a row with RequestDocs in Uniform Dashboard
					masterDashboardDAO.saveUniformDashboardRow(req, rtrvRequestId);
					//Creating a row with RequestDocs in MasterChartDetails
					masterDashboardDAO.saveMasterChartDetailsRow(req, rtrvRequestId);
					saveHistoryTimeLineForNew(req, rtrvRequestId);
				}

				res.setResponseCode("0");
				res.setResponseMessage("Document Request Received!");

			} else if (req.getVendorId() == 4) {
				//Lympha
				
				Long retrieveReqId = fetchRetrieveRequestId(req);

				log.debug("retrieveReqId : " + retrieveReqId);
				String rtrvRequestId = retrieveReqId + "";
				
				masterDashboardDAO.saveRequestedDocs(req, rtrvRequestId);
				
				//Fetching existing record using rtrvRequestId
				UniformDashboard dashboard = masterDashboardDAO
						.getRetrieveRecordById(rtrvRequestId);
				
				log.debug("dashboard : " +dashboard);
				
				if (dashboard != null) {
					String retrieveStatus = dashboard.getRetrieveStatus();
					
					if (retrieveStatus != null
							&& (retrieveStatus.equalsIgnoreCase("Submitted")
								|| retrieveStatus.equalsIgnoreCase("Completed")
								|| retrieveStatus.equalsIgnoreCase("Cancelled")
								|| retrieveStatus.equalsIgnoreCase("Returned"))) {
						retrieveStatus = "Returned";

						masterDashboardDAO.updateUniformDashboardByRtvId(
								rtrvRequestId, retrieveStatus);
						
						saveHistoryTimeLineForExisting(req, rtrvRequestId,
								BOConstants.RETRIEVE_RETURNED_STATUS,
								BOConstants.RETURNED_STATUS_TEXT);
					} else {
						saveHistoryTimeLineForExisting(req, rtrvRequestId,
								retrieveStatus,
								BOConstants.NEW_STATUS_TEXT);
					}
					
				} else {
					//Creating a row with RequestDocs in Uniform Dashboard
					masterDashboardDAO.saveUniformDashboardRow(req, rtrvRequestId);
					//Creating a row with RequestDocs in MasterChartDetails
					masterDashboardDAO.saveMasterChartDetailsRow(req, rtrvRequestId);
					saveHistoryTimeLineForNew(req, rtrvRequestId);
				}

				res.setResponseCode("0");
				res.setResponseMessage("Document Request Received!");
			}
			
		} catch (Exception e) {
			log.error("Exception occured while saving request docs: {}",
					e.getMessage());
			res.setResponseCode("2");
			res.setResponseMessage(BOConstants.UNKNOWN_ERROR);
		}
		return res;
	}
	
	private void saveHistoryTimeLineForNew(DocsReq req, String rtrvRequestId) {
		if (req.getVendorId() == 5) {
			//For NPWT - Solventum
			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", rtrvRequestId);
			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(rtrvRequestId);
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");
			historyTimeline.setRetrieveStatus(DAOConstants.RETRIVE_NEW_STATUS);

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			vendorStatus.setCoverageSummary(null);
			historyTimeline.setVendorStatus(vendorStatus);

			HistoryUserNotes userNotesObj = new HistoryUserNotes();
			userNotesObj.setDescription(NEW_STATUS_TEXT);
			historyTimeline.setUserNotes(userNotesObj);

			log.debug("Creating History timeline:  {}", historyTimeline);
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			log.debug("Created History timeline");
			
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
			docReqTimeline.setRequestId(rtrvRequestId);
			docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline.setLastUpdatedUserId(0L);
			docReqTimeline.setLastUpdatedUsername("Retrieve API");
			docReqTimeline.setRetrieveStatus(DAOConstants.RETRIVE_NEW_STATUS);

			VendorStatus vendorStatus1 = new VendorStatus();
			vendorStatus1.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus1.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus1.setCoverageSummary(null);

			List<String> reqDocs = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason + dateRange);
					} else if (!reason.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason);
					} else {
						reqDocs.add(eDoc.getDocumentType());
					}
				}
				vendorStatus1.setRequestedDocs(reqDocs);
			}
			docReqTimeline.setVendorStatus(vendorStatus1);

			HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
			userNotesObj1.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline.setUserNotes(userNotesObj1);

			log.debug("Creating History timeline:  {}", docReqTimeline);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
			log.debug("Created History timeline");

		} else if(req.getVendorId() == 2) {
			//Apria
			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", rtrvRequestId);
			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(rtrvRequestId);
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");
			historyTimeline.setRetrieveStatus(DAOConstants.RETRIVE_NEW_STATUS);

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			vendorStatus.setCoverageSummary(null);
			historyTimeline.setVendorStatus(vendorStatus);

			HistoryUserNotes userNotesObj = new HistoryUserNotes();
			userNotesObj.setDescription(NEW_STATUS_TEXT);
			historyTimeline.setUserNotes(userNotesObj);

			log.debug("Creating History timeline:  {}", historyTimeline);
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			log.debug("Created History timeline");
			
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
			docReqTimeline.setRequestId(rtrvRequestId);
			docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline.setLastUpdatedUserId(0L);
			docReqTimeline.setLastUpdatedUsername("Retrieve API");
			docReqTimeline.setRetrieveStatus(DAOConstants.RETRIVE_NEW_STATUS);

			VendorStatus vendorStatus1 = new VendorStatus();
			vendorStatus1.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus1.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus1.setCoverageSummary(null);

			List<String> reqDocs = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason + dateRange);
					} else if (!reason.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason);
					} else {
						reqDocs.add(eDoc.getDocumentType());
					}
				}
				vendorStatus1.setRequestedDocs(reqDocs);
			}
			docReqTimeline.setVendorStatus(vendorStatus1);

			HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
			userNotesObj1.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline.setUserNotes(userNotesObj1);

			log.debug("Creating History timeline:  {}", docReqTimeline);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
			log.debug("Created History timeline");
			
		} else if (req.getVendorId() == 4) {
			//For Lympha
			// Make entry in History timeline
			log.debug("Creating History timeline Request: {}", rtrvRequestId);
			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(rtrvRequestId);
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");
			HistoryUserNotes userNotesObj = new HistoryUserNotes();
			
			if (req.getVendorStatus() != null
					&& !req.getVendorStatus().isEmpty()
					&& req.getVendorStatus().equalsIgnoreCase("ORDER_RECEIVED")) {
				historyTimeline.setRetrieveStatus(DAOConstants.RETRIVE_NEW_STATUS);
				userNotesObj.setDescription(NEW_STATUS_TEXT);
			} else {
				historyTimeline.setRetrieveStatus("");
				userNotesObj.setDescription("");
			}

			VendorStatus vendorStatus = new VendorStatus();
			vendorStatus.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			vendorStatus.setCoverageSummary(null);
			historyTimeline.setVendorStatus(vendorStatus);
			historyTimeline.setUserNotes(userNotesObj);

			log.debug("Creating History timeline:  {}", historyTimeline);
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
			log.debug("Created History timeline");
			
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
			docReqTimeline.setRequestId(rtrvRequestId);
			docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline.setLastUpdatedUserId(0L);
			docReqTimeline.setLastUpdatedUsername("Retrieve API");
			
			if (req.getVendorStatus() != null
					&& !req.getVendorStatus().isEmpty()
					&& req.getVendorStatus().equalsIgnoreCase("ORDER_RECEIVED")) {
				docReqTimeline.setRetrieveStatus(DAOConstants.RETRIVE_NEW_STATUS);
			} else {
				docReqTimeline.setRetrieveStatus("");
			}
			
			VendorStatus vendorStatus1 = new VendorStatus();
			vendorStatus1.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus1.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus1.setCoverageSummary(null);

			List<String> reqDocs = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason + dateRange);
					} else if (!reason.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason);
					} else {
						reqDocs.add(eDoc.getDocumentType());
					}
				}
				vendorStatus1.setRequestedDocs(reqDocs);
			}
			docReqTimeline.setVendorStatus(vendorStatus1);

			HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
			userNotesObj1.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline.setUserNotes(userNotesObj1);

			log.debug("Creating History timeline:  {}", docReqTimeline);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
			log.debug("Created History timeline");
		}
	}
	
	private String formatDate(Date inputDate) {
		if (inputDate == null) {
			return "";
		}
		
		try {
			DateFormat targetFormat = new SimpleDateFormat("MM/dd/yyyy");
			return targetFormat.format(inputDate);
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
		}
		return "";
	}
	
	private void saveHistoryTimeLineForExisting(DocsReq req, String
			rtrvRequestId, String retrieveStatus, String description) {
		//For NPWT - Solventum
		if (req.getVendorId() == 5) {
			// Make entry in History timeline
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
			docReqTimeline.setRequestId(rtrvRequestId);
			docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline.setLastUpdatedUserId(0L);
			docReqTimeline.setLastUpdatedUsername("Retrieve API");
			docReqTimeline.setRetrieveStatus(retrieveStatus);

			VendorStatus vendorStatus1 = new VendorStatus();
			vendorStatus1.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus1.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus1.setCoverageSummary(null);

			List<String> reqDocs = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason + dateRange);
						
					} else if (!reason.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason);
						
					} else {
						reqDocs.add(eDoc.getDocumentType());
					}
				}
				vendorStatus1.setRequestedDocs(reqDocs);
			}
			docReqTimeline.setVendorStatus(vendorStatus1);

			HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
			userNotesObj1.setDescription(description);
			docReqTimeline.setUserNotes(userNotesObj1);

			log.debug("Creating History timeline:  {}", docReqTimeline);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
			log.debug("Created History timeline");
			
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline1 = new MasterHistoryTimeline();
			docReqTimeline1.setRequestId(rtrvRequestId);
			docReqTimeline1.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline1.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline1.setLastUpdatedUserId(0L);
			docReqTimeline1.setLastUpdatedUsername("Retrieve API");
			docReqTimeline1.setRetrieveStatus(retrieveStatus);

			VendorStatus vendorStatus2 = new VendorStatus();
			vendorStatus2.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus2.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus2.setCoverageSummary(null);

			List<String> reqDocs2 = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs2.add(eDoc.getDocumentType() + " - " + reason + dateRange);
					} else if (!reason.isEmpty()) {
						reqDocs2.add(eDoc.getDocumentType() + " - " + reason);
					} else {
						reqDocs2.add(eDoc.getDocumentType());
					}
				}
				vendorStatus2.setRequestedDocs(reqDocs2);
			}
			docReqTimeline1.setVendorStatus(vendorStatus2);

			HistoryUserNotes userNotesObj2 = new HistoryUserNotes();
			userNotesObj2.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline1.setUserNotes(userNotesObj2);

			log.debug("Creating History timeline:  {}", docReqTimeline1);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline1);
			log.debug("Created History timeline");
		} else if (req.getVendorId() == 2) {
			//Apria
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline1 = new MasterHistoryTimeline();
			docReqTimeline1.setRequestId(rtrvRequestId);
			docReqTimeline1.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline1.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline1.setLastUpdatedUserId(0L);
			docReqTimeline1.setLastUpdatedUsername("Retrieve API");
			docReqTimeline1.setRetrieveStatus(retrieveStatus);

			VendorStatus vendorStatus2 = new VendorStatus();
			vendorStatus2.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus2.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus2.setCoverageSummary(null);

			List<String> reqDocs2 = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs2.add(eDoc.getDocumentType() + " - " + reason + dateRange);
					} else if (!reason.isEmpty()) {
						reqDocs2.add(eDoc.getDocumentType() + " - " + reason);
					} else {
						reqDocs2.add(eDoc.getDocumentType());
					}
				}
				vendorStatus2.setRequestedDocs(reqDocs2);
			}
			docReqTimeline1.setVendorStatus(vendorStatus2);

			HistoryUserNotes userNotesObj2 = new HistoryUserNotes();
			userNotesObj2.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline1.setUserNotes(userNotesObj2);

			log.debug("Creating History timeline:  {}", docReqTimeline1);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline1);
			log.debug("Created History timeline");
			
		} else if (req.getVendorId() == 4) {
			//Lympha
			
			// Make entry in History timeline
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline = new MasterHistoryTimeline();
			docReqTimeline.setRequestId(rtrvRequestId);
			docReqTimeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline.setLastUpdatedUserId(0L);
			docReqTimeline.setLastUpdatedUsername("Retrieve API");
			docReqTimeline.setRetrieveStatus(retrieveStatus);

			VendorStatus vendorStatus1 = new VendorStatus();
			vendorStatus1.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus1.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus1.setCoverageSummary(null);

			List<String> reqDocs = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason + dateRange);
						
					} else if (!reason.isEmpty()) {
						reqDocs.add(eDoc.getDocumentType() + " - " + reason);
						
					} else {
						reqDocs.add(eDoc.getDocumentType());
					}
				}
				vendorStatus1.setRequestedDocs(reqDocs);
			}
			docReqTimeline.setVendorStatus(vendorStatus1);

			HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
			userNotesObj1.setDescription(description);
			docReqTimeline.setUserNotes(userNotesObj1);

			log.debug("Creating History timeline:  {}", docReqTimeline);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline);
			log.debug("Created History timeline");
			
			//Making requested documents entry in history
			MasterHistoryTimeline docReqTimeline1 = new MasterHistoryTimeline();
			docReqTimeline1.setRequestId(rtrvRequestId);
			docReqTimeline1.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
			docReqTimeline1.setLastUpdatedUserFullname("Retrieve API");
			docReqTimeline1.setLastUpdatedUserId(0L);
			docReqTimeline1.setLastUpdatedUsername("Retrieve API");
			docReqTimeline1.setRetrieveStatus(retrieveStatus);

			VendorStatus vendorStatus2 = new VendorStatus();
			vendorStatus2.setCurrentStatus(getVendorStatus(req.getVendorId(),
					req.getVendorStatus()));
			
			vendorStatus2.setSecondaryStatus(req.getSecondaryStatus());
			vendorStatus2.setCoverageSummary(null);

			List<String> reqDocs2 = new ArrayList<>();
			
			if (req.getDocuments() != null
					&& !req.getDocuments().isEmpty()) {
				
				for (EDocument eDoc : req.getDocuments()) {
					
					String reason = "";
					if (eDoc.getReason() != null && !eDoc.getReason().isEmpty()) {
						reason = eDoc.getReason();
					}
					
					String dateRange = "";
					if (eDoc.getStartDate() != null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + " - "
								+ formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (eDoc.getStartDate() != null && eDoc.getEndDate() == null) {
						dateRange = " (" + formatDate(eDoc.getStartDate()) + ")";
					}
					
					if (eDoc.getStartDate() == null && eDoc.getEndDate() != null) {
						dateRange = " (" + formatDate(eDoc.getEndDate()) + ")";
					}
					
					if (!reason.isEmpty() && !dateRange.isEmpty()) {
						reqDocs2.add(eDoc.getDocumentType() + " - " + reason + dateRange);
					} else if (!reason.isEmpty()) {
						reqDocs2.add(eDoc.getDocumentType() + " - " + reason);
					} else {
						reqDocs2.add(eDoc.getDocumentType());
					}
				}
				vendorStatus2.setRequestedDocs(reqDocs2);
			}
			docReqTimeline1.setVendorStatus(vendorStatus2);

			HistoryUserNotes userNotesObj2 = new HistoryUserNotes();
			userNotesObj2.setDescription(REQUESTED_DOCUMENT_TEXT);
			docReqTimeline1.setUserNotes(userNotesObj2);

			log.debug("Creating History timeline:  {}", docReqTimeline1);
			historyTimelineDAO.saveHistoryTimeline(docReqTimeline1);
			log.debug("Created History timeline");
		}
	}
	
	private CTPOrderRes getOrderInfo(DocsReq req) {
		OrderInfoObj orderInfoRes = new OrderInfoObj();
		CTPOrderRes res = new CTPOrderRes();
		String url = env.getProperty(BOConstants.KERECIS_ORDER_INFO_URL);
		
		String orderId = req.getVendorRequestId();
		Map<String, String>  uriVariables = new HashMap<>();
		uriVariables.put("id", orderId);

		log.debug("Kerecis Order Info URL: {}",url);
		log.debug("Id: {}",orderId);
		try {
			log.info("Kerecis OrderInfo URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(getHeaders());
			
			assert url != null;
			ResponseEntity<OrderInfoObj> sresponse = restTemplate
					.exchange(url, HttpMethod.GET, request,
							OrderInfoObj.class,uriVariables);
			
			log.debug("sresponse : " + sresponse);
			orderInfoRes = sresponse.getBody();
			log.debug("orderInfoRes : " + orderInfoRes);
			res.setOrderInfoObj(orderInfoRes);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (HttpClientErrorException e) {
			log.error(String.format(
					"HttpClientErrorException occurred in OrderInfo: %s",
					e));
			res = new CTPOrderRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setResponseCode(errorResponse.get(ERRORCODE));
			res.setResponseMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(String.format(
					"HttpStatusCodeException occurred in OrderInfo: %s",
					e));
			res = new CTPOrderRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			res.setResponseCode(errorResponse.get(ERRORCODE));
			res.setResponseMessage(errorResponse.get(ERRORMESSAGE));
		}
		
		return res;
	}
	
	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");

		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')), tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}
	
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.set("app-key", env.getProperty(BOConstants.KERECIS_APP_KEY));
		headers.set("app-secret", env.getProperty(BOConstants.KERECIS_APP_SECRECT));
		return headers;
	}

	@Override
	public UpdateAssignedToRes batchUpdateAssignee(MasterCTPDashboardReq req,
			List<CTPData> records) {
		UpdateAssignedToRes res = new UpdateAssignedToRes();
		try {
			res = masterDashboardDAO.updatedAssigneedTo(req, records);
		} catch (Exception e) {
			log.error("Exception occured while Updating Batch Assigned To: {}",
					e.getMessage());
		}
		return res;
	}
	
	public void saveOrderInfo(CTPOrderReq req) {
		try {
			String retrieveStatus = "New";

			Integer historyId = historyTimelineDAO.getHistoryId();

			MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
			historyTimeline.setRequestId(req.getHealogicsOrderNo());
			historyTimeline.setHistoryId(historyId + 1);
			historyTimeline.setBluebookId(req.getBluebookId());
			historyTimeline.setFacilityId(Long.valueOf(req.getFacilityId()));
			historyTimeline.setLastUpdatedUserFullname("Retrieve API");
			historyTimeline.setLastUpdatedUserId(0L);
			historyTimeline.setLastUpdatedUsername("Retrieve API");
			historyTimeline.setPatientId(req.getPatientId());
			historyTimeline.setPatientName(req.getPatientLastName()
					+ ", " + req.getPatientFirstName());
			historyTimeline.setRetrieveStatus(retrieveStatus);
			
			HistoryUserNotes userNotesObj = new HistoryUserNotes();
			userNotesObj.setDescription("New chart received");
			
			historyTimeline.setUserNotes(userNotesObj);
			
			historyTimelineDAO.saveHistoryTimeline(historyTimeline);
		} catch (Exception e) {
			log.error("Exception occured while saving History Timeline: {}", e.getMessage());
		}
		
	}

	@Override
	public UniformDashboardRes getUniformData(boolean isExcel, boolean isFilter,
			MasterCTPDashboardReq dashboardReq, int index, String taskType, String assignee) {
		log.debug("Uniform Dashboard Payload: {}",dashboardReq);
		UniformDashboardRes ctpDashboardRes = new UniformDashboardRes();
		List<UniformDashboard> dashboard = new ArrayList<>();
		List<UniformData> uniformData = new ArrayList<>();
		long currentMillis = System.currentTimeMillis();
		Timestamp currentTime = new Timestamp(currentMillis);
		try {
			
			//Fetching User Role
			Boolean isSuperUser = dashboardDAO
					.getRetrieveUser(dashboardReq.getUserId(), dashboardReq.getUsername());
			
			Long totalCount = 0L;
			boolean isExhausted = false;
			if (isFilter) {
				//Applying Filter List
				Map<String, Object> filterList = new HashMap<>();
				filterList = masterDashboardDAO.getFilteredUniformList(isExcel, dashboardReq, index,
						taskType, assignee, isSuperUser);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));

				dashboard = (List<UniformDashboard>) filterList.get("data");   

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					ctpDashboardRes.setNextIndex(0);
				} else {
					ctpDashboardRes.setNextIndex(index + PAGE_SIZE);
				}
							
			} else {
				totalCount = masterDashboardDAO.getUniformTotalCount(index, taskType,
					assignee, dashboardReq, isSuperUser);
				
			//	totalCount = masterDashboardDAO.getUniformTotalCount(dashboardReq, isSuperUser);
				
				dashboard = masterDashboardDAO.getUniformRecords(isExcel, dashboardReq,
						index, taskType, assignee, isSuperUser);
				
			//	dashboard = masterDashboardDAO.getUniformRecords(isExcel, dashboardReq, isSuperUser);

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					ctpDashboardRes.setNextIndex(0);
				} else {
					ctpDashboardRes.setNextIndex(index + PAGE_SIZE);
				} 

			}   

			//Fetching user facilities
			List<UserFacilities> facilities = dashboardDAO
					.getUserFacilities(dashboardReq.getUserId(), dashboardReq.getUsername());

			if (dashboard != null) {
				// SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd
				// HH:mm:ss");

				//Need to optimize this code
				for (UniformDashboard record : dashboard) {
					boolean matched = false;
					UniformData uniform = new UniformData();
					for (UserFacilities fac : facilities) {
						if (fac.getFacilityBluebookId()
								.equalsIgnoreCase(record.getBluebookId())) {
							matched = true;
							break;
						}
					}
					if (matched) {
						log.debug("matched:  ", matched);
						uniform.setBbc(record.getBluebookId());
						uniform.setRequestId(record.getRequestId());
						uniform.setVendorId(record.getVendorId());
						uniform.setVendor(record.getVendorName());
						uniform.setAge(record.getAge()+"");
						uniform.setPatientName(record.getPatientLastName()+", "+record.getPatientFirstName());
						uniform.setPatientDOB(record.getPatientDOB());
						uniform.setPatientId(record.getPatientId());
						uniform.setVendorOrderNo(record.getVendorOrderNo());
						uniform.setAssignedTo(record.getAssignedTo());
						uniform.setLastTeamUpdated(record.getLastTeamUpdatedTimestamp());
						uniform.setLastTeamUpdatedFullName(record.getLastTeamUpdatedFullName());
						uniform.setBhcOrderSource(record.getOrderSource());
						uniform.setiHealConfiguration(record.getIhealConfig());
						uniform.setFollowupDate(record.getFollowupDate());
						uniform.setRetrieveStatus(record.getRetrieveStatus());
						uniform.setVendorStatus(getVendorStatus(record.getVendorId(),
								record.getVendorStatus()));
						uniform.setInsurance(record.getPrimaryInsurance());
						uniform.setResponseDate(record.getResponseDate());
						uniform.setVendorOrderDate(record.getVendorOrderDate());
						uniform.setReceivedDate(record.getReceivedDate());
						uniform.setCreatedTimestamp(currentTime);
						
						uniformData.add(uniform);

					} else {
						log.debug("not matched:  ", matched);						
						uniform.setBbc(record.getBluebookId());
						uniform.setRequestId(record.getRequestId());
						uniform.setVendorId(null);
						uniform.setVendor(null);
						uniform.setPatientDOB(null);
						uniform.setAge(null);
						uniform.setPatientName(null);
						uniform.setPatientId(null);
						uniform.setVendorOrderNo(null);
						uniform.setAssignedTo(null);
						uniform.setLastTeamUpdated(null);
						uniform.setLastTeamUpdatedFullName(null);
						uniform.setBhcOrderSource(null);
						uniform.setiHealConfiguration(null);
						uniform.setFollowupDate(null);
						uniform.setRetrieveStatus(null);
						uniform.setVendorStatus(null);
						uniform.setInsurance(null);
						uniform.setResponseDate(null);
						uniform.setVendorOrderDate(null);
						uniform.setReceivedDate(null);
						uniform.setCreatedTimestamp(currentTime);
						uniformData.add(uniform);
					}

				}

				ctpDashboardRes.setCurrentIndex(index);
				ctpDashboardRes.setTotalCount(totalCount);
				ctpDashboardRes
						.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				ctpDashboardRes.setExhausted(isExhausted);   

			} else {
				dashboard = null;
			}
			log.debug("Next index: {}", (index + PAGE_SIZE));

			ctpDashboardRes.setResponseCode("0");
			ctpDashboardRes.setResponseMessage(BOConstants.SUCCESS);
			ctpDashboardRes.setRecords(uniformData);
			
		} catch (Exception e) {
			log.error("Exception occured while fetching Uniform Data:  {}",
					e.getMessage());
			ctpDashboardRes.setResponseCode("1");
			ctpDashboardRes.setResponseMessage(BOConstants.FAILED);
			ctpDashboardRes.setRecords(new ArrayList<>());
			ctpDashboardRes.setNextIndex(index);
			ctpDashboardRes.setCurrentIndex(index);
			ctpDashboardRes.setTotalCount(0L);
			ctpDashboardRes.setTotalPage(0);
			ctpDashboardRes.setExhausted(false);
		}
		return ctpDashboardRes;
	
	}
	
	@Override
	public Map<String, String> validDocReq(DocsReq req) {
		Map<String, String> validationError = new HashMap<>();
		if (req == null) {
			validationError.put("request", "Invalid request!");
			
		} else if (req.getVendorId() == null
				|| req.getVendorId() == 0) {
			validationError.put("vendorId", "Invalid Vendor Id!");

		} else {
			if(req.getVendorId() == 3
					|| req.getVendorId() == 5
					|| req.getVendorId() == 2
					|| req.getVendorId() == 4) {
				if (req.getOrderSource() == null
						|| req.getOrderSource().isEmpty()) {
					validationError.put("orderSource", "Invalid Order Source!");
				}
				if (req.getVendorId() == null
						|| req.getVendorId() == 0) {
					validationError.put("vendorId", "Invalid Vendor Id!");
				}
				
				if (req.getFacilityBBC() == null
						|| req.getFacilityBBC().isEmpty()) {
					validationError.put("facilityBBC", "Invalid Facility BBC!");
				}
				
				if (req.getPatientFirstName() == null
						|| req.getPatientFirstName().isEmpty()) {
					validationError.put("patientFirstName", "Invalid Patient First Name!");
				}
				
				if (req.getPatientLastName() == null
						|| req.getPatientLastName().isEmpty()) {
					validationError.put("patientLastName", "Invalid Patient Last Name!");
				}
				
				if (req.getDocuments() == null || req.getDocuments().size() <= 0) {
					validationError.put("documents", "Invalid Documents!");
				}
			}
			
			if (req.getVendorId() == 3) {
				//CTP
				if (req.getVendorRequestId() == null
						|| req.getVendorRequestId().isEmpty()) {
					validationError.put("vendorRequestId", "Invalid Vendor RequestId!");
				}
				
				if (req.getVendorCustomerNumber() == null
						|| req.getVendorCustomerNumber().isEmpty()) {
					validationError.put("vendorCustomerNumber", "Invalid Vendor Customer Number!");
				}
				
				if (req.getOrderToken() == null
						|| req.getOrderToken().isEmpty()) {
					validationError.put("orderToken", "Invalid Order Token!");
				}
			} else if (req.getVendorId() == 5) {
				//NPWT - Solventum
				//Same as VendorOrderNo
				if (req.getVendorRequestId() == null
						|| req.getVendorRequestId().isEmpty()) {
					validationError.put("vendorRequestId", "Invalid Vendor Request Id!");
				}
				
				if (req.getVendorStatus() == null
						|| req.getVendorStatus().isEmpty()) {
					validationError.put("vendorStatus", "Invalid Vendor Status!");
				}
				
				if (req.getPrimaryInsurance() == null
						|| req.getPrimaryInsurance().isEmpty()) {
					validationError.put("primaryInsurance", "Invalid Primary Insurance!");
				}
				
				if (req.getFacilityName() == null
						|| req.getFacilityName().isEmpty()) {
					validationError.put("facilityName", "Invalid Facility Name!");
				}
				
				if (req.getOrderSource() != null && !req.getOrderSource().isEmpty()
						&& req.getOrderSource().equalsIgnoreCase("WOUNDQ")) {

					if (req.getOrderToken() == null
							|| req.getOrderToken().isEmpty()) {
						validationError.put("orderToken", "Invalid Order Token!");
					}
					
					if (req.getOrderDisplayNumber() == 0) {
						validationError.put("orderDisplayNumber", "Invalid Order Display Number!");
					}
					
					if (req.getFacilityId() == 0) {
						validationError.put("facilityId", "Invalid Facility Id!");
					}
					
					if (req.getPatientId() == null || req.getPatientId().isEmpty()) {
						validationError.put("patientId", "Invalid Patient Id!");
					}
					
					if (req.getVisitId() == 0) {
						validationError.put("visitId", "Invalid Visit Id!");
					}
					
					if (req.getVisitDate() == null) {
						validationError.put("visitDate", "Invalid Visit Date!");
					}
				}
			
			} else if (req.getVendorId() == 2) {
				//NPWT - Apria
				//Same as VendorOrderNo
				if (req.getVendorRequestId() == null
						|| req.getVendorRequestId().isEmpty()) {
					validationError.put("vendorRequestId", "Invalid Vendor Request Id!");
				}
				
				if (req.getVendorStatus() == null
						|| req.getVendorStatus().isEmpty()) {
					validationError.put("vendorStatus", "Invalid Vendor Status!");
				}
				
				if (req.getPrimaryInsurance() == null
						|| req.getPrimaryInsurance().isEmpty()) {
					validationError.put("primaryInsurance", "Invalid Primary Insurance!");
				}
				
				if (req.getOrderSource() != null && !req.getOrderSource().isEmpty()
						&& req.getOrderSource().equalsIgnoreCase("WOUNDQ")) {

					if (req.getOrderToken() == null
							|| req.getOrderToken().isEmpty()) {
						validationError.put("orderToken", "Invalid Order Token!");
					}
					
					if (req.getOrderDisplayNumber() == 0) {
						validationError.put("orderDisplayNumber", "Invalid Order Display Number!");
					}
					
					if (req.getFacilityId() == 0) {
						validationError.put("facilityId", "Invalid Facility Id!");
					}
					
					if (req.getPatientId() == null || req.getPatientId().isEmpty()) {
						validationError.put("patientId", "Invalid Patient Id!");
					}
					
					/*if (req.getVisitId() == 0) {
						validationError.put("visitId", "Invalid Visit Id!");
					}*/
					
					if (req.getVisitDate() == null) {
						validationError.put("visitDate", "Invalid Visit Date!");
					}
				}
			
			} else if (req.getVendorId() == 4) {
				//Lympha
				if (req.getVendorRequestId() == null
						|| req.getVendorRequestId().isEmpty()) {
					validationError.put("vendorRequestId", "Invalid Vendor Request Id!");
				}
				
				if (req.getVendorStatus() == null
						|| req.getVendorStatus().isEmpty()) {
					validationError.put("vendorStatus", "Invalid Vendor Status!");
				}
				
				if (req.getPrimaryInsurance() == null
						|| req.getPrimaryInsurance().isEmpty()) {
					validationError.put("primaryInsurance", "Invalid Primary Insurance!");
				}
				
				if (req.getFacilityName() == null
						|| req.getFacilityName().isEmpty()) {
					validationError.put("facilityName", "Invalid Facility Name!");
				}
				
				if (req.getOrderSource() != null && !req.getOrderSource().isEmpty()
						&& req.getOrderSource().equalsIgnoreCase("WOUNDQ")) {

					if (req.getOrderToken() == null
							|| req.getOrderToken().isEmpty()) {
						validationError.put("orderToken", "Invalid Order Token!");
					}
					
					if (req.getOrderDisplayNumber() == 0) {
						validationError.put("orderDisplayNumber", "Invalid Order Display Number!");
					}
					
					if (req.getFacilityId() == 0) {
						validationError.put("facilityId", "Invalid Facility Id!");
					}
					
					if (req.getPatientId() == null || req.getPatientId().isEmpty()) {
						validationError.put("patientId", "Invalid Patient Id!");
					}
					
					if (req.getVisitId() == 0) {
						validationError.put("visitId", "Invalid Visit Id!");
					}
					
					if (req.getVisitDate() == null) {
						validationError.put("visitDate", "Invalid Visit Date!");
					}
				}
			
			}
		}
		log.debug("Validation ERROR: {}",validationError.toString());
		return validationError;
	}
	
	public Long fetchRetrieveRequestId(DocsReq req) {
		PrimaryKeySetup primaryKeyDetails = null;
		Long retrieveReqId = 0L;
		
		try {
			primaryKeyDetails = masterDashboardDAO.fetchPrimaryKeyByVendorId(
					req.getVendorId());
		} catch (CustomException e) {
			log.error("Exception occured while fetchPrimaryKeyByVendorId: {}", e.getMessage());
		} catch (Exception e) {
			log.error("Exception occured while fetchPrimaryKeyByVendorId: {}", e.getMessage());
		}
		
		log.debug("primaryKeyDetails : " +primaryKeyDetails);
		
		if (primaryKeyDetails == null) {
			return retrieveReqId;
		}
		
		RetrievePrimaryKeyMappings pkMappings = null;
		
		ObjectMapper objectMapper = new ObjectMapper();
		if (primaryKeyDetails.getPrimaryKey() != null) {
			try {
				pkMappings = objectMapper.readValue(primaryKeyDetails.getPrimaryKey(),
						new TypeReference<RetrievePrimaryKeyMappings>() {
				});
			} catch (JsonProcessingException e) {
				log.error("Json Procession exception " +
						"while parsing RetrievePrimaryKeyMappings:  {}",e);
			}
		}
		
		if (pkMappings == null || pkMappings.getPrimaryKeyMappings() == null) {
			return retrieveReqId;
		}
		
		//Convert to switch once more options added
		if (req.getVendorId() == 5 || req.getVendorId() == 2) {
			PrimaryKeyLookup lookup = null;
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			try {
				lookup = masterDashboardDAO.lookupPrimaryKey(
						pkMappings.getPrimaryKeyMappings(),
						req.getVendorId(), req.getVendorRequestId(), req.getVendorStatus());

			} catch (CustomException e) {
				log.error("Exception occured while lookupPrimaryKey: {}", e.getMessage());
			} catch (Exception e) {
				log.error("Exception occured while lookupPrimaryKey: {}", e.getMessage());
			}
			
			log.debug("lookup : " +lookup);
			
			if (lookup == null) {
				lookup = new PrimaryKeyLookup();
				lookup.setVendorName(primaryKeyDetails.getVendorName());
				lookup.setServiceLine(primaryKeyDetails.getServiceLine());
				lookup.setPrimaryKey1(req.getVendorRequestId());
				lookup.setPrimaryKey2(req.getVendorStatus());
				lookup.setVendorId(req.getVendorId());
				lookup.setCreatedTimestamp(currentTime);
				
				log.debug("new lookup entry : " +lookup);
				
				try {
					retrieveReqId = masterDashboardDAO.generateRetrieveReqId(lookup);
				} catch (CustomException e) {
					log.error("Exception occured while generateRetrieveReqId: {}", e.getMessage());
				} catch (Exception e) {
					log.error("Exception occured while generateRetrieveReqId: {}", e.getMessage());
				}
				
				log.debug("generated new retrieveReqId : " +retrieveReqId);
				
				return retrieveReqId;
			}
			
			retrieveReqId = lookup.getRetrieveReqId();
			
		} else if (req.getVendorId() == 101 || req.getVendorId() == 4) {
			
			PrimaryKeyLookup lookup = null;
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);
			try {
				lookup = masterDashboardDAO.lookupPrimaryKey(
						pkMappings.getPrimaryKeyMappings(),
						req.getVendorId(), req.getVendorRequestId(), "");

			} catch (CustomException e) {
				log.error("Exception occured while lookupPrimaryKey: {}", e.getMessage());
			} catch (Exception e) {
				log.error("Exception occured while lookupPrimaryKey: {}", e.getMessage());
			}
			
			log.debug("lookup : " +lookup);
			
			if (lookup == null) {
				lookup = new PrimaryKeyLookup();
				lookup.setVendorName(primaryKeyDetails.getVendorName());
				lookup.setServiceLine(primaryKeyDetails.getServiceLine());
				lookup.setPrimaryKey1(req.getVendorRequestId());
				lookup.setVendorId(req.getVendorId());
				lookup.setCreatedTimestamp(currentTime);
				
				log.debug("new lookup entry : " +lookup);
				
				try {
					retrieveReqId = masterDashboardDAO.generateRetrieveReqId(lookup);
				} catch (CustomException e) {
					log.error("Exception occured while generateRetrieveReqId: {}", e.getMessage());
				} catch (Exception e) {
					log.error("Exception occured while generateRetrieveReqId: {}", e.getMessage());
				}
				
				log.debug("generated new retrieveReqId : " +retrieveReqId);
				
				return retrieveReqId;
			}
			
			retrieveReqId = lookup.getRetrieveReqId();
		}
		
		log.debug("final - retrieveReqId : " +retrieveReqId);
		return retrieveReqId;
	}
	
	@Override
	public PrimaryKeyLookup lookupRetrieveReqId(DocsReq req) {
		PrimaryKeySetup primaryKeyDetails = null;
		PrimaryKeyLookup lookup = null;
		
		try {
			primaryKeyDetails = masterDashboardDAO.fetchPrimaryKeyByVendorId(
					req.getVendorId());
		} catch (CustomException e) {
			log.error("Exception occured while fetchPrimaryKeyByVendorId: {}", e.getMessage());
		} catch (Exception e) {
			log.error("Exception occured while fetchPrimaryKeyByVendorId: {}", e.getMessage());
		}
		
		log.debug("primaryKeyDetails : " +primaryKeyDetails);
		
		if (primaryKeyDetails == null) {
			return lookup;
		}
		
		RetrievePrimaryKeyMappings pkMappings = null;
		
		ObjectMapper objectMapper = new ObjectMapper();
		if (primaryKeyDetails.getPrimaryKey() != null) {
			try {
				pkMappings = objectMapper.readValue(primaryKeyDetails.getPrimaryKey(),
						new TypeReference<RetrievePrimaryKeyMappings>() {
				});
			} catch (JsonProcessingException e) {
				log.error("Json Procession exception " +
						"while parsing RetrievePrimaryKeyMappings:  {}",e);
			}
		}
		
		if (pkMappings == null || pkMappings.getPrimaryKeyMappings() == null) {
			return lookup;
		}
		
		//Convert to switch once more options added
		if (req.getVendorId() == 5) {
			try {
				lookup = masterDashboardDAO.lookupPrimaryKey(
						pkMappings.getPrimaryKeyMappings(),
						req.getVendorId(), req.getVendorRequestId(), req.getVendorStatus());

			} catch (CustomException e) {
				log.error("Exception occured while lookupPrimaryKey: {}", e.getMessage());
			} catch (Exception e) {
				log.error("Exception occured while lookupPrimaryKey: {}", e.getMessage());
			}
			
			log.debug("lookup : " +lookup);
		}
		
		log.debug("final - lookup : " +lookup);
		return lookup;
	}
	
	@Override
	public NotesAttemptDetails getAttemptTypeByServiceline(String serviceLine) {
		NotesAttemptDetails res = new NotesAttemptDetails();
		try {
			List<NotesAttemptType> attemptTypeList = masterDashboardDAO
					.getAttemptTypeByServiceline(serviceLine);
			
			ObjectMapper mapper = new ObjectMapper();
			
			List<AttemptCategory> categoryList = new ArrayList<>();
			
			if (attemptTypeList != null && attemptTypeList.size() > 0) {
				for (NotesAttemptType notesAttempt : attemptTypeList) {
					
					AttemptCategory categoryDetails = new AttemptCategory();
					categoryDetails.setCategory(notesAttempt.getAttemptCategory());
					
					AttemptType attemptType = null;
					
					if (notesAttempt.getAttemptType() != null) {
						try {
							attemptType = mapper.readValue(notesAttempt.getAttemptType(),
									new TypeReference<AttemptType>() {
							});
						} catch (JsonProcessingException e) {
							log.error("Json Procession exception "
									+ "while parsing RetrievePrimaryKeyMappings:  {}",
									e);
						}
					}
					
					if (attemptType != null) {
						categoryDetails.setTypes(attemptType.getType());
						
						categoryDetails.setContacts((attemptType.getContact() == null)
								? new ArrayList<String>() : attemptType.getContact());
						
						categoryDetails.setVendorContact((attemptType.getVendorContact() == null)
								? new ArrayList<String>() : attemptType.getVendorContact());
					} else {
						categoryDetails.setTypes(new ArrayList<String>());
						categoryDetails.setContacts(new ArrayList<String>());
						categoryDetails.setVendorContact(new ArrayList<String>());
					}
					
					categoryList.add(categoryDetails);
				}
			}
			
			res.setServiceLine(serviceLine);
			res.setNotesAttempt(categoryList);
			res.setResponseCode(BOConstants.SUCCESS_RESPONSE_CODE);
			res.setResponseMessage(BOConstants.SUCCESS);
			
		} catch (CustomException e) {
			log.error("Exception occured while generateRetrieveReqId: {}", e.getMessage());
			res.setResponseCode(BOConstants.FAILED_RESPONSE_CODE);
			res.setResponseMessage(BOConstants.FAILED);
		} catch (Exception e) {
			log.error("Exception occured while generateRetrieveReqId: {}", e.getMessage());
			res.setResponseCode(BOConstants.FAILED_RESPONSE_CODE);
			res.setResponseMessage(BOConstants.FAILED);
		}
		
		return res;
	}

	@Override
	public UpdateAssignedToRes batchUpdateAssignees(MasterCTPDashboardReq req, List<UniformData> records) {
		UpdateAssignedToRes res = new UpdateAssignedToRes();
		try {
			res = masterDashboardDAO.updatedAssigneedToRecord(req, records);
		} catch (Exception e) {
			log.error("Exception occured while Updating Batch Assigned To: {}",
					e.getMessage());
		}
		return res;
	}
	
	private String getVendorStatus(Integer vendorId, String orderStatus) {
		String vendorStatus = orderStatus;
		
		if (vendorId == 5 || vendorId == 2) {
			switch (orderStatus) {
			case DAOConstants.SOLVENTUM_FULL_MR_REQUEST: {
				vendorStatus = DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER: {
				vendorStatus = DAOConstants.VENDOR_ORDER_RELEASE_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_1: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_1_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_SUB_CYCLE_2: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_2_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_3: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_3_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_4: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_4_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_ADDITIONAL_DOC_REQUIRED: {
				vendorStatus = DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED;
			}
				break;
				
			default:
				break;
			}
		}
		return vendorStatus;
	}

	@Override
	public Map<String, String> validDocReqForWoundQ(WoundQOrderNotificationReq req) {
		Map<String, String> validationError = new HashMap<>();
		if (req == null) {
			validationError.put("request", "Invalid request!");

		} else {
			if (req.getOrderToken() == null || req.getOrderToken().isEmpty()) {
				validationError.put("orderToken", "Invalid Order Token!");
			}

			if (req.getOrderDisplayNumber() == null || req.getOrderDisplayNumber().intValue() == 0) {
				validationError.put("orderDisplayNumber", "Invalid Order Display Number!");
			}

			if (req.getFacilityId() == null || req.getFacilityId().intValue() == 0) {
				validationError.put("facilityId", "Invalid Facility Id!");
			}

			if (req.getPatientId() == null || req.getPatientId().intValue() == 0) {
				validationError.put("patientId", "Invalid Patient Id!");
			}
		}
		log.debug("Validation ERROR: {}", validationError.toString());
		return validationError;
	}

	@Override
	public WoundQOrderNotificationRes getOrderDetails(WoundQOrderNotificationReq req)
			throws CustomException {
		WoundQOrderNotificationRes orderNotificationRes = new WoundQOrderNotificationRes();
		try {
			Integer patientId = req.getPatientId();
			Integer vendorId = req.getVendorId();
			String orderToken = req.getOrderToken();
			
			if (vendorId != null && vendorId.intValue() == 3) {
				orderNotificationRes.setResponseCode("0");
				orderNotificationRes.setResponseMessage("Order Notification Received!");
				
				return orderNotificationRes;
				
			} else if (vendorId != null && vendorId.intValue() != 6) {
				orderNotificationRes.setResponseCode("1");
				orderNotificationRes.setResponseMessage("Invalid VendorId!");
				
				return orderNotificationRes;
			}
	
			//Processing VendorId 6
			// Call the WoundQOrderDocService method
			WoundQOrderDetailsRes woundQRes = woundQOrderDocService.callOrderDetails(
					patientId, vendorId, orderToken);
			
			if (woundQRes != null && woundQRes.getResponseCode() == 200) {
				//Success
				DocsReq docReq = new DocsReq();
				//Setting 101 for LifeNet to generate retrieve request id
				docReq.setVendorId(101);
				docReq.setVendorRequestId((woundQRes.getOrderDetails() != null
						&& woundQRes.getOrderDetails().getOrderDisplayNumber() != null
						&& woundQRes.getOrderDetails().getOrderDisplayNumber().intValue() != 0)
					? woundQRes.getOrderDetails().getOrderDisplayNumber().toString() : "0");
				
				Long retrieveReqId = fetchRetrieveRequestId(docReq);
		
				log.debug("retrieveReqId : " + retrieveReqId);
				String rtrvRequestId = retrieveReqId + "";
				
				// Save the data to the document_request table
				DocumentRequest documentRequest = new DocumentRequest();
				documentRequest.setRequestId(rtrvRequestId);
				documentRequest.setPatientId(patientId);
				documentRequest.setVendorId(vendorId);
				documentRequest.setWoundqOrderToken(orderToken);
				documentRequest.setFacilityId(req.getFacilityId());
				documentRequest.setWoundqOrderNo(String.valueOf(
						req.getOrderDisplayNumber()));
				documentRequest.setVendorOrderNo(String.valueOf(
						req.getOrderDisplayNumber()));
				documentRequest.setOrderSource("WoundQ");
				documentRequest.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
				if (woundQRes.getVisitDate() != null) {
					documentRequest.setVisitDate(new Timestamp(woundQRes.getVisitDate().getTime()));
				} else {
					documentRequest.setVisitDate(null);
				}
				
				if (woundQRes.getFacilityObject() != null) {
					documentRequest.setFacilityId(woundQRes.getFacilityObject().getFacilityId());
					documentRequest.setBluebookId(woundQRes.getFacilityObject().getFacilityBbc());
				}
				
				if (woundQRes.getPatient() != null) {
					documentRequest.setMedicalRecordNumber(woundQRes.getPatient().getPatientMrn());
					documentRequest.setPatientFirstName(woundQRes.getPatient().getFirstName());
					documentRequest.setPatientLastName(woundQRes.getPatient().getLastName());
					documentRequest.setPatientName(documentRequest.getPatientLastName()
							+ ", " + documentRequest.getPatientFirstName());
					
					docReq.setPatientDOB(woundQRes.getPatient().getDob());
				}
				
				//Get LifeNet Documents from Document Library
				DocumentLibrary docLibrary = masterDashboardDAO.getDocumentLibrary(vendorId);
				
				List<EDocument> eDocsList = new ArrayList<>();
				
				if (docLibrary != null && docLibrary.getDocumentList() != null) {
					
					VendorDocumentTypes docTypes = new VendorDocumentTypes();
					
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						docTypes = objectMapper.readValue(
								docLibrary.getDocumentList(),
							new TypeReference<VendorDocumentTypes>() {
						});
					} catch (JsonProcessingException e) {
						log.error("Json Procession exception:  {}", e);
					}
					
					log.debug("docTypes : "+docTypes);
						
					if (docTypes != null && docTypes.getDocuments() != null) {
						for (String docType : docTypes.getDocuments()) {
							EDocument eDoc = new EDocument();
							eDoc.setDocumentRequestId(UUID.randomUUID().toString());
							eDoc.setDocumentType(docType);
							eDocsList.add(eDoc);
						}
					}
					
					log.debug("eDocsList : "+eDocsList);
				}
				
				ObjectMapper objectMapper1 = new ObjectMapper();
				
				String docListString = null;
				try {
					docListString = objectMapper1.writeValueAsString(eDocsList);
				} catch (JsonProcessingException e) {
					log.error("Exception occured  while getting primaryInsJson JSON: " + e.getMessage());
				}

				log.debug("docListString : " +docListString);
				
				documentRequest.setDocuments(docListString);
				
				log.debug("documentRequest=========="+documentRequest);
				
				masterDashboardDAO.saveDocumentRequest(documentRequest);
				
				docReq.setPatientFirstName(documentRequest.getPatientFirstName());
				docReq.setPatientLastName(documentRequest.getPatientLastName());
				docReq.setFacilityId(documentRequest.getFacilityId());
				docReq.setFacilityBBC(documentRequest.getBluebookId());
				//docReq.setVendorOrderNumber(woundQRes.getOrderDisplayNumber());
				
				if (woundQRes.getOrderDetails() != null) {
					String providerFullNames = woundQRes.getOrderDetails().getPhysician();
					
					if (providerFullNames != null && !providerFullNames.isEmpty()) {
						log.debug("providerFullNames=========="+providerFullNames);
					    // Split the name by comma and trim any leading/trailing spaces
					    String[] nameParts = providerFullNames.split(",");
					    if (nameParts.length == 2) {
					        String providerLastName = nameParts[0].trim();
					        String providerFirstName = nameParts[1].trim();
					        docReq.setProviderFirstName(providerFirstName);
					        docReq.setProviderLastName(providerLastName);
					    } else {
					    	docReq.setProviderFirstName("");
					        docReq.setProviderLastName("");
					    }
					} else {
						docReq.setProviderFirstName("");
				        docReq.setProviderLastName("");
					}
					
					String caseManagerName = woundQRes.getOrderDetails().getCaseManager();
					
					if (caseManagerName != null && !caseManagerName.isEmpty()) {
						log.debug("caseManagerName=========="+caseManagerName);
					    // Split the name by comma and trim any leading/trailing spaces
					    String[] nameParts = caseManagerName.split(",");
					    if (nameParts.length == 2) {
					        String caseManagerLastName = nameParts[0].trim();
					        String caseManagerFirstName = nameParts[1].trim();
					        docReq.setClinicianFirstName(caseManagerFirstName);
					        docReq.setClinicianLastName(caseManagerLastName);
					    } else {
					    	docReq.setClinicianFirstName("");
					        docReq.setClinicianLastName("");
					    }
					} else {
						docReq.setClinicianFirstName("");
				        docReq.setClinicianLastName("");
					}
				}
				
				docReq.setMedicalRecordNumber(documentRequest.getMedicalRecordNumber());
				docReq.setOrderSource("WoundQ");
				
				CTPDashboard ctpDashboard = masterDashboardDAO.getCTPRecordById(
						rtrvRequestId);
				
				log.info("ctpDashboard : " +ctpDashboard);
				
				if (ctpDashboard != null) {
					masterDashboardDAO.saveWoundQOrderInfo(rtrvRequestId,
							ctpDashboard, true, woundQRes, documentRequest, vendorId);
				} else {
					masterDashboardDAO.saveWoundQOrderInfo(rtrvRequestId,
							null, false, woundQRes, documentRequest, vendorId);
				}
				
				orderNotificationRes.setResponseCode("0");
				orderNotificationRes.setResponseMessage("Order Notification Received!");
			} else {
				//Error
				orderNotificationRes.setResponseCode("1");
				orderNotificationRes.setResponseMessage("Unknown Error!");
			}
			
		} catch (Exception e) {
			log.error("Exception occured : {}", e.getMessage());
			
			orderNotificationRes.setResponseCode("2");
			orderNotificationRes.setResponseMessage("Unknown Exception!");
		}

		return orderNotificationRes;
	}
	
}
