package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.DAOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORMESSAGE;

import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dto.DocServiceReq;
import com.healogics.rtrv.dto.FileUploadReq;
import com.healogics.rtrv.dto.IHealCustomScanUploadReq;
import com.healogics.rtrv.dto.IHealCustomScanUploadRes;
import com.healogics.rtrv.dto.IHealDocViewPDFGetReq;
import com.healogics.rtrv.dto.IHealDocViewPDFGetRes;
import com.healogics.rtrv.dto.IHealDocViewPDFReq;
import com.healogics.rtrv.dto.IHealDocViewPDFRes;
import com.healogics.rtrv.dto.IHealDocumentViewPDFGetRes;
import com.healogics.rtrv.dto.IHealFileGetReq;
import com.healogics.rtrv.dto.IHealFileGetRes;

@Service
public class DocumentService {
	private final Logger log = LoggerFactory.getLogger(DocumentService.class);
	
	private final Environment env;
	
	private final RestTemplate restTemplate;
	
	@Autowired
	public DocumentService(Environment env, @Qualifier("httpTemplate1") RestTemplate restTemplate) {
		this.env = env;
		this.restTemplate = restTemplate;
	}

	
	public IHealDocViewPDFRes sendDocViewPDFReq(DocServiceReq req) {

		IHealDocViewPDFRes docViewRes = null;

		String url = env.getProperty(BOConstants.IHEAL_DOC_VIEW_PDF_REQ_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealDocViewPDFReq docViewReq = new IHealDocViewPDFReq();
		docViewReq.setPrivateKey(privateKey);
		docViewReq.setMasterToken(req.getMasterToken());
		docViewReq.setFacilityId(req.getFacilityId());
		docViewReq.setPatientId(req.getPatientId());
		docViewReq.setUserId(req.getUserId());
		docViewReq.setVisitId(req.getVisitId());
		docViewReq.setJobSavePdfFileName(req.getJobSavePdfFileName());
		docViewReq.setDocumentationViewName(req.getDocumentationViewName());
		docViewReq.setRequireSignatures(req.getRequireSignatures());
		docViewReq.setClientState(req.getClientState());

		try {
			log.info("IHeal DocViewPDFRequest URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(docViewReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealDocViewPDFRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealDocViewPDFRes.class);
			log.info("IHeal DocViewPDFRequest URL post Completed ");
			log.debug("iHeal DocViewPDFRequest Response : {}",
					sresponse.getBody());
			docViewRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in DocViewPDFRequest API - ",
					e);
			docViewRes = new IHealDocViewPDFRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			docViewRes.setErrorCode(errorResponse.get(ERRORCODE));
			docViewRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in DocViewPDFRequest API: ",
					e);
			docViewRes = new IHealDocViewPDFRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			docViewRes.setErrorCode(errorResponse.get(ERRORCODE));
			docViewRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return docViewRes;
	}
	
	public IHealDocViewPDFGetRes sendDocViewPDFGet(DocServiceReq req) {

		IHealDocViewPDFGetRes docViewRes = null;

		String url = env.getProperty(BOConstants.IHEAL_DOC_VIEW_PDF_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealDocViewPDFGetReq docGetReq = new IHealDocViewPDFGetReq();
		docGetReq.setPrivateKey(privateKey);
		docGetReq.setMasterToken(req.getMasterToken());
		docGetReq.setFacilityId(req.getFacilityId());
		docGetReq.setPatientId(req.getPatientId());
		docGetReq.setUserId(req.getUserId());
		docGetReq.setVisitId(req.getVisitId());
		docGetReq.setPdfFilename(req.getPdfFilename());
		docGetReq.setJobId(req.getJobId());

		try {
			log.info("IHeal DocViewPDFGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(docGetReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealDocViewPDFGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealDocViewPDFGetRes.class);
			log.info("IHeal DocViewPDFGet URL post Completed ");
			log.debug("iHeal DocViewPDFGet Response : {}",
					sresponse.getBody());
			docViewRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in DocViewPDFGet API - ",
					e);
			docViewRes = new IHealDocViewPDFGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			docViewRes.setErrorCode(errorResponse.get(ERRORCODE));
			docViewRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in DocViewPDFGet API: ",
					e);
			docViewRes = new IHealDocViewPDFGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			docViewRes.setErrorCode(errorResponse.get(ERRORCODE));
			docViewRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return docViewRes;
	}
	
	public IHealCustomScanUploadRes uploadFileToIheal(
			FileUploadReq fileUploadReq) {
		IHealCustomScanUploadRes customScanUploadRes;
		String url = env.getProperty(BOConstants.IHEAL_CUSTOMSCAN_UPLOAD_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanUploadReq customScanUploadReq = new IHealCustomScanUploadReq();
		customScanUploadReq.setPrivateKey(privateKey);
		customScanUploadReq.setEventDateTime("");
		customScanUploadReq.setMasterToken(fileUploadReq.getMasterToken());
		customScanUploadReq.setFacilityId(fileUploadReq.getFacilityId());
		customScanUploadReq.setPatientId(fileUploadReq.getPatientId());
		customScanUploadReq.setUserId(fileUploadReq.getUserId());
		customScanUploadReq.setGroupId(0);
		try {
			// split doc name using . and assign extension
			String title = "";
			String extension = "";

			if (fileUploadReq.getFileName() != null
					&& !fileUploadReq.getFileName().isEmpty()) {
				String[] docArr = fileUploadReq.getFileName().split("\\.");
			
				if (docArr.length > 1) {
					extension = docArr[docArr.length - 1];
				title =	fileUploadReq.getFileName().replace("."+extension, "");
				}
				log.debug("extension:   {} ",extension);
				log.debug("title:   {} ",title);
			}
			
			customScanUploadReq.setTitle(title);
			customScanUploadReq.setExtension(extension);
			customScanUploadReq.setGroupName("");
			String scanId = UUID.randomUUID().toString();
			customScanUploadReq.setScanId(scanId);
			customScanUploadReq.setScanStream(fileUploadReq.getFileContent());
			customScanUploadReq.setScanExtension(extension);
			try {
				log.info("IHeal CustomScanUpload URL post started ");
				HttpEntity<Object> request = new HttpEntity<>(
						customScanUploadReq, getHeaders());
				assert url != null;
				ResponseEntity<IHealCustomScanUploadRes> sresponse = restTemplate
						.exchange(url, HttpMethod.POST, request,
								IHealCustomScanUploadRes.class);
				customScanUploadRes = sresponse.getBody();
				log.info("IHeal CustomScanUpload URL post Completed ");
				customScanUploadRes.setResponseCode("0");
				customScanUploadRes.setResponseMessage("Success");
			} catch (HttpClientErrorException e) {
				log.error(
						"HttpClientErrorException occurred in CustomScanUpload",
						e);
				customScanUploadRes = new IHealCustomScanUploadRes();
				HashMap<String, Object> errorResponse = extractResp(
						e.getResponseBodyAsString());
				customScanUploadRes
						.setResponseCode((String) errorResponse.get(ERRORCODE));
				customScanUploadRes.setResponseMessage(
						(String) errorResponse.get(ERRORMESSAGE));
			} catch (HttpStatusCodeException e) {
				log.error(
						"HttpStatusCodeException occurred in CustomScanUpload",
						e);
				customScanUploadRes = new IHealCustomScanUploadRes();
				HashMap<String, Object> errorResponse = extractResp(
						e.getResponseBodyAsString());
				customScanUploadRes
						.setResponseCode((String) errorResponse.get(ERRORCODE));
				customScanUploadRes.setResponseMessage(
						(String) errorResponse.get(ERRORMESSAGE));
			} catch (Exception e) {
				log.error("Exception occurred in CustomScanUpload ", e);
				customScanUploadRes = new IHealCustomScanUploadRes();
				HashMap<String, Object> errorResponse = extractResp(
						e.getMessage());
				customScanUploadRes
						.setResponseCode((String) errorResponse.get(ERRORCODE));
				customScanUploadRes.setResponseMessage(
						(String) errorResponse.get(ERRORMESSAGE));
			}
		} catch (Exception ex) {
			log.error("Exception occurred in CustomScanUpload", ex);
			customScanUploadRes = new IHealCustomScanUploadRes();
			HashMap<String, Object> errorResponse = extractResp(
					ex.getMessage());
			customScanUploadRes
					.setResponseCode((String) errorResponse.get("51"));
			customScanUploadRes.setResponseMessage(
					(String) errorResponse.get(ERRORMESSAGE));
		}

		return customScanUploadRes;
	}
	
	public IHealFileGetRes getCustomScanContent(DocServiceReq req) {

		IHealFileGetRes fileGetRes = null;

		String url = env.getProperty(BOConstants.IHEAL_FILE_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		
		IHealFileGetReq fileGetReq = new IHealFileGetReq();
		fileGetReq.setPrivateKey(privateKey);
		fileGetReq.setMasterToken(req.getMasterToken());
		fileGetReq.setFacilityId(req.getFacilityId());
		fileGetReq.setPatientId(req.getPatientId());
		fileGetReq.setUserId(req.getUserId());
		fileGetReq.setDocumentEntityId(req.getDocEntityId());
		fileGetReq.setType("CustomScans");

		try {
			log.info("IHeal FileGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(fileGetReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealFileGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealFileGetRes.class);
			log.info("IHeal FileGet URL post Completed ");
			log.debug("iHeal FileGet Response : {}",
					sresponse.getBody());
			fileGetRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in FileGet API - ",
					e);
			fileGetRes = new IHealFileGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in FileGet API: ",
					e);
			fileGetRes = new IHealFileGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return fileGetRes;
	}
	
	public IHealDocumentViewPDFGetRes sendDocumentViewPDFGet(DocServiceReq req) {

		IHealDocumentViewPDFGetRes fileGetRes = null;

		String url = env.getProperty(BOConstants.IHEAL_DOCUMENT_VIEW_PDF_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		
		IHealFileGetReq fileGetReq = new IHealFileGetReq();
		fileGetReq.setPrivateKey(privateKey);
		fileGetReq.setMasterToken(req.getMasterToken());
		fileGetReq.setFacilityId(req.getFacilityId());
		fileGetReq.setPatientId(req.getPatientId());
		fileGetReq.setUserId(req.getUserId());
		fileGetReq.setDocumentEntityId(req.getDocEntityId());

		try {
			fileGetRes = new IHealDocumentViewPDFGetRes();
			log.info("IHeal DocumentViewPDFGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(fileGetReq,
					getHeaders());
			assert url != null;
			ResponseEntity<byte[]> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							byte[].class);
			log.info("IHeal DocumentViewPDFGet URL post Completed ");
			/*log.debug("iHeal DocumentViewPDFGet Response : {}",
					sresponse.getBody());*/
			byte[]  res = sresponse.getBody();
			/*log.debug("PDF Bytes: {}",res);*/
			fileGetRes.setErrorCode("0");
			fileGetRes.setErrorMessage("Success");
			fileGetRes.setPdfBytes(res);
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in DocumentViewPDFGet API - ",
					e);
			fileGetRes = new IHealDocumentViewPDFGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in DocumentViewPDFGet API: ",
					e);
			fileGetRes = new IHealDocumentViewPDFGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return fileGetRes;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}
	
	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}
	
	private HashMap<String, Object> extractResp(String responseBody) {
		HashMap<String, Object> data = new HashMap<>();
		String body = responseBody.replace("[{}]", "").replace("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1, tmp.length()));
		}
		return data;
	}
}
