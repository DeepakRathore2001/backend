package com.healogics.rtrv.bo.Impl;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE_DOUBLE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.healogics.rtrv.bo.ReportsBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.ReportsDAO;
import com.healogics.rtrv.dao.UniformReportDAO;
import com.healogics.rtrv.dto.AWDFilterOptions;
import com.healogics.rtrv.dto.AWDFilterOptionsRes;
import com.healogics.rtrv.dto.NPWTFilterOptions;
import com.healogics.rtrv.dto.NPWTFilterOptionsRes;
import com.healogics.rtrv.dto.NPWTReportData;
import com.healogics.rtrv.dto.NPWTReportReq;
import com.healogics.rtrv.dto.NPWTReportRes;
import com.healogics.rtrv.dto.ViewReportsDetails;
import com.healogics.rtrv.dto.ViewReportsReq;
import com.healogics.rtrv.dto.ViewReportsRes;
import com.healogics.rtrv.entity.NPWTReport;
import com.healogics.rtrv.entity.Reports;

@Service
public class ReportsBOImpl implements ReportsBO {

	
	private final Logger log = LoggerFactory.getLogger(ReportsBOImpl.class);

	private final ReportsDAO reportsDAO;
	
	private final UniformReportDAO uniformReportDAO;
	
	@Autowired
	public ReportsBOImpl(ReportsDAO reportsDAO, UniformReportDAO uniformReportDAO) {
		this.reportsDAO = reportsDAO;
		this.uniformReportDAO = uniformReportDAO;
	}

	@Override
	public ViewReportsRes viewReports(ViewReportsReq req, boolean isExcel) {
		List<ViewReportsDetails> viewReportsList = new ArrayList<>();
		ViewReportsRes res = new ViewReportsRes();
		try {
			Long totalCount = 0L;
			boolean isExhausted = false;
			 List<Reports> reports = new ArrayList<>();
			Map<String, Object> details = new HashMap<>();
			 details = reportsDAO.viewReports(req,isExcel);

			 totalCount = Long.valueOf((Integer) details.get("Count"));
			 reports = (List<Reports>) details.get("data");
			 int index = req.getIndex();
			 
			 if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					res.setNextIndex(0);
				} else {
					res.setNextIndex(index + PAGE_SIZE);
				}

			 
			if (reports != null) {
				for (Reports report : reports) {
					ViewReportsDetails viewReport = new ViewReportsDetails();
					viewReport.setBbc(report.getBbc());
					viewReport.setBhcInvoiceOrderId(
							report.getBhcInvoiceOrderId());
					viewReport.setBhcMedicalRecordId(
							report.getBhcMedicalRecordId());
					viewReport.setBhcOrderReceivedDate(
							report.getBhcOrderReceivedDate());
					viewReport.setBhcOrderSource(report.getBhcOrderSource());
					viewReport
							.setBhcPatientAcctId(report.getBhcPatientAcctId());
					viewReport.setBhcShipDate(report.getBhcShipDate());
					viewReport.setDateDifference(report.getDateDifference());
					viewReport.setDocsFirstSent(report.getDocsFirstSent());
					viewReport.setDocsLastSent(report.getDocsLastSent());
					viewReport.setFirstReceived(report.getFirstReceived());
					viewReport.setInsuranceCategory(
							report.getInsuranceCategory());
					viewReport.setLastReceived(report.getLastReceived());
					viewReport.setNoFilesSent(report.getNoFilesSent());
					viewReport.setStatus(report.getStatus());
					viewReportsList.add(viewReport);
				}
				res.setCurrentIndex(index);
				res.setTotalCount(totalCount);
				res.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));
				res.setExhausted(isExhausted);

			} else {
				reports = null;
			}
			log.debug("Next index: {}", (index + PAGE_SIZE));
			
			res.setReports(viewReportsList);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching View Reports Details:  {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);

			res.setReports(viewReportsList);
			res.setNextIndex(req.getIndex());
			res.setCurrentIndex(req.getIndex());
			res.setTotalPage(0);
			res.setTotalCount(0L);
			res.setExhausted(false);
		}
		return res;
	}

	@Override
	public NPWTReportRes generateNPWTReport(boolean isFilter, NPWTReportReq req,
			int index, boolean isExcel) {
		List<NPWTReportData> viewNPWTReportsList = new ArrayList<>();
		NPWTReportRes res = new NPWTReportRes();
		 List<NPWTReport> reports = new ArrayList<>();
		try {
			Long totalCount = 0L;
			boolean isExhausted = false;

			if (isFilter) {

				Map<String, Object> details = new HashMap<>();

				details = uniformReportDAO.generateNPWTReport(req, index, isExcel);
				totalCount = Long.valueOf((Integer) details.get("Count"));

				reports = (List<NPWTReport>) details.get("data");

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					res.setNextIndex(0);
				} else {
					res.setNextIndex(index + PAGE_SIZE);
				}

			} else {
				totalCount = uniformReportDAO.getTotalCount(index, req);
				reports = uniformReportDAO.generateAllNPWTReport(req, index,isExcel);

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					res.setNextIndex(0);
				} else {
					res.setNextIndex(index + PAGE_SIZE);

				}
			}
			
			log.debug("reports : "+reports);
			
			if (reports != null) {
				for (NPWTReport report : reports) {
					NPWTReportData viewReport = new NPWTReportData();
					viewReport.setBBC(report.getBluebookCode());
					viewReport.setRoNo(report.getRoNo());
					viewReport.setHlWqOrderNo(report.getHlWqOrderNo());
					viewReport.setPatientName(report.getPatientName());
					viewReport.setFirstReceivedDate(report.getFirstReceivedDate());
					viewReport.setDocumentsFirstSent(report.getDocumentsFirstSent());
					viewReport.setDocumentsLastSent(report.getDocumentsLastSent());
					viewReport.setVendorStatus(getVendorStatus(DAOConstants.SOLVENTUM_VENDOR_ID, report.getVendorStatus()));
							
					viewReport.setRetrieveStatus(report.getRetrieveStatus());
					viewReport.setNoFilesSent(report.getFilesSent());
					viewNPWTReportsList.add(viewReport);

				}
				res.setCurrentIndex(index);
				res.setTotalCount(totalCount);
				res.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				res.setExhausted(isExhausted);
			} else {
				reports = null;
			}

			res.setReports(viewNPWTReportsList);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while fetching View Reports Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setReports(viewNPWTReportsList);
			res.setNextIndex(index);
			res.setCurrentIndex(index);
			res.setTotalCount(0L);
			res.setTotalPage(0);
			res.setExhausted(false);
		}
		return res;
	}
	
	@Override
	public NPWTFilterOptionsRes npwtReportFilterOptions(NPWTReportReq req) {
		NPWTFilterOptionsRes res = new NPWTFilterOptionsRes();
		try {
			NPWTFilterOptions filterOptions = uniformReportDAO.npwtReportFilterOptions(req);
			
//			log.info("req.getFilterOptions() : " +req.getFilterOptions());
			log.info("options - before : " +filterOptions);
			
			List<Object> updatedList = new ArrayList<>();
			Set<Object> uniqueList = new TreeSet<Object>();
			if (filterOptions.getOptions() != null && !filterOptions.getOptions().isEmpty()
					&& req.getFilterOptions().equalsIgnoreCase("vendorStatus")) {
				
				List<Object> vendorStatusList = filterOptions.getOptions();
				
				for (Object vendorStatus : vendorStatusList) {
					String status= (String) vendorStatus;
					status = status.replace(" ","");
					vendorStatus= (Object) status;
					uniqueList.add(getVendorStatus(5, vendorStatus));
				}
				for(Object option:uniqueList) {
					updatedList.add(option);
				}
				
				filterOptions.setOptions(updatedList);
				
				log.info("options - after : " +filterOptions);
			}
			
			if (filterOptions != null && !filterOptions.getOptions().isEmpty()) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setFilterOptions(filterOptions);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching View Reports Details:  {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public AWDFilterOptionsRes awdReportFilterOptions(ViewReportsReq req) {
		AWDFilterOptionsRes res = new AWDFilterOptionsRes();
		try {
			AWDFilterOptions filterOptions = reportsDAO.awdReportFilterOptions(req);
			if (filterOptions != null) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setFilterOptions(filterOptions);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching View Reports Details:  {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	

	private String getVendorStatus(Integer vendorId, Object vendorStatus2) {
		String vendorStatus = (String) vendorStatus2;
		
		if (vendorId == 5) {
			switch ((String) vendorStatus2) {
			case DAOConstants.SOLVENTUM_FULL_MR_REQUEST: {
				vendorStatus = DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER: {
				vendorStatus = DAOConstants.VENDOR_ORDER_RELEASE_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_1: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_1_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_SUB_CYCLE_2: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_2_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_3: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_3_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_4: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_4_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_ADDITIONAL_DOC_REQUIRED: {
				vendorStatus = DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED;
			}
				break;
			case "Full MR Request" : {
				vendorStatus = DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS;
			}
				break;
			
			case "Pending 3rd Party Verification": {
				vendorStatus = DAOConstants.VENDOR_ORDER_RELEASE_STATUS;
			}
				break;
			case "Additional Documentation Required": {
				vendorStatus = DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED;
			}
				break;

				
			default:
				break;
			}
		}
		return vendorStatus;
	}

}
