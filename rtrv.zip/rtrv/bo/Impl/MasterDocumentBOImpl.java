package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.BOConstants.FAILED;
import static com.healogics.rtrv.constants.BOConstants.FAILED_RESPONSE_CODE;
import static com.healogics.rtrv.constants.BOConstants.NOT_FOUND;
import static com.healogics.rtrv.constants.BOConstants.NOT_FOUND_RESPONSE_CODE;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.MasterDocumentBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.MasterDocumentDAO;
import com.healogics.rtrv.dto.MasterGetDocumentReq;
import com.healogics.rtrv.dto.MasterGetDocumentRes;
import com.healogics.rtrv.entity.MasterDocumentStore;

@Service
public class MasterDocumentBOImpl implements MasterDocumentBO{
	private final Logger log = LoggerFactory.getLogger(MasterDocumentBOImpl.class);
	
	private final MasterDocumentDAO masterDocumentDAO;

	@Autowired
	public MasterDocumentBOImpl(MasterDocumentDAO masterDocumentDAO) {
		this.masterDocumentDAO = masterDocumentDAO;
	}
	
	@Override
	public MasterGetDocumentRes getDocumentContent(MasterGetDocumentReq req) {
		MasterGetDocumentRes res = new MasterGetDocumentRes();
		try {
			Timestamp docGetTimestamp = new Timestamp(System.currentTimeMillis());
			
			MasterDocumentStore documentObj = masterDocumentDAO.getDocumentContent(
					req.getDocumentRequestId(),
					req.getDocumentToken());
			
			//update Doc sent status in DB
			masterDocumentDAO.saveGetDocumentStatus(
					req.getDocumentToken(), "Received",
					docGetTimestamp, "Sent", 
					new Timestamp(System.currentTimeMillis()));
			
			if (documentObj == null) {
				res.setFileStream("");
				res.setErrorCode(NOT_FOUND_RESPONSE_CODE);
				res.setErrorMessage(NOT_FOUND);
				return res;
			}

			if (documentObj.getDocumentContent() != null
					&& !documentObj.getDocumentContent().isEmpty()) {
				res.setFileStream(documentObj.getDocumentContent());
				res.setFileName(documentObj.getDocumentName());
			} else {
				res.setFileStream("");
				res.setFileName("");
			}
			res.setErrorCode("0");
			res.setErrorMessage(BOConstants.SUCCESS);
			
		} catch (Exception e) {
			log.error("Exception occured while Getting Document Content: " + e.getMessage());
			res.setErrorCode(FAILED_RESPONSE_CODE);
			res.setErrorMessage(FAILED);
		}
		return res;
	}
}
