package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.DAOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORMESSAGE;
import static com.healogics.rtrv.constants.BOConstants.DOC_SUCCESSFUL;
import static com.healogics.rtrv.constants.BOConstants.DOC_PENDING;
import static com.healogics.rtrv.constants.BOConstants.DOC_FAILED;

import java.io.File;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.MasterDashboardDAO;
import com.healogics.rtrv.dao.MasterDocumentDAO;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dto.ApriaDocNotificationRes;
import com.healogics.rtrv.dto.DocServiceReq;
import com.healogics.rtrv.dto.HistoryTimelineDocStatus;
import com.healogics.rtrv.dto.IHealDocumentViewPDFGetRes;
import com.healogics.rtrv.dto.IHealFileGetReq;
import com.healogics.rtrv.dto.IHealFileGetRes;
import com.healogics.rtrv.dto.KerecisDocumentRes;
import com.healogics.rtrv.dto.MasterDocServiceReq;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.dto.SolvemtumErrorDetails;
import com.healogics.rtrv.dto.SolventumDocNotificationRes;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.entity.MasterDocumentationHistory;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.utils.CommonUtils;

import static com.healogics.rtrv.constants.BOConstants.SUCCESS;
import static com.healogics.rtrv.constants.BOConstants.FAILED;

@Component
@Service
public class MasterPDFService {
	private final Logger log = LoggerFactory.getLogger(MasterPDFService.class);
	
	private Map<String, Long> counters = new HashMap<>();
	
	private final MasterDocumentDAO documentDAO;
	private final MasterHistoryTimelineDAO historyTimelineDAO;
	private final Environment env;
	private final RestTemplate restTemplate;
	private final KerecisOrderDocService kerecisService;
	private final SolventumOrderDocService solventumService;
	private final MasterDashboardDAO masterDashboardDAO;
	private final LifeNetDocService lifeNetDocService;
	private final ApriaOrderDocService apriaOrderDocService;
	
	@Autowired
	public MasterPDFService(MasterDocumentDAO documentDAO,
			MasterHistoryTimelineDAO historyTimelineDAO,
			Environment env, @Qualifier("httpTemplate1") RestTemplate restTemplate,
			KerecisOrderDocService kerecisService,
			SolventumOrderDocService solventumService,
			MasterDashboardDAO masterDashboardDAO,
			LifeNetDocService lifeNetDocService,
			ApriaOrderDocService apriaOrderDocService) {
		this.documentDAO = documentDAO;
		this.historyTimelineDAO = historyTimelineDAO;
		this.env = env;
		this.restTemplate = restTemplate;
		this.kerecisService = kerecisService;
		this.solventumService = solventumService;
		this.masterDashboardDAO = masterDashboardDAO;
		this.lifeNetDocService = lifeNetDocService;
		this.apriaOrderDocService = apriaOrderDocService;
	}
	
	public int saveDocumentContent(MasterSubmitChartReq submitReq, int historyId) {
		int docStatus = 0;
		try {
			List<MasterDocumentStore> documents = null;
			
			if (submitReq.getServiceLine().equalsIgnoreCase("CTP")) {
				documents = documentDAO.getAttachments(
						submitReq.getOrderId());
			} else if (submitReq.getServiceLine().equalsIgnoreCase("NPWT")) {
				documents = documentDAO.getAttachments(
						submitReq.getRequestId());
			}
			
			MasterDocumentationHistory historyTimeline = historyTimelineDAO
					.getHistoryTimelineById(historyId);
			
			List<HistoryTimelineDocStatus> docObjList = null;
			
			if (historyTimeline != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				
				try {
					docObjList = objectMapper.readValue(
							historyTimeline.getDocumentObject(),
							new TypeReference<List<HistoryTimelineDocStatus>>() {
							});
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception:  {}" , e);
				} 
			}
			
			if (documents != null && !documents.isEmpty()) {
				
				for (MasterDocumentStore doc : documents) {
					//skipping already SUBMITTED
					if (doc != null && doc.getDocumentStatus() != null
							&& doc.getDocumentStatus().equalsIgnoreCase("SUBMITTED")) {
						continue;
					}
					
					if (doc.getDocumentSource() != null
							&& doc.getDocumentSource().equalsIgnoreCase("MANUAL")) {
						
						//Document already available in DB
						doc.setDocumentAvailable(1);
						doc.setDocumentStatus("SUBMITTED");
						
						if(doc.getDocumentType().equalsIgnoreCase("Other")) {
							doc.setDocumentType("CUSTOM_SCANS");
						}
						
						boolean status = documentDAO.saveDocumentContent(submitReq, doc, true);
						
						if (status && doc.getDocumentAvailable() != null
								&& doc.getDocumentAvailable().intValue() == 1) {
							
							if (submitReq.getServiceLine().equalsIgnoreCase("CTP")) {
								
								log.debug("submitReq.getVendorName() : " +submitReq.getVendorName());
								
								if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("LIFENET")) {
									
									Long documentId = 0L;
									Long currentCounter = counters.getOrDefault(doc.getDocumentType(), 0L);
									Long nextCounter = currentCounter + 1L;
									counters.put(doc.getDocumentType(), nextCounter);
									documentId = nextCounter;
									
									log.debug("documentId : " +documentId);
									
									//send to LIFENET S3 bucket
									doc.setDocNotificationStatus("Sent to S3");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									if (lifeNetDocService.uploadFileToLifeNetS3(submitReq, doc, documentId)) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
									} else {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										doc.setDocNotificationStatus("Failed to upload to S3");
										doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
									
								} else if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("KERECIS")) {
									
									doc.setDocNotificationStatus("Sent");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									//Notify Kerecis once doc is ready
									KerecisDocumentRes res = kerecisService.callDocumentNotification(
											doc.getOrderId(),
											doc.getDocumentToken(), doc.getDocRequestId(),
											doc.getDocumentType(), doc.getDocumentAvailable().toString());
									
									if (res != null && res.getResponseCode() == 0) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
										
									} else if (res != null && res.getResponseCode() != 0) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										doc.setDocNotificationStatus("Failed - with code: "
												+ res.getResponseCode());
										doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
								}
							
								
							} else if (submitReq.getServiceLine().equalsIgnoreCase("NPWT")) {
								
								log.debug("submitReq.getVendorName() : " +submitReq.getVendorName());
								
								PrimaryKeyLookup lookup = masterDashboardDAO.primaryKeyLookupByRtrvId(
										Long.valueOf(submitReq.getRequestId()));
								
								String vendorRequestId = "";
								
								if (lookup != null) {
									vendorRequestId = lookup.getPrimaryKey1();
								}
								
								log.info("vendorRequestId : " +vendorRequestId);
								
								if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("SOLVENTUM")) {
									
									doc.setDocNotificationStatus("Sent");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									SolventumDocNotificationRes res = solventumService.callDocumentNotification(
											vendorRequestId, doc.getDocumentToken(), doc.getDocRequestId(),
											doc.getDocumentType(), doc.getDocumentAvailable().toString());
									
									if (res != null && res.isSucceeded()) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
										
									} else if (res != null && !res.isSucceeded()) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										SolvemtumErrorDetails error = res.getError();
										
										doc.setDocNotificationStatus("Failed - with code: "
												+ error.getErrorCode());
										doc.setDocNotificationTimestamp(
												new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
									
								} else if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("APRIA")) {
									
									doc.setDocNotificationStatus("Sent");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									ApriaDocNotificationRes apriaRes = apriaOrderDocService.callDocumentNotification(
											vendorRequestId, doc.getDocumentToken(), doc.getDocRequestId(),
											doc.getDocumentType(), doc.getDocumentAvailable().toString());
									
									if (apriaRes != null && apriaRes.getResponseCode().equalsIgnoreCase("0")) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
										
									} else if (apriaRes != null && !apriaRes.getResponseCode().equalsIgnoreCase("0")) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										doc.setDocNotificationStatus(apriaRes.getResponseMessage());
										doc.setDocNotificationTimestamp(
												new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
								}
							}
							
						}
						
					} else if (doc.getDocumentSource() != null
							&& doc.getDocumentSource().equalsIgnoreCase("IHEAL")) {
						
						log.debug("**** doc.getDocumentType: {}", doc.getDocumentType());
						
						if (doc.getDocumentType() != null
								&& (doc.getDocumentType().equalsIgnoreCase("WOUND_ASSESSMENT")
										|| doc.getDocumentType().equalsIgnoreCase("PROGRESS_NOTES")
										|| doc.getDocumentType().equalsIgnoreCase("PROCEDURE_NOTES")
										|| doc.getDocumentType().equalsIgnoreCase("PROVIDER_ORDER")
										|| doc.getDocumentType().equalsIgnoreCase("PATIENT_HISTORY")
										|| doc.getDocumentType().equalsIgnoreCase("HPI")
										|| doc.getDocumentType().equalsIgnoreCase("PROBLEM_LIST")
										|| doc.getDocumentType().equalsIgnoreCase("DISCHARGE_SUMMARY")
										|| doc.getDocumentType().equalsIgnoreCase("NUTRITIONAL_ASSESSMENT")
										|| doc.getDocumentType().equalsIgnoreCase("ACTIVITY_DAILY_LIVING")
										|| doc.getDocumentType().equalsIgnoreCase("MEDICAL_RECONCILIATION")
										|| doc.getDocumentType().equalsIgnoreCase("LOWER_EXTREMITY"))) {
							
							MasterDocServiceReq docServiceReq = new MasterDocServiceReq();
							docServiceReq.setMasterToken(submitReq.getMasterToken());
							docServiceReq.setUserId(submitReq.getUserId());
							docServiceReq.setPatientId(submitReq.getPatientId());
							docServiceReq.setFacilityId(submitReq.getFacilityId());
							
							if (doc.getIhealDocumentId() != null) {
								docServiceReq.setDocEntityId(doc.getIhealDocumentId().toString());
							} else {
								docServiceReq.setDocEntityId(null);
							}
							
							doc.setIhealDocRequestStatus(SUCCESS);
							doc.setIhealDocRequestTimestamp(new Timestamp(System.currentTimeMillis()));
							
							//Save Document status in Doc Store if iHeal take more time to send doc
							documentDAO.saveDocumentContent(submitReq, doc, false);
							
							IHealDocumentViewPDFGetRes iHealRes = null;

							if (doc.getDocumentType().equalsIgnoreCase("MEDICAL_RECONCILIATION")) {
								iHealRes = callMedRecPDFView(docServiceReq);
							} else {
								iHealRes = callDocumentViewPDFGet(docServiceReq);
							}
								
							if (iHealRes != null
									&& iHealRes.getErrorCode() != null
									&& iHealRes.getErrorCode().equalsIgnoreCase("0")) {
								
								//Save document content to document store table
								String docContent = Base64.getEncoder().encodeToString(iHealRes.getPdfBytes());
								doc.setDocumentContent(docContent);
								doc.setDocDownloadStatus(SUCCESS);
								doc.setDocDownloadTimestamp(new Timestamp(System.currentTimeMillis()));
								doc.setDocumentAvailable(1);
								doc.setDocumentStatus("SUBMITTED");
								doc.setErrorCode(iHealRes.getErrorCode());
								doc.setErrorMessage(iHealRes.getErrorMessage());
								
								log.info("token : " +doc.getDocumentToken());
								log.info("before docObjList : " +docObjList);
								
								docObjList = updateDocDownloadStatus(docObjList, doc.getDocumentToken(), SUCCESS);
								
								log.info("after docObjList : " +docObjList);
								
							} else {
								doc.setDocDownloadStatus(FAILED);
								doc.setDocDownloadTimestamp(new Timestamp(System.currentTimeMillis()));
								doc.setDocumentAvailable(0);
								doc.setDocumentStatus("SUBMITTED");
								doc.setErrorCode(iHealRes.getErrorCode());
								doc.setErrorMessage(iHealRes.getErrorMessage());
								
								docObjList = updateDocDownloadStatus(docObjList, doc.getDocumentToken(), FAILED);
							}
				
						} else if (doc.getDocumentType() != null
								&& (doc.getDocumentType().equalsIgnoreCase("CUSTOM_SCANS")
									|| doc.getDocumentType().equalsIgnoreCase("TEST_RESULTS"))) {
							
							DocServiceReq docServiceReq = new DocServiceReq();
							docServiceReq.setMasterToken(submitReq.getMasterToken());
							docServiceReq.setFacilityId(submitReq.getFacilityId());
							docServiceReq.setPatientId(submitReq.getPatientId());
							docServiceReq.setUserId(submitReq.getUserId());
							docServiceReq.setDocEntityId(doc.getIhealDocumentId().toString());
							
							doc.setIhealDocRequestStatus(SUCCESS);
							doc.setIhealDocRequestTimestamp(new Timestamp(System.currentTimeMillis()));
							
							//Save Document status in Doc Store if iHeal take more time to send doc
							documentDAO.saveDocumentContent(submitReq, doc, false);

							IHealFileGetRes fileGetRes = getCustomScanContent(docServiceReq,doc.getDocumentType());

							if (fileGetRes.getErrorCode() != null && fileGetRes.getErrorCode().equalsIgnoreCase("0")) {
								//Save document content to document store table
								doc.setDocumentContent(fileGetRes.getImageStream());
								doc.setDocMimeType(fileGetRes.getImageMimeType());
								doc.setDocDownloadStatus(SUCCESS);
								doc.setDocDownloadTimestamp(new Timestamp(System.currentTimeMillis()));
								doc.setDocumentAvailable(1);
								doc.setDocumentStatus("SUBMITTED");
								doc.setErrorCode(fileGetRes.getErrorCode());
								doc.setErrorMessage(fileGetRes.getErrorMessage());
								
								docObjList = updateDocDownloadStatus(docObjList, doc.getDocumentToken(), SUCCESS);
							} else {
								doc.setDocDownloadStatus(FAILED);
								doc.setDocDownloadTimestamp(new Timestamp(System.currentTimeMillis()));
								doc.setDocumentAvailable(0);
								doc.setDocumentStatus("SUBMITTED");
								doc.setErrorCode(fileGetRes.getErrorCode());
								doc.setErrorMessage(fileGetRes.getErrorMessage());
								
								docObjList = updateDocDownloadStatus(docObjList, doc.getDocumentToken(), FAILED);
							}
						}
										
						boolean status = documentDAO.saveDocumentContent(submitReq, doc, false);
						
						log.debug("doc.getDocumentAvailable() : " +doc.getDocumentAvailable());
						log.debug("doc.getDocumentAvailable() : " +doc.getDocumentAvailable().intValue());
						log.debug("doc.getDocumentAvailable() : " +(doc.getDocumentAvailable().intValue() == 1));
						
						if (status && doc.getDocumentAvailable() != null
								&& doc.getDocumentAvailable().intValue() == 1) {
							
							if (submitReq.getServiceLine().equalsIgnoreCase("CTP")) {
								
								if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("LIFENET")) {
									
									Long documentId = 0L;
									Long currentCounter = counters.getOrDefault(doc.getDocumentType(), 0L);
									Long nextCounter = currentCounter + 1L;
									counters.put(doc.getDocumentType(), nextCounter);
									documentId = nextCounter;
									
									log.debug("documentId : " +documentId);
									
									//send to LIFENET S3 bucket
									doc.setDocNotificationStatus("Sent to S3");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									if (lifeNetDocService.uploadFileToLifeNetS3(submitReq, doc, documentId)) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
									} else {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										doc.setDocNotificationStatus("Failed to upload to S3");
										doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
									
								} else if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("KERECIS")) {
									
									doc.setDocNotificationStatus("Sent");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									//Notify Kerecis once doc is ready
									KerecisDocumentRes res = kerecisService.callDocumentNotification(doc.getOrderId(),
											doc.getDocumentToken(), doc.getDocRequestId(),
											doc.getDocumentType(), doc.getDocumentAvailable().toString());
									
									if (res != null && res.getResponseCode() == 0) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
										
									} else if (res != null && res.getResponseCode() != 0) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										doc.setDocNotificationStatus("Failed - with code: " + res.getResponseCode());
										doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
								}
							} else if (submitReq.getServiceLine().equalsIgnoreCase("NPWT")) {
								
								PrimaryKeyLookup lookup = masterDashboardDAO.primaryKeyLookupByRtrvId(
										Long.valueOf(submitReq.getRequestId()));
								
								String vendorRequestId = "";
								
								if (lookup != null) {
									vendorRequestId = lookup.getPrimaryKey1();
								}
								
								log.info("vendorRequestId : " +vendorRequestId);
								
								log.debug("submitReq.getVendorName() : " +submitReq.getVendorName());
								
								if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("SOLVENTUM")) {
									
									doc.setDocNotificationStatus("Sent");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									SolventumDocNotificationRes res = solventumService.callDocumentNotification(
											vendorRequestId, doc.getDocumentToken(), doc.getDocRequestId(),
											doc.getDocumentType(), doc.getDocumentAvailable().toString());
									
									if (res != null && res.isSucceeded()) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
										
									} else if (res != null && !res.isSucceeded()) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										SolvemtumErrorDetails error = res.getError();
										
										doc.setDocNotificationStatus("Failed - with code: "
												+ error.getErrorCode());
										doc.setDocNotificationTimestamp(
												new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
									
								} else if (submitReq.getVendorName() != null
										&& submitReq.getVendorName().equalsIgnoreCase("APRIA")) {
									
									doc.setDocNotificationStatus("Sent");
									doc.setDocNotificationTimestamp(new Timestamp(System.currentTimeMillis()));
									documentDAO.saveDocNotificationStatus(submitReq, doc);
									
									ApriaDocNotificationRes apriaRes = apriaOrderDocService.callDocumentNotification(
											vendorRequestId, doc.getDocumentToken(), doc.getDocRequestId(),
											doc.getDocumentType(), doc.getDocumentAvailable().toString());
									
									if (apriaRes != null && apriaRes.getResponseCode().equalsIgnoreCase("0")) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_SUCCESSFUL);
										
									} else if (apriaRes != null && !apriaRes.getResponseCode().equalsIgnoreCase("0")) {
										docObjList = updateVendorStatus(docObjList, doc.getDocumentToken(),
												DOC_FAILED);
										
										doc.setDocNotificationStatus(apriaRes.getResponseMessage());
										doc.setDocNotificationTimestamp(
												new Timestamp(System.currentTimeMillis()));
										documentDAO.saveDocNotificationStatus(submitReq, doc);
									}
								}
							}
						}
					}
				}
				counters.clear();
			}
			
			if (docObjList != null) {
				historyTimelineDAO.updateHistoryTimeline(historyId, docObjList);
			}
			
			docStatus = 1;
		} catch (Exception e) {
			log.error("Exception occured while getting document from iHeal: {}", e.getMessage());
		}
		return docStatus;
	}
	
	private List<HistoryTimelineDocStatus> updateDocDownloadStatus(
			List<HistoryTimelineDocStatus> docList,
			String docToken, String docDownloadStatus) {
		
		if (docList != null && !docList.isEmpty()) {
			
			for (HistoryTimelineDocStatus doc : docList) {
				
				if (doc.getDocumentToken() != null
						&& doc.getDocumentToken().equalsIgnoreCase(docToken)) {
					doc.setDocumentDownloadStatus(docDownloadStatus);
					break;
				}
			}
		}
		return docList;
	}
	
	private List<HistoryTimelineDocStatus> updateVendorStatus(
			List<HistoryTimelineDocStatus> docList,
			String docToken, String vendorStatus) {
		
		if (docList != null && !docList.isEmpty()) {
			
			for (HistoryTimelineDocStatus doc : docList) {
				
				if (doc.getDocumentToken() != null
						&& doc.getDocumentToken().equalsIgnoreCase(docToken)) {
					doc.setVendorDownloadStatus(vendorStatus);
					break;
				}
			}
		}
		return docList;
	}
	
	public IHealDocumentViewPDFGetRes callDocumentViewPDFGet(MasterDocServiceReq req) {

		IHealDocumentViewPDFGetRes fileGetRes = null;

		String url = env.getProperty(BOConstants.IHEAL_DOCUMENT_VIEW_PDF_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealFileGetReq fileGetReq = new IHealFileGetReq();
		fileGetReq.setPrivateKey(privateKey);
		fileGetReq.setMasterToken(req.getMasterToken());
		fileGetReq.setFacilityId(req.getFacilityId());
		fileGetReq.setPatientId(req.getPatientId());
		fileGetReq.setUserId(req.getUserId());
		fileGetReq.setDocumentEntityId(req.getDocEntityId());

		try {
			fileGetRes = new IHealDocumentViewPDFGetRes();
			log.info("IHeal DocumentViewPDFGet URL post started ");
			
			HttpEntity<Object> request = new HttpEntity<>(fileGetReq, getHeaders());
			assert url != null;
			
			ResponseEntity<byte[]> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request, byte[].class);
			
			log.info("IHeal DocumentViewPDFGet URL post Completed ");
			
			byte[] res = sresponse.getBody();
			
			fileGetRes.setErrorCode("0");
			fileGetRes.setErrorMessage("Success");
			fileGetRes.setPdfBytes(res);
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in DocumentViewPDFGet API - ", e);
			
			fileGetRes = new IHealDocumentViewPDFGetRes();
			
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
			
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in DocumentViewPDFGet API: ", e);
			
			fileGetRes = new IHealDocumentViewPDFGetRes();
			
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return fileGetRes;
	}
	//
	public IHealDocumentViewPDFGetRes callMedRecPDFView(MasterDocServiceReq req) {

		IHealDocumentViewPDFGetRes fileGetRes = null;

		String url = env.getProperty(BOConstants.IHEAL_MED_REC_VIEW_PDF_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealFileGetReq fileGetReq = new IHealFileGetReq();
		fileGetReq.setPrivateKey(privateKey);
		fileGetReq.setMasterToken(req.getMasterToken());
		fileGetReq.setFacilityId(req.getFacilityId());
		fileGetReq.setPatientId(req.getPatientId());
		fileGetReq.setUserId(req.getUserId());
		fileGetReq.setReconciliationId(req.getDocEntityId());

		try {
			fileGetRes = new IHealDocumentViewPDFGetRes();
			log.info("IHeal MedRecViewPDFGet URL post started ");
			
			HttpEntity<Object> request = new HttpEntity<>(fileGetReq, getHeaders());
			assert url != null;
			
			ResponseEntity<byte[]> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request, byte[].class);
			
			log.info("IHeal MedRecViewPDFGet URL post Completed ");
			
			byte[] res = sresponse.getBody();
			
			fileGetRes.setErrorCode("0");
			fileGetRes.setErrorMessage("Success");
			fileGetRes.setPdfBytes(res);
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in MedRecViewPDFGet API - ", e);
			
			fileGetRes = new IHealDocumentViewPDFGetRes();
			
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
			
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in MedRecViewPDFGet API: ", e);
			
			fileGetRes = new IHealDocumentViewPDFGetRes();
			
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return fileGetRes;
	}
	
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}
	
	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}
	
	private HashMap<String, Object> extractResp(String responseBody) {
		HashMap<String, Object> data = new HashMap<>();
		String body = responseBody.replace("[{}]", "").replace("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1, tmp.length()));
		}
		return data;
	}
	
	public IHealFileGetRes getCustomScanContent(DocServiceReq req, String docType) {

		IHealFileGetRes fileGetRes = null;

		String url = env.getProperty(BOConstants.IHEAL_FILE_GET_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		
		IHealFileGetReq fileGetReq = new IHealFileGetReq();
		fileGetReq.setPrivateKey(privateKey);
		fileGetReq.setMasterToken(req.getMasterToken());
		fileGetReq.setFacilityId(req.getFacilityId());
		fileGetReq.setPatientId(req.getPatientId());
		fileGetReq.setUserId(req.getUserId());
		fileGetReq.setDocumentEntityId(req.getDocEntityId());
		if(docType.equalsIgnoreCase("TEST_RESULTS")) {
			fileGetReq.setType("TestResults");
		}else {
			fileGetReq.setType("CustomScans");
		}

		try {
			log.info("IHeal FileGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(fileGetReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealFileGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealFileGetRes.class);
			log.info("IHeal FileGet URL post Completed ");
			log.debug("iHeal FileGet Response : {}",
					sresponse.getBody());
			fileGetRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in FileGet API - ",
					e);
			fileGetRes = new IHealFileGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in FileGet API: ",
					e);
			fileGetRes = new IHealFileGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			fileGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			fileGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return fileGetRes;
	}
	
	
	
}
