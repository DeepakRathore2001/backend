package com.healogics.rtrv.bo.Impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dto.ApriaAuthServiceRes;
import com.healogics.rtrv.dto.ApriaDocNotificationRes;
import com.healogics.rtrv.dto.RetrieveDocNotificationReq;

@Service
public class ApriaOrderDocService {
	private final Logger log = LoggerFactory.getLogger(ApriaOrderDocService.class);

	private final Environment env;
	private final RestTemplate restTemplate;

	@Autowired
	public ApriaOrderDocService(Environment env,
			@Qualifier("httpTemplate2") RestTemplate restTemplate) {
		this.env = env;
		this.restTemplate = restTemplate;
	}

	public ApriaDocNotificationRes callDocumentNotification(
			String vendorRequestId, String documentToken,
			String documentRequestId,
			String documentType, String documentAvailable) {
		
		ApriaDocNotificationRes res = null;

		RetrieveDocNotificationReq req = new RetrieveDocNotificationReq();
		req.setVendorRequestId(vendorRequestId);
		req.setDocumentToken(documentToken);
		req.setDocumentRequestId(documentRequestId);
		req.setDocumentType(documentType);
		req.setDocumentAvailable(documentAvailable);

		log.info("RetrieveDocNotificationReq : " + req);
		
		String url = env.getProperty(BOConstants.APRIA_DOC_NOTIFIER_URL);
		log.info("URL : " + url);

		try {
			//Call Apria Auth Service to get access_token
			ApriaAuthServiceRes authRes = callApriaAuthService();

			if (authRes != null && authRes.getResponseCode().equalsIgnoreCase("0")) {

				//Setting access_token in Doc Notifier API Header
				HttpEntity<Object> request = new HttpEntity<>(req,
						getApriaDocNotifierHeaders(authRes.getAccess_token()));

				assert url != null;

				log.info("Apria Document Notification URL post started ");

				ResponseEntity<ApriaDocNotificationRes> sresponse = restTemplate.exchange(
						url, HttpMethod.POST, request,
						ApriaDocNotificationRes.class);

				log.info("Apria Document Notification URL post Completed ");
				log.info("Apria Notification Response : {}", sresponse);

				if (sresponse != null
						&& sresponse.getStatusCode() != null
						&& sresponse.getStatusCode().equals(HttpStatus.ACCEPTED)
						&& sresponse.getStatusCodeValue() == 202) {
					res = new ApriaDocNotificationRes();
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				} else {
					res = new ApriaDocNotificationRes();
					res.setResponseCode("4");
					res.setResponseMessage("Failed");
				}

			} else if (authRes != null
					&& !authRes.getResponseCode().equalsIgnoreCase("0")) {
				res = new ApriaDocNotificationRes();
				res.setResponseCode("1");
				res.setResponseMessage("Failed");
			}

		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callDocumentNotification API - ", e);

			res = new ApriaDocNotificationRes();
			res.setResponseCode("2");
			res.setResponseMessage("Failed - " + e.getMessage());

		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callDocumentNotification API: ", e);

			res = new ApriaDocNotificationRes();
			res.setResponseCode("3");
			res.setResponseMessage("Failed - " + e.getMessage());
		}
		return res;
	}

	public ApriaAuthServiceRes callApriaAuthService() {
		ApriaAuthServiceRes res = null;

		String url = env.getProperty(BOConstants.APRIA_AUTH_URL);
		log.info("URL : " + url);

		try {
			assert url != null;

			//Forming data
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add("grant_type", env.getProperty(BOConstants.APRIA_GRANT_TYPE));
			map.add("client_id", env.getProperty(BOConstants.APRIA_CLIENT_ID));
			map.add("client_secret", env.getProperty(BOConstants.APRIA_CLIENT_SECRET));
			map.add("scope", env.getProperty(BOConstants.APRIA_SCOPE));

			log.info("map : " + map);

			HttpEntity<MultiValueMap<String, String>> request
				= new HttpEntity<MultiValueMap<String, String>>(map,
					getApriaAuthHeaders());

			log.info("Apria OAuth Token URL post started ");
			
			ResponseEntity<ApriaAuthServiceRes> response = restTemplate.exchange(
					url, HttpMethod.POST, request,
					ApriaAuthServiceRes.class);

			log.info("Apria OAuth Token URL post Completed ");
			
			log.info("Apria OAuth Token Response : {}", response);
			log.info("Apria OAuth Token Response body : {}", response.getBody());
			
			if (response != null) {
				res = response.getBody();
				
				if (res != null) {
					res.setResponseCode("0");
					res.setResponseMessage("Success");
				} else {
					res = new ApriaAuthServiceRes();
					res.setResponseCode("3");
					res.setResponseMessage("Failed");
				}
			}
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callApriaAuthService API - ", e);
			List<String> errorList = new ArrayList<>();
			errorList.add(e.getMessage());

			res = new ApriaAuthServiceRes();
			res.setResponseCode("1");
			res.setResponseMessage("Failed");

		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callApriaAuthService API: ", e);
			List<String> errorList = new ArrayList<>();
			errorList.add(e.getMessage());

			res = new ApriaAuthServiceRes();
			res.setResponseCode("2");
			res.setResponseMessage("Failed");
		}
		return res;
	}

	private HttpHeaders getApriaDocNotifierHeaders(String token) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("Authorization", ("Bearer " + token));
		headers.setContentType(MediaType.APPLICATION_JSON);

		log.debug("headers: " + headers);

		return headers;
	}

	private HttpHeaders getApriaAuthHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		log.debug("headers: " + headers);

		return headers;
	}
}
