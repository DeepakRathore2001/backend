package com.healogics.rtrv.bo.Impl;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dto.RetrieveDocNotificationReq;
import com.healogics.rtrv.dto.KerecisDocumentRes;
import com.healogics.rtrv.dto.KerecisNotesObject;
import com.healogics.rtrv.dto.KerecisUpdateDocReq;

@Service
public class KerecisOrderDocService {
	
	private final Logger log = LoggerFactory.getLogger(KerecisOrderDocService.class);
	
	private final Environment env;
	private final RestTemplate restTemplate;

	@Autowired
	public KerecisOrderDocService(Environment env, @Qualifier("httpTemplate1") RestTemplate restTemplate) {
		this.env = env;
		this.restTemplate = restTemplate;
	}
	
	public KerecisDocumentRes callDocumentNotification(
			String vendorRequestId, String documentToken,
			String documentRequestId,
			String documentType, String documentAvailable) {
		KerecisDocumentRes res = null;
		String url = env.getProperty(BOConstants.KERECIS_BASE_URL)
				+ vendorRequestId
				+ BOConstants.KERECIS_DOCUMENT_URL;
		
		log.info("URL : " +url);

		RetrieveDocNotificationReq req = new RetrieveDocNotificationReq();
		req.setVendorRequestId(vendorRequestId);
		req.setDocumentToken(documentToken);
		req.setDocumentRequestId(documentRequestId);
		req.setDocumentType(documentType);
		req.setDocumentAvailable(documentAvailable);
		
		log.info("KerecisDocNotificationReq : " +req);

		try {
			log.info("Kerecis Document Notification URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(req, getKerecisHeaders());
			
			assert url != null;
			
			ResponseEntity<KerecisDocumentRes> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request,
					KerecisDocumentRes.class);
			
			log.info("Kerecis Document Notification URL post Completed ");
			log.info("Kerecis Document Notification Response : {}", sresponse);
			log.debug("Kerecis Document Notification Response body : {}", sresponse.getBody());
			
			res = sresponse.getBody();
			
			if (res != null) {
				if (res.getCode() == 0) {
					res.setResponseCode(res.getCode());
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode(res.getCode());
					res.setResponseMessage("Error");
				}
			}
			
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callDocumentNotification API - ", e);
			res = new KerecisDocumentRes();
			res.setResponseCode(1);
			res.setResponseMessage(e.getMessage());
			
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callDocumentNotification API: ", e);
			res = new KerecisDocumentRes();
			res.setResponseCode(1);
			res.setResponseMessage(e.getMessage());
		}
		return res;
	}
	
	private HttpHeaders getKerecisHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.KERECIS_HOST_NAME));
		headers.add("app-key", env.getProperty(BOConstants.KERECIS_APP_KEY));
		headers.add("app-secret", env.getProperty(BOConstants.KERECIS_APP_SECRECT));
		
		log.debug("headers: " +headers);
		
		return headers;
	}
	
	public KerecisDocumentRes callUpdateDocumentation(String vendorRequestId,
			String retrieveStatus, KerecisNotesObject note) {
		KerecisDocumentRes res = null;
		
		String url = env.getProperty(BOConstants.KERECIS_BASE_URL)
				+ vendorRequestId
				+ BOConstants.KERECIS_DOCUMENT_UPDATE_URL;
		
		log.info("URL : " +url);

		KerecisUpdateDocReq req = new KerecisUpdateDocReq();
		req.setRetrieveStatus(retrieveStatus);
		req.setNote(note);
		
		log.info("KerecisUpdateDocReq : " +req);

		try {
			log.info("Kerecis Update Documentation URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(req, getKerecisHeaders());
			
			assert url != null;
			
			ResponseEntity<KerecisDocumentRes> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request,
					KerecisDocumentRes.class);
			
			log.info("Kerecis Update Documentation URL post Completed ");
			log.info("Kerecis Update Documentation Response : {}", sresponse);
			log.debug("Kerecis Update Documentation Response body : {}", sresponse.getBody());
			
			res = sresponse.getBody();
			
			if (res != null) {
				if (res.getCode() == 0) {
					res.setResponseCode(res.getCode());
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode(res.getCode());
					res.setResponseMessage("Error");
				}
			}
			
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callUpdateDocumentation API - ", e);
			res = new KerecisDocumentRes();
			res.setResponseCode(1);
			res.setResponseMessage(e.getMessage());
			
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callUpdateDocumentation API: ", e);
			res = new KerecisDocumentRes();
			res.setResponseCode(1);
			res.setResponseMessage(e.getMessage());
		}
		return res;
		
	}

}
