package com.healogics.rtrv.bo.Impl;

public class CTPOrderBOImpl {
	
}
