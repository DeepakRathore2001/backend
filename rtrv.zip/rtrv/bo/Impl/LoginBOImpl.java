package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.BOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.BOConstants.ERRORMESSAGE;

import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.bo.LoginBO;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.MasterRetrieveDAO;
import com.healogics.rtrv.dao.UserLoginDAO;
import com.healogics.rtrv.dto.AuthenticateByTokenReq;
import com.healogics.rtrv.dto.AuthenticateByTokenRes;
import com.healogics.rtrv.dto.AuthenticateIntanceByTokenReq;
import com.healogics.rtrv.dto.AuthenticateIntanceByTokenRes;
import com.healogics.rtrv.dto.CipherText;
import com.healogics.rtrv.dto.DocumentURLReq;
import com.healogics.rtrv.dto.IHealUser;
import com.healogics.rtrv.dto.IHealUserFacilityListGetRes;
import com.healogics.rtrv.dto.IhealFacility;
import com.healogics.rtrv.dto.IhealUserReq;
import com.healogics.rtrv.dto.IhealUserdetails;
import com.healogics.rtrv.dto.LoginReq;
import com.healogics.rtrv.dto.LoginRes;
import com.healogics.rtrv.dto.LoginUser;
import com.healogics.rtrv.dto.OAuthReq;
import com.healogics.rtrv.dto.PlainTextObj;
import com.healogics.rtrv.dto.ServiceLineList;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.dto.UserFacilityRes;
import com.healogics.rtrv.dto.UserPreferenceDetails;
import com.healogics.rtrv.dto.VendorLoginRes;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.entity.ServiceLine;
import com.healogics.rtrv.entity.UserPreference;
import com.healogics.rtrv.exception.CustomException;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
@TransactionManager1
public class LoginBOImpl implements LoginBO {
	private final Logger log = LoggerFactory.getLogger(LoginBOImpl.class);

	private final SessionFactory sessionFactory;

	private final RestTemplate restTemplate;

	private final Environment env;

	private final UserLoginDAO userLoginDAO;
	
	private final MasterRetrieveDAO masterRetrieveDAO;

	@Autowired
	public LoginBOImpl(@Qualifier("httpTemplate1") RestTemplate restTemplate, Environment env,
			UserLoginDAO userLoginDAO, @Qualifier("SessionFactory1") SessionFactory sf,
			MasterRetrieveDAO masterRetrieveDAO) {
		this.restTemplate = restTemplate;
		this.env = env;
		this.userLoginDAO = userLoginDAO;
		this.sessionFactory = sf;
		this.masterRetrieveDAO = masterRetrieveDAO;
	}

	@Override
	public LoginRes login(LoginReq req) {
		IhealUserReq ihealUserReq = new IhealUserReq();

		Session session = this.sessionFactory.getCurrentSession();

		byte[] decodeduserNameBytes = Base64.getDecoder()
				.decode(req.getUserName());
		String decodedUserNameString = new String(decodeduserNameBytes);

		byte[] decodedPasswordBytes = Base64.getDecoder()
				.decode(req.getPassword());
		String decodedPasswordString = new String(decodedPasswordBytes);
		
		ihealUserReq
				.setUsername(decodedUserNameString);
		ihealUserReq
				.setPassword(decodedPasswordString);

		IhealUserdetails ihealUserdetails = iheal2Authenticate(ihealUserReq);
		log.debug("ihealUserdetails : {}", ihealUserdetails);
		LoginRes loginRes = null;
		LoginUser loginUser = new LoginUser();

		// Display message when iHeal is down
		if (ihealUserdetails.getErrorCode() != null
				&& !ihealUserdetails.getErrorCode().equalsIgnoreCase("0")) {
			loginRes = new LoginRes();
			loginRes.setResponseCode(ihealUserdetails.getErrorCode());
			loginRes.setResponseMessage(ihealUserdetails.getErrorMessage());
			loginRes.setUserPreferenceDetails(null);
			loginRes.setServiceLineList(null);
			loginRes.setUserRole(null);
			loginRes.setBusinessRole(null);
			loginRes.setIsSuperUser(null);

			loginUser.setUsername(ihealUserReq.getUsername());
			loginUser.setDeviceId(null);
			loginUser.setDeviceIp(null);
			loginUser.setDeviceType("Web");
			loginUser.setErrorCode(ihealUserdetails.getErrorCode());
			loginUser.setErrorMessage(ihealUserdetails.getErrorMessage());
			loginUser.setLoginStatus("Failed");
			loginUser.setLoginFlow("Direct");

		} else if (ihealUserdetails.getErrorCode() != null
				&& ihealUserdetails.getErrorCode().equalsIgnoreCase("0")) {
			loginRes = new LoginRes();
			loginRes.setAccessToken(getJWTToken(ihealUserReq.getUsername()));
			loginRes.setRefreshToken(
					getJWTRefreshToken(ihealUserReq.getUsername()));
			loginRes.setResponseCode(ihealUserdetails.getErrorCode());
			loginRes.setResponseMessage(ihealUserdetails.getErrorMessage());
			loginRes.setIhealUserdetails(ihealUserdetails);

			loginRes.setUserPreferenceDetails(
					retainServiceLine(ihealUserdetails.getUser().getUserId(),ihealUserdetails));

			loginRes.setServiceLineList(getServiceLine());
			log.info("ihealUserdetails.getUser() :  {}",
					ihealUserdetails.getUser());

			loginUser.setUsername(ihealUserdetails.getUser().getUserName());

			String userHql = "From RetrieveUsers r WHERE username = :username "
					+ " AND userId = :userId ";

			RetrieveUsers retrieveUsers = session
					.createQuery(userHql, RetrieveUsers.class)
					.setParameter("username",
							ihealUserdetails.getUser().getUserName())
					.setParameter("userId",
							Long.valueOf(
									ihealUserdetails.getUser().getUserId()))
					.setMaxResults(1).uniqueResult();
			if (retrieveUsers != null) {
				loginRes.setUserRole(retrieveUsers.getRetrieveRole());
				
				List<String> businessRole = new ArrayList<>();
				ObjectMapper objectMapper = new ObjectMapper();
				if(retrieveUsers.getBusinessRole() != null) {
				try {
					businessRole = objectMapper.readValue(
							retrieveUsers.getBusinessRole(),
							new TypeReference<List<String>>() {
							});
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception:  {}" , e);
				}
				}
				
				loginRes.setBusinessRole(businessRole);

				if (retrieveUsers.getBusinessRole() != null && 
						retrieveUsers.getBusinessRole()
						.equalsIgnoreCase("Operations Specialist")) {
					loginUser.setUserRole(retrieveUsers.getBusinessRole());
					loginRes.setIsSuperUser(retrieveUsers.getIsSuperUser());
					loginUser.setErrorCode("51");
					loginUser.setErrorMessage(
							"Restricted Role - Operations Specialist");
					loginUser.setLoginStatus("Failed");
				} else {
					loginUser.setUserRole(
							ihealUserdetails.getUser().getRoles().toString());
					loginUser.setErrorCode(ihealUserdetails.getErrorCode());
					loginRes.setIsSuperUser(retrieveUsers.getIsSuperUser());
					loginUser.setErrorMessage(
							ihealUserdetails.getErrorMessage());
					loginUser.setLoginStatus("Success");
				}
			}

			loginUser.setUserId(ihealUserdetails.getUser().getUserId());
			loginUser.setUserFullname(ihealUserdetails.getUser().getLastName()
					+ ", " + ihealUserdetails.getUser().getFirstName());

			loginUser.setEmailId(ihealUserdetails.getUser().getEmail());
			loginUser.setEmployedBy(
					ihealUserdetails.getUser().getEmployedByDescription());
			loginUser.setLastLoginTimestamp(
					ihealUserdetails.getUser().getLastLogonTime());

			loginUser.setDeviceId(null);
			loginUser.setDeviceIp(null);
			loginUser.setDeviceType("Web");

			loginUser.setLoginFlow("Direct");

			// Save Retrieve users
			userLoginDAO.saveRetrieveUserLogin(ihealUserdetails.getUser());
		}

		log.debug("loginUser : {}", loginUser);

		userLoginDAO.saveUserLogin(loginUser);
		return loginRes;
	}

	@Override
	public LoginRes loginByOAuth(OAuthReq req) {
		IhealUserReq ihealUserReq = new IhealUserReq();

		Session session = this.sessionFactory.getCurrentSession();

		AuthenticateByTokenRes tokenRes = iheal2AuthenticateByToken(req);
		log.debug("tokenRes : {}", tokenRes);
		LoginRes loginRes = null;
		LoginUser loginUser = new LoginUser();

		// ClickStreamReq streamReq = new ClickStreamReq();

		// Display message when iHeal is down
		if (tokenRes.getErrorCode() != null
				&& !tokenRes.getErrorCode().equalsIgnoreCase("0")) {
			loginRes = new LoginRes();
			loginRes.setResponseCode(tokenRes.getErrorCode());
			loginRes.setResponseMessage(tokenRes.getErrorMessage());
			loginRes.setUserPreferenceDetails(null);
			loginRes.setServiceLineList(null);
			loginRes.setFacilities(null);
			loginRes.setUserRole(null);
			loginRes.setBusinessRole(null);
			loginRes.setIsSuperUser(null);
			
			loginUser.setUsername(ihealUserReq.getUsername());
			loginUser.setDeviceId(null);
			loginUser.setDeviceIp(null);
			loginUser.setDeviceType("Web");
			loginUser.setErrorCode(tokenRes.getErrorCode());
			loginUser.setErrorMessage(tokenRes.getErrorMessage());
			loginUser.setLoginStatus("Failed");
			loginUser.setLoginFlow("Direct");

			/*
			 * streamReq.setBluebookId(""); streamReq.setFacilityId(0);
			 * streamReq.setModuleDescription("Login - Failed");
			 * streamReq.setModuleName("Login"); streamReq.setServiceLine("");
			 * streamReq.setUserFullname(req.getEncryptedUserId());
			 * streamReq.setUserId(0L);
			 * streamReq.setUsername(req.getAuthCode());
			 * streamReq.setVendor("");
			 */

		} else if (tokenRes.getErrorCode() != null
				&& tokenRes.getErrorCode().equalsIgnoreCase("0")) {
			loginRes = new LoginRes();
			loginRes.setAccessToken(getJWTToken(ihealUserReq.getUsername()));
			loginRes.setRefreshToken(
					getJWTRefreshToken(ihealUserReq.getUsername()));
			loginRes.setResponseCode(tokenRes.getErrorCode());
			loginRes.setResponseMessage(tokenRes.getErrorMessage());

			IhealUserdetails ihealUserdetails = new IhealUserdetails();
			ihealUserdetails.setErrorCode(tokenRes.getErrorCode());
			ihealUserdetails.setErrorMessage(tokenRes.getErrorMessage());
			// ihealUserdetails.setLastLoginFacilityId(lastLoginFacilityId);
			ihealUserdetails.setMasterToken(tokenRes.getMasterToken());
			ihealUserdetails.setUser(tokenRes.getUser());
			ihealUserdetails.setWarnings(tokenRes.getWarnings());

			loginRes.setUserPreferenceDetails(
					retainServiceLine(tokenRes.getUser().getUserId(), ihealUserdetails));

			loginRes.setServiceLineList(getServiceLine());
			log.info("ihealUserdetails.getUser() :  {}",
					ihealUserdetails.getUser());

			loginUser.setUsername(ihealUserdetails.getUser().getUserName());

			// user facilities
			UserFacilityRes userFacilityRes = getUserFacilities(
					ihealUserdetails.getUser().getUserId(),
					tokenRes.getMasterToken());

			String userHql = "From RetrieveUsers r WHERE username = :username "
					+ " AND userId = :userId ";

			RetrieveUsers retrieveUsers = session
					.createQuery(userHql, RetrieveUsers.class)
					.setParameter("username",
							ihealUserdetails.getUser().getUserName())
					.setParameter("userId",
							Long.valueOf(
									ihealUserdetails.getUser().getUserId()))
					.setMaxResults(1).uniqueResult();
			if (retrieveUsers != null) {
				loginRes.setUserRole(retrieveUsers.getRetrieveRole());
				
				List<String> businessRole = new ArrayList<>();
				ObjectMapper objectMapper = new ObjectMapper();
				if(retrieveUsers.getBusinessRole() != null) {
				try {
					businessRole = objectMapper.readValue(
							retrieveUsers.getBusinessRole(),
							new TypeReference<List<String>>() {
							});
				} catch (JsonProcessingException e) {
					log.error("Json Procession exception:  {}" , e);
				}
				}
				
				loginRes.setBusinessRole(businessRole);
				if (businessRole != null && !businessRole.isEmpty()
						&& businessRole.contains("Operations Specialist")) {
					loginRes.setIsSuperUser(retrieveUsers.getIsSuperUser());
					loginUser.setUserRole(retrieveUsers.getBusinessRole());
					loginUser.setErrorCode("17");
					loginUser.setErrorMessage(
							"Restricted Role - Operations Specialist");
					loginUser.setLoginStatus("Failed");
					ihealUserdetails.setErrorCode("17");
					ihealUserdetails.setErrorMessage(
							"Restricted Role - Operations Specialist");
				} else {
					loginRes.setIsSuperUser(retrieveUsers.getIsSuperUser());
					loginUser.setUserRole(
							ihealUserdetails.getUser().getRoles().toString());
					loginUser.setErrorCode(ihealUserdetails.getErrorCode());
					loginUser.setErrorMessage(
							ihealUserdetails.getErrorMessage());
					loginUser.setLoginStatus("Success");
				}
			} else {
				// Save Retrieve users
				userLoginDAO.saveRetrieveUserLogin(ihealUserdetails.getUser());
			}

				
				
			loginRes.setIhealUserdetails(ihealUserdetails);
			if (userFacilityRes != null
					&& userFacilityRes.getResponseCode().equals("0")) {
				loginRes.setFacilities(userFacilityRes.getFacilities());
				int rowChanged = userLoginDAO.saveUserFacilities(
						ihealUserdetails.getUser().getUserId(),
						userFacilityRes.getFacilities());
			}

			loginUser.setUserId(ihealUserdetails.getUser().getUserId());
			loginUser.setUserFullname(ihealUserdetails.getUser().getLastName()
					+ ", " + ihealUserdetails.getUser().getFirstName());
			loginUser.setUserRole(
					ihealUserdetails.getUser().getRoles().toString());

			loginUser.setEmailId(ihealUserdetails.getUser().getEmail());
			loginUser.setEmployedBy(
					ihealUserdetails.getUser().getEmployedByDescription());
			loginUser.setLastLoginTimestamp(
					ihealUserdetails.getUser().getLastLogonTime());

			loginUser.setDeviceId(null);
			loginUser.setDeviceIp(null);
			loginUser.setDeviceType("Web");
			loginUser.setErrorCode(ihealUserdetails.getErrorCode());
			loginUser.setErrorMessage(ihealUserdetails.getErrorMessage());
			loginUser.setLoginFlow("Direct");
			
			// Save Retrieve users
			userLoginDAO.saveRetrieveUserLogin(ihealUserdetails.getUser());

		}

		log.debug("loginUser : {}", loginUser);

		userLoginDAO.saveUserLogin(loginUser);
		return loginRes;
	}

	private List<ServiceLineList> getServiceLine() {

		List<ServiceLineList> serviceLineList = new ArrayList<>();

		try {
			Session session = this.sessionFactory.getCurrentSession();
			List<ServiceLine> serviceLines = session
					.createQuery("FROM ServiceLine").list();

			if (serviceLines != null) {
				for (ServiceLine serviceLine : serviceLines) {
					ServiceLineList serviceList = new ServiceLineList();
					serviceList.setId(serviceLine.getId());
					serviceList.setServiceLine(serviceLine.getServiceLine());
					serviceList.setServiceLineCode(
							serviceLine.getServiceLineCode());
					serviceList.setVendor(serviceLine.getVendor());
					serviceLineList.add(serviceList);
				}
				log.info("Service Line List:   {}", serviceLineList);
			}
		} catch (Exception e) {
			log.debug("Service Line List Failed!!!!");
		}
		return serviceLineList;
	}

	private UserPreferenceDetails retainServiceLine(String stringUserId, IhealUserdetails ihealUserdetails) {
		Session session = this.sessionFactory.getCurrentSession();
		DateTimeFormatter timeFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd HH:mm:ss");
		UserPreferenceDetails userPreferenceDetails = null;
		UserPreference userPreference = null;
		Long userId = Long.parseLong(stringUserId);
		log.debug("userId:   {}", userId);
		try {
			String hql = "FROM UserPreference WHERE userId = :userId";
			userPreference = session.createQuery(hql, UserPreference.class)
					.setParameter("userId", userId).setMaxResults(1)
					.uniqueResult();
		} catch (Exception e) {
			log.debug("Exception occured : {}", e.getMessage());
		}

		try {
			if (userPreference != null) {
				userPreferenceDetails = new UserPreferenceDetails();

				userPreferenceDetails
						.setColorCodes(userPreference.getAvatarColor());
				userPreferenceDetails
						.setAwdDashboard(userPreference.getAwdDashboard());
				userPreferenceDetails
						.setBluebookId(userPreference.getBluebookId());
				userPreferenceDetails
						.setCreatedBy(userPreference.getCreatedBy());
				userPreferenceDetails.setCreatedTimestamp(userPreference
						.getCreatedTimestamp().format(timeFormat));
				userPreferenceDetails
						.setCtpDashboard(userPreference.getCtpDashboard());
				userPreferenceDetails
						.setFacilityId(userPreference.getFacilityId());
				userPreferenceDetails
						.setLastUpdatedBy(userPreference.getLastUpdatedBy());
				userPreferenceDetails.setLastUpdatedTimestamp(userPreference
						.getLastUpdatedTimestamp().format(timeFormat));
				userPreferenceDetails
						.setNpwtDashboard(userPreference.getNpwtDashboard());
				userPreferenceDetails.setServiceLineDesc(
						userPreference.getServiceLineDesc());
				userPreferenceDetails.setServiceLineCode(
						userPreference.getServiceLineCode());
				userPreferenceDetails
						.setUserFullname(userPreference.getUserFullname());
				userPreferenceDetails.setUserId(userPreference.getUserId());
				userPreferenceDetails.setUsername(userPreference.getUsername());
				userPreferenceDetails.setClearNotifcationTimestamp(
						userPreference.getClearNotificationTimestamp());
			} else {
				userPreference = new UserPreference();
				userPreference.setUserId(Long.valueOf(stringUserId));
				userPreference.setUsername(ihealUserdetails.getUser().getUserName());
				userPreference.setServiceLineCode("AWD");
				userPreference.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()).toLocalDateTime());
				userPreference.setUserFullname(ihealUserdetails.getUser().getLastName()+", "+ihealUserdetails.getUser().getFirstName());
				userPreference.setCreatedBy(ihealUserdetails.getUser().getLastName()+", "+ihealUserdetails.getUser().getFirstName());
				userPreference.setLastUpdatedBy(ihealUserdetails.getUser().getLastName()+", "+ihealUserdetails.getUser().getFirstName());
				userPreference.setLastUpdatedTimestamp(new Timestamp(System.currentTimeMillis()).toLocalDateTime());				
				session.save(userPreference);
			}
			log.info("User Preference Retain Service Line:  {} ",
					userPreferenceDetails);
		} catch (Exception e) {
			log.debug("Retain Service Line failed!!!");
		}
		return userPreferenceDetails;
	}

	@Override
	public IhealUserdetails iheal2Authenticate(IhealUserReq user) {
		IhealUserdetails ihealUserdetails;
		log.debug("Reading properties from application.properties");

		String url = env.getProperty(BOConstants.IHEAL_LOGIN_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		user.setPrivateKey(privateKey);
		try {
			log.info("IHeal login URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(user, getHeaders());
			assert url != null;
			ResponseEntity<IhealUserdetails> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request, IhealUserdetails.class);
			log.info("IHeal login URL post Completed ");
			log.debug("iHeal Auth Response : {}", sresponse.getBody());
			ihealUserdetails = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in LoginBOImpl - ", e);
			ihealUserdetails = new IhealUserdetails();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealUserdetails.setErrorCode(errorResponse.get(ERRORCODE));
			ihealUserdetails.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in LoginBOImpl: ", e);
			ihealUserdetails = new IhealUserdetails();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealUserdetails.setErrorCode(errorResponse.get(ERRORCODE));
			ihealUserdetails.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealUserdetails;
	}

	@Override
	public AuthenticateByTokenRes iheal2AuthenticateByToken(OAuthReq req) {
		AuthenticateByTokenRes ihealUserdetails;
		AuthenticateByTokenReq authReq = new AuthenticateByTokenReq();

		String url = env.getProperty(BOConstants.IHEAL_LOGIN_BY_TOKEN_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		authReq.setPrivateKey(privateKey);
		authReq.setAuthenticateToken(req.getAuthCode());
		authReq.setUserId(req.getEncryptedUserId());

		CipherText cipherText = new CipherText();
		cipherText.setUserId(req.getEncryptedUserId());
		authReq.setCipherTexts(cipherText);

		try {
			log.info("IHeal UserInfo URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(authReq,
					getHeaders());
			assert url != null;
			ResponseEntity<AuthenticateByTokenRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							AuthenticateByTokenRes.class);
			log.info("IHeal UserInfo URL post Completed ");
			log.debug("iHeal UserInfo Response : {}", sresponse.getBody());
			ihealUserdetails = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in iheal2AuthenticateByToken - ",
					e);
			ihealUserdetails = new AuthenticateByTokenRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealUserdetails.setErrorCode(errorResponse.get(ERRORCODE));
			ihealUserdetails.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in iheal2AuthenticateByToken: ",
					e);
			ihealUserdetails = new AuthenticateByTokenRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealUserdetails.setErrorCode(errorResponse.get(ERRORCODE));
			ihealUserdetails.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealUserdetails;
	}

	@Override
	public AuthenticateIntanceByTokenRes authenticateIntanceByToken(
			DocumentURLReq req) {
		AuthenticateIntanceByTokenRes tokenRes;
		AuthenticateIntanceByTokenReq tokenReq = new AuthenticateIntanceByTokenReq();

		String url = env.getProperty(BOConstants.IHEAL_INSTANCE_TOKEN_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		tokenReq.setPrivateKey(privateKey);
		tokenReq.setMasterToken(req.getMasterToken());
		tokenReq.setUserId(req.getUserId());

		PlainTextObj plainTextObj = new PlainTextObj();
		plainTextObj.setDocumentId(req.getDocumentId());
		plainTextObj.setFacilityId(req.getFacilityId());
		tokenReq.setPlainTexts(plainTextObj);

		try {
			log.info("IHeal AuthenticateInstanceByToken URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(tokenReq,
					getHeaders());
			assert url != null;
			ResponseEntity<AuthenticateIntanceByTokenRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							AuthenticateIntanceByTokenRes.class);
			log.info("IHeal AuthenticateInstanceByToken URL post Completed ");
			log.debug("iHeal AuthenticateInstanceByToken Response : {}",
					sresponse.getBody());
			tokenRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in authenticateIntanceByToken - ",
					e);
			tokenRes = new AuthenticateIntanceByTokenRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			tokenRes.setErrorCode(errorResponse.get(ERRORCODE));
			tokenRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in authenticateIntanceByToken: ",
					e);
			tokenRes = new AuthenticateIntanceByTokenRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			tokenRes.setErrorCode(errorResponse.get(ERRORCODE));
			tokenRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return tokenRes;
	}

	private String getJWTToken(String username) {
		String secretKey = env.getProperty(BOConstants.JWT_SECRETKEY);
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils
				.commaSeparatedStringToAuthorityList("ROLE_USER");
		int expTime = Integer
				.parseInt(env.getProperty(BOConstants.JWT_EXPIRATION_TIME));
		String token = Jwts.builder().setId("healogicsrtrvJWT")
				.setSubject(username)
				.claim("authorities",
						grantedAuthorities.stream()
								.map(GrantedAuthority::getAuthority)
								.collect(Collectors.toList()))
				.setIssuedAt(new Date(System.currentTimeMillis()))
				// 10 mins expiration time
				.setExpiration(new Date(System.currentTimeMillis() + expTime))
				.signWith(SignatureAlgorithm.HS512, secretKey.getBytes())
				.compact();
		return "Bearer " + token;
	}

	private String getJWTRefreshToken(String username) {
		String secretKey = env.getProperty(BOConstants.JWT_SECRETKEY);
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils
				.commaSeparatedStringToAuthorityList("ROLE_USER");
		int expTime = Integer.parseInt(
				env.getProperty(BOConstants.JWT_REFRESHTOKEN_EXPIRATION_TIME));
		String token = Jwts.builder().setId("healogicsrtrvJWT")
				.setSubject(username)
				.claim("authorities",
						grantedAuthorities.stream()
								.map(GrantedAuthority::getAuthority)
								.collect(Collectors.toList()))
				.setIssuedAt(new Date(System.currentTimeMillis()))
				// 6 hours expiration time
				.setExpiration(new Date(System.currentTimeMillis() + expTime))
				.signWith(SignatureAlgorithm.HS512,
						((secretKey != null)
								? secretKey.getBytes(StandardCharsets.UTF_8)
								: null))
				.compact();
		return "Bearer " + token;
	}

	@Override
	public IhealUserdetails logout(IHealUser user) {
		IhealUserdetails ihealUserdetails;
		String url = env.getProperty(BOConstants.IHEAL_LOGOUT_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		user.setPrivateKey(privateKey);
		try {
			HttpEntity<Object> request = new HttpEntity<>(user, getHeaders());
			ResponseEntity<IhealUserdetails> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request, IhealUserdetails.class);
			ihealUserdetails = sresponse.getBody();
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			log.error("Http Client Exception occurred in UserBO Impl", e);
			ihealUserdetails = new IhealUserdetails();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			ihealUserdetails.setErrorCode(errorResponse.get(ERRORCODE));
			ihealUserdetails.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		return ihealUserdetails;
	}

	@Override
	public UserPreference getUserPreference(String stringUserId) {
		Session session = this.sessionFactory.getCurrentSession();
		UserPreference userPreference = null;
		Long userId = Long.parseLong(stringUserId);
		log.debug("userId:   {}", userId);
		try {
			String hql = "FROM UserPreference WHERE userId = :userId";
			userPreference = session.createQuery(hql, UserPreference.class)
					.setParameter("userId", userId).setMaxResults(1)
					.uniqueResult();
		} catch (Exception e) {
			log.debug("Exception occured in getUserPreference: {}",
					e.getMessage());
		}
		return userPreference;
	}
	
	@Override
	public void updateUserPreference(String userId, Timestamp currentTime)
			throws CustomException {
		Session session = this.sessionFactory.getCurrentSession();
		try {
			UserPreference userPref = session
					.createQuery("FROM UserPreference WHERE userId = :userId",
							UserPreference.class)
					.setParameter("userId", Long.valueOf(userId))
					.setMaxResults(1).uniqueResult();
			
			if (userPref != null) {
				//userPref.setClearNotificationTimestamp(currentTime);
				userPref.setMasterClearNotificationTimestamp(currentTime);
				session.update(userPref);
			} else {
				UserPreference userPreference = new UserPreference();
				userPreference.setUserId(Long.valueOf(userId));
				//userPreference.setClearNotificationTimestamp(currentTime);
				userPreference.setMasterClearNotificationTimestamp(currentTime);
				session.update(userPreference);
			}
		} catch (Exception e) {
			log.debug("Exception occured in getUserPreference: {}",
					e.getMessage());
		}
	}

	@Override
	public VendorLoginRes authenticateVendor(LoginReq req) {
		VendorLoginRes res = new VendorLoginRes();
		
			if (req == null) {
			// invlaid request
			res.setResponseCode("1");
			res.setResponseMessage("Invalid Request!");
			return res;
		}

		if (req.getUserName() == null || req.getUserName().isEmpty()) {
			// invalid username
			res.setResponseCode("2");
			res.setResponseMessage("Invalid userName!");
			return res;
		}

		if (req.getPassword() == null || req.getPassword().isEmpty()) {
			// invalid password
			res.setResponseCode("3");
			res.setResponseMessage("Invalid password!");
			return res;
		}

		if (masterRetrieveDAO.isValidUser(
				req.getUserName(), req.getPassword())) {
			// Success
			// generate token
			res.setResponseCode("0");
			res.setResponseMessage("Success");
			res.setAccessToken(getJWTToken(req.getUserName()));
			return res;
		} else {
			// Error
			res.setResponseCode("4");
			res.setResponseMessage("Invalid username or password!");
			return res;
		}
	}
	
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {

			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));

		}
		return data;
	}

	@Override
	public UserFacilityRes getUserFacilities(String userId,
			String masterToken) {
		IHealUserFacilityListGetRes facilitiesResponse = null;
		List<String> v2Settings = new ArrayList<>();
		v2Settings.add("RetrieveInterfaces");
		String url = env.getProperty(BOConstants.IHEAL_USERFACILITIES_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		IHealUser user = new IHealUser();
		user.setMasterToken(masterToken);
		user.setUserId(userId);
		user.setPrivateKey(privateKey);
		user.setFacilitySettings(v2Settings);
		UserFacilityRes userFacilityRes = new UserFacilityRes();
		try {
			log.info("IHeal userfacility URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(user, getHeaders());

			assert url != null;
			ResponseEntity<IHealUserFacilityListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealUserFacilityListGetRes.class);
			facilitiesResponse = sresponse.getBody();
			log.debug("SettingsV2:  " + sresponse.getBody().getFacilities()
					.get(0).getSettingsV2());
			log.debug("iHeal facilitiesResponse : " + facilitiesResponse);
		} catch (HttpClientErrorException e) {
			log.error(String.format(
					"HttpClientErrorException occurred in getUserFacilities: %s",
					e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(String.format(
					"HttpStatusCodeException occurred in getUserFacilities: %s",
					e));
			facilitiesResponse = new IHealUserFacilityListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			facilitiesResponse.setErrorCode(errorResponse.get(ERRORCODE));
			facilitiesResponse.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		if (facilitiesResponse != null
				&& facilitiesResponse.getErrorCode() != null
				&& facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			List<UserFacilities> facilities = new ArrayList<>();
			for (IhealFacility facility : facilitiesResponse.getFacilities()) {
				UserFacilities fac = new UserFacilities();
				fac.setFacilityId(facility.getFacilityId());
				fac.setFacilityBluebookId(facility.getFacilityBluebookId());
				fac.setFacilityName(facility.getFacilityName());
				fac.setConfiguration(facility.getConfiguration());
				fac.setSettings(facility.getSettings());
				fac.setSettingsV2(facility.getSettingsV2());
				facilities.add(fac);
			}
			userFacilityRes.setFacilities(facilities);

			userFacilityRes.setResponseCode("0");
			userFacilityRes.setResponseDesc("Success");
		} else if (facilitiesResponse != null
				&& facilitiesResponse.getErrorCode() != null
				&& !facilitiesResponse.getErrorCode().equalsIgnoreCase("0")) {
			userFacilityRes.setResponseCode(facilitiesResponse.getErrorCode());
			userFacilityRes
					.setResponseDesc(facilitiesResponse.getErrorMessage());
		}
		log.debug("UserFacilityRes:  {}", userFacilityRes);
		return userFacilityRes;
	}

}
