package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.BOConstants.DOC_PENDING;
import static com.healogics.rtrv.constants.BOConstants.FAILED;
import static com.healogics.rtrv.constants.BOConstants.FAILED_RESPONSE_CODE;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_COMPLETED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.MASTER_HISTORY_TIMELINE_SIZE_DOUBLE;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_WAITING_FOR_DOCUMENTS_STATUS;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_POST_APPLN_APPEAL_STATUS;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_PRE_APPLN_APPEAL_STATUS;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_BILLING_SUPPORT_STATUS;
import static com.healogics.rtrv.constants.BOConstants.MASTER_HISTORY_TIMELINE_SIZE;
import static com.healogics.rtrv.constants.BOConstants.MASTER_NOTES_SIZE;
import static com.healogics.rtrv.constants.BOConstants.MASTER_NOTES_SIZE_DOUBLE;
import static com.healogics.rtrv.constants.BOConstants.NOT_FOUND;
import static com.healogics.rtrv.constants.BOConstants.NOT_FOUND_RESPONSE_CODE;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_COMPLETED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_NEW_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_RETURNED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_SUBMITTED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.SUCCESS;
import static com.healogics.rtrv.constants.BOConstants.SUCCESS_RESPONSE_CODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORMESSAGE;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_RECEIVED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.KERECIS_CANCELED_STATUS;
import static com.healogics.rtrv.constants.BOConstants.RETRIEVE_CANCELED_STATUS;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.bo.MasterChartReviewBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.MasterChartReviewDAO;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dto.APIResponse;
import com.healogics.rtrv.dto.GetOrderUpdateReq;
import com.healogics.rtrv.dto.GetSavedAttachmentRes;
import com.healogics.rtrv.dto.HistoryTimelineDocStatus;
import com.healogics.rtrv.dto.HistoryUserNotes;
import com.healogics.rtrv.dto.IHealCustomScanListReq;
import com.healogics.rtrv.dto.IHealDocumentObj;
import com.healogics.rtrv.dto.IHealPatientLoadObj;
import com.healogics.rtrv.dto.IHealPatientLoadReq;
import com.healogics.rtrv.dto.IHealPatientLoadRes;
import com.healogics.rtrv.dto.IHealVisitDocumentListGetRes;
import com.healogics.rtrv.dto.IHealVisitListGetRes;
import com.healogics.rtrv.dto.IHealVisitObj;
import com.healogics.rtrv.dto.KerecisDocumentRes;
import com.healogics.rtrv.dto.MasterChartDetailsObj;
import com.healogics.rtrv.dto.MasterChartDetailsReq;
import com.healogics.rtrv.dto.MasterChartDetailsRes;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.dto.MasterHistoryTimelineDetails;
import com.healogics.rtrv.dto.MasterHistoryTimelineRes;
import com.healogics.rtrv.dto.MasterModifyRecordReq;
import com.healogics.rtrv.dto.MasterNoteByIdRes;
import com.healogics.rtrv.dto.MasterNotesDetails;
import com.healogics.rtrv.dto.MasterNotesListRes;
import com.healogics.rtrv.dto.MasterSaveAttachmentObj;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartRes;
import com.healogics.rtrv.dto.RetrieveDocNotificationReq;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.SaveResponse;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsRes;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.dto.VisitDocumentListReq;
import com.healogics.rtrv.dto.VisitDocumentObj;
import com.healogics.rtrv.dto.VisitDocumentRes;
import com.healogics.rtrv.dto.VisitObj;
import com.healogics.rtrv.dto.VisitsListRes;
import com.healogics.rtrv.entity.CTPDashboard;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.entity.MasterDocumentationHistory;
import com.healogics.rtrv.entity.MasterUserNotes;
import com.healogics.rtrv.entity.UniformDashboard;

@Service
public class MasterChartReviewBOImpl implements MasterChartReviewBO {
	private final Logger log = LoggerFactory.getLogger(MasterChartReviewBOImpl.class);
	
	private final MasterChartReviewDAO masterChartReviewDAO;
	private final MasterHistoryTimelineDAO historyTimelineDAO;
	private final Environment env;
	private final RestTemplate restTemplate1;
	private final RestTemplate restTemplate2;
	private final MasterPDFService pdfService;
	private final KerecisOrderDocService kerecisService;
	
	public MasterChartReviewBOImpl(MasterChartReviewDAO masterChartReviewDAO,
			MasterHistoryTimelineDAO historyTimelineDAO, Environment env,
			@Qualifier("httpTemplate1") RestTemplate restTemplate1,
			@Qualifier("httpTemplate2") RestTemplate restTemplate2,
			MasterPDFService pdfService,
			KerecisOrderDocService kerecisService) {
		this.masterChartReviewDAO = masterChartReviewDAO;
		this.historyTimelineDAO = historyTimelineDAO;
		this.env = env;
		this.restTemplate1 = restTemplate1;
		this.restTemplate2 = restTemplate2;
		this.pdfService = pdfService;
		this.kerecisService = kerecisService;
	}
	
	@Override
	public RTRVAPIResponse saveMasterNotes(SaveMasterNotesReq req) {
		RTRVAPIResponse res = new RTRVAPIResponse();
		
		try {
			req = masterChartReviewDAO.saveMasterNotes(req);
			
			res.setResponseCode(SUCCESS_RESPONSE_CODE);
			res.setResponseMessage(SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while saving notes: " +e.getMessage());
			res.setResponseCode(FAILED_RESPONSE_CODE);
			res.setResponseMessage(FAILED);
		}
		
		return res;
	}
	
	public KerecisDocumentRes callDocumentNotificationForTesting() {
		KerecisDocumentRes res = null;
		String url = "https://emrapiqa.azurewebsites.net/api/DocumentNotifier";
		log.info("URL : " +url);
 
		RetrieveDocNotificationReq req = new RetrieveDocNotificationReq();
		req.setVendorRequestId("278");
		req.setDocumentToken("MzM4OSMyMDI0IzQyIzEkJDM4NTYyMDIjODYyMDEwNTQjRE1FIzE3NzMyJCQzMzg5IzM4NTYyMDIjMTc3MzIjMQ==");
		req.setDocumentRequestId("ca1190f2-23b1-4dc2-9022-bf006be4190b");
		req.setDocumentType("WOUND_ASSESSMENT");
		req.setDocumentAvailable("1");
		log.info("KerecisDocNotificationReq : " +req);
 
		try {
			log.info("Kerecis Document Notification URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(req, getKerecisHeadersForTesting());
			assert url != null;
			ResponseEntity<KerecisDocumentRes> sresponse = restTemplate2.exchange(
					url, HttpMethod.POST, request,
					KerecisDocumentRes.class);
			log.info("Kerecis Document Notification URL post Completed ");
			log.info("Kerecis Document Notification Response : {}", sresponse);
			log.debug("Kerecis Document Notification Response body : {}", sresponse.getBody());
			res = sresponse.getBody();
			if (res != null) {
				if (res.getCode() == 0) {
					res.setResponseCode(res.getCode());
					res.setResponseMessage("Success");
				} else {
					res.setResponseCode(res.getCode());
					res.setResponseMessage("Error");
				}
			}
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callDocumentNotification API - ", e);
			res = new KerecisDocumentRes();
			res.setResponseCode(1);
			res.setResponseMessage(e.getMessage());
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callDocumentNotification API: ", e);
			res = new KerecisDocumentRes();
			res.setResponseCode(1);
			res.setResponseMessage(e.getMessage());
		}
		return res;
	}
	private HttpHeaders getKerecisHeadersForTesting() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", "emrapiqa.azurewebsites.net");
		headers.add("x-functions-key", "ARRCpdQ5EsPkFpAtjrd9N84KGGOayMg8JFKLyPLN5pX_AzFuTq0XDA==");
		//headers.add("app-secret", env.getProperty(BOConstants.KERECIS_APP_SECRECT));
		log.debug("headers: " +headers);
		return headers;
	}

	@Override
	public MasterChartDetailsRes getChartData(MasterChartDetailsReq req) {
		MasterChartDetailsRes res = new MasterChartDetailsRes();
		try {
			MasterChartDetailsObj details = null;
			if(req.getServiceLine().equalsIgnoreCase("CTP")) {
				details = masterChartReviewDAO.getchartDetails(req);
				
			} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
				details = masterChartReviewDAO.getUniformChartDetails(req);
			}
			if (details != null) {
				res.setChartReviewDetails(details);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching CTP Chart Details: {}"
					, e.getMessage());
		}
		return res;
	}
	
	@Override
	public MasterNotesListRes getMasterNotesList(String orderId, int index, String serviceLine) {
		MasterNotesListRes res = new MasterNotesListRes();
		List<MasterNotesDetails> notesDetailsList = new ArrayList<>();
		
		try {
			List<MasterUserNotes> notesList = masterChartReviewDAO.getMasterNotesList(
					orderId, index,serviceLine);
			
			Long totalCount = masterChartReviewDAO.getNotesCount(orderId);

			boolean isExhausted = false;

			int noteSize = MASTER_NOTES_SIZE;
			double noteSizeDouble = MASTER_NOTES_SIZE_DOUBLE;
			
			if(serviceLine.equalsIgnoreCase("NPWT") || serviceLine.equalsIgnoreCase("CTP")) {
				noteSize = noteSize - 5;
				noteSizeDouble = noteSizeDouble - 5.0;
			}
			
			if ((index + noteSize) >= totalCount) {
				isExhausted = true;
				res.setNextIndex(0);
			} else {
				res.setNextIndex(index + noteSize);
			}
			
			if (notesList != null) {
				for (MasterUserNotes notes : notesList) {
					MasterNotesDetails details = new MasterNotesDetails();
					details.setNoteId(notes.getNoteId());
					details.setAttemptCategory(notes.getAttemptCategory());
					details.setAttemptType(notes.getAttemptType());
					details.setBluebookId(notes.getBluebookId());
					details.setDescription(notes.getDescription());
					details.setFacilityId(notes.getFacilityId() + "");
					details.setFollowupDate(notes.getFollowupDate());
					details.setLastUpdatedTimestamp(
							notes.getLastUpdatedTimestamp());
					details.setLastUpdatedUserFullname(
							notes.getLastUpdatedUserFullname());
					details.setLastUpdatedUserId(
							notes.getLastUpdatedUserId() + "");
					details.setLastUpdatedUsername(
							notes.getLastUpdatedUsername());
					details.setPatientFullname(notes.getPatientFullname());
					details.setPatientId(notes.getPatientId() + "");
					details.setContactMethod(notes.getContactMethod());
					details.setContact(notes.getContact());
					
					notesDetailsList.add(details);
				}
			}
			res.setCurrentIndex(index);
			res.setTotalCount(totalCount);
			res.setTotalPage(Math.ceil(totalCount / noteSizeDouble));
			res.setExhausted(isExhausted);
			
			res.setNotes(notesDetailsList);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
		} catch (Exception e) {
			res.setNotes(notesDetailsList);
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public MasterNoteByIdRes getNoteById(String noteId) {
		MasterNoteByIdRes res = new MasterNoteByIdRes();
		try {
			MasterUserNotes userNote = masterChartReviewDAO.getNoteById(noteId);
			MasterNotesDetails details = new MasterNotesDetails();

			if (userNote != null) {
				details.setNoteId(userNote.getNoteId());
				details.setAttemptCategory(userNote.getAttemptCategory());
				details.setAttemptType(userNote.getAttemptType());
				details.setBluebookId(userNote.getBluebookId());
				details.setDeleteFlag(userNote.isDeleteFlag());
				details.setDescription(userNote.getDescription());
				details.setFacilityId(userNote.getFacilityId() + "");
				details.setFollowupDate(userNote.getFollowupDate());
				details.setLastUpdatedTimestamp(
						userNote.getLastUpdatedTimestamp());
				details.setLastUpdatedUserFullname(
						userNote.getLastUpdatedUserFullname());
				details.setLastUpdatedUserId(userNote.getLastUpdatedUserId() + "");
				details.setLastUpdatedUsername(userNote.getLastUpdatedUsername());
				details.setPatientFullname(userNote.getPatientFullname());
				details.setPatientId(userNote.getPatientId() + "");
			}

			res.setNote(details);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching Note By Id Details: {}",
					e.getMessage());

			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);

		}
		return res;
	}
	
	
	@Override
	public SaveResponse saveMasterChartDetails(MasterSaveChartReq req) {
		SaveResponse res = new SaveResponse();
		try {
			if (req.getServiceLine().equalsIgnoreCase("CTP")) {
				masterChartReviewDAO.saveMasterChartDetails(req);

			} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
				masterChartReviewDAO.saveUniformChartDetails(req);
			}
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error(
					"Exception occured while saving CTP Record: {}"
							, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	private String getFileTypeForS3(String doctype) {
		String fileType = "";
		switch (doctype) {			
			case "CUSTOM_SCANS" :
				fileType = "CustomScans";
				break;
			case "PROBLEM_LIST" :
				fileType = "ProblemList";
				break;
			case "PROCEDURE_NOTES" :
				fileType = "Debridements";
				break;
			case "PROGRESS_NOTES" :
				fileType = "ProgressNotes";
				break;
			case "WOUND_ASSESSMENT" :
				fileType = "WoundAssessments";
				break;
			case "PATIENT_HISTORY" :
				fileType = "HxROS";
				break;
			case "TEST_RESULTS" :
				fileType = "TestResults";
				break;
			case "LOWER_EXTREMITY" :
				fileType = "LEAsmt";
				break;
			case "ACTIVITY_DAILY_LIVING" :
				fileType = "ActivityDailyLiving";
				break;
			case "DISCHARGE_SUMMARY" :
				fileType = "DischargeInstructions";
				break;
			case "PROVIDER_ORDER" :
				fileType = "Orders";
				break;
			case "NUTRITIONAL_ASSESSMENT" :
				fileType = "NutritionAssessment";
				break;
			case "MEDICAL_RECONCILIATION" :
				fileType = "MedicalRecord";
				break;
			case "INSURANCE_CARD" :
				fileType = "InsuranceCard";
				break;
			case "OPERATIVE_REPORT" :
				fileType = "OperativeReport";
				break;
			default :
				fileType = doctype;
				break;
		}
		return fileType;
	}
	
	@Override
	public GetSavedAttachmentRes getSavedDocuments(MasterChartDetailsReq req) {
		GetSavedAttachmentRes res = new GetSavedAttachmentRes();
		List<MasterSaveAttachmentObj> attachmentObjs = new ArrayList<>();
		List<MasterDocumentStore> docStoreList = null;
		try {
			if(req.getOrderId() != null) {
		    docStoreList = masterChartReviewDAO.getAttachments(req.getOrderId());
			}
			log.debug("DocStoreList Size: {}",docStoreList.size());
			if(docStoreList != null && !docStoreList.isEmpty()) {
				
				for(MasterDocumentStore doc : docStoreList) {
					MasterSaveAttachmentObj docObj = new MasterSaveAttachmentObj();
					if(doc.getIhealDocumentId() != null){
						docObj.setDocumentEntityId(doc.getIhealDocumentId().toString());
					} else {
						docObj.setDocumentEntityId(null);
					}
					
					if (doc.getIhealVersionId() != null) {
						docObj.setVersionId(doc.getIhealVersionId().toString());
					} else {
						docObj.setVersionId(null);
					}
					
					String[] forTime = doc.getDocDownloadTimestamp()
							.toString().split(" ");
					docObj.setAddedDate(forTime[0]);
					docObj.setDocumentContent(" ");
					docObj.setDocumentName(doc.getDocumentName());
					docObj.setDocumentSource(doc.getDocumentSource());
					docObj.setDocumentToken(doc.getDocumentToken());
					docObj.setDocumentType(getFileTypeForS3(doc.getDocumentType()));
					if(doc.getDocumentSource().equalsIgnoreCase("MANUAL")) {
						docObj.setIsManualDoc(true);
					}else {
						docObj.setIsManualDoc(false);
					}
					if(doc.getDocumentStatus().equalsIgnoreCase("SAVED")) {
						docObj.setIsSubmitted(0);
					}else {
						docObj.setIsSubmitted(1);
					}
					docObj.setDeleted(false);
					docObj.setNewFile(false);
					
					attachmentObjs.add(docObj);
				}
				res.setDocuments(attachmentObjs);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			}  
			  if(attachmentObjs != null && attachmentObjs.isEmpty()) {
				res.setResponseCode("21");
				res.setResponseMessage("No Attachment found!");
				res.setDocuments(new ArrayList<>());
			}
			
		} catch (Exception e) {
			log.error(
					"Exception occured while Fetching Saved Attachments: {}"
							, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public MasterHistoryTimelineRes getOrderHistory(String orderId, int index) {
		MasterHistoryTimelineRes res = new MasterHistoryTimelineRes();
		res.setRequestId(UUID.randomUUID().toString());
		try {
			
			List<MasterHistoryTimelineDetails> historyList = new ArrayList<>();
			
			List<MasterDocumentationHistory> docHistoryList
					= historyTimelineDAO.getOrderHistory(orderId, index);
			
			log.debug("docHistoryList : "+docHistoryList);
			
			Long totalCount = historyTimelineDAO.getHistoryCount(orderId);
			
			log.debug("totalCount : "+totalCount);

			boolean isExhausted = false;

			if ((index + MASTER_HISTORY_TIMELINE_SIZE) >= totalCount) {
				isExhausted = true;
				res.setNextIndex(0);
			} else {
				res.setNextIndex(index + MASTER_HISTORY_TIMELINE_SIZE);
			}
			
			if (docHistoryList != null && docHistoryList.size() > 0) {
				
				for (MasterDocumentationHistory docHistory : docHistoryList) {
					log.debug("docHistory : "+docHistory);
					
					MasterHistoryTimelineDetails history = new MasterHistoryTimelineDetails();
					history.setHistoryId(docHistory.getHistoryId());
					history.setLastUpdatedTimestamp(docHistory.getLastUpdatedTimestamp());
					history.setLastUpdatedUserFullname(docHistory.getLastUpdatedUserFullname());
					history.setLastUpdatedUserId(docHistory.getLastUpdatedUserId());
					history.setLastUpdatedUsername(docHistory.getLastUpdatedUsername());
					history.setRetrieveStatus(docHistory.getRetrieveStatus());
					
					ObjectMapper objectMapper = new ObjectMapper();
					
					VendorStatus vendorStatus = new VendorStatus();
					
					if (docHistory.getVendorStatus() != null) {
						try {
							vendorStatus = objectMapper.readValue(
									docHistory.getVendorStatus(),
									new TypeReference<VendorStatus>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing VendorStatus:  {}" , e);
						} 
					}
					
					HistoryUserNotes userNotes = new HistoryUserNotes();
					
					if (docHistory.getUserNotes() != null) { 
						try {
							userNotes = objectMapper.readValue(
									docHistory.getUserNotes(),
									new TypeReference<HistoryUserNotes>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing HistoryUserNotes:  {}" , e);
						}
					}
					
					log.debug("docHistory.getDocumentObject : " +docHistory.getDocumentObject());
					
					List<HistoryTimelineDocStatus> docStatus = new ArrayList<>();
					
					if (docHistory.getDocumentObject() != null) { 
						try {
							docStatus = objectMapper.readValue(
									docHistory.getDocumentObject(),
									new TypeReference<List<HistoryTimelineDocStatus>>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Exeption while processing HistoryTimelineDocStatus:  {}" , e);
						} 
					}
					
					history.setUserNotes(userNotes);
					history.setVendorStatus(vendorStatus);
					history.setDocumentStatus(docStatus);
					
					historyList.add(history);
				}
			}
			
			res.setCurrentIndex(index);
			res.setTotalCount(totalCount);
			res.setTotalPage(Math.ceil(totalCount / MASTER_HISTORY_TIMELINE_SIZE_DOUBLE));
			res.setExhausted(isExhausted);
			
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
			res.setHistoryList(historyList);
			
		} catch (Exception e) {
			log.error("Exception occured while fetching order history details : {}",
					e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setHistoryList(null);
		}
		return res;
	}
	
	@Override
	public MasterSubmitChartRes masterSubmitChart(MasterSubmitChartReq req) {
		MasterSubmitChartRes res = new MasterSubmitChartRes();
		
		if (req.getServiceLine().equalsIgnoreCase("CTP")) {
			res = masterSubmitChartCTP(req);

		} else if (req.getServiceLine().equalsIgnoreCase("NPWT")) {
			res = masterSubmitChartNPWT(req);
		}
		
		return res;
	}
	
	private MasterSubmitChartRes masterSubmitChartNPWT(MasterSubmitChartReq req) {
		MasterSubmitChartRes res = new MasterSubmitChartRes();
		
		try {
			UniformDashboard dashboard = masterChartReviewDAO.getUniformDashboard(
					req.getRequestId());
			
			if (dashboard != null) {
				MasterSaveChartReq saveChartReq = new MasterSaveChartReq();
				saveChartReq.setOrderId(req.getOrderId());
				saveChartReq.setDocuments(req.getDocuments());
				saveChartReq.setLastUpdatedUserFullName(req.getLastUpdatedUserFullName());
				saveChartReq.setLastUpdatedUserId(req.getLastUpdatedUserId());
				saveChartReq.setLastUpdatedUserName(req.getLastUpdatedUserName());
				saveChartReq.setServiceLine(req.getServiceLine());
				saveChartReq.setRequestId(req.getRequestId());
				saveChartReq.setVendorName(req.getVendorName());
				
				log.debug("saveChartReq : " +saveChartReq);
				
				boolean isSuccess = masterChartReviewDAO.saveDocuments(saveChartReq);
				
				log.debug("isSuccess : " +isSuccess);
				
				//make Submitted entry in History timeline
				Integer historyId = historyTimelineDAO.getHistoryId();

				MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
				historyTimeline.setRequestId(req.getRequestId());
				historyTimeline.setHistoryId(historyId + 1);
				historyTimeline.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
				historyTimeline.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
				historyTimeline.setLastUpdatedUsername(req.getLastUpdatedUserName());
				
				historyTimeline.setRetrieveStatus("Submitted");
				VendorStatus vendorStatus = new VendorStatus();
				vendorStatus.setCurrentStatus(getVendorStatus(dashboard.getVendorId(),
						dashboard.getVendorStatus()));
				historyTimeline.setVendorStatus(vendorStatus);

				String[] nameStrings = req.getLastUpdatedUserFullName().split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				userNotesObj.setDescription(nameStrings[1] + " " + nameStrings[0]
						+ "# submitted the chart to vendor");
				historyTimeline.setUserNotes(userNotesObj);

				historyTimeline.setDocStatusObj(getDocumentDetails(req.getRequestId()));
				
				log.debug("historyTimeline : " +historyTimeline);

				historyTimelineDAO.saveHistoryTimeline(historyTimeline);
				
				log.debug("Created History timeline: ");
				
				//Need to de-couple this call
				int docSaveStatus = pdfService.saveDocumentContent(req,
						historyTimeline.getHistoryId());
				
				Long noOfUpdates =  masterChartReviewDAO.getNotesCount(req.getRequestId());
				
				List<MasterDocumentStore> docs= masterChartReviewDAO.getAttachments(req.getRequestId());
				
				int filesSent = (docs == null) ? 0
						: docs.size();
				
				masterChartReviewDAO.updateNPWTSubmitStatus(req, noOfUpdates, filesSent);
				
				//make Completed entry in History timeline
				Integer historyId1 = historyTimelineDAO.getHistoryId();

				MasterHistoryTimeline historyTimeline1 = new MasterHistoryTimeline();
				historyTimeline1.setRequestId(req.getRequestId());
				historyTimeline1.setHistoryId(historyId1 + 1);
				historyTimeline1.setLastUpdatedUserFullname("Retrieve System");
				historyTimeline1.setLastUpdatedUserId(0L);
				historyTimeline1.setLastUpdatedUsername("Retrieve System");
				
				historyTimeline1.setRetrieveStatus("Completed");
				VendorStatus vendorStatus1 = new VendorStatus();
				vendorStatus1.setCurrentStatus(getVendorStatus(dashboard.getVendorId(),
						dashboard.getVendorStatus()));
				historyTimeline1.setVendorStatus(vendorStatus1);

				HistoryUserNotes userNotesObj1 = new HistoryUserNotes();
				userNotesObj1.setDescription("Chart completed");
				historyTimeline1.setUserNotes(userNotesObj1);

				//historyTimeline1.setDocStatusObj(getDocumentDetails(req.getRequestId()));
				
				log.debug("historyTimeline : " +historyTimeline1);

				historyTimelineDAO.saveHistoryTimeline(historyTimeline1);
				
				log.debug("Created History timeline: ");
				
				res.setResponseCode(SUCCESS_RESPONSE_CODE);
				res.setResponseMessage(SUCCESS);

			} else {
				res.setResponseCode(FAILED_RESPONSE_CODE);
				res.setResponseMessage(FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured in masterSubmitChartNPWT: " +e.getMessage());
			res.setResponseCode(FAILED_RESPONSE_CODE);
			res.setResponseMessage(FAILED);
		}
		return res;
	}
	
	private MasterSubmitChartRes masterSubmitChartCTP(MasterSubmitChartReq req) {
		MasterSubmitChartRes res = new MasterSubmitChartRes();
		res.setRequestId(UUID.randomUUID().toString());
		try {
			CTPDashboard dashboard = masterChartReviewDAO.getDashboard(req.getOrderId());
			
			if (dashboard != null) {
				MasterSaveChartReq saveChartReq = new MasterSaveChartReq();
				saveChartReq.setOrderId(req.getOrderId());
				saveChartReq.setDocuments(req.getDocuments());
				saveChartReq.setLastUpdatedUserFullName(req.getLastUpdatedUserFullName());
				saveChartReq.setLastUpdatedUserId(req.getLastUpdatedUserId());
				saveChartReq.setLastUpdatedUserName(req.getLastUpdatedUserName());
				saveChartReq.setServiceLine(req.getServiceLine());
				
				log.debug("saveChartReq : " +saveChartReq);

				boolean isSuccess = masterChartReviewDAO.saveDocuments(saveChartReq);
				
				log.debug("isSuccess : " +isSuccess);
				
				//make entry in History timeline
				Integer historyId = historyTimelineDAO.getHistoryId();

				MasterHistoryTimeline historyTimeline = new MasterHistoryTimeline();
				historyTimeline.setRequestId(req.getOrderId());
				historyTimeline.setHistoryId(historyId + 1);
				historyTimeline.setLastUpdatedUserFullname(req.getLastUpdatedUserFullName());
				historyTimeline.setLastUpdatedUserId(Long.valueOf(req.getLastUpdatedUserId()));
				historyTimeline.setLastUpdatedUsername(req.getLastUpdatedUserName());
				
				historyTimeline.setRetrieveStatus("Submitted");
				VendorStatus vendorStatus = new VendorStatus();
				vendorStatus.setCurrentStatus(dashboard.getVendorStatus());
				historyTimeline.setVendorStatus(vendorStatus);

				String[] nameStrings = req.getLastUpdatedUserFullName().split(", ");

				HistoryUserNotes userNotesObj = new HistoryUserNotes();
				userNotesObj.setDescription(nameStrings[1] + " " + nameStrings[0]
						+ "# submitted the chart to vendor");
				historyTimeline.setUserNotes(userNotesObj);
				historyTimeline.setDocStatusObj(getDocumentDetails(req.getOrderId()));
				log.debug("historyTimeline : " +historyTimeline);

				historyTimelineDAO.saveHistoryTimeline(historyTimeline);
				log.debug("Created History timeline: ");
				
				//Need to de-couple this call
				int docSaveStatus = pdfService.saveDocumentContent(req,
						historyTimeline.getHistoryId());
				
				Long noOfUpdates =  masterChartReviewDAO.getNotesCount(req.getOrderId());
				
				List<MasterDocumentStore> docs= masterChartReviewDAO.getAttachments(req.getOrderId());
				
				int filesSent = (docs == null) ? 0
						: docs.size();
				
				masterChartReviewDAO.updateSubmitStatus(req,noOfUpdates, filesSent);
				
				res.setResponseCode(SUCCESS_RESPONSE_CODE);
				res.setResponseMessage(SUCCESS);

			} else {
				res.setResponseCode(FAILED_RESPONSE_CODE);
				res.setResponseMessage(FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured in masterSubmitChartCTP: " +e.getMessage());
			res.setResponseCode(FAILED_RESPONSE_CODE);
			res.setResponseMessage(FAILED);
		}
		return res;
	}
	
	private List<HistoryTimelineDocStatus> getDocumentDetails(String requestId) {
		List<HistoryTimelineDocStatus> docDetails = new ArrayList<>();
		try {
			List<MasterDocumentStore> documents = masterChartReviewDAO.getAttachments(
					requestId);
			log.debug("Documents: {}",documents);

			if (documents != null && !documents.isEmpty()) {
				for (MasterDocumentStore doc : documents) {
					//skipping already SUBMITTED
					if (doc != null && doc.getDocumentStatus() != null
							&& doc.getDocumentStatus().equalsIgnoreCase("SUBMITTED")) {
						continue;
					}
					
					HistoryTimelineDocStatus docStatus = new HistoryTimelineDocStatus();
					docStatus.setDocumentToken(doc.getDocumentToken());
					docStatus.setDocumentName(doc.getDocumentName());
					docStatus.setDocumentSource(doc.getDocumentSource());
					docStatus.setDocumentType(getFileTypeForS3(doc.getDocumentType()));
					docStatus.setDocumentDownloadStatus(doc.getDocDownloadStatus());
					docStatus.setVendorDownloadStatus(DOC_PENDING);
					docStatus.setDocEntityId(doc.getIhealDocumentId());
					docStatus.setVersionId(doc.getIhealVersionId());
					docStatus.setFacilityId(doc.getFacilityId());
					docDetails.add(docStatus);
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while generating documents: {}", e.getMessage());
		}
		return docDetails;
	}
	
	@Override
	public APIResponse updateOrderInformation(GetOrderUpdateReq req) {
		APIResponse res = new APIResponse();
		res.setRequestId(UUID.randomUUID().toString());
		try {
			
			if (req.getVendorId() == BOConstants.CTP_VENDOR_ID) {
				//CTP
				CTPDashboard ctpData = masterChartReviewDAO.getRecordByRequestId(
						req.getVendorRequestId());

				if (ctpData == null) {
					res.setResponseCode(NOT_FOUND_RESPONSE_CODE);
					res.setResponseMessage(NOT_FOUND);

				} else {
					String retrieveStatus = ctpData.getRetrieveStatus();

					if (retrieveStatus != null
							&& !retrieveStatus.isEmpty()
							&& req.getVendorStatus() != null
							&& !req.getVendorStatus().isEmpty()
							&& (retrieveStatus.equalsIgnoreCase(RETRIEVE_SUBMITTED_STATUS)
									|| retrieveStatus.equalsIgnoreCase(RETRIEVE_COMPLETED_STATUS))
							&& (req.getVendorStatus().equalsIgnoreCase(KERECIS_WAITING_FOR_DOCUMENTS_STATUS)
									|| req.getVendorStatus().equalsIgnoreCase(KERECIS_POST_APPLN_APPEAL_STATUS)
									|| req.getVendorStatus().equalsIgnoreCase(KERECIS_PRE_APPLN_APPEAL_STATUS)
									|| req.getVendorStatus().equalsIgnoreCase(KERECIS_BILLING_SUPPORT_STATUS))) {

						req.setRetrieveStatus(RETRIEVE_RETURNED_STATUS);
						
					} else {
						if (req.getVendorStatus()
								.equalsIgnoreCase(KERECIS_WAITING_FOR_DOCUMENTS_STATUS)) {
							req.setRetrieveStatus(RETRIEVE_NEW_STATUS);

						} else if (req.getVendorStatus().equalsIgnoreCase(KERECIS_COMPLETED_STATUS)) {
							req.setRetrieveStatus(RETRIEVE_COMPLETED_STATUS);

						} else if (req.getVendorStatus().equalsIgnoreCase(KERECIS_RECEIVED_STATUS)) {
							req.setRetrieveStatus(RETRIEVE_NEW_STATUS);
							
						} else if (req.getVendorStatus().equalsIgnoreCase(KERECIS_CANCELED_STATUS)) {
							req.setRetrieveStatus(RETRIEVE_CANCELED_STATUS);
							
						} else {
							req.setRetrieveStatus(retrieveStatus);
						}
					}
					
					log.debug("req : " +req);

					masterChartReviewDAO.updateOrderInformation(req);
					res.setResponseCode(SUCCESS_RESPONSE_CODE);
					res.setResponseMessage(SUCCESS);
				}
			} else if (req.getVendorId() == BOConstants.NPWT_VENDOR_ID) {
				
				//Handle updateDocumentation API for NPWT here
				
				res.setResponseCode(FAILED_RESPONSE_CODE);
				res.setResponseMessage(FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while Updating Order Information: " +e.getMessage());
			res.setResponseCode(FAILED_RESPONSE_CODE);
			res.setResponseMessage(FAILED);
		}
		return res;
	}
	
	@Override
	public VisitDocumentRes getVisitDocumentList(VisitDocumentListReq req) {

		VisitDocumentRes response = new VisitDocumentRes();

		IHealVisitDocumentListGetRes visitRes = null;
		String url = env.getProperty(BOConstants.IHEAL_VISIT_DOCUMENT_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		customScanReq.setVisitId(req.getVisitId());

		// List<String> validDocumentTypes =
		// Arrays.asList("ProgressNoteDocument", "HBODocument",
		// "WoundAssessmentDocument", "DebridementDocument",
		// "MultiWoundChartDocument",
		// "TCOMDocument","MultiWoundChartNotesDocument");

		try {
			log.info("IHeal VisitDocumentListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealVisitDocumentListGetRes> sresponse = restTemplate1
					.exchange(url, HttpMethod.POST, request,
							IHealVisitDocumentListGetRes.class);
			log.info("IHeal VisitDocumentListGet URL post Completed ");
			log.debug("iHeal VisitDocumentListGet Response : {}",
					sresponse.getBody());
			visitRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in VisitDocumentListGet API - ",
					e);
			visitRes = new IHealVisitDocumentListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			visitRes.setErrorCode(errorResponse.get(ERRORCODE));
			visitRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in VisitDocumentListGet API: ",
					e);
			visitRes = new IHealVisitDocumentListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			visitRes.setErrorCode(errorResponse.get(ERRORCODE));
			visitRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		
		List<VisitDocumentObj> documentList = new ArrayList<>();
		if (visitRes != null
				&& visitRes.getErrorCode() != null
				&& visitRes.getErrorCode()
						.equalsIgnoreCase("0")) {
			List<IHealDocumentObj> visitDocs = visitRes
					.getDocuments();

			if (visitDocs != null && !visitDocs.isEmpty()) {
				for (IHealDocumentObj iHealObj : visitDocs) {
					VisitDocumentObj doc = new VisitDocumentObj();
					doc.setDocumentEntityId(iHealObj.getDocumentEntityId());
					doc.setVersionId(iHealObj.getVersionId());
					doc.setDocumentType(iHealObj.getDocumentType());
					doc.setFacilityId(iHealObj.getFacilityId());
					doc.setPatientId(iHealObj.getPatientId());
					doc.setVisitId(iHealObj.getVisitId());
					doc.setVisitDateTime(iHealObj.getVisitDateTime());
					doc.setAddedDateTime(iHealObj.getAddedDateTime());
					doc.setSignatureRequirementMet(iHealObj.isSignatureRequirementMet());
					documentList.add(doc);
				}
				response.setResponseCode("0");
				response.setResponseMessage(BOConstants.SUCCESS);
			}

			Map<String, List<VisitDocumentObj>> visitDocMap = documentList
					.stream().collect(Collectors
							.groupingBy(VisitDocumentObj::getDocumentType));

			log.debug("visitDocMap : {}", visitDocMap);
			response.setDocumentsList(visitDocMap);

		} else if (visitRes != null
				&& visitRes.getErrorCode() != null
				&& !visitRes.getErrorCode()
						.equalsIgnoreCase("0")) {
			response.setResponseCode(visitRes.getErrorCode());
			response.setResponseMessage(
					visitRes.getErrorMessage());
		} else {
			response.setResponseCode("25");
			response.setResponseMessage("Invalid Response");
		}
		
		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}

		return response;
	}
	
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}
	
	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')), tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}

	@Override
	public VisitsListRes getVisitsList(VisitDocumentListReq req) {
		
		VisitsListRes response = new VisitsListRes();

		IHealVisitListGetRes visitListRes = null;
		String url = env.getProperty(BOConstants.IHEAL_VISIT_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());
		
		String startDateString = "";
		String endDateString = "";
		
		if (req.getStartDate() != null && req.getEndDate() != null
				&& !req.getStartDate().isEmpty()
				&& !req.getEndDate().isEmpty()) {
			startDateString = req.getStartDate();
			endDateString = req.getEndDate();
		} else {
			//Call PatientLoad API to get Patient Admission Date
			LocalDate admissionDate = getPatientAdmissionDate(req);
			
			LocalDate currentDate = LocalDate.now();
			LocalDate startDate = currentDate.minusDays(365);
			
			if (admissionDate != null) {
				startDate = admissionDate;
			}
			
			LocalDate endDate = currentDate;
			
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("yyyy-MM-dd");
			startDateString = startDate.format(formatter);
			endDateString = endDate.format(formatter);
		}
		
		customScanReq.setStartDate(startDateString);
		customScanReq.setEndDate(endDateString);

		try {
			log.info("IHeal VisitListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealVisitListGetRes> sresponse = restTemplate2
					.exchange(url, HttpMethod.POST, request,
							IHealVisitListGetRes.class);
			log.info("IHeal VisitListGet URL post Completed ");
			log.debug("iHeal VisitListGet Response : {}",
					sresponse.getBody());
			visitListRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in VisitListGet API - ",
					e);
			visitListRes = new IHealVisitListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			visitListRes.setErrorCode(errorResponse.get(ERRORCODE));
			visitListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in VisitListGet API: ",
					e);
			visitListRes = new IHealVisitListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			visitListRes.setErrorCode(errorResponse.get(ERRORCODE));
			visitListRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
	//	
		List<VisitObj> visitList = new ArrayList<>();
		if (visitListRes != null
				&& visitListRes.getErrorCode() != null
				&& visitListRes.getErrorCode()
						.equalsIgnoreCase("0")) {
			List<IHealVisitObj> visitObjs = visitListRes
					.getVisits();

			if (visitObjs != null && !visitObjs.isEmpty()) {
				for (IHealVisitObj iHealObj : visitObjs) {
					VisitObj doc = new VisitObj();
					doc.setVisitId(iHealObj.getVisitId());
					doc.setDateOfService(iHealObj.getVisitDateTime());
					doc.setVisitTypeCode(iHealObj.getVisitTypeCode());
					doc.setVisitTypeDescription(iHealObj.getVisitTypeDescription());
					doc.setServiceLineId(iHealObj.getServiceLineId());
					doc.setServiceLineDescription(iHealObj.getServiceLineDescription());
					doc.setVisitStatus(iHealObj.getVisitStatus());
					visitList.add(doc);
				}
				response.setResponseCode("0");
				response.setResponseMessage(BOConstants.SUCCESS);
			}
			
			response.setVisitList(visitList);

		} else if (visitListRes != null
				&& visitListRes.getErrorCode() != null
				&& !visitListRes.getErrorCode()
						.equalsIgnoreCase("0")) {
			response.setResponseCode(visitListRes.getErrorCode());
			response.setResponseMessage(
					visitListRes.getErrorMessage());
		} else {
			response.setResponseCode("25");
			response.setResponseMessage("Invalid Response");
		}
		
		if (response.getVisitList() != null
				&& response.getVisitList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Visits found!");
		}
		
		return response;
	}
	
	@Override
	public SaveResponse modifyRecord(MasterModifyRecordReq req) {
		SaveResponse res = new SaveResponse();
		try {
			masterChartReviewDAO.masterModifyRecord(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error(
					"Exception occured while modifyRecord: {}"
							, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public ViewAttachmentRes getAttachmentContent(MasterChartDetailsReq req) {
		ViewAttachmentRes res = new ViewAttachmentRes();

		try {
			res = masterChartReviewDAO.viewManualAttachment(req);
		} catch (Exception e) {
			log.error("Exception occured while viewing Manual Attachments: "
					, e.getMessage());
		}

		return res;
	}
	
	private LocalDate getPatientAdmissionDate(VisitDocumentListReq req) {
		LocalDate admissionDate = null;
		IHealPatientLoadRes patientLoadRes = null;
		String url = env.getProperty(BOConstants.IHEAL_PATIENT_LOAD_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
		
		log.debug("url : " +url);

		IHealPatientLoadReq patientLoadReq = new IHealPatientLoadReq();
		patientLoadReq.setPrivateKey(privateKey);
		patientLoadReq.setMasterToken(req.getMasterToken());
		patientLoadReq.setFacilityId(req.getFacilityId());
		patientLoadReq.setPatientId(req.getPatientId());
		patientLoadReq.setUserId(req.getUserId());
		
		try {
			log.info("IHeal PatientLoad URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(patientLoadReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealPatientLoadRes> sresponse = restTemplate2
					.exchange(url, HttpMethod.POST, request,
							IHealPatientLoadRes.class);
			log.info("IHeal PatientLoad URL post Completed ");
			log.debug("iHeal PatientLoad Response : {}",
					sresponse.getBody());
			patientLoadRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in PatientLoad API - ",
					e);
			patientLoadRes = new IHealPatientLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			patientLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			patientLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in PatientLoad API: ",
					e);
			patientLoadRes = new IHealPatientLoadRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			patientLoadRes.setErrorCode(errorResponse.get(ERRORCODE));
			patientLoadRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}
		
		
		try {
			if (patientLoadRes != null
					&& patientLoadRes.getErrorCode() != null
					&& patientLoadRes.getErrorCode().equalsIgnoreCase("0")) {
				IHealPatientLoadObj patientObj = patientLoadRes.getPatient();
				
				if (patientObj != null) {
					String admissionDateStr = patientObj.getAdmissionDate();
					log.debug("admissionDateStr : " +admissionDateStr);
					
					if (admissionDateStr == null || admissionDateStr.isEmpty()) {
						String preRegDateStr = patientObj.getPreregistrationDate();
						log.debug("preRegDateStr : " +preRegDateStr);
						
						if (preRegDateStr != null && !preRegDateStr.isEmpty()) {
							//2024-10-03T00:00:00
							//Convert String date to LocalDate
							admissionDate = LocalDate.parse(preRegDateStr,
									DateTimeFormatter.ofPattern("yyyy-MM-ddTHH:mm:ss"));
							
							log.debug("preRegDate : " +admissionDate);
						}
					} else {
						admissionDate = LocalDate.parse(admissionDateStr,
								DateTimeFormatter.ofPattern("yyyy-MM-ddTHH:mm:ss"));
						
						log.debug("admissionDate : " +admissionDate);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception occured : " +e.getMessage());
		}
		
		log.debug("final - admissionDate : " +admissionDate);
		return admissionDate;
		
	}
	
	private String getVendorStatus(Integer vendorId, String orderStatus) {
		String vendorStatus = orderStatus;
		
		if (vendorId == 5) {
			switch (orderStatus) {
			case DAOConstants.SOLVENTUM_FULL_MR_REQUEST: {
				vendorStatus = DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER: {
				vendorStatus = DAOConstants.VENDOR_ORDER_RELEASE_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_1: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_1_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_SUB_CYCLE_2: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_2_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_3: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_3_STATUS;
			}
				break;
				
			case DAOConstants.SOLVENTUM_SUB_CYCLE_4: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_4_STATUS;
			}
				break;
			
			case DAOConstants.SOLVENTUM_ADDITIONAL_DOC_REQUIRED: {
				vendorStatus = DAOConstants.VENDOR_ADDITIONAL_DOC_REQUIRED;
			}
				break;
				
			default:
				break;
			}
		}
		return vendorStatus;
	}
	@Override
	public UpdatePatientDetailsRes updatePatientDetails(
			UpdatePatientDetailsReq req) {
		UpdatePatientDetailsRes res = new UpdatePatientDetailsRes();
		try {
			masterChartReviewDAO.updatePatientDetails(req);
			res.setResponseCode("0");
			res.setResponseDesc(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while Saving Notes Details: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;
	}
}