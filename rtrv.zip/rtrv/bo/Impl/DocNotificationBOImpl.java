package com.healogics.rtrv.bo.Impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.DocNotificationBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.DocNotificationDAO;
import com.healogics.rtrv.dto.DocumentNotificationReq;
import com.healogics.rtrv.dto.DocumentNotificationRes;
import com.healogics.rtrv.exception.CustomException;

@Service
public class DocNotificationBOImpl implements DocNotificationBO {
	private final Logger log = LoggerFactory.getLogger(DocNotificationBOImpl.class);

	private final DocNotificationDAO docNotificationDAO;

	private final PDFService pdfService;
	
	@Autowired
	public DocNotificationBOImpl(DocNotificationDAO docNotificationDAO, PDFService pdfService) {
		this.docNotificationDAO = docNotificationDAO;
		this.pdfService = pdfService;
	}

	@Override
	public DocumentNotificationRes getDocNotification(DocumentNotificationReq req)
			throws CustomException {
		DocumentNotificationRes res = new DocumentNotificationRes();
		try {
			log.info("Updating notification status in db..");
			
			docNotificationDAO.saveDocNotification(req);
			
			log.info("Updated notification status in db..");
			
			log.info("Invoking processPDFDocument..");
			
			pdfService.processPDFDocument(req);
			
			log.info("Done processPDFDocument..");
			
			res.setErrorCode("0");
			res.setErrorMessage(BOConstants.SUCCESS);
			
		} catch (Exception e) {
			log.error("Exception occured : {}",e.getMessage());
			res.setErrorCode("1");
			res.setErrorMessage(BOConstants.FAILED);
		}
		log.info("Sending resposne back to iHeal...");
		return res;
	}
}
