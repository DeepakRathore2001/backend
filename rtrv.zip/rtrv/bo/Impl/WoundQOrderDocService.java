package com.healogics.rtrv.bo.Impl;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dto.WoundQOrderDetailsRes;
import com.healogics.rtrv.dto.WoundQOrderDetailsReq;

@Service
public class WoundQOrderDocService {

	private final Logger log = LoggerFactory.getLogger(WoundQOrderDocService.class);

	private final Environment env;
	private final RestTemplate restTemplate;

	@Autowired
	public WoundQOrderDocService(Environment env, @Qualifier("httpTemplate1") RestTemplate restTemplate) {
		this.env = env;
		this.restTemplate = restTemplate;
	}

	public WoundQOrderDetailsRes callOrderDetails(Integer patientId,
			Integer vendorId, String orderToken) {

		WoundQOrderDetailsRes res = null;

		String url = env.getProperty(BOConstants.WOUNDQ_BASE_URL)
				+ env.getProperty(BOConstants.WOUNDQ_DOCUMENT_URL);

		log.info("URL : " + url);

		WoundQOrderDetailsReq req = new WoundQOrderDetailsReq();
		req.setOrderToken(orderToken);
		req.setPatientId(patientId);
		req.setVendorId(vendorId);

		log.info("WoundQDocNotificationReq : " + req);

		try {
			log.info("WoundQ Get Order Details URL post started ");

			HttpEntity<Object> request = new HttpEntity<>(req, getWoundQHeaders());

			assert url != null;

			ResponseEntity<WoundQOrderDetailsRes> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request,
					WoundQOrderDetailsRes.class);

			log.info("WoundQ Get Order Details URL post Completed ");
			log.debug("WoundQ Get Order Details Response body : {}", sresponse.getBody());

			res = sresponse.getBody();

		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callOrderDetails API - ", e);
			res = new WoundQOrderDetailsRes();
			res.setResponseCode(1);

		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callOrderDetails API: ", e);
			res = new WoundQOrderDetailsRes();
			res.setResponseCode(1);
		}
		return res;
	}

	private HttpHeaders getWoundQHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.WOUNDQ_HOST_NAME));
		headers.add("app-key", env.getProperty(BOConstants.WOUNDQ_APP_KEY));
		headers.add("app-secret", env.getProperty(BOConstants.WOUNDQ_APP_SECRECT));
		headers.add("vendorId", env.getProperty(BOConstants.WOUNDQ_VENDOR_ID));

		log.debug("headers: " + headers);

		return headers;
	}
}
