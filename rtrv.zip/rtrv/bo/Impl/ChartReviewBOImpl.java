package com.healogics.rtrv.bo.Impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.ChartReviewBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.ChartReviewDAO;
import com.healogics.rtrv.dto.ChartReviewDetails;
import com.healogics.rtrv.dto.ChartReviewReq;
import com.healogics.rtrv.dto.ChartReviewRes;
import com.healogics.rtrv.dto.IHealPatientObj;
import com.healogics.rtrv.dto.IHealPatientSearchRes;
import com.healogics.rtrv.dto.ModifyRecordReq;
import com.healogics.rtrv.dto.NoteByIdRes;
import com.healogics.rtrv.dto.NotesDetails;
import com.healogics.rtrv.dto.NotesListRes;
import com.healogics.rtrv.dto.PatientSearchObj;
import com.healogics.rtrv.dto.PatientSearchReq;
import com.healogics.rtrv.dto.PatientSearchRes;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveNotesRes;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.SaveResponse;
import com.healogics.rtrv.dto.SubmitRequest;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsRes;
import com.healogics.rtrv.dto.UserRolesDetails;
import com.healogics.rtrv.dto.UserRolesRes;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.entity.UserNotes;
import com.healogics.rtrv.utils.CommonUtils;

import static com.healogics.rtrv.constants.DAOConstants.NOTES_SIZE;
import static com.healogics.rtrv.constants.DAOConstants.NOTES_SIZE_DOUBLE;

@Service
public class ChartReviewBOImpl implements ChartReviewBO {
	private final Logger log = LoggerFactory.getLogger(ChartReviewBOImpl.class);
	
	private final ChartReviewDAO chartReviewDAO;
	
	@Autowired
	public ChartReviewBOImpl(ChartReviewDAO chartReviewDAO) {
		this.chartReviewDAO = chartReviewDAO;
	}

	@Override
	public ChartReviewRes getChartReviewData(ChartReviewReq req) {
		ChartReviewRes res = new ChartReviewRes();
		try {
			ChartReviewDetails details = chartReviewDAO.getchartDetails(req);

			if (details != null) {
				res.setChartReviewDetails(details);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching ChartReview Details: {}"
					, e.getMessage());
		}
		return res;
	}

	@Override
	public SaveResponse saveDetailsnAttachments(SaveRequest req) {
		SaveResponse res = new SaveResponse();
		try {
			chartReviewDAO.saveRequest(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error(
					"Exception occured while saving ChartReview Details and attachments: {}"
							, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public SaveResponse submitRecord(SubmitRequest req) {
		SaveResponse res = new SaveResponse();
		try {
			boolean status = chartReviewDAO.submitRecord(req);
			log.error("status : " +status);

			if (status) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while submit ChartReview Details: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public SaveNotesRes saveNotes(SaveNotesReq req) {
		SaveNotesRes res = new SaveNotesRes();
		try {
			
			if (req.getDescription() != null
					&& !req.getDescription().isEmpty()) {
				
				if (req.getDescription().contains("\n")) {
					String updatedDesc = req.getDescription().replace("\n", " ");
					
					log.info("updatedDesc : " +updatedDesc);
					
					req.setDescription(updatedDesc);
				}
				
			}
			
			chartReviewDAO.saveNotes(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while Saving Notes Details: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public SaveResponse modifyRecord(ModifyRecordReq req) {
		SaveResponse res = new SaveResponse();
		try {
			chartReviewDAO.modifyRecord(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error(
					"Exception occured while modifyRecord: {}"
							, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public NotesListRes getNotesData(ChartReviewReq req) {
		NotesListRes res = new NotesListRes();
		List<NotesDetails> notesDetailsList = new ArrayList<>();
		try {
			List<UserNotes> noteList = chartReviewDAO.getNotesList(req);

			Long totalCount = chartReviewDAO.getNotesCount(req.getMedRecId(),
					req.getBhcInvoiceOrderId());

			int index = req.getIndex();
			boolean isExhausted = false;

			if ((index + NOTES_SIZE) >= totalCount) {
				isExhausted = true;
				res.setNextIndex(0);
			} else {
				res.setNextIndex(index + NOTES_SIZE);
			}
			if (noteList != null) {
				for (UserNotes notes : noteList) {
					NotesDetails details = new NotesDetails();
					details.setNoteId(notes.getNoteId());
					details.setAddendumReceived(notes.getAddendumReceived());
					details.setAddendumSent(notes.isAddendumSent());
					details.setAttemptCategory(notes.getAttemptCategory());
					details.setAttemptType(notes.getAttemptType());
					details.setBhcInvoiceOrderNo(
							notes.getBhcInvoiceOrderNo() + "");
					details.setBhcMedicalRecordId(
							notes.getBhcMedicalRecordId() + "");
					details.setBluebookId(notes.getBluebookId());
					details.setDeleteFlag(notes.isDeleteFlag());
					details.setDescription(notes.getDescription());
					details.setFacilityId(notes.getFacilityId() + "");
					details.setFollowupDate(notes.getFollowupDate());
					details.setLastUpdatedTimestamp(
							notes.getLastUpdatedTimestamp());
					details.setLastUpdatedUserFullname(
							notes.getLastUpdatedUserFullname());
					details.setLastUpdatedUserId(
							notes.getLastUpdatedUserId() + "");
					details.setLastUpdatedUsername(
							notes.getLastUpdatedUsername());
					details.setPatientFullname(notes.getPatientFullname());
					details.setPatientId(notes.getPatientId() + "");
					details.setPatientNotSeen30Days(
							notes.getPatientNotSeen30Days());
					details.setReceivedRX(notes.getReceivedRX());
					details.setIsRXSent(notes.getRXSent());
					details.setContactMethod(notes.getContactMethod());
					notesDetailsList.add(details);

				}

				res.setCurrentIndex(index);
				res.setTotalCount(totalCount);
				res.setTotalPage(Math.ceil(totalCount / NOTES_SIZE_DOUBLE));
				res.setExhausted(isExhausted);

			}

			res.setNotes(notesDetailsList);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching NotesList Details: {}"
					, e.getMessage());

			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setNotes(notesDetailsList);
			res.setNextIndex(req.getIndex());
			res.setCurrentIndex(req.getIndex());
			res.setTotalPage(0);
			res.setExhausted(false);

		}
		return res;
	}

	@Override
	public UserRolesRes getUserRoles(boolean isSuperUser) {
		UserRolesRes res = new UserRolesRes();
		List<UserRolesDetails> usersList = new ArrayList<>();
		try {
			List<RetrieveUsers> retrieveUserList = chartReviewDAO
					.getUserRolesList(isSuperUser);

			if (retrieveUserList != null) {
				for (RetrieveUsers list : retrieveUserList) {
					UserRolesDetails rolesDetails = new UserRolesDetails();
					rolesDetails.setUserId(list.getUserId() + "");
					rolesDetails.setUsername(list.getUsername());
					rolesDetails.setUserFullname(list.getUserFullName());
					rolesDetails.setEmailId(list.getEmailId());
					rolesDetails.setUserRoles(list.getRetrieveRole());
					rolesDetails.setIsSuperUser(list.getIsSuperUser());

					usersList.add(rolesDetails);

				}
			}

			res.setUserList(usersList);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching UserRoles Details: {}"
					, e.getMessage());

			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);

		}
		return res;
	}

	@Override
	public NoteByIdRes getNoteById(String noteId) {
		NoteByIdRes res = new NoteByIdRes();

		try {
			UserNotes userNote = chartReviewDAO.getNoteById(noteId);
			NotesDetails details = new NotesDetails();
			if (userNote != null) {

				details.setNoteId(userNote.getNoteId());
				details.setAddendumReceived(userNote.getAddendumReceived());
				details.setAddendumSent(userNote.isAddendumSent());
				details.setAttemptCategory(userNote.getAttemptCategory());
				details.setAttemptType(userNote.getAttemptType());
				details.setBhcInvoiceOrderNo(
						userNote.getBhcInvoiceOrderNo() + "");
				details.setBhcMedicalRecordId(
						userNote.getBhcMedicalRecordId() + "");
				details.setBluebookId(userNote.getBluebookId());
				details.setDeleteFlag(userNote.isDeleteFlag());
				details.setDescription(userNote.getDescription());
				details.setFacilityId(userNote.getFacilityId() + "");
				details.setFollowupDate(userNote.getFollowupDate());
				details.setLastUpdatedTimestamp(
						userNote.getLastUpdatedTimestamp());
				details.setLastUpdatedUserFullname(
						userNote.getLastUpdatedUserFullname());
				details.setLastUpdatedUserId(
						userNote.getLastUpdatedUserId() + "");
				details.setLastUpdatedUsername(
						userNote.getLastUpdatedUsername());
				details.setPatientFullname(userNote.getPatientFullname());
				details.setPatientId(userNote.getPatientId() + "");
				details.setPatientNotSeen30Days(
						userNote.getPatientNotSeen30Days());
				details.setReceivedRX(userNote.getReceivedRX());
                details.setIsRXSent(userNote.getRXSent());
			}

			res.setNote(details);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching Note By Id Details: {}"
					, e.getMessage());

			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);

		}
		return res;
	}

	@Override
	public PatientSearchRes searchPatient(PatientSearchReq patientSearchReq) {
		PatientSearchRes patientRes = new PatientSearchRes();
		IHealPatientSearchRes ihealPatientSearchRes = new IHealPatientSearchRes();
		try {
			String patientFirstName = "";
			if (patientSearchReq.getPatientFirstName() != null
					&& patientSearchReq.getPatientFirstName().length() >= 3) {
				patientFirstName = patientSearchReq.getPatientFirstName().substring(0, 3);
				
			} else if (patientSearchReq.getPatientFirstName() != null
					&& patientSearchReq.getPatientFirstName().length() == 2) {
				patientFirstName = patientSearchReq.getPatientFirstName().substring(0, 2);
				
			} else if (patientSearchReq.getPatientFirstName() != null
					&& patientSearchReq.getPatientFirstName().length() == 1) {
				patientFirstName = patientSearchReq.getPatientFirstName().substring(0, 1);
			}
			
			int count = (patientFirstName != null) ? patientFirstName.length() : 0;
			
			/*String patientLastName = (patientSearchReq.getSearchValue() != null)
				? patientSearchReq.getSearchValue().substring(0, 3) : "";*/
				
			String patientLastName = "";
			if (patientSearchReq.getSearchValue() != null
					&& patientSearchReq.getSearchValue().length() >= 3) {
				patientLastName = patientSearchReq.getSearchValue().substring(0, 3);
				
			} else if (patientSearchReq.getSearchValue() != null
					&& patientSearchReq.getSearchValue().length() == 2) {
				patientLastName = patientSearchReq.getSearchValue().substring(0, 2);
				
			} else if (patientSearchReq.getSearchValue() != null
					&& patientSearchReq.getSearchValue().length() == 1) {
				patientLastName = patientSearchReq.getSearchValue().substring(0, 1);
			}
					
			patientSearchReq.setSearchValue(patientLastName);
			
			ihealPatientSearchRes = chartReviewDAO
					.getPatientObj(patientSearchReq);

			if (ihealPatientSearchRes != null
					&& ihealPatientSearchRes.getErrorCode() != null
					&& ihealPatientSearchRes.getErrorCode()
							.equalsIgnoreCase("0")) {

				// Success scenario
				List<PatientSearchObj> pateintList = new ArrayList<>();
				if (ihealPatientSearchRes.getPatients() != null
						&& !ihealPatientSearchRes.getPatients().isEmpty()) {

					PatientSearchObj patient = null;
					for (IHealPatientObj patientObj : ihealPatientSearchRes
							.getPatients()) {

						if (patientObj == null) {
							continue;
						}
						
						String iHealPatientFirstName = "";
						if (count == 3) {
							iHealPatientFirstName = (patientObj != null
									&& patientObj.getPatientFirstName() != null
									&& patientObj.getPatientFirstName().length() >= 3)
								? patientObj.getPatientFirstName().substring(0, 3) : "";
								
						} else if (count == 2) {
							iHealPatientFirstName = (patientObj != null
									&& patientObj.getPatientFirstName() != null
									&& patientObj.getPatientFirstName().length() >= 2)
								? patientObj.getPatientFirstName().substring(0, 2) : "";
								
						} else if (count == 3) {
							iHealPatientFirstName = (patientObj != null
									&& patientObj.getPatientFirstName() != null
									&& patientObj.getPatientFirstName().length() >= 1)
								? patientObj.getPatientFirstName().substring(0, 1) : "";
						}
						

						if (patientObj.getPatientFirstName() == null
								|| patientObj.getPatientFirstName().isEmpty()
								|| !iHealPatientFirstName.equalsIgnoreCase(patientFirstName)) {
							continue;
						}

						patient = new PatientSearchObj();
						patient.setFirstName(patientObj.getPatientFirstName());
						patient.setLastName(patientObj.getPatientLastName());
						patient.setSex(patientObj.getPatientSex());
						patient.setMrnNumber(patientObj.getPatientNumber());
						patient.setPatientId(patientObj.getPatientId());
						patient.setDischargeStatusCode(patientObj.getDischargeStatusCode());
						if (patientObj.getDischargeDate() == null) {
							patient.setDischargeDate(null);
						} else {
							try {
								patient.setDischargeDate(CommonUtils.getTargetDateFormat(
										"yyyy-MM-dd'T'HH:mm:ss", "MM/dd/yyyy", patientObj.getDischargeDate()));
							} catch (Exception e1) {
								patient.setDischargeDate("");
							}
						}

						if (patientObj.getPatientDOB() == null) {
							patient.setPatientDOB(null);
							patient.setAge(0);
						} else {
							try {
								patient.setPatientDOB(
										CommonUtils.getTargetDateFormat(
												"yyyy-MM-dd'T'HH:mm:ss",
												"MM/dd/yyyy",
												patientObj.getPatientDOB()));
							} catch (Exception e1) {
								patient.setPatientDOB("");
							}

							if (patientObj.getPatientDOB() == null) {
								patient.setAge(0);
							} else {
								SimpleDateFormat formatter = new SimpleDateFormat(
										"yyyy-MM-dd'T'HH:mm:ss");
								Date date = null;
								try {
									date = formatter
											.parse(patientObj.getPatientDOB());
								} catch (ParseException e) {
									log.debug(String.format(
											"Exception occured during age calculate: %s ",
											e.getMessage()));
								}

								if (date != null) {
									// Converting obtained Date object to
									// LocalDate object
									Instant instant = date.toInstant();
									ZonedDateTime zone = instant
											.atZone(ZoneId.systemDefault());
									LocalDate givenDate = zone.toLocalDate();
									// Calculating the difference between given
									// date to current date.
									Period period = Period.between(givenDate,
											LocalDate.now());

									patient.setAge(period.getYears());
								} else {
									patient.setAge(0);
								}

							}
						}
						pateintList.add(patient);
					}
				}

				log.debug("pateintList size : {}", pateintList.size());
				patientRes.setPatients(pateintList);
				patientRes.setPageIndex(ihealPatientSearchRes.getPageIndex());
				patientRes
						.setMaxPageSize(ihealPatientSearchRes.getMaxPageSize());
				patientRes
						.setResultCount("" + pateintList.size());
				patientRes.setResponseMessage(
						ihealPatientSearchRes.getErrorMessage());
				patientRes
						.setResponseCode(ihealPatientSearchRes.getErrorCode());

			} else if (ihealPatientSearchRes != null
					&& ihealPatientSearchRes.getErrorCode() != null
					&& !ihealPatientSearchRes.getErrorCode()
							.equalsIgnoreCase("0")) {
				// Error Scenario
				patientRes.setResponseMessage(
						ihealPatientSearchRes.getErrorMessage());
				patientRes
						.setResponseCode(ihealPatientSearchRes.getErrorCode());
			}

		} catch (Exception e) {
			log.error("Exception occured while Patient Search from IHeal: {}"
					, e.getMessage());
			patientRes.setResponseCode("1");
			patientRes.setResponseMessage(BOConstants.FAILED);
		}
		return patientRes;
	}

	@Override
	public UpdatePatientDetailsRes updatePatientDetails(
			UpdatePatientDetailsReq req) {
		UpdatePatientDetailsRes res = new UpdatePatientDetailsRes();
		try {
			chartReviewDAO.updatePatientDetails(req);
			res.setResponseCode("0");
			res.setResponseDesc(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while Saving Notes Details: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;
	}

}
