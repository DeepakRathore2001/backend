package com.healogics.rtrv.bo.Impl;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;

@Service
@Configurable
public class AWSS3FileUploadService {
	
private final Logger log = LoggerFactory.getLogger(AWSS3FileUploadService.class);
	
	@Value("${aws.access.key}")
	private String awsAccessKey;
	
	@Value("${aws.secret.key}")
	private String awsSecretKey;
	
	public boolean uploadFileToS3(String bucketName, String destFileName,
			String localFilePath) throws Exception {
		boolean uploadStatus = false;
		try {
			log.debug("bucketName: {}", bucketName);
			log.debug("destFileName: {}", destFileName);
			log.debug("localFilePath: {}", localFilePath);

			AWSCredentials credentials = new BasicAWSCredentials(
					awsAccessKey, awsSecretKey);

			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(
							credentials)).withRegion(Regions.US_EAST_1)
					.build();

			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}

			File file = new File(localFilePath);

			PutObjectRequest request = new PutObjectRequest(bucketName, destFileName, file);
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType("text/csv");
			metadata.setContentEncoding("utf-8");
			request.setMetadata(metadata);

			s3client.putObject(request);
			log.debug("Content Length AWS S3:   {} ", metadata.getContentLength());

			log.info("File Successfully uploaded to S3 location: {}", bucketName
					+ ", destFile: {}", destFileName);

			uploadStatus = true;

		} catch (AmazonS3Exception e) {
			log.debug("Print Stack Trace:");
			e.printStackTrace();
			log.error("Error uploading file to S3. AWS Error Code: {}", e.getErrorMessage());
			throw new Exception(e.getMessage());

		} catch (Exception e) {
			log.error("Exception occured in uploadFileToS3: {}", e.getMessage());
			throw new Exception(e.getMessage());
		}
		log.debug("uploadStatus:    {}", uploadStatus);
		return uploadStatus;
	}

	public boolean uploadFileToDataSolutionsS3(String bucketName, String destFileName,
			String localFilePath) throws Exception {
		boolean uploadStatus = false;
		try {
			log.debug("bucketName: {}", bucketName);
			log.debug("destFileName: {}", destFileName);
			log.debug("localFilePath: {}", localFilePath);

			AWSCredentials credentials = new BasicAWSCredentials(
					awsAccessKey, awsSecretKey);

			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(
							credentials)).withRegion(Regions.US_EAST_1)
					.build();

			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}

			File file = new File(localFilePath);
			
			/*destFileName = "Test/Retrieve/Inbound/" + destFileName;
			
			log.debug("destFileName: before Uploading: ", destFileName);*/

			PutObjectRequest request = new PutObjectRequest(bucketName, destFileName, file);
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType("text/csv");
			metadata.setContentEncoding("utf-8");
			request.setMetadata(metadata);

			s3client.putObject(request);
			log.debug("Content Length AWS S3:   {} ", metadata.getContentLength());

			log.info("File Successfully uploaded to S3 location: {}", bucketName
					+ ", destFile: {}", destFileName);

			uploadStatus = true;

		} catch (AmazonS3Exception e) {
			log.debug("Print Stack Trace:");
			e.printStackTrace();
			log.error("Error uploading file to S3. AWS Error Code: {}", e.getErrorMessage());
			throw new Exception(e.getMessage());

		} catch (Exception e) {
			log.error("Exception occured in uploadFileToS3: {}", e.getMessage());
			throw new Exception(e.getMessage());
		}
		log.debug("uploadStatus:    {}", uploadStatus);
		return uploadStatus;
	}
}
