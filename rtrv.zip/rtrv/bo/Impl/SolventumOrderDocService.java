package com.healogics.rtrv.bo.Impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dto.RetrieveDocNotificationReq;
import com.healogics.rtrv.dto.SolvemtumErrorDetails;
import com.healogics.rtrv.dto.SolventumDocNotificationRes;

@Service
public class SolventumOrderDocService {
	private final Logger log = LoggerFactory.getLogger(SolventumOrderDocService.class);
	
	private final Environment env;
	private final RestTemplate restTemplate;

	@Autowired
	public SolventumOrderDocService(Environment env,
			@Qualifier("httpTemplate2") RestTemplate restTemplate) {
		this.env = env;
		this.restTemplate = restTemplate;
	}
	
	public SolventumDocNotificationRes callDocumentNotification(
			String vendorRequestId, String documentToken,
			String documentRequestId,
			String documentType, String documentAvailable) {
		SolventumDocNotificationRes res = null;
		String url = env.getProperty(BOConstants.SOLVENTUM_BASE_URL)
				+ env.getProperty(BOConstants.SOLVENTUM_DOC_NOTIFIER_API_URL);
		
		log.info("URL : " +url);

		RetrieveDocNotificationReq req = new RetrieveDocNotificationReq();
		req.setVendorRequestId(vendorRequestId);
		req.setDocumentToken(documentToken);
		req.setDocumentRequestId(documentRequestId);
		req.setDocumentType(documentType);
		req.setDocumentAvailable(documentAvailable);
		
		log.info("RetrieveDocNotificationReq : " +req);

		try {
			log.info("Solventum Document Notification URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(req, getSolventumHeaders());
			
			assert url != null;
			
			ResponseEntity<SolventumDocNotificationRes> sresponse = restTemplate.exchange(
					url, HttpMethod.POST, request,
					SolventumDocNotificationRes.class);
			
			log.info("Solventum Document Notification URL post Completed ");
			log.info("Solventum Document Notification Response : {}", sresponse);
			log.debug("Solventum Document Notification Response body : {}", sresponse.getBody());
			
			res = sresponse.getBody();
			
		} catch (HttpClientErrorException e) {
			log.error("HttpClientErrorException occurred in callDocumentNotification API - ", e);
			List<String> errorList = new ArrayList<>();
			errorList.add(e.getMessage());
			
			res = new SolventumDocNotificationRes();
			res.setSucceeded(false);
			res.setItem(false);
			
			SolvemtumErrorDetails error = new SolvemtumErrorDetails();
			error.setErrorCode(1);
			error.setErrorMessages(errorList);
			res.setError(error);
		} catch (HttpStatusCodeException e) {
			log.error("HttpStatusCodeException occurred in callDocumentNotification API: ", e);
			List<String> errorList = new ArrayList<>();
			errorList.add(e.getMessage());
			
			res = new SolventumDocNotificationRes();
			res.setSucceeded(false);
			res.setItem(false);
			
			SolvemtumErrorDetails error = new SolvemtumErrorDetails();
			error.setErrorCode(1);
			error.setErrorMessages(errorList);
			res.setError(error);
		}
		return res;
	}
	
	private HttpHeaders getSolventumHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.SOLVENTUM_HOST_NAME));
		headers.add("x-functions-key", env.getProperty(BOConstants.SOLVENTUM_APP_KEY));
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		log.debug("headers: " +headers);
		
		return headers;
	}
}
