package com.healogics.rtrv.bo.Impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.TeamMemberBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.TeamMemberDAO;
import com.healogics.rtrv.dto.TeamMember;
import com.healogics.rtrv.dto.TeamMemberRes;
import com.healogics.rtrv.entity.RetrieveMembers;

@Service
public class TeamMemberBOImpl implements TeamMemberBO {
	private final Logger log = LoggerFactory.getLogger(TeamMemberBOImpl.class);

	private final TeamMemberDAO teamMemberDAO;

	@Autowired
	public TeamMemberBOImpl(TeamMemberDAO teamMemberDAO) {
		this.teamMemberDAO = teamMemberDAO;
	}
	
	@Override
	public TeamMemberRes getActiveTeamMebers() {
		TeamMemberRes teamMemberRes = new TeamMemberRes();
		List<TeamMember> teamMemberList = new ArrayList<>();

		try {
			List<RetrieveMembers> members = teamMemberDAO.getActiveTeamMebers();
			
			log.debug("members size : {}",members.size());
			
			for (RetrieveMembers team : members) {
				TeamMember teamMember = new TeamMember();
				
				teamMember.setId(team.getRetrieveMemberId());
				teamMember.setAssignedBBC(team.getBluebookCode());
				teamMember.setName(team.getAwdDocSpecialist());
				teamMember.setStatus(team.getActive());
				
				teamMemberList.add(teamMember);
			}
			log.debug("teamMemberList size : {}",teamMemberList.size());
			
			//Sort team member name by ascending later
			
			teamMemberRes.setResponseCode("0");
			teamMemberRes.setResponseMessage(BOConstants.SUCCESS);
			teamMemberRes.setTeamMembers(teamMemberList);

		} catch (Exception e) {
			log.error("Exception occured : {}",e.getMessage());
			teamMemberRes.setResponseCode("1");
			teamMemberRes.setResponseMessage(BOConstants.FAILED);
			teamMemberRes.setTeamMembers(teamMemberList);
		}
		
		return teamMemberRes;
	}
}
