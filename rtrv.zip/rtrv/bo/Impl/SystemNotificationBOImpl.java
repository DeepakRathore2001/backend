package com.healogics.rtrv.bo.Impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.SystemNotificationBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.SystemNotificationDAO;
import com.healogics.rtrv.dto.SystemNotificationDetails;
import com.healogics.rtrv.dto.SystemNotificationListReq;
import com.healogics.rtrv.dto.SystemNotificationListRes;
import com.healogics.rtrv.dto.SystemNotificationWSAReq;
import com.healogics.rtrv.dto.SystemNotificationWSARes;
import com.healogics.rtrv.dto.UserNotificationReq;
import com.healogics.rtrv.dto.UserNotificationRes;
import com.healogics.rtrv.entity.SystemNotification;

@Service
public class SystemNotificationBOImpl implements SystemNotificationBO {

	private final Logger log = LoggerFactory
			.getLogger(SystemNotificationBOImpl.class);

	private final SystemNotificationDAO notificationDAO;
	
	@Autowired
	public SystemNotificationBOImpl(SystemNotificationDAO notificationDAO) {
		this.notificationDAO = notificationDAO;
	}

	@Override
	public SystemNotificationWSARes createNotifications(
			SystemNotificationWSAReq systemNotificationReq) {
		SystemNotificationWSARes res = new SystemNotificationWSARes();
		try {
			String id = notificationDAO
					.saveSystemNotifications(systemNotificationReq);
			if (id != null) {
				res.setNotificationId(id);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			}
		} catch (Exception e) {
			log.error("Exception occured while saving System Notifications: {}"
					,e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;

	}

	@Override
	public SystemNotificationListRes getSystemNotificationList(
			SystemNotificationListReq systemNotListReq) {
		SystemNotificationListRes res = new SystemNotificationListRes();
		try {
			List<SystemNotificationDetails> notificationDetails = new ArrayList<>();
			List<SystemNotification> systemNotificationList = notificationDAO
					.getSystemNotifications(systemNotListReq);
			if (systemNotificationList != null) {
				for (SystemNotification systemNot : systemNotificationList) {
					SystemNotificationDetails details = new SystemNotificationDetails();
					details.setTitle(systemNot.getTitle());
					details.setNotificationId(systemNot.getNotificationId());
					details.setHyperlink(systemNot.getHyperlink());
					details.setDescription(systemNot.getDescription());
					notificationDetails.add(details);
				}
				res.setSystemNotification(notificationDetails);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			}
		} catch (Exception e) {
			log.error("Exception occured while fecthing System Notifications: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public SystemNotificationWSARes updateSystemNotification(
			SystemNotificationWSAReq systemWSAReq) {
		SystemNotificationWSARes res = new SystemNotificationWSARes();
		try {
			String id = notificationDAO.saveSystemNotifications(systemWSAReq);
			if (id != null) {
				res.setNotificationId(id);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			}
		} catch (Exception e) {
			log.error("Exception occured while updating System Notifications: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public UserNotificationRes saveUserNotifications(
			UserNotificationReq userNotificationReq) {
		UserNotificationRes res = new UserNotificationRes();
		try {
			notificationDAO.saveUserNotifications(userNotificationReq);
			res.setResponseCode("0");
			res.setResponseDesc(BOConstants.SUCCESS);
		} catch (Exception e) {
			log.error("Exception occured while saving System Notifications: {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public UserNotificationRes deleteSystemNotifications(List<String> notificationIds) {
		UserNotificationRes res = new UserNotificationRes();
		try {
			notificationDAO.deleteNotifications(notificationIds);
			res.setResponseCode("0");
			res.setResponseDesc(BOConstants.SUCCESS);
			
		} catch (Exception e) {
			log.error("Exception occured while deleting System Notifications: {}"
					,e.getMessage());
			res.setResponseCode("1");
			res.setResponseDesc(BOConstants.FAILED);
		}
		return res;
	}

}
