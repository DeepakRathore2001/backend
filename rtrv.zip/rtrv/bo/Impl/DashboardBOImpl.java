package com.healogics.rtrv.bo.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.DashboardBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.DashboardDAO;
import com.healogics.rtrv.dto.AWDDashboardRes;
import com.healogics.rtrv.dto.AWDData;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.FilterOptions;
import com.healogics.rtrv.dto.FilterOptionsRes;
import com.healogics.rtrv.dto.MedicalRecodInvoiceDetails;
import com.healogics.rtrv.dto.SetStatusReq;
import com.healogics.rtrv.dto.SetStatusRes;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.UserFacilities;
import com.healogics.rtrv.entity.AWDDashboard;
import com.healogics.rtrv.entity.RetrieveUsers;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;

import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE_DOUBLE;

@Service
public class DashboardBOImpl implements DashboardBO {
	private final Logger log = LoggerFactory.getLogger(DashboardBOImpl.class);

	private final DashboardDAO dashboardDAO;

	@Autowired
	public DashboardBOImpl(DashboardDAO dashboardDAO) {
		this.dashboardDAO = dashboardDAO;
	}

	public AWDDashboardRes getAWDData(boolean isBatchAssignment,boolean isExcel, boolean isFilter,
			DashboardReq req, int index, String taskType, String assignee) {
		AWDDashboardRes awdDashboardRes = new AWDDashboardRes();
		List<AWDData> awdDataList = new ArrayList<>();

		log.debug("index: {}", index);
		List<AWDDashboard> awdDashboard = new ArrayList<>();
		try {
			
			//Fetching User Role
			Boolean isSuperUser = dashboardDAO
					.getRetrieveUser(req.getUserId(), req.getUsername());
			
			Long totalCount = 0L;
			boolean isExhausted = false;
			if (isFilter) {
				//Applying Filter List
				Map<String, Object> filterList = new HashMap<>();

				filterList = dashboardDAO.getFileredAWDList(isExcel, req, index,
						taskType, assignee, isSuperUser);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));

				awdDashboard = (List<AWDDashboard>) filterList.get("data");

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					awdDashboardRes.setNextIndex(0);
				} else {
					awdDashboardRes.setNextIndex(index + PAGE_SIZE);
				}

			} else {
				totalCount = dashboardDAO.getTotalCount(index, taskType,
						assignee, req,isSuperUser);
				awdDashboard = dashboardDAO.getAllAWDRecords(isExcel, req,
						index, taskType, assignee, isSuperUser);

				if ((index + PAGE_SIZE) >= totalCount) {
					isExhausted = true;
					awdDashboardRes.setNextIndex(0);
				} else {
					awdDashboardRes.setNextIndex(index + PAGE_SIZE);
				}

			}

			//Fetching user facilities
			List<UserFacilities> facilities = dashboardDAO
					.getUserFacilities(req.getUserId(), req.getUsername());

			if (awdDashboard != null) {
				// SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd
				// HH:mm:ss");

				for (AWDDashboard awdRecord : awdDashboard) {
					boolean matched = false;
					AWDData awd = new AWDData();
					for (UserFacilities fac : facilities) {
						if (fac.getFacilityBluebookId()
								.equalsIgnoreCase(awdRecord.getBbc())) {
							matched = true;
							break;
						}
					}
					if(isBatchAssignment) {
						log.debug("isBatchAssignment:  {}", isBatchAssignment);

						awd.setBhcMedRecId(awdRecord.getBhcMedicalRecordId());
						awd.setBbc(awdRecord.getBbc());
						awd.setFacilityName(awdRecord.getFacilityName());
						awd.setBhcReferralId(awdRecord.getBhcReferralId());
						awd.setBhcOrderSource(awdRecord.getBhcOrderSource());
						awd.setBhcOrderReceivedDate(
								awdRecord.getBhcOrderReceivedDate());
						awd.setFirstReceived(awdRecord.getFirstReceived());
						awd.setFollowupDate(awdRecord.getFollowupDate());
						awd.setPatientName(awdRecord.getPatientLastName() + ", "
								+ awdRecord.getPatientFirstName());
						awd.setProviderName(awdRecord.getProviderFullname());
						awd.setBhcInvoiceOrderId(
								"" + awdRecord.getBhcInvoiceOrderId());
						awd.setAssignedTo(awdRecord.getAssigneeFullName());
						awd.setStatus(awdRecord.getStatus());

						awd.setVendor("Byram");
						awd.setAge("0");
						awd.setLastUpdatedDate(awdRecord.getLastUpdatedDate());
						awd.setLastTeamUpdatedUserFullName(
								awdRecord.getLastTeamUpdatedUserFullname());
						awd.setLastTeamUpdated(awdRecord.getLastTeamUpdated());
						awd.setLastUpdatedDateTime(
								awdRecord.getLastUpdatedDateTime());
						awd.setLastUpdatedUserFullName(
								awdRecord.getLastUpdatedUserFullName());
						awd.setLastUpdatedUserId(
								awdRecord.getLastUpdatedUserId() + "");
						awd.setLastUpdatedUserName(
								awdRecord.getLastUpdatedUserName());

						awd.setStatusUpdatedDateTime(
								awdRecord.getStatusUpdatedDateTime());
						awd.setStatusUpdatedUserFullName(
								awdRecord.getStatusUpdatedUserFullName());
						awd.setStatusUpdatedUserId(
								awdRecord.getStatusUpdatedUserId() + "");
						awd.setStatusUpdatedUserName(
								awdRecord.getStatusUpdatedUserName());

						awd.setiHealConfiguration(
								(awdRecord.getFacilityType() != null)
										? awdRecord.getFacilityType()
										: "-");

						awd.setBhcDocStatus(awdRecord.getBhcDocumentStatus());
						awd.setInsuranceType(
								awdRecord.getBhcPrimaryInsurance());

						awd.setPatientDOB(CommonUtils
								.formatLocalDate(awdRecord.getPatientDOB()));
						awd.setBhcMissingDocNotes(
								awdRecord.getBhcMissingDocNotes());

						awd.setBhcShipDate(awdRecord.getBhcShipDate());
						awd.setBhcLastUpdateDate(awdRecord.getBhcLastUpdated());
						awd.setBhcPatientAcctId(
								awdRecord.getBhcPatientAcctId() + "");

						awd.setBhcMedicalRecAddedDate(
								awdRecord.getMedicalRecordAddedDate());

						Map<Integer, String> medicalRecInvoices = getMedicalRecordInvoices(
								awdRecord.getBhcMedicalRecordId());

						// Have to check alternate way for this
						awd.setInvoiceIdsWithAmount(medicalRecInvoices
								.get(awdRecord.getBhcMedicalRecordId()));
						awdDataList.add(awd);
						
					} else {
						if (matched) {
							log.debug("matched:  {}", matched);
							awd.setBhcMedRecId(awdRecord.getBhcMedicalRecordId());
							awd.setBbc(awdRecord.getBbc());
							awd.setFacilityName(awdRecord.getFacilityName());
							awd.setBhcReferralId(awdRecord.getBhcReferralId());
							awd.setBhcOrderSource(awdRecord.getBhcOrderSource());
							awd.setBhcOrderReceivedDate(
									awdRecord.getBhcOrderReceivedDate());
							awd.setFirstReceived(awdRecord.getFirstReceived());
							awd.setFollowupDate(awdRecord.getFollowupDate());
							awd.setPatientName(awdRecord.getPatientLastName() + ", "
									+ awdRecord.getPatientFirstName());
							awd.setProviderName(awdRecord.getProviderFullname());
							awd.setBhcInvoiceOrderId(
									"" + awdRecord.getBhcInvoiceOrderId());
							awd.setAssignedTo(awdRecord.getAssigneeFullName());
							awd.setStatus(awdRecord.getStatus());

							awd.setVendor("Byram");
							awd.setAge("0");
							awd.setLastUpdatedDate(awdRecord.getLastUpdatedDate());
							awd.setLastTeamUpdatedUserFullName(
									awdRecord.getLastTeamUpdatedUserFullname());
							awd.setLastTeamUpdated(awdRecord.getLastTeamUpdated());
							awd.setLastUpdatedDateTime(
									awdRecord.getLastUpdatedDateTime());
							awd.setLastUpdatedUserFullName(
									awdRecord.getLastUpdatedUserFullName());
							awd.setLastUpdatedUserId(
									awdRecord.getLastUpdatedUserId() + "");
							awd.setLastUpdatedUserName(
									awdRecord.getLastUpdatedUserName());

							awd.setStatusUpdatedDateTime(
									awdRecord.getStatusUpdatedDateTime());
							awd.setStatusUpdatedUserFullName(
									awdRecord.getStatusUpdatedUserFullName());
							awd.setStatusUpdatedUserId(
									awdRecord.getStatusUpdatedUserId() + "");
							awd.setStatusUpdatedUserName(
									awdRecord.getStatusUpdatedUserName());

							awd.setiHealConfiguration(
									(awdRecord.getFacilityType() != null)
											? awdRecord.getFacilityType()
											: "-");

							awd.setBhcDocStatus(awdRecord.getBhcDocumentStatus());
							awd.setInsuranceType(
									awdRecord.getBhcPrimaryInsurance());

							awd.setPatientDOB(CommonUtils
									.formatLocalDate(awdRecord.getPatientDOB()));
							awd.setBhcMissingDocNotes(
									awdRecord.getBhcMissingDocNotes());

							awd.setBhcShipDate(awdRecord.getBhcShipDate());
							awd.setBhcLastUpdateDate(awdRecord.getBhcLastUpdated());
							awd.setBhcPatientAcctId(
									awdRecord.getBhcPatientAcctId() + "");

							awd.setBhcMedicalRecAddedDate(
									awdRecord.getMedicalRecordAddedDate());

							Map<Integer, String> medicalRecInvoices = getMedicalRecordInvoices(
									awdRecord.getBhcMedicalRecordId());

							// Have to check alternate way for this
							awd.setInvoiceIdsWithAmount(medicalRecInvoices
									.get(awdRecord.getBhcMedicalRecordId()));
							awdDataList.add(awd);

						} else {
							awd.setBhcMedRecId(0);
							awd.setBbc(awdRecord.getBbc());
							awd.setFacilityName(awdRecord.getFacilityName());
							awd.setBhcReferralId(null);
							awd.setBhcOrderSource(null);
							awd.setBhcOrderReceivedDate(null);
							awd.setFirstReceived(null);
							awd.setFollowupDate(null);
							awd.setPatientName(null);
							awd.setProviderName(null);
							awd.setBhcInvoiceOrderId(""+awdRecord.getBhcInvoiceOrderId());
							awd.setAssignedTo(null);
							awd.setStatus(null);

							awd.setVendor(null);
							awd.setAge(null);
							awd.setLastUpdatedDate(null);
							awd.setLastTeamUpdatedUserFullName(null);
							awd.setLastTeamUpdated(null);
							awd.setLastUpdatedDateTime(null);
							awd.setLastUpdatedUserFullName(null);
							awd.setLastUpdatedUserId(null);
							awd.setLastUpdatedUserName(null);

							awd.setStatusUpdatedDateTime(null);
							awd.setStatusUpdatedUserFullName(null);
							awd.setStatusUpdatedUserId(null);
							awd.setStatusUpdatedUserName(null);

							awd.setiHealConfiguration(null);

							awd.setBhcDocStatus(null);
							awd.setInsuranceType(null);

							awd.setPatientDOB(null);
							awd.setBhcMissingDocNotes(null);

							awd.setBhcShipDate(null);
							awd.setBhcLastUpdateDate(null);
							awd.setBhcPatientAcctId(null);

							awd.setBhcMedicalRecAddedDate(null);

							// Have to check alternate way for this
							awd.setInvoiceIdsWithAmount(null);
							awdDataList.add(awd);
						}
					}
					

				}

				awdDashboardRes.setCurrentIndex(index);
				awdDashboardRes.setTotalCount(totalCount);
				awdDashboardRes
						.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				awdDashboardRes.setExhausted(isExhausted);

			} else {
				awdDashboard = null;
			}
			log.debug("Next index: {}", (index + PAGE_SIZE));

			awdDashboardRes.setResponseCode("0");
			awdDashboardRes.setResponseMessage(BOConstants.SUCCESS);
			awdDashboardRes.setRecords(awdDataList);

		} catch (Exception e) {
			log.error("Exception occured while fetching AWD Data:  {}",
					e.getMessage());
			awdDashboardRes.setResponseCode("1");
			awdDashboardRes.setResponseMessage(BOConstants.FAILED);
			awdDashboardRes.setRecords(awdDataList);
			awdDashboardRes.setNextIndex(index);
			awdDashboardRes.setCurrentIndex(index);
			awdDashboardRes.setTotalCount(0L);
			awdDashboardRes.setTotalPage(0);
			awdDashboardRes.setExhausted(false);
		}

		return awdDashboardRes;
	}

	@Override
	public Long getAWDNewTaskcount() {
		Long count = 0L;
		try {
			count = dashboardDAO.getAWDNewTaskCount();
		} catch (Exception e) {
			log.error("Exception occured while fetching AWD Data: {}",
					e.getMessage());
		}

		return count;
	}

	public static void main(String[] args) {
		double pageSize = 20.0;
		Long totalCount = 40L;

		System.out.println("Ceil : " + Math.ceil(totalCount / pageSize));

	}

	@Override
	public FilterOptionsRes getSearchFilterOptions(DashboardReq req)
			throws CustomException {
		FilterOptionsRes res = new FilterOptionsRes();
		try {
			FilterOptions filterOptions = dashboardDAO.getFilterOptions(req);
			if (filterOptions != null) {
				res.setFilterOptions(filterOptions);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching Filter Options:  {}",
					e.getMessage());
		}
		return res;
	}

	private Map<Integer, String> getMedicalRecordInvoices(int medRecId) {
		Map<Integer, String> medicalRecordInvoice = new HashMap<>();
		try {
			List<MedicalRecodInvoiceDetails> invoices = dashboardDAO
					.getAllInvoiceDetails(medRecId);

			for (MedicalRecodInvoiceDetails invoice : invoices) {
				String invoiceAmount = "";

				if (invoice.getInvoiceAmount() == null) {
					invoiceAmount = "$0.00";
				} else {
					String invoiceStr = invoice.getInvoiceAmount();

					if (invoiceStr.contains("-")) {
						// Negative value
						log.info("Received invoiceStr  : {}", invoiceStr);
						invoiceStr = invoiceStr.replace("-", "");

						invoiceAmount = "($" + invoiceStr + ")";
						log.info("invoiceAmount after conversion  : {}",
								invoiceStr);
					} else {
						invoiceAmount = "$" + invoiceStr;
					}
				}

				if (medicalRecordInvoice
						.containsKey(invoice.getBhcMedRecId())) {

					String value = medicalRecordInvoice
							.get(invoice.getBhcMedRecId());

					medicalRecordInvoice.put(invoice.getBhcMedRecId(),
							(value + "," + (invoice.getBhcInvoiceOrderId() + "-"
									+ invoiceAmount)));
				} else {
					medicalRecordInvoice.put(invoice.getBhcMedRecId(),
							(invoice.getBhcInvoiceOrderId() + "-"
									+ invoiceAmount));
				}
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Filter Options: {}",
					e.getMessage());
		}
		return medicalRecordInvoice;
	}

	@Override
	public SetStatusRes setStatus(SetStatusReq req) {
		SetStatusRes res = null;
		try {
			res = dashboardDAO.setStatus(req);
		} catch (Exception e) {
			log.error(
					"Exception occured while setting AWD Dashboard status:  {}",
					e.getMessage());
		}
		return res;
	}

	@Override
	public UpdateAssignedToRes batchUpdateAssignee(DashboardReq req,
			List<AWDData> awdRecords) {
		UpdateAssignedToRes res = new UpdateAssignedToRes();
		try {
			res = dashboardDAO.updatedAssigneedTo(req, awdRecords);
		} catch (Exception e) {
			log.error("Exception occured while Updating Batch Assigned To: {}",
					e.getMessage());
		}
		return res;
	}

}
