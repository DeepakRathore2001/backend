package com.healogics.rtrv.bo.Impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.transaction.Transactional;
import javax.xml.bind.DatatypeConverter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.healogics.rtrv.bo.AppNotificationBO;
import com.healogics.rtrv.config.TransactionManager1;
import com.healogics.rtrv.dao.PDFDAO;
import com.healogics.rtrv.dao.impl.ChartReviewDAOImpl;
import com.healogics.rtrv.dto.DocServiceReq;
import com.healogics.rtrv.dto.DocumentNotificationReq;
import com.healogics.rtrv.dto.IHealDocViewPDFGetRes;
import com.healogics.rtrv.dto.IHealDocumentViewPDFGetRes;
import com.healogics.rtrv.dto.SubmitRequest;
import com.healogics.rtrv.entity.DocumentNotificationStatus;
import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.utils.CommonUtils;

@Component
@Service
@Repository
@TransactionManager1
public class PDFService {
	private final Logger log = LoggerFactory.getLogger(PDFService.class);

	private final DocumentService docService;

	private final SessionFactory sessionFactory;

	private final PDFDAO pdfDAO;

	private final Environment env;

	private final AppNotificationBO appNotificationBO;

	@Autowired
	public PDFService(@Qualifier("SessionFactory1") SessionFactory sf, DocumentService docService,
			PDFDAO pdfDAO, Environment env,
			AppNotificationBO appNotificationBO) {
		this.sessionFactory = sf;
		this.docService = docService;
		this.pdfDAO = pdfDAO;
		this.env = env;
		this.appNotificationBO = appNotificationBO;
	}

	private Map<String, Long> counters = new HashMap<>();

	@Value("${retrieve.byram.s3.bucketname}")
	private String retrieveS3BucketName;

	public int uploadIHealAttachments(String uUIDStr,
			DocServiceReq docServiceReq, String bluebookId, String docType,
			SubmitRequest req, String documentUUId) {
		log.info("uploadCustomScansToS3 started with clientState: {}", uUIDStr);
		int uploadStatus = 0;

		try {
			// Calling DocumentViewPDFGET API to get content from Iheal
			IHealDocumentViewPDFGetRes pdfRes = docService.sendDocumentViewPDFGet(docServiceReq);
			
			if (pdfRes != null && pdfRes.getErrorCode().equalsIgnoreCase("0")) {

				Long documentId = 0L;
				String dateDocSent = CommonUtils.getCurrentDate("MMddyyyy");

				String dateStr = CommonUtils.getCurrentDate("yyyy-MM-dd");
				Date currentDate = CommonUtils.getDateObj("yyyy-MM-dd", dateStr);

				log.info("currentDate : {}", currentDate);

				Long currentCounter = counters.getOrDefault(docType, 0L);
				Long nextCounter = currentCounter + 1L;

				counters.put(docType, nextCounter);

				documentId = nextCounter;

				// BBC_Facilityname_PatientFirstname_Patientlastname_BHCshipdate_BHCPatientAcct#
				// _BHCPatientInv_DateDocWasSent(MMDDYYYY)_DocType.pdf

				// decide file name based on business logic
				String fileName = req.getBluebookId() + "_" + req.getFacilityName() + "_" + req.getPatientFirstName()
						+ "_" + req.getPatientLastName() + "_"
						+ CommonUtils.getTargetDateFormat("MM/dd/yyyy", "MMddyyyy", req.getBhcShipDate()) + "_"
						+ req.getBhcPatientAccountNo() + "_" + req.getBhcPatientInv() + "_" + dateDocSent + "_"
						+ getFileTypeForS3(docType) + "_" + documentId + ".pdf";
				
				log.info("filename ###: {}" ,fileName);
				
				fileName = removeSpecialCharacters(fileName);
				
				log.info("filename after removed Special Chars ###: {}" ,fileName);

				String path = env.getProperty("retrieve.local.file.location") + fileName;

				log.info("Converting BYTES to PDF file..");
				log.info("Local File Path: {}", path);

				// convert PDF Base64 stream into PDF file
				String localFilePath = getPDFFileFromBytes(pdfRes.getPdfBytes(), path);

				log.debug("Before upload UUIDStr Client State:   {}", uUIDStr);
				
				if (uploadFileToS3(getS3UploadBucketName(docType), fileName, localFilePath, docType)) {
					uploadStatus = 1;
					log.debug(" after upload UUIDStr Client State:   {}", uUIDStr);

					boolean status = false;
					try {
						status = pdfDAO.saveDocPDFGetStatus(uUIDStr, "Success");
						uploadStatus = 1;
					} catch (Exception e) {
						log.debug("saveSendToS2Status Error Message:  {}", e.getMessage());
					}
					log.debug("After Updated to DB .........................{}", status);

				} else {
					pdfDAO.saveDocPDFGetStatus(uUIDStr, "Failed");
					uploadStatus = 0;
					// Send Failed DocumentNotification
					int dnsStatus = getDocumentNotificationStatus(req.getBhcMedicalRecordId(),
							req.getBhcInvoiceOrderId());
					log.debug("dnsStatus:   {}", dnsStatus);
					if (dnsStatus == 0) {
						appNotificationBO.sendFailedDocNotification(req.getBhcMedicalRecordId(),
								req.getBhcInvoiceOrderId(), documentUUId, req.getLastUpdatedUserId(),
								req.getLastUpdatedUserName(), req.getLastTeamUpdatedUserFullname());
					}
				}

				if (deleteLocalFile(localFilePath)) {
					log.info("Local file Successfully deleted from path: {}", localFilePath);
				} else {
					log.info("Local file not deleted from path: {}", localFilePath);
				}
			} else {
				pdfDAO.saveDocPDFGetStatus(uUIDStr, "Failed");
				uploadStatus = 0;
				// Send Failed DocumentNotification
				int dnsStatus = getDocumentNotificationStatus(req.getBhcMedicalRecordId(), req.getBhcInvoiceOrderId());
				log.debug("dnsStatus:   {}", dnsStatus);
				if (dnsStatus == 0) {
					appNotificationBO.sendFailedDocNotification(req.getBhcMedicalRecordId(), req.getBhcInvoiceOrderId(),
							documentUUId, req.getLastUpdatedUserId(), req.getLastUpdatedUserName(),
							req.getLastTeamUpdatedUserFullname());
				}
			}
		} catch (Exception e) {
			uploadStatus = 0;
		}
		return uploadStatus;
	}

	/*
	 * public int uploadIHealAttachments(String uUIDStr, byte[] pdfBytes, String
	 * bluebookId, String docType, SubmitRequest req, String documentUUId) {
	 * log.info("uploadCustomScansToS3 started with clientState: {}", uUIDStr);
	 * int uploadStatus = 0;
	 * 
	 * try { Long documentId = 0L; String dateDocSent =
	 * CommonUtils.getCurrentDate("MMddyyyy");
	 * 
	 * String dateStr = CommonUtils.getCurrentDate("yyyy-MM-dd"); Date
	 * currentDate = CommonUtils.getDateObj("yyyy-MM-dd", dateStr);
	 * 
	 * log.info("currentDate : {}", currentDate);
	 * 
	 * try { documentId = pdfDAO.getDocumentId(
	 * Long.valueOf(req.getBhcMedicalRecordId()),
	 * Long.valueOf(req.getBhcInvoiceOrderId()), docType, currentDate);
	 * 
	 * log.info("documentId from db: {}", documentId); } catch (Exception e) {
	 * log.error("Exception occured while fetching documoentId: {}",
	 * e.getMessage()); }
	 * 
	 * log.info("documentId: {}", documentId); boolean firstTime = true;
	 * 
	 * if (documentId != null && documentId > 0L) { documentId = documentId +
	 * 1L; firstTime = false; } else { documentId = 1L; }
	 * 
	 * Long currentCounter = counters.getOrDefault(docType, 0L); Long
	 * nextCounter = currentCounter + 1L;
	 * 
	 * counters.put(docType, nextCounter);
	 * 
	 * documentId = nextCounter;
	 * 
	 * //
	 * BBC_Facilityname_PatientFirstname_Patientlastname_BHCshipdate_BHCPatientAcct#
	 * // _BHCPatientInv_DateDocWasSent(MMDDYYYY)_DocType.pdf
	 * 
	 * // decide file name based on business logic String fileName =
	 * req.getBluebookId() + "_" + req.getFacilityName() + "_" +
	 * req.getPatientFirstName() + "_" + req.getPatientLastName() + "_" +
	 * CommonUtils.getTargetDateFormat("MM/dd/yyyy", "MMddyyyy",
	 * req.getBhcShipDate()) + "_" + req.getBhcPatientAccountNo() + "_" +
	 * req.getBhcPatientInv() + "_" + dateDocSent + "_" +
	 * getFileTypeForS3(docType) + "_" + documentId + ".pdf";
	 * 
	 * String path = env.getProperty("retrieve.local.file.location") + fileName;
	 * 
	 * log.info("Converting BYTES to PDF file..");
	 * log.info("Local File Path: {}", path);
	 * 
	 * // convert PDF Base64 stream into PDF file String localFilePath =
	 * getPDFFileFromBytes(pdfBytes, path);
	 * 
	 * log.debug("Before upload UUIDStr Client State:   {}", uUIDStr); if
	 * (uploadFileToS3(getS3UploadBucketName(docType), fileName, localFilePath,
	 * docType)) { uploadStatus = 1;
	 * log.debug(" after upload UUIDStr Client State:   {}", uUIDStr);
	 * 
	 * boolean status = false; try { status =
	 * pdfDAO.saveDocPDFGetStatus(uUIDStr, "Success"); uploadStatus = 1; } catch
	 * (Exception e) { log.debug("saveSendToS2Status Error Message:  {}",
	 * e.getMessage()); }
	 * log.debug("After Updated to DB .........................{}", status);
	 * 
	 * } else { pdfDAO.saveDocPDFGetStatus(uUIDStr, "Failed"); uploadStatus = 0;
	 * // Send Failed DocumentNotification int dnsStatus =
	 * getDocumentNotificationStatus( req.getBhcMedicalRecordId(),
	 * req.getBhcInvoiceOrderId()); log.debug("dnsStatus:   {}", dnsStatus); if
	 * (dnsStatus == 0) { appNotificationBO.sendFailedDocNotification(
	 * req.getBhcMedicalRecordId(), req.getBhcInvoiceOrderId(), documentUUId,
	 * req.getLastUpdatedUserId(), req.getLastUpdatedUserName(),
	 * req.getLastTeamUpdatedUserFullname()); } }
	 * 
	 * if (deleteLocalFile(localFilePath)) {
	 * log.info("Local file Successfully deleted from path: {}", localFilePath);
	 * } else { log.info("Local file not deleted from path: {}", localFilePath);
	 * } } catch (Exception e) { uploadStatus = 0; } return uploadStatus; }
	 */

	@Async
	public void processPDFDocument(DocumentNotificationReq req) {
		log.info("processPDFDocument started with req: {}", req);
		DocumentStatus docStatus = null;
		try {
			docStatus = pdfDAO.getDocumentDetails(req.getClientState());

			log.info("docStatus : {}", docStatus);

			if (docStatus != null) {
				DocServiceReq docReq = new DocServiceReq();
				docReq.setMasterToken(docStatus.getMasterToken());
				docReq.setFacilityId(req.getFacilityId());
				docReq.setPatientId(req.getPatientId());
				docReq.setUserId(
						docStatus.getDocSubmittedByUserId().intValue());
				docReq.setVisitId(req.getVisitId());
				docReq.setPdfFilename(docStatus.getPdfFileName());
				docReq.setJobId(Integer.parseInt(docStatus.getIhealJobId()));

				IHealDocViewPDFGetRes res = docService
						.sendDocViewPDFGet(docReq);

				if (res.getErrorCode() != null
						&& res.getErrorCode().equalsIgnoreCase("0")) {
					// Success
					log.info(
							"Received Document Base64 from iHeal DocViewPDFGet API - Status response: {}",
							res.getErrorMessage());
					pdfDAO.saveDocPDFGetStatus(req.getClientState(), "Success");

					Long documentId = 0L;

					String dateStr = CommonUtils.getCurrentDate("yyyy-MM-dd");
					Date currentDate = CommonUtils.getDateObj("yyyy-MM-dd",
							dateStr);

					log.info("currentDate : {}", currentDate);

					try {
						// get file count from document_name table
						documentId = pdfDAO.getDocumentId(
								docStatus.getBhcMedRecId(),
								docStatus.getBhcInvOrderNo(),
								docStatus.getDocumentType(), currentDate);
						log.info("documentId from db: {}", documentId);
					} catch (Exception e) {
						log.error(
								"Exception occured while fetching documentId: {}",
								e.getMessage());
					}

					log.info("documentId: {}", documentId);
					boolean firstTime = true;

					if (documentId != null && documentId > 0L) {
						documentId = documentId + 1L;
						firstTime = false;
					} else {
						documentId = 1L;
					}

					Long currentCounter = counters
							.getOrDefault(docStatus.getDocumentType(), 0L);
					Long nextCounter = currentCounter + 1L;

					counters.put(docStatus.getDocumentType(), nextCounter);
					documentId = nextCounter;

					// BBC_Facilityname_PatientFirstname_Patientlastname_BHCshipdate_BHCPatientAcct#
					// _BHCPatientInv_DateDocWasSent(MMDDYYYY)_DocType.pdf

					/*
					 * String dateDocSent =
					 * CommonUtils.getCurrentDate("MMddyyyy");
					 */

					// decide file name based on business logic
					String fileName = docStatus.getBluebookId() + "_"
							+ docStatus.getFacilityName() + "_"
							+ docStatus.getPatientFirstName() + "_"
							+ docStatus.getPatientLastName() + "_"
							+ CommonUtils.formatDate("MMddyyyy",
									docStatus.getBhcShipDate())
							+ "_" + docStatus.getBhcPatientAcctNo() + "_"
							+ docStatus.getBhcPatientInv() + "_"
							+ CommonUtils.getCurrentDate("MMddyyyy") + "_"
							+ getFileTypeForS3(docStatus.getDocumentType())
							+ "_" + documentId + ".pdf";
					
					log.info("filename ###: {}" ,fileName);
					
					fileName = removeSpecialCharacters(fileName);
					
					log.info("filename after removed Special Chars ###: {}" ,fileName);

					String path = env.getProperty(
							"retrieve.local.file.location") + fileName;

					log.info("Converting Base64 to PDF file..");
					log.info("Local File Path: {}", path);

					// convert PDF Base64 stream into PDF file
					String localFilePath = getPDFFile(res.getPdfStream(), path);

					if (uploadFileToS3(
							getS3UploadBucketName(docStatus.getDocumentType()),
							fileName, localFilePath,
							docStatus.getDocumentType())) {
						pdfDAO.saveSendToS3Status(req.getClientState(),
								"Success");
						// call save documentation history service
						log.debug(
								"inside pdf service method to call documentation history");

						/*
						 * pdfDAO.saveDocumentationHistory(
						 * docStatus.getBhcMedRecId(),
						 * docStatus.getBhcInvOrderNo(),
						 * fileNameForDocumentation,docStatus.
						 * getDocumentationHistoryNoteId());
						 */

						/*
						 * // save file count in document_name table
						 * DocumentNameObj docNameObj = new DocumentNameObj();
						 * docNameObj.setBhcMedRecId(docStatus.getBhcMedRecId())
						 * ; docNameObj
						 * .setBhcInvOrderNo(docStatus.getBhcInvOrderNo());
						 * docNameObj.setDocumentType(docStatus.getDocumentType(
						 * )); docNameObj.setVisitDate(currentDate);
						 * docNameObj.setDocumentId(documentId);
						 * 
						 * docNameObj.setBhcPatientAcctNo(
						 * docStatus.getBhcPatientAcctNo()); docNameObj
						 * .setBhcPatientInv(docStatus.getBhcPatientInv());
						 * docNameObj.setBhcShipDate(docStatus.getBhcShipDate())
						 * ;
						 * docNameObj.setBluebookId(docStatus.getBluebookId());
						 * docNameObj.setDateDocSent(new Date());
						 * docNameObj.setFacilityId(docStatus.getFacilityId());
						 * docNameObj.setFacilityName(docStatus.getFacilityName(
						 * ));
						 * 
						 * if (firstTime) { log.debug("firsttime");
						 * docNameObj.setCreatedTimestamp( new
						 * Timestamp(System.currentTimeMillis()));
						 * docNameObj.setCreatedUserFullname(
						 * docStatus.getDocSubmittedByUserFullname());
						 * docNameObj.setCreatedUserId(
						 * docStatus.getDocSubmittedByUserId());
						 * docNameObj.setCreatedUsername(
						 * docStatus.getDocSubmittedByUsername());
						 * docNameObj.setLastUpdatedByUserFullname(
						 * docStatus.getDocSubmittedByUserFullname());
						 * docNameObj.setLastUpdatedByUserId(
						 * docStatus.getDocSubmittedByUserId());
						 * docNameObj.setLastUpdatedByUsername(
						 * docStatus.getDocSubmittedByUsername());
						 * docNameObj.setLastUpdatedTimestamp( new
						 * Timestamp(System.currentTimeMillis())); } else {
						 * docNameObj.setLastUpdatedByUserFullname(
						 * docStatus.getDocSubmittedByUserFullname());
						 * docNameObj.setLastUpdatedByUserId(
						 * docStatus.getDocSubmittedByUserId());
						 * docNameObj.setLastUpdatedByUsername(
						 * docStatus.getDocSubmittedByUsername());
						 * docNameObj.setLastUpdatedTimestamp( new
						 * Timestamp(System.currentTimeMillis())); }
						 * 
						 * docNameObj.setPatientFirstName(
						 * docStatus.getPatientFirstName());
						 * docNameObj.setPatientLastName(
						 * docStatus.getPatientLastName());
						 * 
						 * log.info("docNameObj : " + docNameObj);
						 * 
						 * pdfDAO.saveDocumentId(docNameObj, firstTime);
						 */
					} else {
						pdfDAO.saveSendToS3Status(req.getClientState(),
								"Failed");

						if (ChartReviewDAOImpl.getNotificationSend()
								.compareAndSet(false, true)) {
							// Send Failed DocumentNotification
							int dnsStatus = getDocumentNotificationStatus(
									Long.valueOf(docStatus.getBhcMedRecId())
											.intValue(),
									Long.valueOf(docStatus.getBhcInvOrderNo())
											.intValue());
							log.debug("dnsStatus:   {}", dnsStatus);
							if (dnsStatus == 0) {
								log.debug("dnsStatus:   {}", dnsStatus);
								appNotificationBO.sendFailedDocNotification(
										Long.valueOf(docStatus.getBhcMedRecId())
												.intValue(),
										Long.valueOf(
												docStatus.getBhcInvOrderNo())
												.intValue(),
										docStatus
												.getDocumentationHistoryNoteId(),
										docStatus.getDocSubmittedByUserId()
												+ "",
										docStatus.getDocSubmittedByUsername(),
										docStatus
												.getDocSubmittedByUserFullname());
							}
						}

					}

					if (deleteLocalFile(localFilePath)) {
						log.info(
								"Local file Successfully deleted from path: {}",
								localFilePath);
					} else {
						log.info("Local file not deleted from path: {}",
								localFilePath);
					}

				} else {
					// Failed
					pdfDAO.saveDocPDFGetStatus(req.getClientState(),
							"Failed - " + res.getErrorMessage());

					if (ChartReviewDAOImpl.getNotificationSend()
							.compareAndSet(false, true)) {
						// Send Failed DocumentNotification
						int dnsStatus = getDocumentNotificationStatus(
								Long.valueOf(docStatus.getBhcMedRecId())
										.intValue(),
								Long.valueOf(docStatus.getBhcInvOrderNo())
										.intValue());
						log.debug("dnsStatus:   {}", dnsStatus);
						if (dnsStatus == 0) {
							log.debug("dnsStatus:  {}", dnsStatus);
							appNotificationBO.sendFailedDocNotification(
									Long.valueOf(docStatus.getBhcMedRecId())
											.intValue(),
									Long.valueOf(docStatus.getBhcInvOrderNo())
											.intValue(),
									docStatus.getDocumentationHistoryNoteId(),
									docStatus.getDocSubmittedByUserId() + "",
									docStatus.getDocSubmittedByUsername(),
									docStatus.getDocSubmittedByUserFullname());
						}
					}

				}

			}
		} catch (Exception e) {
			log.error("Exception occured in processPDFDocument: {}",
					e.getMessage());
		}
	}

	public int uploadCustomScansToS3(String clientState, String pdfStream,
			String bluebookId, String docType, SubmitRequest req,
			String documentUUID) {
		log.info("uploadCustomScansToS3 started with clientState: {}",
				clientState);
		int uploadStatus = 0;

		try {
			Long documentId = 0L;
			String dateDocSent = CommonUtils.getCurrentDate("MMddyyyy");

			String dateStr = CommonUtils.getCurrentDate("yyyy-MM-dd");
			Date currentDate = CommonUtils.getDateObj("yyyy-MM-dd", dateStr);

			log.info("currentDate : {}", currentDate);

			try {
				// get file count from document_name table
				/*
				 * documentId = pdfDAO.getCustomScansDocumentId(
				 * Long.valueOf(req.getBhcMedicalRecordId()),
				 * Long.valueOf(req.getBhcInvoiceOrderId()), docType);
				 */

				documentId = pdfDAO.getDocumentId(
						Long.valueOf(req.getBhcMedicalRecordId()),
						Long.valueOf(req.getBhcInvoiceOrderId()), docType,
						currentDate);

				log.info("documentId from db: {}", documentId);
			} catch (Exception e) {
				log.error("Exception occured while fetching documoentId: {}",
						e.getMessage());
			}

			log.info("documentId: {}", documentId);
			boolean firstTime = true;

			if (documentId != null && documentId > 0L) {
				documentId = documentId + 1L;
				firstTime = false;
			} else {
				documentId = 1L;
			}

			Long currentCounter = counters.getOrDefault(docType, 0L);
			Long nextCounter = currentCounter + 1L;

			counters.put(docType, nextCounter);

			documentId = nextCounter;

			// BBC_Facilityname_PatientFirstname_Patientlastname_BHCshipdate_BHCPatientAcct#
			// _BHCPatientInv_DateDocWasSent(MMDDYYYY)_DocType.pdf

			// decide file name based on business logic
			String fileName = req.getBluebookId() + "_" + req.getFacilityName()
					+ "_" + req.getPatientFirstName() + "_"
					+ req.getPatientLastName() + "_"
					+ CommonUtils.getTargetDateFormat("MM/dd/yyyy", "MMddyyyy",
							req.getBhcShipDate())
					+ "_" + req.getBhcPatientAccountNo() + "_"
					+ req.getBhcPatientInv() + "_" + dateDocSent + "_"
					+ getFileTypeForS3(docType) + "_" + documentId + ".pdf";
			
			log.info("filename ###: {}" ,fileName);
			
			fileName = removeSpecialCharacters(fileName);
			
			log.info("filename after removed Special Chars ###: {}" ,fileName);

			String path = env.getProperty("retrieve.local.file.location")
					+ fileName;

			log.info("Converting Base64 to PDF file..");
			log.info("Local File Path: {}", path);

			// convert PDF Base64 stream into PDF file
			String localFilePath = getPDFFile(pdfStream, path);

			log.debug("Before upload UUIDStr Client State:   {}", clientState);
			if (uploadFileToS3(getS3UploadBucketName(docType), fileName,
					localFilePath, docType)) {
				uploadStatus = 1;
				log.debug(" after upload UUIDStr Client State:   {}",
						clientState);
				log.debug(
						"After Uploaded to AWS S3...........................");
				boolean status = false;
				try {
					status = pdfDAO.saveSendToS3Status(clientState, "Success");
					uploadStatus = 1;
				} catch (Exception e) {
					log.debug("saveSendToS2Status Error Message:  {}",
							e.getMessage());
				}
				log.debug("After Updated to DB .........................{}",
						status);
				// call savedocumentation history table service
				/*
				 * log.debug(
				 * "inside pdf service method to call documentation history");
				 * pdfDAO.saveDocumentationHistory(
				 * Long.valueOf(req.getBhcMedicalRecordId()),
				 * Long.valueOf(req.getBhcInvoiceOrderId()),
				 * fileNameForDocumentation, documentUUID);
				 */

				// save file count in document_name table
				/*
				 * DocumentNameObj docNameObj = new DocumentNameObj();
				 * docNameObj.setBhcMedRecId(
				 * Long.valueOf(req.getBhcMedicalRecordId()));
				 * docNameObj.setBhcInvOrderNo(
				 * Long.valueOf(req.getBhcInvoiceOrderId()));
				 * docNameObj.setDocumentType(docType);
				 * docNameObj.setVisitDate(currentDate);
				 * docNameObj.setDocumentId(documentId);
				 * 
				 * docNameObj.setBhcPatientAcctNo(req.getBhcPatientAccountNo());
				 * docNameObj.setBhcPatientInv(req.getBhcPatientInv());
				 * 
				 * docNameObj.setBhcShipDate(CommonUtils.getDateObj(
				 * "MM/dd/yyyy", req.getBhcShipDate()));
				 * docNameObj.setBluebookId(req.getBluebookId());
				 * docNameObj.setDateDocSent(CommonUtils.getDateObj(
				 * "yyyy-MM-dd", CommonUtils.getCurrentDate("yyyy-MM-dd")));
				 * 
				 * docNameObj.setFacilityId(req.getFacilityId());
				 * docNameObj.setFacilityName(req.getFacilityName());
				 * 
				 * if (firstTime) { docNameObj.setCreatedTimestamp( new
				 * Timestamp(System.currentTimeMillis()));
				 * docNameObj.setCreatedUserFullname(
				 * req.getLastUpdatedUserFullName());
				 * docNameObj.setCreatedUserId(
				 * Long.valueOf(req.getLastUpdatedUserId()));
				 * docNameObj.setCreatedUsername(req.getLastUpdatedUserName());
				 * docNameObj.setLastUpdatedByUserFullname(
				 * req.getLastUpdatedUserFullName());
				 * docNameObj.setLastUpdatedByUserId(
				 * Long.valueOf(req.getLastUpdatedUserId()));
				 * docNameObj.setLastUpdatedByUsername(
				 * req.getLastUpdatedUserName());
				 * docNameObj.setLastUpdatedTimestamp( new
				 * Timestamp(System.currentTimeMillis())); } else {
				 * docNameObj.setLastUpdatedByUserFullname(
				 * req.getLastUpdatedUserFullName());
				 * docNameObj.setLastUpdatedByUserId(
				 * Long.valueOf(req.getLastUpdatedUserId()));
				 * docNameObj.setLastUpdatedByUsername(
				 * req.getLastUpdatedUserName());
				 * docNameObj.setLastUpdatedTimestamp( new
				 * Timestamp(System.currentTimeMillis())); }
				 * 
				 * docNameObj.setPatientFirstName(req.getPatientFirstName());
				 * docNameObj.setPatientLastName(req.getPatientLastName());
				 * 
				 * pdfDAO.saveDocumentId(docNameObj, firstTime);
				 */
			} else {
				pdfDAO.saveSendToS3Status(clientState, "Failed");
				uploadStatus = 0;
				// Send Failed DocumentNotification
				int dnsStatus = getDocumentNotificationStatus(
						req.getBhcMedicalRecordId(),
						req.getBhcInvoiceOrderId());
				log.debug("dnsStatus:   {}", dnsStatus);
				if (dnsStatus == 0) {
					appNotificationBO.sendFailedDocNotification(
							req.getBhcMedicalRecordId(),
							req.getBhcInvoiceOrderId(), documentUUID,
							req.getLastUpdatedUserId(),
							req.getLastUpdatedUserName(),
							req.getLastTeamUpdatedUserFullname());
				}
			}

			if (deleteLocalFile(localFilePath)) {
				log.info("Local file Successfully deleted from path: {}",
						localFilePath);
			} else {
				log.info("Local file not deleted from path: {}", localFilePath);
			}
		} catch (Exception e) {
			log.error("- {}", e.getMessage());
			uploadStatus = 0;
		}
		return uploadStatus;
	}

	private String getFileTypeForS3(String doctype) {
		String fileType = "";
		switch (doctype) {
			// IHeal DOc Types
			case "ProviderOrders" :
				fileType = "ProviderOrder";
				break;
			case "WoundAssessments" :
				fileType = "Assessment";
				break;
			case "ProgressNotes" :
				fileType = "ProgressNote";
				break;
			case "Debridements" :
				fileType = "ProcedureNote";
				break;
			case "CustomScans" :
				fileType = "CustomScans";
				break;
			// Manual Attach Doc Type
			case "Provider Orders" :
				fileType = "ProviderOrder";
				break;
			case "Wound Assessment" :
				fileType = "Assessment";
				break;
			case "Progress Note" :
				fileType = "ProgressNote";
				break;
			case "Procedure Note" :
				fileType = "ProcedureNote";
				break;
			case "Multi-Wound Chart" :
				fileType = "Assessment";
				break;
			default :
				break;
		}
		return fileType;
	}

	private String getS3UnprocessedBucketName(String doctype) {
		String buketName = "";
		switch (doctype) {
			case "ProviderOrders" :
				buketName = env
						.getProperty("retrieve.byram.outbound.orders.bucket");
				break;
			case "Provider Orders" :
				buketName = env
						.getProperty("retrieve.byram.outbound.orders.bucket");
				break;
			case "WoundAssessments" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.assessment.bucket");
				break;
			case "ProgressNotes" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.additional.bucket");
				break;
			case "Debridements" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.additional.bucket");
				break;
			case "Wound Assessment" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.assessment.bucket");
				break;
			case "Multi-Wound Chart" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.assessment.bucket");
				break;
			case "Progress Note" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.additional.bucket");
				break;
			case "Procedure Note" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.additional.bucket");
				break;
			case "CustomScans" :
				buketName = env.getProperty(
						"retrieve.byram.outbound.additional.bucket");
				break;
			default :
				break;
		}
		return buketName;
	}

	private String getS3UploadBucketName(String doctype) {
		String buketName = "";
		switch (doctype) {
			case "ProviderOrders" :
				buketName = env
						.getProperty("retrieve.byram.upload.orders.bucket");
				break;
			case "Provider Orders" :
				buketName = env
						.getProperty("retrieve.byram.upload.orders.bucket");
				break;
			case "WoundAssessments" :
				buketName = env
						.getProperty("retrieve.byram.upload.assessment.bucket");
				break;
			case "ProgressNotes" :
				buketName = env
						.getProperty("retrieve.byram.upload.additional.bucket");
				break;
			case "Debridements" :
				buketName = env
						.getProperty("retrieve.byram.upload.additional.bucket");
				break;
			case "Wound Assessment" :
				buketName = env
						.getProperty("retrieve.byram.upload.assessment.bucket");
				break;
			case "Progress Note" :
				buketName = env
						.getProperty("retrieve.byram.upload.additional.bucket");
				break;
			case "Procedure Note" :
				buketName = env
						.getProperty("retrieve.byram.upload.additional.bucket");
				break;
			case "Multi-Wound Chart" :
				buketName = env
						.getProperty("retrieve.byram.upload.assessment.bucket");
				break;
			case "CustomScans" :
				buketName = env
						.getProperty("retrieve.byram.upload.additional.bucket");
				break;
			default :
				break;
		}
		return buketName;
	}

	private String getS3UploadBucketPath(String doctype) {
		String buketName = "";
		switch (doctype) {
			case "ProviderOrders" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.orders.bucket");
				break;
			case "Provider Orders" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.orders.bucket");
				break;
			case "WoundAssessments" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.assessment.bucket");
				break;
			case "ProgressNotes" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.additional.bucket");
				break;
			case "Debridements" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.additional.bucket");
				break;
			case "CustomScans" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.additional.bucket");
				break;
			case "Wound Assessment" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.assessment.bucket");
				break;
			case "Progress Note" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.additional.bucket");
				break;
			case "Procedure Note" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.additional.bucket");
				break;
			case "Multi-Wound Chart" :
				buketName = env.getProperty(
						"retrieve.byram.upload.path.assessment.bucket");
				break;
			default :
				break;
		}
		return buketName;
	}

	private String getPDFFileFromBytes(byte[] pdfBytes, String path) {
		File file = null;
		try {

			// byte[] data = DatatypeConverter.parseBase64Binary(base64Content);

			file = new File(path);

			try (OutputStream outputStream = new BufferedOutputStream(
					new FileOutputStream(file))) {
				outputStream.write(pdfBytes);
				log.debug("Inside output stream.....");
			} catch (Exception e) {
				log.error("Exception occured while writing outstream:  {}",
						e.getMessage());
			}

		} catch (Exception e) {
			log.error("Exception occured in getPDFFile: {}", e.getMessage());
		}
		return path;
	}

	private String getPDFFile(String base64Content, String path) {
		File file = null;
		try {

			byte[] data = DatatypeConverter.parseBase64Binary(base64Content);

			file = new File(path);

			try (OutputStream outputStream = new BufferedOutputStream(
					new FileOutputStream(file))) {
				outputStream.write(data);
				log.debug("Inside output stream.....");
			} catch (Exception e) {
				log.error("Exception occured while writing outstream:  {}",
						e.getMessage());
			}

		} catch (Exception e) {
			log.error("Exception occured in getPDFFile: {}", e.getMessage());
		}
		return path;
	}

	private boolean deleteLocalFile(String path) {
		try {
			File file = new File(path);
			if (file.exists()) {
				return file.delete();
			} else {
				return true;
			}
		} catch (Exception e) {
			log.error("Exception occured in getPDFFile: {}", e.getMessage());
		}
		return false;
	}

	private boolean uploadFileToS3(String bucketName, String destFileName,
			String localFilePath, String docType) {
		boolean uploadStatus = false;
		try {

			log.debug("bucketName:          {}", bucketName);
			log.debug("destFileName:          {}", destFileName);
			log.debug("localFilePath:          {}", localFilePath);

			AWSCredentials credentials = new BasicAWSCredentials(
					"AKIA5S3Z2GRILUCVUUP5",
					"OtNlRMwOejR3g9gz4LHS7iJa3SLNcvPzFWtLU4Sx");

			if (credentials == null) {
				log.error("AWS credentials - Error : {}", credentials);
				return false;
			}

			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(
							new AWSStaticCredentialsProvider(credentials))
					.withRegion(Regions.US_EAST_1).build();

			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}

			File file = new File(localFilePath);

			PutObjectRequest request = new PutObjectRequest(bucketName,
					destFileName, file);
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType("application/pdf");
			metadata.setContentEncoding("utf-8");
			request.setMetadata(metadata);

			s3client.putObject(request);
			log.debug("Content Length AWS S3:   {} ",
					metadata.getContentLength());

			log.info("File Successfully uploaded to S3 location: {}",bucketName);
			
			log.info("destFileName:  {}", destFileName);

			uploadStatus = true;

		} catch (AmazonS3Exception e) {
			log.debug("Print Stack Trace:");
			e.printStackTrace();
			log.error("Error uploading file to S3. AWS Error Code: {}",
					e.getErrorMessage());

		} catch (Exception e) {
			log.error("Exception occured in uploadFileToS3: {}",
					e.getMessage());
		}
		log.debug("uploadStatus:    {}", uploadStatus);

		return copyToUnprocessed(retrieveS3BucketName,
				(getS3UploadBucketPath(docType) + "/" + destFileName),
				(getS3UnprocessedBucketName(docType) + destFileName));
	}

	private boolean copyToUnprocessed(String bucketName, String fromKey,
			String toKey) {
		log.info("copyToUnprocessed running");
		log.info("bucketName : {}", bucketName);
		log.info("fromKey : {}", fromKey);
		log.info("toKey : {}", toKey);
		try {

			AWSCredentials credentials = new BasicAWSCredentials(
					"AKIA5S3Z2GRILUCVUUP5",
					"OtNlRMwOejR3g9gz4LHS7iJa3SLNcvPzFWtLU4Sx");
			if (credentials == null) {
				log.error("AWS credentials - Error : {}", credentials);
				return false;
			}
			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(
							new AWSStaticCredentialsProvider(credentials))
					.withRegion(Regions.US_EAST_1).build();
			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}
			try {
				s3client.copyObject(bucketName, fromKey, bucketName, toKey);
			} catch (AmazonServiceException e) {
				log.error("Exception occured in while copying file: {}",
						e.getMessage());
			}
		} catch (Exception e) {
			log.error("Exception occured in copyToUnprocessed: {}",
					e.getMessage());
		}
		log.info("copyToUnprocessed completed");
		return removeProcessedFile(bucketName, fromKey);
	}
	private boolean removeProcessedFile(String bucketName, String objectKey) {
		log.info("removeProcessedFile running");
		log.info("bucketName : {}", bucketName);
		log.info("objectKey : {}", objectKey);
		try {
			AWSCredentials credentials = new BasicAWSCredentials(
					"AKIA5S3Z2GRILUCVUUP5",
					"OtNlRMwOejR3g9gz4LHS7iJa3SLNcvPzFWtLU4Sx");
			if (credentials == null) {
				log.error("AWS credentials - Error : {}", credentials);
				return false;
			}
			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(
							new AWSStaticCredentialsProvider(credentials))
					.withRegion(Regions.US_EAST_1).build();
			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}
			try {
				s3client.deleteObject(bucketName, objectKey);
			} catch (AmazonServiceException e) {
				log.error("Exception occured in while copying file:  {}",
						e.getMessage());
			}
		} catch (Exception e) {
			log.error("Exception occured in copyToArchieved:  {}",
					e.getMessage());
		}
		log.info("removeProcessedFile completed!");
		return true;
		// return false;
	}

	private int getDocumentNotificationStatus(int bhcMedRecId,
			int bhcInvoiceOrderId) {
		// DocumentNotificationStatus Table Update
		int status = 0;
		Session session = this.sessionFactory.getCurrentSession();

		try {
			String hql = "From DocumentNotificationStatus WHERE bhcMedicalRecordId = :bhcMedicalRecordId"
					+ " AND bhcInvoiceOrderNo = :bhcInvoiceOrderNo ";
			DocumentNotificationStatus dns = session
					.createQuery(hql, DocumentNotificationStatus.class)
					.setParameter("bhcMedicalRecordId", new Long(bhcMedRecId))
					.setParameter("bhcInvoiceOrderNo",
							new Long(bhcInvoiceOrderId))
					.setMaxResults(1).uniqueResult();
			log.debug("DocumentNotificationStatus object:  {}", dns);
			if (dns != null) {
				if (dns.getNotificationSent() == 1) {
					status = 1;
				}
			}
		} catch (Exception e) {
			log.error(
					"Exception occured while updating document notification status :  {}",
					e.getMessage());
		}
		return status;
	}
	
	private String removeSpecialCharacters(String fileName) {
		try {
			if (fileName != null && !fileName.trim().isEmpty()) {
				return fileName.replaceAll("[<>:\"/\\\\|?* ]", "");
			}
		} catch (Exception e) {
			System.out.println("An error occurred in removeSpecialCharacters: " + e.getMessage());
		}
		return fileName;
	}

}
