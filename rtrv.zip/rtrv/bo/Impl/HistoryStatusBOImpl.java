package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.DAOConstants.HISTORY_TIMELINE_SIZE;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.HistoryStatusBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.HistoryStatusDAO;
import com.healogics.rtrv.dto.DocumentUploadStatusRes;
import com.healogics.rtrv.dto.StatusHistory;
import com.healogics.rtrv.dto.StatusTimelineRes;
import com.healogics.rtrv.entity.DocumentStatus;
import com.healogics.rtrv.entity.DocumentationHistory;
import com.healogics.rtrv.exception.CustomException;

@Service
public class HistoryStatusBOImpl implements HistoryStatusBO {
	private final Logger log = LoggerFactory
			.getLogger(HistoryStatusBOImpl.class);

	private final HistoryStatusDAO historyStatusDAO;
	
	@Autowired
	public HistoryStatusBOImpl(HistoryStatusDAO historyStatusDAO) {
		this.historyStatusDAO = historyStatusDAO;
	}

	@Override
	public StatusTimelineRes getStatusHistory(int bhcMedRecId, int bhcInvoiceId,
			int page) throws CustomException {
		List<StatusHistory> statusList = new ArrayList<>();
		StatusTimelineRes res = new StatusTimelineRes();

		try {
			List<DocumentationHistory> historyList = historyStatusDAO
					.getStatusHistory(bhcMedRecId, bhcInvoiceId, page);

			Long totalCount = historyStatusDAO.getTotalCount(bhcMedRecId,
					bhcInvoiceId);

			Map<Integer, DocumentationHistory> mergedMap = new HashMap<>();
			for (DocumentationHistory history : historyList) {
				if (history.getDocumentId() != null
						&& !history.getDocumentId().isEmpty()) {
					int noteId = history.getNoteId();
				String docStatus = "";	
				DocumentStatus docStatusObj = historyStatusDAO.getDocumentStatusByHistory(history.getDocumentId());
				if(docStatusObj != null) {
					docStatus = docStatusObj.getDocUploadStatus();
				}
					if (mergedMap.containsKey(noteId)) {
						
						String mergedFileName = "";
						String fileName1 = mergedMap.get(noteId)
								.getBhcMissingDocNotes();
						String fileName2 = history.getBhcMissingDocNotes();
						if (fileName1 != null && fileName2 != null
								&& !fileName1.isEmpty()
								&& !fileName2.isEmpty()) {
							fileName2 = fileName2 +"%"+docStatus+"%"+history.getDocumentId();
							mergedFileName = fileName1 + "#" + fileName2;
						}

						mergedMap.get(noteId)
								.setBhcMissingDocNotes(mergedFileName);
					} else {
						String filename = history.getBhcMissingDocNotes();
						history.setBhcMissingDocNotes(filename +"%"+docStatus+"%"+history.getDocumentId());
						mergedMap.put(noteId, history);
					}
				}
			}

			List<DocumentationHistory> mergedList = new ArrayList<>(
					mergedMap.values());

			mergedList.sort(Comparator
					.comparing(DocumentationHistory::getNoteId)
					.reversed());

			log.debug("totalCount: {}", totalCount);
			log.debug("page: {}", page);
			log.debug("historyList     {} " , historyList);
			log.debug("historyListSize     {}" , historyList.size());
			/*
			 * Map<Integer, List<DocumentationHistory>> result = historyList
			 * .stream() .collect(Collectors.groupingBy(
			 * DocumentationHistory::getNoteId, LinkedHashMap::new,
			 * Collectors.toList()));
			 * 
			 * Map<Integer, List<DocumentationHistory>> docHistoryMap = result
			 * .entrySet().stream() .sorted(Map.Entry .<Integer,
			 * List<DocumentationHistory>>comparingByKey() .reversed())
			 * .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
			 * (oldValue, newValue) -> oldValue, LinkedHashMap::new));
			 */

			/*
			 * Map<Integer, List<DocumentationHistory>> result = historyList
			 * .stream().collect(Collectors
			 * .groupingBy(DocumentationHistory::getNoteId));
			 */

			/*
			 * for (DocumentationHistory history : historyList) { if
			 * (result.containsKey(history.getNoteId())) {
			 * List<DocumentationHistory> docHistory = result
			 * .get(history.getNoteId()); docHistory.add(history);
			 * result.put(history.getNoteId(), docHistory); } else {
			 * List<DocumentationHistory> docHistory = new ArrayList<>();
			 * docHistory.add(history); result.put(history.getNoteId(),
			 * docHistory); } }
			 */

			/*
			 * Map<Integer, List<DocumentationHistory>> result2 =
			 * result.entrySet() .stream()
			 * .sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
			 * .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
			 * (oldValue, newValue) -> oldValue, LinkedHashMap::new));
			 */

			log.debug("mergedList.........{}", mergedList);
			log.debug("mergedListSize.........{}" , mergedList.size());

			/*
			 * result = new TreeMap<>(Comparator.reverseOrder());
			 * result.putAll(historyList.stream().collect(
			 * Collectors.groupingBy(DocumentationHistory::getNoteId)));
			 */

			totalCount = mergedList.size() + 0L;

			int startIndex = page * HISTORY_TIMELINE_SIZE;

			/*
			 * List<Map<Integer, List<DocumentationHistory>>> paginatedEntries =
			 * result2.entrySet().stream() .skip(startIndex) .limit(endIndex -
			 * startIndex) .collect(Collectors.toList());
			 */

			// Convert Map.Entry<Integer, List<DocumentationHistory>> to
			// Map<Integer, List<DocumentationHistory>>
			/*
			 * List<Map<Integer, List<DocumentationHistory>>> convertedEntries =
			 * paginatedEntries.stream() .collect(Collectors.toList());
			 */

			// documentationHistoryMapList.addAll(paginatedEntries);

			int nextPageNo = 0;
			Boolean isExhausted = false;
			List<DocumentationHistory> paginatedList = new ArrayList<>();

			if (mergedList.size() > (startIndex + HISTORY_TIMELINE_SIZE)) {
				paginatedList.addAll(mergedList.subList(startIndex,
						startIndex + HISTORY_TIMELINE_SIZE));
				nextPageNo = page + 1;
				isExhausted = false;
			} else {
				paginatedList.addAll(
						mergedList.subList(startIndex, mergedList.size()));
				isExhausted = true;
			}

			/*
			 * if (result.size() > (startIndex + HISTORY_TIMELINE_SIZE)) { /*
			 * Map<Integer, List<DocumentationHistory>> paginatedMap = new
			 * HashMap<>(); paginatedMap.put(entry.getKey(), entry.getValue());
			 * documentationHistoryMapList.add(paginatedMap);
			 * 
			 * Map<Integer, List<DocumentationHistory>> paginatedMap = result
			 * .entrySet().stream().skip(startIndex).limit(endIndex)
			 * .collect(Collectors.toMap(Map.Entry::getKey,
			 * Map.Entry::getValue));
			 * documentationHistoryMapList.add(paginatedMap); nextPageNo = page
			 * + 1; } else { Map<Integer, List<DocumentationHistory>>
			 * paginatedMap = result .entrySet().stream().skip(startIndex)
			 * .limit(result.size()).collect(Collectors
			 * .toMap(Map.Entry::getKey, Map.Entry::getValue));
			 * documentationHistoryMapList.add(paginatedMap); }
			 */

			log.debug("pagianatedList:  {}", paginatedList);
			log.debug("pagianatedListSize:  {}", paginatedList.size());
			/*
			 * Map<Integer, List<StatusHistory>> shHistoryMap = new HashMap<>();
			 * 
			 * for (Map<Integer, List<DocumentationHistory>> map :
			 * documentationHistoryMapList) { log.debug("firstLoopMap:    " +
			 * map); for (Map.Entry<Integer, List<DocumentationHistory>> entry :
			 * map .entrySet()) { int noteId = entry.getKey();
			 * List<DocumentationHistory> histories = entry.getValue();
			 * log.debug("noteId...." + noteId); log.debug("histories:   " +
			 * entry.getValue()); List<StatusHistory> statusHistories = new
			 * ArrayList<>(); for (DocumentationHistory documentationHistory :
			 * histories) { StatusHistory sh = new StatusHistory();
			 * sh.setNoteId(documentationHistory.getNoteId());
			 * sh.setDateTimestamp(
			 * documentationHistory.getLastUpdatedTimestamp());
			 * sh.setBhcMissingDocNotes(
			 * documentationHistory.getBhcMissingDocNotes());
			 * sh.setBhcMissingDocType(
			 * documentationHistory.getBhcMissingDocType()); sh.setBhcDocStatus(
			 * documentationHistory.getBhcDocumentStatus());
			 * sh.setRetrieveStatus( documentationHistory.getRetrieveStatus());
			 * sh.setLastUpdatedUserFullname(documentationHistory
			 * .getLastUpdatedUserFullname()); sh.setLastUpdatedUserId(
			 * documentationHistory.getLastUpdatedUserId() + "");
			 * sh.setUserNotes(documentationHistory.getUserNotes());
			 * sh.setAssignedTo(documentationHistory.getAssignedTo());
			 * statusHistories.add(sh); } shHistoryMap.put(noteId,
			 * statusHistories); }
			 * 
			 * } log.debug("paginatedMap For Loop : " + shHistoryMap);
			 */

			/*
			 * for (Map.Entry<Integer, List<StatusHistory>> entry : shHistoryMap
			 * .entrySet()) { String fileName = ""; int noteId = entry.getKey();
			 * log.debug("Histories noteId " + noteId); List<StatusHistory>
			 * histories = entry.getValue(); log.debug("histories:   " +
			 * entry.getValue());
			 * 
			 * StatusHistory his = new StatusHistory(); for (StatusHistory
			 * history : histories) {
			 * 
			 * his.setNoteId(history.getNoteId());
			 * his.setDateTimestamp(history.getDateTimestamp()); // This block
			 * will process only when status is submitted if
			 * (history.getRetrieveStatus() .equalsIgnoreCase("Submitted")) { if
			 * (history.getBhcMissingDocNotes() != null &&
			 * !history.getBhcMissingDocNotes().isEmpty()) { if (fileName !=
			 * null && !fileName.isEmpty()) { fileName = fileName + "#" +
			 * history.getBhcMissingDocNotes(); } else { fileName =
			 * history.getBhcMissingDocNotes(); } } } else { fileName =
			 * history.getBhcMissingDocNotes(); } log.debug("fileName....." +
			 * fileName); his.setBhcMissingDocNotes(fileName);
			 * his.setBhcMissingDocType(history.getBhcMissingDocType());
			 * his.setBhcDocStatus(history.getBhcDocStatus());
			 * his.setRetrieveStatus(history.getRetrieveStatus());
			 * his.setLastUpdatedUserFullname(
			 * history.getLastUpdatedUserFullname()); his.setLastUpdatedUserId(
			 * history.getLastUpdatedUserId() + "");
			 * his.setUserNotes(history.getUserNotes());
			 * his.setAssignedTo(history.getAssignedTo());
			 * log.debug("his object" + his);
			 * 
			 * } statusList.add(his); log.debug("firstLoop Completed...."); }
			 */

			for (DocumentationHistory history : paginatedList) {
				StatusHistory statusHistory = new StatusHistory();
				statusHistory.setAssignedTo(history.getAssignedTo());
				statusHistory.setBhcDocStatus(history.getBhcDocumentStatus());
				statusHistory
						.setBhcMissingDocNotes(history.getBhcMissingDocNotes());
				statusHistory
						.setBhcMissingDocType(history.getBhcMissingDocType());
				statusHistory
						.setDateTimestamp(history.getLastUpdatedTimestamp());
				statusHistory.setLastUpdatedUserFullname(
						history.getLastUpdatedUserFullname());
				statusHistory.setLastUpdatedUserId(
						"" + history.getLastUpdatedUserId());
				statusHistory.setNoteId(history.getNoteId());
				statusHistory.setRetrieveStatus(history.getRetrieveStatus());
				statusHistory.setUserNotes(history.getUserNotes());
				statusHistory.setAddendum(history.getAddendum());
				statusHistory.setRecordModify(history.getRecordModify());
				statusList.add(statusHistory);
			}

			log.debug("final status List: {}", statusList);

			// boolean isExhausted = !(totalCount > startIndex
			// + HISTORY_TIMELINE_SIZE);
			res.setCurentPage(page);
			res.setExhausted(isExhausted);
			res.setNextPage(nextPageNo);
			res.setTotalCount(totalCount);
			res.setTotalPage(Math.ceil(totalCount / 5.0));

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
			res.setStatusList(statusList);

		} catch (Exception e) {
			log.error(
					"Exception occured in getStatusHistory: {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);

			res.setStatusList(new ArrayList<>());
			res.setCurentPage(0);
			res.setExhausted(false);
			res.setNextPage(0);
			res.setTotalCount(0L);
			res.setTotalPage(0);

		}
		return res;
	}

	@Override
	public DocumentUploadStatusRes getDocUploadStatus(String documentUUID) {
		DocumentUploadStatusRes res = new DocumentUploadStatusRes();
		try {
			DocumentStatus status = historyStatusDAO.getDocumentStatusByHistory(documentUUID);
			if(status != null) {
				res.setDocUploadStatus(status.getDocUploadStatus());
				res.setResponseCode("0");
				res.setResponseMessage("Success");
			}
		}catch(Exception e) {
			log.error(
					"Exception occured in getDocumentUploadStatus:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage("Failed");
		}
		return res;
	}
}
