package com.healogics.rtrv.bo.Impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.LoginBO;
import com.healogics.rtrv.bo.MasterAppNotificationBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.MasterAppNotificationDAO;
import com.healogics.rtrv.dto.MasterAppNotificaionReq;
import com.healogics.rtrv.dto.MasterAppNotificationCountRes;
import com.healogics.rtrv.dto.MasterAppNotificationListRes;
import com.healogics.rtrv.dto.RTRVMasterAppNotifications;
import com.healogics.rtrv.entity.MasterAppNotification;
import com.healogics.rtrv.entity.UserPreference;

@Service
public class MasterAppNotificationBOImpl implements MasterAppNotificationBO {
	private final Logger log = LoggerFactory
			.getLogger(MasterAppNotificationBOImpl.class);

	private final MasterAppNotificationDAO masterAppNotifyDAO;

	private final LoginBO loginBO;
	
	@Autowired
	public MasterAppNotificationBOImpl(MasterAppNotificationDAO masterAppNotifyDAO,
			LoginBO loginBO) {
		this.masterAppNotifyDAO = masterAppNotifyDAO;
		this.loginBO = loginBO;
	}
	
	@Override
	public MasterAppNotificationListRes getAppNotifications(MasterAppNotificaionReq req) {
		MasterAppNotificationListRes res = new MasterAppNotificationListRes();
		List<RTRVMasterAppNotifications> rtrvAppNotifications = new ArrayList<>();
		try {
			UserPreference userPreference = loginBO
					.getUserPreference(req.getUserId());

			log.info("userPreference :  {}", userPreference);

			Timestamp clearNotificationTimestamp = null;

			if (userPreference != null) {
				clearNotificationTimestamp
						= userPreference.getMasterClearNotificationTimestamp();

				log.info("clearNotificationTimestamp :  {}",
						clearNotificationTimestamp);
			}

			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd");
			Calendar c1 = Calendar.getInstance();
			String currentDate = df.format(date);
			log.info("currentDate :  {}", currentDate);

			// now add 30 day in Calendar instance
			c1.add(Calendar.DAY_OF_YEAR, -30);
			df = new SimpleDateFormat("yyyy-MM-dd");
			Date resultDate = c1.getTime();
			String last30DaysDate = df.format(resultDate);
			log.info("last30DaysDate :  {}", last30DaysDate);

			List<MasterAppNotification> appNotifications = masterAppNotifyDAO
					.getAppNotification(Long.valueOf(req.getUserId()),
							clearNotificationTimestamp, last30DaysDate);

			log.info("appNotifications :  {}", appNotifications);
			log.info("appNotifications.size() : {}", appNotifications.size());

			if (appNotifications != null) {
				for (MasterAppNotification appNotification : appNotifications) {
					RTRVMasterAppNotifications rtrvApp = new RTRVMasterAppNotifications();
					rtrvApp.setNotifcationId(
							appNotification.getNotificationId());
					rtrvApp.setNotificationType(
							appNotification.getNotificationTitle());
					rtrvApp.setReadFlag(appNotification.getReadFlag());
					rtrvApp.setUserFullname(appNotification.getUserFullname());
					rtrvApp.setUserId(appNotification.getUserId());

					UserPreference userPref = loginBO.getUserPreference(
							appNotification.getUserId() + "");
					
					if (userPref != null) {
						rtrvApp.setUserColorCodes(userPref.getAvatarColor());
					}

					rtrvApp.setUsername(appNotification.getUsername());

					rtrvApp.setCreatedTimestamp(
							appNotification.getCreatedTimestamp());
					rtrvApp.setCreatorUserFullname(
							appNotification.getCreatorUserFullname());
					rtrvApp.setCreatorUserId(
							appNotification.getCreatorUserId());

					UserPreference userPrefere = loginBO.getUserPreference(
							"" + appNotification.getCreatorUserId());
					
					if (userPrefere != null) {
						rtrvApp.setCreatorColorCodes(
								userPrefere.getAvatarColor());
					}

					rtrvApp.setCreatorUsername(
							appNotification.getCreatorUsername());
					rtrvApp.setHyperlink(appNotification.getHyperlink());
					rtrvApp.setLastUpdatedTimestamp(
							appNotification.getLastUpdatedTimestamp());
					rtrvApp.setDescription(
							appNotification.getNotificationDescription());
					rtrvAppNotifications.add(rtrvApp);
				}
			}

			res.setAppNotificationList(rtrvAppNotifications);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching App Notification:  {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setAppNotificationList(rtrvAppNotifications);
		}
		return res;
	}
	
	@Override
	public RTRVAPIResponse updateNotifications(MasterAppNotificaionReq req) {
		RTRVAPIResponse res = new RTRVAPIResponse();
		try {
			long currentMillis = System.currentTimeMillis();
			Timestamp currentTime = new Timestamp(currentMillis);

			if (req.getClearedFlag()) {
				loginBO.updateUserPreference(req.getUserId(), currentTime);
			}

			masterAppNotifyDAO.updateNotifications(req);

			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while updating App Notification:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public MasterAppNotificationCountRes getAppNotificationCount(String userId) {
		MasterAppNotificationCountRes res = new MasterAppNotificationCountRes();
		Boolean status = false;
		try {
			Long count = masterAppNotifyDAO.getAppNotificationCount(userId);
			log.debug("Notifications Count Size:   {}", count);
			
			if (count > 0) {
				status = true;
			}
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);
			res.setUnreadAppNotifcationExists(status);
		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			log.error(
					"Exception occured while fetching App Notification Count: {}"
							, e.getMessage());
		}
		return res;
	}
}
