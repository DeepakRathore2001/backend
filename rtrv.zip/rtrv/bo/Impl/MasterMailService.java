package com.healogics.rtrv.bo.Impl;

import java.time.LocalDateTime;
import java.util.Base64;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.healogics.rtrv.dao.MailDAO;
import com.healogics.rtrv.dao.MasterEmailDAO;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.TaggedUser;
import com.sendgrid.Content;
import com.sendgrid.Email;
import com.sendgrid.Mail;
import com.sendgrid.Method;
import com.sendgrid.Personalization;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;

@Aspect
@Component
public class MasterMailService {

	private static final Log LOGGER = LogFactory.getLog(MailService.class);

	private final Environment env;
	private final MasterEmailDAO mailDAO;
	
	@Autowired
	public MasterMailService(Environment env, MasterEmailDAO mailDAO) {
		this.env = env;
		this.mailDAO = mailDAO;
	}
	
	//@After("execution(* com.healogics.rtrv.bo.Impl.MasterChartReviewBOImpl.saveMasterNotes(..)) && args(req)")
	public void after(JoinPoint joinPoint, SaveMasterNotesReq req) {

		try {
		//	LOGGER.info("Save notes req : " + req);

			if (req.getNoteId() == null || req.getNoteId().isEmpty()) {
				LOGGER.info("Invalid note...");
				return;
			}

			if (req.getTaggedUsers() == null || req.getTaggedUsers().isEmpty()) {
				// User not tagged, return
				LOGGER.info("No user is tagged in notes...");
				return;
			}

			if (req.getTaggedUsers() != null && !req.getTaggedUsers().isEmpty()) {

				StringBuilder sb = new StringBuilder();
				sb.append("requestId=");
				sb.append(req.getRequestId());

				sb.append("&notesId=");
				sb.append(req.getNoteId());

				sb.append("&sl=");
				sb.append("CTP");
				
				String encodedURL = Base64.getUrlEncoder().encodeToString(sb.toString().getBytes());

				LOGGER.debug("reqURL : before encode - " + sb.toString());

				// form URL
				StringBuilder reqURL = new StringBuilder();
				reqURL.append(env.getProperty("app.url"));
				reqURL.append("/?req=");
				reqURL.append(encodedURL);
				reqURL.append("&src=email");

				LOGGER.debug("reqURL : after encode - " + reqURL.toString());

				for (TaggedUser notesUser : req.getTaggedUsers()) {
					com.healogics.rtrv.dto.Email email = new com.healogics.rtrv.dto.Email();
					try {
						email.setVendorRequestId(req.getRequestId());
						email.setBluebookId(req.getBluebookId());
						email.setCreatedTimestamp(LocalDateTime.now());
						email.setFacilityId(Long.valueOf(req.getFacilityId()));
						email.setNoteCreatorUserFullname(req.getLastUpdatedUserFullname());
						email.setNoteCreatorUserId(Long.valueOf(req.getLastUpdatedUserId()));
						email.setNoteCreatorUsername(req.getLastUpdatedUsername());
						email.setNoteId(req.getNoteId());
						email.setPatientId(req.getPatientId());
						email.setPatientName(req.getPatientFullname());
						
						email.setTaggedUserFullname(notesUser.getUserFullName());
						email.setTaggedUserId(notesUser.getUserId());
						email.setTaggedUsername(notesUser.getUserName());
						email.setToEmailId(notesUser.getUserEmail());
						
						//set URL
						email.setNoteURL(reqURL.toString());
						
						Personalization personalization = new Personalization();
						personalization.addTo(new Email(notesUser.getUserEmail()));
						personalization.setSubject(env.getProperty("mail.subject"));

						Mail mail = new Mail();
						mail.setFrom(new Email(env.getProperty("mail.sender")));
						mail.addPersonalization(personalization);

						// Form URL
						String bodyContent = "<br><br>Hello, <br><br>" + env.getProperty("mail.body")
								+ " Please click <a href=\""
								+ reqURL + "\">here</a> to view the note.\n";

						LOGGER.info("bodyContent : " + bodyContent);

						mail.addContent(new Content("text/html", bodyContent));

						SendGrid sg = new SendGrid(env.getProperty("sendGrid.apiKey"));

						Request request = new Request();
						request.setMethod(Method.POST);
						request.setEndpoint("mail/send");
						request.setBody(mail.build());
						
						email.setEmailSentTime(LocalDateTime.now());
						
						Response response = sg.api(request);
						email.setEmailStatus("Success");

						email.setResponseCode(response.getStatusCode() + "");
						email.setResponseMessage(response.getBody());
						
						LOGGER.debug("getStatusCode : " + response.getStatusCode());

					} catch (Exception ex) {
						LOGGER.error("Failed to send email: ", ex);
						email.setEmailStatus("Failed");
					}
					LOGGER.debug("Saving email obj... : " +email);
					mailDAO.saveMailNotification(email);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception occured while sending master email notification.. " + e.getMessage());
		}

	}
	
}
