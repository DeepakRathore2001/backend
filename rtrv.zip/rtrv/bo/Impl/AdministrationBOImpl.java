package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE;
import static com.healogics.rtrv.constants.DAOConstants.PAGE_SIZE_DOUBLE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healogics.rtrv.bo.AdministrationBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.AdministrationDAO;
import com.healogics.rtrv.dto.AdminDashboardFilterOptionsRes;
import com.healogics.rtrv.dto.AdminDashboardReq;
import com.healogics.rtrv.dto.AdminDashboardRes;
import com.healogics.rtrv.dto.AdministrationRetrieveMembersRes;
import com.healogics.rtrv.dto.AdministrationRetrieveUsersRes;
import com.healogics.rtrv.dto.CenterAssignmentPopupRes;
import com.healogics.rtrv.dto.FilteredBBCResponse;
import com.healogics.rtrv.dto.IHealDocument;
import com.healogics.rtrv.dto.RetrieveMembersDetails;
import com.healogics.rtrv.dto.RetrieveUsersDetails;
import com.healogics.rtrv.dto.UpdateCenteAssignmentReq;
import com.healogics.rtrv.entity.RetrieveUsers;

@Service
public class AdministrationBOImpl implements AdministrationBO {

	private final Logger log = LoggerFactory.getLogger(AdministrationBOImpl.class);

	private final AdministrationDAO administrationDAO;

	@Autowired
	public AdministrationBOImpl(AdministrationDAO administrationDAO) {
		this.administrationDAO = administrationDAO;
	}

	@Override
	public AdministrationRetrieveMembersRes getRetrieveMembers(boolean isFilter, AdminDashboardReq req, int index) {
		AdministrationRetrieveMembersRes res = new AdministrationRetrieveMembersRes();
		List<RetrieveMembersDetails> memberDetailsList = new ArrayList<>();
		try {
			List<Object[]> members = new ArrayList<>();
			log.debug("index: {}", index);

			Long totalCount = 0L;
			boolean isExhausted = false;
			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = administrationDAO.getFilteredRetrieveMembers(req, index);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));
				members = (List<Object[]>) filterList.get("data");

			} else {
				// without filter
				members = administrationDAO.getRetrieveMembersData(req, index);
				totalCount = administrationDAO.totalRetrieveMembers();
			}

			if ((index + PAGE_SIZE) >= totalCount) {
				isExhausted = true;
				res.setNextIndex(0);
			} else {
				res.setNextIndex(index + PAGE_SIZE);
			}

			if (members != null) {
				for (Object[] data : members) {
					RetrieveMembersDetails details = new RetrieveMembersDetails();
					details.setActive((int) data[0]);
					details.setRetrieveMemberId((Long) data[1]);
					details.setBluebookCode((String) data[2]);
					details.setOpsSpecialist((String) data[3]);
					details.setAwdDocClerk((String) data[4]);
					details.setAwdDocClerkUsername((String) data[5]);
					details.setAwdDocSpecialist((String) data[6]);
					details.setAwdDocSpecialistUsername((String) data[7]);
					details.setNpwtDocClerk((String) data[8]);
					details.setNpwtDocClerkUsername((String) data[9]);
					details.setNpwtDocSpecialist((String) data[10]);
					details.setNpwtDocSpecialistUsername((String) data[11]);
					details.setCtpDocClerk((String) data[12]);
					details.setCtpDocClerkUsername((String) data[13]);
					details.setCtpDocSpecialist((String) data[14]);
					details.setCtpDocSpecialistUsername((String) data[15]);
					details.setTerritory((String) data[16]);
					details.setDivision((String) data[17]);
					details.setMarket((String) data[18]);
					details.setiHealConfiguration((String) data[19]);

					memberDetailsList.add(details);
				}
				res.setCurrentIndex(index);
				res.setTotalCount(totalCount);
				res.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				res.setExhausted(isExhausted);
				log.debug("Next index: {}", (index + PAGE_SIZE));

				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setRetrieveMembers(memberDetailsList);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Retrieve Members Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setRetrieveMembers(memberDetailsList);
			res.setNextIndex(index);
			res.setCurrentIndex(index);
			res.setTotalCount(0L);
			res.setTotalPage(0);
			res.setExhausted(false);
		}
		return res;
	}

	@Retryable(maxAttempts = 3, backoff = @Backoff(delay = 5000))
	@Override
	public AdministrationRetrieveUsersRes getRetrieveUsers(boolean isFilter, AdminDashboardReq req, int index) {
		AdministrationRetrieveUsersRes res = new AdministrationRetrieveUsersRes();
		List<RetrieveUsersDetails> usersDetailsList = new ArrayList<>();
		try {
			List<RetrieveUsers> users = new ArrayList<>();

			log.debug("index: {}", index);

			Long totalCount = 0L;
			boolean isExhausted = false;
			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = administrationDAO.getFilteredRetrieveUsers(req, index);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));
				users = (List<RetrieveUsers>) filterList.get("data");

			} else {
				// without filter
				users = administrationDAO.getRetrieveUsersData(req, index);
				totalCount = administrationDAO.totalRetrieveUsers(req.getIsSuperUser());
			}

			if ((index + PAGE_SIZE) >= totalCount) {
				isExhausted = true;
				res.setNextIndex(0);
			} else {
				res.setNextIndex(index + PAGE_SIZE);
			}

			if (users != null) {
				for (RetrieveUsers data : users) {
					RetrieveUsersDetails details = new RetrieveUsersDetails();
					details.setEmailId(data.getEmailId());
					details.setLast_logged_in_timestamp(data.getLastLoggedInTimestamp());
					details.setRetrieveRole(data.getRetrieveRole());
					details.setUserFullName(data.getUserFullName());
					details.setUserId(data.getUserId());
					details.setUsername(data.getUsername());
					List<String> businessRole = new ArrayList<>();
					ObjectMapper objectMapper = new ObjectMapper();
					if (data.getBusinessRole() != null) {
						try {
							businessRole = objectMapper.readValue(data.getBusinessRole(),
									new TypeReference<List<String>>() {
									});
						} catch (JsonProcessingException e) {
							log.error("Json Procession exception:  {}", e);
						}
					}
					details.setBusinessRole(businessRole);
					details.setIsSuperUser(data.getIsSuperUser());
					usersDetailsList.add(details);
				}
				res.setCurrentIndex(index);
				res.setTotalCount(totalCount);
				res.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				res.setExhausted(isExhausted);
				log.debug("Next index: {}", (index + PAGE_SIZE));

				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setRetrieveUsers(usersDetailsList);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Retrieve Users Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setRetrieveUsers(usersDetailsList);
			res.setNextIndex(index);
			res.setCurrentIndex(index);
			res.setTotalCount(0L);
			res.setTotalPage(0);
			res.setExhausted(false);

			throw new RuntimeException("Error During Fetching Retrieve Users Details: ", e);
		}
		return res;
	}

	@Recover
	public AdministrationRetrieveUsersRes recover(RuntimeException e, boolean isFilter, AdminDashboardReq req,
			int index) {
		AdministrationRetrieveUsersRes res = new AdministrationRetrieveUsersRes();
		List<RetrieveUsersDetails> usersDetailsList = new ArrayList<>();
		log.error("All Retry failed while fetching Retrieve Users Details:  {}", e.getMessage());
		res.setResponseCode("1");
		res.setResponseMessage(BOConstants.FAILED);
		res.setRetrieveUsers(usersDetailsList);
		res.setNextIndex(index);
		res.setCurrentIndex(index);
		res.setTotalCount(0L);
		res.setTotalPage(0);
		res.setExhausted(false);
		return res;
	}

	@Override
	public AdminDashboardFilterOptionsRes getCenterFilterOptions(AdminDashboardReq req) {
		AdminDashboardFilterOptionsRes res = new AdminDashboardFilterOptionsRes();
		try {
			List<String> filterOptions = administrationDAO.getCenterAssignmentFilterOptions(req);
			if (filterOptions != null) {
				res.setOptions(filterOptions);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while  Center Admin Dashboard Filter Options:  {}", e.getMessage());
		}
		return res;
	}

	@Override
	public AdminDashboardFilterOptionsRes getSearchFilterOptions(AdminDashboardReq req) {
		AdminDashboardFilterOptionsRes res = new AdminDashboardFilterOptionsRes();
		try {
			List<String> filterOptions = administrationDAO.getRoleAssignmentFilterOptions(req);
			if (filterOptions != null) {
				res.setOptions(filterOptions);
				res.setResponseCode("0");
				res.setResponseDesc(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseDesc(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while  Role Admin Dashboard Filter Options:  {}", e.getMessage());
		}
		return res;
	}

	@Override
	public CenterAssignmentPopupRes getCenterAssignmentValues(AdminDashboardReq req) {
		CenterAssignmentPopupRes res = new CenterAssignmentPopupRes();
		try {
			Map<String, List<String>> valuesMap = new HashMap<>();
			String[] columns = new String[] { "bbc", "territory", "role", "name", "division", "market", "ihealConfig",
					"opsSpecialist" };
			for (String column : columns) {
				if (column.equalsIgnoreCase("role")) {
					List<String> values = new ArrayList<>();
					values.add("AWDDocClerk");
					values.add("AWDDocSpecialist");
					valuesMap.put(column, values);
				} /*
					 * else if (column.equalsIgnoreCase("division")) { List<String> values = new
					 * ArrayList<>(); values.add("East"); values.add("West");
					 * values.add("National Accounts"); values.add("Non-Comprehensive Accounts");
					 * valuesMap.put(column, values); }
					 */else if (column.equalsIgnoreCase("name")) {
					List<String> values = administrationDAO.getAssigneeNameFromUsersTable(req.getIsSuperUser());
					valuesMap.put(column, values);
				} else {
					List<String> values = administrationDAO.getCenterAssignmentPopupValues(column);
					if (values != null && !values.isEmpty()) {
						valuesMap.put(column, values);
					}
				}
			}
			log.debug("CenterAssignmentPopupRes valuesMap: {} ", valuesMap);
			if (valuesMap != null && !valuesMap.isEmpty()) {
				res.setValuesMap(valuesMap);
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			}
		} catch (Exception e) {
			log.error("Exception occured while  Fetching Center Assignment Values:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public FilteredBBCResponse getCenterDropDownOptions(AdminDashboardReq req) {
		   FilteredBBCResponse res = new FilteredBBCResponse();
		    try {
		      //  log.info("Fetching filtered BBC data for request: {}", req);
		        res = administrationDAO.getCenterAssignmentDropDownValues(req);
		    } catch (Exception e) {
		        log.error("Exception occurred while fetching filtered BBC data: {}", e.getMessage());
		        res.setResponseCode("1");
		        res.setResponseMessage("FAILED");
		    }
		    return res;
		}
//	@Override
//	public CenterAssignmentPopupRes getCenterDropDownOptions(AdminDashboardReq req) {
//		CenterAssignmentPopupRes res = new CenterAssignmentPopupRes();
//		try {
//			Map<String, List<String>> valuesMap = new HashMap<>();
//			String dropDown = req.getDropDown();
//			String[] columns = new String[] {};
//			if (req.getDropDown() != null && !req.getDropDown().isEmpty()) {
//				columns = new String[] { "name", "ihealConfig", "default", dropDown };
//			} else {
//				columns = new String[] { "name", "ihealConfig", "default" };
//			}
//			for (String column : columns) {
//				if (column.equalsIgnoreCase("name")) {
//					List<String> values = administrationDAO.getAssigneeNameFromUsersTable(req.getIsSuperUser());
//					if (values != null && !values.isEmpty()) {
//						valuesMap.put(column, values);
//					}
//				} else if (column.equalsIgnoreCase("ihealConfig")) {
//					List<String> values = administrationDAO.getCenterAssignmentPopupValues(column);
//					if (values != null && !values.isEmpty()) {
//						valuesMap.put(column, values);
//					}
//				} else if (column.equalsIgnoreCase("default")) {
//					List<String> values = administrationDAO.getCenterAssignmentPopupValues("division");
//					if (values != null && !values.isEmpty()) {
//						valuesMap.put("division", values);
//					}
//
//				} else {
//					List<String> values = administrationDAO.getCenterAssignmentDropDownValues(column, req);
//					if (values != null && !values.isEmpty()) {
//						if (req.getDropDown().equalsIgnoreCase("division")) {
//							valuesMap.put("market", values);
//						} else if (req.getDropDown().equalsIgnoreCase("market")) {
//							valuesMap.put("territory", values);
//						} else if (req.getDropDown().equalsIgnoreCase("territory")) {
//							valuesMap.put("bbc", values);
//						} else if (req.getDropDown().equalsIgnoreCase("allbbc")) {
//							valuesMap.put("allbbc", values);
//						}
//					}
////						else if(column.equalsIgnoreCase("market")) {
////					List<String> values = administrationDAO.getCenterAssignmentDropDownValues(column);
////						if (values != null && !values.isEmpty()) {
////							valuesMap.put("territory", values);
////						}
////				}
////				else if(column.equalsIgnoreCase("territory")) {
////					List<String> values = administrationDAO.getCenterAssignmentDropDownValues(column);
////					if (values != null && !values.isEmpty()) {
////						valuesMap.put("bbc", values);
////					}
////				}
////				else if(column.equalsIgnoreCase("division")) {
////						List<String> values = administrationDAO.getCenterAssignmentDropDownValues(column);
////						if (values != null && !values.isEmpty()) {
////							valuesMap.put("territory", values);
////						}
////				}
////				else {
////					List<String> values = administrationDAO.getCenterAssignmentDropDownValues(column);
////					if (values != null && !values.isEmpty()) {
////						valuesMap.put("territory", values);
////					}
//				}
//
//				log.debug("CenterAssignmentPopupRes valuesMap: {} ", valuesMap);
//				if (valuesMap != null && !valuesMap.isEmpty()) {
//					res.setValuesMap(valuesMap);
//					res.setResponseCode("0");
//					res.setResponseMessage(BOConstants.SUCCESS);
//				} else {
//					res.setResponseCode("1");
//					res.setResponseMessage(BOConstants.FAILED);
//				}
//			}
//		} catch (Exception e) {
//			log.error("Exception occured while getting center drop down Options:  {}", e.getMessage());
//			res.setResponseCode("1");
//			res.setResponseMessage(BOConstants.FAILED);
//		}
//		return res;
//	}

//	@Override
//	public CenterAssignmentPopupRes getCenterDropDownOptions(AdminDashboardReq req) {
//		CenterAssignmentPopupRes res = new CenterAssignmentPopupRes();
//		try {
//			Map<String, List<String>> valuesMap = new HashMap<>();
//			List<String> columns = new ArrayList<>(Arrays.asList("name", "ihealConfig", "default","bbc","businessRole"));
//
//			// Add the dropDown column if it's not null or empty
//			if (req.getDropDown() != null && !req.getDropDown().isEmpty()) {
//				columns.add(req.getDropDown());
//			}
//
//			for (String column : columns) {
//				List<String> values = null;
//
//				if (column.equalsIgnoreCase("name")) {
//					values = administrationDAO.getAssigneeNameFromUsersTable(req.getIsSuperUser());
//					if (values != null && !values.isEmpty()) {
//						valuesMap.put(column, values);
//					}
//				} else if (column.equalsIgnoreCase("ihealConfig")) {
//					values = administrationDAO.getCenterAssignmentPopupValues(column);
//					if (values != null && !values.isEmpty()) {
//						valuesMap.put(column, values);
//					}
//				} else if (column.equalsIgnoreCase("default")) {
//					values = administrationDAO.getCenterAssignmentPopupValues("division");
//					if (values != null && !values.isEmpty()) {
//						valuesMap.put("division", values);
//					}
//				} else if (column.equalsIgnoreCase("bbc")) {
//					if ((req.getMarket() != null && !req.getMarket().isEmpty())
//							|| (req.getTerritory() != null && !req.getTerritory().isEmpty())
//							|| req.getDivision() != null && !req.getDivision().isEmpty()) {
//					
//					}else {
//						values = administrationDAO.getCenterAssignmentPopupValues("bbc");
//						if (values != null && !values.isEmpty()) {
//						valuesMap.put("bbc", values);
//						}
//					}
//				}  else if (column.equalsIgnoreCase("businessRole")) {
//						values = administrationDAO.getCenterAssignmentPopupValues("businessRole");
//						if (values != null && !values.isEmpty()) {
//							valuesMap.put("businessRole", values);
//						}
//				}
//				else {
//					// Check if the respective filter value is present
//					if ((column.equalsIgnoreCase("market") && req.getMarket() != null && !req.getMarket().isEmpty())
//							|| (column.equalsIgnoreCase("territory") && req.getTerritory() != null
//									&& !req.getTerritory().isEmpty())
//							|| (column.equalsIgnoreCase("division") && req.getDivision() != null
//									&& !req.getDivision().isEmpty())) {
//
//						values = administrationDAO.getCenterAssignmentDropDownValues(column, req);
//						if (values != null && !values.isEmpty()) {
//							switch (req.getDropDown().toLowerCase()) {
//							case "division":
//								valuesMap.put("market", values);
//								break;
//							case "market":
//								valuesMap.put("territory", values);
//								break;
//							case "territory":
//								valuesMap.put("filterdbbc", values);
//								break;
//							}
//						}				
//					}
//				}
//
//			}
//
//			log.debug("CenterAssignmentPopupRes valuesMap: {} ", valuesMap);
//			if (valuesMap != null && !valuesMap.isEmpty()) {
//				res.setValuesMap(valuesMap);
//				res.setResponseCode("0");
//				res.setResponseMessage(BOConstants.SUCCESS);
//			} else {
//				res.setResponseCode("1");
//				res.setResponseMessage(BOConstants.FAILED);
//			}
//		} catch (Exception e) {
//			log.error("Exception occurred while getting center drop down options: {}", e.getMessage());
//			res.setResponseCode("1");
//			res.setResponseMessage(BOConstants.FAILED);
//		}
//		return res;
//	}

	@Override
	public AdminDashboardRes saveRetrieveUsers(AdminDashboardReq req) {
		AdminDashboardRes res = new AdminDashboardRes();
		try {

			if (req.getUserRoles() != null) {
				administrationDAO.updateRetrieveUsers(req.getUserRoles());
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			}

		} catch (Exception e) {
			log.error("Exception occured while Saving Retrieve Users Roles:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public AdminDashboardRes saveRetrieveMembers(UpdateCenteAssignmentReq req) {
		AdminDashboardRes res = new AdminDashboardRes();
		try {
			
			int result = administrationDAO.updateRetrieveMembers(req);
			if(result!=0) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			}
			else {
				log.error("Exception occured while  Saving Retrieve Members Table:  {}");
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}

		} catch (Exception e) {
			log.error("Exception occured while  Saving Retrieve Members Table:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}

	@Override
	public AdministrationRetrieveMembersRes getRetrieveMembersToExcel(boolean isFilter, AdminDashboardReq req) {
		AdministrationRetrieveMembersRes res = new AdministrationRetrieveMembersRes();
		List<RetrieveMembersDetails> memberDetailsList = new ArrayList<>();
		try {
			List<Object[]> members = new ArrayList<>();
			// log.debug("index: {}", index);

			Long totalCount = 0L;
			boolean isExhausted = false;
			if (isFilter) {
				// Applying Filter List
				Map<String, Object> filterList = administrationDAO.getFilteredRetrieveMemberstoExcel(req);
				totalCount = Long.valueOf((Integer) filterList.get("Count"));
				members = (List<Object[]>) filterList.get("data");

			} else {
				// without filter
				members = administrationDAO.getRetrieveMembersDatatoExcel(req);
				totalCount = administrationDAO.totalRetrieveMembers();
			}

			/*
			 * if ((index + PAGE_SIZE) >= totalCount) { isExhausted = true;
			 * res.setNextIndex(0); } else { res.setNextIndex(index + PAGE_SIZE); }
			 */

			if (members != null) {
				for (Object[] data : members) {
					RetrieveMembersDetails details = new RetrieveMembersDetails();
					details.setActive((int) data[0]);
					details.setRetrieveMemberId((Long) data[1]);
					details.setBluebookCode((String) data[2]);
					details.setOpsSpecialist((String) data[3]);
					details.setAwdDocClerk((String) data[4]);
					details.setAwdDocClerkUsername((String) data[5]);
					details.setAwdDocSpecialist((String) data[6]);
					details.setAwdDocSpecialistUsername((String) data[7]);
					details.setNpwtDocClerk((String) data[8]);
					details.setNpwtDocClerkUsername((String) data[9]);
					details.setNpwtDocSpecialist((String) data[10]);
					details.setNpwtDocSpecialistUsername((String) data[11]);
					details.setCtpDocClerk((String) data[12]);
					details.setCtpDocClerkUsername((String) data[13]);
					details.setCtpDocSpecialist((String) data[14]);
					details.setCtpDocSpecialistUsername((String) data[15]);
					details.setTerritory((String) data[16]);
					details.setDivision((String) data[17]);
					details.setMarket((String) data[18]);
					details.setiHealConfiguration((String) data[19]);

					memberDetailsList.add(details);
				}
				// res.setCurrentIndex(index);
				res.setTotalCount(totalCount);
				res.setTotalPage(Math.ceil(totalCount / PAGE_SIZE_DOUBLE));

				res.setExhausted(isExhausted);
				// log.debug("Next index: {}", (index + PAGE_SIZE));

				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
				res.setRetrieveMembers(memberDetailsList);
			}

		} catch (Exception e) {
			log.error("Exception occured while fetching Retrieve Members Details:  {}", e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setRetrieveMembers(memberDetailsList);
			// res.setNextIndex(index);
			// res.setCurrentIndex(index);
			res.setTotalCount(0L);
			res.setTotalPage(0);
			res.setExhausted(false);
		}
		return res;
	}

}
