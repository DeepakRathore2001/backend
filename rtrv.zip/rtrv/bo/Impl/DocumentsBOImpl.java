package com.healogics.rtrv.bo.Impl;

import static com.healogics.rtrv.constants.DAOConstants.ERRORCODE;
import static com.healogics.rtrv.constants.DAOConstants.ERRORMESSAGE;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.healogics.rtrv.bo.DocumentsBO;
import com.healogics.rtrv.bo.LoginBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.DocumentsDAO;
import com.healogics.rtrv.dto.AttachmentDetails;
import com.healogics.rtrv.dto.AuthenticateIntanceByTokenRes;
import com.healogics.rtrv.dto.DocumentURLReq;
import com.healogics.rtrv.dto.DocumentURLRes;
import com.healogics.rtrv.dto.DocumentsListReq;
import com.healogics.rtrv.dto.IHealCustomScanListGetRes;
import com.healogics.rtrv.dto.IHealCustomScanListReq;
import com.healogics.rtrv.dto.IHealCustomScanObj;
import com.healogics.rtrv.dto.IHealDebridementRes;
import com.healogics.rtrv.dto.IHealDocumentObj;
import com.healogics.rtrv.dto.IHealDocumentRes;
import com.healogics.rtrv.dto.IHealDocumentsListGetRes;
import com.healogics.rtrv.dto.IHealMedRecReq;
import com.healogics.rtrv.dto.IHealMedRecRes;
import com.healogics.rtrv.dto.IHealProgressNotesListGetRes;
import com.healogics.rtrv.dto.IHealTesResultRes;
import com.healogics.rtrv.dto.IHealTestResultListGetRes;
import com.healogics.rtrv.dto.IHealWound;
import com.healogics.rtrv.dto.IHealWoundAssessmentListGetResponse;
import com.healogics.rtrv.dto.IHealWoundListGetRes;
import com.healogics.rtrv.dto.IHealWoundMeasurement;
import com.healogics.rtrv.dto.ManualAttachmentRes;
import com.healogics.rtrv.dto.MedRecDocObj;
import com.healogics.rtrv.dto.MedRecListReq;
import com.healogics.rtrv.dto.MedRecListRes;
import com.healogics.rtrv.dto.Reconciliations;
import com.healogics.rtrv.dto.TestResultsResult;
import com.healogics.rtrv.dto.ViewAttachmentReq;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.dto.WoundListRes;
import com.healogics.rtrv.exception.CustomException;

import static com.healogics.rtrv.constants.BOConstants.DOCUMENT_BASE_URL;
import static com.healogics.rtrv.constants.BOConstants.MED_REC_DOCUMENT_BASE_URL;

@Service
public class DocumentsBOImpl implements DocumentsBO {
	private final Logger log = LoggerFactory.getLogger(DocumentsBOImpl.class);

	private final DocumentsDAO documentsDAO;
	
	private final LoginBO loginBO;
	
	private final Environment env;
	private final RestTemplate restTemplate;
	
	@Autowired
	public DocumentsBOImpl(DocumentsDAO documentsDAO, LoginBO loginBO, Environment env,
			@Qualifier("httpTemplate1") RestTemplate restTemplate) {
		this.documentsDAO = documentsDAO;
		this.loginBO = loginBO;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	@Override
	public IHealDocumentRes getIHealCustomScanList(DocumentsListReq req)
			throws CustomException {
		IHealDocumentRes response = new IHealDocumentRes();
		try {
			IHealCustomScanListGetRes customScanList = documentsDAO
					.getCustomScanList(req);
			List<AttachmentDetails> customScanAttachments = new ArrayList<>();

			if (customScanList != null && customScanList.getErrorCode() != null
					&& customScanList.getErrorCode().equalsIgnoreCase("0")) {
				List<IHealCustomScanObj> customScans = customScanList
						.getScans();

				if (customScans != null && !customScans.isEmpty()) {
					for (IHealCustomScanObj customScan : customScans) {
						AttachmentDetails details = new AttachmentDetails();
						details.setDocName(customScan.getTitle() + "."
								+ customScan.getScanExtension());
						details.setGroupName(customScan.getGroup().getName());
						details.setTestDesc(customScan.getTitle());
						details.setVersionId(customScan.getDocument().getVersionId());
						details.setDocEntityId(
								customScan.getDocument().getDocumentEntityId()
										+ "");

						String[] forTime = customScan.getDocument()
								.getAddedDateTime().split("T");

						String[] visitTime = customScan.getDocument()
								.getVisitDateTime().split("T");

						details.setVisitDate(visitTime[0]);
						details.setAddedDate(forTime[0]);
						details.setManually(false);
						details.setVisitId(
								customScan.getDocument().getVisitId());
						details.setDocType("CustomScans");
						customScanAttachments.add(details);
					}
					response.setResponseCode("0");
					response.setResponseMessage(BOConstants.SUCCESS);
				}

				Map<String, List<AttachmentDetails>> customScanMap = customScanAttachments
						.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getAddedDate));

				customScanMap = new TreeMap<>(Comparator.reverseOrder());
				customScanMap.putAll(
						customScanAttachments.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getAddedDate)));

				/*
				 * Map<String, List<AttachmentDetails>> customScanMap =
				 * customScanAttachments .stream()
				 * .collect(Collectors.groupingBy(
				 * AttachmentDetails::getAddedDate,
				 * Collectors.collectingAndThen( Collectors.toList(), list ->
				 * list.stream() .sorted(Comparator.comparing(
				 * AttachmentDetails::getAddedDate)) .collect(
				 * Collectors.toList()))));
				 */

				log.debug("customScanMap  SuccessFully : ");

				response.setDocumentsList(customScanMap);
			} else if (customScanList != null
					&& customScanList.getErrorCode() != null
					&& !customScanList.getErrorCode().equalsIgnoreCase("0")) {
				response.setResponseCode(customScanList.getErrorCode());
				response.setResponseMessage(customScanList.getErrorMessage());
			} else {
				response.setResponseCode("25");
				response.setResponseMessage("Invalid Response");
			}
		} catch (Exception e) {
			log.error("Exception occured while processing CustomScans");
			throw new CustomException(e.getMessage());
		}

		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}
		return response;
	}

	@Override
	public IHealTesResultRes getIHealTestResultsList(DocumentsListReq req)
			throws CustomException {
		IHealTesResultRes response = new IHealTesResultRes();
		try {
			IHealTestResultListGetRes testResultListGetRes = getTestResultsList(req);
			List<AttachmentDetails> testResultsAttachments = new ArrayList<>();

			if (testResultListGetRes != null && testResultListGetRes.getErrorCode() != null
					&& testResultListGetRes.getErrorCode().equalsIgnoreCase("0")) {
				List<TestResultsResult> testResuts = testResultListGetRes
						.getResults();

				if (testResuts != null && !testResuts.isEmpty()) {
					for (TestResultsResult result : testResuts) {
						AttachmentDetails details = new AttachmentDetails();
						details.setDocName(result.getTestDescription());
						details.setGroupName(result.getGroupName());
						details.setTestDesc(result.getTestDescription());
						details.setVersionId(result.getDocument().getVersionId());
						details.setDocEntityId(
								result.getDocument().getDocumentEntityId()
										+ "");

						String[] forTime = result.getDocument()
								.getAddedDateTime().split("T");

						String[] visitTime = result.getDocument()
								.getVisitDateTime().split("T");

						details.setVisitDate(visitTime[0]);
						details.setAddedDate(forTime[0]);
						details.setManually(false);
						details.setVisitId(
								result.getDocument().getVisitId());
						details.setSigned(result.getDocument().isSignatureRequirementMet());
						details.setDocType("TestResults");
						testResultsAttachments.add(details);
					}
					response.setResponseCode("0");
					response.setResponseMessage(BOConstants.SUCCESS);
					response.setDocumentsList(testResultsAttachments);
				} else {
					response.setResponseCode("0");
					response.setResponseMessage(BOConstants.SUCCESS);
					response.setDocumentsList(new ArrayList<>());
				}

				log.debug("TestResuts List  SuccessFully : ");

			} else if (testResultListGetRes != null
					&& testResultListGetRes.getErrorCode() != null
					&& !testResultListGetRes.getErrorCode().equalsIgnoreCase("0")) {
				response.setResponseCode(testResultListGetRes.getErrorCode());
				response.setResponseMessage(testResultListGetRes.getErrorMessage());
			} else {
				response.setResponseCode("25");
				response.setResponseMessage("Invalid Response");
			}
		} catch (Exception e) {
			log.error("Exception occured while processing TestResults");
			throw new CustomException(e.getMessage());
		}

		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}
		return response;
	}
	
	private IHealTestResultListGetRes getTestResultsList(DocumentsListReq req) {
		IHealTestResultListGetRes testResultListGetRes = null;

		String url = env.getProperty(BOConstants.IHEAL_TEST_RESULTS_LIST_URL);
		String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);

		IHealCustomScanListReq customScanReq = new IHealCustomScanListReq();
		customScanReq.setPrivateKey(privateKey);
		customScanReq.setMasterToken(req.getMasterToken());
		customScanReq.setFacilityId(req.getFacilityId());
		customScanReq.setPatientId(req.getPatientId());
		customScanReq.setUserId(req.getUserId());

		try {
			log.info("IHeal TestResultsListGet URL post started ");
			HttpEntity<Object> request = new HttpEntity<>(customScanReq,
					getHeaders());
			assert url != null;
			ResponseEntity<IHealTestResultListGetRes> sresponse = restTemplate
					.exchange(url, HttpMethod.POST, request,
							IHealTestResultListGetRes.class);
			log.info("IHeal TestResultsListGet URL post Completed ");
			log.debug("iHeal TestResultsListGet Response : {}",
					sresponse.getBody());
			testResultListGetRes = sresponse.getBody();
		} catch (HttpClientErrorException e) {
			log.error(
					"HttpClientErrorException occurred in TestResultsListGet API - ",
					e);
			testResultListGetRes = new IHealTestResultListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			testResultListGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			testResultListGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		} catch (HttpStatusCodeException e) {
			log.error(
					"HttpStatusCodeException occurred in TestResultsListGet API: ",
					e);
			testResultListGetRes = new IHealTestResultListGetRes();
			HashMap<String, String> errorResponse = extractResponse(
					e.getResponseBodyAsString());
			testResultListGetRes.setErrorCode(errorResponse.get(ERRORCODE));
			testResultListGetRes.setErrorMessage(errorResponse.get(ERRORMESSAGE));
		}

		return testResultListGetRes;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("HOST", env.getProperty(BOConstants.IHEAL_HOST_NAME));
		return headers;
	}

	private HashMap<String, String> extractResponse(String responseBody) {
		HashMap<String, String> data = new HashMap<>();
		String body = responseBody.replaceAll("[{}]", "").replaceAll("\"", "");
		String[] arr = body.split(",");
		for (String tmp : arr) {
			data.put(tmp.substring(0, tmp.indexOf(':')),
					tmp.substring(tmp.indexOf(':') + 1));
		}
		return data;
	}
	
	@Override
	public IHealDocumentRes getProviderOrderList(DocumentsListReq req)
			throws CustomException {

		IHealDocumentRes response = new IHealDocumentRes();
		try {
			IHealDocumentsListGetRes providerOrderListRes = documentsDAO
					.getProviderOrderList(req);

			List<AttachmentDetails> providerOrderAttachments = new ArrayList<>();
			if (providerOrderListRes != null
					&& providerOrderListRes.getErrorCode() != null
					&& providerOrderListRes.getErrorCode()
							.equalsIgnoreCase("0")) {
				List<IHealDocumentObj> providerOrders = providerOrderListRes
						.getProviderOrder();

				if (providerOrders != null && !providerOrders.isEmpty()) {
					for (IHealDocumentObj iHealObj : providerOrders) {
						AttachmentDetails details = new AttachmentDetails();
						details.setDocName("PO");
						details.setGroupName("");
						details.setTestDesc(
								"PO - " + iHealObj.getAddedDateTime());
						details.setVersionId(iHealObj.getVersionId());
						details.setDocEntityId(
								iHealObj.getDocumentEntityId() + "");

						String[] visitTime = iHealObj.getVisitDateTime()
								.split("T");
						details.setVisitDate(visitTime[0]);

						String[] forTime = iHealObj.getAddedDateTime()
								.split("T");
						details.setAddedDate(forTime[0]);

						details.setVisitId(iHealObj.getVisitId());
						details.setManually(false);
						details.setSigned(iHealObj.isSignatureRequirementMet());
						providerOrderAttachments.add(details);
					}
					response.setResponseCode("0");
					response.setResponseMessage(BOConstants.SUCCESS);
				}

				Map<String, List<AttachmentDetails>> providerMap = providerOrderAttachments
						.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate));

				providerMap = new TreeMap<>(Comparator.reverseOrder());
				providerMap.putAll(
						providerOrderAttachments.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate)));

				log.debug("providerOrderMap : {}", providerMap);
				response.setDocumentsList(providerMap);

			} else if (providerOrderListRes != null
					&& providerOrderListRes.getErrorCode() != null
					&& !providerOrderListRes.getErrorCode()
							.equalsIgnoreCase("0")) {
				response.setResponseCode(providerOrderListRes.getErrorCode());
				response.setResponseMessage(
						providerOrderListRes.getErrorMessage());
			} else {
				response.setResponseCode("25");
				response.setResponseMessage("Invalid Response");
			}
		} catch (Exception e) {
			log.error("Exception occured while processing ProviderOrders");
			throw new CustomException(e.getMessage());
		}

		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}
		return response;
	}

	@Override
	public IHealDocumentRes getProgressNotesList(DocumentsListReq req)
			throws CustomException {
		IHealDocumentRes response = new IHealDocumentRes();
		try {
			IHealProgressNotesListGetRes progressNotesListRes = documentsDAO
					.getProgressNotesList(req);
			List<AttachmentDetails> progressAttachments = new ArrayList<>();
			if (progressNotesListRes != null
					&& progressNotesListRes.getErrorCode() != null
					&& progressNotesListRes.getErrorCode()
							.equalsIgnoreCase("0")) {
				List<IHealDocumentObj> progressNotes = progressNotesListRes
						.getProgressnote();

				if (progressNotes != null && !progressNotes.isEmpty()) {
					for (IHealDocumentObj iHealObj : progressNotes) {
						AttachmentDetails details = new AttachmentDetails();
						details.setDocName("PN");
						details.setGroupName("");
						details.setTestDesc(
								"PN - " + iHealObj.getAddedDateTime());
						details.setVersionId(iHealObj.getVersionId());
						details.setDocEntityId(
								iHealObj.getDocumentEntityId() + "");

						String[] visitTime = iHealObj.getVisitDateTime()
								.split("T");
						details.setVisitDate(visitTime[0]);

						String[] forTime = iHealObj.getAddedDateTime()
								.split("T");
						details.setAddedDate(forTime[0]);

						details.setManually(false);
						details.setVisitId(iHealObj.getVisitId());
						details.setSigned(iHealObj.isSignatureRequirementMet());
						progressAttachments.add(details);
					}
					response.setResponseCode("0");
					response.setResponseMessage(BOConstants.SUCCESS);
				}
				Map<String, List<AttachmentDetails>> progressNotesMap = progressAttachments
						.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate));

				progressNotesMap = new TreeMap<>(Comparator.reverseOrder());
				progressNotesMap
						.putAll(progressAttachments.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate)));

				log.debug("progressNotesMap : {}", progressNotesMap);
				response.setDocumentsList(progressNotesMap);

			} else if (progressNotesListRes != null
					&& progressNotesListRes.getErrorCode() != null
					&& !progressNotesListRes.getErrorCode()
							.equalsIgnoreCase("0")) {
				response.setResponseCode(progressNotesListRes.getErrorCode());
				response.setResponseMessage(
						progressNotesListRes.getErrorMessage());
			} else {
				response.setResponseCode("25");
				response.setResponseMessage("Invalid Response");
			}
		} catch (Exception e) {
			log.error("Exception occured while processing ProgressNotes ");
			throw new CustomException(e.getMessage());
		}

		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}
		return response;
	}

	@Override
	public WoundListRes getIHealWoundList(DocumentsListReq req)
			throws CustomException {
		WoundListRes res = new WoundListRes();
		try {
			IHealWoundListGetRes woundList = documentsDAO.getWoundList(req);

			List<IHealWound> iHealWounds = new ArrayList<>();
			List<IHealWound> activeWoundsList = new ArrayList<>();
			List<IHealWound> inactiveWoundsList = new ArrayList<>();

			if (woundList != null && woundList.getErrorCode() != null
					&& woundList.getErrorCode().equalsIgnoreCase("0")) {

				List<IHealWoundMeasurement> iHealWoundMeasure = woundList
						.getWoundMeasurements();

				if (iHealWoundMeasure != null && !iHealWoundMeasure.isEmpty()) {
					for (IHealWoundMeasurement mes : iHealWoundMeasure) {
						iHealWounds.add(mes.getWound());
					}
					Collections.sort(iHealWounds, new Comparator<IHealWound>(){
						@Override
						public int compare(IHealWound w1, IHealWound w2) {
						return Long.compare(w1.getDocument().getDocumentEntityId(), w2.getDocument().getDocumentEntityId());	
						}
					});
			/*		if(!req.isActiveOnly()) {
						iHealWounds = iHealWounds.stream().filter(w -> w.isActiveWound() == false)
								.collect(Collectors.toList());
					}      */
					iHealWounds.forEach(wound ->{
						if(wound.isActiveWound()) {
							activeWoundsList.add(wound);
						} else {
							inactiveWoundsList.add(wound);
						}
					});
					res.setResponseCode("0");
					res.setResponseMessage(BOConstants.SUCCESS);
				}

				log.debug("active iHealWounds:   {}", activeWoundsList);
				log.debug("inactive iHealWounds:   {}", inactiveWoundsList);
				res.setActiveWounds(activeWoundsList);
				res.setInactiveWounds(inactiveWoundsList);
        
				log.debug("IHeal Wounds success:......................");

			} else if (woundList != null && woundList.getErrorCode() != null
					&& !woundList.getErrorCode().equalsIgnoreCase("0")) {
				res.setResponseCode(woundList.getErrorCode());
				res.setResponseMessage(woundList.getErrorMessage());
			} else {
				res.setResponseCode("25");
				res.setResponseMessage("Invalid Response");
			}
		} catch (Exception e) {
			log.error("Exception occured while processing WoundList");
			throw new CustomException(e.getMessage());
		}

		if ((res.getActiveWounds() != null && res.getActiveWounds().isEmpty()) && 
				(res.getInactiveWounds() != null && res.getInactiveWounds().isEmpty())) {
			res.setResponseCode("21");
			res.setResponseMessage("No Wound found!");
		}
		return res;
	}

	@Override
	public IHealDocumentRes getDebridementsList(DocumentsListReq req)
			throws CustomException {
		IHealDocumentRes res = new IHealDocumentRes();
		try {

			LocalDate startDate = null;
			LocalDate endDate = null;
			LocalDate currentDate = LocalDate.now();
			if (req.getStartDate() != null && req.getEndDate() != null
					&& !req.getStartDate().isEmpty()
					&& !req.getEndDate().isEmpty()) {
				startDate = LocalDate.parse(req.getStartDate(),
							DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				endDate = LocalDate.parse(req.getEndDate(),
						DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			} else {
				startDate = currentDate.minusDays(365);
				endDate = currentDate;
			}
			
			log.debug("Debridements startDateString:   " + startDate.toString());
			log.debug("Debridements endDateString:   " + endDate.toString());
			
			IHealDebridementRes debridementsRes = documentsDAO
					.getDebridementsList(req, 0);

			List<AttachmentDetails> debridementsAttachments = new ArrayList<>();
			if (debridementsRes != null
					&& debridementsRes.getErrorCode() != null
					&& debridementsRes.getErrorCode().equalsIgnoreCase("0")) {

				List<IHealDocumentObj> debridements = debridementsRes
						.getProcedures();

				if (debridements != null && !debridements.isEmpty()) {
					final LocalDate finalStartDate = startDate;
					final LocalDate finalEndDate = endDate;
					debridements.removeIf(deb -> {
						String resDate = deb.getVisitDateTime().split("T")[0]; 
						LocalDate date = LocalDate.parse(resDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						return date.isBefore(finalStartDate) || date.isAfter(finalEndDate);
					});

					for (IHealDocumentObj iHealObj : debridements) {
						AttachmentDetails details = new AttachmentDetails();
						details.setDocName("Debridements");
						details.setGroupName("");
						details.setTestDesc("Debridements - "
								+ iHealObj.getAddedDateTime());
						details.setVersionId(iHealObj.getVersionId());
						details.setDocEntityId(
								iHealObj.getDocumentEntityId() + "");

						log.debug("Added Date Time:  {}"
								, iHealObj.getAddedDateTime());

						String[] visitTime = iHealObj.getVisitDateTime()
								.split("T");
						details.setVisitDate(visitTime[0]);
						String[] forTime = iHealObj.getAddedDateTime()
								.split("T");
						details.setAddedDate(forTime[0]);
						details.setManually(false);
						details.setVisitId(iHealObj.getVisitId());
						details.setSigned(iHealObj.isSignatureRequirementMet());
						debridementsAttachments.add(details);
					}
					res.setResponseCode("0");
					res.setResponseMessage(BOConstants.SUCCESS);
				}
				Map<String, List<AttachmentDetails>> debridementsMap = debridementsAttachments
						.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate));

				debridementsMap = new TreeMap<>(Comparator.reverseOrder());
				debridementsMap.putAll(
						debridementsAttachments.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate)));

				log.debug("debridemetsMap : {}" , debridementsMap);
				res.setDocumentsList(debridementsMap);

			} else if (debridementsRes != null
					&& debridementsRes.getErrorCode() != null
					&& !debridementsRes.getErrorCode().equalsIgnoreCase("0")) {
				res.setResponseCode(debridementsRes.getErrorCode());
				res.setResponseMessage(debridementsRes.getErrorMessage());
			} else {
				res.setResponseCode("25");
				res.setResponseMessage("Invalid Response");
			}

		} catch (Exception e) {
			log.error("Exception occured while processing Debridements");
			throw new CustomException(e.getMessage());
		}

		if (res.getDocumentsList() != null
				&& res.getDocumentsList().isEmpty()) {
			res.setResponseCode("21");
			res.setResponseMessage("No Attachment found!");
		}
		return res;
	}

	@Override
	public IHealDocumentRes getIHealWoundAssessmentList(DocumentsListReq req)
			throws CustomException {
		IHealDocumentRes response = new IHealDocumentRes();
		try {
			IHealWoundAssessmentListGetResponse woundAssessmentResponse = documentsDAO
					.getWoundAssessmentList(0, req);
			List<AttachmentDetails> woundAssessmentAttachments = new ArrayList<>();
			if (woundAssessmentResponse != null
					&& woundAssessmentResponse.getErrorCode() != null
					&& woundAssessmentResponse.getErrorCode()
							.equalsIgnoreCase("0")) {
				List<IHealDocumentObj> woundAssess = woundAssessmentResponse
						.getAssessments();

				if (woundAssess != null && !woundAssess.isEmpty()) {
					for (IHealDocumentObj iHealObj : woundAssess) {
						AttachmentDetails details = new AttachmentDetails();
						details.setDocName("WoundAssessment");
						details.setGroupName("");
						details.setTestDesc("WoundAssessment - "
								+ iHealObj.getAddedDateTime());
						details.setVersionId(iHealObj.getVersionId());
						details.setDocEntityId(
								iHealObj.getDocumentEntityId() + "");

						String[] visitTime = iHealObj.getVisitDateTime()
								.split("T");
						details.setVisitDate(visitTime[0]);
						String[] forTime = iHealObj.getAddedDateTime()
								.split("T");
						details.setAddedDate(forTime[0]);
						details.setManually(false);
						details.setVisitId(iHealObj.getVisitId());
						details.setSigned(iHealObj.isSignatureRequirementMet());
						woundAssessmentAttachments.add(details);
					}
					response.setResponseCode("0");
					response.setResponseMessage(BOConstants.SUCCESS);
				}
				Map<String, List<AttachmentDetails>> woundAssessmentMap = woundAssessmentAttachments
						.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate));

				woundAssessmentMap = new TreeMap<>(Comparator.reverseOrder());
				woundAssessmentMap.putAll(
						woundAssessmentAttachments.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getVisitDate)));

				log.debug("woundAssessmentMap : {}", woundAssessmentMap);
				response.setDocumentsList(woundAssessmentMap);

			} else if (woundAssessmentResponse != null
					&& woundAssessmentResponse.getErrorCode() != null
					&& !woundAssessmentResponse.getErrorCode()
							.equalsIgnoreCase("0")) {
				response.setResponseCode(
						woundAssessmentResponse.getErrorCode());
				response.setResponseMessage(
						woundAssessmentResponse.getErrorMessage());
			} else {
				response.setResponseCode("25");
				response.setResponseMessage("Invalid Response");
			}
		} catch (Exception e) {
			log.error("Exception occured while processing Wound Assessment ");
			throw new CustomException(e.getMessage());
		}

		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}
		return response;
	}

	@Override
	public ManualAttachmentRes getManualAttachmentsList(DocumentsListReq req)
			throws CustomException {
		ManualAttachmentRes response = new ManualAttachmentRes();
		try {
			log.debug("getManualAttachment:----------");
			List<AttachmentDetails> manualAttachmentsList = documentsDAO
					.getManualAttachmentList(req);

			if (manualAttachmentsList != null) {
				response.setResponseCode("0");
				response.setResponseMessage(BOConstants.SUCCESS);

				Map<String, List<AttachmentDetails>> manualAttachMap = manualAttachmentsList
						.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getAddedDate));

				manualAttachMap = new TreeMap<>(Comparator.reverseOrder());
				manualAttachMap.putAll(
						manualAttachmentsList.stream().collect(Collectors
								.groupingBy(AttachmentDetails::getAddedDate)));

				log.debug("manualAttachMap : {}", manualAttachMap);
				response.setDocumentsList(manualAttachMap);
			} else {
				response.setResponseCode("1");
				response.setResponseMessage(BOConstants.FAILED);
				response.setDocumentsList(null);
			}

		} catch (Exception e) {
			log.error("Exception occured while processing Manual Attachments ");
			throw new CustomException(e.getMessage());
		}

		if (response.getDocumentsList() != null
				&& response.getDocumentsList().isEmpty()) {
			response.setResponseCode("21");
			response.setResponseMessage("No Attachment found!");
		}
		return response;
	}

	@Override
	public ViewAttachmentRes getIHealFileGet(ViewAttachmentReq req) {

		ViewAttachmentRes res = new ViewAttachmentRes();

		try {
			res = documentsDAO.viewIHealAttachment(req);
		} catch (Exception e) {
			log.error("Exception occured while viewing IHeal Attachments: {}"
					, e.getMessage());
		}

		return res;
	}

	@Override
	public ViewAttachmentRes viewManualAttachments(ViewAttachmentReq req)
			throws CustomException {
		ViewAttachmentRes res = new ViewAttachmentRes();

		try {
			res = documentsDAO.viewManualAttachment(req);
		} catch (Exception e) {
			log.error("Exception occured while viewing IHeal Attachments: "
					, e.getMessage());
		}

		return res;
	}
	
	private String urlEncode(String input) {
		String encodedData = "";
		try {
			encodedData = URLEncoder.encode(input, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			log.error("Exception occured while URL encoding: {}"
					,e.getMessage());
		}
		return encodedData;
	}
	
	@Override
	public DocumentURLRes getDocumentURL(DocumentURLReq req) {
		log.info("DocumentURLReq : " +req);
		DocumentURLRes res = new DocumentURLRes();
		try {
			AuthenticateIntanceByTokenRes tokenRes = loginBO.authenticateIntanceByToken(req);
			
			if (tokenRes != null
					&& tokenRes.getErrorCode().equalsIgnoreCase("0")) {
				//Success
				
				String facilityId = "";
				String documentId = "";
				if (tokenRes.getCipherTexts() != null) {
					facilityId = tokenRes.getCipherTexts().getFacilityId();
					documentId = tokenRes.getCipherTexts().getDocumentId();
				}
				
				StringBuilder documentURL = new StringBuilder();
				if (req.isMedRecDoc() == 1) {
					documentURL.append(env.getProperty(MED_REC_DOCUMENT_BASE_URL));
				} else {
					documentURL.append(env.getProperty(DOCUMENT_BASE_URL));
				}
				
				documentURL.append("?token=");
				documentURL.append(urlEncode(tokenRes.getAuthenticateToken()));
				
				documentURL.append("&tokenid=");
				documentURL.append(urlEncode(facilityId));
				
				if (req.isMedRecDoc() == 1) {
					documentURL.append("&ReconciliationID=");
				} else {
					documentURL.append("&DocumentID=");
				}
				
				documentURL.append(urlEncode(documentId));
				
				if (req.isMedRecDoc() == 1) {
					documentURL.append("&Reconciliation=1");
				}
				
				log.info("documentURL : {}",documentURL.toString());
				
				res.setDocumentURL(documentURL.toString());
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);

			} else if (tokenRes != null
					&& !tokenRes.getErrorCode().equalsIgnoreCase("0")) {
				//Failed
				res.setDocumentURL("");
				res.setResponseCode(tokenRes.getErrorCode());
				res.setResponseMessage(tokenRes.getErrorMessage());
			} else {
				//Invalid Response
				res.setDocumentURL("");
				res.setResponseCode("1");
				res.setResponseMessage("Invalid Response");
			}
			
		} catch (Exception e) {
			log.error("Exception occured while getting Document URL: {}"
					,e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	@Override
	public MedRecListRes getMedRecList(MedRecListReq req) {
	    MedRecListRes response = new MedRecListRes();
	    Map<String, List<MedRecDocObj>> groupedDocuments = new HashMap<>();
	    String url = env.getProperty(BOConstants.IHEAL_MED_REC_LIST_URL);
	    String privateKey = env.getProperty(BOConstants.IHEAL_PRIVATEKEY);
	 
	    IHealMedRecReq customScanReq = new IHealMedRecReq();
	    customScanReq.setPrivateKey(privateKey);
	    customScanReq.setMasterToken(req.getMasterToken());
	    customScanReq.setFacilityId(req.getFacilityId());
	    customScanReq.setPatientId(req.getPatientId());
	    customScanReq.setUserId(req.getUserId());
	 
	    try {
	        log.info("IHeal MedRec URL post started ");
	        HttpEntity<Object> request = new HttpEntity<>(customScanReq, getHeaders());
	 
	        assert url != null;
	        ResponseEntity<IHealMedRecRes> sresponse = restTemplate.exchange(
	                url, HttpMethod.POST, request, IHealMedRecRes.class);
	        log.info("IHeal MedRecListGet URL post Completed ");
	        log.debug("iHeal MedRecListGet Response : {}", sresponse.getBody());
	 
	        IHealMedRecRes docListRes = sresponse.getBody();
	 
	        if (docListRes != null) {
	            if ("0".equalsIgnoreCase(docListRes.getErrorCode())) {
	                List<Reconciliations> docList = docListRes.getReconciliations();
	                if (docList != null && !docList.isEmpty()) {
	                    for (Reconciliations iHealObj : docList) {
	                        MedRecDocObj doc = new MedRecDocObj();
 
	                        String reconciliationDate = iHealObj.getReconciliationDate();
	                        String formattedDate = formatDate(reconciliationDate);
	                        doc.setDocName("MedRec_" + formattedDate);  
	                        doc.setTestDesc("MedRec_" + formattedDate); 
	                        doc.setDocEntityId(iHealObj.getReconciliationId());  
	                        doc.setDocType("MedicalRecord");  
	                        doc.setVisitDate(formattedDate);  
	                        doc.setGroupName("");  
	                        doc.setAddedDate(formattedDate);  
	                        doc.setIsSubmitted(0);  
	                        doc.setVersionId(0); 
	                        doc.setDocumentStatus(null);  
	                        doc.setManually(false);  
	                        doc.setSigned(false);  

	                        groupedDocuments.computeIfAbsent(formattedDate, k -> new ArrayList<>()).add(doc);
	                    }
	                }
	            }
	 
	            if (!groupedDocuments.isEmpty()) {
	                response.setResponseCode("0");
	                response.setResponseMessage("Success");
	                response.setDocumentsList(groupedDocuments);
	            } else {
	                response.setResponseCode("21");
	                response.setResponseMessage("No Attachments found for the specified document type");
	            }
	        } else {
	            response.setResponseCode("25");
	            response.setResponseMessage("Invalid Response");
	        }
	    } catch (HttpClientErrorException e) {
	        log.error("HttpClientErrorException occurred in MedRecListGet API - ", e);
	        response.setResponseCode("26");
	        response.setResponseMessage("Client Error");
	    } catch (HttpStatusCodeException e) {
	        log.error("HttpStatusCodeException occurred in MedRecListGet API: ", e);
	        response.setResponseCode("27");
	        response.setResponseMessage("HTTP Status Error");
	    } catch (Exception e) {
	        log.error("Exception occurred while processing MedRecListGet ", e);
	        response.setResponseCode("28");
	        response.setResponseMessage("Internal Server Error");
	    }
	 
	    return response;
	}
	 
	private String formatDate(String reconciliationDate) {
	    try {
	        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	        Date date = originalFormat.parse(reconciliationDate);
	        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
	        return targetFormat.format(date);
	    } catch (ParseException e) {
	        log.error("Error parsing reconciliationDate: " + reconciliationDate, e);
	        return "UnknownDate";  
	    }
	}



}
