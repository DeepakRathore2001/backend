package com.healogics.rtrv.bo.Impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.AppNotificationBO;
import com.healogics.rtrv.bo.LoginBO;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.dao.AppNotificationDAO;
import com.healogics.rtrv.dto.AppNotificaionsReq;
import com.healogics.rtrv.dto.AppNotificationCountRes;
import com.healogics.rtrv.dto.AppNotificationListRes;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.RTRVAppNotifications;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.UpdateAppNotificationsRes;
import com.healogics.rtrv.entity.AppNotifications;
import com.healogics.rtrv.entity.UserPreference;

@Service
public class AppNotificationBOImpl implements AppNotificationBO {

	private final Logger log = LoggerFactory
			.getLogger(AppNotificationBOImpl.class);

	private final AppNotificationDAO appNotificationDAO;

	private final LoginBO loginBO;
	
	@Autowired
	public AppNotificationBOImpl(AppNotificationDAO appNotificationDAO, LoginBO loginBO) {
		this.appNotificationDAO = appNotificationDAO;
		this.loginBO = loginBO;
	}

	@Override
	public AppNotificationCountRes getNotificationCount(
			AppNotificaionsReq req) {
		AppNotificationCountRes res = new AppNotificationCountRes();
		Boolean status = false;
		try {
			List<AppNotifications> count = appNotificationDAO.getCount(req);
			log.debug("Notifications Count Size:   {}", count.size());
			int size = 0;
			if (count != null) {
				for (AppNotifications not : count) {
					if (!not.getReadFlag()) {
						size = size + 1;
					}
				}
				if (size > 0) {
					status = true;
				}
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			}
			res.setUnreadFlag(status);
		} catch (Exception e) {
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			log.error(
					"Exception occured while fetching App Notification Count: {}"
							, e.getMessage());
		}
		return res;
	}

	@Override
	public Boolean saveAppNotifications(SaveNotesReq req) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveNoteNotifications(req);

		} catch (Exception e) {
			log.error("Exception occured while Saving App Notification :  {}"
					, e.getMessage());
		}
		return status;
	}

	@Override
	public Boolean saveAssignedNotifications(SaveRequest saveReq) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveAssignedNotifications(saveReq);

		} catch (Exception e) {
			log.error(
					"Exception occured while Saving Assigned App Notification :  {}"
							, e.getMessage());
		}
		return status;
	}

	@Override
	public UpdateAppNotificationsRes updateNotifications(
			AppNotificaionsReq req) {
		UpdateAppNotificationsRes res = new UpdateAppNotificationsRes();
		try {
			Long count = appNotificationDAO.updateNotifications(req);

			if (count != null) {
				res.setResponseCode("0");
				res.setResponseMessage(BOConstants.SUCCESS);
			} else {
				res.setResponseCode("1");
				res.setResponseMessage(BOConstants.FAILED);
			}
		} catch (Exception e) {
			log.error("Exception occured while updating App Notification:  {}"
					, e.getMessage());
		}
		return res;
	}

	@Override
	public AppNotificationListRes getAppNotifications(AppNotificaionsReq req) {
		AppNotificationListRes res = new AppNotificationListRes();
		List<RTRVAppNotifications> rtrvAppNotifications = new ArrayList<>();
		try {
			UserPreference userPreference = loginBO
					.getUserPreference(req.getUserId());

			log.info("userPreference :  {}", userPreference);

			Timestamp clearNotificationTimestamp = null;

			if (userPreference != null) {
				clearNotificationTimestamp = userPreference
						.getClearNotificationTimestamp();

				log.info("clearNotificationTimestamp :  {}"
						, clearNotificationTimestamp);
			}

			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd");
			Calendar c1 = Calendar.getInstance();
			String currentDate = df.format(date);
			log.info("currentDate :  {}", currentDate);

			// now add 30 day in Calendar instance
			c1.add(Calendar.DAY_OF_YEAR, -30);
			df = new SimpleDateFormat("yyyy-MM-dd");
			Date resultDate = c1.getTime();
			String last30DaysDate = df.format(resultDate);
			log.info("last30DaysDate :  {}", last30DaysDate);

			List<AppNotifications> appNotifications = appNotificationDAO
					.getAppNotification(Long.valueOf(req.getUserId()),
							clearNotificationTimestamp, last30DaysDate);

			log.info("appNotifications :  {}", appNotifications);
			log.info("appNotifications.size() : {}", appNotifications.size());

			if (appNotifications != null) {
				for (AppNotifications appNotification : appNotifications) {
					RTRVAppNotifications rtrvApp = new RTRVAppNotifications();
					rtrvApp.setNotifcationId(
							appNotification.getNotificationId());
					rtrvApp.setNotificationType(
							appNotification.getNotificationTitle());
					rtrvApp.setReadFlag(appNotification.getReadFlag());
					rtrvApp.setUserFullname(appNotification.getUserFullname());
					rtrvApp.setUserId(appNotification.getUserId());

					UserPreference userPref = loginBO.getUserPreference(
							appNotification.getUserId() + "");
					if (userPref != null) {
						rtrvApp.setUserColorCodes(userPref.getAvatarColor());
					}

					rtrvApp.setUsername(appNotification.getUsername());

					rtrvApp.setCreatedTimestamp(
							appNotification.getCreatedTimestamp());
					rtrvApp.setCreatorUserFullname(
							appNotification.getCreatorUserFullname());
					rtrvApp.setCreatorUserId(
							appNotification.getCreatorUserId());

					UserPreference userPrefere = loginBO.getUserPreference(
							"" + appNotification.getCreatorUserId());
					if (userPrefere != null) {
						rtrvApp.setCreatorColorCodes(
								userPrefere.getAvatarColor());

					}

					rtrvApp.setCreatorUsername(
							appNotification.getCreatorUsername());
					rtrvApp.setHyperlink(appNotification.getHyperlink());
					rtrvApp.setLastUpdatedTimestamp(
							appNotification.getLastUpdatedTimestamp());
					rtrvApp.setDescription(
							appNotification.getNotificationDescription());
					rtrvAppNotifications.add(rtrvApp);
				}
			}

			res.setAppNotifications(rtrvAppNotifications);
			res.setResponseCode("0");
			res.setResponseMessage(BOConstants.SUCCESS);

		} catch (Exception e) {
			log.error("Exception occured while fetching App Notification:  {}"
					, e.getMessage());
			res.setResponseCode("1");
			res.setResponseMessage(BOConstants.FAILED);
			res.setAppNotifications(rtrvAppNotifications);
		}
		return res;
	}

	@Override
	public Boolean saveBatchAssigned(int size, DashboardReq req) {
		Boolean status = false;
		try {
			status = appNotificationDAO.saveBatchAssignedNotifications(size,
					req);

		} catch (Exception e) {
			log.error(
					"Exception occured while Saving Batch Assigned App Notification : {}"
							, e.getMessage());
		}
		return status;
	}

	@Override
	public boolean sendFailedDocNotification(int bhcMedicalRecordId,
			int bhcInvoiceOrderId, String documentId ,String userId, String username, String userFullname) {
		Boolean status = false;
		try {
			status = appNotificationDAO.sendFailedDocumentNotification(bhcMedicalRecordId,bhcInvoiceOrderId,documentId
					,userId,username,userFullname);

		} catch (Exception e) {
			log.error(
					"Exception occured while Sending Failed Doc Notification :  {}"
							, e.getMessage());
		}
		return status;
	}
}
