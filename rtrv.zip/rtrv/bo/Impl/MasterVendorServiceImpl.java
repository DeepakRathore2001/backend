package com.healogics.rtrv.bo.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.MasterDashboardBO;
import com.healogics.rtrv.bo.MasterVendorService;
import com.healogics.rtrv.constants.BOConstants;
import com.healogics.rtrv.constants.DAOConstants;
import com.healogics.rtrv.dao.MasterDashboardDAO;
import com.healogics.rtrv.dao.MasterHistoryTimelineDAO;
import com.healogics.rtrv.dto.DocsReq;
import com.healogics.rtrv.dto.HistoryUserNotes;
import com.healogics.rtrv.dto.MasterHistoryTimeline;
import com.healogics.rtrv.dto.OrderStatusReq;
import com.healogics.rtrv.dto.OrderStatusRes;
import com.healogics.rtrv.dto.VendorStatus;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.entity.UniformDashboard;

@Service
public class MasterVendorServiceImpl implements MasterVendorService {
	private final Logger log = LoggerFactory.getLogger(MasterVendorServiceImpl.class);
	
	private final MasterDashboardBO masterDashboardBO;
	
	private final MasterDashboardDAO masterDashboardDAO;
	
	private final MasterHistoryTimelineDAO historyTimelineDAO;
	
	@Autowired
	public MasterVendorServiceImpl(MasterDashboardBO masterDashboardBO,
			MasterHistoryTimelineDAO historyTimelineDAO,
			MasterDashboardDAO masterDashboardDAO) {
		this.masterDashboardBO = masterDashboardBO;
		this.historyTimelineDAO = historyTimelineDAO;
		this.masterDashboardDAO = masterDashboardDAO;
	}
	
	@Override
	public Map<String, String> validateOrderStatusReq(OrderStatusReq req) {
		Map<String, String> validationError = new HashMap<>();
		
		try {
			if (req == null) {
				validationError.put("request", "Invalid request!");
				
			} else if (req.getVendorId() == 0) {
				validationError.put("vendorId", "Invalid Vendor Id!");

			} else {
				if (req.getVendorId() == BOConstants.NPWT_VENDOR_ID
						|| req.getVendorId() == BOConstants.APRIA_VENDOR_ID) {
					//NPWT - Solventum
					//NPWT - Apria
					
					if (req.getOrderToken() == null || req.getOrderToken().isEmpty()) {
						validationError.put("orderToken", "Invalid Order Token!");
					}
					
					if (req.getFacilityId() == 0) {
						validationError.put("facilityId", "Invalid Facility Id!");
					}
					
					if (req.getPatientId() == null || req.getPatientId().isEmpty()) {
						validationError.put("patientId", "Invalid Patient Id!");
					}
					
					if (req.getOrderDisplayNumber() == 0) {
						validationError.put("orderDisplayNumber", "Invalid Order Display Number!");
					}
					
					if (req.getStatusIdentifier() == null || req.getStatusIdentifier().isEmpty()) {
						validationError.put("statusIdentifier", "Invalid Status Identifier!");
					}
					
					if (req.getVendorOrderNumber() == null || req.getVendorOrderNumber().isEmpty()) {
						validationError.put("vendorOrderNumber", "Invalid Vendor Order Number!");
					}
					
					if (req.getOrderStatus() == null || req.getOrderStatus().isEmpty()) {
						validationError.put("orderStatus", "Invalid Order Status!");
					}
					
					if (req.getUpdatedAt() == null) {
						validationError.put("updatedAt", "Invalid Updated At!");
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception occured in validateOrderStatusReq: " +e.getMessage());
		}
		
		return validationError;
	}
	
	@Override
	public OrderStatusRes processOrderStatusRequest(OrderStatusReq req) {
		OrderStatusRes res = new OrderStatusRes();
		
		try {
			if (req.getVendorId() == BOConstants.NPWT_VENDOR_ID) {
				
					if(req.getOrderStatus().equalsIgnoreCase("Cancelled") 
							|| req.getStatus().equalsIgnoreCase("Cancelled")) {
						
						boolean isUpdated = masterDashboardDAO.updateAllRTRVRecords(
								req.getVendorOrderNumber().toString());
						
						List<String> rtrvRequestId = masterDashboardDAO.fetchAllRTRVRecords(
								req.getVendorOrderNumber().toString());
						
						for(String requestId : rtrvRequestId) {
							MasterHistoryTimeline timeline = new MasterHistoryTimeline();
							timeline.setRequestId(requestId);
							timeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
							timeline.setLastUpdatedUserFullname("Retrieve API");
							timeline.setLastUpdatedUserId(0L);
							timeline.setLastUpdatedUsername("Retrieve API");
							timeline.setRetrieveStatus("Canceled");

							VendorStatus vendorStatus2 = new VendorStatus();
							vendorStatus2.setCurrentStatus("Canceled");
							vendorStatus2.setStatusDetail(req.getStatusDetail());
							vendorStatus2.setSecondaryStatus("");
							vendorStatus2.setCoverageSummary(null);
							vendorStatus2.setRequestedDocs(null);

							timeline.setVendorStatus(vendorStatus2);

							HistoryUserNotes userNotesObj2 = new HistoryUserNotes();
							userNotesObj2.setDescription(BOConstants.CANCELED_STATUS_TEXT);
							timeline.setUserNotes(userNotesObj2);

							log.debug("Creating History timeline:  {}", timeline);
							historyTimelineDAO.saveHistoryTimeline(timeline);
							log.debug("Created History timeline");	
						}
						
						res.setResponseCode(BOConstants.SUCCESS_RESPONSE_CODE);
						res.setResponseMessage(BOConstants.SUCCESS);
				} else {
					// NPWT
					// First check order exists and update status in dashboard
					// table and send response
					DocsReq docReq = new DocsReq();
					docReq.setVendorId(req.getVendorId());
					docReq.setVendorRequestId(req.getVendorOrderNumber());
					docReq.setVendorStatus(req.getOrderStatus());

					PrimaryKeyLookup lookup = masterDashboardBO.lookupRetrieveReqId(docReq);

					if (lookup == null) {
						res.setResponseCode("2");
						res.setResponseMessage("Order not found!");
					} else {
						// Process Order Status here
						UniformDashboard dashboard = masterDashboardDAO
								.getRetrieveRecordById(lookup.getRetrieveReqId().toString());

						String retrieveStatus = "";
						String vendorStatus = req.getOrderStatus();

						if (dashboard != null) {
							retrieveStatus = dashboard.getRetrieveStatus();
						}

						// update CSR details in chart_details table
						masterDashboardDAO.updateCSRDetailsInChartDetails(lookup.getRetrieveReqId().toString(),
								req.getCsrName(), req.getCsrPhone(),
								req.getCsrEmail(), req.getStatusDetail());

						if (req.getOrderStatus().equalsIgnoreCase("Full MR Request")
								|| req.getOrderStatus().equalsIgnoreCase("Pending 3rd Party Verification")
								|| req.getOrderStatus().equalsIgnoreCase("SUB CYCLE-n")) {

							retrieveStatus = "New";
							vendorStatus = getVendorStatus(req.getVendorId(), req.getOrderStatus());
						}

						// Make statusDetail entry in history timeline
						if (req.getStatusDetail() != null && !req.getStatusDetail().isEmpty()) {
							MasterHistoryTimeline timeline = new MasterHistoryTimeline();
							timeline.setRequestId(lookup.getRetrieveReqId() + "");
							timeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
							timeline.setLastUpdatedUserFullname("Retrieve API");
							timeline.setLastUpdatedUserId(0L);
							timeline.setLastUpdatedUsername("Retrieve API");
							timeline.setRetrieveStatus(retrieveStatus);

							VendorStatus vendorStatus2 = new VendorStatus();
							vendorStatus2.setCurrentStatus(getVendorStatus(req.getVendorId(), vendorStatus));
							vendorStatus2.setStatusDetail(req.getStatusDetail());
							vendorStatus2.setSecondaryStatus("");
							vendorStatus2.setCoverageSummary(null);
							vendorStatus2.setRequestedDocs(null);

							timeline.setVendorStatus(vendorStatus2);

							HistoryUserNotes userNotesObj2 = new HistoryUserNotes();
							userNotesObj2.setDescription(req.getStatusDetail());
							timeline.setUserNotes(userNotesObj2);

							log.debug("Creating History timeline:  {}", timeline);
							historyTimelineDAO.saveHistoryTimeline(timeline);
							log.debug("Created History timeline");
						}
						res.setResponseCode(BOConstants.SUCCESS_RESPONSE_CODE);
						res.setResponseMessage(BOConstants.SUCCESS);
					}

				}
			} else if (req.getVendorId() == BOConstants.APRIA_VENDOR_ID) {
				
				
				// NPWT
				// First check order exists and update status in dashboard
				// table and send response
				DocsReq docReq = new DocsReq();
				docReq.setVendorId(req.getVendorId());
				docReq.setVendorRequestId(req.getVendorOrderNumber());
				docReq.setVendorStatus(req.getOrderStatus());

				PrimaryKeyLookup lookup = masterDashboardBO.lookupRetrieveReqId(docReq);

				if (lookup == null) {
					res.setResponseCode("2");
					res.setResponseMessage("Order not found!");
				} else {
					// Process Order Status here
					UniformDashboard dashboard = masterDashboardDAO
							.getRetrieveRecordById(lookup.getRetrieveReqId().toString());

					String retrieveStatus = "";
					String vendorStatus = req.getOrderStatus();

					if (dashboard != null) {
						retrieveStatus = dashboard.getRetrieveStatus();
					}

					// update CSR details in chart_details table
					/*masterDashboardDAO.updateCSRDetailsInChartDetails(lookup.getRetrieveReqId().toString(),
							req.getCsrName(), req.getCsrPhone(),
							req.getCsrEmail(), req.getStatusDetail());*/

					if (req.getOrderStatus().equalsIgnoreCase("SUB CYCLE-n")) {
						retrieveStatus = "New";
						vendorStatus = getVendorStatus(req.getVendorId(), req.getOrderStatus());
					}

					// Make statusDetail entry in history timeline
					if (req.getStatusDetail() != null && !req.getStatusDetail().isEmpty()) {
						MasterHistoryTimeline timeline = new MasterHistoryTimeline();
						timeline.setRequestId(lookup.getRetrieveReqId() + "");
						timeline.setHistoryId(historyTimelineDAO.getHistoryId() + 1);
						timeline.setLastUpdatedUserFullname("Retrieve API");
						timeline.setLastUpdatedUserId(0L);
						timeline.setLastUpdatedUsername("Retrieve API");
						timeline.setRetrieveStatus(retrieveStatus);

						VendorStatus vendorStatus2 = new VendorStatus();
						vendorStatus2.setCurrentStatus(getVendorStatus(req.getVendorId(), vendorStatus));
						vendorStatus2.setStatusDetail(req.getStatusDetail());
						vendorStatus2.setSecondaryStatus("");
						vendorStatus2.setCoverageSummary(null);
						vendorStatus2.setRequestedDocs(null);

						timeline.setVendorStatus(vendorStatus2);

						HistoryUserNotes userNotesObj2 = new HistoryUserNotes();
						userNotesObj2.setDescription(req.getStatusDetail());
						timeline.setUserNotes(userNotesObj2);

						log.debug("Creating History timeline:  {}", timeline);
						historyTimelineDAO.saveHistoryTimeline(timeline);
						log.debug("Created History timeline");
					}
					res.setResponseCode(BOConstants.SUCCESS_RESPONSE_CODE);
					res.setResponseMessage(BOConstants.SUCCESS);
				}

			
			}
			
		} catch (Exception e) {
			log.error("Exception occured in processOrderStatusRequest: " +e.getMessage());
			res.setResponseCode(BOConstants.FAILED_RESPONSE_CODE);
			res.setResponseMessage(BOConstants.FAILED);
		}
		return res;
	}
	
	private String getVendorStatus(Integer vendorId, String orderStatus) {
		String vendorStatus = "";

		if (vendorId == 5 |  vendorId == 2) {
			switch (orderStatus) {
			case DAOConstants.SOLVENTUM_FULL_MR_REQUEST: {
				vendorStatus = DAOConstants.VENDOR_CLAIM_SUBMISSION_STATUS;
			}
				break;

			case DAOConstants.SOLVENTUM_PENDING_3RD_PARTY_VER: {
				vendorStatus = DAOConstants.VENDOR_ORDER_RELEASE_STATUS;
			}
				break;

			case DAOConstants.SOLVENTUM_SUB_CYCLE_1: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_1_STATUS;
			}
				break;

			case DAOConstants.SOLVENTUM_SUB_CYCLE_2: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_2_STATUS;
			}
				break;

			case DAOConstants.SOLVENTUM_SUB_CYCLE_3: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_3_STATUS;
			}
				break;

			case DAOConstants.SOLVENTUM_SUB_CYCLE_4: {
				vendorStatus = DAOConstants.VENDOR_SUB_CYCLE_4_STATUS;
			}
				break;

			default:
				break;
			}
		}
		return vendorStatus;
	}
}
