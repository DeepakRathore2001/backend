package com.healogics.rtrv.bo.Impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.entity.MasterDocumentStore;
import com.healogics.rtrv.utils.CommonUtils;

@Service
public class LifeNetDocService {
private final Logger log = LoggerFactory.getLogger(LifeNetDocService.class);
	
	private final Environment env;
	
	
	@Value("${retrieve.s3.bucketname}")
	private String retrieveS3BucketName;
	
	@Autowired
	public LifeNetDocService(Environment env) {
		this.env = env;
	}
	
	public boolean uploadFileToLifeNetS3(MasterSubmitChartReq submitReq,
			MasterDocumentStore doc, Long documentId) {
		try {
			log.debug("uploadFileToLifeNetS3 started...");
			
			String dateDocSent = CommonUtils.getCurrentDate("MMddyyyy");
			
			log.debug("dateDocSent : " +dateDocSent);
			
			//BBC_FacilityID_FacilityName_PatientLastName_PatientFirstName
				//_VendorOrderNo_currentDate(MMDDYYYY)_DocType_counter.pdf
			
			String fileName = submitReq.getBluebookId() + "_"
					+ submitReq.getFacilityId() + "_"
					+ submitReq.getFacilityName() + "_"
					+ submitReq.getPatientFirstName() + "_"
					+ submitReq.getPatientLastName() + "_"
					+ ((submitReq.getVendorOrderNo() != null) 
						? (submitReq.getVendorOrderNo() + "_") : "")
					+ dateDocSent + "_"
					+ getFileTypeForS3(doc.getDocumentType()) + "_"
					+ documentId + ".pdf";
			
			if (doc != null && doc.getDocMimeType() != null
					&& !doc.getDocMimeType().isEmpty()
					&& doc.getDocMimeType().startsWith("image/png")) {
				
				fileName = submitReq.getBluebookId() + "_"
						+ submitReq.getFacilityId() + "_"
						+ submitReq.getFacilityName() + "_"
						+ submitReq.getPatientFirstName() + "_"
						+ submitReq.getPatientLastName() + "_"
						+ ((submitReq.getVendorOrderNo() != null) 
							? (submitReq.getVendorOrderNo() + "_") : "")
						+ dateDocSent + "_"
						+ getFileTypeForS3(doc.getDocumentType()) + "_"
						+ documentId + ".png";
				
			} else if (doc != null && doc.getDocMimeType() != null
					&& !doc.getDocMimeType().isEmpty()
					&& (doc.getDocMimeType().startsWith("image/jpeg")
							|| doc.getDocMimeType().startsWith("image/jpg"))) {
				
				fileName = submitReq.getBluebookId() + "_"
						+ submitReq.getFacilityId() + "_"
						+ submitReq.getFacilityName() + "_"
						+ submitReq.getPatientFirstName() + "_"
						+ submitReq.getPatientLastName() + "_"
						+ ((submitReq.getVendorOrderNo() != null) 
							? (submitReq.getVendorOrderNo() + "_") : "")
						+ dateDocSent + "_"
						+ getFileTypeForS3(doc.getDocumentType()) + "_"
						+ documentId + ".jpg";
				
			} else if (doc != null && doc.getDocMimeType() != null
					&& !doc.getDocMimeType().isEmpty()
					&& doc.getDocMimeType().startsWith("image/gif")) {
				
				fileName = submitReq.getBluebookId() + "_"
						+ submitReq.getFacilityId() + "_"
						+ submitReq.getFacilityName() + "_"
						+ submitReq.getPatientFirstName() + "_"
						+ submitReq.getPatientLastName() + "_"
						+ ((submitReq.getVendorOrderNo() != null) 
							? (submitReq.getVendorOrderNo() + "_") : "")
						+ dateDocSent + "_"
						+ getFileTypeForS3(doc.getDocumentType()) + "_"
						+ documentId + ".gif";
				
			} else if (doc != null && doc.getDocMimeType() != null
					&& !doc.getDocMimeType().isEmpty()
					&& doc.getDocMimeType().startsWith("image/bmp")) {
				
				fileName = submitReq.getBluebookId() + "_"
						+ submitReq.getFacilityId() + "_"
						+ submitReq.getFacilityName() + "_"
						+ submitReq.getPatientFirstName() + "_"
						+ submitReq.getPatientLastName() + "_"
						+ ((submitReq.getVendorOrderNo() != null) 
							? (submitReq.getVendorOrderNo() + "_") : "")
						+ dateDocSent + "_"
						+ getFileTypeForS3(doc.getDocumentType()) + "_"
						+ documentId + ".bmp";
			}
			
			log.debug("fileName : " +fileName);
			
			fileName = removeSpecialCharacters(fileName);
			
			log.info("filename after removed Special Chars ###: {}" ,fileName);

			String path = env.getProperty("retrieve.local.file.location") + fileName;
			
			log.info("Converting BYTES to PDF file..");
			log.info("Local File Path: {}", path);
			
			String localFilePath = getPDFFile(doc.getDocumentContent(), path);
			
			String uploadS3BucketPath = env
					.getProperty("retrieve.lifenet.documents.upload.bucket.location");
			String uploadS3Bucket = env
					.getProperty("retrieve.lifenet.documents.upload.bucket");
			String unprocessedS3Bucket = env
					.getProperty("retrieve.lifenet.documents.unprocessed.bucket");
			
			
			if (doc.getDocumentType() != null
					&& doc.getDocumentType().equalsIgnoreCase("PROVIDER_ORDER")) {
				uploadS3BucketPath = env
						.getProperty("retrieve.lifenet.orders.upload.bucket.location");
				uploadS3Bucket = env
						.getProperty("retrieve.lifenet.orders.upload.bucket");
				unprocessedS3Bucket = env
						.getProperty("retrieve.lifenet.orders.unprocessed.bucket");
			}
			
			if (uploadFileToS3(uploadS3BucketPath, fileName, localFilePath,
					uploadS3Bucket, unprocessedS3Bucket, doc.getDocMimeType())) {
				//Success
				if (deleteLocalFile(localFilePath)) {
					log.info("Local file Successfully deleted from path: {}", localFilePath);
				} else {
					log.info("Local file not deleted from path: {}", localFilePath);
				}
				return true;
			} else {
				//Failed to upload
				return false;
			}
			
		} catch (Exception e) {
			log.error("Exception occured in uploadFileToLifeNetS3 : {}", e.getMessage());
		}
		return false;
	}
	
	private String getPDFFile(String base64Content, String path) {
		File file = null;
		try {

			byte[] data = DatatypeConverter.parseBase64Binary(base64Content);

			file = new File(path);

			try (OutputStream outputStream = new BufferedOutputStream(
					new FileOutputStream(file))) {
				outputStream.write(data);
				log.debug("Inside output stream.....");
			} catch (Exception e) {
				log.error("Exception occured while writing outstream:  {}",
						e.getMessage());
			}

		} catch (Exception e) {
			log.error("Exception occured in getPDFFile: {}", e.getMessage());
		}
		return path;
	}
	
	private String getPDFFileFromBytes(byte[] pdfBytes, String path) {
		File file = null;
		try {

			// byte[] data = DatatypeConverter.parseBase64Binary(base64Content);

			file = new File(path);

			try (OutputStream outputStream = new BufferedOutputStream(
					new FileOutputStream(file))) {
				outputStream.write(pdfBytes);
				log.debug("Inside output stream.....");
			} catch (Exception e) {
				log.error("Exception occured while writing outstream:  {}",
						e.getMessage());
			}

		} catch (Exception e) {
			log.error("Exception occured in getPDFFile: {}", e.getMessage());
		}
		return path;
	}
	
	private boolean deleteLocalFile(String path) {
		try {
			File file = new File(path);
			if (file.exists()) {
				return file.delete();
			} else {
				return true;
			}
		} catch (Exception e) {
			log.error("Exception occured in getPDFFile: {}", e.getMessage());
		}
		return false;
	}
	
	private boolean copyToUnprocessed(String bucketName, String fromKey,
			String toKey) {
		log.info("copyToUnprocessed running");
		log.info("bucketName : {}", bucketName);
		log.info("fromKey : {}", fromKey);
		log.info("toKey : {}", toKey);
		try {

			AWSCredentials credentials = new BasicAWSCredentials(
					"AKIA5S3Z2GRILUCVUUP5",
					"OtNlRMwOejR3g9gz4LHS7iJa3SLNcvPzFWtLU4Sx");
			if (credentials == null) {
				log.error("AWS credentials - Error : {}", credentials);
				return false;
			}
			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(
							new AWSStaticCredentialsProvider(credentials))
					.withRegion(Regions.US_EAST_1).build();
			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}
			try {
				s3client.copyObject(bucketName, fromKey, bucketName, toKey);
			} catch (AmazonServiceException e) {
				log.error("Exception occured in while copying file: {}",
						e.getMessage());
			}
		} catch (Exception e) {
			log.error("Exception occured in copyToUnprocessed: {}",
					e.getMessage());
		}
		log.info("copyToUnprocessed completed");
		return removeProcessedFile(bucketName, fromKey);
	}
	private boolean removeProcessedFile(String bucketName, String objectKey) {
		log.info("removeProcessedFile running");
		log.info("bucketName : {}", bucketName);
		log.info("objectKey : {}", objectKey);
		try {
			AWSCredentials credentials = new BasicAWSCredentials(
					"AKIA5S3Z2GRILUCVUUP5",
					"OtNlRMwOejR3g9gz4LHS7iJa3SLNcvPzFWtLU4Sx");
			if (credentials == null) {
				log.error("AWS credentials - Error : {}", credentials);
				return false;
			}
			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(
							new AWSStaticCredentialsProvider(credentials))
					.withRegion(Regions.US_EAST_1).build();
			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}
			try {
				s3client.deleteObject(bucketName, objectKey);
			} catch (AmazonServiceException e) {
				log.error("Exception occured in while copying file:  {}",
						e.getMessage());
			}
		} catch (Exception e) {
			log.error("Exception occured in copyToArchieved:  {}",
					e.getMessage());
		}
		log.info("removeProcessedFile completed!");
		return true;
	}
	
	private String getFileTypeForS3(String doctype) {
		String fileType = "";
		switch (doctype) {			
			case "CUSTOM_SCANS" :
				fileType = "CustomScans";
				break;
			case "PROBLEM_LIST" :
				fileType = "ProblemList";
				break;
			case "PROCEDURE_NOTES" :
				fileType = "Debridements";
				break;
			case "PROGRESS_NOTES" :
				fileType = "ProgressNotes";
				break;
			case "WOUND_ASSESSMENT" :
				fileType = "WoundAssessments";
				break;
			case "PATIENT_HISTORY" :
				fileType = "HxROS";
				break;
			case "TEST_RESULTS" :
				fileType = "TestResults";
				break;
			case "LOWER_EXTREMITY" :
				fileType = "LEAsmt";
				break;
			case "ACTIVITY_DAILY_LIVING" :
				fileType = "ActivityDailyLiving";
				break;
			case "DISCHARGE_SUMMARY" :
				fileType = "DischargeInstructions";
				break;
			case "PROVIDER_ORDER" :
				fileType = "Orders";
				break;
			case "NUTRITIONAL_ASSESSMENT" :
				fileType = "NutritionAssessment";
				break;
			case "MEDICAL_RECONCILIATION" :
				fileType = "MedicalRecord";
				break;
			case "INSURANCE_CARD" :
				fileType = "InsuranceCard";
				break;
			case "OPERATIVE_REPORT" :
				fileType = "OperativeReport";
				break;
			default :
				fileType = doctype;
				break;
		}
		return fileType;
	}
	
	private String getuploadS3Location(String doctype) {
		String uploadLocation = "";
		
		String uploadS3Bucket = env
				.getProperty("retrieve.lifenet.upload.bucket");
		
		String unprocessedS3Bucket = env
				.getProperty("retrieve.lifenet.unprocessed.bucket");
		
		if (doctype != null
				&& doctype.equalsIgnoreCase("PROVIDER_ORDER")) {
			uploadLocation = "";
		}
		return uploadLocation;
	}
	
	private String removeSpecialCharacters(String fileName) {
		try {
			if (fileName != null && !fileName.trim().isEmpty()) {
				return fileName.replaceAll("[<>:\"/\\\\|?* ]", "");
			}
		} catch (Exception e) {
			System.out.println("An error occurred in removeSpecialCharacters: " + e.getMessage());
		}
		return fileName;
	}
	
	private boolean uploadFileToS3(String uploadS3BucketPath, String destFileName,
			String localFilePath, String uploadS3BucketFromKey,
			String unprocessedS3BucketToKey, String mimeType) {
		boolean uploadStatus = false;
		try {
			log.debug("uploadS3BucketPath: {}", uploadS3BucketPath);
			log.debug("destFileName: {}", destFileName);
			log.debug("localFilePath: {}", localFilePath);
			log.debug("uploadS3BucketFromKey: {}", uploadS3BucketFromKey);
			log.debug("unprocessedS3BucketToKey: {}", unprocessedS3BucketToKey);

			AWSCredentials credentials = new BasicAWSCredentials(
					"AKIA5S3Z2GRILUCVUUP5",
					"OtNlRMwOejR3g9gz4LHS7iJa3SLNcvPzFWtLU4Sx");

			if (credentials == null) {
				log.error("AWS credentials - Error : {}", credentials);
				return false;
			}

			AmazonS3 s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(
							new AWSStaticCredentialsProvider(credentials))
					.withRegion(Regions.US_EAST_1).build();

			if (s3client == null) {
				log.error("Error : s3client : {}", s3client);
				return false;
			}

			File file = new File(localFilePath);

			PutObjectRequest request = new PutObjectRequest(uploadS3BucketPath,
					destFileName, file);
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType(mimeType);
			metadata.setContentEncoding("utf-8");
			request.setMetadata(metadata);

			s3client.putObject(request);
			log.debug("Content Length AWS S3:   {} ",
					metadata.getContentLength());

			log.info("File Successfully uploaded to S3 location: {}",uploadS3BucketPath);
			
			log.info("destFileName:  {}", destFileName);

			uploadStatus = true;

		} catch (AmazonS3Exception e) {
			log.debug("Print Stack Trace:");
			e.printStackTrace();
			log.error("Error uploading file to S3. AWS Error Code: {}",
					e.getErrorMessage());

		} catch (Exception e) {
			log.error("Exception occured in uploadFileToS3: {}",
					e.getMessage());
		}
		log.debug("uploadStatus:    {}", uploadStatus);

		return copyToUnprocessed(retrieveS3BucketName,
				(uploadS3BucketFromKey + "/" + destFileName),
				(unprocessedS3BucketToKey + destFileName));
	}
}
