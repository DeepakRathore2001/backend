package com.healogics.rtrv.bo.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healogics.rtrv.bo.ServiceLineBO;
import com.healogics.rtrv.dao.ServiceLineDAO;
import com.healogics.rtrv.dto.SaveServiceLineReq;
import com.healogics.rtrv.dto.SaveServiceLineRes;

@Service
public class ServiceLineBOImpl implements ServiceLineBO {

	private final ServiceLineDAO serviceLineDAO;
	
	@Autowired
	public ServiceLineBOImpl(ServiceLineDAO serviceLineDAO) {
		this.serviceLineDAO = serviceLineDAO;
	}

	@Override
	public SaveServiceLineRes saveServiceLine(SaveServiceLineReq req)
			throws Exception {
		return serviceLineDAO.saveServiceLine(req);
	}

	@Override
	public SaveServiceLineRes updateColorCodes(SaveServiceLineReq req)
			throws Exception {
		return serviceLineDAO.updateUserColorCodes(req);
	}

}
