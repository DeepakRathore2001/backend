package com.healogics.rtrv.bo;

import java.util.List;

import com.healogics.rtrv.dto.SystemNotificationListReq;
import com.healogics.rtrv.dto.SystemNotificationListRes;
import com.healogics.rtrv.dto.SystemNotificationWSAReq;
import com.healogics.rtrv.dto.SystemNotificationWSARes;
import com.healogics.rtrv.dto.UserNotificationReq;
import com.healogics.rtrv.dto.UserNotificationRes;

public interface SystemNotificationBO {

	SystemNotificationWSARes createNotifications(
			SystemNotificationWSAReq systemNotificationReq);

	SystemNotificationListRes getSystemNotificationList(
			SystemNotificationListReq systemNotListReq);

	SystemNotificationWSARes updateSystemNotification(
			SystemNotificationWSAReq systemWSAReq);

	UserNotificationRes saveUserNotifications(
			UserNotificationReq userNotificationReq);
	
	public UserNotificationRes deleteSystemNotifications(List<String> notificationIds);

}
