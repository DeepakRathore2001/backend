package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.DocumentNotificationReq;
import com.healogics.rtrv.dto.DocumentNotificationRes;
import com.healogics.rtrv.exception.CustomException;

public interface DocNotificationBO {
	public DocumentNotificationRes getDocNotification(DocumentNotificationReq req)
			throws CustomException;
}
