package com.healogics.rtrv.bo;

import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;
import com.healogics.rtrv.dto.APIResponse;
import com.healogics.rtrv.dto.GetOrderUpdateReq;
import com.healogics.rtrv.dto.GetSavedAttachmentRes;
import com.healogics.rtrv.dto.MasterChartDetailsReq;
import com.healogics.rtrv.dto.MasterChartDetailsRes;
import com.healogics.rtrv.dto.MasterHistoryTimelineRes;
import com.healogics.rtrv.dto.MasterModifyRecordReq;
import com.healogics.rtrv.dto.MasterNoteByIdRes;
import com.healogics.rtrv.dto.MasterNotesListRes;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartRes;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.SaveResponse;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsRes;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.dto.VisitDocumentListReq;
import com.healogics.rtrv.dto.VisitDocumentRes;
import com.healogics.rtrv.dto.VisitsListRes;

public interface MasterChartReviewBO {
	public RTRVAPIResponse saveMasterNotes(SaveMasterNotesReq req);

	public MasterChartDetailsRes getChartData(MasterChartDetailsReq req);
	
	public SaveResponse saveMasterChartDetails(MasterSaveChartReq req);
	
	public MasterNotesListRes getMasterNotesList(String requestId, int index, String serviceLine);
	
	public MasterHistoryTimelineRes getOrderHistory(String orderId, int index);
	
	public MasterSubmitChartRes masterSubmitChart(MasterSubmitChartReq req);

	public VisitDocumentRes getVisitDocumentList(VisitDocumentListReq req);

	public VisitsListRes getVisitsList(VisitDocumentListReq req);

	public APIResponse updateOrderInformation(GetOrderUpdateReq req);

	public SaveResponse modifyRecord(MasterModifyRecordReq req);

	public GetSavedAttachmentRes getSavedDocuments(MasterChartDetailsReq req);

	public ViewAttachmentRes getAttachmentContent(MasterChartDetailsReq req);
	
	public MasterNoteByIdRes getNoteById(String noteId);

	public UpdatePatientDetailsRes updatePatientDetails(UpdatePatientDetailsReq req);

}
