package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.AdminDashboardFilterOptionsRes;
import com.healogics.rtrv.dto.AdminDashboardReq;
import com.healogics.rtrv.dto.AdminDashboardRes;
import com.healogics.rtrv.dto.AdministrationRetrieveMembersRes;
import com.healogics.rtrv.dto.AdministrationRetrieveUsersRes;
import com.healogics.rtrv.dto.CenterAssignmentPopupRes;
import com.healogics.rtrv.dto.FilteredBBCResponse;
import com.healogics.rtrv.dto.UpdateCenteAssignmentReq;

public interface AdministrationBO {

	public AdministrationRetrieveMembersRes getRetrieveMembers(boolean isFilter, AdminDashboardReq dashboardReq, int index);

	public AdministrationRetrieveUsersRes getRetrieveUsers(boolean isFilter, AdminDashboardReq dashboardReq, int index);

	public AdminDashboardFilterOptionsRes getSearchFilterOptions(
			AdminDashboardReq req);

	public AdminDashboardFilterOptionsRes getCenterFilterOptions(
			AdminDashboardReq req);

	public CenterAssignmentPopupRes getCenterAssignmentValues(AdminDashboardReq req);

	public AdminDashboardRes saveRetrieveUsers(AdminDashboardReq req);

	public AdminDashboardRes saveRetrieveMembers(UpdateCenteAssignmentReq req);

	public AdministrationRetrieveMembersRes getRetrieveMembersToExcel(boolean isFilter, AdminDashboardReq dashboardReq);

	public FilteredBBCResponse getCenterDropDownOptions(AdminDashboardReq req);


}
