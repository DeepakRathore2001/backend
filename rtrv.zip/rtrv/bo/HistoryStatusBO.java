package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.DocumentUploadStatusRes;
import com.healogics.rtrv.dto.StatusTimelineRes;
import com.healogics.rtrv.exception.CustomException;

public interface HistoryStatusBO {
	public StatusTimelineRes getStatusHistory(int bhcMedRecId, int bhcInvoiceId, int index)
			throws CustomException;

	public DocumentUploadStatusRes getDocUploadStatus(String documentUUID) ;
}
