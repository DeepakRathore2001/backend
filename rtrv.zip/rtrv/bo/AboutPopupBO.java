package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.BuildDetailsResponse;

public interface AboutPopupBO {

	public BuildDetailsResponse getBuildDetails();

}
