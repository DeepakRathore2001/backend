package com.healogics.rtrv.bo;

import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;
import com.healogics.rtrv.dto.MasterAppNotificaionReq;
import com.healogics.rtrv.dto.MasterAppNotificationCountRes;
import com.healogics.rtrv.dto.MasterAppNotificationListRes;

public interface MasterAppNotificationBO {
	public MasterAppNotificationListRes getAppNotifications(
			MasterAppNotificaionReq req);
	
	public RTRVAPIResponse updateNotifications(
			MasterAppNotificaionReq req);
	
	public MasterAppNotificationCountRes getAppNotificationCount(
			String userId);
}
