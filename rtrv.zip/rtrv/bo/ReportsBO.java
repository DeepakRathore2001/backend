package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.AWDFilterOptionsRes;
import com.healogics.rtrv.dto.NPWTFilterOptionsRes;
import com.healogics.rtrv.dto.NPWTReportReq;
import com.healogics.rtrv.dto.NPWTReportRes;
import com.healogics.rtrv.dto.ViewReportsReq;
import com.healogics.rtrv.dto.ViewReportsRes;

public interface ReportsBO {

	public ViewReportsRes viewReports(ViewReportsReq req, boolean isExcel);

	public NPWTReportRes generateNPWTReport(boolean isFilter, NPWTReportReq req, int index, boolean isExcel);

	public NPWTFilterOptionsRes npwtReportFilterOptions(NPWTReportReq req);

	public AWDFilterOptionsRes awdReportFilterOptions(ViewReportsReq req);
	
}
