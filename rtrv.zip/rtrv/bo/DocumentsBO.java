package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.DocumentURLReq;
import com.healogics.rtrv.dto.DocumentURLRes;
import com.healogics.rtrv.dto.DocumentsListReq;
import com.healogics.rtrv.dto.IHealDocumentRes;
import com.healogics.rtrv.dto.IHealMedRecRes;
import com.healogics.rtrv.dto.IHealTesResultRes;
import com.healogics.rtrv.dto.ManualAttachmentRes;
import com.healogics.rtrv.dto.MedRecListReq;
import com.healogics.rtrv.dto.MedRecListRes;
import com.healogics.rtrv.dto.ViewAttachmentReq;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.dto.WoundListRes;
import com.healogics.rtrv.exception.CustomException;

public interface DocumentsBO {

	IHealDocumentRes getIHealCustomScanList(DocumentsListReq req)
			throws CustomException;

	IHealDocumentRes getProviderOrderList(DocumentsListReq req) throws CustomException;

	IHealDocumentRes getProgressNotesList(DocumentsListReq req) throws CustomException;
	
	WoundListRes getIHealWoundList(DocumentsListReq req) throws CustomException;

	IHealDocumentRes getDebridementsList(DocumentsListReq req) throws CustomException;
	
	IHealDocumentRes getIHealWoundAssessmentList(DocumentsListReq req) throws CustomException;

	ManualAttachmentRes getManualAttachmentsList(DocumentsListReq req) throws CustomException;

	ViewAttachmentRes getIHealFileGet(ViewAttachmentReq req);

	ViewAttachmentRes viewManualAttachments(ViewAttachmentReq req) throws CustomException;
	
	public DocumentURLRes getDocumentURL(DocumentURLReq req);

	IHealTesResultRes getIHealTestResultsList(DocumentsListReq req) throws CustomException;

	MedRecListRes getMedRecList(MedRecListReq req);

}
