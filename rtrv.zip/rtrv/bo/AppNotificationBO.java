package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.AppNotificaionsReq;
import com.healogics.rtrv.dto.AppNotificationCountRes;
import com.healogics.rtrv.dto.AppNotificationListRes;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.UpdateAppNotificationsRes;

public interface AppNotificationBO {

	public AppNotificationCountRes getNotificationCount(AppNotificaionsReq req);

	public Boolean saveAppNotifications(SaveNotesReq req);

	public Boolean saveAssignedNotifications(SaveRequest saveReq);

	public UpdateAppNotificationsRes updateNotifications(AppNotificaionsReq req);
	
	public AppNotificationListRes getAppNotifications(AppNotificaionsReq req);

	public Boolean saveBatchAssigned(int size, DashboardReq req);

	public boolean sendFailedDocNotification(int bhcMedicalRecordId,
			int bhcInvoiceOrderId, String documentId, String userId, String userName, String userFullname);

}
