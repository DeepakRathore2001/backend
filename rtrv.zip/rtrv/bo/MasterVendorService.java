package com.healogics.rtrv.bo;

import java.util.Map;

import com.healogics.rtrv.dto.OrderStatusReq;
import com.healogics.rtrv.dto.OrderStatusRes;

public interface MasterVendorService {
	public Map<String, String> validateOrderStatusReq(OrderStatusReq req);
	public OrderStatusRes processOrderStatusRequest(OrderStatusReq req);
}
