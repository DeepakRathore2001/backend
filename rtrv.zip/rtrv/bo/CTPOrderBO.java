package com.healogics.rtrv.bo;

public interface CTPOrderBO {

}
