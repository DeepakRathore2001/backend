package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.ChartReviewReq;
import com.healogics.rtrv.dto.ChartReviewRes;
import com.healogics.rtrv.dto.ModifyRecordReq;
import com.healogics.rtrv.dto.NoteByIdRes;
import com.healogics.rtrv.dto.NotesListRes;
import com.healogics.rtrv.dto.PatientSearchReq;
import com.healogics.rtrv.dto.PatientSearchRes;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveNotesRes;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.SaveResponse;
import com.healogics.rtrv.dto.SubmitRequest;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsRes;
import com.healogics.rtrv.dto.UserRolesRes;

public interface ChartReviewBO {
	public ChartReviewRes getChartReviewData(ChartReviewReq req);
	public SaveResponse saveDetailsnAttachments(SaveRequest req);
	public SaveResponse submitRecord(SubmitRequest req);
	public SaveNotesRes saveNotes(SaveNotesReq req);
	public NotesListRes getNotesData(ChartReviewReq req);
	public UserRolesRes getUserRoles(boolean isSuperUser);
	public NoteByIdRes getNoteById(String noteId);
	public PatientSearchRes searchPatient(PatientSearchReq patientSearchReq);
	public UpdatePatientDetailsRes updatePatientDetails(
			UpdatePatientDetailsReq req);
	public SaveResponse modifyRecord(ModifyRecordReq req);

}
