package com.healogics.rtrv.bo;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.healogics.rtrv.dto.APIResponse;
import com.healogics.rtrv.dto.CTPDashboardRes;
import com.healogics.rtrv.dto.CTPData;
import com.healogics.rtrv.dto.CTPFilterOptionsRes;
import com.healogics.rtrv.dto.DocsReq;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.NotesAttemptDetails;
import com.healogics.rtrv.dto.UniformDashboardRes;
import com.healogics.rtrv.dto.UniformData;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.WoundQOrderDetailsRes;
import com.healogics.rtrv.dto.WoundQOrderNotificationReq;
import com.healogics.rtrv.dto.WoundQOrderNotificationRes;
import com.healogics.rtrv.entity.PrimaryKeyLookup;
import com.healogics.rtrv.exception.CustomException;

public interface MasterDashboardBO {

	CTPDashboardRes getCTPData(boolean isExcel, boolean isFilter,
			MasterCTPDashboardReq dashboardReq,
			int index, String taskType, String username);

	CTPFilterOptionsRes getCTPSearchFilterOptions(MasterCTPDashboardReq req);
	
	public APIResponse saveRequestedDocs(DocsReq req);

	UpdateAssignedToRes batchUpdateAssignee(MasterCTPDashboardReq req,
			List<CTPData> records);

	UniformDashboardRes getUniformData(boolean isExcel, boolean isFilter,
			MasterCTPDashboardReq dashboardReq, int index, String taskType, String username);
	
	public Map<String, String> validDocReq(DocsReq req);
	
	public NotesAttemptDetails getAttemptTypeByServiceline(String serviceLine);
	
	public PrimaryKeyLookup lookupRetrieveReqId(DocsReq req);

	UpdateAssignedToRes batchUpdateAssignees(MasterCTPDashboardReq req, List<UniformData> records);

	Map<String, String> validDocReqForWoundQ(WoundQOrderNotificationReq req);

	WoundQOrderNotificationRes getOrderDetails(WoundQOrderNotificationReq req)throws CustomException;

}
