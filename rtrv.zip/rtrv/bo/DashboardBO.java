package com.healogics.rtrv.bo;

import java.util.List;

import com.healogics.rtrv.dto.AWDDashboardRes;
import com.healogics.rtrv.dto.AWDData;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.FilterOptionsRes;
import com.healogics.rtrv.dto.SetStatusReq;
import com.healogics.rtrv.dto.SetStatusRes;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.exception.CustomException;

public interface DashboardBO {
	public AWDDashboardRes getAWDData(boolean isBatchAssignment,boolean isExcel,boolean isFilter, DashboardReq req,int index, String taskType, String assignee);
	public Long getAWDNewTaskcount();
	
	public FilterOptionsRes getSearchFilterOptions(DashboardReq req) throws CustomException;
	public SetStatusRes setStatus(SetStatusReq req);
	public UpdateAssignedToRes batchUpdateAssignee(DashboardReq req, List<AWDData> awdRecords);
}
