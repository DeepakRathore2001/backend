package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.SaveServiceLineReq;
import com.healogics.rtrv.dto.SaveServiceLineRes;

public interface ServiceLineBO {

	public SaveServiceLineRes saveServiceLine(SaveServiceLineReq req) throws Exception;

	public SaveServiceLineRes updateColorCodes(SaveServiceLineReq req) throws Exception;

}
