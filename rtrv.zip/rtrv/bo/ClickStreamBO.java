package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.ClickStreamReq;
import com.healogics.rtrv.dto.ClickStreamRes;
import com.healogics.rtrv.exception.CustomException;

public interface ClickStreamBO {
	public ClickStreamRes saveClickStreamData(ClickStreamReq req)
			throws CustomException;
}
