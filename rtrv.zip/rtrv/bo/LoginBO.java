package com.healogics.rtrv.bo;

import java.sql.Timestamp;

import com.healogics.rtrv.dto.AuthenticateByTokenRes;
import com.healogics.rtrv.dto.AuthenticateIntanceByTokenRes;
import com.healogics.rtrv.dto.DocumentURLReq;
import com.healogics.rtrv.dto.IHealUser;
import com.healogics.rtrv.dto.IhealUserReq;
import com.healogics.rtrv.dto.IhealUserdetails;
import com.healogics.rtrv.dto.LoginReq;
import com.healogics.rtrv.dto.LoginRes;
import com.healogics.rtrv.dto.OAuthReq;
import com.healogics.rtrv.dto.UserFacilityRes;
import com.healogics.rtrv.dto.VendorLoginRes;
import com.healogics.rtrv.entity.UserPreference;
import com.healogics.rtrv.exception.CustomException;

public interface LoginBO {

	public LoginRes login(LoginReq loginReq);
	
	public IhealUserdetails iheal2Authenticate(IhealUserReq user); 
	
	public IhealUserdetails logout(IHealUser user);
	
	public AuthenticateByTokenRes iheal2AuthenticateByToken(OAuthReq req);
	
	public LoginRes loginByOAuth(OAuthReq req);
	
	public UserPreference getUserPreference(String stringUserId);
	
	public AuthenticateIntanceByTokenRes authenticateIntanceByToken(DocumentURLReq req);
	
	public VendorLoginRes authenticateVendor(LoginReq req);

	public UserFacilityRes getUserFacilities(String userId, String masterToken);
	
	public void updateUserPreference(String userId, Timestamp currentTime)
			throws CustomException ;

}
