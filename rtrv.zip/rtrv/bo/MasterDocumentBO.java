package com.healogics.rtrv.bo;

import com.healogics.rtrv.dto.MasterGetDocumentReq;
import com.healogics.rtrv.dto.MasterGetDocumentRes;

public interface MasterDocumentBO {

	public MasterGetDocumentRes getDocumentContent(MasterGetDocumentReq req);
}
