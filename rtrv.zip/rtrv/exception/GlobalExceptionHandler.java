package com.healogics.rtrv.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

@RestControllerAdvice
public class GlobalExceptionHandler{
	
	public GlobalExceptionHandler() {
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public Map<String, String> handleGenericException(Exception ex){
		Map<String, String> errors = new HashMap<>();
		errors.put("error", ex.getMessage());
	 return errors;
	}
	
	@ExceptionHandler(CustomException.class)
	public Map<String, String> handleCustomException(CustomException ex){
		Map<String, String> errors = new HashMap<>();
		errors.put("error", ex.getMessage());
	 return errors;
	}
	
	@ExceptionHandler(javax.validation.ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public Map<String, String> handleValidationException(javax.validation.ConstraintViolationException ex){
		Map<String, String> errors = new HashMap<>();
		ex.getConstraintViolations().forEach(violation-> errors.put("error", violation.getMessage()));
	return errors;
	}
	
	@ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex){
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(err-> errors.put(err.getField(), err.getDefaultMessage()));
	return errors;
	}
	
	
}
