package com.healogics.rtrv.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.healogics.rtrv.entity.BuildDetails;

@Repository
@Component
public class BuildDetailsRepository {
	
	private final DynamoDBMapper dynamoDBMapper;
	
	@Autowired
	public BuildDetailsRepository(DynamoDBMapper dynamoDBMapper) {
		this.dynamoDBMapper = dynamoDBMapper;
	}

	public BuildDetails getBuildByKey(String hashKey) {
		BuildDetails bd = new BuildDetails();
		bd.setPk(hashKey);
		// By setting this flag false, it will sort results using Range key in
		// reverse order
		DynamoDBQueryExpression<BuildDetails> queryExp = new DynamoDBQueryExpression<>();
		queryExp.withHashKeyValues(bd).withScanIndexForward(false);
		List<BuildDetails> buildList = dynamoDBMapper.query(BuildDetails.class,
				queryExp);
		bd = buildList.get(0);
		return bd;
	}
}
