package com.healogics.rtrv.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.AdministrationBO;
import com.healogics.rtrv.bo.DashboardBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.AWDDashboardRes;
import com.healogics.rtrv.dto.AdminDashboardReq;
import com.healogics.rtrv.dto.AdministrationRetrieveMembersRes;
import com.healogics.rtrv.dto.AdministrationRetrieveUsersRes;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.utils.CommonUtils;
import com.healogics.rtrv.utils.ExportExcelUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ExportExcelController {

	private final Logger log = LoggerFactory
			.getLogger(ExportExcelController.class);

	private final DashboardBO dashboardBO;
	private final AdministrationBO administrationBO;
	
	@Autowired
	public ExportExcelController(DashboardBO dashboardBO, AdministrationBO administrationBO) {
		this.dashboardBO = dashboardBO;
		this.administrationBO = administrationBO;
	}

	@ApiOperation(value = "To export excel for facility dashboard")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/dashboardexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityDashboardExcel(
			@ApiParam(name = "Export Facility Dashboard Excel", value = "Export Facility Dashboard Excel", required = true) 
			@RequestBody DashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AWDDashboardRes awdDashboardRes = null;
		String excelStream = "";
		boolean isFilter = false;
		boolean isBatchAssignment = false;
		try {
			
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}

			awdDashboardRes = dashboardBO.getAWDData(isBatchAssignment, true,isFilter, req,
					req.getIndex(), req.getTaskType(), req.getUsername());
			log.debug("awdDashboardRes: {}",awdDashboardRes);
			excelStream = ExportExcelUtil.generateDashboardExcel(req,awdDashboardRes.getRecords());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Center Assignments Report")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/generatecenterassignmentsreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> centerAssignmentsExcel(
			@ApiParam(name = "AdminDashboardReq", value = "AdminDashboardReq data", required = true)
			@RequestBody AdminDashboardReq dashboardReq) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AdministrationRetrieveMembersRes res = null;
		String excelStream = "";

		try {
			boolean isFilter = false;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
			//boolean isExcel = true;
			res = administrationBO.getRetrieveMembersToExcel(isFilter, dashboardReq);
			//log.debug("viewReportsRes: " + res);

			excelStream = ExportExcelUtil
					.generateCenterAssignmentsReportExcel(res.getRetrieveMembers());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
	
}
