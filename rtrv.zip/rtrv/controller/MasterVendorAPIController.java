package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;

import java.beans.PropertyEditorSupport;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.MasterVendorService;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.OrderStatusReq;
import com.healogics.rtrv.dto.OrderStatusRes;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class MasterVendorAPIController {
	
	private final Logger log = LoggerFactory
			.getLogger(MasterVendorAPIController.class);
	
	private final MasterVendorService vendorService;
	
	@Autowired
	public MasterVendorAPIController(MasterVendorService vendorService) {
		this.vendorService = vendorService;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Integer.class, new PropertyEditorSupport() {
			@Override
			public void setAsText(String text) throws IllegalArgumentException{
				if(!text.matches("\\d+")) {
					throw new IllegalArgumentException("Invalid value for the :"+text+". Only numeric values are allowed");
				}
				setValue(Integer.parseInt(text));
			}
		});
	}
	
	@ApiOperation(value = "Fetch Order Status")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/api/docservices/orderStatus", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> requestDocs(
			@ApiParam(name = "DocsReq", value = "DocsReq data", required = true)
			@Valid @RequestBody OrderStatusReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		OrderStatusRes orderStatusRes = new OrderStatusRes();
		String requestId = UUID.randomUUID().toString();
		log.info("orderStatus - Received request id : " +requestId);
		
		try {
			log.info("orderStatus - Request: " +req);
			
			Map<String, String> validationError = vendorService.validateOrderStatusReq(req);
			
			if (validationError.size() > 0) {
				orderStatusRes.setResponseCode("1");
				orderStatusRes.setResponseMessage(validationError.toString());
				orderStatusRes.setRequestId(requestId);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderStatusRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ORDER_STATUS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			orderStatusRes = vendorService.processOrderStatusRequest(req);
			
			if (orderStatusRes != null) {
				orderStatusRes.setRequestId(requestId);
			}
			
			if (orderStatusRes != null
					&& orderStatusRes.getResponseCode() != null
					&& (orderStatusRes.getResponseCode().equalsIgnoreCase("0")
							|| orderStatusRes.getResponseCode().equalsIgnoreCase("2"))) {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderStatusRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ORDER_STATUS);
				
				log.info("orderStatus - Response : " +orderStatusRes);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.OK);
			} else {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderStatusRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ORDER_STATUS);
				
				log.info("orderStatus - Response : " +orderStatusRes);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			orderStatusRes = new OrderStatusRes();
			orderStatusRes.setRequestId(requestId);
			orderStatusRes.setResponseCode("2");
			orderStatusRes.setResponseMessage(ControllerConstants.UNKNOWN_ERROR);
			
			log.info("orderStatus - Response : " +orderStatusRes);
			
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, orderStatusRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ORDER_STATUS);
		
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}