package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.DOC_NOTIFICATION_SERVICE;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.DocNotificationBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.DocumentNotificationReq;
import com.healogics.rtrv.dto.DocumentNotificationRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DocNotificationController {
	private final Logger log = LoggerFactory
			.getLogger(DocNotificationController.class);
	
	private final Environment env;
	
	private final DocNotificationBO docNotificationBO;
	
	@Autowired
	public DocNotificationController(Environment env, DocNotificationBO docNotificationBO) {
		this.env = env;
		this.docNotificationBO = docNotificationBO;
	}
	
	@ApiOperation(value = "Document Notification Service")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/user/documentnotification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAttachmentDetails(
			@ApiParam(name = "DocumentNotificationReq Req", 
				value = "DocumentNotificationReq Req", required = true)
			@RequestBody DocumentNotificationReq req,
			@RequestHeader Map<String, String> headers) {
		
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		Map<String, Object> messageHeader;
		try {
			
			log.debug("req : {}",req);
			log.debug("headers : {}" ,headers);
			
			String rtvAppKey = headers.get("retrieve-app-key");
			String rtvAppSecret = headers.get("retrieve-app-secret");
			
			log.debug("rtvAppKey.equalsIgnoreCase(env.getProperty(retrieve.app.key) : {}" 
					,rtvAppKey.equalsIgnoreCase(env.getProperty("retrieve.app.key")));
			
			log.debug("rtvAppKey.equalsIgnoreCase(env.getProperty(retrieve.app.secret) : {}" 
					,rtvAppKey.equalsIgnoreCase(env.getProperty("retrieve.app.secret")));
			
			if (rtvAppKey == null || rtvAppKey.isEmpty()
					|| rtvAppSecret == null || rtvAppSecret.isEmpty()
					|| !rtvAppKey.equalsIgnoreCase(env.getProperty("retrieve.app.key"))
					|| !rtvAppSecret.equalsIgnoreCase(env.getProperty("retrieve.app.secret"))) {

				statusCode = ControllerConstants.INVALID_CREDENTIALS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_CREDENTIALS;
				
				response = CommonUtils.getResponseObject(
						ControllerConstants.DOC_NOTIFICATION_SERVICE, statusCode,
						errorCode, statusDesc);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, null);
				
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.add(ControllerConstants.TIMESTAMP, formattedDate);
				httpHeaders.add(ControllerConstants.ACTION,
						ControllerConstants.DOC_NOTIFICATION_SERVICE);
				httpHeaders.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				
				return new ResponseEntity<>(json, httpHeaders,
						HttpStatus.UNAUTHORIZED);
			}
			
			if (req.getFacilityId() == 0
					|| req.getPatientId() == 0
					|| req.getVisitId() == 0
					|| req.getClientState() == null
					|| req.getClientState().isEmpty()
					|| req.getPdfFileName() == null
					|| req.getPdfFileName().isEmpty()) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				
				response = CommonUtils.getResponseObject(
						ControllerConstants.DOC_NOTIFICATION_SERVICE, statusCode,
						errorCode, statusDesc);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, null);
				
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.add(ControllerConstants.TIMESTAMP, formattedDate);
				httpHeaders.add(ControllerConstants.ACTION,
						ControllerConstants.DOC_NOTIFICATION_SERVICE);
				httpHeaders.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				
				return new ResponseEntity<>(json, httpHeaders,
						HttpStatus.BAD_REQUEST);
			}

			DocumentNotificationRes res = docNotificationBO.getDocNotification(req);
			
			messageHeader = CommonUtils.getMessageHeader(DOC_NOTIFICATION_SERVICE, formattedDate);
			response = CommonUtils.getResponseObject(DOC_NOTIFICATION_SERVICE, "200", res.getErrorCode(),
					res.getErrorMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add(ControllerConstants.TIMESTAMP, formattedDate);
			httpHeaders.add(ControllerConstants.ACTION, DOC_NOTIFICATION_SERVICE);

			return new ResponseEntity<>(json, httpHeaders, HttpStatus.OK);


		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(DOC_NOTIFICATION_SERVICE,
					formattedDate);
			response = CommonUtils.getResponseObject(DOC_NOTIFICATION_SERVICE,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, null);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add(ControllerConstants.TIMESTAMP, formattedDate);
			httpHeaders.add(ControllerConstants.ACTION,
					ControllerConstants.DOC_NOTIFICATION_SERVICE);
			httpHeaders.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			httpHeaders.add(ControllerConstants.RESPONSE, String.valueOf(response));

			return new ResponseEntity<>(json, httpHeaders,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
