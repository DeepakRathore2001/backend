package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_UPDATE_APP_NOTIFICATION;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_APP_NOTIFICATIONS;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_APP_NOTIFICATIONS_STATUS;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.MasterAppNotificationBO;
import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.MasterAppNotificaionReq;
import com.healogics.rtrv.dto.MasterAppNotificationCountRes;
import com.healogics.rtrv.dto.MasterAppNotificationListRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class MasterAppNotificationController {
	
	private final Logger log = LoggerFactory
			.getLogger(MasterAppNotificationController.class);

	private final MasterAppNotificationBO masterAppNotifyBO;

	@Autowired
	public MasterAppNotificationController(MasterAppNotificationBO masterAppNotifyBO) {
		this.masterAppNotifyBO = masterAppNotifyBO;
	}

	@ApiOperation(value = "To update app notifications")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/updatemasterappnotifications", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateAppNotification(
			@ApiParam(name = "MasterAppNotificaionReq", value = "MasterAppNotificaionReq data", required = true)
			@RequestBody MasterAppNotificaionReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		RTRVAPIResponse res = null;
		Map<String, Object> response = null;
		try {
			res = masterAppNotifyBO.updateNotifications(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MASTER_UPDATE_APP_NOTIFICATION,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_UPDATE_APP_NOTIFICATION, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_UPDATE_APP_NOTIFICATION);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MASTER_UPDATE_APP_NOTIFICATION,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_UPDATE_APP_NOTIFICATION, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_UPDATE_APP_NOTIFICATION);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_UPDATE_APP_NOTIFICATION,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_UPDATE_APP_NOTIFICATION, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_UPDATE_APP_NOTIFICATION);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch App Notification List")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/masterappnotifications", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAppNotificationList(
			@ApiParam(name = "MasterAppNotificaionReq", value = "MasterAppNotificaionReq data", required = true)
			@RequestBody MasterAppNotificaionReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterAppNotificationListRes res = null;
		Map<String, Object> response = null;
		try {

			res = masterAppNotifyBO.getAppNotifications(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						MASTER_APP_NOTIFICATIONS, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_APP_NOTIFICATIONS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_APP_NOTIFICATIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						MASTER_APP_NOTIFICATIONS, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_APP_NOTIFICATIONS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_APP_NOTIFICATIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_APP_NOTIFICATIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_APP_NOTIFICATIONS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_APP_NOTIFICATIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch App Notification Count")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/masterappnotificationstatus", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAppNotificationStatus(
			@ApiParam(name = "MasterAppNotificaionReq", value = "MasterAppNotificaionReq data", required = true)
			@RequestBody MasterAppNotificaionReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterAppNotificationCountRes res = null;
		Map<String, Object> response = null;
		try {

			res = masterAppNotifyBO.getAppNotificationCount(req.getUserId());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						MASTER_APP_NOTIFICATIONS_STATUS, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_APP_NOTIFICATIONS_STATUS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_APP_NOTIFICATIONS_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						MASTER_APP_NOTIFICATIONS_STATUS, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_APP_NOTIFICATIONS_STATUS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_APP_NOTIFICATIONS_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_APP_NOTIFICATIONS_STATUS,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_APP_NOTIFICATIONS_STATUS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_APP_NOTIFICATIONS_STATUS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
