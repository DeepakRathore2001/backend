package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.ADMINISTRATION_RETRIEVE_MEMBERS;
import static com.healogics.rtrv.constants.ControllerConstants.ADMINISTRATION_RETRIEVE_USERS;
import static com.healogics.rtrv.constants.ControllerConstants.ADMIN_FILTER_DASHBOARD;
import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.UPDATE_RETRIEVE_USERS_TABLE;
import static com.healogics.rtrv.constants.ControllerConstants.UPDATE_RETRIEVE_MEMBERS_TABLE;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.AdministrationBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.AdminDashboardFilterOptionsRes;
import com.healogics.rtrv.dto.AdminDashboardReq;
import com.healogics.rtrv.dto.AdminDashboardRes;
import com.healogics.rtrv.dto.AdministrationRetrieveMembersRes;
import com.healogics.rtrv.dto.AdministrationRetrieveUsersRes;
import com.healogics.rtrv.dto.CenterAssignmentPopupRes;
import com.healogics.rtrv.dto.FilteredBBCResponse;
import com.healogics.rtrv.dto.UpdateCenteAssignmentReq;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AdministrationController {
	private final Logger log = LoggerFactory
			.getLogger(AdministrationController.class);

	private final AdministrationBO administrationBO;
	
	@Autowired
	public AdministrationController(AdministrationBO administrationBO) {
		this.administrationBO = administrationBO;
	}
	
	@ApiOperation(value = "Fetch Retrieve Members")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/filterretrievemembers", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getRetrieveMembers(@RequestBody AdminDashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdministrationRetrieveMembersRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
			
			res = administrationBO.getRetrieveMembers(isFilter, dashboardReq, dashboardReq.getIndex());

			messageHeader = CommonUtils.getMessageHeader(ADMINISTRATION_RETRIEVE_MEMBERS,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMINISTRATION_RETRIEVE_MEMBERS, "200", "0",
					SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMINISTRATION_RETRIEVE_MEMBERS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADMINISTRATION_RETRIEVE_MEMBERS,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMINISTRATION_RETRIEVE_MEMBERS, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMINISTRATION_RETRIEVE_MEMBERS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Retrieve Users")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@GetMapping(value = "/app/getretrieveusers", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getRetrieveUsers(@RequestBody AdminDashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdministrationRetrieveUsersRes res = null;
		Map<String, Object> response = null;
		try {
			res = administrationBO.getRetrieveUsers(false, dashboardReq, dashboardReq.getIndex());

			messageHeader = CommonUtils.getMessageHeader(ADMINISTRATION_RETRIEVE_USERS,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMINISTRATION_RETRIEVE_USERS, "200", "0",
					SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMINISTRATION_RETRIEVE_USERS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADMINISTRATION_RETRIEVE_USERS,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMINISTRATION_RETRIEVE_USERS, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMINISTRATION_RETRIEVE_USERS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Fetch Filtered Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/filterretrieveusers", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredData(
			@ApiParam(name = "AdminDashboardReq", value = "DashboardReq data", required = true) @RequestBody AdminDashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdministrationRetrieveUsersRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
				res = administrationBO.getRetrieveUsers(isFilter,
						dashboardReq, dashboardReq.getIndex());

			if (res != null
					&& res.getResponseCode() != null
					&& res.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(ADMIN_FILTER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ADMIN_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(ADMIN_FILTER_DASHBOARD,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.ADMIN_FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(ADMIN_FILTER_DASHBOARD,
					formattedDate);
			response = CommonUtils.getResponseObject(ADMIN_FILTER_DASHBOARD, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.ADMIN_FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get Role Admin Dashboard columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/rolefilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody AdminDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AdminDashboardFilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = administrationBO.getSearchFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get Center Admin Dashboard columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/centerfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCenterMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) @RequestBody AdminDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		AdminDashboardFilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = administrationBO.getCenterFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get Center Admin Dashboard columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getcenterassignmentvalues", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCenterAssignmentPopupValues(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true) 
			@RequestBody AdminDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
	    CenterAssignmentPopupRes res = null;
		Map<String, Object> messageHeader;
		try {
			
			res = administrationBO.getCenterAssignmentValues(req);

			if (res == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_CENTER_ASSIGNMENT_VALUES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	

	@ApiOperation(value = "To get Center DropDown Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getCenterDropDownOptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCenterDropDownOptions(
			@ApiParam(name = "Search CenterDropDown Options", value = "Search CenterDropDown Options", required = true) @RequestBody AdminDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilteredBBCResponse dropDownOptions = null;
		Map<String, Object> messageHeader;
		try {

		 dropDownOptions = administrationBO.getCenterDropDownOptions(req);

			if ( dropDownOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE,  dropDownOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE,  dropDownOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE,  dropDownOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Update Retrieve Users")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/saveretrieveusers", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateRetrieveUsers(
			@ApiParam(name = "AdminDashboardReq", value = "AdminDashboardReq data", required = true)
			@RequestBody AdminDashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdminDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			
			res = administrationBO.saveRetrieveUsers(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_RETRIEVE_USERS_TABLE,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_RETRIEVE_USERS_TABLE, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_RETRIEVE_USERS_TABLE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_RETRIEVE_USERS_TABLE,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_RETRIEVE_USERS_TABLE, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_RETRIEVE_USERS_TABLE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_RETRIEVE_USERS_TABLE,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_RETRIEVE_USERS_TABLE, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_RETRIEVE_USERS_TABLE);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Update Center Assignments")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savecenterassignee", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateRetrieveMembers(
			@ApiParam(name = "AdminDashboardReq", value = "AdminDashboardReq data", required = true)
			@RequestBody UpdateCenteAssignmentReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AdminDashboardRes res = null;
		Map<String, Object> response = null;
		try {
			
			res = administrationBO.saveRetrieveMembers(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_RETRIEVE_MEMBERS_TABLE,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_RETRIEVE_MEMBERS_TABLE, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_RETRIEVE_MEMBERS_TABLE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_RETRIEVE_MEMBERS_TABLE,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_RETRIEVE_MEMBERS_TABLE, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_RETRIEVE_MEMBERS_TABLE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_RETRIEVE_MEMBERS_TABLE,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_RETRIEVE_MEMBERS_TABLE, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_RETRIEVE_MEMBERS_TABLE);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
