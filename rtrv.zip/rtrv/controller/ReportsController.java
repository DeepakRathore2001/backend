package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.VIEW_REPORTS;
import static com.healogics.rtrv.constants.ControllerConstants.NPWT_REPORT;
import static com.healogics.rtrv.constants.ControllerConstants.NPWT_REPORT_EXCEL;
import static com.healogics.rtrv.constants.ControllerConstants.NPWT_REPORT_FILTER_OPTIONS;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.ReportsBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.AWDFilterOptionsRes;
import com.healogics.rtrv.dto.NPWTFilterOptionsRes;
import com.healogics.rtrv.dto.NPWTReportReq;
import com.healogics.rtrv.dto.NPWTReportRes;
import com.healogics.rtrv.dto.ViewReportsReq;
import com.healogics.rtrv.dto.ViewReportsRes;
import com.healogics.rtrv.utils.CommonUtils;
import com.healogics.rtrv.utils.ExportExcelUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ReportsController {

	private static final String AWD_REPORT_FILTER_OPTIONS = null;

	private final Logger log = LoggerFactory.getLogger(ReportsController.class);

	private final ReportsBO reportsBO;
	
	@Autowired
	public ReportsController(ReportsBO reportsBO) {
		this.reportsBO = reportsBO;
	}

	@ApiOperation(value = "Fetch Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/viewreports", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> viewReports(
			@ApiParam(name = "ViewReportsReq", value = "ViewReportsReq data", required = true) @RequestBody ViewReportsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ViewReportsRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isExcel = false;
			res = reportsBO.viewReports(req, isExcel);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(VIEW_REPORTS,
						formattedDate);
				response = CommonUtils.getResponseObject(VIEW_REPORTS, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_REPORTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(VIEW_REPORTS,
						formattedDate);
				response = CommonUtils.getResponseObject(VIEW_REPORTS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_REPORTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(VIEW_REPORTS,
					formattedDate);
			response = CommonUtils.getResponseObject(VIEW_REPORTS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.VIEW_REPORTS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To export excel for view reports")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/reportsexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityDashboardExcel(
			@ApiParam(name = "Export Reports Excel", value = "Export Reports Excel", required = true) @RequestBody ViewReportsReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		ViewReportsRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			res = reportsBO.viewReports(req, isExcel);
			//log.debug("viewReportsRes: " + res);
			excelStream = ExportExcelUtil
					.generateReportsExcel(res.getReports());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch NPWT Report Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/generatenpwtreport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> generateNPWTReport(
			@ApiParam(name = "NPWTReportReq", value = "NPWTReportReq data", required = true) @RequestBody NPWTReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NPWTReportRes res = null;
		Map<String, Object> response = null;
		try {
			boolean isExcel = false;
			boolean isFilter = false;
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}
			res = reportsBO.generateNPWTReport(isFilter, req, req.getIndex(), isExcel);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(NPWT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(NPWT_REPORT, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NPWT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(NPWT_REPORT,
						formattedDate);
				response = CommonUtils.getResponseObject(NPWT_REPORT, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NPWT_REPORT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NPWT_REPORT,
					formattedDate);
			response = CommonUtils.getResponseObject(NPWT_REPORT, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NPWT_REPORT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch NPWT Report Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/npwtreportfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> generateNPWTReportFilterOptions(
			@ApiParam(name = "NPWTReportReq", value = "NPWTReportReq data", required = true) @RequestBody NPWTReportReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NPWTFilterOptionsRes res = null;
		Map<String, Object> response = null;
		try {
			//boolean isExcel = false;
			res = reportsBO.npwtReportFilterOptions(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(NPWT_REPORT_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(NPWT_REPORT_FILTER_OPTIONS, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NPWT_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(NPWT_REPORT_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(NPWT_REPORT_FILTER_OPTIONS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NPWT_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NPWT_REPORT_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(NPWT_REPORT_FILTER_OPTIONS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NPWT_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To export excel for view uniform reports")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/uniformreportexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getUniformReportExcel(
			@ApiParam(name = "NPWTReportReq", value = "NPWTReportReq data", required = true) @RequestBody NPWTReportReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		NPWTReportRes res = null;
		String excelStream = "";

		try {
			boolean isExcel = true;
			boolean isFilter = false;
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}
			res = reportsBO.generateNPWTReport(isFilter, req, req.getIndex(), isExcel);
			//log.debug("viewReportsRes: " + res);
			excelStream = ExportExcelUtil
					.generateUniformReportsExcel(res.getReports());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Fetch AWD Report Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/awdreportfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> generateAWDReportFilterOptions(
			@ApiParam(name = "ViewReportsReq", value = "ViewReportsReq data", required = true) @RequestBody ViewReportsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AWDFilterOptionsRes res = null;
		Map<String, Object> response = null;
		try {
			//boolean isExcel = false;
			res = reportsBO.awdReportFilterOptions(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(AWD_REPORT_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(AWD_REPORT_FILTER_OPTIONS, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.AWD_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(AWD_REPORT_FILTER_OPTIONS,
						formattedDate);
				response = CommonUtils.getResponseObject(AWD_REPORT_FILTER_OPTIONS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.AWD_REPORT_FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(AWD_REPORT_FILTER_OPTIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(AWD_REPORT_FILTER_OPTIONS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NPWT_REPORT_FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
