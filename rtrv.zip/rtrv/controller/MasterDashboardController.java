package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.CTP_DASHBOARD;
import static com.healogics.rtrv.constants.ControllerConstants.UNIFORM_DASHBOARD;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_BATCH_ASSIGNED_TO;
import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.MasterDashboardBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.APIResponse;
import com.healogics.rtrv.dto.CTPDashboardRes;
import com.healogics.rtrv.dto.CTPFilterOptionsRes;
import com.healogics.rtrv.dto.CTPOrderReq;
import com.healogics.rtrv.dto.CTPOrderRes;
import com.healogics.rtrv.dto.DocsReq;
import com.healogics.rtrv.dto.MasterCTPDashboardReq;
import com.healogics.rtrv.dto.NotesAttemptDetails;
import com.healogics.rtrv.dto.UniformDashboardRes;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.dto.WoundQOrderDetailsRes;
import com.healogics.rtrv.dto.WoundQOrderNotificationReq;
import com.healogics.rtrv.dto.WoundQOrderNotificationRes;
import com.healogics.rtrv.exception.CustomException;
import com.healogics.rtrv.utils.CommonUtils;
import com.healogics.rtrv.utils.ExportExcelUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class MasterDashboardController {
	private final Logger log = LoggerFactory
			.getLogger(MasterDashboardController.class);
	
private final MasterDashboardBO ctpDashboardBO;
	
	@Autowired
	public MasterDashboardController(MasterDashboardBO ctpDashboardBO) {
		this.ctpDashboardBO = ctpDashboardBO;
	}
	
	@ApiOperation(value = "Health Check")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@GetMapping(value = "/user/HealthCheck", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> healthCheck() {
		Map<String, Object> json = new HashMap<>();
		json.put("status", "Success");
		return new ResponseEntity<>(json,
				HttpStatus.OK);
		
	}
	
	@ApiOperation(value = "Fetch Order Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/orderinfo", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getOrderDetails(
			@ApiParam(name = "CTPOrderReq", value = "CTPOrderReq data", required = true)
			@RequestBody CTPOrderReq orderReq) {
		String formattedDate = CommonUtils.getformattedDate();
		CTPOrderRes orderRes = new CTPOrderRes();
		String requestId = UUID.randomUUID().toString();
		log.info("Received request id : " +requestId);
		try {
			Map<String, String> validationError = checkCPTValidation(orderReq);
			
			if (validationError.size() > 0) {
				orderRes.setResponseCode("1");
				orderRes.setResponseMessage(validationError.toString());
				orderRes.setRequestId(requestId);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_ORDER);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			//call BO method here
			//right now setting response manually
			log.info("Order Received: " +orderReq);
			
			orderRes.setResponseCode("0");
			orderRes.setResponseMessage("Order Received!");
			orderRes.setRequestId(requestId);
			
			log.debug("orderRes : " +orderRes);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, orderRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_ORDER);
		
			return new ResponseEntity<>(json, headers,
					HttpStatus.OK);
			
		} catch (Exception e) {
			orderRes.setRequestId(requestId);
			orderRes.setResponseCode("2");
			orderRes.setResponseMessage("Unknown Error!");
			
			log.debug("orderRes : " +orderRes);
			
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, orderRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_ORDER);
		
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private Map<String, String> checkCPTValidation(CTPOrderReq orderReq){
		Map<String, String> validationError = new HashMap<>();
		if (orderReq == null) {
			validationError.put("request", "Invalid request!");
		} else {
			if (orderReq.getVendorId() == null
				|| orderReq.getVendorId().isEmpty()) {
				validationError.put("vendorId", "Invalid vendorId!");
			}
			
			if (orderReq.getOrderSource() == null
				|| orderReq.getOrderSource().isEmpty()) {
				validationError.put("orderSource", "Invalid Order Source!");
			}
			
			if (orderReq.getPatientFirstName() == null
				|| orderReq.getPatientFirstName().isEmpty()) {
				validationError.put("patientFirstName", "Invalid Patient First Name!");
			}
			
			if (orderReq.getPatientLastName() == null
				|| orderReq.getPatientLastName().isEmpty()) {
				validationError.put("patientLastName", "Invalid Patient Last Name!");
			}
			
			if (orderReq.getPhysicianFirstName() == null
				|| orderReq.getPhysicianFirstName().isEmpty()) {
				validationError.put("physicianFirstName", "Invalid Physician First Name!");
			}
			
			if (orderReq.getPhysicianLastName() == null
				|| orderReq.getPhysicianLastName().isEmpty()) {
				validationError.put("physicianLastName", "Invalid Physician Last Name!");
			}
			
			if (orderReq.getCaseManagerFirstName() == null
				|| orderReq.getCaseManagerFirstName().isEmpty()) {
				validationError.put("caseManagerFirstName", "Invalid CaseManager First Name!");
			}
			
			if (orderReq.getCaseManagerLastName() == null
				|| orderReq.getCaseManagerLastName().isEmpty()) {
				validationError.put("caseManagerLastName", "Invalid CaseManager Last Name!");
			}
			
			if (orderReq.getOrderReceivedDate() == null
					|| orderReq.getOrderReceivedDate().isEmpty()) {
				validationError.put("orderReceivedDate", "Invalid Order Received Date!");
			}
			
			if (orderReq.getCurrentStatus() == null
					|| orderReq.getCurrentStatus().isEmpty()) {
				validationError.put("currentStatus", "Invalid Current Status!");
			}
			
			if (orderReq.getMissingElementsNotes() == null
					|| orderReq.getMissingElementsNotes().isEmpty()) {
				validationError.put("missingElementsNotes", "Invalid Missing Elements Notes!");
			}
			
		/*	// New Parameters
			if (orderReq.getVendorReferralNo() == null
					|| orderReq.getVendorReferralNo().isEmpty()) {
				validationError.put("vendorReferralNo", "Invalid Vendor Referral No!");
			}
			
			if (orderReq.getHealogicsOrderNo() == null
					|| orderReq.getHealogicsOrderNo().isEmpty()) {
				validationError.put("healogicsOrderNo", "Invalid Healogics Order No!");
			}
			
			if (orderReq.getHealogicsPatientID() == null
					|| orderReq.getHealogicsPatientID().isEmpty()) {
				validationError.put("healogicsPatientID", "Invalid Healogics Patient ID!");
			}
			
			if (orderReq.getHealogicsPatientMRN() == null
					|| orderReq.getHealogicsPatientMRN().isEmpty()) {
				validationError.put("healogicsPatientMRN", "Invalid Healogics Patient MRN!");
			}
			
			if (orderReq.getWaitingOnDocs() == null
					|| orderReq.getWaitingOnDocs().isEmpty()) {
				validationError.put("waitingOnDocs", "Invalid Waiting On Docs!");
			}
			
			if (orderReq.getPendingPriorAuthDate() == null) {
				validationError.put("pendingPriorAuthDate", "Invalid Pending Prior Auth Date!");
			}
			
			if (orderReq.getPendingPriorAuthWaiting() == null
					|| orderReq.getPendingPriorAuthWaiting().isEmpty()) {
				validationError.put("pendingPriorAuthWaiting", "Invalid Pending Prior Auth Waiting!");
			}
			
			if (orderReq.getPreAppAppealDate() == null) {
				validationError.put("preAppAppealDate", "Invalid Pre App Appeal Date!");
			}
			
			if (orderReq.getPostAppAppealDate() == null) {
				validationError.put("postAppAppealDate", "Invalid Post App Appeal Date!");
			}
			
			if (orderReq.getPostAppAppealStatus() == null
					|| orderReq.getPostAppAppealStatus().isEmpty()) {
				validationError.put("postAppAppealStatus", "Invalid Post App Appeal Status!");
			}
			
			if (orderReq.getFollowupDate() == null
					|| orderReq.getFollowupDate().isEmpty()) {
				validationError.put("followupDate", "Invalid Followup Date!");
			}
			
			if (orderReq.getNotes() == null
					|| orderReq.getNotes().isEmpty()) {
				validationError.put("notes", "Invalid Notes!");
			}
			
			if (orderReq.getSpecialInstructions() == null
					|| orderReq.getSpecialInstructions().isEmpty()) {
				validationError.put("specialInstructions", "Invalid Special Instructions!");
			}
			
			if (orderReq.getPrimaryInsName() == null
					|| orderReq.getPrimaryInsName().isEmpty()) {
				validationError.put("primaryInsName", "Invalid Primary Ins Name!");
			}
			
			if (orderReq.getPrimaryInsPolicyNo() == null
					|| orderReq.getPrimaryInsPolicyNo().isEmpty()) {
				validationError.put("primaryInsPolicyNo", "Invalid Primary Ins Policy No!");
			}
			
			if (orderReq.getPrimaryInsCompany() == null
					|| orderReq.getPrimaryInsCompany().isEmpty()) {
				validationError.put("primaryInsCompany", "Invalid Primary Ins Company!");
			}
			
			if (orderReq.getPrimaryInsMac() == null
					|| orderReq.getPrimaryInsMac().isEmpty()) {
				validationError.put("primaryInsMac", "Invalid Primary Ins Mac!");
			}
			
			if (orderReq.getPrimaryInsDeductible() == null
					|| orderReq.getPrimaryInsDeductible().isEmpty()) {
				validationError.put("primaryInsDeductible", "Invalid Primary Ins Deductible!");
			}
			
			if (orderReq.getPrimaryInsDeducMet() == null
					|| orderReq.getPrimaryInsDeducMet().isEmpty()) {
				validationError.put("primaryInsDeducMet", "Invalid Primary Ins Deduc Met!");
			}
			
			if (orderReq.getPrimaryInsCopay() == null
					|| orderReq.getPrimaryInsCopay().isEmpty()) {
				validationError.put("primaryInsCopay", "Invalid Primary Ins Copay!");
			}
			
			if (orderReq.getPrimaryInsCoinsurance() == null
					|| orderReq.getPrimaryInsCoinsurance().isEmpty()) {
				validationError.put("primaryInsCoinsurance", "Invalid Primary Ins Coinsurance!");
			}
			
			if (orderReq.getPrimaryInsOOPMax() == null
					|| orderReq.getPrimaryInsOOPMax().isEmpty()) {
				validationError.put("primaryInsOOPMax", "Invalid Primary Ins OOP Max!");
			}
			
			if (orderReq.getPrimaryInsOOPMet() == null
					|| orderReq.getPrimaryInsOOPMet().isEmpty()) {
				validationError.put("primaryInsOOPMet", "Invalid Primary Ins OOP Met!");
			}
			
			if (orderReq.getPrimaryInsStatus() == null
					|| orderReq.getPrimaryInsStatus().isEmpty()) {
				validationError.put("primaryInsStatus", "Invalid Primary Ins Status!");
			}
			
			if (orderReq.getPrimaryInsPercentCovered() == null
					|| orderReq.getPrimaryInsPercentCovered().isEmpty()) {
				validationError.put("primaryInsPercentCovered", "Invalid Primary Ins Percent Covered!");
			}
			
			if (orderReq.getPrimaryInsReasonNotCovered() == null
					|| orderReq.getPrimaryInsReasonNotCovered().isEmpty()) {
				validationError.put("primaryInsReasonNotCovered", "Invalid Primary Ins Reason Not Covered!");
			}
			
			if (orderReq.getPrimaryInsReasonNA() == null
					|| orderReq.getPrimaryInsReasonNA().isEmpty()) {
				validationError.put("primaryInsReasonNA", "Invalid Primary Ins Reason NA!");
			}
			
			if (orderReq.getSecondaryInsName() == null
					|| orderReq.getSecondaryInsName().isEmpty()) {
				validationError.put("secondaryInsName", "Invalid Secondary Ins Name!");
			}
			
			if (orderReq.getSecondaryInsCompany() == null
					|| orderReq.getSecondaryInsCompany().isEmpty()) {
				validationError.put("secondaryInsCompany", "Invalid Secondary Ins Company!");
			}
			
			if (orderReq.getSecondaryInsMac() == null
					|| orderReq.getSecondaryInsMac().isEmpty()) {
				validationError.put("secondaryInsMac", "Invalid Secondary Ins Mac!");
			}
			
			if (orderReq.getSecondaryInsPolicyNo() == null
					|| orderReq.getSecondaryInsPolicyNo().isEmpty()) {
				validationError.put("secondaryInsPolicyNo", "Invalid Secondary Ins Policy No!");
			}
			
			if (orderReq.getSecondaryInsDeductible() == null
					|| orderReq.getSecondaryInsDeductible().isEmpty()) {
				validationError.put("secondaryInsDeductible", "Invalid Secondary Ins Deductible!");
			}
			
			if (orderReq.getSecondaryInsDeducMet() == null
					|| orderReq.getSecondaryInsDeducMet().isEmpty()) {
				validationError.put("secondaryInsDeducMet", "Invalid Secondary Ins Deduc Met!");
			}
			
			if (orderReq.getSecondaryInsCopay() == null
					|| orderReq.getSecondaryInsCopay().isEmpty()) {
				validationError.put("secondaryInsCopay", "Invalid Secondary Ins Copay!");
			}   */
		
		}
		return validationError;
	}
	
	@ApiOperation(value = "Fetch Order Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/api/docservices/requestDocs", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> requestDocs(
			@ApiParam(name = "DocsReq", value = "DocsReq data", required = true)
			@Valid @RequestBody DocsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		APIResponse orderRes = new APIResponse();
		String requestId = UUID.randomUUID().toString();
		log.info("requestDocs - Received request id : " +requestId);
		
		try {
			log.info("requestDocs - Request: " +req);
			
			Map<String, String> validationError = ctpDashboardBO.validDocReq(req);
			
			if (validationError.size() > 0) {
				orderRes.setResponseCode("1");
				orderRes.setResponseMessage(validationError.toString());
				orderRes.setRequestId(requestId);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			orderRes = ctpDashboardBO.saveRequestedDocs(req);
			
			if (orderRes != null) {
				orderRes.setRequestId(requestId);
			}
			
			if (orderRes != null
					&& orderRes.getResponseCode() != null
					&& orderRes.getResponseCode().equalsIgnoreCase("0")) {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
				
				log.info("requestDocs - orderRes: " +orderRes);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.OK);
			} else {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
				
				log.info("requestDocs - orderRes: " +orderRes);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			orderRes.setRequestId(requestId);
			orderRes.setResponseCode("2");
			orderRes.setResponseMessage(ControllerConstants.UNKNOWN_ERROR);
			
			log.info("requestDocs - orderRes: " +orderRes);
			
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, orderRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.REQUEST_EDOCS);
		
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch CTP Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/masterdashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCPTDashboardData(
			@ApiParam(name = "MasterCTPDashboardReq", value = "MasterCTPDashboardReq data", required = true)
			@RequestBody MasterCTPDashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		CTPDashboardRes ctpDashboardRes = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			boolean isExcel = false;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
			if (dashboardReq.getServiceLine().equalsIgnoreCase("CTP")) {

				ctpDashboardRes = ctpDashboardBO.getCTPData(isExcel, isFilter,
						dashboardReq, dashboardReq.getIndex(),
						dashboardReq.getTaskType(), dashboardReq.getUsername());
			} else {
				ctpDashboardRes = new CTPDashboardRes();
				ctpDashboardRes.setRecords(new ArrayList<>());
				ctpDashboardRes.setResponseCode("0");
				ctpDashboardRes.setResponseMessage("Success");
			}
			if (ctpDashboardRes != null
					&& ctpDashboardRes.getResponseCode() != null
					&& ctpDashboardRes.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(CTP_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(CTP_DASHBOARD, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, ctpDashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CTP_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(CTP_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(CTP_DASHBOARD, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, ctpDashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CTP_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(CTP_DASHBOARD,
					formattedDate);
			response = CommonUtils.getResponseObject(CTP_DASHBOARD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, ctpDashboardRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CTP_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get CTP Dashboard columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/masterfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true)
			@RequestBody MasterCTPDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CTPFilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = ctpDashboardBO.getCTPSearchFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To export excel for Master dashboard")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/masterexcelexport", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityDashboardExcel(
			@ApiParam(name = "MasterCTPDashboardReq", value = "MasterCTPDashboardReq", required = true) 
			@RequestBody MasterCTPDashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		CTPDashboardRes ctpDashboardRes = null;
		String excelStream = "";
		boolean isFilter = false;
		try {
			
			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}

			ctpDashboardRes = ctpDashboardBO.getCTPData(true,isFilter, req,
					req.getIndex(), req.getTaskType(), req.getUsername());
			log.debug("ctpDashboardRes: {}",ctpDashboardRes);
			
			excelStream = ExportExcelUtil.generateMasterDashboardExcel(req,ctpDashboardRes.getRecords());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Master Update Batch Assigned To")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/masterbatchassigned", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateBatchAssignedTo(
			@ApiParam(name = "UpdateAssignedToReq", value = "UpdateAssignedToReq data", required = true)
			@RequestBody MasterCTPDashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UpdateAssignedToRes res = null;
		UniformDashboardRes dashboardRes = null;
		Map<String, Object> response = null;
		CTPDashboardRes ctpDashboardRes = null;
		boolean isFilter = false;
		boolean isExcel = false;
		try {

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}
			if (req.getServiceLine() == "CTP" || req.getServiceLine().equalsIgnoreCase("CTP")) {
				ctpDashboardRes = ctpDashboardBO.getCTPData(true, isFilter, req,
						req.getIndex(), req.getTaskType(),
						req.getUsername());
				log.debug("ctpDashboardRes: {}", ctpDashboardRes);

				res = ctpDashboardBO.batchUpdateAssignee(req, ctpDashboardRes.getRecords());
				
			} else if (req.getServiceLine() == "NPWT" || req.getServiceLine().equalsIgnoreCase("NPWT")) {
				dashboardRes = ctpDashboardBO.getUniformData(isExcel, isFilter, req,
						req.getIndex(), req.getTaskType(),
						req.getUsername());
				log.debug("npwtdashboardRes: {}", dashboardRes);

				res = ctpDashboardBO.batchUpdateAssignees(req, dashboardRes.getRecords());
			}

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MASTER_BATCH_ASSIGNED_TO,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_BATCH_ASSIGNED_TO, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_BATCH_ASSIGNED_TO);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MASTER_BATCH_ASSIGNED_TO,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_BATCH_ASSIGNED_TO, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_BATCH_ASSIGNED_TO);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_BATCH_ASSIGNED_TO,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_BATCH_ASSIGNED_TO, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_BATCH_ASSIGNED_TO);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}	
	
	
	@ApiOperation(value = "Fetch Uniform Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/uniformdashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getUniformDashboardData(
			@ApiParam(name = "MasterCTPDashboardReq", value = "MasterCTPDashboardReq data", required = true)
			@RequestBody MasterCTPDashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UniformDashboardRes dashboardRes = null;
		Map<String, Object> response = null;
		try {
			boolean isFilter = false;
			boolean isExcel = false;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
			if (!dashboardReq.getServiceLine().equalsIgnoreCase("AWD")
					&& !dashboardReq.getServiceLine().equalsIgnoreCase("CTP")) {

				dashboardRes = ctpDashboardBO.getUniformData(isExcel, isFilter,
						dashboardReq, dashboardReq.getIndex(),
						dashboardReq.getTaskType(), dashboardReq.getUsername());
			//	dashboardRes = ctpDashboardBO.getUniformData(isExcel, isFilter,	dashboardReq);
			} else {
				dashboardRes = new UniformDashboardRes();
				dashboardRes.setRecords(new ArrayList<>());
				dashboardRes.setResponseCode("0");
				dashboardRes.setResponseMessage("Success");
			}
			if (dashboardRes != null
					&& dashboardRes.getResponseCode() != null
					&& dashboardRes.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(UNIFORM_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(UNIFORM_DASHBOARD, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, dashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UNIFORM_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UNIFORM_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(UNIFORM_DASHBOARD, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, dashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UNIFORM_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UNIFORM_DASHBOARD,
					formattedDate);
			response = CommonUtils.getResponseObject(UNIFORM_DASHBOARD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, dashboardRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UNIFORM_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To export excel for Uniform Dashboard")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/uniformdashboardexcel", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getUniformDashboardExcel(
			@ApiParam(name = "MasterCTPDashboardReq", value = "MasterCTPDashboardReq data", required = true)
			@RequestBody MasterCTPDashboardReq dashboardReq) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		UniformDashboardRes dashboardRes = null;
		String excelStream = "";
		boolean isFilter = false;
		try {
			boolean isExcel = true;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
			if (!dashboardReq.getServiceLine().equalsIgnoreCase("AWD")
					&& !dashboardReq.getServiceLine().equalsIgnoreCase("CTP")) {

				dashboardRes = ctpDashboardBO.getUniformData(isExcel, isFilter,
						dashboardReq, dashboardReq.getIndex(),
						dashboardReq.getTaskType(), dashboardReq.getUsername());
			}
			
			excelStream = ExportExcelUtil.generateUniformDashboardExcel(dashboardReq,dashboardRes.getRecords());

			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "200", "0",
					ControllerConstants.SUCCESS_DESC);

			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);

			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);

			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception e) {
			log.error("EXCEPTION OCCURRED: {}", e.getMessage());
			e.printStackTrace();
			response = CommonUtils.getResponseObject(
					ControllerConstants.EXPORT_EXCEL, "501", "501",
					e.getMessage());
			Map<String, Object> excelDetails = new LinkedHashMap<>();
			excelDetails.put("messageheader", response);
			excelDetails.put("excelstream", excelStream);
			Map<String, Object> json = new HashMap<>();
			json.put("exceldownload", excelDetails);

			HttpHeaders headers = new HttpHeaders();
			headers.add("timestamp", formattedDate);
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Notes Attempt Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/notesattempt", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNotesAttempt(
			@ApiParam(name = "MasterCTPDashboardReq", value = "MasterCTPDashboardReq data", required = true)
			@RequestBody MasterCTPDashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		NotesAttemptDetails res = new NotesAttemptDetails();
		String requestId = UUID.randomUUID().toString();
		log.info("requestDocs - Received request id : " +requestId);
		
		try {
			if (req == null || req.getServiceLine() == null
					|| req.getServiceLine().isEmpty()) {
				res.setResponseCode("1");
				res.setResponseMessage("Invalid serviceLine!");
				res.setRequestId(requestId);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTES_ATTEMPT_DETAILS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			res = ctpDashboardBO.getAttemptTypeByServiceline(req.getServiceLine());
			
			if (res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTES_ATTEMPT_DETAILS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.OK);
			} else {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTES_ATTEMPT_DETAILS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			res = new NotesAttemptDetails();
			res.setRequestId(requestId);
			res.setResponseCode("2");
			res.setResponseMessage(ControllerConstants.UNKNOWN_ERROR);
			
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NOTES_ATTEMPT_DETAILS);
		
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Order Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/api/docservices/orderNotification", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> orderNotification(
			@ApiParam(name = "DocsReq", value = "DocsReq data", required = true)
			@Valid @RequestBody WoundQOrderNotificationReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		WoundQOrderNotificationRes res = new WoundQOrderNotificationRes();
		String requestId = UUID.randomUUID().toString();
		log.info("orderNotification - Received request id : " +requestId);
		
		try {
			log.info("orderNotification - Request: " +req);
			
			Map<String, String> validationError = ctpDashboardBO.validDocReqForWoundQ(req);
			
			if (validationError.size() > 0) {
				res.setResponseCode("1");
				res.setResponseMessage(validationError.toString());
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			res = ctpDashboardBO.getOrderDetails(req);
			
			if (res != null
					&& res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
				
				log.info("orderNotification - res: " +res);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.OK);
			} else {
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
				
				log.info("orderNotification - res: " +res);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			res.setResponseCode("2");
			res.setResponseMessage(ControllerConstants.UNKNOWN_ERROR);
			
			log.info("orderNotification - res: " +res);
			
			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.REQUEST_EDOCS);
		
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
