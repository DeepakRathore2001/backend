package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.UPDATE_PATIENT_DETAILS;
import static com.healogics.rtrv.constants.ControllerConstants.GET_ATTACHMENT_REQUEST;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_CHART_DETAIS;
import static com.healogics.rtrv.constants.ControllerConstants.SAVE_MASTER_NOTES;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_NOTES_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.SAVE_MASTER_CHART_DETAILS;
import static com.healogics.rtrv.constants.ControllerConstants.GET_DOCUMENT_CONTENT;
import static com.healogics.rtrv.constants.ControllerConstants.GET_ORDER_INFORMATION_UPDATES;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_HISTORY_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.SUBMIT_MASTER_CHART;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_VISIT_LIST_GET;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_MODIFY_RECORD;
import static com.healogics.rtrv.constants.ControllerConstants.GET_SAVED_ATTACHMENTS;
import static com.healogics.rtrv.constants.ControllerConstants.VIEW_SAVED_ATTACHMENTS;
import static com.healogics.rtrv.constants.ControllerConstants.MASTER_NOTE_BY_ID;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.MasterChartReviewBO;
import com.healogics.rtrv.bo.MasterDocumentBO;
import com.healogics.rtrv.bo.Impl.RTRVAPIResponse;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.APIResponse;
import com.healogics.rtrv.dto.CTPOrderRes;
import com.healogics.rtrv.dto.GetOrderUpdateReq;
import com.healogics.rtrv.dto.GetSavedAttachmentRes;
import com.healogics.rtrv.dto.MasterChartDetailsReq;
import com.healogics.rtrv.dto.MasterChartDetailsRes;
import com.healogics.rtrv.dto.MasterGetAttachmentReq;
import com.healogics.rtrv.dto.MasterGetDocumentReq;
import com.healogics.rtrv.dto.MasterGetDocumentRes;
import com.healogics.rtrv.dto.MasterHistoryTimelineRes;
import com.healogics.rtrv.dto.MasterModifyRecordReq;
import com.healogics.rtrv.dto.MasterNoteByIdRes;
import com.healogics.rtrv.dto.MasterNotesListReq;
import com.healogics.rtrv.dto.MasterNotesListRes;
import com.healogics.rtrv.dto.MasterSaveChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartReq;
import com.healogics.rtrv.dto.MasterSubmitChartRes;
import com.healogics.rtrv.dto.SaveMasterNotesReq;
import com.healogics.rtrv.dto.SaveResponse;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsRes;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.dto.VisitDocumentListReq;
import com.healogics.rtrv.dto.VisitDocumentRes;
import com.healogics.rtrv.dto.VisitsListRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class MasterChartReviewController {
	private final Logger log = LoggerFactory
			.getLogger(MasterChartReviewController.class);

	private final MasterChartReviewBO masterChartReviewBO;
	private final MasterDocumentBO masterDocumentBO;
	
	@Autowired
	public MasterChartReviewController(MasterChartReviewBO masterChartReviewBO,
			MasterDocumentBO masterDocumentBO) {
		this.masterChartReviewBO = masterChartReviewBO;
		this.masterDocumentBO = masterDocumentBO;
	}
	
	@ApiOperation(value = "To save notes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savemasternotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveMasterNotes(
			@ApiParam(name = "SaveMasterNotesReq", value = "SaveMasterNotesReq data", required = true)
			@RequestBody SaveMasterNotesReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		RTRVAPIResponse res = null;
		Map<String, Object> response = null;
		try {
			res = masterChartReviewBO.saveMasterNotes(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_MASTER_NOTES,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_MASTER_NOTES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SAVE_MASTER_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_MASTER_NOTES,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_MASTER_NOTES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SAVE_MASTER_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_MASTER_NOTES,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_MASTER_NOTES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					SAVE_MASTER_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To Get notes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getmasternotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getMasterNotesList(
			@ApiParam(name = "MasterNotesListReq", value = "MasterNotesListReq data", required = true)
			@RequestBody MasterNotesListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterNotesListRes res = null;
		Map<String, Object> response = null;
		try {
			res = masterChartReviewBO.getMasterNotesList(req.getRequestId(),
					req.getIndex(),req.getServiceLine());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MASTER_NOTES_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_NOTES_LIST, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						MASTER_NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MASTER_NOTES_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_NOTES_LIST, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						MASTER_NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_NOTES_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_NOTES_LIST, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					MASTER_NOTES_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Save Master Chart Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savemasterchart", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveDetailsAttachment(
			@ApiParam(name = "MasterSaveChartReq", value = "MasterSaveChartReq data", required = true)
			@RequestBody MasterSaveChartReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveResponse saveResponse = null;
		Map<String, Object> response = null;
		log.debug("MasterSaveChartReq : " +req);
		log.info("req : " +req);
		try {
			saveResponse = masterChartReviewBO.saveMasterChartDetails(req);

			if (saveResponse != null && saveResponse.getResponseCode() != null
					&& saveResponse.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_MASTER_CHART_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_MASTER_CHART_DETAILS, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, saveResponse);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_MASTER_CHART_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_MASTER_CHART_DETAILS,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_MASTER_CHART_DETAILS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, saveResponse);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_MASTER_CHART_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_MASTER_CHART_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_MASTER_CHART_DETAILS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, saveResponse);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_MASTER_CHART_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Saved Attachments Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getattachments", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getSavedAttachments(
			@ApiParam(name = "MasterChartDetailsReq", value = "MasterChartDetailsReq data", required = true)
			@RequestBody MasterChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		GetSavedAttachmentRes chartReviewRes = null;
		Map<String, Object> response = null;
		try {

			chartReviewRes = masterChartReviewBO.getSavedDocuments(req);

			if (chartReviewRes != null
					&& chartReviewRes.getResponseCode() != null
					&& chartReviewRes.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils
						.getMessageHeader(GET_SAVED_ATTACHMENTS, formattedDate);
				response = CommonUtils.getResponseObject(GET_SAVED_ATTACHMENTS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_SAVED_ATTACHMENTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (chartReviewRes != null && chartReviewRes.getResponseCode() != null
					&& chartReviewRes.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(
						GET_SAVED_ATTACHMENTS, formattedDate);
				response = CommonUtils.getResponseObject(GET_SAVED_ATTACHMENTS,
						"406", chartReviewRes.getResponseCode(), chartReviewRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_SAVED_ATTACHMENTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils
						.getMessageHeader(GET_SAVED_ATTACHMENTS, formattedDate);
				response = CommonUtils.getResponseObject(GET_SAVED_ATTACHMENTS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_SAVED_ATTACHMENTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(GET_SAVED_ATTACHMENTS,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_SAVED_ATTACHMENTS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_SAVED_ATTACHMENTS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Attachment Content Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/viewdocument", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> viewSavedAttachments(
			@ApiParam(name = "MasterChartDetailsReq", value = "MasterChartDetailsReq data", required = true)
			@RequestBody MasterChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ViewAttachmentRes chartReviewRes = null;
		Map<String, Object> response = null;
		try {

			chartReviewRes = masterChartReviewBO.getAttachmentContent(req);

			if (chartReviewRes != null
					&& chartReviewRes.getResponseCode() != null
					&& chartReviewRes.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils
						.getMessageHeader(VIEW_SAVED_ATTACHMENTS, formattedDate);
				response = CommonUtils.getResponseObject(VIEW_SAVED_ATTACHMENTS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_SAVED_ATTACHMENTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils
						.getMessageHeader(VIEW_SAVED_ATTACHMENTS, formattedDate);
				response = CommonUtils.getResponseObject(VIEW_SAVED_ATTACHMENTS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_SAVED_ATTACHMENTS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(VIEW_SAVED_ATTACHMENTS,
					formattedDate);
			response = CommonUtils.getResponseObject(VIEW_SAVED_ATTACHMENTS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.VIEW_SAVED_ATTACHMENTS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Master Chart Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getmasterchartdetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCharReviewDetails(
			@ApiParam(name = "MasterChartDetailsReq", value = "MasterChartDetailsReq data", required = true)
			@RequestBody MasterChartDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterChartDetailsRes chartReviewRes = null;
		Map<String, Object> response = null;
		try {

			chartReviewRes = masterChartReviewBO.getChartData(req);

			if (chartReviewRes != null
					&& chartReviewRes.getResponseCode() != null
					&& chartReviewRes.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils
						.getMessageHeader(MASTER_CHART_DETAIS, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_CHART_DETAIS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_CHART_DETAIS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils
						.getMessageHeader(MASTER_CHART_DETAIS, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_CHART_DETAIS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_CHART_DETAIS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_CHART_DETAIS,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_CHART_DETAIS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_CHART_DETAIS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Get Attachment Request to iHeal")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/api/docservices/getattachmentrequest", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAttachmentRequest(
			@ApiParam(name = "MasterGetAttachmentReq", value = "MasterGetAttachmentReq data", required = true)
			@RequestBody MasterGetAttachmentReq req) {
		
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		Map<String, Object> messageHeader;
		CTPOrderRes orderRes = new CTPOrderRes();
		String requestId = UUID.randomUUID().toString();
		log.info("Received request id : " +requestId);
		try {			
			Map<String, String> validationError = validAttachmentReq(req);
			
			if (validationError.size() > 0) {
				orderRes.setResponseCode("1");
				orderRes.setResponseMessage(validationError.toString());
				orderRes.setRequestId(requestId);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.REQUEST_EDOCS);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			//Call BO Method and After BO call Kerecis API to send notifications
			
			
			orderRes.setResponseCode("0");
			orderRes.setResponseMessage("Attachment Request Received!");
			orderRes.setRequestId(requestId);

			if (orderRes != null && orderRes.getResponseCode() != null
					&& orderRes.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						GET_ATTACHMENT_REQUEST, formattedDate);
				response = CommonUtils.getResponseObject(GET_ATTACHMENT_REQUEST,
						"200", orderRes.getResponseCode(), orderRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_ATTACHMENT_REQUEST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						GET_ATTACHMENT_REQUEST, formattedDate);
				response = CommonUtils.getResponseObject(GET_ATTACHMENT_REQUEST,
						"500", (orderRes != null ? orderRes.getResponseCode() : ""),
						(orderRes != null ? orderRes.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, orderRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_ATTACHMENT_REQUEST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(GET_ATTACHMENT_REQUEST,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_ATTACHMENT_REQUEST,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, orderRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_ATTACHMENT_REQUEST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private Map<String, String> validAttachmentReq(MasterGetAttachmentReq req){
		Map<String, String> validationError = new HashMap<>();
		if (req == null) {
			validationError.put("request", "Invalid request!");
		} else {
			if (req.getMasterToken() == null
					|| req.getMasterToken().isEmpty()) {
				validationError.put("masterToken", "Invalid Master Token!");
			}
			if (req.getUserId() == null
					|| req.getUserId().isEmpty()) {
				validationError.put("userId", "Invalid User Id!");
			}
			
			if (req.getPatientId() == null
					|| req.getPatientId().isEmpty()) {
				validationError.put("patientId", "Invalid Patient ID!");
			}
			
			if (req.getFacilityId() == null
					|| req.getFacilityId().isEmpty()) {
				validationError.put("facilityId", "Invalid Facility Id!");
			}
			
			if (req.getDocumentObjs() == null || req.getDocumentObjs().size() <= 0) {
				validationError.put("documents", "Invalid Documents!");
			}
		
		}
		return validationError;
	}
	
	
	@ApiOperation(value = "Get Document Content to Kerecis")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/api/docservices/getdocument", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDocumentContent(
			@ApiParam(name = "MasterGetDocumentReq", value = "MasterGetDocumentReq data", required = true)
			@RequestBody MasterGetDocumentReq req) {
		
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		Map<String, Object> messageHeader;
		MasterGetDocumentRes res = new MasterGetDocumentRes();
		Map<String, String> validationError = new HashMap<>();
		try {		
			
			if (req == null) {
				validationError.put("request", "Invalid request!");
			} else {
				if (req.getDocumentRequestId() == null
						|| req.getDocumentRequestId().isEmpty()) {
					validationError.put("documentRequestId", "Invalid Document Request Id!");
				}
				if (req.getDocumentToken() == null
						|| req.getDocumentToken().isEmpty()) {
					validationError.put("documentToken", "Invalid Document Token!");
				}
			}
			
			if (validationError.size() > 0) {
				res.setErrorCode("1");
				res.setErrorMessage(validationError.toString());
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_DOCUMENT_CONTENT);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			//Call BO Method to get document from RTRV DB
			res = masterDocumentBO.getDocumentContent(req);

			if (res != null && res.getErrorCode() != null
					&& res.getErrorCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						GET_DOCUMENT_CONTENT, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_CONTENT,
						"200", res.getErrorCode(), res.getErrorMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_DOCUMENT_CONTENT);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						GET_DOCUMENT_CONTENT, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOCUMENT_CONTENT,
						"500", (res != null ? res.getErrorCode() : ""),
						(res != null ? res.getErrorMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_DOCUMENT_CONTENT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(GET_DOCUMENT_CONTENT,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_DOCUMENT_CONTENT,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_DOCUMENT_CONTENT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get history list")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getmasterhistory", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getOrderHistory(
			@ApiParam(name = "OrderReq", value = "OrderReq data", required = true)
			@RequestBody MasterNotesListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterHistoryTimelineRes res = null;
		Map<String, Object> response = null;
		try {

			res = masterChartReviewBO.getOrderHistory(req.getRequestId(), req.getIndex());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MASTER_HISTORY_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_HISTORY_LIST, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						MASTER_HISTORY_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MASTER_HISTORY_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_HISTORY_LIST, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						MASTER_HISTORY_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_HISTORY_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_HISTORY_LIST, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					MASTER_HISTORY_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Submit Master Chart")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/submitmasterchart", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> submitMasterChart(
			@ApiParam(name = "MasterSubmitChartReq", value = "MasterSubmitChartReq data", required = true)
			@RequestBody MasterSubmitChartReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterSubmitChartRes res = null;
		Map<String, Object> response = null;
		try {
			log.info("submitmasterchart with orderId: " +req.getOrderId());
			
			res = masterChartReviewBO.masterSubmitChart(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SUBMIT_MASTER_CHART,
						formattedDate);
				response = CommonUtils.getResponseObject(SUBMIT_MASTER_CHART, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SUBMIT_MASTER_CHART);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SUBMIT_MASTER_CHART,
						formattedDate);
				response = CommonUtils.getResponseObject(SUBMIT_MASTER_CHART, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						SUBMIT_MASTER_CHART);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SUBMIT_MASTER_CHART,
					formattedDate);
			response = CommonUtils.getResponseObject(SUBMIT_MASTER_CHART, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					SUBMIT_MASTER_CHART);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get List of document id from iHeal")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getvisitdocumentlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getVisitDocumentList(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody VisitDocumentListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		VisitDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken()) || StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = masterChartReviewBO.getVisitDocumentList(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_VISIT_DOCUMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_DOCUMENT_LIST, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_VISIT_DOCUMENT_LIST, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_DOCUMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To get List of Visits from iHeal")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getvisitlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getVisitsList(
			@ApiParam(name = "VisitListGet Req", value = "Visits Req", required = true) @RequestBody VisitDocumentListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		VisitsListRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken()) || StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_VISIT_LIST_GET, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_LIST_GET);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = masterChartReviewBO.getVisitsList(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_LIST_GET, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_VISIT_LIST_GET);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_LIST_GET, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_LIST_GET);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_LIST_GET, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_VISIT_LIST_GET, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_LIST_GET);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_VISIT_LIST_GET, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_VISIT_LIST_GET, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_VISIT_LIST_GET);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Receive Update Information from Kerecis")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/api/docservices/updateDocumentation", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateDocumentation(
			@ApiParam(name = "GetOrderUpdateReq", value = "GetOrderUpdateReq data", required = true)
			@RequestBody GetOrderUpdateReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		Map<String, Object> messageHeader;
		APIResponse res = new APIResponse();
		Map<String, String> validationError = new HashMap<>();
		
		try {		
			log.debug("updateDocumentation Request Received from Vendor: {}",req);
			
			if (req == null) {
				validationError.put("request", "Invalid request!");
				
			} else {
				if (req.getVendorId() == 0) {
					validationError.put("vendorRequestId", "Invalid Vendor Id!");
					
				} else {
					if (req.getVendorId() == 3) {
						//CTP
						if (req.getVendorRequestId() == null
								|| req.getVendorRequestId().isEmpty()) {
							validationError.put("vendorRequestId", "Invalid Vendor RequestId!");
						}
						if (req.getVendorStatus() == null
								|| req.getVendorStatus().isEmpty()) {
							validationError.put("vendorStatus", "Invalid Vendor Status!");
						}
						
					} else if (req.getVendorId() == 5) {
						//NPWT
					}
				}
			}
			
			if (validationError.size() > 0) {
				res.setResponseCode("1");
				res.setResponseMessage(validationError.toString());
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_ORDER_INFORMATION_UPDATES);
			
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}
			
			//Call BO Method to store all updates to DB
			res = masterChartReviewBO.updateOrderInformation(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						GET_ORDER_INFORMATION_UPDATES, formattedDate);
				response = CommonUtils.getResponseObject(GET_ORDER_INFORMATION_UPDATES,
						"200", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_ORDER_INFORMATION_UPDATES);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);
				
			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("2")) {
				messageHeader = CommonUtils.getMessageHeader(
						GET_ORDER_INFORMATION_UPDATES, formattedDate);
				response = CommonUtils.getResponseObject(GET_ORDER_INFORMATION_UPDATES,
						"404", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_ORDER_INFORMATION_UPDATES);

				return new ResponseEntity<>(json, headers, HttpStatus.NOT_FOUND);
				
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						GET_ORDER_INFORMATION_UPDATES, formattedDate);
				response = CommonUtils.getResponseObject(GET_ORDER_INFORMATION_UPDATES,
						"500", (res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_ORDER_INFORMATION_UPDATES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(GET_ORDER_INFORMATION_UPDATES,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_ORDER_INFORMATION_UPDATES,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_ORDER_INFORMATION_UPDATES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To Modify Master Record")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/mastermodifyrecord", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> modifyRecord(
			@ApiParam(name = "MasterModifyRecordReq", value = "MasterModifyRecordReq data", required = true)
			@RequestBody MasterModifyRecordReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveResponse res = null;
		Map<String, Object> response = null;
		try {

			res = masterChartReviewBO.modifyRecord(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						MASTER_MODIFY_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_MODIFY_RECORD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_MODIFY_RECORD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						MASTER_MODIFY_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(MASTER_MODIFY_RECORD,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_MODIFY_RECORD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_MODIFY_RECORD,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_MODIFY_RECORD,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_MODIFY_RECORD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch Note Data By Id")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getmasternotebyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNoteById(
			@ApiParam(name = "SaveMasterNotesReq", value = "SaveMasterNotesReq data", required = true)
			@RequestBody SaveMasterNotesReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		MasterNoteByIdRes res = null;
		Map<String, Object> response = null;
		try {

			res = masterChartReviewBO.getNoteById(req.getNoteId());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(MASTER_NOTE_BY_ID,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_NOTE_BY_ID, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_NOTE_BY_ID);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(MASTER_NOTE_BY_ID,
						formattedDate);
				response = CommonUtils.getResponseObject(MASTER_NOTE_BY_ID, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MASTER_NOTE_BY_ID);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MASTER_NOTE_BY_ID,
					formattedDate);
			response = CommonUtils.getResponseObject(MASTER_NOTE_BY_ID, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MASTER_NOTE_BY_ID);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@ApiOperation(value = "To Update Patient Details in DB")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/masterpatientlink", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updatePatientDetails(
			@ApiParam(name = "UpdatePatientDetailsReq", value = "UpdatePatientDetailsReq data", required = true)
			@RequestBody UpdatePatientDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UpdatePatientDetailsRes res = null;
		Map<String, Object> response = null;
		try {

			res = masterChartReviewBO.updatePatientDetails(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						UPDATE_PATIENT_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_PATIENT_DETAILS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_PATIENT_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						UPDATE_PATIENT_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_PATIENT_DETAILS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_PATIENT_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_PATIENT_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_PATIENT_DETAILS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_PATIENT_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
}
