package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.DASHBOARD;
import static com.healogics.rtrv.constants.ControllerConstants.FILTER_DASHBOARD;
import static com.healogics.rtrv.constants.ControllerConstants.NEW_TASK_COUNT;
import static com.healogics.rtrv.constants.ControllerConstants.SET_STATUS;
import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.UPDATE_ASSIGNED_TO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.healogics.rtrv.bo.DashboardBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.AWDDashboardRes;
import com.healogics.rtrv.dto.DashboardReq;
import com.healogics.rtrv.dto.FilterOptionsRes;
import com.healogics.rtrv.dto.SetStatusReq;
import com.healogics.rtrv.dto.SetStatusRes;
import com.healogics.rtrv.dto.UpdateAssignedToRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DashboardController {
	private final Logger log = LoggerFactory
			.getLogger(DashboardController.class);

	private final DashboardBO dashboardBO;
	
	@Autowired
	public DashboardController(DashboardBO dashboardBO) {
		this.dashboardBO = dashboardBO;
	}
	
	 private final SseEmitter emitter = new SseEmitter();
	  
	    @GetMapping("/app/stream")
	    public SseEmitter streamMessages() {
	        // Schedule a task to send periodic messages
	        Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(
	            () -> {
					try {
						emitter.send(SseEmitter.event().data("Hello from the server!"));
					} catch (IOException e) {
						log.info("Exception occured: " +e.getMessage());
					}
				},
	            0, 5, TimeUnit.SECONDS
	        );
	        return emitter;
	    }

	@ApiOperation(value = "Fetch Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/dashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDashboardDetails(
			@ApiParam(name = "DashboardReq", value = "DashboardReq data", required = true)
			@RequestBody DashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AWDDashboardRes awdDashboardRes = null;
		Map<String, Object> response = null;
		boolean isBatchAssignment = false;
		try {

			if (dashboardReq.getServiceLine().equalsIgnoreCase("AWD")) {

				awdDashboardRes = dashboardBO.getAWDData(isBatchAssignment,false, false,
						dashboardReq, dashboardReq.getIndex(),
						dashboardReq.getTaskType(), dashboardReq.getUsername());
			} else {
				awdDashboardRes = new AWDDashboardRes();
				awdDashboardRes.setRecords(new ArrayList<>());
				awdDashboardRes.setResponseCode("0");
				awdDashboardRes.setResponseMessage("Success");
			}
			if (awdDashboardRes != null
					&& awdDashboardRes.getResponseCode() != null
					&& awdDashboardRes.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(DASHBOARD, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, awdDashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(DASHBOARD, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, awdDashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(DASHBOARD,
					formattedDate);
			response = CommonUtils.getResponseObject(DASHBOARD, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, awdDashboardRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch New Task count")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@GetMapping(value = "/app/newtaskcount", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNewTaskCount() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		Long newTaskCount = 0L;
		Map<String, Object> response = null;
		try {
			newTaskCount = dashboardBO.getAWDNewTaskcount();

			messageHeader = CommonUtils.getMessageHeader(NEW_TASK_COUNT,
					formattedDate);
			response = CommonUtils.getResponseObject(NEW_TASK_COUNT, "200", "0",
					SUCCESS_DESC);

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, newTaskCount);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NEW_TASK_COUNT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.OK);

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NEW_TASK_COUNT,
					formattedDate);
			response = CommonUtils.getResponseObject(NEW_TASK_COUNT, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, newTaskCount);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NEW_TASK_COUNT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Dashboard columns Filter Options")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/searchfilteroptions", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFacilityMultiFilterOptions(
			@ApiParam(name = "Search Filter Options", value = "Search Filter Options", required = true)
			@RequestBody DashboardReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		FilterOptionsRes filterOptions = null;
		Map<String, Object> messageHeader;
		try {

			filterOptions = dashboardBO.getSearchFilterOptions(req);

			if (filterOptions == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "406", "22",
						"No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.FILTER_OPTIONS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.FILTER_OPTIONS, "200", "0",
						SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, filterOptions);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_OPTIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.FILTER_OPTIONS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.FILTER_OPTIONS, "500", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, filterOptions);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_OPTIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Filtered Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/filterdashboard", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getFilteredData(
			@ApiParam(name = "DashboardReq", value = "DashboardReq data", required = true)
			@RequestBody DashboardReq dashboardReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AWDDashboardRes awdDashboardRes = null;
		Map<String, Object> response = null;
		
		try {
			boolean isBatchAssignment = false;
			boolean isFilter = false;
			boolean isExcel = false;
			if (dashboardReq.getFilters() != null
					&& !dashboardReq.getFilters().isEmpty()) {
				isFilter = true;
			}
			if (dashboardReq.getServiceLine().equalsIgnoreCase("AWD")) {
				awdDashboardRes = dashboardBO.getAWDData(isBatchAssignment,isExcel, isFilter,
						dashboardReq, dashboardReq.getIndex(),
						dashboardReq.getTaskType(), dashboardReq.getUsername());
			} else {
				awdDashboardRes = new AWDDashboardRes();
				awdDashboardRes.setRecords(new ArrayList<>());
				awdDashboardRes.setResponseCode("0");
				awdDashboardRes.setResponseMessage("Success");
			}
			if (awdDashboardRes != null
					&& awdDashboardRes.getResponseCode() != null
					&& awdDashboardRes.getResponseCode()
							.equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(FILTER_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(FILTER_DASHBOARD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, awdDashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(FILTER_DASHBOARD,
						formattedDate);
				response = CommonUtils.getResponseObject(FILTER_DASHBOARD,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, awdDashboardRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.FILTER_DASHBOARD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(FILTER_DASHBOARD,
					formattedDate);
			response = CommonUtils.getResponseObject(FILTER_DASHBOARD, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, awdDashboardRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.FILTER_DASHBOARD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Set Status")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/setstatus", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> setAWDDashboardStatus(
			@ApiParam(name = "SetStatusReq", value = "DashboardReq data", required = true) @RequestBody SetStatusReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SetStatusRes res = null;
		Map<String, Object> response = null;
		try {

			res = dashboardBO.setStatus(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SET_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(SET_STATUS, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SET_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SET_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(SET_STATUS, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SET_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SET_STATUS,
					formattedDate);
			response = CommonUtils.getResponseObject(SET_STATUS, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SET_STATUS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "Update Batch Assigned To")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/batchassigned", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>>updateBatchAssignedTo(
			@ApiParam(name = "UpdateAssignedToReq", value = "UpdateAssignedToReq data", required = true)
			@RequestBody DashboardReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UpdateAssignedToRes res = null;
		Map<String, Object> response = null;
		AWDDashboardRes awdDashboardRes = null;
		boolean isFilter = false;
		boolean isBatchAssignment = true;
		try {

			if (req.getFilters() != null && !req.getFilters().isEmpty()) {
				isFilter = true;
			}

			awdDashboardRes = dashboardBO.getAWDData(isBatchAssignment, true, isFilter, req,
					req.getIndex(), req.getTaskType(), req.getUsername());
			log.debug("awdDashboardRes: {}",awdDashboardRes);
			
			res = dashboardBO.batchUpdateAssignee(req, awdDashboardRes.getRecords());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_ASSIGNED_TO,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_ASSIGNED_TO, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_ASSIGNED_TO);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_ASSIGNED_TO,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_ASSIGNED_TO, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_ASSIGNED_TO);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_ASSIGNED_TO,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_ASSIGNED_TO, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_ASSIGNED_TO);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

}
