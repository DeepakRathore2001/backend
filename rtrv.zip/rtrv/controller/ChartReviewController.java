package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.CHART_REVIEW_DETAILS;
import static com.healogics.rtrv.constants.ControllerConstants.MODIFY_RECORD;
import static com.healogics.rtrv.constants.ControllerConstants.NOTES_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.NOTE_BY_ID;
import static com.healogics.rtrv.constants.ControllerConstants.PATIENT_SEARCH;
import static com.healogics.rtrv.constants.ControllerConstants.SAVE_NOTES;
import static com.healogics.rtrv.constants.ControllerConstants.SAVE_REQUEST;
import static com.healogics.rtrv.constants.ControllerConstants.SUBMIT_REQUEST;
import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.UPDATE_PATIENT_DETAILS;
import static com.healogics.rtrv.constants.ControllerConstants.USER_ROLES;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.ChartReviewBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.ChartReviewReq;
import com.healogics.rtrv.dto.ChartReviewRes;
import com.healogics.rtrv.dto.ModifyRecordReq;
import com.healogics.rtrv.dto.NoteByIdRes;
import com.healogics.rtrv.dto.NotesListRes;
import com.healogics.rtrv.dto.PatientSearchReq;
import com.healogics.rtrv.dto.PatientSearchRes;
import com.healogics.rtrv.dto.SaveNotesReq;
import com.healogics.rtrv.dto.SaveNotesRes;
import com.healogics.rtrv.dto.SaveRequest;
import com.healogics.rtrv.dto.SaveResponse;
import com.healogics.rtrv.dto.SubmitRequest;
import com.healogics.rtrv.dto.UpdatePatientDetailsReq;
import com.healogics.rtrv.dto.UpdatePatientDetailsRes;
import com.healogics.rtrv.dto.UserRolesRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ChartReviewController {
	private final Logger log = LoggerFactory
			.getLogger(ChartReviewController.class);

	private final ChartReviewBO chartReviewBO;
	
	@Autowired
	public ChartReviewController(ChartReviewBO chartReviewBO) {
		this.chartReviewBO = chartReviewBO;
	}

	@ApiOperation(value = "Fetch Dashboard Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getchartdetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getCharReviewDetails(
			@ApiParam(name = "DashboardReq", value = "DashboardReq data", required = true)
			@RequestBody ChartReviewReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		ChartReviewRes chartReviewRes = null;
		Map<String, Object> response = null;
		try {

			chartReviewRes = chartReviewBO.getChartReviewData(req);

			if (chartReviewRes != null
					&& chartReviewRes.getResponseCode() != null
					&& chartReviewRes.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils
						.getMessageHeader(CHART_REVIEW_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(CHART_REVIEW_DETAILS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CHART_REVIEW_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils
						.getMessageHeader(CHART_REVIEW_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(CHART_REVIEW_DETAILS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.CHART_REVIEW_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(CHART_REVIEW_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(CHART_REVIEW_DETAILS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, chartReviewRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.CHART_REVIEW_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Save ChartReview Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savedetailsattachment", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveDetailsAttachment(
			@ApiParam(name = "SaveRequest", value = "SaveRequest data", required = true) @RequestBody SaveRequest req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveResponse saveResponse = null;
		Map<String, Object> response = null;
		try {

			saveResponse = chartReviewBO.saveDetailsnAttachments(req);

			if (saveResponse != null && saveResponse.getResponseCode() != null
					&& saveResponse.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_REQUEST,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_REQUEST, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, saveResponse);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_REQUEST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_REQUEST,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_REQUEST, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, saveResponse);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_REQUEST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_REQUEST,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_REQUEST, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, saveResponse);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_REQUEST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Submit ChartReview Details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/submitrecord", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> submitRecord(
			@ApiParam(name = "SubmitRequest", value = "SubmitRequest data", required = true) @RequestBody SubmitRequest req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveResponse saveResponse = null;
		Map<String, Object> response = null;
		try {

			saveResponse = chartReviewBO.submitRecord(req);
			
			log.debug("saveResponse : " +saveResponse);

			if (saveResponse != null && saveResponse.getResponseCode() != null
					&& saveResponse.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SUBMIT_REQUEST,
						formattedDate);
				response = CommonUtils.getResponseObject(SUBMIT_REQUEST, "200",
						"0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, saveResponse);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUBMIT_REQUEST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SUBMIT_REQUEST,
						formattedDate);
				response = CommonUtils.getResponseObject(SUBMIT_REQUEST, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, saveResponse);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SUBMIT_REQUEST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SUBMIT_REQUEST,
					formattedDate);
			response = CommonUtils.getResponseObject(SUBMIT_REQUEST, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, saveResponse);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SUBMIT_REQUEST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To save notes")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/savenotes", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> saveNotes(
			@ApiParam(name = "SaveNotesReq", value = "SaveNotesReq data", required = true) @RequestBody SaveNotesReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveNotesRes res = null;
		Map<String, Object> response = null;
		try {

			res = chartReviewBO.saveNotes(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_NOTES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
						formattedDate);
				response = CommonUtils.getResponseObject(SAVE_NOTES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.SAVE_NOTES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(SAVE_NOTES,
					formattedDate);
			response = CommonUtils.getResponseObject(SAVE_NOTES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.SAVE_NOTES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Notes Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getnoteslist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNotesList(
			@ApiParam(name = "ChartReviewReq", value = "ChartReviewReq data", required = true) @RequestBody ChartReviewReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NotesListRes res = null;
		Map<String, Object> response = null;
		try {

			res = chartReviewBO.getNotesData(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(NOTES_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(NOTES_LIST, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(NOTES_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(NOTES_LIST, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NOTES_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(NOTES_LIST, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NOTES_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Note Data By Id")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getnotebyid", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getNoteById(
			@ApiParam(name = "ChartReviewReq", value = "ChartReviewReq data", required = true)
			@RequestBody ChartReviewReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		NoteByIdRes res = null;
		Map<String, Object> response = null;
		try {

			res = chartReviewBO.getNoteById(req.getNoteId());

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(NOTE_BY_ID,
						formattedDate);
				response = CommonUtils.getResponseObject(NOTE_BY_ID, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTE_BY_ID);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(NOTE_BY_ID,
						formattedDate);
				response = CommonUtils.getResponseObject(NOTE_BY_ID, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.NOTE_BY_ID);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(NOTE_BY_ID,
					formattedDate);
			response = CommonUtils.getResponseObject(NOTE_BY_ID, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.NOTE_BY_ID);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Fetch Notes Data")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/getuserroleslist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getUserRolesList(
			@ApiParam(name = "ChartReviewReq", value = "ChartReviewReq data", required = true) 
			@RequestBody ChartReviewReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UserRolesRes res = null;
		Map<String, Object> response = null;
		boolean isSuperUser = false;
		try {
			if(req.getIsSuperUser() != null) {
				isSuperUser = req.getIsSuperUser();
			}
			res = chartReviewBO.getUserRoles(isSuperUser);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(USER_ROLES,
						formattedDate);
				response = CommonUtils.getResponseObject(USER_ROLES, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.USER_ROLES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(USER_ROLES,
						formattedDate);
				response = CommonUtils.getResponseObject(USER_ROLES, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.USER_ROLES);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(USER_ROLES,
					formattedDate);
			response = CommonUtils.getResponseObject(USER_ROLES, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.USER_ROLES);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "Patient Search")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/searchpatient", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> searchPatient(
			@ApiParam(name = "Patient Search Request", value = "Patient Search details", required = true) @RequestBody PatientSearchReq patientSearchReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		PatientSearchRes patientSearchRes = null;
		Map<String, Object> response;
		try {
			patientSearchRes = chartReviewBO.searchPatient(patientSearchReq);

			if (patientSearchRes != null
					&& patientSearchRes.getResponseCode() != null) {
				if (patientSearchRes.getResponseCode().equalsIgnoreCase("0")) {

					messageHeader = CommonUtils.getMessageHeader(PATIENT_SEARCH,
							formattedDate);
					response = CommonUtils.getResponseObject(PATIENT_SEARCH,
							"200", "0", SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE,
							patientSearchRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.PATIENT_SEARCH);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);
				} else {
					// All other error codes
					messageHeader = CommonUtils.getMessageHeader(PATIENT_SEARCH,
							formattedDate);
					response = CommonUtils.getResponseObject(PATIENT_SEARCH,
							"500", patientSearchRes.getResponseCode(),
							patientSearchRes.getResponseMessage());

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE,
							patientSearchRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.PATIENT_SEARCH);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				messageHeader = CommonUtils.getMessageHeader(PATIENT_SEARCH,
						formattedDate);
				response = CommonUtils.getResponseObject(PATIENT_SEARCH, "500",
						"556", "Invalid response");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, patientSearchRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.PATIENT_SEARCH);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(PATIENT_SEARCH,
					formattedDate);
			response = CommonUtils.getResponseObject(PATIENT_SEARCH, "556",
					"556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, patientSearchRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.PATIENT_SEARCH);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To Update Patient Details in DB")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/updatepatientdetails", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updatePatientDetails(
			@ApiParam(name = "UpdatePatientDetailsReq", value = "UpdatePatientDetailsReq data", required = true)
			@RequestBody UpdatePatientDetailsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UpdatePatientDetailsRes res = null;
		Map<String, Object> response = null;
		try {

			res = chartReviewBO.updatePatientDetails(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						UPDATE_PATIENT_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_PATIENT_DETAILS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_PATIENT_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						UPDATE_PATIENT_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_PATIENT_DETAILS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_PATIENT_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_PATIENT_DETAILS,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_PATIENT_DETAILS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_PATIENT_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To Modify Record")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/modifyrecord", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> modifyRecord(
			@ApiParam(name = "ModifyRecordReq", value = "ModifyRecordReq data", required = true)
			@RequestBody ModifyRecordReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		SaveResponse res = null;
		Map<String, Object> response = null;
		try {

			res = chartReviewBO.modifyRecord(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						MODIFY_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(MODIFY_RECORD,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MODIFY_RECORD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						MODIFY_RECORD, formattedDate);
				response = CommonUtils.getResponseObject(MODIFY_RECORD,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MODIFY_RECORD);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(MODIFY_RECORD,
					formattedDate);
			response = CommonUtils.getResponseObject(MODIFY_RECORD,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MODIFY_RECORD);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}