package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.APP_NOTIFICATION_COUNT;
import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.UPDATE_APP_NOTIFICATION;
import static com.healogics.rtrv.constants.ControllerConstants.APP_NOTIFICATIONS;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.AppNotificationBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.AppNotificaionsReq;
import com.healogics.rtrv.dto.AppNotificationCountRes;
import com.healogics.rtrv.dto.AppNotificationListRes;
import com.healogics.rtrv.dto.UpdateAppNotificationsRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AppNotificationsController {

	private final Logger log = LoggerFactory
			.getLogger(AppNotificationsController.class);

	private final AppNotificationBO appNotificationBO;

	@Autowired
	public AppNotificationsController(AppNotificationBO appNotificationBO) {
		this.appNotificationBO = appNotificationBO;
	}
	
	@ApiOperation(value = "Fetch App Notification Count")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/appnotificationstatus", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAppNotificationCount(
			@ApiParam(name = "AppNotificaionsReq", value = "AppNotificaionsReq data", required = true)
			@RequestBody AppNotificaionsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AppNotificationCountRes res = null;
		Map<String, Object> response = null;
		try {

			res = appNotificationBO.getNotificationCount(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						APP_NOTIFICATION_COUNT, formattedDate);
				response = CommonUtils.getResponseObject(APP_NOTIFICATION_COUNT,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.APP_NOTIFICATION_COUNT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						APP_NOTIFICATION_COUNT, formattedDate);
				response = CommonUtils.getResponseObject(APP_NOTIFICATION_COUNT,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.APP_NOTIFICATION_COUNT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(APP_NOTIFICATION_COUNT,
					formattedDate);
			response = CommonUtils.getResponseObject(APP_NOTIFICATION_COUNT,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.APP_NOTIFICATION_COUNT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@ApiOperation(value = "To update app notifications")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/updateappnotifications", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> updateAppNotification(
			@ApiParam(name = "AppNotificaionsReq", value = "AppNotificaionsReq data", required = true)
			@RequestBody AppNotificaionsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		UpdateAppNotificationsRes res = null;
		Map<String, Object> response = null;
		try {

			res = appNotificationBO.updateNotifications(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_APP_NOTIFICATION,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_APP_NOTIFICATION, "200", "0",
						SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_APP_NOTIFICATION);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(UPDATE_APP_NOTIFICATION,
						formattedDate);
				response = CommonUtils.getResponseObject(UPDATE_APP_NOTIFICATION, "500",
						"556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.UPDATE_APP_NOTIFICATION);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(UPDATE_APP_NOTIFICATION,
					formattedDate);
			response = CommonUtils.getResponseObject(UPDATE_APP_NOTIFICATION, "556", "556",
					excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.UPDATE_APP_NOTIFICATION);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "Fetch App Notification List")
	@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised")})
	@PostMapping(value = "/app/appnotifications", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAppNotificationList(
			@ApiParam(name = "AppNotificaionsReq", value = "AppNotificaionsReq data", required = true)
			@RequestBody AppNotificaionsReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		AppNotificationListRes res = null;
		Map<String, Object> response = null;
		try {

			res = appNotificationBO.getAppNotifications(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						APP_NOTIFICATIONS, formattedDate);
				response = CommonUtils.getResponseObject(APP_NOTIFICATIONS,
						"200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.APP_NOTIFICATIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						APP_NOTIFICATIONS, formattedDate);
				response = CommonUtils.getResponseObject(APP_NOTIFICATIONS,
						"500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.APP_NOTIFICATIONS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(APP_NOTIFICATIONS,
					formattedDate);
			response = CommonUtils.getResponseObject(APP_NOTIFICATIONS,
					"556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.APP_NOTIFICATIONS);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
