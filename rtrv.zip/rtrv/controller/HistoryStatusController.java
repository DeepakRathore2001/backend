package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;
import static com.healogics.rtrv.constants.ControllerConstants.STATUS_TIMELINE;
import static com.healogics.rtrv.constants.ControllerConstants.GET_DOC_UPLOAD_STATUS;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.HistoryStatusBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.DocumentUploadStatusRes;
import com.healogics.rtrv.dto.StatusTimelineReq;
import com.healogics.rtrv.dto.StatusTimelineRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class HistoryStatusController {
		private final Logger log = LoggerFactory
				.getLogger(HistoryStatusController.class);

		private final HistoryStatusBO historyStatusBO;
		
		@Autowired
		public HistoryStatusController(HistoryStatusBO historyStatusBO) {
			this.historyStatusBO = historyStatusBO;
		}

		@ApiOperation(value = "Fetch history of status")
		@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
				@ApiResponse(code = 401, message = "Unauthorised")})
		@PostMapping(value = "/app/getstatustimeline", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> getStatusTimeline(
				@ApiParam(name = "statusTimelineReq", value = "statusTimelineReq data", required = true)
				@RequestBody StatusTimelineReq statusTimelineReq) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> messageHeader;
			StatusTimelineRes statusTimeLineRes = null;
			Map<String, Object> response = null;
			try {

				statusTimeLineRes = historyStatusBO.getStatusHistory(
						statusTimelineReq.getBhcMedRecId(),
						statusTimelineReq.getBhcInvOrderId(),statusTimelineReq.getPage());

				if (statusTimeLineRes != null
						&& statusTimeLineRes.getResponseCode() != null
						&& statusTimeLineRes.getResponseCode()
								.equalsIgnoreCase("0")) {
					messageHeader = CommonUtils.getMessageHeader(STATUS_TIMELINE,
							formattedDate);
					response = CommonUtils.getResponseObject(STATUS_TIMELINE, "200", "0",
							SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, statusTimeLineRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.STATUS_TIMELINE);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);

				} else {
					messageHeader = CommonUtils.getMessageHeader(STATUS_TIMELINE,
							formattedDate);
					response = CommonUtils.getResponseObject(STATUS_TIMELINE, "500",
							"556", "Service Exception");

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, statusTimeLineRes);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.STATUS_TIMELINE);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}

			} catch (Exception excp) {
				log.error(String.format("Exception occured: %s", excp));
				messageHeader = CommonUtils.getMessageHeader(STATUS_TIMELINE,
						formattedDate);
				response = CommonUtils.getResponseObject(STATUS_TIMELINE, "556", "556",
						excp.getMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, statusTimeLineRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.STATUS_TIMELINE);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		
		@ApiOperation(value = "Fetch Document Upload status")
		@ApiResponses(value = {@ApiResponse(code = 200, message = SUCCESS_DESC),
				@ApiResponse(code = 401, message = "Unauthorised")})
		@PostMapping(value = "/app/docuploadstatus", headers = "Accept=application/json")
		public ResponseEntity<Map<String, Object>> getDocumentUploadStatus(
				@ApiParam(name = "statusTimelineReq", value = "statusTimelineReq data", required = true)
				@RequestBody StatusTimelineReq statusTimelineReq) {

			String formattedDate = CommonUtils.getformattedDate();
			Map<String, Object> messageHeader;
			DocumentUploadStatusRes res = null;
			Map<String, Object> response = null;
			try {

				res = historyStatusBO.getDocUploadStatus(
						statusTimelineReq.getDocumentUUID());

				if (res != null
						&& res.getResponseCode() != null
						&& res.getResponseCode()
								.equalsIgnoreCase("0")) {
					messageHeader = CommonUtils.getMessageHeader(GET_DOC_UPLOAD_STATUS,
							formattedDate);
					response = CommonUtils.getResponseObject(GET_DOC_UPLOAD_STATUS, "200", "0",
							SUCCESS_DESC);

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.GET_DOC_UPLOAD_STATUS);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers, HttpStatus.OK);

				} else {
					messageHeader = CommonUtils.getMessageHeader(GET_DOC_UPLOAD_STATUS,
							formattedDate);
					response = CommonUtils.getResponseObject(GET_DOC_UPLOAD_STATUS, "500",
							"556", "Service Exception");

					Map<String, Object> json = new HashMap<>();
					json.put(ControllerConstants.API_RESPONSE, res);
					HttpHeaders headers = new HttpHeaders();
					headers.add(ControllerConstants.TIMESTAMP, formattedDate);
					headers.add(ControllerConstants.ACTION,
							ControllerConstants.GET_DOC_UPLOAD_STATUS);
					headers.add(ControllerConstants.MSG_HEADER,
							String.valueOf(messageHeader));
					headers.add(ControllerConstants.RESPONSE,
							String.valueOf(response));
					return new ResponseEntity<>(json, headers,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}

			} catch (Exception excp) {
				log.error(String.format("Exception occured: %s", excp));
				messageHeader = CommonUtils.getMessageHeader(GET_DOC_UPLOAD_STATUS,
						formattedDate);
				response = CommonUtils.getResponseObject(GET_DOC_UPLOAD_STATUS, "556", "556",
						excp.getMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_DOC_UPLOAD_STATUS);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		

}
