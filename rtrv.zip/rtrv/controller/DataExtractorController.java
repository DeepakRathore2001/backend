package com.healogics.rtrv.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.Impl.DataExtractorService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DataExtractorController {
	
	private final Logger log = LoggerFactory.getLogger(DataExtractorController.class);
	
	@Autowired
	private DataExtractorService dataExtractorService;
	
	@ApiOperation(value = "To generate CTP Historical extract")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/user/generatectphistoricaldata", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> generateCTPHistoricalData() {
		try {
			dataExtractorService.runCTPHistoricalDataExtractor();

			Map<String, Object> json = new HashMap<>();
			json.put("status", "Success");
			HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<>(json, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));

			Map<String, Object> json = new HashMap<>();
			json.put("status", "Error");
			HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To generate NPWT Historical extract")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/user/generatenpwthistoricaldata", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> generateNPWTHistoricalData() {
		try {
			dataExtractorService.runNPWTHistoricalExtractor();

			Map<String, Object> json = new HashMap<>();
			json.put("status", "Success");
			HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<>(json, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));

			Map<String, Object> json = new HashMap<>();
			json.put("status", "Error");
			HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
