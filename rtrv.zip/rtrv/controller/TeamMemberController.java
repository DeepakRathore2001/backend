package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.TEAM_MEMBER_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.TeamMemberBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.TeamMemberReq;
import com.healogics.rtrv.dto.TeamMemberRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class TeamMemberController {
	private final Logger log = LoggerFactory.getLogger(TeamMemberController.class);

	private final TeamMemberBO teamMemberBO;
	
	@Autowired
	public TeamMemberController(TeamMemberBO teamMemberBO) {
		this.teamMemberBO = teamMemberBO;
	}

	@ApiOperation(value = "Fetch Team Member Data")
	@ApiResponses(value = { @ApiResponse(code = 200, message = SUCCESS_DESC),
			@ApiResponse(code = 401, message = "Unauthorised") })
	@PostMapping(value = "/app/teammembers", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getTeamMemberDetails(
			@ApiParam(name = "TeamMemberReq", value = "TeamMemberReq data", required = true)
			@RequestBody TeamMemberReq teamMemberReq) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> messageHeader;
		TeamMemberRes teamMemberRes = null;
		Map<String, Object> response = null;
		try {

			//default AWD
			teamMemberRes = teamMemberBO.getActiveTeamMebers();

			if (teamMemberRes != null && teamMemberRes.getResponseCode() != null
					&& teamMemberRes.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(TEAM_MEMBER_LIST, formattedDate);
				response = CommonUtils.getResponseObject(TEAM_MEMBER_LIST, "200", "0", SUCCESS_DESC);

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, teamMemberRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.TEAM_MEMBER_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(TEAM_MEMBER_LIST, formattedDate);
				response = CommonUtils.getResponseObject(TEAM_MEMBER_LIST, "500", "556", "Service Exception");

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, teamMemberRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.TEAM_MEMBER_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception excp) {
			log.error(String.format("Exception occured: %s", excp));
			messageHeader = CommonUtils.getMessageHeader(TEAM_MEMBER_LIST, formattedDate);
			response = CommonUtils.getResponseObject(TEAM_MEMBER_LIST, "556", "556", excp.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, teamMemberRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.TEAM_MEMBER_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
