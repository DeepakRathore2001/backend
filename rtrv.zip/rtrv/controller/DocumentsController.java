package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_CUSTOM_SCAN_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_DEBRIDEMENTS_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_PROGRESS_NOTES_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_PROVIDER_ORDER_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.IHEAL_TEST_RESULTS_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.MANUAL_ATTACHMENT_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.VIEW_ATTACHMENT;
import static com.healogics.rtrv.constants.ControllerConstants.VIEW_MANUAL_ATTACHMENT;
import static com.healogics.rtrv.constants.ControllerConstants.WOUND_LIST;
import static com.healogics.rtrv.constants.ControllerConstants.GET_DOC_URL;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.DocumentsBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.DocumentURLReq;
import com.healogics.rtrv.dto.DocumentURLRes;
import com.healogics.rtrv.dto.DocumentsListReq;
import com.healogics.rtrv.dto.IHealDocumentRes;
import com.healogics.rtrv.dto.IHealMedRecRes;
import com.healogics.rtrv.dto.IHealTesResultRes;
import com.healogics.rtrv.dto.ManualAttachmentRes;
import com.healogics.rtrv.dto.MedRecListReq;
import com.healogics.rtrv.dto.MedRecListRes;
import com.healogics.rtrv.dto.ViewAttachmentReq;
import com.healogics.rtrv.dto.ViewAttachmentRes;
import com.healogics.rtrv.dto.WoundListRes;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class DocumentsController {

	private final Logger log = LoggerFactory
			.getLogger(DocumentsController.class);

	private final DocumentsBO documentsBO;
	
	@Autowired
	public DocumentsController(DocumentsBO documentsBO) {
		this.documentsBO = documentsBO;
	}

	@ApiOperation(value = "To iHeal Custom Scan List")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getcustomscanlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getAttachmentDetails(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody DocumentsListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_CUSTOM_SCAN_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_CUSTOM_SCAN_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getIHealCustomScanList(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_CUSTOM_SCAN_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_CUSTOM_SCAN_LIST,
						"200", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_CUSTOM_SCAN_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_CUSTOM_SCAN_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_CUSTOM_SCAN_LIST,
						"406", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_CUSTOM_SCAN_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_CUSTOM_SCAN_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_CUSTOM_SCAN_LIST,
						"500", (res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_CUSTOM_SCAN_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_CUSTOM_SCAN_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_CUSTOM_SCAN_LIST,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.IHEAL_CUSTOM_SCAN_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To iHeal Test Results List")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/gettestresults", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getTestResults(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody DocumentsListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealTesResultRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_TEST_RESULTS_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_TEST_RESULTS_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getIHealTestResultsList(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_TEST_RESULTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_TEST_RESULTS_LIST,
						"200", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, IHEAL_TEST_RESULTS_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_TEST_RESULTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_TEST_RESULTS_LIST,
						"406", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_TEST_RESULTS_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_TEST_RESULTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(IHEAL_TEST_RESULTS_LIST,
						"500", (res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_TEST_RESULTS_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(IHEAL_TEST_RESULTS_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_TEST_RESULTS_LIST,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.IHEAL_TEST_RESULTS_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get List of Provider Order from iHeal")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getproviderorderlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getProviderOrderDetails(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody DocumentsListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_PROVIDER_ORDER_LIST,
						statusCode, errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROVIDER_ORDER_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getProviderOrderList(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROVIDER_ORDER_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROVIDER_ORDER_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						IHEAL_PROVIDER_ORDER_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROVIDER_ORDER_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROVIDER_ORDER_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROVIDER_ORDER_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROVIDER_ORDER_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROVIDER_ORDER_LIST, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROVIDER_ORDER_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils
					.getMessageHeader(IHEAL_PROVIDER_ORDER_LIST, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_PROVIDER_ORDER_LIST,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.IHEAL_PROVIDER_ORDER_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get List of Progress Notes from iHeal")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getprogressnoteslist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getProgressNotesDetails(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true)
			@RequestBody DocumentsListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST,
						statusCode, errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getProgressNotesList(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROGRESS_NOTES_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROGRESS_NOTES_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						IHEAL_PROGRESS_NOTES_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROGRESS_NOTES_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROGRESS_NOTES_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_PROGRESS_NOTES_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_PROGRESS_NOTES_LIST, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils
					.getMessageHeader(IHEAL_PROGRESS_NOTES_LIST, formattedDate);
			response = CommonUtils.getResponseObject(IHEAL_PROGRESS_NOTES_LIST,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.IHEAL_PROGRESS_NOTES_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get wound & measurement details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getwoundlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getWoundList(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody DocumentsListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		WoundListRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.WOUND_LIST, statusCode, errorCode,
						statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.WOUND_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getIHealWoundList(req);

			if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(WOUND_LIST, "200",
						res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, WOUND_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(WOUND_LIST, "406",
						res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.WOUND_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
						formattedDate);
				response = CommonUtils.getResponseObject(WOUND_LIST, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.WOUND_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(WOUND_LIST, "556", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.WOUND_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Debridements details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getdebridementslist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDebridementsList(
			@ApiParam(name = "Wound List Req", value = "Wound List Req", required = true) @RequestBody DocumentsListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| Integer.parseInt(req.getUserId()) == 0) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_DEBRIDEMENTS_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getDebridementsList(req);

			if (res != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_DEBRIDEMENTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_DEBRIDEMENTS_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// Unknown error
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_DEBRIDEMENTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_DEBRIDEMENTS_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_DEBRIDEMENTS_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_DEBRIDEMENTS_LIST, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(WOUND_LIST, "556", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.IHEAL_DEBRIDEMENTS_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Wound Assessment details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getwoundassessmentlist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getWoundAssessmentList(
			@ApiParam(name = "Wound List Req", value = "Wound List Req", required = true) @RequestBody DocumentsListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		IHealDocumentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| Integer.parseInt(req.getUserId()) == 0) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST,
						statusCode, errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getIHealWoundAssessmentList(req);

			if (res != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_WOUNDASSESSMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_WOUNDASSESSMENT_LIST, "200",
						res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// Unknown error
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_WOUNDASSESSMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_WOUNDASSESSMENT_LIST, "406",
						res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						IHEAL_WOUNDASSESSMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(
						IHEAL_WOUNDASSESSMENT_LIST, "500",
						(res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(WOUND_LIST, "556", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.IHEAL_WOUNDASSESSMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To get Manual Attachments details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getmanualattachments", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getManualAttachmentsList(
			@ApiParam(name = "Manual Attachment Req", value = "Manual Attachment Req", required = true) @RequestBody DocumentsListReq req) {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		ManualAttachmentRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMedRecId())
					|| StringUtils.isBlank(req.getBhcInvoiceOrderId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.MANUAL_ATTACHMENT_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MANUAL_ATTACHMENT_LIST);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getManualAttachmentsList(req);

			if (res != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						MANUAL_ATTACHMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(MANUAL_ATTACHMENT_LIST,
						"200", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MANUAL_ATTACHMENT_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null
					&& res.getResponseCode().equalsIgnoreCase("21")) {
				// Unknown error
				messageHeader = CommonUtils.getMessageHeader(
						MANUAL_ATTACHMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(MANUAL_ATTACHMENT_LIST,
						"406", res.getResponseCode(), res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MANUAL_ATTACHMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						MANUAL_ATTACHMENT_LIST, formattedDate);
				response = CommonUtils.getResponseObject(MANUAL_ATTACHMENT_LIST,
						"500", (res != null ? res.getResponseCode() : ""),
						(res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.MANUAL_ATTACHMENT_LIST);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(WOUND_LIST,
					formattedDate);
			response = CommonUtils.getResponseObject(WOUND_LIST, "556", "556",
					e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.MANUAL_ATTACHMENT_LIST);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To view attachment details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/viewattachment", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> viewAttachment(
			@ApiParam(name = "View Attachment Req", value = "View Attachment Req", required = true) @RequestBody ViewAttachmentReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		ViewAttachmentRes atachment = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken())
					|| StringUtils.isBlank(req.getFacilityId())
					|| StringUtils.isBlank(req.getPatientId())
					|| StringUtils.isBlank(req.getDocumentEntityId())
					|| StringUtils.isBlank(req.getiHealFileType())
					|| StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.VIEW_ATTACHMENT, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, atachment);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_ATTACHMENT);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			atachment = documentsBO.getIHealFileGet(req);

			if (atachment != null && atachment.getResponseCode() != null
					&& atachment.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(VIEW_ATTACHMENT,
						formattedDate);
				response = CommonUtils.getResponseObject(VIEW_ATTACHMENT, "200",
						atachment.getResponseCode(),
						atachment.getResponseDesc());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, atachment);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, VIEW_ATTACHMENT);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(VIEW_ATTACHMENT,
						formattedDate);
				response = CommonUtils.getResponseObject(VIEW_ATTACHMENT, "500",
						(atachment != null ? atachment.getResponseCode() : ""),
						(atachment != null ? atachment.getResponseDesc() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, atachment);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_ATTACHMENT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(VIEW_ATTACHMENT,
					formattedDate);
			response = CommonUtils.getResponseObject(VIEW_ATTACHMENT, "556",
					"556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, atachment);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.VIEW_ATTACHMENT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "To view manual attachment details")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/viewmanualattachment", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> viewManualAttachment(
			@ApiParam(name = "View Attachment Req", value = "View Attachment Req", required = true)
			@RequestBody ViewAttachmentReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		ViewAttachmentRes atachment = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getDocumentId())
					|| StringUtils.isBlank(req.getBhcInvoiceOrderId())
					|| StringUtils.isBlank(req.getMedRecId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.VIEW_MANUAL_ATTACHMENT, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, atachment);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_MANUAL_ATTACHMENT);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			atachment = documentsBO.viewManualAttachments(req);

			if (atachment != null && atachment.getResponseCode() != null
					&& atachment.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(
						VIEW_MANUAL_ATTACHMENT, formattedDate);
				response = CommonUtils.getResponseObject(VIEW_MANUAL_ATTACHMENT,
						"200", atachment.getResponseCode(),
						atachment.getResponseDesc());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, atachment);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, VIEW_MANUAL_ATTACHMENT);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						VIEW_MANUAL_ATTACHMENT, formattedDate);
				response = CommonUtils.getResponseObject(VIEW_MANUAL_ATTACHMENT,
						"500",
						(atachment != null ? atachment.getResponseCode() : ""),
						(atachment != null ? atachment.getResponseDesc() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, atachment);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.VIEW_MANUAL_ATTACHMENT);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(VIEW_MANUAL_ATTACHMENT,
					formattedDate);
			response = CommonUtils.getResponseObject(VIEW_MANUAL_ATTACHMENT,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, atachment);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.VIEW_MANUAL_ATTACHMENT);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get document URL")
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Success")})
	@PostMapping(value = "/app/getdocumenturl", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getDocumentURL(
			@ApiParam(name = "Get DocumentURL Req", value = "Get DocumentURL Req", required = true)
			@RequestBody DocumentURLReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		DocumentURLRes documentURLRes = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getDocumentId())
					|| StringUtils.isBlank(req.getMasterToken())
					|| req.getUserId() == 0
					|| StringUtils.isBlank(req.getFacilityId())) {
				
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(
						ControllerConstants.GET_DOC_URL, statusCode,
						errorCode, statusDesc);
				
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, documentURLRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_DOC_URL);
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.BAD_REQUEST);
			}

			documentURLRes = documentsBO.getDocumentURL(req);

			if (documentURLRes != null && documentURLRes.getResponseCode() != null
					&& documentURLRes.getResponseCode().equalsIgnoreCase("0")) {
				
				messageHeader = CommonUtils.getMessageHeader(
						GET_DOC_URL, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOC_URL,
						"200", documentURLRes.getResponseCode(),
						documentURLRes.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, documentURLRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, GET_DOC_URL);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else {
				messageHeader = CommonUtils.getMessageHeader(
						GET_DOC_URL, formattedDate);
				response = CommonUtils.getResponseObject(GET_DOC_URL,
						"500",
						(documentURLRes != null ? documentURLRes.getResponseCode() : ""),
						(documentURLRes != null ? documentURLRes.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, documentURLRes);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION,
						ControllerConstants.GET_DOC_URL);
				headers.add(ControllerConstants.MSG_HEADER,
						String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE,
						String.valueOf(response));
				return new ResponseEntity<>(json, headers,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(GET_DOC_URL,
					formattedDate);
			response = CommonUtils.getResponseObject(GET_DOC_URL,
					"556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, documentURLRes);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION,
					ControllerConstants.GET_DOC_URL);
			headers.add(ControllerConstants.MSG_HEADER,
					String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "To get List of med rec from iHeal")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@PostMapping(value = "/app/getmedreclist", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getMedRecList(
			@ApiParam(name = "Documents Req", value = "Attachment Req", required = true) @RequestBody MedRecListReq req) {

		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		String statusCode = ControllerConstants.SUCCESS_CODE;
		String errorCode = ControllerConstants.ZERO_ERROR_CODE;
		String statusDesc = ControllerConstants.SUCCESS_DESC;
		MedRecListRes res = null;
		Map<String, Object> messageHeader;
		try {
			if (StringUtils.isBlank(req.getMasterToken()) || StringUtils.isBlank(req.getUserId())) {
				statusCode = ControllerConstants.INVALID_PARAMETERS;
				errorCode = ControllerConstants.ERROR_CODE_NUMBER;
				statusDesc = ControllerConstants.INVALID_PARAMETERS;
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_MED_REC_LIST, statusCode,
						errorCode, statusDesc);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_MED_REC_LIST);
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.BAD_REQUEST);
			}

			res = documentsBO.getMedRecList(req);

			if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("0")) {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.IHEAL_MED_REC_LIST, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_MED_REC_LIST, "200", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_MED_REC_LIST);

				return new ResponseEntity<>(json, headers, HttpStatus.OK);

			} else if (res != null && res.getResponseCode() != null && res.getResponseCode().equalsIgnoreCase("21")) {
				// empty measurement
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.IHEAL_MED_REC_LIST, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_MED_REC_LIST, "406", res.getResponseCode(),
						res.getResponseMessage());

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_MED_REC_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);

			} else {
				messageHeader = CommonUtils.getMessageHeader(ControllerConstants.IHEAL_MED_REC_LIST, formattedDate);
				response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_MED_REC_LIST, "500",
						(res != null ? res.getResponseCode() : ""), (res != null ? res.getResponseMessage() : ""));

				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, res);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_MED_REC_LIST);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(ControllerConstants.IHEAL_MED_REC_LIST, formattedDate);
			response = CommonUtils.getResponseObject(ControllerConstants.IHEAL_MED_REC_LIST, "556", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, res);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.IHEAL_MED_REC_LIST);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}