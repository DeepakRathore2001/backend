package com.healogics.rtrv.controller;

import static com.healogics.rtrv.constants.ControllerConstants.SUCCESS_DESC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healogics.rtrv.bo.AboutPopupBO;
import com.healogics.rtrv.constants.ControllerConstants;
import com.healogics.rtrv.dto.BuildDetailsResponse;
import com.healogics.rtrv.utils.CommonUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AboutPopupController {
	
	private final Logger log = LoggerFactory.getLogger(AboutPopupController.class);
	
	private final AboutPopupBO aboutPopupBO;
	
	@Autowired
	public AboutPopupController(AboutPopupBO aboutPopupBO) {
		this.aboutPopupBO = aboutPopupBO;
	}
	
	@ApiOperation(value = "To get build details")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success") })
	@GetMapping(value = "/app/buildversion", headers = "Accept=application/json")
	public ResponseEntity<Map<String, Object>> getBuildVersion() {
		String formattedDate = CommonUtils.getformattedDate();
		Map<String, Object> response;
		BuildDetailsResponse buildDetails = null;
		Map<String, Object> messageHeader;
		try {
			buildDetails = aboutPopupBO.getBuildDetails();
			log.info("buildDetails : {}",buildDetails);
			
			if (buildDetails == null) {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.BUILD_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.BUILD_DETAILS, "406", "22", "No Records Found!");
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, buildDetails);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.BUILD_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.CONFLICT);
			} else {
				messageHeader = CommonUtils.getMessageHeader(
						ControllerConstants.BUILD_DETAILS, formattedDate);
				response = CommonUtils.getResponseObject(
						ControllerConstants.BUILD_DETAILS, "200", "0", SUCCESS_DESC);
				Map<String, Object> json = new HashMap<>();
				json.put(ControllerConstants.API_RESPONSE, buildDetails);
				HttpHeaders headers = new HttpHeaders();
				headers.add(ControllerConstants.TIMESTAMP, formattedDate);
				headers.add(ControllerConstants.ACTION, ControllerConstants.BUILD_DETAILS);
				headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
				headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
				return new ResponseEntity<>(json, headers, HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error(String.format("Exception occured: %s", e));
			messageHeader = CommonUtils.getMessageHeader(
					ControllerConstants.BUILD_DETAILS, formattedDate);
			response = CommonUtils.getResponseObject(
					ControllerConstants.BUILD_DETAILS, "500", "556", e.getMessage());

			Map<String, Object> json = new HashMap<>();
			json.put(ControllerConstants.API_RESPONSE, buildDetails);
			HttpHeaders headers = new HttpHeaders();
			headers.add(ControllerConstants.TIMESTAMP, formattedDate);
			headers.add(ControllerConstants.ACTION, ControllerConstants.BUILD_DETAILS);
			headers.add(ControllerConstants.MSG_HEADER, String.valueOf(messageHeader));
			headers.add(ControllerConstants.RESPONSE, String.valueOf(response));
			return new ResponseEntity<>(json, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
